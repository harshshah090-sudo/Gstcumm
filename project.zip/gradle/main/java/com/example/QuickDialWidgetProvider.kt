package com.example

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.view.View
import android.widget.RemoteViews
import com.example.data.AppDatabase
import com.example.data.ContactShortcut
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class QuickDialWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Run database query on IO thread asynchronously
        CoroutineScope(Dispatchers.IO).launch {
            val db = AppDatabase.getDatabase(context)
            val contacts = db.contactDao().getAllContactsDirect()
            
            // Update each widget on the home screen
            for (appWidgetId in appWidgetIds) {
                updateWidget(context, appWidgetManager, appWidgetId, contacts)
            }
        }
    }

    private fun updateWidget(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetId: Int,
        contacts: List<ContactShortcut>
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_folder_compact)

        // Bind clicking the entire Liquid Glass folder circle to open FolderActivity
        val folderIntent = Intent(context, FolderActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val folderPendingIntent = PendingIntent.getActivity(
            context,
            appWidgetId,
            folderIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.folder_circle, folderPendingIntent)
        views.setOnClickPendingIntent(R.id.widget_root, folderPendingIntent)

        // Previews of the first 4 slots inside the folder
        val initialsSlots = listOf(
            R.id.slot1_initials,
            R.id.slot2_initials,
            R.id.slot3_initials,
            R.id.slot4_initials
        )

        for (i in initialsSlots.indices) {
            val viewId = initialsSlots[i]
            if (i < contacts.size) {
                val contact = contacts[i]
                
                // Get initials
                val initials = if (contact.name.isNotBlank()) {
                    val parts = contact.name.trim().split("\\s+".toRegex())
                    if (parts.size >= 2) {
                        (parts[0].take(1) + parts[1].take(1)).uppercase()
                    } else {
                        contact.name.take(2).uppercase()
                    }
                } else {
                    "?"
                }

                var bitmap: Bitmap? = null
                if (contact.avatarUri != null) {
                    try {
                        val uri = Uri.parse(contact.avatarUri)
                        context.contentResolver.openInputStream(uri)?.use { inputStream ->
                            val decoded = BitmapFactory.decodeStream(inputStream)
                            if (decoded != null) {
                                bitmap = getCircularBitmap(decoded)
                            }
                        }
                    } catch (e: Exception) {
                        // fallback
                    }
                }

                if (bitmap == null) {
                    bitmap = createInitialsBitmap(context, initials, contact.colorHex)
                }

                views.setImageViewBitmap(viewId, bitmap)
            } else {
                // Empty preview placeholder
                val emptyBitmap = createInitialsBitmap(context, "+", "#374151")
                views.setImageViewBitmap(viewId, emptyBitmap)
            }
        }

        appWidgetManager.updateAppWidget(appWidgetId, views)
    }

    private fun getCircularBitmap(src: Bitmap): Bitmap {
        val size = Math.min(src.width, src.height)
        val output = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        
        val color = 0xff424242.toInt()
        val paint = Paint()
        val rect = Rect(0, 0, size, size)
        
        paint.isAntiAlias = true
        canvas.drawARGB(0, 0, 0, 0)
        paint.color = color
        canvas.drawCircle(size / 2f, size / 2f, size / 2f, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        
        val srcRect = Rect(
            (src.width - size) / 2,
            (src.height - size) / 2,
            (src.width + size) / 2,
            (src.height + size) / 2
        )
        canvas.drawBitmap(src, srcRect, rect, paint)
        return output
    }

    private fun createInitialsBitmap(context: Context, initials: String, colorHex: String): Bitmap {
        val density = context.resources.displayMetrics.density
        val sizePx = (32 * density).toInt() // 32dp
        val output = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        
        // Draw circle background
        val paint = Paint().apply {
            isAntiAlias = true
            color = try {
                Color.parseColor(colorHex)
            } catch (e: Exception) {
                Color.parseColor("#3F51B5")
            }
        }
        canvas.drawCircle(sizePx / 2f, sizePx / 2f, sizePx / 2f, paint)
        
        // Draw initials text
        paint.apply {
            color = Color.WHITE
            textSize = sizePx * 0.45f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        
        // Center text vertically
        val yPos = (sizePx / 2f) - ((paint.descent() + paint.ascent()) / 2f)
        canvas.drawText(initials, sizePx / 2f, yPos, paint)
        
        return output
    }

    companion object {
        fun triggerUpdate(context: Context) {
            val intent = Intent(context, QuickDialWidgetProvider::class.java).apply {
                action = AppWidgetManager.ACTION_APPWIDGET_UPDATE
                val ids = AppWidgetManager.getInstance(context).getAppWidgetIds(
                    ComponentName(context, QuickDialWidgetProvider::class.java)
                )
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            }
            context.sendBroadcast(intent)
        }
    }
}
