package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ContactRepository
import com.example.data.ContactShortcut
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ContactViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ContactRepository
    val allContacts: StateFlow<List<ContactShortcut>>

    init {
        val contactDao = AppDatabase.getDatabase(application).contactDao()
        repository = ContactRepository(contactDao)
        allContacts = repository.allContactsFlow.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addContact(name: String, phoneNumber: String, type: String, colorHex: String, avatarUri: String? = null) {
        viewModelScope.launch {
            val currentList = allContacts.value
            val nextIndex = if (currentList.isEmpty()) 0 else currentList.maxOf { it.orderIndex } + 1
            val newContact = ContactShortcut(
                name = name,
                phoneNumber = phoneNumber,
                type = type,
                colorHex = colorHex,
                avatarUri = avatarUri,
                orderIndex = nextIndex
            )
            repository.insert(newContact)
            QuickDialWidgetProvider.triggerUpdate(getApplication())
        }
    }

    fun updateContact(contact: ContactShortcut) {
        viewModelScope.launch {
            repository.update(contact)
            QuickDialWidgetProvider.triggerUpdate(getApplication())
        }
    }

    fun deleteContact(contact: ContactShortcut) {
        viewModelScope.launch {
            repository.delete(contact)
            
            // Re-order remaining contacts
            val remaining = repository.getAllContactsDirect()
            remaining.forEachIndexed { index, item ->
                repository.update(item.copy(orderIndex = index))
            }
            QuickDialWidgetProvider.triggerUpdate(getApplication())
        }
    }

    fun moveUp(contact: ContactShortcut) {
        viewModelScope.launch {
            val list = allContacts.value
            val index = list.indexOfFirst { it.id == contact.id }
            if (index > 0) {
                val prevContact = list[index - 1]
                repository.update(contact.copy(orderIndex = prevContact.orderIndex))
                repository.update(prevContact.copy(orderIndex = contact.orderIndex))
                QuickDialWidgetProvider.triggerUpdate(getApplication())
            }
        }
    }

    fun moveDown(contact: ContactShortcut) {
        viewModelScope.launch {
            val list = allContacts.value
            val index = list.indexOfFirst { it.id == contact.id }
            if (index != -1 && index < list.size - 1) {
                val nextContact = list[index + 1]
                repository.update(contact.copy(orderIndex = nextContact.orderIndex))
                repository.update(nextContact.copy(orderIndex = contact.orderIndex))
                QuickDialWidgetProvider.triggerUpdate(getApplication())
            }
        }
    }
}
