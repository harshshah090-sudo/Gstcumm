package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "contact_shortcuts")
data class ContactShortcut(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phoneNumber: String,
    val type: String = "BOTH", // "CALL", "SMS", "BOTH"
    val colorHex: String = "#3F51B5", // Beautiful accent colors
    val avatarUri: String? = null,
    val orderIndex: Int = 0
)
