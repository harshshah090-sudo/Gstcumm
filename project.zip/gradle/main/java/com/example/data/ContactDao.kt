package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ContactDao {
    @Query("SELECT * FROM contact_shortcuts ORDER BY orderIndex ASC")
    fun getAllContactsFlow(): Flow<List<ContactShortcut>>

    @Query("SELECT * FROM contact_shortcuts ORDER BY orderIndex ASC")
    suspend fun getAllContactsDirect(): List<ContactShortcut>

    @Query("SELECT * FROM contact_shortcuts WHERE id = :id")
    suspend fun getContactById(id: Int): ContactShortcut?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContact(contact: ContactShortcut): Long

    @Update
    suspend fun updateContact(contact: ContactShortcut)

    @Delete
    suspend fun deleteContact(contact: ContactShortcut)

    @Query("DELETE FROM contact_shortcuts WHERE id = :id")
    suspend fun deleteContactById(id: Int)
}
