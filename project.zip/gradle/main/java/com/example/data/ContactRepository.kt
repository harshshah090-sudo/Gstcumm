package com.example.data

import kotlinx.coroutines.flow.Flow

class ContactRepository(private val contactDao: ContactDao) {
    val allContactsFlow: Flow<List<ContactShortcut>> = contactDao.getAllContactsFlow()

    suspend fun getAllContactsDirect(): List<ContactShortcut> = contactDao.getAllContactsDirect()

    suspend fun getContactById(id: Int): ContactShortcut? = contactDao.getContactById(id)

    suspend fun insert(contact: ContactShortcut) = contactDao.insertContact(contact)

    suspend fun update(contact: ContactShortcut) = contactDao.updateContact(contact)

    suspend fun delete(contact: ContactShortcut) = contactDao.deleteContact(contact)

    suspend fun deleteById(id: Int) = contactDao.deleteContactById(id)
}
