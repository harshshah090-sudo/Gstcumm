package com.example

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import coil.compose.AsyncImage
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.AppDatabase
import com.example.data.ContactShortcut
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.flow.first

class FolderActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Disable opening transitions immediately
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            overrideActivityTransition(OVERRIDE_TRANSITION_OPEN, 0, 0)
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }

        // Enable beautiful real-time window blur for Android 12+ (API 31+)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            window.setBackgroundBlurRadius(35) // Elegant liquid glass background blur
        }
        
        setContent {
            MyApplicationTheme {
                FolderOverlayScreen(
                    onClose = { finish() },
                    onCallContact = { contact -> callContact(contact) },
                    onMessageContact = { contact -> messageContact(contact) }
                )
            }
        }
    }

    override fun finish() {
        super.finish()
        // Disable closing transitions for instant overlay feel
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            overrideActivityTransition(OVERRIDE_TRANSITION_CLOSE, 0, 0)
        } else {
            @Suppress("DEPRECATION")
            overridePendingTransition(0, 0)
        }
    }

    private fun callContact(contact: ContactShortcut) {
        val hasCallPermission = ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intent = if (hasCallPermission) {
            Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.phoneNumber}"))
        } else {
            // Fallback to dialer which doesn't require runtime permission
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:${contact.phoneNumber}"))
        }
        
        try {
            startActivity(intent)
            finish() // Close folder after action
        } catch (e: Exception) {
            Toast.makeText(this, "Could not start call: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun messageContact(contact: ContactShortcut) {
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${contact.phoneNumber}"))
        try {
            startActivity(intent)
            finish() // Close folder after action
        } catch (e: Exception) {
            Toast.makeText(this, "Could not open messenger: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@Composable
fun FolderOverlayScreen(
    onClose: () -> Unit,
    onCallContact: (ContactShortcut) -> Unit,
    onMessageContact: (ContactShortcut) -> Unit
) {
    val context = LocalContext.current
    var contacts by remember { mutableStateOf<List<ContactShortcut>>(emptyList()) }
    var visible by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val db = AppDatabase.getDatabase(context)
        db.contactDao().getAllContactsFlow().collect { list ->
            contacts = list
        }
    }

    LaunchedEffect(Unit) {
        // Trigger smooth entrance animation
        visible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)) // Deep blurred/dimmed backdrop
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                onClose()
            },
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = visible,
            enter = fadeIn(animationSpec = spring()) + slideInVertically(
                initialOffsetY = { it / 2 },
                animationSpec = spring()
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { /* Consume click to avoid closing when tapping container area */ },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (contacts.isEmpty()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "No contacts in folder yet.",
                            fontSize = 16.sp,
                            color = Color.White.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Open app to add quick contacts!",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Color.Cyan,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    // Lay out floating contacts directly without any container/folder card
                    val columnsCount = if (contacts.size <= 2) contacts.size else 3
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(columnsCount),
                        verticalArrangement = Arrangement.spacedBy(28.dp),
                        horizontalArrangement = Arrangement.spacedBy(20.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 20.dp)
                    ) {
                        items(contacts) { contact ->
                            FolderContactItem(
                                contact = contact,
                                onCall = { onCallContact(contact) },
                                onMessage = { onMessageContact(contact) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
                
                Text(
                    text = "Tap anywhere outside to close",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.45f),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun FolderContactItem(
    contact: ContactShortcut,
    onCall: () -> Unit,
    onMessage: () -> Unit
) {
    val initials = if (contact.name.isNotBlank()) {
        val parts = contact.name.trim().split("\\s+".toRegex())
        if (parts.size >= 2) {
            (parts[0].take(1) + parts[1].take(1)).uppercase()
        } else {
            contact.name.take(2).uppercase()
        }
    } else {
        "?"
    }

    val parsedColor = try {
        Color(android.graphics.Color.parseColor(contact.colorHex))
    } catch (e: Exception) {
        MaterialTheme.colorScheme.primary
    }

    Column(
        modifier = Modifier
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                if (contact.type == "SMS") {
                    onMessage()
                } else {
                    onCall()
                }
            }
            .padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Floating glass-like glowing circular avatar
        Box(
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(
                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(parsedColor.copy(alpha = 0.95f), parsedColor.copy(alpha = 0.65f)),
                    )
                )
                .border(
                    BorderStroke(2.dp, Color.White.copy(alpha = 0.85f)),
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (contact.avatarUri != null) {
                AsyncImage(
                    model = Uri.parse(contact.avatarUri),
                    contentDescription = "Avatar",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
            } else {
                Text(
                    text = initials,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = contact.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Label indicator for the action type
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = if (contact.type == "SMS") Icons.Default.Email else Icons.Default.Phone,
                contentDescription = contact.type,
                tint = Color.White.copy(alpha = 0.7f),
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (contact.type == "SMS") "SMS" else "Call",
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.7f)
            )
        }
    }
}
