package com.example

import com.example.data.DefaultPanchangSeed
import com.example.data.JainGacch
import com.example.data.PARYUSHAN_DAY_DUTIES
import com.example.data.ParyushanCalendarRepository
import com.example.data.ParyushanPhase
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

/**
 * Unit tests verifying Paryushan 8-day duty schedule and completion state.
 */
class ExampleUnitTest {

  @Test
  fun testParyushan8DaysDuties() {
    val panchangEvents = DefaultPanchangSeed.getDefault2026Events()
    val schedule = ParyushanCalendarRepository.allSchedules.first { it.year == 2026 && it.gacch == JainGacch.TAPAGACCH }
    val startMillis = schedule.startDateMillis
    val dayMs = 24 * 3600 * 1000L

    val expectedDuties = listOf(
      1 to ("Day 1" to "पर्यूषण 5 कर्तव्य"),
      2 to ("Day 2" to "वार्षिक 11 कर्तव्य"),
      3 to ("Day 3" to "पौषध आत्मा का औषध"),
      4 to ("Day 4" to "कल्पसूत्र वांचन"),
      5 to ("Day 5" to "जन्म वांचन"),
      6 to ("Day 6" to "पार्श्व, नेम एवं ऋषभ चरित्र"),
      7 to ("Day 7" to "स्थविरावली एवं समाचारी"),
      8 to ("Day 8" to "संवत्सरी एवं क्षमापना")
    )

    for ((dayNum, texts) in expectedDuties) {
      // Midday of that day (12:00 PM)
      val testTime = startMillis + ((dayNum - 1) * dayMs) + (6 * 3600 * 1000L)
      val state = ParyushanCalendarRepository.getCountdownState(
        gacch = JainGacch.TAPAGACCH,
        nowMillis = testTime,
        panchangEvents = panchangEvents
      )

      assertEquals("Expected active phase for Day $dayNum", ParyushanPhase.PARYUSHAN_ACTIVE, state.phase)
      assertEquals("Day number should match", dayNum, state.currentDayNumber)
      assertEquals("Main text should match", texts.first, state.activeDayMainText)
      assertEquals("Sub text should match", texts.second, state.activeDaySubText)
    }
  }

  @Test
  fun testPostDay9CompletionState() {
    val panchangEvents = DefaultPanchangSeed.getDefault2026Events()
    val schedule = ParyushanCalendarRepository.allSchedules.first { it.year == 2026 && it.gacch == JainGacch.TAPAGACCH }
    val startMillis = schedule.startDateMillis
    val dayMs = 24 * 3600 * 1000L
    // Day 9 Sunrise + 1 hour (07:00 AM on Sep 16, 2026)
    val day9SunrisePlus1h = startMillis + (8L * dayMs) + (3600 * 1000L)

    val state = ParyushanCalendarRepository.getCountdownState(
      gacch = JainGacch.TAPAGACCH,
      nowMillis = day9SunrisePlus1h,
      panchangEvents = panchangEvents // only 2026 events loaded
    )

    assertEquals("Expected COMPLETED phase after Day 9 sunrise", ParyushanPhase.PARYUSHAN_COMPLETED, state.phase)
    assertEquals("Active day main text should display completion", "पर्यूषण पर्व समाप्त 🙏🏻", state.activeDayMainText)
    assertEquals("Active day sub text should display Michhami Dukkadam", "मिच्छामि दुक्कडम्", state.activeDaySubText)
  }
}

