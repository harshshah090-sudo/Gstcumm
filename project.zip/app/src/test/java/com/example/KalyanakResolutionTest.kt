package com.example

import com.example.data.JainKalyanakRepository
import com.example.data.PanchangEventEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class KalyanakResolutionTest {

    @Test
    fun testOnlyPresentCalendarKalyanaksAreShown() {
        val sampleEvents = listOf(
            PanchangEventEntity(
                dateString = "2026-11-06",
                dayOfWeek = "Friday",
                tithi = "कार्तिक वदि १२",
                kalyanaks = "श्री पद्मप्रभ स्वामी जन्म कल्याणक",
                parvasAndEvents = ""
            ),
            PanchangEventEntity(
                dateString = "2026-11-08",
                dayOfWeek = "Sunday",
                tithi = "कार्तिक वदि १४",
                kalyanaks = "श्री महावीर प्रभु निर्वाण कल्याणक",
                parvasAndEvents = "दीपावली महापर्व; श्री महुड़ी तीर्थ में अधिष्ठायक श्री घंटाकर्ण महावीर देव का हवन"
            ),
            PanchangEventEntity(
                dateString = "2026-11-09",
                dayOfWeek = "Monday",
                tithi = "कार्तिक वदि अमावस",
                kalyanaks = "",
                parvasAndEvents = "श्री गौतम स्वामी केवलज्ञान"
            ),
            PanchangEventEntity(
                dateString = "2026-11-10",
                dayOfWeek = "Tuesday",
                tithi = "कार्तिक सुदि १",
                kalyanaks = "श्री अनन्तनाथ स्वामी च्यवन कल्याणक",
                parvasAndEvents = "नूतन वर्षारंभ"
            )
        )

        val resolved = JainKalyanakRepository.resolvePresentInCalendarTirthankarKalyanaks(sampleEvents)

        // Only Padmaprabha (6), Anantnath (14), and Mahavir (24) should be resolved
        val tirthankarNumbers = resolved.map { it.first.number }
        assertEquals(listOf(6, 14, 24), tirthankarNumbers)

        // Padmaprabha should have exactly 1 kalyanak (Janma without tirthankar name prefix)
        val padmaprabhaKalyanaks = resolved.first { it.first.number == 6 }.second
        assertEquals(1, padmaprabhaKalyanaks.size)
        assertEquals("जन्म कल्याणक", padmaprabhaKalyanaks[0].customTitle)
        assertEquals("2026-11-06", padmaprabhaKalyanaks[0].eventDateString)

        // Mahavira should have exactly 1 kalyanak (Nirvana on 2026-11-08 without tirthankar name prefix)
        val mahaviraKalyanaks = resolved.first { it.first.number == 24 }.second
        assertEquals(1, mahaviraKalyanaks.size)
        assertEquals("निर्वाण कल्याणक", mahaviraKalyanaks[0].customTitle)
        assertEquals("2026-11-08", mahaviraKalyanaks[0].eventDateString)
        assertEquals("कार्तिक वदि चौदस", mahaviraKalyanaks[0].traditionalTithi)

        // 2026-11-09 with Gautam Swami in parvasAndEvents should NOT create any Tirthankara Kalyanak
        assertTrue(resolved.none { pair -> pair.second.any { it.eventDateString == "2026-11-09" } })
    }

    @Test
    fun testEveryCanonicalKalyanakTithiIsCompletelyInHindiWithoutNumbers() {
        val digitRegex = Regex("[0-9०-९]")
        for (tirthankarData in JainKalyanakRepository.CANONICAL_24_TIRTHANKARAS_KALYANAKS) {
            for (kalyanak in tirthankarData.kalyanaks) {
                val tithi = kalyanak.traditionalTithi
                assertTrue(
                    "Tirthankar ${tirthankarData.tirthankar.name} Kalyanak ${kalyanak.category} has number in tithi: '$tithi'",
                    !digitRegex.containsMatchIn(tithi)
                )
                assertTrue(
                    "Tithi '$tithi' should not be blank",
                    tithi.isNotBlank()
                )
            }
        }
    }

    @Test
    fun testConvertTithiToHindiWords() {
        assertEquals("कार्तिक वदि बारस", JainKalyanakRepository.convertTithiToHindiWords("कार्तिक वदि १२"))
        assertEquals("कार्तिक वदि चौदस", JainKalyanakRepository.convertTithiToHindiWords("कार्तिक वदि 14"))
        assertEquals("ज्येष्ठ सुदि पूर्णिमा", JainKalyanakRepository.convertTithiToHindiWords("ज्येष्ठ सुदि १५"))
        assertEquals("माघ वदि अमावस्या", JainKalyanakRepository.convertTithiToHindiWords("माघ वदि १५"))
        assertEquals("कार्तिक सुदि एकम", JainKalyanakRepository.convertTithiToHindiWords("कार्तिक सुदि १"))
        assertEquals("वैशाख सुदि आठम", JainKalyanakRepository.convertTithiToHindiWords("वैशाख सुदि ८"))
    }
}
