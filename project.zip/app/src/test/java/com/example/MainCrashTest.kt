package com.example

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.data.UserSessionManager
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.annotation.Config
import org.robolectric.shadows.ShadowLooper

@RunWith(AndroidJUnit4::class)
@Config(sdk = [34], application = MyApplication::class)
class MainCrashTest {

  @Test
  fun testLaunchMainActivityLoggedOut() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    UserSessionManager.init(context)
    UserSessionManager.logout()

    ActivityScenario.launch(MainActivity::class.java).use { scenario ->
      scenario.onActivity { activity ->
        // Pump main looper
        ShadowLooper.idleMainLooper()
      }
    }
  }

  @Test
  fun testLaunchMainActivityLoggedIn() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    UserSessionManager.init(context)
    UserSessionManager.login("9009253000", "Master Admin", null, true)

    ActivityScenario.launch(MainActivity::class.java).use { scenario ->
      scenario.onActivity { activity ->
        ShadowLooper.idleMainLooper()
      }
    }
  }
}
