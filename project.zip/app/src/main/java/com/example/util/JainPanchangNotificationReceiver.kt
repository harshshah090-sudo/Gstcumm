package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.JainPanchangRepository
import java.util.Calendar

class JainPanchangNotificationReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        if (action == Intent.ACTION_BOOT_COMPLETED || action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            JainPanchangNotificationManager.initNotifications(context)
            return
        }

        val isDailyTithi = intent.getBooleanExtra("is_daily_tithi", false)
        val title: String
        val message: String

        if (isDailyTithi) {
            val cal = Calendar.getInstance()
            val yr = cal.get(Calendar.YEAR)
            val mo = cal.get(Calendar.MONTH) + 1
            val dy = cal.get(Calendar.DAY_OF_MONTH)

            val selectedCity = com.example.data.JainCityManager.getSelectedCity(context)
            val dp = JainPanchangRepository.getDayPanchang(yr, mo, dy, selectedCity)

            title = "आज की जैन तिथि: ${dp.tithiName}"

            val eventStr = if (dp.events.isNotEmpty()) {
                "\nविशेष: " + dp.events.joinToString(" | ") { it.titleHindi }
            } else ""

            message = "जय जिनेन्द्र! आज नवकारसी: ${dp.navkarsiTime} | पौरुषी: 08:30 AM | चौविहार: ${dp.chauviharTime}$eventStr"
        } else {
            title = intent.getStringExtra("title") ?: "जैन पंचांग रिमाइंडर"
            message = intent.getStringExtra("message") ?: "आज विशेष जैन पर्व एवं तिथि है।"
        }

        showNotification(context, title, message)
    }

    fun showNotification(context: Context, title: String, message: String) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "jain_panchang_channel"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Jain Panchang Daily Tithi & Special Events",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily alerts for Jain Tithi, Navkarshi timings, Paryushan, and Kalyanaks"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            100,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_group_logo)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify((System.currentTimeMillis() % 100000).toInt(), notification)
    }
}

