package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.widget.Toast
import com.example.data.JainPanchangRepository
import java.util.Calendar
import java.util.TimeZone

object JainPanchangNotificationManager {

    private const val PREFS_NAME = "jain_panchang_prefs"
    private const val KEY_DAILY_TITHI = "pref_daily_tithi"
    private const val KEY_PARYUSHAN_ALERTS = "pref_paryushan_alerts"
    private const val KEY_KALYANAK_ALERTS = "pref_kalyanak_alerts"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isDailyTithiEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_DAILY_TITHI, true)
    fun isParyushanAlertsEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_PARYUSHAN_ALERTS, true)
    fun isKalyanakAlertsEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_KALYANAK_ALERTS, true)

    fun setDailyTithiEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_DAILY_TITHI, enabled).apply()
        if (enabled) scheduleDailyMorningAlarm(context)
        else cancelAlarm(context, 1001)
    }

    fun setParyushanAlertsEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_PARYUSHAN_ALERTS, enabled).apply()
        if (enabled) scheduleUpcomingEventReminders(context)
    }

    fun setKalyanakAlertsEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_KALYANAK_ALERTS, enabled).apply()
        if (enabled) scheduleUpcomingEventReminders(context)
    }

    fun initNotifications(context: Context) {
        if (isDailyTithiEnabled(context)) {
            scheduleDailyMorningAlarm(context)
        }
        if (isParyushanAlertsEnabled(context) || isKalyanakAlertsEnabled(context)) {
            scheduleUpcomingEventReminders(context)
        }
    }

    fun triggerInstantTestNotification(context: Context) {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        val yr = cal.get(Calendar.YEAR)
        val mo = cal.get(Calendar.MONTH) + 1
        val dy = cal.get(Calendar.DAY_OF_MONTH)

        val selectedCity = com.example.data.JainCityManager.getSelectedCity(context)
        val dp = JainPanchangRepository.getDayPanchang(yr, mo, dy, selectedCity)

        val title = "आज की जैन तिथि: ${dp.tithiName}"
        val eventStr = if (dp.events.isNotEmpty()) {
            "\nविशेष: " + dp.events.joinToString(" | ") { it.titleHindi }
        } else ""
        val message = "जय जिनेन्द्र! आज नवकारसी: ${dp.navkarsiTime} | पौरुषी: 08:30 AM | चौविहार: ${dp.chauviharTime}$eventStr"

        JainPanchangNotificationReceiver().showNotification(context, title, message)
        Toast.makeText(context, "परीक्षण नोटिफिकेशन भेजा गया!", Toast.LENGTH_SHORT).show()
    }

    fun scheduleDailyMorningAlarm(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, JainPanchangNotificationReceiver::class.java).apply {
            putExtra("is_daily_tithi", true)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val calendar = Calendar.getInstance().apply {
            timeInMillis = System.currentTimeMillis()
            set(Calendar.HOUR_OF_DAY, 6)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }

        try {
            alarmManager.setInexactRepeating(
                AlarmManager.RTC_WAKEUP,
                calendar.timeInMillis,
                AlarmManager.INTERVAL_DAY,
                pendingIntent
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun scheduleEventReminder(
        context: Context,
        eventTitle: String,
        eventDateStr: String,
        eventDesc: String,
        showToast: Boolean = true
    ) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, JainPanchangNotificationReceiver::class.java).apply {
            putExtra("title", "विशेष पर्व रिमाइंडर: $eventTitle")
            putExtra("message", "$eventTitle ($eventDateStr) - $eventDesc")
        }

        val requestCode = eventTitle.hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Schedule notification at 7:00 AM on event day
        val dateParts = eventDateStr.split("-")
        if (dateParts.size == 3) {
            val yr = dateParts[0].toIntOrNull() ?: return
            val mo = dateParts[1].toIntOrNull() ?: return
            val dy = dateParts[2].toIntOrNull() ?: return

            val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).apply {
                set(yr, mo - 1, dy, 7, 0, 0)
            }

            if (cal.timeInMillis > System.currentTimeMillis()) {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)
                    } else {
                        alarmManager.set(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)
                    }
                    if (showToast) {
                        Toast.makeText(context, "$eventTitle हेतु नोटिफिकेशन सेट किया गया", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    if (showToast) {
                        Toast.makeText(context, "नोटिफिकेशन सेट हुआ", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                if (showToast) {
                    Toast.makeText(context, "यह पर्व दिनांक बीत चुकी है", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun scheduleUpcomingEventReminders(context: Context) {
        val now = System.currentTimeMillis()
        val currentYear = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).get(Calendar.YEAR)
        val events = JainPanchangRepository.getAllEventsForYear(currentYear)
            .filter { ev ->
                val dateParts = ev.dateString.split("-")
                if (dateParts.size == 3) {
                    val yr = dateParts[0].toIntOrNull() ?: return@filter false
                    val mo = dateParts[1].toIntOrNull() ?: return@filter false
                    val dy = dateParts[2].toIntOrNull() ?: return@filter false
                    val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).apply {
                        set(yr, mo - 1, dy, 23, 59, 59)
                    }
                    cal.timeInMillis >= now
                } else false
            }

        events.take(5).forEach { ev ->
            scheduleEventReminder(context, ev.titleHindi, ev.dateString, ev.description, showToast = false)
        }
    }

    private fun cancelAlarm(context: Context, requestCode: Int) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, JainPanchangNotificationReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }
}
