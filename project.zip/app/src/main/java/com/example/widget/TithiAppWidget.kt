package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.util.TypedValue
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.DefaultPanchangSeed
import com.example.data.PanchangEventEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TithiAppWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Immediate baseline update so launcher receives valid RemoteViews right away
        for (appWidgetId in appWidgetIds) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_tithi)
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (t: Throwable) {
                t.printStackTrace()
            }
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (appWidgetId in appWidgetIds) {
                    updateAppWidget(context, appWidgetManager, appWidgetId)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            } finally {
                try {
                    pendingResult.finish()
                } catch (e: Throwable) {
                    e.printStackTrace()
                }
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE_WIDGET ||
            intent.action == Intent.ACTION_DATE_CHANGED ||
            intent.action == Intent.ACTION_TIME_CHANGED ||
            intent.action == Intent.ACTION_TIMEZONE_CHANGED
        ) {
            updateAllWidgets(context)
        }
    }

    companion object {
        const val ACTION_UPDATE_WIDGET = "com.example.widget.UPDATE_TITHI_WIDGET"

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context) ?: return
            val componentName = ComponentName(context, TithiAppWidget::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName) ?: return
            if (appWidgetIds.isEmpty()) return

            CoroutineScope(Dispatchers.IO).launch {
                for (appWidgetId in appWidgetIds) {
                    updateAppWidget(context, appWidgetManager, appWidgetId)
                }
            }
        }

        suspend fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_tithi)

            // Load user-customized widget settings
            val widgetSettings = WidgetPreferences.getSettings(context)

            // 1. Dynamic Liquid Glass Background with Custom Opacity
            try {
                val glassBitmap = WidgetGlassBitmapHelper.createLiquidGlassBitmap(
                    width = 480,
                    height = 240,
                    opacityPercent = widgetSettings.widgetOpacity
                )
                views.setImageViewBitmap(R.id.widget_bg_image, glassBitmap)
            } catch (t: Throwable) {
                t.printStackTrace()
            }

            // 2. Custom Font Sizes for Tithi and Time Clock
            views.setTextViewTextSize(
                R.id.widget_tithi_title,
                TypedValue.COMPLEX_UNIT_SP,
                widgetSettings.tithiFontSize
            )
            views.setTextViewTextSize(
                R.id.widget_clock,
                TypedValue.COMPLEX_UNIT_SP,
                widgetSettings.timeFontSize
            )

            // Current date and parts
            val now = Date()
            val todayDateString = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(now)
            val dayOfWeekStr = SimpleDateFormat("EEEE", Locale.ENGLISH).format(now)
            val dateMonthStr = SimpleDateFormat("d MMMM", Locale.ENGLISH).format(now)
            val yearStr = SimpleDateFormat("yyyy", Locale.ENGLISH).format(now)

            // Try fetching today's event from Room DB
            var todayEvent: PanchangEventEntity? = null
            try {
                val dao = AppDatabase.getDatabase(context).panchangDao()
                todayEvent = dao.getEventByDate(todayDateString)
            } catch (e: Throwable) {
                e.printStackTrace()
            }

            // Fallback to seed if not found
            if (todayEvent == null) {
                val seedList = DefaultPanchangSeed.getDefault2026Events()
                todayEvent = seedList.find { it.dateString == todayDateString }
            }

            val rawTithi = if (!todayEvent?.tithi.isNullOrBlank()) {
                todayEvent!!.tithi
            } else {
                "श्रावण सुदी बीज"
            }

            var cleanTithi = rawTithi
                .replace(Regex("\\s*\\([^)]*\\)"), "") // Remove bracketed numbers like (७), (२)
                .replace(Regex("[0-9०-९()]"), "")      // Remove numeric numbers
                .trim()

            val romanToHindi = listOf(
                "Ekam" to "एकम", "Bij" to "बीज", "Teej" to "तीज", "Choth" to "चौथ",
                "Pancham" to "पंचमी", "Chhath" to "छठ", "Satam" to "सातम", "Aatham" to "आठम",
                "Atham" to "आठम", "Nom" to "नोम", "Dasham" to "दशम", "Agiyaras" to "ग्यारस",
                "Gyaras" to "ग्यारस", "Baras" to "बारस", "Terash" to "तेरस", "Teras" to "तेरस",
                "Chaudas" to "चौदस", "Poonam" to "पूनम", "Purnima" to "पूर्णिमा",
                "Amavasya" to "अमावस्या", "Amavas" to "अमावस्या"
            )
            for ((roman, hindi) in romanToHindi) {
                cleanTithi = cleanTithi.replace(Regex("(?i)\\b$roman\\b"), hindi)
            }
            cleanTithi = cleanTithi
                .replace("सुदि", "सुदी")
                .replace("वदि", "वदी")
                .replace(Regex("\\s+"), " ")
                .trim()

            // Calculate Samvat info
            val parts = todayDateString.split("-")
            val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
            val month = parts.getOrNull(1)?.toIntOrNull() ?: 8
            val vs = if (month >= 11) year + 57 + 1 else year + 57
            val vns = if (month >= 11) year + 526 + 1 else year + 526

            fun toDevanagari(num: Int): String {
                val digits = charArrayOf('०', '१', '२', '३', '४', '५', '६', '७', '८', '९')
                return num.toString().map { digits[it - '0'] }.joinToString("")
            }

            val samvatString = "वि. सं. ${toDevanagari(vs)} • वीर सं. ${toDevanagari(vns)}"

            // Update Left Partition Views
            views.setTextViewText(R.id.widget_tithi_title, cleanTithi)
            views.setTextViewText(R.id.widget_samvat_text, samvatString)

            // Event or Kalyanak Text
            val kalyanak = todayEvent?.kalyanaks?.ifBlank { null }
            val parva = todayEvent?.parvasAndEvents?.ifBlank { null }
            val isImportant = todayEvent?.isImportantTithi == true

            val eventTagText = when {
                !kalyanak.isNullOrBlank() -> "★ $kalyanak"
                !parva.isNullOrBlank() -> "★ $parva"
                isImportant -> "★ विशेष तिथि"
                else -> "★ जैन पंचांग"
            }

            views.setTextViewText(R.id.widget_event_text, eventTagText)
            views.setViewVisibility(R.id.widget_event_text, View.VISIBLE)

            // Right Partition Date
            views.setTextViewText(R.id.widget_day_text, dayOfWeekStr)
            views.setTextViewText(R.id.widget_date_month_text, dateMonthStr)
            views.setTextViewText(R.id.widget_year_text, yearStr)

            // Bottom Bar Timings
            if (widgetSettings.showTimings) {
                views.setViewVisibility(R.id.widget_h_divider, View.VISIBLE)
                views.setViewVisibility(R.id.widget_bottom_bar, View.VISIBLE)
                val navkarsi = todayEvent?.navkarsiTime?.ifBlank { null } ?: "06:52 AM"
                val sunset = todayEvent?.sunsetTime?.ifBlank { null } ?: "06:58 PM"
                views.setTextViewText(R.id.widget_navkarsi_time, navkarsi)
                views.setTextViewText(R.id.widget_sunset_time, sunset)
            } else {
                views.setViewVisibility(R.id.widget_h_divider, View.GONE)
                views.setViewVisibility(R.id.widget_bottom_bar, View.GONE)
            }

            // Set PendingIntent to open app when tapping on the widget
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            withContext(Dispatchers.Main) {
                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        }
    }
}
