package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.CityPreferences
import com.example.data.DefaultPanchangSeed
import com.example.data.PanchangEventEntity
import com.example.utils.SolarTimingCalculator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class TithiAppWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        // Immediate baseline update so launcher receives valid RemoteViews right away
        for (appWidgetId in appWidgetIds) {
            try {
                val views = RemoteViews(context.packageName, R.layout.widget_tithi)
                val intent = Intent(context, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                }
                val pendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)
                appWidgetManager.updateAppWidget(appWidgetId, views)
            } catch (t: Throwable) {
                t.printStackTrace()
            }
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                for (appWidgetId in appWidgetIds) {
                    updateAppWidget(context, appWidgetManager, appWidgetId)
                }
            } catch (e: Throwable) {
                e.printStackTrace()
            } finally {
                pendingResult.finish()
            }
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return
        if (
            action == WidgetAlarmScheduler.ACTION_UPDATE_WIDGET ||
            action == Intent.ACTION_DATE_CHANGED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.MY_PACKAGE_REPLACED"
        ) {
            updateAllWidgets(context)
        }
    }

    companion object {

        fun updateAllWidgets(context: Context) {
            val appWidgetManager = AppWidgetManager.getInstance(context) ?: return
            val componentName = ComponentName(context, TithiAppWidget::class.java)
            val appWidgetIds = appWidgetManager.getAppWidgetIds(componentName)
            if (appWidgetIds.isEmpty()) return

            CoroutineScope(Dispatchers.IO).launch {
                for (appWidgetId in appWidgetIds) {
                    try {
                        updateAppWidget(context, appWidgetManager, appWidgetId)
                    } catch (e: Throwable) {
                        e.printStackTrace()
                    }
                }
            }
        }

        private suspend fun updateAppWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            appWidgetId: Int
        ) {
            val views = RemoteViews(context.packageName, R.layout.widget_tithi)
            val widgetSettings = WidgetPreferences.getSettings(context)

            val now = Calendar.getInstance()
            val nowMinutes = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
            val todayDate = now.time
            val todayDateString = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(todayDate)

            // 1. Calculate Solar Timings
            val selectedCity = CityPreferences.getSelectedCity(context)
            val solarTimings = SolarTimingCalculator.calculateLocalSolarTimings(now, selectedCity)

            fun parseTimeToMinutes(timeStr: String): Int {
                return try {
                    val clean = timeStr.trim().uppercase(Locale.US)
                    val isPm = clean.contains("PM")
                    val isAm = clean.contains("AM")
                    val timePart = clean.replace("AM", "").replace("PM", "").trim()
                    val parts = timePart.split(":")
                    var h = parts[0].trim().toInt()
                    val m = parts.getOrNull(1)?.trim()?.toInt() ?: 0
                    if (isPm && h < 12) h += 12
                    if (isAm && h == 12) h = 0
                    h * 60 + m
                } catch (e: Exception) {
                    if (timeStr.contains("06:")) 372 else 1108 // Safe fallbacks
                }
            }

            val sunriseMinutes = parseTimeToMinutes(solarTimings.sunrise)
            val sunsetMinutes = parseTimeToMinutes(solarTimings.sunset)

            // 2. Determine Day Mode vs Night Mode
            val isDayMode = nowMinutes in sunriseMinutes until sunsetMinutes

            // 3. Render Dynamic Liquid Glass Background
            val glassBitmap = WidgetGlassBitmapHelper.createLiquidGlassBitmap(
                width = 540,
                height = 260,
                opacityPercent = widgetSettings.widgetOpacity,
                cornerRadiusPx = 36f,
                isDayMode = isDayMode
            )
            views.setImageViewBitmap(R.id.widget_bg_image, glassBitmap)

            // 4. Hindi Day and Date
            val hindiWeekdays = mapOf(
                Calendar.SUNDAY to "रविवार",
                Calendar.MONDAY to "सोमवार",
                Calendar.TUESDAY to "मंगलवार",
                Calendar.WEDNESDAY to "बुधवार",
                Calendar.THURSDAY to "गुरुवार",
                Calendar.FRIDAY to "शुक्रवार",
                Calendar.SATURDAY to "शनिवार"
            )
            val hindiMonths = mapOf(
                0 to "जनवरी", 1 to "फरवरी", 2 to "मार्च", 3 to "अप्रैल",
                4 to "मई", 5 to "जून", 6 to "जुलाई", 7 to "अगस्त",
                8 to "सितम्बर", 9 to "अक्टूबर", 10 to "नवम्बर", 11 to "दिसम्बर"
            )
            val weekdayHindi = hindiWeekdays[now.get(Calendar.DAY_OF_WEEK)] ?: "शुक्रवार"
            val dayOfMonth = now.get(Calendar.DAY_OF_MONTH)
            val monthHindi = hindiMonths[now.get(Calendar.MONTH)] ?: "सितम्बर"
            val yearVal = now.get(Calendar.YEAR)
            val dateHindi = "$dayOfMonth $monthHindi $yearVal"

            views.setTextViewText(R.id.widget_weekday_text, weekdayHindi)
            views.setTextViewText(R.id.widget_date_text, dateHindi)

            // 5. Panchang: Paksha and Tithi from Room DB with Default Seed Fallback
            var todayEvent: PanchangEventEntity? = null
            try {
                val dao = AppDatabase.getDatabase(context).panchangDao()
                todayEvent = dao.getEventByDate(todayDateString)
            } catch (e: Throwable) {
                e.printStackTrace()
            }
            if (todayEvent == null) {
                val seedList = DefaultPanchangSeed.getDefault2026Events()
                todayEvent = seedList.find { it.dateString == todayDateString }
            }

            val rawTithi = if (!todayEvent?.tithi.isNullOrBlank()) {
                todayEvent!!.tithi
            } else {
                "भाद्रपद शुक्ल तृतीया"
            }

            // Extract Paksha and Tithi parts
            val cleanTithi = rawTithi
                .replace(Regex("\\s*\\([^)]*\\)"), "")
                .replace(Regex("[0-9०-९()]"), "")
                .replace("सुदि", "शुक्ल")
                .replace("सुदी", "शुक्ल")
                .replace("वदि", "कृष्ण")
                .replace("वदी", "कृष्ण")
                .trim()

            val parts = cleanTithi.split(" ")
            val pakshaString: String
            val tithiString: String

            if (parts.size >= 3) {
                pakshaString = "${parts[0]} ${parts[1]}"
                tithiString = parts.subList(2, parts.size).joinToString(" ")
            } else if (parts.size == 2) {
                pakshaString = parts[0]
                tithiString = parts[1]
            } else {
                pakshaString = "जैन पंचांग"
                tithiString = cleanTithi
            }

            views.setTextViewText(R.id.widget_paksha_text, pakshaString)
            views.setTextViewText(R.id.widget_tithi_text, tithiString)

            // 6. Calculate Celestial Arc & Progress
            val dayLength = (sunsetMinutes - sunriseMinutes).coerceAtLeast(1)
            val nightLength = (1440 - sunsetMinutes + sunriseMinutes).coerceAtLeast(1)

            val dayProgress = if (isDayMode) {
                ((nowMinutes - sunriseMinutes).toFloat() / dayLength.toFloat()).coerceIn(0f, 1f)
            } else {
                0f
            }

            val nightMinutesElapsed = if (nowMinutes >= sunsetMinutes) {
                nowMinutes - sunsetMinutes
            } else {
                (1440 - sunsetMinutes) + nowMinutes
            }
            val nightProgress = (nightMinutesElapsed.toFloat() / nightLength.toFloat()).coerceIn(0f, 1f)

            val activeProgress = if (isDayMode) dayProgress else nightProgress

            // 7. Render Celestial Sun / Moon Arc Bitmap
            val arcBitmap = WidgetSunArcHelper.createSunArcBitmap(
                width = 520,
                height = 140,
                progress = activeProgress,
                isDayMode = isDayMode
            )
            views.setImageViewBitmap(R.id.widget_sun_arc_image, arcBitmap)

            // 8. Format Sunrise & Sunset (e.g. 06:12, 18:28 in 24h or clean 12h)
            fun formatCleanTime(minutes: Int): String {
                val h = minutes / 60
                val m = minutes % 60
                return String.format(Locale.US, "%02d:%02d", h, m)
            }
            val sunriseFormatted = formatCleanTime(sunriseMinutes)
            val sunsetFormatted = formatCleanTime(sunsetMinutes)

            views.setTextViewText(R.id.widget_sunrise_time, sunriseFormatted)
            views.setTextViewText(R.id.widget_sunset_time, sunsetFormatted)

            // 9. Day Mode vs Night Mode UI Styling
            if (isDayMode) {
                views.setViewVisibility(R.id.widget_moon_icon, View.GONE)
                views.setTextViewText(R.id.widget_progress_title, "दिन का प्रगति")
                val percentInt = (dayProgress * 100).toInt()
                views.setTextViewText(R.id.widget_progress_value, "$percentInt%")

                views.setTextColor(R.id.widget_weekday_text, Color.parseColor("#F5CA65"))
                views.setTextColor(R.id.widget_paksha_text, Color.parseColor("#F5CA65"))
                views.setTextColor(R.id.widget_progress_value, Color.parseColor("#F5CA65"))
                views.setTextColor(R.id.widget_clock_ampm, Color.parseColor("#DFB25E"))
                views.setTextColor(R.id.widget_ratnatraya_text, Color.parseColor("#A0E0C0"))
            } else {
                views.setViewVisibility(R.id.widget_moon_icon, View.VISIBLE)
                views.setTextViewText(R.id.widget_progress_title, "अगली सूर्योदय तक")

                val remainingMinutes = (nightLength - nightMinutesElapsed).coerceAtLeast(0)
                val remHours = remainingMinutes / 60
                val remMins = remainingMinutes % 60
                val remainingStr = "${remHours}h ${remMins}m शेष"
                views.setTextViewText(R.id.widget_progress_value, remainingStr)

                // Night Palette: Starlight cyan & cool white
                views.setTextColor(R.id.widget_weekday_text, Color.parseColor("#94C6FF"))
                views.setTextColor(R.id.widget_paksha_text, Color.parseColor("#94C6FF"))
                views.setTextColor(R.id.widget_progress_value, Color.parseColor("#94C6FF"))
                views.setTextColor(R.id.widget_clock_ampm, Color.parseColor("#80BFFF"))
                views.setTextColor(R.id.widget_ratnatraya_text, Color.parseColor("#80BFFF"))
            }

            // 10. Schedule exact wakeup alarms for next sunrise/sunset
            val calSunrise = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, sunriseMinutes / 60)
                set(Calendar.MINUTE, sunriseMinutes % 60)
                set(Calendar.SECOND, 0)
            }
            val calSunset = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, sunsetMinutes / 60)
                set(Calendar.MINUTE, sunsetMinutes % 60)
                set(Calendar.SECOND, 0)
            }
            WidgetAlarmScheduler.scheduleNextSolarUpdate(
                context,
                calSunrise.timeInMillis,
                calSunset.timeInMillis
            )

            // 11. Tapping widget opens main app
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

            withContext(Dispatchers.Main) {
                appWidgetManager.updateAppWidget(appWidgetId, views)
            }
        }
    }
}
