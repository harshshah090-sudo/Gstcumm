package com.example.widget

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object WidgetAlarmScheduler {

    const val ACTION_UPDATE_WIDGET = "com.example.widget.UPDATE_TITHI_WIDGET"

    /**
     * Schedules alarms for exact sunrise, sunset, midnight, and periodic 30-minute intervals
     * to keep Sun Arc and Day/Night states current without battery drain.
     */
    fun scheduleNextSolarUpdate(context: Context, nextSunriseMillis: Long, nextSunsetMillis: Long) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return

        val intent = Intent(context, TithiAppWidget::class.java).apply {
            action = ACTION_UPDATE_WIDGET
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            1001,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val now = System.currentTimeMillis()
        val triggerCandidates = mutableListOf<Long>()

        // 1. Next periodic check in 20 minutes
        triggerCandidates.add(now + 20 * 60 * 1000L)

        // 2. Next sunrise (if in future)
        if (nextSunriseMillis > now) {
            triggerCandidates.add(nextSunriseMillis)
            triggerCandidates.add(nextSunriseMillis + 60 * 1000L) // +1m buffer
        }

        // 3. Next sunset (if in future)
        if (nextSunsetMillis > now) {
            triggerCandidates.add(nextSunsetMillis)
            triggerCandidates.add(nextSunsetMillis + 60 * 1000L) // +1m buffer
        }

        // 4. Midnight (Date change)
        val midnightCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 24)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 5)
            set(Calendar.MILLISECOND, 0)
        }
        triggerCandidates.add(midnightCal.timeInMillis)

        val nextTrigger = triggerCandidates.filter { it > now }.minOrNull() ?: (now + 20 * 60 * 1000L)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC, nextTrigger, pendingIntent)
            } else {
                alarmManager.set(AlarmManager.RTC, nextTrigger, pendingIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
