package com.example.widget

import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.cos
import kotlin.math.sin

object WidgetSunArcHelper {

    /**
     * Renders a high-resolution celestial arc bitmap representing the path of the Sun or Moon.
     *
     * @param width Canvas width in pixels (e.g. 520)
     * @param height Canvas height in pixels (e.g. 140)
     * @param progress Position along the arc (0.0 = sunrise/sunset, 1.0 = sunset/next sunrise)
     * @param isDayMode true = Golden Sun Arc, false = Silver-Blue Moon Arc
     */
    fun createSunArcBitmap(
        width: Int = 520,
        height: Int = 140,
        progress: Float = 0.37f,
        isDayMode: Boolean = true
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val clampedProgress = progress.coerceIn(0f, 1f)

        // Arc geometry coordinates
        // Semicircular / gentle arch spanning across the width
        val paddingX = width * 0.12f
        val startX = paddingX
        val endX = width - paddingX
        val baselineY = height * 0.88f
        val peakY = height * 0.18f

        // Construct parabolic arch path from Left (Sunrise) to Right (Sunset)
        val arcPath = Path().apply {
            moveTo(startX, baselineY)
            // Cubic bezier for a natural, elegant celestial vault
            cubicTo(
                startX + (endX - startX) * 0.22f, peakY,
                startX + (endX - startX) * 0.78f, peakY,
                endX, baselineY
            )
        }

        // Measure path to extract positions for active track and orb
        val pathMeasure = PathMeasure(arcPath, false)
        val totalLength = pathMeasure.length

        // 1. Inactive Track: Translucent Track along full length
        val inactivePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3.2f
            strokeCap = Paint.Cap.ROUND
            color = if (isDayMode) {
                Color.argb(70, 0xFF, 0xFF, 0xFF) // Soft translucent white in Day
            } else {
                Color.argb(55, 0x8C, 0xC4, 0xFF) // Translucent ice-blue in Night
            }
        }
        canvas.drawPath(arcPath, inactivePaint)

        // 2. Active Track: Glowing Arc up to current progress
        if (clampedProgress > 0.005f) {
            val activePath = Path()
            pathMeasure.getSegment(0f, totalLength * clampedProgress, activePath, true)

            val activeStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = 4.2f
                strokeCap = Paint.Cap.ROUND
                shader = if (isDayMode) {
                    LinearGradient(
                        startX, baselineY, endX, peakY,
                        intArrayOf(
                            Color.argb(180, 0xDF, 0xB2, 0x5E), // Muted gold at horizon
                            Color.argb(255, 0xF5, 0xCA, 0x65), // Brilliant sun gold
                            Color.argb(255, 0xFF, 0xE2, 0x8A)  // Radiant warm amber
                        ),
                        floatArrayOf(0f, 0.6f, 1f),
                        Shader.TileMode.CLAMP
                    )
                } else {
                    LinearGradient(
                        startX, baselineY, endX, peakY,
                        intArrayOf(
                            Color.argb(160, 0x5C, 0x93, 0xD4), // Navy horizon
                            Color.argb(230, 0x94, 0xC6, 0xFF), // Luminous moon cyan
                            Color.argb(255, 0xD6, 0xE9, 0xFF)  // Starlight white
                        ),
                        floatArrayOf(0f, 0.6f, 1f),
                        Shader.TileMode.CLAMP
                    )
                }
            }
            canvas.drawPath(activePath, activeStrokePaint)
        }

        // 3. Current Position Orb & Radiant Glow
        val pos = FloatArray(2)
        val tan = FloatArray(2)
        pathMeasure.getPosTan(totalLength * clampedProgress, pos, tan)
        val orbX = pos[0]
        val orbY = pos[1]

        // Outer Glow Aura
        val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            val glowRadius = 24f
            shader = if (isDayMode) {
                RadialGradient(
                    orbX, orbY, glowRadius,
                    intArrayOf(
                        Color.argb(180, 0xFF, 0xD4, 0x4D),
                        Color.argb(70, 0xF5, 0xAA, 0x22),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
            } else {
                RadialGradient(
                    orbX, orbY, glowRadius,
                    intArrayOf(
                        Color.argb(180, 0xBF, 0xDD, 0xFF),
                        Color.argb(60, 0x4E, 0x8C, 0xDE),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.45f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }
        canvas.drawCircle(orbX, orbY, 24f, glowPaint)

        // Core Solid Orb with White Specular Center
        val orbCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = if (isDayMode) Color.parseColor("#FFA500") else Color.parseColor("#7AB7FF")
        }
        canvas.drawCircle(orbX, orbY, 8.5f, orbCorePaint)

        val orbInnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = if (isDayMode) Color.parseColor("#FFF4CC") else Color.parseColor("#F0F7FF")
        }
        canvas.drawCircle(orbX, orbY, 5.5f, orbInnerPaint)

        return bitmap
    }
}
