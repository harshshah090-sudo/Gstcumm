package com.example.widget

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class WidgetSettings(
    val tithiFontSize: Float = 30f,
    val timeFontSize: Float = 29f,
    val widgetOpacity: Int = 75, // 0 (transparent glass) to 100 (solid)
    val showTimings: Boolean = true
)

object WidgetPreferences {
    private const val PREFS_NAME = "tithi_widget_prefs"
    private const val KEY_TITHI_FONT_SIZE = "key_tithi_font_size"
    private const val KEY_TIME_FONT_SIZE = "key_time_font_size"
    private const val KEY_WIDGET_OPACITY = "key_widget_opacity"
    private const val KEY_SHOW_TIMINGS = "key_show_timings"

    const val DEFAULT_TITHI_FONT_SIZE = 30f
    const val DEFAULT_TIME_FONT_SIZE = 29f
    const val DEFAULT_OPACITY = 75
    const val MIN_TITHI_FONT_SIZE = 18f
    const val MAX_TITHI_FONT_SIZE = 44f
    const val MIN_TIME_FONT_SIZE = 18f
    const val MAX_TIME_FONT_SIZE = 45f

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getSettings(context: Context): WidgetSettings {
        val prefs = getPrefs(context)
        return WidgetSettings(
            tithiFontSize = prefs.getFloat(KEY_TITHI_FONT_SIZE, DEFAULT_TITHI_FONT_SIZE),
            timeFontSize = prefs.getFloat(KEY_TIME_FONT_SIZE, DEFAULT_TIME_FONT_SIZE),
            widgetOpacity = prefs.getInt(KEY_WIDGET_OPACITY, DEFAULT_OPACITY),
            showTimings = prefs.getBoolean(KEY_SHOW_TIMINGS, true)
        )
    }

    fun saveSettings(
        context: Context,
        tithiFontSize: Float,
        timeFontSize: Float,
        widgetOpacity: Int,
        showTimings: Boolean = true
    ) {
        val clampedTithi = tithiFontSize.coerceIn(MIN_TITHI_FONT_SIZE, MAX_TITHI_FONT_SIZE)
        val clampedTime = timeFontSize.coerceIn(MIN_TIME_FONT_SIZE, MAX_TIME_FONT_SIZE)
        val clampedOpacity = widgetOpacity.coerceIn(0, 100)

        getPrefs(context).edit().apply {
            putFloat(KEY_TITHI_FONT_SIZE, clampedTithi)
            putFloat(KEY_TIME_FONT_SIZE, clampedTime)
            putInt(KEY_WIDGET_OPACITY, clampedOpacity)
            putBoolean(KEY_SHOW_TIMINGS, showTimings)
            apply()
        }

        // Trigger instant broadcast update to all active widgets on home screen
        TithiAppWidget.updateAllWidgets(context)
    }

    fun resetToDefaults(context: Context) {
        saveSettings(
            context = context,
            tithiFontSize = DEFAULT_TITHI_FONT_SIZE,
            timeFontSize = DEFAULT_TIME_FONT_SIZE,
            widgetOpacity = DEFAULT_OPACITY,
            showTimings = true
        )
    }
}
