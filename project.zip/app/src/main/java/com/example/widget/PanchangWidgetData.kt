package com.example.widget

/**
 * Clean data model representing all parameters required to render
 * the Liquid Glass Jain Panchang Widget in Day or Night mode.
 */
data class PanchangWidgetData(
    val weekdayHindi: String,       // e.g. "शुक्रवार"
    val dateHindi: String,          // e.g. "19 सितम्बर 2026"
    val clockTime: String,          // e.g. "10:47"
    val amPm: String,               // e.g. "AM"
    val pakshaHindi: String,        // e.g. "भाद्रपद शुक्ल"
    val tithiHindi: String,         // e.g. "तृतीया"
    val sunriseTime: String,        // e.g. "06:12"
    val sunsetTime: String,         // e.g. "18:28"
    val dayProgress: Float,         // 0.0f..1.0f (Day mode: current progress)
    val nightProgress: Float,       // 0.0f..1.0f (Night mode: progress until next sunrise)
    val progressPercentStr: String, // e.g. "37%"
    val nightRemainingStr: String,  // e.g. "7h 25m शेष"
    val isDayMode: Boolean          // true = Day Mode (Sunrise -> Sunset), false = Night Mode
)
