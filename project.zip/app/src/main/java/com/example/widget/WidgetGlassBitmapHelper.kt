package com.example.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader

object WidgetGlassBitmapHelper {

    /**
     * Generates a realistic liquid glass background bitmap.
     *
     * @param width Canvas width in pixels
     * @param height Canvas height in pixels
     * @param opacityPercent Transparency/opacity parameter (0..100)
     * @param cornerRadiusPx Radius of rounded corners (24-30dp converted to px)
     * @param isDayMode true for warm amber-tinted frosted glass, false for midnight navy glass
     */
    fun createLiquidGlassBitmap(
        width: Int = 600,
        height: Int = 300,
        opacityPercent: Int = 75,
        cornerRadiusPx: Float = 38f,
        isDayMode: Boolean = true
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val alphaFactor = (opacityPercent.coerceIn(20, 100) / 100f)

        // 1. Base Liquid Glass Tint Gradient
        // Semi-transparent frosted glass body allowing underlying wallpaper to show through
        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = if (isDayMode) {
                // Day: Translucent warm smoky amber glass tint
                val a1 = ((0.52f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                val a2 = ((0.62f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                val a3 = ((0.58f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(
                        Color.argb(a1, 0x1E, 0x1A, 0x14), // Warm dark golden charcoal
                        Color.argb(a2, 0x16, 0x13, 0x0E), // Deep muted amber shadow
                        Color.argb(a3, 0x22, 0x1D, 0x17)  // Soft warm umber
                    ),
                    floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.CLAMP
                )
            } else {
                // Night: Deep midnight indigo-blue translucent glass
                val a1 = ((0.60f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                val a2 = ((0.70f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                val a3 = ((0.65f * alphaFactor) * 255).toInt().coerceIn(0, 255)
                LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(
                        Color.argb(a1, 0x0B, 0x12, 0x20), // Deep translucent midnight blue
                        Color.argb(a2, 0x07, 0x0C, 0x16), // Dark abyssal navy
                        Color.argb(a3, 0x0E, 0x16, 0x26)  // Slate starlight shadow
                    ),
                    floatArrayOf(0f, 0.5f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        val strokeWidth = 2.4f
        val rect = RectF(
            strokeWidth / 2f,
            strokeWidth / 2f,
            width.toFloat() - (strokeWidth / 2f),
            height.toFloat() - (strokeWidth / 2f)
        )
        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, bgPaint)

        // 2. Liquid Specular Light Sheen & Curved Surface Refraction (Top Edge Reflection)
        val sheenAlphaTop = ((0.28f + 0.14f * (1f - alphaFactor)) * 255).toInt().coerceIn(0, 255)
        val sheenAlphaMid = ((0.08f + 0.05f * (1f - alphaFactor)) * 255).toInt().coerceIn(0, 255)
        val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = if (isDayMode) {
                LinearGradient(
                    0f, 0f, 0f, height * 0.52f,
                    intArrayOf(
                        Color.argb(sheenAlphaTop, 0xFF, 0xF8, 0xEA), // Soft warm champagne sheen
                        Color.argb(sheenAlphaMid, 0xDF, 0xB2, 0x5E), // Muted golden refraction
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.40f, 1f),
                    Shader.TileMode.CLAMP
                )
            } else {
                LinearGradient(
                    0f, 0f, 0f, height * 0.52f,
                    intArrayOf(
                        Color.argb(sheenAlphaTop, 0xEE, 0xF5, 0xFF), // Crisp starlight ice sheen
                        Color.argb(sheenAlphaMid, 0x7E, 0xAC, 0xE6), // Soft indigo refraction
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.40f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        val sheenRect = RectF(
            rect.left + 1.5f,
            rect.top + 1.5f,
            rect.right - 1.5f,
            rect.bottom * 0.58f
        )
        canvas.drawRoundRect(sheenRect, cornerRadiusPx - 1f, cornerRadiusPx - 1f, sheenPaint)

        // 3. Subtle Bottom Reflection Sheen
        val bottomSheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = if (isDayMode) {
                LinearGradient(
                    0f, height.toFloat(), 0f, height * 0.85f,
                    intArrayOf(
                        Color.argb(35, 0xFF, 0xEA, 0xB5),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            } else {
                LinearGradient(
                    0f, height.toFloat(), 0f, height * 0.85f,
                    intArrayOf(
                        Color.argb(35, 0x94, 0xC6, 0xFF),
                        Color.TRANSPARENT
                    ),
                    null,
                    Shader.TileMode.CLAMP
                )
            }
        }
        val bottomSheenRect = RectF(
            rect.left + 1.5f,
            rect.bottom * 0.82f,
            rect.right - 1.5f,
            rect.bottom - 1.5f
        )
        canvas.drawRoundRect(bottomSheenRect, cornerRadiusPx - 1f, cornerRadiusPx - 1f, bottomSheenPaint)

        // 4. Glowing Precision Glass Bezel Rim Stroke
        val strokeAlpha = ((0.42f + 0.28f * alphaFactor) * 255).toInt().coerceIn(60, 240)
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            this.strokeWidth = strokeWidth
            shader = if (isDayMode) {
                LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(
                        Color.argb(strokeAlpha, 0xFF, 0xFA, 0xEE), // Top-left specular highlight
                        Color.argb((strokeAlpha * 0.8f).toInt(), 0xDF, 0xB2, 0x5E), // Body gold
                        Color.argb((strokeAlpha * 0.4f).toInt(), 0x90, 0x70, 0x30), // Shadow edge
                        Color.argb((strokeAlpha * 0.7f).toInt(), 0xF5, 0xCA, 0x65)  // Bottom-right rim
                    ),
                    floatArrayOf(0f, 0.35f, 0.75f, 1f),
                    Shader.TileMode.CLAMP
                )
            } else {
                LinearGradient(
                    0f, 0f, width.toFloat(), height.toFloat(),
                    intArrayOf(
                        Color.argb(strokeAlpha, 0xF0, 0xF7, 0xFF), // Top-left starlight highlight
                        Color.argb((strokeAlpha * 0.8f).toInt(), 0x7E, 0xAC, 0xE6), // Body ice blue
                        Color.argb((strokeAlpha * 0.4f).toInt(), 0x32, 0x48, 0x70), // Shadow edge
                        Color.argb((strokeAlpha * 0.7f).toInt(), 0x9C, 0xC4, 0xF5)  // Bottom-right rim
                    ),
                    floatArrayOf(0f, 0.35f, 0.75f, 1f),
                    Shader.TileMode.CLAMP
                )
            }
        }

        canvas.drawRoundRect(rect, cornerRadiusPx, cornerRadiusPx, strokePaint)

        return bitmap
    }
}
