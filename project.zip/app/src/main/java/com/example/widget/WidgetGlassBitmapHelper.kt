package com.example.widget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader

object WidgetGlassBitmapHelper {

    /**
     * Generates a liquid glass background bitmap with dynamic opacity (0..100)
     * and rounded corners.
     */
    fun createLiquidGlassBitmap(
        width: Int = 480,
        height: Int = 240,
        opacityPercent: Int = 75,
        cornerRadiusDp: Float = 28f
    ): Bitmap {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val alphaFactor = (opacityPercent.coerceIn(0, 100) / 100f)
        val baseAlpha = (alphaFactor * 255).toInt().coerceIn(0, 255)

        // 1. Draw Base Glass Background Gradient
        val startColor = Color.argb(baseAlpha, 0x11, 0x1A, 0x16)
        val midColor = Color.argb(baseAlpha, 0x0B, 0x13, 0x0F)
        val endColor = Color.argb(baseAlpha, 0x0E, 0x16, 0x12)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(startColor, midColor, endColor),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }

        val strokeWidth = 2.5f
        val rect = RectF(
            strokeWidth / 2f,
            strokeWidth / 2f,
            width.toFloat() - (strokeWidth / 2f),
            height.toFloat() - (strokeWidth / 2f)
        )

        canvas.drawRoundRect(rect, cornerRadiusDp, cornerRadiusDp, bgPaint)

        // 2. Liquid Specular Light Sheen (Top Half Reflection)
        val sheenAlphaTop = ((0.18f + 0.12f * (1f - alphaFactor)) * 255).toInt().coerceIn(0, 255)
        val sheenAlphaMid = ((0.06f + 0.04f * (1f - alphaFactor)) * 255).toInt().coerceIn(0, 255)
        val sheenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            shader = LinearGradient(
                0f, 0f, 0f, height * 0.55f,
                intArrayOf(
                    Color.argb(sheenAlphaTop, 0xEA, 0xFF, 0xF3),
                    Color.argb(sheenAlphaMid, 0x80, 0xDF, 0xB2),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.45f, 1f),
                Shader.TileMode.CLAMP
            )
        }

        val sheenRect = RectF(
            rect.left + 1.5f,
            rect.top + 1.5f,
            rect.right - 1.5f,
            rect.bottom * 0.65f
        )
        canvas.drawRoundRect(sheenRect, cornerRadiusDp - 1f, cornerRadiusDp - 1f, sheenPaint)

        // 3. Glowing Emerald-Gold Bezel Rim Stroke
        val strokeAlpha = ((0.35f + 0.35f * alphaFactor) * 255).toInt().coerceIn(40, 230)
        val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            this.strokeWidth = strokeWidth
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(
                    Color.argb(strokeAlpha, 0x80, 0xDF, 0xB2),
                    Color.argb((strokeAlpha * 0.7f).toInt(), 0xDF, 0xB2, 0x5E),
                    Color.argb(strokeAlpha, 0x80, 0xDF, 0xB2)
                ),
                null,
                Shader.TileMode.CLAMP
            )
        }

        canvas.drawRoundRect(rect, cornerRadiusDp, cornerRadiusDp, strokePaint)

        return bitmap
    }
}
