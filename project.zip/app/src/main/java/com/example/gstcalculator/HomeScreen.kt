package com.example.gstcalculator

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.PlatformTextStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil.compose.AsyncImage
import com.example.gstcalculator.ui.theme.GSTCalculatorTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

fun formatTimestamp(timestamp: Long): String {
    val now = System.currentTimeMillis()
    val diff = now - timestamp
    val minutes = (diff / (1000 * 60)).toInt()
    val hours = (diff / (1000 * 60 * 60)).toInt()

    return when {
        minutes < 1 -> "just now"
        minutes < 60 -> "$minutes min ago"
        hours < 24 -> "$hours hr ago"
        else -> SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
    }
}

fun formatDeletionDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

data class Contact(val name: String, val phoneNumber: String)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterialApi::class, ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel,
    isLocalsScreen: Boolean = false,
    customerType: String,
    currentScreenName: String,
    onScreenChange: (String) -> Unit
) {
    val customers by viewModel.filteredCustomers
    val searchQuery by viewModel.searchQuery
    val currentSortOption by viewModel.sortOption
    var showSortMenu by remember { mutableStateOf(false) }
    val isRefreshing by remember { mutableStateOf(false) }
    val pullRefreshState = rememberPullRefreshState(
        refreshing = isRefreshing,
        onRefresh = { viewModel.clearSearch() }
    )
    var showDraftsDialog by remember { mutableStateOf(false) }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var showBackupRestoreDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val backupManager = remember { AppDataBackupManager(context) }
    val hasNewReminders by viewModel.hasNewReminders
    val hasNewOrders by viewModel.hasNewOrders
    
    val userRole by viewModel.userRole
    val isAdmin = userRole == "admin"
    
    val customScreens by DataRepository.customScreens.collectAsState()
    var showScreenDropdown by remember { mutableStateOf(false) }
    var showAddScreenDialog by remember { mutableStateOf(false) }

    var showDateChangeDialog by remember { mutableStateOf(false) }
    var transactionToUpdate by remember { mutableStateOf<TransactionWithCustomer?>(null) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<androidx.compose.ui.unit.IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    BackHandler(enabled = currentSortOption == SortOption.Date) {
        viewModel.onSortOptionChange(SortOption.MostRecent)
    }

    if (showDateChangeDialog && transactionToUpdate != null) {
        WheelDateChangeDialog(
            initialDate = transactionToUpdate!!.transaction.date ?: System.currentTimeMillis(),
            onDismiss = { showDateChangeDialog = false },
            onConfirm = { newDate ->
                transactionToUpdate?.let {
                    viewModel.updateTransactionDate(it, newDate)
                }
                showDateChangeDialog = false
            }
        )
    }

    if (showAddScreenDialog) {
        var screenName by remember { mutableStateOf("") }
        BouncyDialog(onDismissRequest = { showAddScreenDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("New Screen", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF1976D2))
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = screenName,
                        onValueChange = { screenName = it },
                        label = { Text("Screen Name") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showAddScreenDialog = false }) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = {
                            if (screenName.isNotBlank()) {
                                DataRepository.addCustomScreen(screenName.trim())
                                onScreenChange(screenName.trim())
                                showAddScreenDialog = false
                            }
                        }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))) {
                            Text("Ok")
                        }
                    }
                }
            }
        }
    }

    if (showDraftsDialog) {
        selectedCustomer?.let { customer ->
            val transactionViewModel: TransactionViewModel = viewModel(factory = TransactionViewModelFactory(context, customer.id!!, customer.customerType), key = customer.id)
            DraftsDialog(
                viewModel = transactionViewModel,
                onDismiss = { showDraftsDialog = false },
                onDraftClick = { draftId ->
                    if (transactionViewModel.isConnected.value) {
                        showDraftsDialog = false
                        navController.navigate("createBill/${customer.id}/${customer.customerType}?draftId=$draftId")
                    } else {
                        Toast.makeText(context, "Cannot open draft while offline", Toast.LENGTH_SHORT).show()
                    }
                },
                onDeleteDraft = { draftId ->
                    if (transactionViewModel.isConnected.value) {
                        transactionViewModel.deleteDraft(draftId)
                    } else {
                        Toast.makeText(context, "Cannot delete draft while offline", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    if (showBackupRestoreDialog) {
        BackupRestoreDialog(
            onDismiss = { showBackupRestoreDialog = false },
            backupManager = backupManager,
            context = context
        )
    }

    Scaffold(
        containerColor = Color.Transparent,
        topBar = {
            TopAppBar(
                title = {
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.combinedClickable(
                                onClick = { if (isAdmin) showScreenDropdown = true },
                                onLongClick = { navController.navigate("salesAndCashReceived") }
                            )
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
                                Text(
                                    if (isLocalsScreen) "Locals" else currentScreenName,
                                    color = Color.White,
                                    fontSize = 18.sp,
                                    style = TextStyle(
                                        platformStyle = PlatformTextStyle(
                                            includeFontPadding = false
                                        ),
                                        lineHeight = 18.sp
                                    ),
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Total Customers: ${viewModel.totalCustomerCount.value}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    style = TextStyle(
                                        platformStyle = PlatformTextStyle(
                                            includeFontPadding = false
                                        ),
                                        lineHeight = 10.sp
                                    )
                                )
                                Text(
                                    "Settled Customers: ${viewModel.settledCustomerCount.value}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    style = TextStyle(
                                        platformStyle = PlatformTextStyle(
                                            includeFontPadding = false
                                        ),
                                        lineHeight = 10.sp
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            if (!viewModel.isConnected.value) {
                                Text(
                                    text = "Offline",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier
                                        .background(
                                            color = Color(0xFFD50000),
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (isAdmin) {
                            DropdownMenu(
                                expanded = showScreenDropdown,
                                onDismissRequest = { showScreenDropdown = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Shah Stores") },
                                    onClick = {
                                        onScreenChange("Shah Stores")
                                        showScreenDropdown = false
                                    }
                                )
                                customScreens.forEach { screen ->
                                    DropdownMenuItem(
                                        text = { Text(screen) },
                                        onClick = {
                                            onScreenChange(screen)
                                            showScreenDropdown = false
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { 
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Add Screen")
                                        }
                                    },
                                    onClick = {
                                        showAddScreenDialog = true
                                        showScreenDropdown = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2)),
                actions = {
                    if (!isLocalsScreen) {
                        IconButton(onClick = { navController.navigate("webOrders") }) {
                            BadgedBox(
                                badge = {
                                    if (hasNewOrders) {
                                        Badge(containerColor = Color(0xFFD50000))
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ShoppingCart,
                                    contentDescription = "Web Orders",
                                    tint = if (hasNewOrders) Color(0xFFFF9800) else Color.White
                                )
                            }
                        }
                        IconButton(onClick = {
                            navController.navigate("paymentReminders")
                            viewModel.remindersViewed()
                        }) {
                            BadgedBox(
                                badge = {
                                    if (hasNewReminders) {
                                        Badge(containerColor = Color(0xFFFF9800))
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Notifications,
                                    contentDescription = "Notifications",
                                    tint = if (hasNewReminders) Color(0xFFFF9800) else Color.White
                                )
                            }
                        }
                        IconButton(onClick = { navController.navigate("settings") }) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "Settings",
                                tint = Color.White
                            )
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .pullRefresh(pullRefreshState)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures { change, dragAmount ->
                            change.consume()
                            if (dragAmount > 0) {
                                viewModel.onSearchQueryChanged("")
                            }
                        }
                    },
                contentPadding = WindowInsets.navigationBars.asPaddingValues()
            ) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1976D2))
                            .padding(start = 16.dp, end = 16.dp, top = 8.dp)
                            .zIndex(1f) // Keep balance card on top
                    ) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp, horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("You will Give", color = Color.Black)
                                    RollingAmount(
                                        amount = viewModel.totalYouWillGet.value,
                                        color = Color(0xFF008800),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                VerticalDivider(modifier = Modifier.height(40.dp))
                                Column {
                                    Text("You will Get", color = Color.Black)
                                    RollingAmount(
                                        amount = viewModel.totalYouWillGive.value,
                                        color = Color(0xFFD50000),
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
                stickyHeader {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1976D2))
                            .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                            .zIndex(1f) // Ensure search bar stays on top during list bounce
                    ) {
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { viewModel.onSearchQueryChanged(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp),
                            textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            decorationBox = { innerTextField ->
                                Row(
                                    modifier = Modifier
                                        .background(
                                            color = Color(0xFFF5F5F5),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Icon",
                                        tint = Color.Gray
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        innerTextField()
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = "Search Customer",
                                                color = Color.Gray,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { viewModel.onSearchQueryChanged("") }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Clear Search",
                                                tint = Color.Gray
                                            )
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box {
                                        IconButton(onClick = { showSortMenu = true }) {
                                            Icon(
                                                imageVector = Icons.Default.FilterList,
                                                contentDescription = "Filter Icon",
                                                tint = Color.Gray
                                            )
                                        }
                                        DropdownMenu(
                                            expanded = showSortMenu,
                                            onDismissRequest = { showSortMenu = false }
                                        ) {
                                            SortOption.values().forEach { option ->
                                                DropdownMenuItem(
                                                    text = { Text(option.displayName) },
                                                    onClick = {
                                                        viewModel.onSortOptionChange(option)
                                                        showSortMenu = false
                                                    }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }
                
                if (currentSortOption == SortOption.Date) {
                    val transactions by viewModel.filteredTransactions
                    val groupedTransactions = transactions.groupBy {
                        SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it.transaction.date ?: 0))
                    }
                    
                    groupedTransactions.forEach { (date, dailyTransactions) ->
                        item(key = "date_$date") {
                            HomeDateSeparator(date = date)
                        }
                        items(dailyTransactions, key = { it.transaction.id ?: it.transaction.hashCode() }) { item ->
                            TransactionDateRow(
                                modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                                item = item,
                                onRowClick = {
                                    navController.navigate("transaction/${item.customerId}/${item.customerType}")
                                },
                                onLongClick = {
                                    if (item.transaction.paid) {
                                        Toast.makeText(context, "The transaction is Paid, UnPaid the transaction to change the date.", Toast.LENGTH_LONG).show()
                                    } else {
                                        transactionToUpdate = item
                                        showDateChangeDialog = true
                                    }
                                },
                                onPdfClick = {
                                    viewModel.generatePdfForTransaction(item, context) { path ->
                                        val encodedPath = URLEncoder.encode(path, StandardCharsets.UTF_8.name())
                                        val phone = item.phoneNumber
                                        val name = item.customerName
                                        navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
                                    }
                                }
                            )
                            HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color.Black.copy(alpha = 0.12f))
                        }
                    }
                } else {
                    items(customers, key = { it.id ?: it.hashCode() }) { customer ->
                        Box(modifier = Modifier
                            .animateItemPlacement(animationSpec = springSpec)
                            .combinedClickable(
                                onClick = { navController.navigate("transaction/${customer.id}/${customer.customerType}") },
                                onLongClick = { 
                                    // Long press on home screen can have a different function in future
                                }
                            )
                        ) {
                            CustomerItem(
                                customer = customer,
                                onAvatarClick = {
                                    if (customer.hasDraft) {
                                        if (viewModel.isConnected.value) {
                                            selectedCustomer = customer
                                            showDraftsDialog = true
                                        } else {
                                            Toast.makeText(context, "Please connect to the internet to open drafts", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                currentCustomerType = customerType
                            )
                        }
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color.Black.copy(alpha = 0.12f))
                    }
                }
            }
            PullRefreshIndicator(
                refreshing = isRefreshing,
                state = pullRefreshState,
                modifier = Modifier.align(Alignment.TopCenter)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TransactionDateRow(
    modifier: Modifier = Modifier,
    item: TransactionWithCustomer,
    onRowClick: () -> Unit,
    onLongClick: () -> Unit,
    onPdfClick: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onRowClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        // Column 1: Customer Name - Takes up remaining space and wraps
        Text(
            text = item.customerName,
            fontWeight = FontWeight.Medium,
            fontSize = 16.sp,
            color = Color.Black,
            modifier = Modifier.weight(1f)
        )

        // Column 2: PDF Icon - Fixed width to ensure alignment
        Box(
            modifier = Modifier.width(48.dp),
            contentAlignment = Alignment.Center
        ) {
            if (item.transaction.items.isNotEmpty() || item.transaction.billImageUrl != null) {
                IconButton(
                    onClick = onPdfClick,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.PictureAsPdf,
                        contentDescription = "PDF",
                        tint = Color(0xFFD50000),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Column 3: Amount - Fixed width to ensure alignment
        Text(
            text = formatAmount(item.transaction.amount),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = Color(0xFFD50000),
            modifier = Modifier.width(90.dp),
            textAlign = TextAlign.End
        )
    }
}

@Composable
fun HomeDateSeparator(date: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFE0E0E0)) // Light Gray
        ) {
            Text(
                text = date,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.DarkGray
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WheelDateChangeDialog(
    initialDate: Long,
    onDismiss: () -> Unit,
    onConfirm: (Long) -> Unit
) {
    // Key state on initialDate to ensure it resets when different transactions are clicked
    val initialCalendar = remember(initialDate) { Calendar.getInstance().apply { timeInMillis = initialDate } }
    var currentCalendar by remember(initialDate) { mutableStateOf(Calendar.getInstance().apply { timeInMillis = initialDate }) }
    
    val itemHeight = 40.dp
    val visibleItemsCount = 3
    
    val daysCount = 31
    val totalItems = 10000 * daysCount
    val initialDay = initialCalendar.get(Calendar.DAY_OF_MONTH)
    
    // Ensure we start in the middle of a very long list for smooth infinite scrolling
    val midIndex = totalItems / 2
    val startIndex = midIndex - (midIndex % daysCount) + (initialDay - 1)
    
    // Key the scroll state on initialDate so it jumps to the correct day when reopened
    val scrollState = remember(initialDate) { 
        LazyListState(firstVisibleItemIndex = startIndex - 1)
    }

    val monthYearText by remember(currentCalendar) {
        derivedStateOf {
            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(currentCalendar.time)
        }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            @OptIn(ExperimentalMaterial3Api::class)
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Change Date",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1976D2)
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Text(
                    text = monthYearText,
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Medium
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Box(
                    modifier = Modifier
                        .height(itemHeight * visibleItemsCount)
                        .width(100.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(itemHeight),
                        color = Color.LightGray.copy(alpha = 0.3f),
                        shape = RoundedCornerShape(8.dp)
                    ) {}
                    
                    LazyColumn(
                        state = scrollState,
                        flingBehavior = rememberSnapFlingBehavior(lazyListState = scrollState),
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        items(totalItems) { index ->
                            val day = (index % daysCount) + 1
                            Box(
                                modifier = Modifier
                                    .height(itemHeight)
                                    .fillMaxWidth(),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = day.toString(),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Black
                                )
                            }
                        }
                    }
                    
                    var lastDay by remember(initialDate) { mutableStateOf(initialDay) }
                    LaunchedEffect(scrollState) {
                        snapshotFlow { scrollState.firstVisibleItemIndex }
                            .map { (it + 1) % daysCount + 1 }
                            .distinctUntilChanged()
                            .collect { currentDay ->
                                val newCal = (currentCalendar.clone() as Calendar)
                                
                                // Robust detection for month transitions when scrolling fast or wrapping
                                if (lastDay >= 25 && currentDay <= 7) {
                                    newCal.add(Calendar.MONTH, 1)
                                } else if (lastDay <= 7 && currentDay >= 25) {
                                    newCal.add(Calendar.MONTH, -1)
                                }
                                
                                // Coerce to max days in month to handle cases like Feb 31st
                                val maxDays = newCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                                val adjustedDay = currentDay.coerceAtMost(maxDays)
                                newCal.set(Calendar.DAY_OF_MONTH, adjustedDay)
                                
                                currentCalendar = newCal
                                lastDay = currentDay
                            }
                    }
                }
                
                Spacer(modifier = Modifier.height(24.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm(currentCalendar.timeInMillis) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        @OptIn(ExperimentalMaterial3Api::class)
                        Text("Ok")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerDialog(viewModel: HomeViewModel) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var initialBalance by remember { mutableStateOf("") }
    var nameError by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    var selectedDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val context = LocalContext.current
    var contacts by remember { mutableStateOf<List<Contact>>(emptyList()) }
    var showContactSuggestions by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { isGranted ->
            if (isGranted) {
                // Permission granted, do nothing
            } else {
                Toast.makeText(context, "Permission denied. Can't access contacts.", Toast.LENGTH_SHORT).show()
            }
        }
    )

    LaunchedEffect(name) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
            if (name.isNotEmpty()) {
                delay(300) // Debounce search
                withContext(Dispatchers.IO) {
                    val cursor = context.contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                        arrayOf("%$name%"),
                        null
                    )
                    cursor?.use {
                        val newContacts = mutableListOf<Contact>()
                        while (it.moveToNext()) {
                            val contactName = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME))
                            val phoneNumber = it.getString(it.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
                            newContacts.add(Contact(contactName, phoneNumber))
                        }
                        contacts = newContacts
                    }
                }
            } else {
                contacts = emptyList()
            }
        } else {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDate = it
                        }
                        showDatePicker = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDatePicker = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF1976D2),
                    headlineContentColor = Color(0xFF1976D2),
                    selectedDayContainerColor = Color(0xFF1976D2),
                    selectedDayContentColor = Color.White,
                    todayContentColor = Color(0xFF1976D2),
                    todayDateBorderColor = Color(0xFF1976D2)
                )
            )
        }
    }

    BouncyDialog(onDismissRequest = { viewModel.showAddCustomerDialog.value = false }) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    @OptIn(ExperimentalMaterial3Api::class)
                    Text(
                        text = "Add Customer",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    ExposedDropdownMenuBox(
                        expanded = showContactSuggestions && contacts.isNotEmpty(),
                        onExpandedChange = {
                            // We control this manually based on the text field focus
                        }
                    ) {
                        TextField(
                            modifier = Modifier.fillMaxWidth().menuAnchor(),
                            value = name,
                            onValueChange = {
                                name = it
                                nameError = false
                                showContactSuggestions = true
                            },
                            label = { Text("Name") },
                            isError = nameError,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            colors = ExposedDropdownMenuDefaults.textFieldColors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                disabledContainerColor = Color.White,
                                focusedLabelColor = Color(0xFF1976D2),
                                focusedIndicatorColor = Color(0xFF1976D2)
                            )
                        )

                        ExposedDropdownMenu(
                            expanded = showContactSuggestions && contacts.isNotEmpty(),
                            onDismissRequest = { showContactSuggestions = false },
                            modifier = Modifier.heightIn(max = 200.dp)
                        ) {
                            contacts.forEach { contact ->
                                DropdownMenuItem(
                                    text = { Text(contact.name) },
                                    onClick = {
                                        name = contact.name
                                        phone = cleanPhoneNumber(contact.phoneNumber)
                                        showContactSuggestions = false
                                    }
                                )
                            }
                        }
                    }

                    if (nameError) {
                        Text("Name cannot be empty", color = Color(0xFFD50000), style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = phone,
                        onValueChange = { input ->
                            val digitsOnly = input.filter { it.isDigit() }
                            if (digitsOnly.length <= 10) {
                                phone = digitsOnly
                            }
                        },
                        label = { Text("Phone Number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            disabledContainerColor = Color.White,
                            focusedLabelColor = Color(0xFF1976D2),
                            focusedIndicatorColor = Color(0xFF1976D2)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    TextField(
                        value = initialBalance,
                        onValueChange = { initialBalance = it },
                        label = { Text("Initial Balance") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        trailingIcon = {
                            IconButton(onClick = { showDatePicker = true }) {
                                Icon(Icons.Default.DateRange, contentDescription = "Select Date", tint = Color(0xFF1976D2))
                            }
                        },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            disabledContainerColor = Color.White,
                            focusedLabelColor = Color(0xFF1976D2),
                            focusedIndicatorColor = Color(0xFF1976D2)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = { viewModel.showAddCustomerDialog.value = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        @OptIn(ExperimentalMaterial3Api::class)
                        Button(
                            onClick = {
                                if (name.isBlank()) {
                                    nameError = true
                                } else {
                                    viewModel.addCustomer(name, phone, initialBalance.toDoubleOrNull() ?: 0.0, selectedDate)
                                    viewModel.showAddCustomerDialog.value = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                        ) {
                            Text("Add")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerItem(
    customer: Customer,
    onAvatarClick: () -> Unit,
    currentCustomerType: String,
    isRecycleBin: Boolean = false,
) {
    val isOtherCustomer = customer.customerType != currentCustomerType && !isRecycleBin && currentCustomerType.isNotEmpty()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(modifier = Modifier.clickable { onAvatarClick() }) {
            Avatar(name = customer.name, hasDraft = customer.hasDraft)
        }
        Spacer(modifier = Modifier.width(12.dp))

        // Name and Timestamp column, takes up available space
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = customer.name,
                    fontWeight = FontWeight.Normal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (customer.syncing) {
                    Spacer(modifier = Modifier.width(8.dp))
                    val infiniteTransition = rememberInfiniteTransition(label = "sync")
                    val rotate by infiniteTransition.animateFloat(
                        initialValue = 0f,
                        targetValue = -360f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1000, easing = LinearEasing),
                            repeatMode = RepeatMode.Restart
                        ),
                        label = "rotate"
                    )
                    Icon(
                        imageVector = Icons.Default.Sync,
                        contentDescription = "Syncing",
                        tint = Color(0xFFD50000),
                        modifier = Modifier
                            .size(16.dp)
                            .rotate(rotate)
                    )
                } else if (customer.hasSyncError) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.SyncProblem,
                        contentDescription = "Sync Error",
                        tint = Color(0xFFD50000),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            if (isRecycleBin) {
                customer.lastUpdated?.let {
                    Text("Deleted on: ${formatDeletionDate(it)}", color = Color(0xFFD50000), fontSize = 12.sp)
                }
            } else {
                val date = customer.lastUpdated?.let { formatTimestamp(it) } ?: ""
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(date, color = Color.Gray, fontSize = 12.sp)
                    if (isOtherCustomer) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = customer.customerType,
                            color = Color(0xFFD50000),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .background(Color.White, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.width(8.dp)) // space before amount

        // Amount column
        Column(horizontalAlignment = Alignment.End) {
            val balance = customer.initialBalance ?: 0.0
            val (amount, status, color) = when {
                balance > 0 -> Triple(formatAmount(balance), "Get", Color(0xFFD50000))
                balance < 0 -> Triple(formatAmount(-balance), "Give", Color(0xFF008800))
                else -> Triple("₹0", "Settled", Color.Gray)
            }

            Text(amount, fontWeight = FontWeight.Bold, color = color)
            Text(status, color = Color.Gray, fontSize = 12.sp)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    GSTCalculatorTheme {
        HomeScreen(
            navController = rememberNavController(), 
            viewModel = viewModel(factory = HomeViewModelFactory(LocalContext.current, "HOME")), 
            customerType = "HOME",
            currentScreenName = "Shah Stores",
            onScreenChange = {}
        )
    }
}
