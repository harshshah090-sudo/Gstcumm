package com.example.gstcalculator

import android.content.Context
import coil.imageLoader
import coil.request.CachePolicy
import coil.request.ImageRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

object ImageCacheManager {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val cachedUrls = mutableSetOf<String>()

    fun cacheImage(context: Context, url: String?) {
        if (url.isNullOrBlank() || cachedUrls.contains(url)) return
        
        cachedUrls.add(url)
        scope.launch {
            val request = ImageRequest.Builder(context)
                .data(url)
                .diskCachePolicy(CachePolicy.ENABLED)
                .memoryCachePolicy(CachePolicy.ENABLED)
                .build()
            context.imageLoader.enqueue(request)
        }
    }

    fun clearCacheInfo() {
        cachedUrls.clear()
    }
}
