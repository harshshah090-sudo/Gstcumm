package com.example.gstcalculator

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class HistoryItem(val expression: String, val timestamp: Long)

class CalculatorViewModel : ViewModel() {
    val displayText = mutableStateOf("0")
    val liveResultText = mutableStateOf("")
    val historyList = mutableStateOf<List<HistoryItem>>(emptyList())
    private var isResultDisplayed = false
    private var historyClearJob: Job? = null

    init {
        startHistoryCleanup() // Automatically clean up history
    }

    fun onButtonClick(label: String) {
        when (label) {
            in "0".."9", "00", "." -> handleDigit(label)
            in arrayOf("+", "-", "×", "÷") -> handleOperator(label)
            "AC" -> handleClear()
            "←" -> handleBackspace()
            "%" -> handlePercent()
            "=" -> handleEquals()
            else -> handleGst(label)
        }
        if (label != "AC" && label != "=") {
            updateLiveResult()
        }
    }

    private fun startHistoryCleanup() {
        historyClearJob?.cancel()
        historyClearJob = viewModelScope.launch {
            while (true) {
                delay(60 * 60 * 1000) // Check every hour
                val oneHourAgo = System.currentTimeMillis() - 60 * 60 * 1000
                historyList.value = historyList.value.filter { it.timestamp >= oneHourAgo }
            }
        }
    }


    private fun updateLiveResult() {
        var expression = displayText.value
        if (isResultDisplayed) {
            liveResultText.value = ""
            return
        }

        if (expression.lastOrNull()?.let { it in "+-×÷" } == true) {
            expression = expression.dropLast(1)
        }

        if (!expression.contains('+') && !expression.contains('-') && !expression.contains('×') && !expression.contains('÷')) {
            liveResultText.value = ""
            return
        }

        val numbers = expression.split('+', '-', '×', '÷').mapNotNull { it.toDoubleOrNull() }.toMutableList()
        val operators = expression.filter { it == '+' || it == '-' || it == '×' || it == '÷' }.toMutableList()

        if (expression.startsWith('-') && numbers.isNotEmpty()) {
            numbers[0] = -numbers[0]
            operators.removeFirstOrNull()
        }

        if (numbers.size <= 1 || numbers.size - 1 != operators.size) {
            liveResultText.value = ""
            return
        }

        var result = numbers.first()
        for (i in 0 until operators.size) {
            val op = operators[i]
            val nextNum = numbers[i + 1]
            result = when (op) {
                '+' -> result + nextNum
                '-' -> result - nextNum
                '×' -> result * nextNum
                '÷' -> if (nextNum != 0.0) result / nextNum else Double.NaN
                else -> result
            }
            if (result.isNaN()) {
                liveResultText.value = "Error"
                return
            }
        }

        val resultStr = if (result % 1 == 0.0) {
            result.toLong().toString()
        } else {
            String.format("%.4f", result).trimEnd('0').trimEnd('.')
        }

        if (resultStr != displayText.value) {
            liveResultText.value = resultStr
        } else {
            liveResultText.value = ""
        }
    }

    private fun handleDigit(digit: String) {
        if (isResultDisplayed) {
            displayText.value = if (digit == ".") "0." else digit
            isResultDisplayed = false
        } else {
            val currentText = displayText.value
            if (currentText == "0" && digit != ".") {
                displayText.value = digit
            } else {
                val operatorIndex = currentText.indexOfLast { it == '+' || it == '-' || it == '×' || it == '÷' }
                val numberSegment = if (operatorIndex != -1) currentText.substring(operatorIndex + 1) else currentText
                if (digit == "." && numberSegment.contains(".")) {
                    return
                }
                displayText.value += digit
            }
        }
    }

    private fun handleOperator(op: String) {
        isResultDisplayed = false
        val currentText = displayText.value
        if (currentText.isNotEmpty() && (currentText.last().isDigit() || currentText.endsWith("."))) {
            displayText.value += op
        } else if (currentText.isNotEmpty()) {
            displayText.value = currentText.dropLast(1) + op
        }
    }

    private fun handleGst(gst: String) {
        isResultDisplayed = false
        val currentText = displayText.value
        if (currentText.lastOrNull()?.isDigit() == false && currentText.lastOrNull() != '.') return

        val operatorIndex = currentText.indexOfLast { it == '+' || it == '-' || it == '×' || it == '÷' }

        val numberString = if (operatorIndex != -1) {
            currentText.substring(operatorIndex + 1)
        } else {
            currentText
        }

        val amount = numberString.toDoubleOrNull() ?: return
        val percentage = gst.filter { it.isDigit() }.toDoubleOrNull() ?: return
        val isAdding = gst.contains("+")

        val finalAmount = if (isAdding) {
            amount * (1 + percentage / 100)
        } else {
            amount * 100 / (100 + percentage)
        }

        val finalAmountStr = if (finalAmount % 1 == 0.0) {
            finalAmount.toLong().toString()
        } else {
            String.format("%.4f", finalAmount).trimEnd('0').trimEnd('.')
        }

        if (operatorIndex != -1) {
            displayText.value = currentText.substring(0, operatorIndex + 1) + finalAmountStr
        } else {
            displayText.value = finalAmountStr
        }
    }

    private fun handleEquals() {
        if (liveResultText.value.isNotEmpty() && liveResultText.value != "Error") {
            val newHistory = historyList.value.toMutableList()
            newHistory.add(HistoryItem("${displayText.value}=${liveResultText.value}", System.currentTimeMillis()))
            historyList.value = newHistory
            displayText.value = liveResultText.value
            liveResultText.value = ""
            isResultDisplayed = true
        } else if (!isResultDisplayed) {
             var expression = displayText.value
            if (expression.lastOrNull()?.let { it in "+-×÷" } == true) {
                expression = expression.dropLast(1)
            }
            if (expression != displayText.value) {
                val newHistory = historyList.value.toMutableList()
                newHistory.add(HistoryItem("${displayText.value}=$expression", System.currentTimeMillis()))
                historyList.value = newHistory
                displayText.value = expression
                liveResultText.value = ""
                isResultDisplayed = true
            }
        }
    }

    private fun handlePercent() {
        isResultDisplayed = false
        val currentText = displayText.value
        if (currentText.lastOrNull()?.isDigit() == false && currentText.lastOrNull() != '.') return

        val operatorIndex = currentText.indexOfLast { it == '+' || it == '-' || it == '×' || it == '÷' }

        val numberString = if (operatorIndex != -1) {
            currentText.substring(operatorIndex + 1)
        } else {
            currentText
        }

        val value = numberString.toDoubleOrNull() ?: return
        val result = value / 100

        val resultStr = if (result % 1 == 0.0) result.toLong().toString() else {
            String.format("%.4f", result).trimEnd('0').trimEnd('.')
        }

        if (operatorIndex != -1) {
            displayText.value = currentText.substring(0, operatorIndex + 1) + resultStr
        } else {
            displayText.value = resultStr
        }
    }

    private fun handleClear() {
        displayText.value = "0"
        isResultDisplayed = false
        liveResultText.value = ""
    }

    private fun handleBackspace() {
        if (isResultDisplayed) {
            handleClear()
            return
        }

        if (displayText.value.length > 1) {
            displayText.value = displayText.value.dropLast(1)
        } else {
            displayText.value = "0"
        }
    }

    override fun onCleared() {
        super.onCleared()
        historyClearJob?.cancel()
    }
}
