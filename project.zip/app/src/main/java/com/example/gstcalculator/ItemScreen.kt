package com.example.gstcalculator

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.DecimalFormat

private fun unescapeCsv(field: String): String {
    var result = field.trim()
    while (result.startsWith("\"") && result.endsWith("\"")) {
        result = result.removeSurrounding("\"")
    }
    return result.replace("\"\"","\"")
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterialApi::class, ExperimentalFoundationApi::class)
@Composable
fun ItemScreen(
    showAddItemDialog: Boolean,
    onDismiss: () -> Unit,
    uomViewModel: UomViewModel = viewModel(),
    itemViewModel: ItemViewModel = viewModel()
) {
    val searchQuery by itemViewModel.searchQuery.collectAsState()
    val allItems by itemViewModel.allItems.collectAsState()
    val items by itemViewModel.filteredItems.collectAsState(emptyList())
    val selectedItemIds by itemViewModel.selectedItemIds.collectAsState()
    
    var showManageUomDialog by remember { mutableStateOf(false) }
    var editingItemId by remember { mutableStateOf<String?>(null) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var showSortMenu by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    var showSalesHistoryDialog by remember { mutableStateOf(false) }
    var salesHistory by remember { mutableStateOf<List<ItemSale>>(emptyList()) }
    var selectedItemForHistory by remember { mutableStateOf<String?>(null) }

    var isSelectionMode by remember { mutableStateOf(false) }

    val isRefreshing by remember { mutableStateOf(false) }
    val pullRefreshState = rememberPullRefreshState(
        refreshing = isRefreshing,
        onRefresh = { itemViewModel.onSearchQueryChanged("") }
    )

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    BackHandler(enabled = isSelectionMode) {
        isSelectionMode = false
        itemViewModel.clearSelection()
    }

    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { selectedUri: Uri? ->
        selectedUri?.let { uri ->
            try {
                context.contentResolver.openInputStream(uri)?.use { inputStream ->
                    BufferedReader(InputStreamReader(inputStream)).use { reader ->
                        reader.readLine() // Skip header
                        val itemsToImport = mutableListOf<Item>()
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            val parts = line!!.split(',')
                            if (parts.size == 3) {
                                val name = unescapeCsv(parts[0])
                                val basePrice = unescapeCsv(parts[1])
                                val uom = unescapeCsv(parts[2])
                                if (name.isNotBlank() && basePrice.isNotBlank() && uom.isNotBlank()) {
                                    itemsToImport.add(Item(name = name, basePrice = basePrice.toDouble(), uom = uom))
                                }
                            }
                        }
                        itemViewModel.addMultipleItems(itemsToImport)
                    }
                }
                Toast.makeText(context, "Items imported successfully", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to import items: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    if (showAddItemDialog) {
        AddItemDialog(
            onDismiss = onDismiss,
            onAddItem = { name, basePrice, uom, details ->
                itemViewModel.addItem(name, basePrice, uom, details)
                onDismiss()
            },
            uomViewModel = uomViewModel,
            onEditUomClicked = { showManageUomDialog = true }
        )
    }

    if (showManageUomDialog) {
        ManageUomDialog(onDismiss = { showManageUomDialog = false }, uomViewModel = uomViewModel)
    }

    if (showDeleteConfirmation) {
        BouncyDialog(onDismissRequest = { showDeleteConfirmation = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Delete Items", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Are you sure you want to delete ${selectedItemIds.size} items?")
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showDeleteConfirmation = false }) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { 
                                itemViewModel.deleteSelectedItems()
                                showDeleteConfirmation = false 
                                isSelectionMode = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
                        ) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }

    if (showSalesHistoryDialog) {
        selectedItemForHistory?.let {
            ItemSalesHistoryDialog(
                onDismiss = { showSalesHistoryDialog = false },
                itemName = it,
                salesHistory = salesHistory
            )
        }
    }

    editingItemId?.let { id ->
        val item = items.find { it.id == id }
        if (item != null) {
            EditItemDialog(
                item = item,
                onDismiss = { editingItemId = null },
                onSave = { updatedItem ->
                    itemViewModel.updateItem(updatedItem)
                    editingItemId = null
                },
                onDelete = {
                    itemViewModel.deleteItem(id)
                    editingItemId = null
                },
                uomViewModel = uomViewModel
            )
        } else {
            editingItemId = null
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (isSelectionMode) {
                        Text("${selectedItemIds.size} Selected", color = Color.White)
                    } else {
                        Column {
                            Text("Items", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            Text("Total Items: ${allItems.size}", color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2)),
                actions = {
                    if (isSelectionMode) {
                        IconButton(onClick = { if (selectedItemIds.isNotEmpty()) showDeleteConfirmation = true }) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White)
                        }
                        IconButton(onClick = { 
                            isSelectionMode = false
                            itemViewModel.clearSelection()
                        }) {
                            Icon(Icons.Default.Clear, contentDescription = null, tint = Color.White)
                        }
                    } else {
                        IconButton(onClick = { isSelectionMode = true }) {
                            Icon(Icons.Default.Delete, contentDescription = null, tint = Color.White)
                        }
                        IconButton(onClick = { launcher.launch(arrayOf("*/*")) }) {
                            Icon(Icons.Default.FileUpload, contentDescription = null, tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .pullRefresh(pullRefreshState)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White)
            ) {
                // Search Bar Area
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                        .zIndex(1f) // Ensure search bar stays on top during row bounce
                ) {
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { itemViewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        textStyle = TextStyle(fontSize = 16.sp, color = Color.Black),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        decorationBox = { innerTextField ->
                            Row(
                                modifier = Modifier
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(24.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.weight(1f)) {
                                    if (searchQuery.isEmpty()) Text("Search Item", color = Color.Gray, fontSize = 16.sp)
                                    innerTextField()
                                }
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { itemViewModel.onSearchQueryChanged("") }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Clear, contentDescription = null, tint = Color.Gray)
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(onClick = { showSortMenu = true }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.FilterList, contentDescription = "Sort", tint = Color(0xFF1976D2))
                                }
                                DropdownMenu(expanded = showSortMenu, onDismissRequest = { showSortMenu = false }) {
                                    DropdownMenuItem(text = { Text("Sort A-Z") }, onClick = { itemViewModel.sortItems("A-Z"); showSortMenu = false })
                                    DropdownMenuItem(text = { Text("Lowest Price") }, onClick = { itemViewModel.sortItems("Lowest"); showSortMenu = false })
                                    DropdownMenuItem(text = { Text("Recently Added") }, onClick = { itemViewModel.sortItems("Recent"); showSortMenu = false })
                                }
                            }
                        }
                    )
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .pointerInput(Unit) {
                            detectVerticalDragGestures { change, dragAmount ->
                                change.consume()
                                if (dragAmount > 0) {
                                    itemViewModel.onSearchQueryChanged("")
                                }
                            }
                        }
                ) {
                    itemsIndexed(items, key = { _, item -> item.id }) { index, item ->
                        ItemRow(
                            modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                            index = index,
                            item = item,
                            isSelected = selectedItemIds.contains(item.id),
                            isSelectionMode = isSelectionMode,
                            onToggleSelection = { itemViewModel.toggleItemSelection(item.id) },
                            onEdit = { editingItemId = item.id },
                            onHistory = {
                                selectedItemForHistory = item.name
                                coroutineScope.launch {
                                    salesHistory = itemViewModel.getSalesHistoryForItem(item.name, item.uom, item.id)
                                    showSalesHistoryDialog = true
                                }
                            }
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color.LightGray.copy(alpha = 0.5f))
                    }
                }
            }
            PullRefreshIndicator(
                refreshing = isRefreshing,
                state = pullRefreshState,
                modifier = Modifier.align(Alignment.TopCenter)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemRow(
    modifier: Modifier = Modifier,
    index: Int,
    item: Item,
    isSelected: Boolean,
    isSelectionMode: Boolean,
    onToggleSelection: () -> Unit,
    onEdit: () -> Unit,
    onHistory: () -> Unit
) {
    val decimalFormat = remember { DecimalFormat("#.##") }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { if (isSelectionMode) onToggleSelection() else onEdit() },
                onLongClick = { if (!isSelectionMode) onHistory() }
            )
            .padding(vertical = 12.dp, horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isSelectionMode) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = { onToggleSelection() },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
            )
            Spacer(modifier = Modifier.width(8.dp))
        }

        // Index
        Text(
            text = "${index + 1}",
            color = Color(0xFF1976D2),
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier.width(40.dp)
        )

        // Name
        Text(
            text = item.name,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.Black,
            modifier = Modifier.weight(1f)
        )

        // Price / UOM
        Text(
            text = "₹${decimalFormat.format(item.basePrice)}/${item.uom}",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1976D2)
        )
    }
}
