package com.example.gstcalculator

import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

data class DeletedCustomer(
    val id: String,
    val customerForDisplay: Customer,
    val fullCustomerData: Any, // Raw data to be restored
    val deletionDate: Long
)

class RecycleBinViewModel : ViewModel() {
    private val _deletedCustomers = mutableStateOf<List<DeletedCustomer>>(emptyList())
    val deletedCustomers: State<List<DeletedCustomer>> = _deletedCustomers

    val selectedCustomerIds = mutableStateOf<Set<String>>(emptySet())
    val isSelectionModeActive = derivedStateOf { selectedCustomerIds.value.isNotEmpty() }

    private val recycleBinDatabase = FirebaseDatabase.getInstance().getReference("recycle_bin")

    init {
        fetchDeletedCustomers()
    }

    private fun fetchDeletedCustomers() {
        recycleBinDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customerList = mutableListOf<DeletedCustomer>()
                for (customerSnapshot in snapshot.children) {
                    val customerId = customerSnapshot.key
                    val rawData = customerSnapshot.child("customer").value
                    val customerForDisplay = customerSnapshot.child("customer").getValue(Customer::class.java)
                    val deletionDate = customerSnapshot.child("deletionDate").getValue(Long::class.java)

                    if (customerId != null && rawData != null && customerForDisplay != null && deletionDate != null) {
                        customerForDisplay.id = customerId
                        customerList.add(DeletedCustomer(customerId, customerForDisplay, rawData, deletionDate))
                    }
                }
                _deletedCustomers.value = customerList.sortedByDescending { it.deletionDate }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun toggleCustomerSelection(customerId: String) {
        val currentSelection = selectedCustomerIds.value.toMutableSet()
        if (currentSelection.contains(customerId)) {
            currentSelection.remove(customerId)
        } else {
            currentSelection.add(customerId)
        }
        selectedCustomerIds.value = currentSelection
    }

    fun clearSelection() {
        selectedCustomerIds.value = emptySet()
    }

    fun recoverSelectedCustomers(onComplete: () -> Unit) {
        val customersToRecover = _deletedCustomers.value.filter { it.id in selectedCustomerIds.value }
        if (customersToRecover.isEmpty()) {
            onComplete()
            return
        }

        val updates = mutableMapOf<String, Any?>()
        customersToRecover.forEach { deletedCustomer ->
            val customerData = deletedCustomer.fullCustomerData as Map<*, *>
            val customerType = customerData["customerType"] as? String ?: "HOME"
            val customerId = deletedCustomer.id

            val customerPath = when (customerType) {
                "LOCALS" -> "/customers_locals/$customerId"
                "STAFF" -> "/customers_staff/$customerId"
                else -> "/customers_home/$customerId"
            }
            updates[customerPath] = deletedCustomer.fullCustomerData
            updates["/recycle_bin/$customerId"] = null
        }

        FirebaseDatabase.getInstance().reference.updateChildren(updates).addOnCompleteListener {
            clearSelection()
            onComplete()
        }
    }

    fun permanentlyDeleteSelectedCustomers(onComplete: () -> Unit) {
        val customersToDelete = selectedCustomerIds.value
        if (customersToDelete.isEmpty()) {
            onComplete()
            return
        }

        val updates = mutableMapOf<String, Any?>()
        customersToDelete.forEach {
            updates["/recycle_bin/$it"] = null
        }

        FirebaseDatabase.getInstance().reference.updateChildren(updates).addOnCompleteListener {
            clearSelection()
            onComplete()
        }
    }
}