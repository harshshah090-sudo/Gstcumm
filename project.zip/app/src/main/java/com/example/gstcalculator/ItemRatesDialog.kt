package com.example.gstcalculator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ItemRatesDialog(
    itemRates: Map<String, Map<String, Any>>,
    allItems: List<Item>,
    onDismiss: () -> Unit,
    onRateChanged: (String, String) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    // Fix for Issue 3: Capture the items with rates ONCE when the dialog is initialized.
    // By using 'remember' without keys, this list remains stable even if itemRates 
    // updates from the parent (e.g., when a rate is cleared and removed from the map).
    val itemsToDisplay = remember(allItems, itemRates.keys) {
        allItems.filter { item ->
            val currentNameKey = "${item.name}-${item.uom}"
            itemRates.containsKey(item.id) || 
            itemRates.containsKey(currentNameKey) || 
            item.oldNames.any { oldName -> itemRates.containsKey("$oldName-${item.uom}") }
        }.sortedBy { it.name }
    }

    val filteredItems = remember(searchQuery, itemsToDisplay) {
        itemsToDisplay.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "Item Rates",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp),
                            textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                            singleLine = true,
                            decorationBox = { innerTextField ->
                                Row(
                                    modifier = Modifier
                                        .background(
                                            color = Color(0xFFF5F5F5),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Icon",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        innerTextField()
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = "Search Items",
                                                color = Color.Gray,
                                                fontSize = 14.sp
                                            )
                                        }
                                    }
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { searchQuery = "" },
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Clear Search",
                                                tint = Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        )
                    }
                }

                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 350.dp)
                    ) {
                        items(filteredItems, key = { it.id }) { item ->
                            val currentNameKey = "${item.name}-${item.uom}"
                            
                            // Get current rate data from the updated itemRates map (comes from ViewModel)
                            var rateData = itemRates[item.id] ?: itemRates[currentNameKey]
                            if (rateData == null) {
                                for (oldName in item.oldNames) {
                                    val oldKey = "$oldName-${item.uom}"
                                    if (itemRates.containsKey(oldKey)) {
                                        rateData = itemRates[oldKey]
                                        break
                                    }
                                }
                            }
                            
                            val rateValue = rateData?.get("rate")?.toString()
                            val dateValue = (rateData?.get("date") as? Number)?.toLong() ?: 0L
                            
                            val dateStr = if (dateValue > 0) {
                                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(dateValue))
                            } else ""
                            
                            // Maintain local state for the text field while editing
                            var currentRateText by remember(item.id, rateValue) { mutableStateOf(rateValue ?: "") }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.name} (${item.uom})",
                                        fontSize = 15.sp
                                    )
                                    if (dateStr.isNotEmpty()) {
                                        Text(
                                            text = dateStr,
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                                BasicTextField(
                                    value = currentRateText,
                                    onValueChange = {
                                        currentRateText = it
                                        onRateChanged(item.id, it)
                                    },
                                    textStyle = TextStyle(
                                        color = Color.Black,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .width(80.dp)
                                        .background(Color(0xFFF5F5F5), RoundedCornerShape(4.dp))
                                        .padding(4.dp)
                                )
                            }
                            HorizontalDivider(color = Color.Black.copy(alpha = 0.05f))
                        }
                    }
                }
            }
        }
    }
}
