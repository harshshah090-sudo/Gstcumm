package com.example.gstcalculator

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

class LoginViewModel : ViewModel() {

    val email = mutableStateOf("")
    val password = mutableStateOf("")

    private val _loginState = MutableStateFlow<LoginState>(LoginState.Idle)
    val loginState = _loginState.asStateFlow()

    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()

    fun login() {
        _loginState.value = LoginState.Loading
        val emailValue = email.value.trim()
        val passwordValue = password.value.trim()

        if (emailValue.isEmpty() || passwordValue.isEmpty()) {
            _loginState.value = LoginState.Error("Email and password cannot be empty.")
            return
        }

        auth.signInWithEmailAndPassword(emailValue, passwordValue)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val userId = task.result?.user?.uid
                    if (userId != null) {
                        database.getReference("roles").child(userId).get()
                            .addOnSuccessListener { dataSnapshot ->
                                if (dataSnapshot.exists()) {
                                    val role = dataSnapshot.child("role").getValue(String::class.java) ?: "user"
                                    _loginState.value = LoginState.Success(userRole = role)
                                } else {
                                    _loginState.value = LoginState.Error("User data not found in database for UID: $userId")
                                }
                            }
                            .addOnFailureListener { e ->
                                _loginState.value = LoginState.Error("Failed to retrieve user role for UID: $userId. Error: ${e.message}")
                            }
                    } else {
                        _loginState.value = LoginState.Error("Could not get user UID after login.")
                    }
                } else {
                    _loginState.value = LoginState.Error(task.exception?.message ?: "An unknown error occurred.")
                }
            }
    }
}

sealed class LoginState {
    object Idle : LoginState()
    object Loading : LoginState()
    data class Success(val userRole: String) : LoginState()
    data class Error(val message: String) : LoginState()
}
