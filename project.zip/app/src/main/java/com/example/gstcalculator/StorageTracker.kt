package com.example.gstcalculator

import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

object StorageTracker {
    private val storage = FirebaseStorage.getInstance()
    private val database = FirebaseDatabase.getInstance().getReference("app_stats/storage_usage_bytes")

    // Fast method: Read from database counter
    suspend fun getStoredUsage(): Long {
        return try {
            database.get().await().getValue(Long::class.java) ?: 0L
        } catch (e: Exception) {
            0L
        }
    }

    // Heavy method: Scan all files (Parallel) and update database counter
    suspend fun syncAndGetFolderSize(folderPath: String): Long = withContext(Dispatchers.IO) {
        var totalSize = 0L
        try {
            val listResult = storage.reference.child(folderPath).listAll().await()
            
            // Fetch metadata in parallel for speed
            val deferredSizes = listResult.items.map { fileRef ->
                async {
                    try {
                        fileRef.metadata.await().sizeBytes
                    } catch (e: Exception) {
                        0L
                    }
                }
            }
            totalSize += deferredSizes.awaitAll().sum()

            // Recursively scan subfolders
            val subfolderSizes = listResult.prefixes.map { prefix ->
                async { syncAndGetFolderSize(prefix.path) }
            }
            totalSize += subfolderSizes.awaitAll().sum()

            // Save the result to the database so we don't have to scan again
            database.setValue(totalSize).await()
            
        } catch (e: Exception) {
            Log.e("StorageTracker", "Error syncing storage size", e)
        }
        return@withContext totalSize
    }

    // Helper to increment counter when a new file is uploaded
    fun incrementUsage(bytes: Long) {
        database.get().addOnSuccessListener { snapshot ->
            val current = snapshot.getValue(Long::class.java) ?: 0L
            database.setValue(current + bytes)
        }
    }

    fun formatSize(bytes: Long): String {
        val kb = bytes / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0

        return when {
            gb >= 1 -> "%.2f GB".format(gb)
            mb >= 1 -> "%.2f MB".format(mb)
            kb >= 1 -> "%.2f KB".format(kb)
            else -> "$bytes Bytes"
        }
    }
}
