package com.example.gstcalculator

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditItemDialog(
    item: Item,
    onDismiss: () -> Unit,
    onSave: (Item) -> Unit,
    onDelete: () -> Unit,
    uomViewModel: UomViewModel
) {
    // Initialize editing state
    var name by remember { mutableStateOf(item.name) }
    var basePrice by remember { 
        mutableStateOf(
            if (item.basePrice % 1 == 0.0) item.basePrice.toInt().toString() else item.basePrice.toString()
        ) 
    }
    var uom by remember { mutableStateOf(item.uom) }
    val uoms by uomViewModel.uoms.collectAsState(emptyList())
    var expanded by remember { mutableStateOf(false) }
    
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    
    // Sync variants list in real-time if updated from web/background
    var detailsList by remember { mutableStateOf(item.details) }
    var showBulkPopup by remember { mutableStateOf(false) }

    LaunchedEffect(item.details) {
        detailsList = item.details
    }

    if (showDeleteConfirmation) {
        BouncyDialog(onDismissRequest = { showDeleteConfirmation = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Delete Item", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Are you sure you want to delete '${item.name}'? This action cannot be undone.")
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = { showDeleteConfirmation = false },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { 
                                showDeleteConfirmation = false
                                onDelete() 
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
                        ) {
                            Text("Delete")
                        }
                    }
                }
            }
        }
    }

    if (showBulkPopup) {
        BulkDetailsPopup(
            initialText = detailsList.joinToString("\n"),
            onDismiss = { showBulkPopup = false },
            onSave = {
                detailsList = it
                showBulkPopup = false
            }
        )
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "Edit Item", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                
                LazyColumn(modifier = Modifier.padding(16.dp).fillMaxWidth().heightIn(max = 500.dp)) {
                    item {
                        TextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Item Name") },
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedLabelColor = Color(0xFF1976D2),
                                focusedIndicatorColor = Color(0xFF1976D2)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = basePrice,
                            onValueChange = { basePrice = it },
                            label = { Text("Base Price") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedLabelColor = Color(0xFF1976D2),
                                focusedIndicatorColor = Color(0xFF1976D2)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            TextField(
                                value = uom,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("UOM") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                colors = ExposedDropdownMenuDefaults.textFieldColors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White,
                                    focusedLabelColor = Color(0xFF1976D2),
                                    focusedIndicatorColor = Color(0xFF1976D2)
                                )
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                uoms.forEach { uomItem ->
                                    DropdownMenuItem(text = { Text(uomItem) }, onClick = { uom = uomItem; expanded = false })
                                }
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Button(
                            onClick = { showBulkPopup = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE3F2FD), contentColor = Color(0xFF1976D2)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (detailsList.isEmpty()) "Add Item Details/Variants" else "${detailsList.size} Details Added (Edit)")
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            // Delete Button
                            IconButton(onClick = { showDeleteConfirmation = true }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "Delete",
                                    tint = Color(0xFFD50000)
                                )
                            }
                            
                            Row {
                                TextButton(onClick = onDismiss) { Text("Cancel", color = Color.Gray) }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val newOldNames = if (name != item.name && !item.oldNames.contains(item.name)) {
                                            item.oldNames + item.name
                                        } else {
                                            item.oldNames
                                        }
                                        
                                        val updatedItem = item.copy(
                                            name = name,
                                            basePrice = basePrice.toDoubleOrNull() ?: item.basePrice,
                                            uom = uom,
                                            details = detailsList.distinct().sorted(),
                                            oldNames = newOldNames
                                        )
                                        onSave(updatedItem)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                                ) { Text("Save") }
                            }
                        }
                    }
                }
            }
        }
    }
}
