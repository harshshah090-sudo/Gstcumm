package com.example.gstcalculator

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(navController: NavController) {
    var showBackupRestoreDialog by remember { mutableStateOf(false) }
    var showReminderDialog by remember { mutableStateOf(false) }
    var showDeleteScreensDialog by remember { mutableStateOf(false) }
    
    val context = LocalContext.current
    val userPreferences = remember { UserPreferences(context) }
    
    var userRole by remember { mutableStateOf(userPreferences.getLoginState()) }
    val isAdmin = userRole == "admin"

    LaunchedEffect(Unit) {
        val uid = FirebaseAuth.getInstance().currentUser?.uid
        if (uid != null) {
            FirebaseDatabase.getInstance().getReference("roles").child(uid).child("role")
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val role = snapshot.getValue(String::class.java) ?: "none"
                        userRole = role
                        userPreferences.setLoginState(role)
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        }
    }

    if (showBackupRestoreDialog) {
        BackupRestoreDialog(
            onDismiss = { showBackupRestoreDialog = false },
            backupManager = remember { AppDataBackupManager(context) },
            context = context
        )
    }

    if (showReminderDialog) {
        DefaultReminderTimeDialog(
            onDismiss = { showReminderDialog = false },
            userPreferences = userPreferences
        )
    }
    
    if (showDeleteScreensDialog) {
        DeleteScreensDialog(
            onDismiss = { showDeleteScreensDialog = false },
            userPreferences = userPreferences
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2)),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            if (isAdmin) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showBackupRestoreDialog = true }
                        .padding(vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Backup, contentDescription = "Backup and Restore")
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Backup and Restore", fontSize = 16.sp)
                }
                HorizontalDivider()
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showReminderDialog = true }
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.NotificationsActive, contentDescription = "Default Payment Reminder Time")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Default Payment Reminder Time", fontSize = 16.sp)
            }
            HorizontalDivider()
            
            if (isAdmin) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showDeleteScreensDialog = true }
                        .padding(vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Layers, contentDescription = "Delete Custom Screens")
                    Spacer(modifier = Modifier.width(16.dp))
                    Text("Delete Custom Screens", fontSize = 16.sp)
                }
                HorizontalDivider()
            }
            
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { navController.navigate("recycleBin") }
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Recycle Bin")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Recycle Bin", fontSize = 16.sp)
            }
            HorizontalDivider()
            Spacer(modifier = Modifier.weight(1f))
            Button(
                onClick = {
                    FirebaseAuth.getInstance().signOut()
                    userPreferences.setLoginState("none")
                    DataRepository.isAdmin = false
                    navController.navigate("login") {
                        popUpTo("main") { inclusive = true }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Text("Logout")
            }
        }
    }
}

@Composable
fun DeleteScreensDialog(
    onDismiss: () -> Unit,
    userPreferences: UserPreferences
) {
    val customScreens by DataRepository.customScreens.collectAsState()
    var screenToDelete by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    if (screenToDelete != null) {
        BouncyDialog(onDismissRequest = { screenToDelete = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Delete Screen", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Are you sure you want to delete the ${screenToDelete} screen permanently?")
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { screenToDelete = null }) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = {
                            screenToDelete?.let { screen ->
                                DataRepository.removeCustomScreen(screen)
                                Toast.makeText(context, "$screen deleted", Toast.LENGTH_SHORT).show()
                            }
                            screenToDelete = null
                        }) {
                            Text("Delete", color = Color.Red)
                        }
                    }
                }
            }
        }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().heightIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Delete Custom Screens",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    if (customScreens.isEmpty()) {
                        Text("No custom screens found.", color = Color.Gray, modifier = Modifier.padding(vertical = 16.dp))
                    } else {
                        LazyColumn(modifier = Modifier.weight(1f, fill = false).heightIn(max = 300.dp)) {
                            items(customScreens) { screen ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(screen, fontSize = 16.sp)
                                    IconButton(onClick = { screenToDelete = screen }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
                                    }
                                }
                                HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Done")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DefaultReminderTimeDialog(
    onDismiss: () -> Unit,
    userPreferences: UserPreferences
) {
    val context = LocalContext.current
    var reminderDays by remember { mutableStateOf(userPreferences.getDefaultReminderDays().toString()) }
    var exceptions by remember { mutableStateOf<List<Customer>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    val databases = remember {
        listOf(
            FirebaseDatabase.getInstance().getReference("customers_home"),
            FirebaseDatabase.getInstance().getReference("customers_staff"),
            FirebaseDatabase.getInstance().getReference("customers_locals")
        )
    }

    fun loadExceptions() {
        isLoading = true
        val currentDefault = userPreferences.getDefaultReminderDays()
        val allExceptions = mutableListOf<Customer>()
        var databasesProcessed = 0

        databases.forEach { db ->
            db.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (customerSnapshot in snapshot.children) {
                        val customer = customerSnapshot.getValue(Customer::class.java)
                        customer?.let {
                            // Rule #2: Exception is anyone whose days are different from default AND NOT NULL
                            // If it is NULL, they are already following the default.
                            if (it.paymentReminderDays != null && it.paymentReminderDays != currentDefault) {
                                it.id = customerSnapshot.key
                                // Store which DB they belong to for deletion logic
                                it.customerType = when(db.key) {
                                    "customers_staff" -> "STAFF"
                                    "customers_locals" -> "LOCALS"
                                    else -> "HOME"
                                }
                                allExceptions.add(it)
                            }
                        }
                    }
                    databasesProcessed++
                    if (databasesProcessed == databases.size) {
                        exceptions = allExceptions.sortedBy { it.name }
                        isLoading = false
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    databasesProcessed++
                    if (databasesProcessed == databases.size) {
                        isLoading = false
                    }
                }
            })
        }
    }

    LaunchedEffect(Unit) {
        loadExceptions()
    }

    BouncyDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .heightIn(max = 600.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Default Reminder Time",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TextField(
                            value = reminderDays,
                            onValueChange = { reminderDays = it },
                            label = { Text("Days") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.width(100.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedIndicatorColor = Color(0xFF1976D2),
                                focusedLabelColor = Color(0xFF1976D2)
                            )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text("Days", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }

                    Spacer(modifier = Modifier.height(20.dp))
                    Text("Exceptions (Custom Times):", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))

                    Box(modifier = Modifier.fillMaxWidth().weight(1f, fill = false).heightIn(min = 40.dp, max = 250.dp)) {
                        if (isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp).align(Alignment.Center), color = Color(0xFF1976D2))
                        } else if (exceptions.isEmpty()) {
                            Text("No exceptions found.", color = Color.Gray, modifier = Modifier.align(Alignment.Center))
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(exceptions) { customer ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Column 1: Name (Black)
                                        Text(
                                            text = customer.name, 
                                            modifier = Modifier.weight(1f), 
                                            fontSize = 14.sp,
                                            color = Color.Black
                                        )
                                        
                                        // Column 2: Days (Theme Blue)
                                        Text(
                                            text = "${customer.paymentReminderDays}", 
                                            fontWeight = FontWeight.Bold, 
                                            fontSize = 14.sp, 
                                            color = Color(0xFF1976D2),
                                            modifier = Modifier.width(40.dp)
                                        )
                                        
                                        // Column 3: Delete (Red X)
                                        IconButton(
                                            onClick = {
                                                val dbPath = when(customer.customerType) {
                                                    "STAFF" -> "customers_staff"
                                                    "LOCALS" -> "customers_locals"
                                                    else -> "customers_home"
                                                }
                                                // Rule #4: Delete custom time and reset to default
                                                // We set to NULL to indicate it should follow app default
                                                FirebaseDatabase.getInstance().getReference(dbPath)
                                                    .child(customer.id!!)
                                                    .child("paymentReminderDays")
                                                    .removeValue()
                                                    .addOnSuccessListener {
                                                        loadExceptions()
                                                    }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Close, 
                                                contentDescription = "Remove Exception", 
                                                tint = Color.Red,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = onDismiss
                        ) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val newDays = reminderDays.toIntOrNull()
                                if (newDays != null) {
                                    val oldDefault = userPreferences.getDefaultReminderDays()
                                    userPreferences.setDefaultReminderDays(newDays)

                                    // Rule #1: Update customers having the old default (or no setting) to the new default
                                    databases.forEach { db ->
                                        db.addListenerForSingleValueEvent(object : ValueEventListener {
                                            override fun onDataChange(snapshot: DataSnapshot) {
                                                for (customerSnapshot in snapshot.children) {
                                                    val customer = customerSnapshot.getValue(Customer::class.java)
                                                    // Match if they have the old default OR if they have no setting (null)
                                                    if (customer?.paymentReminderDays == oldDefault || customer?.paymentReminderDays == null) {
                                                        customerSnapshot.ref.child("paymentReminderDays").setValue(newDays)
                                                    }
                                                }
                                            }
                                            override fun onCancelled(error: DatabaseError) {}
                                        })
                                    }
                                    Toast.makeText(context, "Default updated to $newDays days", Toast.LENGTH_SHORT).show()
                                    onDismiss()
                                } else {
                                    Toast.makeText(context, "Invalid number", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Update")
                        }
                    }
                }
            }
        }
    }
}
