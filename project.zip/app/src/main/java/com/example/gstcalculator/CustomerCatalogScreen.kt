package com.example.gstcalculator

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

val AppThemeRed = Color(0xFFD50000)
val AppBackgroundColor = Color(0xFFF5F5F5)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CustomerCatalogScreen(
    navController: NavController,
    customerId: String,
    customerType: String
) {
    val viewModel: CustomerCatalogViewModel = viewModel(
        factory = CustomerCatalogViewModelFactory(customerId, customerType)
    )
    val items by viewModel.filteredItems.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val cart = viewModel.cart
    val isSubmitting by viewModel.isSubmitting
    val coroutineScope = rememberCoroutineScope()

    val screenName = if (customerType == "HOME" || customerType == "LOCALS" || customerType == "STAFF") "Shah Stores" else customerType
    val itemViewModel: ItemViewModel = viewModel(
        key = "Item_$screenName",
        factory = ItemViewModelFactory(screenName)
    )
    val uomViewModel: UomViewModel = viewModel()
    var showAddItemDialog by remember { mutableStateOf(false) }
    var showUomDialog by remember { mutableStateOf(false) }

    var selectedItemIdForVariables by remember { mutableStateOf<String?>(null) }
    var showCartSummary by remember { mutableStateOf(false) }
    var showExitWarning by remember { mutableStateOf(false) }
    
    var showSalesHistoryDialog by remember { mutableStateOf(false) }
    var salesHistory by remember { mutableStateOf<List<ItemSale>>(emptyList()) }
    var selectedItemForHistory by remember { mutableStateOf<Item?>(null) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    val handleBack: () -> Unit = {
        if (cart.isNotEmpty()) {
            showExitWarning = true
        } else {
            navController.popBackStack()
        }
    }

    // Handle system back button
    BackHandler(enabled = true) {
        handleBack()
    }

    if (showExitWarning) {
        BouncyDialog(onDismissRequest = { showExitWarning = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Exit Catalog?", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("You have items in your cart. Exiting will discard this order.", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showExitWarning = false }) {
                            Text("Stay", fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(onClick = {
                            showExitWarning = false
                            navController.popBackStack()
                        }) {
                            Text("Discard", color = AppThemeRed, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
    
    if (showSalesHistoryDialog) {
        selectedItemForHistory?.let { item ->
            ItemSalesHistoryDialog(
                onDismiss = { showSalesHistoryDialog = false },
                itemName = item.name,
                salesHistory = salesHistory,
                uom = item.uom
            )
        }
    }

    if (showAddItemDialog) {
        AddItemDialog(
            onDismiss = { showAddItemDialog = false },
            onAddItem = { name, price, uom, details ->
                itemViewModel.addItem(name, price, uom, details)
                showAddItemDialog = false
            },
            uomViewModel = uomViewModel,
            onEditUomClicked = { showUomDialog = true }
        )
    }

    if (showUomDialog) {
        ManageUomDialog(
            onDismiss = { showUomDialog = false },
            uomViewModel = uomViewModel
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(viewModel.customerName.value, color = Color.White, fontSize = 16.sp)
                        @OptIn(ExperimentalMaterial3Api::class)
                        Text("Place Order", color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = handleBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(onClick = { showAddItemDialog = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add Item", tint = Color.White)
                    }
                    IconButton(onClick = { showCartSummary = true }) {
                        BadgedBox(
                            badge = {
                                if (cart.isNotEmpty()) {
                                    Badge {
                                        Text(cart.size.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2))
            )
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shadowElevation = 8.dp,
                    color = Color.White
                ) {
                    Button(
                        onClick = {
                            viewModel.placeOrder {
                                navController.popBackStack()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .height(48.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White)
                        } else {
                            @OptIn(ExperimentalMaterial3Api::class)
                            Text("Place Order (${cart.size} items)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(AppBackgroundColor)
        ) {
            // Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF1976D2))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .zIndex(1f) // Ensure search bar stays on top during row bounce
            ) {
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.onSearchQueryChanged(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(36.dp),
                    textStyle = TextStyle(fontSize = 13.sp, color = Color.Black),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    decorationBox = { innerTextField ->
                        Row(
                            modifier = Modifier
                                .background(Color.White, RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(modifier = Modifier.weight(1f)) {
                                if (searchQuery.isEmpty()) Text("Search items...", color = Color.Gray, fontSize = 13.sp)
                                innerTextField()
                            }
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { viewModel.onSearchQueryChanged("") }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Clear, contentDescription = null, tint = Color.Gray)
                                }
                            }
                        }
                    }
                )
            }

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { item ->
                    CatalogItemRow(
                        modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                        item = item, 
                        viewModel = viewModel,
                        onOpenVariables = { selectedItemIdForVariables = item.id },
                        onHistoryClick = {
                            coroutineScope.launch {
                                salesHistory = viewModel.getSalesHistoryForItem(item.name, item.uom, item.id)
                                selectedItemForHistory = item
                                showSalesHistoryDialog = true
                            }
                        }
                    )
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                }
            }
        }
    }

    selectedItemIdForVariables?.let { itemId ->
        VariableSelectionDialog(
            itemId = itemId,
            viewModel = viewModel,
            onDismiss = { selectedItemIdForVariables = null }
        )
    }

    if (showCartSummary) {
        CartSummaryDialog(
            viewModel = viewModel,
            onDismiss = { showCartSummary = false }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CatalogItemRow(
    modifier: Modifier = Modifier,
    item: Item, 
    viewModel: CustomerCatalogViewModel,
    onOpenVariables: () -> Unit,
    onHistoryClick: () -> Unit
) {
    val itemRates by viewModel.itemRates.collectAsState()
    val soldRateData = itemRates[item.id] ?: itemRates["${item.name}-${item.uom}"]
    val soldRate = soldRateData?.get("rate")?.toString() ?: ""
    val qty = viewModel.cart[item.id] ?: ""
    val focusRequester = remember { FocusRequester() }

    val density = LocalDensity.current
    val rateEditMaxOffset = with(density) { 120.dp.toPx() } // Slide left (negative)
    val basePriceMaxOffset = with(density) { 180.dp.toPx() } // Slide right (positive) - increased for icon
    
    var offsetX by remember { mutableFloatStateOf(0f) }
    val animatedOffsetX by animateFloatAsState(targetValue = offsetX)
    
    var rateEditValue by remember(soldRate) { mutableStateOf(soldRate) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFFF0F0F0))
    ) {
        // Base Price Reveal (Right Swipe)
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "₹${item.basePrice} / ${item.uom}",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = onHistoryClick, modifier = Modifier.size(24.dp)) {
                    Icon(Icons.Default.History, contentDescription = "History", tint = Color(0xFF1976D2), modifier = Modifier.size(20.dp))
                }
            }
        }

        // Rate Edit Reveal (Left Swipe)
        Box(
            modifier = Modifier
                .matchParentSize()
                .padding(horizontal = 16.dp),
            contentAlignment = Alignment.CenterEnd
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Rate: ", fontSize = 13.sp, color = Color.Gray)
                BasicTextField(
                    value = rateEditValue,
                    onValueChange = { 
                        rateEditValue = it
                        viewModel.saveItemRate(item.id, item.name, item.uom, it)
                    },
                    modifier = Modifier
                        .width(70.dp)
                        .background(Color.White, RoundedCornerShape(4.dp))
                        .border(0.5.dp, Color.LightGray, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    textStyle = TextStyle(fontSize = 14.sp, textAlign = TextAlign.Center),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    decorationBox = { innerTextField ->
                        Box(contentAlignment = Alignment.Center) {
                            if (rateEditValue.isEmpty()) Text("0.0", color = Color.LightGray, fontSize = 14.sp)
                            innerTextField()
                        }
                    }
                )
            }
        }

        // Foreground content (Slidable Row)
        Row(
            modifier = Modifier
                .offset { IntOffset(animatedOffsetX.roundToInt(), 0) }
                .fillMaxWidth()
                .background(Color.White)
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        val newOffset = offsetX + delta
                        offsetX = newOffset.coerceIn(-rateEditMaxOffset, basePriceMaxOffset)
                    },
                    onDragStopped = {
                        offsetX = if (offsetX < -rateEditMaxOffset / 2) -rateEditMaxOffset 
                                 else if (offsetX > basePriceMaxOffset / 2) basePriceMaxOffset
                                 else 0f
                    }
                )
                .combinedClickable(
                    onClick = {
                        if (item.details.isEmpty()) {
                            try { focusRequester.requestFocus() } catch (e: Exception) {}
                        } else {
                            onOpenVariables()
                        }
                    },
                    onLongClick = onOpenVariables
                )
                .padding(horizontal = 16.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                Text(
                    text = buildAnnotatedString {
                        withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, fontSize = 18.sp)) {
                            append(item.name)
                        }
                        if (soldRate.isNotBlank()) {
                            withStyle(style = SpanStyle(color = AppThemeRed, fontSize = 17.sp, fontWeight = FontWeight.Bold)) {
                                append(" $soldRate")
                            }
                        }
                        withStyle(style = SpanStyle(color = Color.Gray, fontSize = 14.sp)) {
                            append("/")
                            append(item.uom)
                        }
                    },
                    textAlign = TextAlign.Start
                )
            }

            if (item.details.isEmpty()) {
                CompactQtyTextField(
                    value = qty,
                    onValueChange = { viewModel.updateCart(item.id, it) },
                    modifier = Modifier.width(105.dp).height(39.dp).focusRequester(focusRequester)
                )
            } else {
                Button(
                    onClick = onOpenVariables,
                    modifier = Modifier.height(39.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (qty.isNotEmpty()) Color(0xFF1976D2) else Color.Gray.copy(alpha = 0.1f),
                        contentColor = if (qty.isNotEmpty()) Color.White else Color.Black
                    ),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(if (qty.isNotEmpty()) "Qty: $qty" else "Select", fontSize = 13.sp)
                }
            }
        }
    }
}


private fun formatPrice(price: Double): String {
    return if (price % 1.0 == 0.0) price.toLong().toString() else price.toString()
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VariableSelectionDialog(
    itemId: String,
    viewModel: CustomerCatalogViewModel,
    onDismiss: () -> Unit
) {
    val allItems by viewModel.allItems.collectAsState()
    val item = allItems.find { it.id == itemId } ?: return
    
    var varSearchQuery by remember { mutableStateOf("") }
    val focusRequesters = remember { mutableMapOf<String, FocusRequester>() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()
    val keyboardController = LocalSoftwareKeyboardController.current

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )
    
    val filteredVars = remember(varSearchQuery, item.details) {
        if (varSearchQuery.isBlank()) item.details
        else item.details.filter { it.contains(varSearchQuery, ignoreCase = true) }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier.fillMaxWidth().heightIn(max = 500.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = AppBackgroundColor)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Box(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFF1976D2)).padding(12.dp).zIndex(1f) // Ensure header on top during bounce
                ) {
                    Text(item.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }

                // Variable List
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .heightIn(max = 300.dp)
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    items(filteredVars, key = { it }) { variable ->
                        val qty = viewModel.breakdowns[itemId]?.get(variable) ?: ""
                        val focusRequester = focusRequesters.getOrPut(variable) { FocusRequester() }
                        
                        var showDeleteConfirm by remember { mutableStateOf(false) }

                        Row(
                            modifier = Modifier
                                .animateItemPlacement(animationSpec = springSpec)
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { try { focusRequester.requestFocus() } catch (e: Exception) {} },
                                    onLongClick = { showDeleteConfirm = true }
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(variable, modifier = Modifier.weight(1f), fontSize = 13.sp)
                            CompactQtyTextField(
                                value = qty,
                                onValueChange = { viewModel.updateBreakdown(itemId, variable, it) },
                                modifier = Modifier.width(105.dp).height(39.dp).focusRequester(focusRequester)
                            )
                        }
                        
                        if (showDeleteConfirm) {
                            BouncyDialog(onDismissRequest = { showDeleteConfirm = false }) {
                                Card(
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color.White),
                                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text("Delete Variable", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("Are you sure you want to delete '$variable' globally?", fontSize = 13.sp)
                                        Spacer(modifier = Modifier.height(24.dp))
                                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                            TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel", fontSize = 13.sp) }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            TextButton(onClick = {
                                                viewModel.deleteVariableGlobally(itemId, variable)
                                                showDeleteConfirm = false
                                            }) { Text("Delete", color = AppThemeRed, fontSize = 13.sp) }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Search/Add Bar
                Box(
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                ) {
                    BasicTextField(
                        value = varSearchQuery,
                        onValueChange = { varSearchQuery = it },
                        modifier = Modifier.fillMaxWidth().height(36.dp),
                        textStyle = TextStyle(fontSize = 13.sp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(
                            imeAction = ImeAction.Search, 
                            capitalization = KeyboardCapitalization.Words
                        ),
                        keyboardActions = KeyboardActions(
                            onSearch = {
                                if (varSearchQuery.isNotBlank()) {
                                    val trimmed = varSearchQuery.trim()
                                    val existingVisible = filteredVars.find { it.equals(trimmed, ignoreCase = true) }
                                    
                                    if (existingVisible != null) {
                                        scope.launch {
                                            val index = filteredVars.indexOf(existingVisible)
                                            if (index != -1) listState.animateScrollToItem(index)
                                            delay(300)
                                            try {
                                                focusRequesters[existingVisible]?.requestFocus()
                                            } catch (e: Exception) {}
                                            keyboardController?.show()
                                        }
                                    } else {
                                        val existingAny = item.details.find { it.equals(trimmed, ignoreCase = true) }
                                        if (existingAny == null) {
                                            // Add new variant
                                            viewModel.addVariableGlobally(itemId, trimmed)
                                            varSearchQuery = ""
                                            scope.launch {
                                                delay(500)
                                                val updatedItem = viewModel.allItems.value.find { it.id == itemId }
                                                val newVar = updatedItem?.details?.find { it.equals(trimmed, ignoreCase = true) } ?: trimmed
                                                val index = updatedItem?.details?.indexOf(newVar) ?: -1
                                                if (index != -1) listState.animateScrollToItem(index)
                                                delay(300)
                                                try {
                                                    focusRequesters[newVar]?.requestFocus()
                                                } catch (e: Exception) {}
                                                keyboardController?.show()
                                            }
                                        } else {
                                            // Exists but was filtered
                                            varSearchQuery = ""
                                            scope.launch {
                                                delay(200)
                                                val index = item.details.indexOf(existingAny)
                                                if (index != -1) listState.animateScrollToItem(index)
                                                delay(300)
                                                try {
                                                    focusRequesters[existingAny]?.requestFocus()
                                                } catch (e: Exception) {}
                                                keyboardController?.show()
                                            }
                                        }
                                    }
                                }
                            }
                        ),
                        decorationBox = { innerTextField ->
                            Row(
                                modifier = Modifier
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .border(0.5.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.weight(1f)) {
                                    if (varSearchQuery.isEmpty()) Text("Search or add variable...", color = Color.Gray, fontSize = 12.sp)
                                    innerTextField()
                                }
                            }
                        }
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartSummaryDialog(
    viewModel: CustomerCatalogViewModel,
    onDismiss: () -> Unit
) {
    val cart = viewModel.cart
    val items by viewModel.allItems.collectAsState()

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 500.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = AppBackgroundColor)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFF1976D2)).padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Cart Summary", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f, fill = false)
                        .padding(16.dp)
                ) {
                    val sortedCart = cart.keys.toList().mapNotNull { id -> items.find { it.id == id } }
                        .sortedBy { it.name }
                    
                    items(sortedCart) { item ->
                        Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(item.name, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                Text("Qty: ${cart[item.id]} ${item.uom}", color = Color(0xFF1976D2), fontSize = 13.sp)
                            }
                            
                            val breakdown = viewModel.breakdowns[item.id]
                            if (!breakdown.isNullOrEmpty()) {
                                breakdown.forEach { (variant, bQty) ->
                                    Text("  • $variant: $bQty", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(top = 8.dp), color = Color.LightGray.copy(alpha = 0.5f))
                        }
                    }
                    
                    if (cart.isEmpty()) {
                        item {
                            Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text("Cart is empty", color = Color.Gray)
                            }
                        }
                    }
                }
                
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                ) {
                    @OptIn(ExperimentalMaterial3Api::class)
                    Text("OK")
                }
            }
        }
    }
}

@Composable
fun CompactQtyTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        textStyle = TextStyle(fontSize = 16.sp, textAlign = TextAlign.Center),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        singleLine = true,
        decorationBox = { innerTextField ->
            Box(
                modifier = Modifier
                    .background(Color.White, RoundedCornerShape(4.dp))
                    .border(0.5.dp, Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (value.isEmpty()) {
                    Text("Qty", fontSize = 14.sp, color = Color.Gray, textAlign = TextAlign.Center)
                }
                innerTextField()
            }
        }
    )
}
