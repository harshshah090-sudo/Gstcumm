package com.example.gstcalculator

import com.google.firebase.database.IgnoreExtraProperties
import java.util.TreeMap

@IgnoreExtraProperties
data class BillItem(
    val itemId: String = "",
    val name: String = "",
    val qty: Any? = "", // Can be String or Long from Firebase
    val rate: String = "",
    val uom: String = "",
    val basePrice: String = "",
    val breakdown: Any? = null // Handle Map or List from Firebase
) {
    fun getQtyString(): String = qty?.toString() ?: ""

    fun getQtyDouble(): Double = getQtyString().toDoubleOrNull() ?: 0.0

    fun getBreakdownStrings(): Map<String, String>? {
        val result = when (val b = breakdown) {
            is Map<*, *> -> {
                b.entries.associate { it.key.toString() to it.value.toString() }
            }
            is List<*> -> {
                b.mapIndexed { index, value -> index.toString() to value.toString() }
                    .filter { it.second != "null" && it.second.isNotEmpty() }
                    .toMap()
            }
            else -> null
        }
        // Return a TreeMap to ensure A-Z sorting
        return result?.let { TreeMap(it) }
    }
}
