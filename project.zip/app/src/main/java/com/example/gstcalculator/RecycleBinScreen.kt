package com.example.gstcalculator

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun RecycleBinScreen(navController: NavController) {
    val viewModel: RecycleBinViewModel = viewModel()
    val deletedCustomers by viewModel.deletedCustomers
    val selectedCustomerIds by viewModel.selectedCustomerIds
    val isSelectionModeActive by viewModel.isSelectionModeActive

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    Scaffold(
        topBar = {
            TopAppBar(
                modifier = Modifier.zIndex(1f), // Keep header on top during list bounce
                title = {
                    @OptIn(ExperimentalMaterial3Api::class)
                    Column {
                        if (isSelectionModeActive) {
                            Text("${selectedCustomerIds.size} selected", color = Color.White)
                        } else {
                            Text("Recycle Bin", color = Color.White)
                            Text("Auto delete in 2 months", color = Color.White, fontSize = 12.sp)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2)),
                navigationIcon = {
                    IconButton(onClick = { 
                        if (isSelectionModeActive) {
                            viewModel.clearSelection()
                        } else {
                            navController.popBackStack()
                        }
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    if (isSelectionModeActive) {
                        IconButton(onClick = { viewModel.recoverSelectedCustomers { } }) {
                            Icon(Icons.Default.Restore, contentDescription = "Recover", tint = Color.White)
                        }
                        IconButton(onClick = { viewModel.permanentlyDeleteSelectedCustomers { } }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.White)
                        }
                    }
                }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            items(deletedCustomers, key = { it.id }) { deletedCustomer ->
                val isSelected = selectedCustomerIds.contains(deletedCustomer.id)
                val customerWithDeletionDate = deletedCustomer.customerForDisplay.copy(lastUpdated = deletedCustomer.deletionDate)

                Box(
                    modifier = Modifier
                        .animateItemPlacement(animationSpec = springSpec)
                        .fillMaxWidth()
                        .combinedClickable(
                            onClick = {
                                if (isSelectionModeActive) {
                                    viewModel.toggleCustomerSelection(deletedCustomer.id)
                                }
                            },
                            onLongClick = { 
                                viewModel.toggleCustomerSelection(deletedCustomer.id)
                            }
                        )
                        .background(if (isSelected) Color(0xFFD3E3F3) else Color.Transparent)
                ) {
                    CustomerItem(
                        customer = customerWithDeletionDate,
                        onAvatarClick = { 
                            if (isSelectionModeActive) {
                                viewModel.toggleCustomerSelection(deletedCustomer.id)
                            }
                        },
                        currentCustomerType = "", // Not needed in Recycle Bin
                        isRecycleBin = true
                    )
                }
                HorizontalDivider()
            }
        }
    }
}