package com.example.gstcalculator

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

data class DeletedTransaction(
    val id: String = "",
    val transaction: Transaction = Transaction(),
    val deletionDate: Long = 0L
)

class TransactionRecycleBinViewModel(private val customerId: String) : ViewModel() {
    private val deletedTransactionsDatabase = FirebaseDatabase.getInstance().getReference("deleted_transactions").child(customerId)
    private val customersDatabase = FirebaseDatabase.getInstance().getReference()
    val deletedTransactions = mutableStateOf<List<DeletedTransaction>>(emptyList())
    val customer = mutableStateOf<Customer?>(null)

    private val SIXTY_DAYS_MS = 60L * 24 * 60 * 60 * 1000

    init {
        loadCustomer()
        loadDeletedTransactions()
        cleanupOldTransactions()
    }

    private fun loadCustomer() {
        // We don't know the exact customerType here easily without passing it, 
        // but we can try to find it in the 3 locations if needed.
        // For PDF generation, we mostly need the customer object.
        listOf("customers_home", "customers_staff", "customers_locals").forEach { type ->
            FirebaseDatabase.getInstance().getReference(type).child(customerId)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val loadedCustomer = snapshot.getValue(Customer::class.java)
                        if (loadedCustomer != null) {
                            loadedCustomer.id = snapshot.key
                            customer.value = loadedCustomer
                        }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        }
    }

    private fun loadDeletedTransactions() {
        deletedTransactionsDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<DeletedTransaction>()
                for (child in snapshot.children) {
                    val transaction = child.child("transaction").getValue(Transaction::class.java)
                    val deletionDate = child.child("deletionDate").getValue(Long::class.java) ?: 0L
                    if (transaction != null) {
                        list.add(DeletedTransaction(child.key ?: "", transaction, deletionDate))
                    }
                }
                deletedTransactions.value = list.sortedByDescending { it.deletionDate }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun cleanupOldTransactions() {
        deletedTransactionsDatabase.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val now = System.currentTimeMillis()
                for (child in snapshot.children) {
                    val deletionDate = child.child("deletionDate").getValue(Long::class.java) ?: 0L
                    if (now - deletionDate > SIXTY_DAYS_MS) {
                        child.ref.removeValue()
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun restoreTransaction(deletedTransaction: DeletedTransaction, customerType: String, onComplete: () -> Unit) {
        val database = when (customerType) {
            "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
            "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
            else -> FirebaseDatabase.getInstance().getReference("customers_home")
        }

        val transaction = deletedTransaction.transaction
        val transactionId = deletedTransaction.id

        viewModelScope.launch {
            database.child(customerId).child("transactions").child(transactionId).setValue(transaction).addOnSuccessListener {
                deletedTransactionsDatabase.child(transactionId).removeValue().addOnSuccessListener {
                    onComplete()
                }
            }
        }
    }

    fun openPdf(transaction: Transaction, context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            // Clean up previous temporary PDF files
            val cacheDir = context.cacheDir
            cacheDir.listFiles()?.forEach { file ->
                if (file.name.startsWith("bill_") || file.name.startsWith("temp_bill") || file.name.startsWith("draft_")) {
                    file.delete()
                }
            }

            val totalAmount = if (transaction.paid) transaction.paidAmount ?: 0.0 else transaction.amount ?: 0.0
            
            // Note: In recycle bin, we might not have the full transactionsWithBalances context 
            // for "last running balance" calculation in the PDF, so we pass an empty list.
            val pdfData = PdfGenerator.createPdf(
                customer = customer.value,
                date = transaction.date ?: 0,
                billItems = transaction.items ?: emptyList(),
                totalAmount = totalAmount,
                transactionsWithBalances = emptyList(),
                isPaid = transaction.paid,
                isPurchaseReturn = transaction.type == "GOT",
                printTwoCopies = false
            )

            val file = File(context.cacheDir, "bill_${UUID.randomUUID()}.pdf")
            FileOutputStream(file).use { it.write(pdfData) }

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )

            withContext(Dispatchers.Main) {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "application/pdf")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                context.startActivity(intent)
            }
        }
    }
}

class TransactionRecycleBinViewModelFactory(private val customerId: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TransactionRecycleBinViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return TransactionRecycleBinViewModel(customerId) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
