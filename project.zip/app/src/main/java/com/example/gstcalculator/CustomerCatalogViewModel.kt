package com.example.gstcalculator

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class CustomerCatalogViewModel(
    private val customerId: String,
    private val customerType: String
) : ViewModel() {

    private val auth = FirebaseAuth.getInstance()
    private val database = when (customerType) {
        "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
        "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
        "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
        else -> FirebaseDatabase.getInstance().getReference("customers_custom_$customerType")
    }

    private val itemDatabase = if (customerType == "HOME" || customerType == "LOCALS" || customerType == "STAFF") {
        FirebaseDatabase.getInstance().getReference("items")
    } else {
        FirebaseDatabase.getInstance().getReference("custom_items").child(customerType)
    }

    private val ordersDatabase = FirebaseDatabase.getInstance().getReference("web_orders")

    private val _items = MutableStateFlow<List<Item>>(emptyList())
    val allItems: StateFlow<List<Item>> = _items

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _itemRates = MutableStateFlow<Map<String, Map<String, Any>>>(emptyMap())
    val itemRates: StateFlow<Map<String, Map<String, Any>>> = _itemRates

    val filteredItems: StateFlow<List<Item>> = combine(_items, _searchQuery, _itemRates) { items, query, rates ->
        val filtered = if (query.isBlank()) {
            items
        } else {
            val searchWords = query.split(" ").filter { it.isNotBlank() }
            items.filter { item ->
                searchWords.all { word ->
                    item.name.contains(word, ignoreCase = true)
                }
            }
        }

        filtered.sortedWith { a, b ->
            val aSold = rates.containsKey(a.id) || rates.containsKey("${a.name}-${a.uom}")
            val bSold = rates.containsKey(b.id) || rates.containsKey("${b.name}-${b.uom}")
            
            if (aSold && !bSold) -1
            else if (!aSold && bSold) 1
            else AlphaNumericComparator.compare(a.name, b.name)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customerName = mutableStateOf("")
    
    // cart: itemId -> total quantity
    val cart = mutableStateMapOf<String, String>()
    // breakdown: itemId -> SnapshotStateMap<variantName, quantity>
    val breakdowns = mutableStateMapOf<String, SnapshotStateMap<String, String>>()
    
    // Tracks the sequence of item selection
    private val _itemSequence = mutableStateListOf<String>()

    val isSubmitting = mutableStateOf(false)
    private var isOrderLoaded = false

    init {
        loadCustomer()
        loadItems()
        loadItemRates()
    }

    private fun loadCustomer() {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                customerName.value = snapshot.child("name").getValue(String::class.java) ?: ""
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadItems() {
        itemDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val itemList = mutableListOf<Item>()
                snapshot.children.forEach { child ->
                    val isDeleted = child.child("isDeleted").getValue(Boolean::class.java) ?: false
                    if (!isDeleted) {
                        val name = child.child("name").getValue(String::class.java) ?: ""
                        val basePrice = (child.child("basePrice").value as? Number)?.toDouble() ?: 0.0
                        val uom = child.child("uom").getValue(String::class.java) ?: ""
                        val details = mutableListOf<String>()
                        child.child("details").children.forEach { detail ->
                            detail.getValue(String::class.java)?.let { details.add(it) }
                        }
                        itemList.add(Item(child.key ?: "", name, basePrice, uom, isDeleted, details.sortedWith(AlphaNumericComparator)))
                    }
                }
                _items.value = itemList
                
                if (!isOrderLoaded && itemList.isNotEmpty()) {
                    loadExistingOrder(itemList)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun loadItemRates() {
        database.child(customerId).child("itemRates").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val rates = snapshot.children.associate { 
                    val rate = if (it.hasChild("rate")) it.child("rate").value.toString() else it.value.toString()
                    val date = if (it.hasChild("date")) (it.child("date").value as? Number)?.toLong() ?: 0L else 0L
                    val isBill = it.child("isBill").getValue(Boolean::class.java) ?: false
                    desanitizeKey(it.key!!) to mapOf("rate" to rate, "date" to date, "isBill" to isBill)
                }
                _itemRates.value = rates
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun saveItemRate(itemId: String, itemName: String, uom: String, rate: String) {
        val sanitizedId = sanitizeKey(itemId)
        val nameKey = "$itemName-$uom"
        val sanitizedNameKey = sanitizeKey(nameKey)
        
        if (rate.isEmpty()) {
            database.child(customerId).child("itemRates").child(sanitizedId).removeValue()
            database.child(customerId).child("itemRates").child(sanitizedNameKey).removeValue()
        } else {
            val existingData = _itemRates.value[itemId] ?: _itemRates.value[nameKey]
            val existingDate = (existingData?.get("date") as? Number)?.toLong() ?: 0L
            val now = System.currentTimeMillis()
            
            if (now >= existingDate) {
                val rateData = mapOf(
                    "rate" to rate,
                    "date" to now,
                    "isBill" to false
                )
                database.child(customerId).child("itemRates").child(sanitizedId).setValue(rateData)
                
                // Local update for immediate UI refresh
                val updated = _itemRates.value.toMutableMap()
                updated[itemId] = rateData
                updated[nameKey] = rateData
                _itemRates.value = updated
            }
        }
    }

    private fun sanitizeKey(key: String): String {
        return key.replace(".", ",").replace("/", "__slash__")
    }

    private fun desanitizeKey(key: String): String {
        return key.replace(",", ".").replace("__slash__", "/")
    }

    private fun loadExistingOrder(allItems: List<Item>) {
        val uid = auth.currentUser?.uid ?: return
        isOrderLoaded = true
        ordersDatabase.child(uid).orderByChild("customerId").equalTo(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val pendingOrder = snapshot.children.mapNotNull { WebOrder.fromSnapshot(it) }
                    .filter { it.status == "Pending" }
                    .maxByOrNull { it.date }

                pendingOrder?.let { order ->
                    order.items.forEach { billItem ->
                        val item = allItems.find { it.name == billItem.name && it.uom == billItem.uom }
                        if (item != null) {
                            if (item.id !in _itemSequence) {
                                _itemSequence.add(item.id)
                            }
                            cart[item.id] = billItem.getQtyString()
                            val bdStrings = billItem.getBreakdownStrings()
                            if (bdStrings != null) {
                                val itemBreakdown = breakdowns.getOrPut(item.id) { mutableStateMapOf() }
                                bdStrings.forEach { (k, v) -> itemBreakdown[k] = v }
                            }
                        }
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun updateCart(itemId: String, qty: String) {
        if (qty.isEmpty() || qty == "0") {
            cart.remove(itemId)
            breakdowns.remove(itemId)
            _itemSequence.remove(itemId)
        } else {
            if (itemId !in cart) {
                _itemSequence.add(itemId)
            }
            cart[itemId] = qty
        }
    }

    fun updateBreakdown(itemId: String, variant: String, qty: String) {
        val itemBreakdown = breakdowns.getOrPut(itemId) { mutableStateMapOf() }
        if (qty.isEmpty() || qty == "0") {
            itemBreakdown.remove(variant)
        } else {
            itemBreakdown[variant] = qty
        }
        
        val total = itemBreakdown.values.sumOf { it.toDoubleOrNull() ?: 0.0 }
        if (total > 0) {
            if (itemId !in cart) {
                _itemSequence.add(itemId)
            }
            cart[itemId] = if (total % 1.0 == 0.0) total.toLong().toString() else total.toString()
        } else {
            cart.remove(itemId)
            breakdowns.remove(itemId)
            _itemSequence.remove(itemId)
        }
    }

    fun addVariableGlobally(itemId: String, variableName: String) {
        val trimmedVariant = variableName.trim()
        if (trimmedVariant.isEmpty()) return

        itemDatabase.child(itemId).child("details").runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                val currentDetails = mutableData.children.mapNotNull { it.getValue(String::class.java) }.toMutableList()
                if (!currentDetails.contains(trimmedVariant)) {
                    currentDetails.add(trimmedVariant)
                    mutableData.value = currentDetails.distinct().sortedWith(AlphaNumericComparator)
                    return Transaction.success(mutableData)
                }
                return Transaction.success(mutableData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) Log.e("CustomerCatalogVM", "Variant addition failed", error.toException())
            }
        })
    }

    fun deleteVariableGlobally(itemId: String, variableName: String) {
        itemDatabase.child(itemId).child("details").runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                val currentDetails = mutableData.children.mapNotNull { it.getValue(String::class.java) }.toMutableList()
                if (currentDetails.contains(variableName)) {
                    currentDetails.remove(variableName)
                    mutableData.value = currentDetails.sortedWith(AlphaNumericComparator)
                    return Transaction.success(mutableData)
                }
                return Transaction.success(mutableData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) Log.e("CustomerCatalogVM", "Variant deletion failed", error.toException())
            }
        })
        
        // Local state cleanup
        if (breakdowns.containsKey(itemId)) {
            val itemBreakdown = breakdowns[itemId]
            itemBreakdown?.remove(variableName)
            val total = itemBreakdown?.values?.sumOf { it.toDoubleOrNull() ?: 0.0 } ?: 0.0
            if (total > 0) {
                cart[itemId] = if (total % 1.0 == 0.0) total.toLong().toString() else total.toString()
            } else {
                cart.remove(itemId)
                breakdowns.remove(itemId)
                _itemSequence.remove(itemId)
            }
        }
    }

    fun placeOrder(onComplete: () -> Unit) {
        val uid = auth.currentUser?.uid ?: return
        if (cart.isEmpty()) return

        isSubmitting.value = true
        
        // Use _itemSequence to maintain the order of selection
        val billItems = _itemSequence.mapNotNull { itemId ->
            val qty = cart[itemId] ?: return@mapNotNull null
            val item = _items.value.find { it.id == itemId } ?: return@mapNotNull null
            val rateData = _itemRates.value[item.id] ?: _itemRates.value["${item.name}-${item.uom}"]
            val rate = rateData?.get("rate")?.toString() ?: item.basePrice.toString()
            BillItem(
                itemId = item.id,
                name = item.name,
                qty = qty,
                rate = rate,
                uom = item.uom,
                basePrice = item.basePrice.toString(),
                breakdown = if (breakdowns.containsKey(itemId)) breakdowns[itemId]?.toMap() else null
            )
        }

        val order = WebOrder(
            id = "",
            customerId = customerId,
            customerName = customerName.value,
            customerType = customerType,
            date = System.currentTimeMillis(),
            items = billItems,
            status = "Pending"
        )

        ordersDatabase.child(uid).orderByChild("customerId").equalTo(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val pendingOrderSnapshot = snapshot.children.find { it.child("status").getValue(String::class.java) == "Pending" }
                
                if (pendingOrderSnapshot != null) {
                    ordersDatabase.child(uid).child(pendingOrderSnapshot.key!!).setValue(order).addOnCompleteListener {
                        isSubmitting.value = false
                        if (it.isSuccessful) onComplete()
                    }
                } else {
                    ordersDatabase.child(uid).push().setValue(order).addOnCompleteListener {
                        isSubmitting.value = false
                        if (it.isSuccessful) onComplete()
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {
                isSubmitting.value = false
            }
        })
    }

    suspend fun getSalesHistoryForItem(itemName: String, itemUom: String, itemId: String): List<ItemSale> = withContext(Dispatchers.IO) {
        val historyMap = mutableMapOf<String, ItemSale>()
        val categories = listOf("STAFF", "LOCALS", "HOME") + DataRepository.customScreens.value
        val sanitizedNameKey = sanitizeKey("$itemName-$itemUom")
        val sanitizedIdKey = sanitizeKey(itemId)

        val oneYearAgo = System.currentTimeMillis() - (365L * 24 * 60 * 60 * 1000L)

        // PERMANENT & INSTANT HISTORY: Scan strictly from itemRates
        for (category in categories) {
            try {
                val type = when(category) {
                    "STAFF" -> "customers_staff"
                    "LOCALS" -> "customers_locals"
                    "HOME" -> "customers_home"
                    else -> "custom_customers/$category"
                }
                val snap = FirebaseDatabase.getInstance().getReference(type).get().await()
                
                for (cSnap in snap.children) {
                    val name = cSnap.child("name").getValue(String::class.java) ?: continue
                    val cId = cSnap.key ?: ""
                    
                    val ratesSnap = cSnap.child("itemRates")
                    val rateSnap = ratesSnap.child(sanitizedIdKey).takeIf { it.exists() } ?: ratesSnap.child(sanitizedNameKey)
                    
                    if (rateSnap != null && rateSnap.exists()) {
                        val rate = if (rateSnap.hasChild("rate")) rateSnap.child("rate").value.toString().toDoubleOrNull() ?: 0.0 
                                  else rateSnap.value.toString().toDoubleOrNull() ?: 0.0
                        
                        val date = if (rateSnap.hasChild("date")) (rateSnap.child("date").value as? Number)?.toLong() ?: 0L else 0L
                        val isBill = rateSnap.child("isBill").getValue(Boolean::class.java) ?: false
                        var qty = if (rateSnap.hasChild("qty")) rateSnap.child("qty").value?.toString() ?: "" else ""
                        
                        val historyList = mutableListOf<SaleHistoryEntry>()
                        val expiredKeys = mutableListOf<String>()

                        if (rateSnap.hasChild("history")) {
                            for (hSnap in rateSnap.child("history").children) {
                                val hDate = (hSnap.child("date").value as? Number)?.toLong() ?: 0L
                                if (hDate < oneYearAgo) {
                                    hSnap.key?.let { expiredKeys.add(it) }
                                } else {
                                    val hQty = hSnap.child("qty").value?.toString() ?: ""
                                    val hRate = (hSnap.child("rate").value as? Number)?.toDouble()
                                        ?: hSnap.child("rate").value?.toString()?.toDoubleOrNull() ?: 0.0
                                    if (hRate > 0.0) {
                                        historyList.add(SaleHistoryEntry(date = hDate, qty = hQty, rate = hRate))
                                    }
                                }
                            }
                        }

                        if (expiredKeys.isNotEmpty()) {
                            val updates = expiredKeys.associate { "$it" to null }
                            rateSnap.ref.child("history").updateChildren(updates)
                        }

                        val transSnap = cSnap.child("transactions")
                        if (transSnap.exists()) {
                            for (tSnap in transSnap.children) {
                                val tDate = (tSnap.child("date").value as? Number)?.toLong() ?: 0L
                                val tType = tSnap.child("type").getValue(String::class.java) ?: ""
                                if (tType == "GAVE" && tDate >= oneYearAgo) {
                                    val itemsSnap = tSnap.child("items")
                                    for (itemSnap in itemsSnap.children) {
                                        val tItemId = itemSnap.child("itemId").getValue(String::class.java) ?: ""
                                        val tName = itemSnap.child("name").getValue(String::class.java) ?: ""
                                        val tUom = itemSnap.child("uom").getValue(String::class.java) ?: ""
                                        val match = (itemId.isNotBlank() && tItemId == itemId) ||
                                                    (tName == itemName && tUom == itemUom)
                                        if (match) {
                                            val tRate = itemSnap.child("rate").value?.toString()?.toDoubleOrNull() ?: 0.0
                                            val tQty = itemSnap.child("qty").value?.toString() ?: ""
                                            if (tRate > 0.0) {
                                                historyList.add(SaleHistoryEntry(date = tDate, qty = tQty, rate = tRate))
                                                val entryKey = "${tDate}_${tRate.toLong()}_${tQty.filter { it.isLetterOrDigit() }}"
                                                rateSnap.ref.child("history").child(entryKey).setValue(mapOf(
                                                    "date" to tDate,
                                                    "qty" to tQty,
                                                    "rate" to tRate
                                                ))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (historyList.isEmpty() && date >= oneYearAgo && rate > 0.0) {
                            historyList.add(SaleHistoryEntry(date = date, qty = qty, rate = rate))
                        }

                        val sortedHistory = historyList
                            .filter { it.date >= oneYearAgo }
                            .distinctBy { "${it.date}_${it.rate}_${it.qty}" }
                            .sortedByDescending { it.date }

                        if (qty.isBlank() && sortedHistory.isNotEmpty()) {
                            qty = sortedHistory.first().qty
                        }

                        if (rate > 0.0) {
                            historyMap["$name-$cId"] = ItemSale(
                                customerName = name,
                                rate = rate,
                                date = date,
                                isBill = isBill,
                                qty = qty,
                                history = sortedHistory
                            )
                        }
                    }
                }
            } catch (e: Exception) {}
        }
        return@withContext historyMap.values.sortedByDescending { it.date }
    }
}

class CustomerCatalogViewModelFactory(private val customerId: String, private val customerType: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(CustomerCatalogViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return CustomerCatalogViewModel(customerId, customerType) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
