package com.example.gstcalculator

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun Avatar(name: String, hasDraft: Boolean = false) {
    val backgroundColor = if (hasDraft) Color(0xFFD50000) else Color(0xFFE0E0E0)
    val textColor = if (hasDraft) Color.White else Color.Black
    Surface(
        modifier = Modifier.size(36.dp),
        shape = CircleShape,
        color = backgroundColor
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = getInitials(name),
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

fun getInitials(name: String): String {
    if (name.isBlank()) {
        return ""
    }
    return name.split(' ')
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
}
