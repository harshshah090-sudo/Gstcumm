package com.example.gstcalculator

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Receipt
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(
    navController: NavController,
    uomViewModel: UomViewModel = viewModel(),
    itemViewModel: ItemViewModel = viewModel(key = "ItemViewModel"),
    showAddItemDialog: Boolean,
    onShowAddItemDialogChange: (Boolean) -> Unit,
    initialCustomerType: String?
) {
    val context = LocalContext.current
    val userPreferences = remember { UserPreferences(context) }
    val userRole = userPreferences.getLoginState()
    val isAdmin = userRole == "admin"
    
    // Start with default screen
    var currentScreenName by remember { mutableStateOf("Shah Stores") }
    
    // Security: If staff, force "Shah Stores" and ignore any initial custom type
    val effectiveCustomerType = if (!isAdmin && initialCustomerType != "HOME" && initialCustomerType != "LOCALS") {
        null
    } else {
        initialCustomerType
    }

    val isDefaultScreen = currentScreenName == "Shah Stores"
    val pageCount = if (isDefaultScreen) 3 else 2
    
    val initialPage = when (effectiveCustomerType) {
        "LOCALS" -> 0
        "HOME" -> 1
        else -> if (isDefaultScreen) 1 else 0
    }
    
    val pagerState = rememberPagerState(initialPage = initialPage, pageCount = { pageCount })
    val scope = rememberCoroutineScope()
    
    // ViewModels for the default screens
    val homeViewModel: HomeViewModel = viewModel(key = "HOME", factory = HomeViewModelFactory(context, "HOME"))
    val localsViewModel: HomeViewModel = viewModel(key = "LOCALS", factory = HomeViewModelFactory(context, "LOCALS"))
    
    // ViewModel for custom screen (Only active if isAdmin and currentScreen is custom)
    val customViewModel: HomeViewModel? = if (isAdmin && !isDefaultScreen) {
        viewModel(
            key = "Home_$currentScreenName", 
            factory = HomeViewModelFactory(context, currentScreenName)
        )
    } else null

    val customItemViewModel: ItemViewModel? = if (isAdmin && !isDefaultScreen) {
        viewModel(
            key = "Item_$currentScreenName",
            factory = ItemViewModelFactory(currentScreenName)
        )
    } else null

    LaunchedEffect(effectiveCustomerType) {
        if (isDefaultScreen) {
            effectiveCustomerType?.let {
                val page = if (it == "LOCALS") 0 else 1
                pagerState.scrollToPage(page)
            }
        }
    }

    if (homeViewModel.showAddCustomerDialog.value) {
        AddCustomerDialog(viewModel = homeViewModel)
    }

    if (localsViewModel.showAddCustomerDialog.value) {
        AddCustomerDialog(viewModel = localsViewModel)
    }
    
    customViewModel?.let {
        if (it.showAddCustomerDialog.value) {
            AddCustomerDialog(viewModel = it)
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = true
        ) { page ->
            if (isDefaultScreen) {
                when (page) {
                    0 -> HomeScreen(
                        navController = navController,
                        viewModel = localsViewModel,
                        isLocalsScreen = true,
                        customerType = "LOCALS",
                        currentScreenName = currentScreenName,
                        onScreenChange = { if (isAdmin) currentScreenName = it }
                    )
                    1 -> HomeScreen(
                        navController = navController,
                        viewModel = homeViewModel,
                        isLocalsScreen = false,
                        customerType = "HOME",
                        currentScreenName = currentScreenName,
                        onScreenChange = { if (isAdmin) currentScreenName = it }
                    )
                    2 -> ItemScreen(
                        showAddItemDialog = showAddItemDialog,
                        onDismiss = { onShowAddItemDialogChange(false) },
                        uomViewModel = uomViewModel,
                        itemViewModel = itemViewModel
                    )
                }
            } else if (isAdmin && customViewModel != null && customItemViewModel != null) {
                when (page) {
                    0 -> HomeScreen(
                        navController = navController,
                        viewModel = customViewModel,
                        isLocalsScreen = false,
                        customerType = currentScreenName,
                        currentScreenName = currentScreenName,
                        onScreenChange = { currentScreenName = it }
                    )
                    1 -> ItemScreen(
                        showAddItemDialog = showAddItemDialog,
                        onDismiss = { onShowAddItemDialogChange(false) },
                        uomViewModel = uomViewModel,
                        itemViewModel = customItemViewModel
                    )
                }
            }
        }

        // Bottom UI elements
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 16.dp)
                .fillMaxWidth(),
        ) {
            // Navigation Pill
            Card(
                shape = RoundedCornerShape(50),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF5F5F5)),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(32.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isDefaultScreen) {
                        Text(
                            text = "L",
                            color = if (pagerState.currentPage == 0) Color(0xFF1976D2) else Color.Gray,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { scope.launch { pagerState.animateScrollToPage(0) } }
                        )
                        Icon(
                            imageVector = Icons.Outlined.People,
                            contentDescription = "Customers",
                            tint = if (pagerState.currentPage == 1) Color(0xFF1976D2) else Color.Gray,
                            modifier = Modifier.clickable { scope.launch { pagerState.animateScrollToPage(1) } }
                        )
                        Icon(
                            imageVector = Icons.Outlined.Receipt,
                            contentDescription = "Items",
                            tint = if (pagerState.currentPage == 2) Color(0xFF1976D2) else Color.Gray,
                            modifier = Modifier.clickable { scope.launch { pagerState.animateScrollToPage(2) } }
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Outlined.People,
                            contentDescription = "Customers",
                            tint = if (pagerState.currentPage == 0) Color(0xFF1976D2) else Color.Gray,
                            modifier = Modifier.clickable { scope.launch { pagerState.animateScrollToPage(0) } }
                        )
                        Icon(
                            imageVector = Icons.Outlined.Receipt,
                            contentDescription = "Items",
                            tint = if (pagerState.currentPage == 1) Color(0xFF1976D2) else Color.Gray,
                            modifier = Modifier.clickable { scope.launch { pagerState.animateScrollToPage(1) } }
                        )
                    }
                }
            }

            // Add Customer FAB
            FloatingActionButton(
                onClick = {
                    if (isDefaultScreen) {
                        when (pagerState.currentPage) {
                            0 -> localsViewModel.showAddCustomerDialog.value = true
                            1 -> homeViewModel.showAddCustomerDialog.value = true
                            2 -> onShowAddItemDialogChange(true)
                        }
                    } else if (isAdmin && customViewModel != null) {
                        when (pagerState.currentPage) {
                            0 -> customViewModel.showAddCustomerDialog.value = true
                            1 -> onShowAddItemDialogChange(true)
                        }
                    }
                },
                shape = CircleShape,
                containerColor = Color(0xFF1976D2),
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 24.dp)
                    .size(40.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
            }
        }
    }
}
