package com.example.gstcalculator

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TransactionRecycleBinScreen(navController: NavController, customerId: String, customerType: String) {
    val viewModel: TransactionRecycleBinViewModel = viewModel(factory = TransactionRecycleBinViewModelFactory(customerId))
    val deletedTransactions by viewModel.deletedTransactions

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Recycle Bin", color = Color.White, fontWeight = FontWeight.Bold)
                        Text(
                            text = "All the transaction will delete parmenently after 60 days.",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 10.sp,
                            lineHeight = 12.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2)),
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                }
            )
        }
    ) { paddingValues ->
        if (deletedTransactions.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(paddingValues), contentAlignment = Alignment.Center) {
                Text("No deleted transactions", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(Color(0xFFF5F5F5))
            ) {
                items(deletedTransactions, key = { it.transaction.id ?: it.hashCode() }) { item ->
                    DeletedTransactionItem(
                        modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                        deletedTransaction = item, 
                        viewModel = viewModel
                    ) {
                        viewModel.restoreTransaction(item, customerType) {
                            // Transaction restored
                        }
                    }
                    HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color.LightGray.copy(alpha = 0.5f))
                }
            }
        }
    }
}

@Composable
fun DeletedTransactionItem(
    modifier: Modifier = Modifier,
    deletedTransaction: DeletedTransaction, 
    viewModel: TransactionRecycleBinViewModel,
    onRestore: () -> Unit
) {
    val transaction = deletedTransaction.transaction
    val typeColor = if (transaction.type == "GAVE") Color(0xFFD50000) else Color(0xFF008800)
    val context = LocalContext.current
    
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(8.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = transaction.type ?: "",
                        color = typeColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "₹${transaction.amount}",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                }
                
                if (!transaction.note.isNullOrBlank()) {
                    Text(text = transaction.note!!, fontSize = 12.sp, color = Color.Black)
                }
                
                Spacer(modifier = Modifier.height(4.dp))
                
                Text(
                    text = "Transaction Date: ${SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(transaction.date ?: 0))}",
                    fontSize = 10.sp,
                    color = Color.Gray
                )
                Text(
                    text = "Deleted on: ${SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(deletedTransaction.deletionDate))}",
                    fontSize = 10.sp,
                    color = Color.Red.copy(alpha = 0.7f)
                )
            }
            
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (transaction.billImageUrl != null) {
                    IconButton(onClick = { viewModel.openPdf(transaction, context) }) {
                        Icon(
                            imageVector = Icons.Default.PictureAsPdf,
                            contentDescription = "PDF",
                            tint = Color.Red,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
                IconButton(onClick = onRestore) {
                    Icon(
                        imageVector = Icons.Default.Restore,
                        contentDescription = "Restore",
                        tint = Color(0xFF1976D2),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
    }
}
