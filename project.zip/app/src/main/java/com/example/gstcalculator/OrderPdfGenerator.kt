package com.example.gstcalculator

import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.colors.DeviceRgb
import com.itextpdf.kernel.events.PdfDocumentEvent
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.layout.Canvas
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Div
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.property.TextAlignment
import com.itextpdf.layout.property.UnitValue
import java.io.ByteArrayOutputStream

object OrderPdfGenerator {

    private val APP_BLUE = DeviceRgb(25, 118, 210)

    fun createOrderPdf(customerName: String, items: List<BillItem>): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        
        // Define dimensions for A5
        val pageSize = PageSize.A5
        val leftMargin = 20f
        val rightMargin = 20f
        val topMargin = 5f
        val bottomMargin = 20f
        val headerHeight = 12f
        val columnGap = 15f
        
        // Event handler to draw the Header and Vertical Divider on every page
        pdf.addEventHandler(PdfDocumentEvent.END_PAGE) { event ->
            val docEvent = event as PdfDocumentEvent
            val page = docEvent.page
            val canvas = PdfCanvas(page)
            val centerX = pageSize.width / 2
            
            // 1. Draw Header Text - Positioned at the very top
            val headerY = pageSize.height - topMargin - 8f
            val canvasLayout = Canvas(canvas, pdf, pageSize)
            canvasLayout.showTextAligned(
                Paragraph(customerName)
                    .setFontSize(16f)
                    .setBold()
                    .setFontColor(APP_BLUE)
                    .setMargin(0f),
                centerX, headerY, TextAlignment.CENTER
            )
            
            // 2. Draw Vertical Divider Line
            canvas.setStrokeColor(ColorConstants.GRAY)
            canvas.setLineWidth(0.5f)
            // Line from bottom margin to just below header area
            canvas.moveTo(centerX.toDouble(), bottomMargin.toDouble())
            canvas.lineTo(centerX.toDouble(), (pageSize.height - topMargin - headerHeight).toDouble())
            canvas.stroke()
            
            canvasLayout.close()
        }

        val document = Document(pdf, pageSize)
        document.setMargins(topMargin + headerHeight, rightMargin, bottomMargin, leftMargin)

        // Use a Table with 2 columns.
        val table = Table(UnitValue.createPointArray(floatArrayOf((pageSize.width - leftMargin - rightMargin - columnGap) / 2, (pageSize.width - leftMargin - rightMargin - columnGap) / 2)))
        table.setWidth(UnitValue.createPercentValue(100f))
        table.setFixedLayout()
        table.setMarginTop(0f)
        
        val leftColumnCell = Cell().setBorder(Border.NO_BORDER).setPaddingRight(columnGap / 2).setPaddingTop(0f)
        val rightColumnCell = Cell().setBorder(Border.NO_BORDER).setPaddingLeft(columnGap / 2).setPaddingTop(0f)
        
        items.forEachIndexed { index, item ->
            val itemDiv = Div().setKeepTogether(true).setMarginBottom(5f)
            
            val qtyStr = item.getQtyString()
            val mainText = "${item.name} - $qtyStr ${item.uom}"
            itemDiv.add(Paragraph(mainText)
                .setFontSize(12f)
                .setBold()
                .setMarginBottom(0f)
                .setMultipliedLeading(1f))
            
            val breakdown = item.getBreakdownStrings()
            if (!breakdown.isNullOrEmpty()) {
                val variantStrings = breakdown.toSortedMap().entries.map { "${it.key}/${it.value}" }
                val variantText = variantStrings.joinToString(", ")
                itemDiv.add(Paragraph(variantText)
                    .setFontSize(11f)
                    .setFontColor(ColorConstants.DARK_GRAY)
                    .setItalic()
                    .setMarginLeft(5f)
                    .setMarginTop(0f)
                    .setMultipliedLeading(1f)
                )
            }

            if (index % 2 == 0) {
                leftColumnCell.add(itemDiv)
            } else {
                rightColumnCell.add(itemDiv)
            }
        }

        table.addCell(leftColumnCell)
        table.addCell(rightColumnCell)

        document.add(table)
        document.close()
        return outputStream.toByteArray()
    }

    fun createSummaryPdf(orders: List<WebOrder>, selectedItemNames: Set<String>): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        
        val pageSize = PageSize.A5
        val leftMargin = 20f
        val rightMargin = 20f
        val topMargin = 5f
        val bottomMargin = 20f
        val headerHeight = 12f
        val columnGap = 15f
        
        pdf.addEventHandler(PdfDocumentEvent.END_PAGE) { event ->
            val docEvent = event as PdfDocumentEvent
            val page = docEvent.page
            val canvas = PdfCanvas(page)
            val centerX = pageSize.width / 2
            
            val headerY = pageSize.height - topMargin - 8f
            val canvasLayout = Canvas(canvas, pdf, pageSize)
            canvasLayout.showTextAligned(
                Paragraph("Orders Summary")
                    .setFontSize(16f)
                    .setBold()
                    .setFontColor(APP_BLUE)
                    .setMargin(0f),
                centerX, headerY, TextAlignment.CENTER
            )
            
            canvas.setStrokeColor(ColorConstants.GRAY)
            canvas.setLineWidth(0.5f)
            canvas.moveTo(centerX.toDouble(), bottomMargin.toDouble())
            canvas.lineTo(centerX.toDouble(), (pageSize.height - topMargin - headerHeight).toDouble())
            canvas.stroke()
            
            canvasLayout.close()
        }

        val document = Document(pdf, pageSize)
        document.setMargins(topMargin + headerHeight, rightMargin, bottomMargin, leftMargin)

        val table = Table(UnitValue.createPointArray(floatArrayOf((pageSize.width - leftMargin - rightMargin - columnGap) / 2, (pageSize.width - leftMargin - rightMargin - columnGap) / 2)))
        table.setWidth(UnitValue.createPercentValue(100f))
        table.setFixedLayout()
        table.setMarginTop(0f)
        
        val leftColumnCell = Cell().setBorder(Border.NO_BORDER).setPaddingRight(columnGap / 2).setPaddingTop(0f)
        val rightColumnCell = Cell().setBorder(Border.NO_BORDER).setPaddingLeft(columnGap / 2).setPaddingTop(0f)
        
        var cellIndex = 0

        // Group by Item Name
        val itemGroups = mutableMapOf<String, MutableList<Pair<String, BillItem>>>()
        orders.forEach { order ->
            order.items.forEach { item ->
                if (item.name in selectedItemNames) {
                    itemGroups.getOrPut(item.name) { mutableListOf() }.add(order.customerName to item)
                }
            }
        }

        val sortedItemNames = selectedItemNames.sorted()
        sortedItemNames.forEach { itemName ->
            val entries = itemGroups[itemName] ?: return@forEach
            
            // Calculate total quantity for this item
            val totalQty = entries.sumOf { it.second.getQtyDouble() }
            val uom = entries.first().second.uom
            val totalQtyStr = if (totalQty % 1.0 == 0.0) totalQty.toLong().toString() else totalQty.toString()

            val itemDiv = Div().setKeepTogether(true).setMarginBottom(10f)
            
            // Item Header: "Name - TotalQty UOM"
            itemDiv.add(Paragraph("$itemName - $totalQtyStr $uom")
                .setFontSize(13f)
                .setBold()
                .setFontColor(APP_BLUE)
                .setMarginBottom(4f)
                .setMultipliedLeading(1f))
            
            // List each customer's quantity and variants for this item
            entries.forEach { (customerName, item) ->
                val qtyStr = item.getQtyString()
                val detailText = "$customerName: $qtyStr $uom"
                itemDiv.add(Paragraph(detailText)
                    .setFontSize(11f)
                    .setBold()
                    .setMarginBottom(0f)
                    .setMultipliedLeading(1f))
                
                val breakdown = item.getBreakdownStrings()
                if (!breakdown.isNullOrEmpty()) {
                    val variantStrings = breakdown.entries.map { "${it.key}/${it.value}" }
                    val variantText = variantStrings.joinToString(", ")
                    itemDiv.add(Paragraph(variantText)
                        .setFontSize(10f)
                        .setFontColor(ColorConstants.DARK_GRAY)
                        .setItalic()
                        .setMarginLeft(10f)
                        .setMarginTop(0f)
                        .setMultipliedLeading(1f)
                    )
                }
            }

            if (cellIndex % 2 == 0) {
                leftColumnCell.add(itemDiv)
            } else {
                rightColumnCell.add(itemDiv)
            }
            cellIndex++
        }

        table.addCell(leftColumnCell)
        table.addCell(rightColumnCell)

        document.add(table)
        document.close()
        return outputStream.toByteArray()
    }
}
