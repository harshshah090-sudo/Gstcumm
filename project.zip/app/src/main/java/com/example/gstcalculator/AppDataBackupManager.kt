package com.example.gstcalculator

import android.content.Context
import android.net.Uri
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.gson.Gson
import com.google.gson.JsonParseException
import java.io.BufferedReader
import java.io.InputStreamReader

class AppDataBackupManager(private val context: Context) {

    private val database = FirebaseDatabase.getInstance().reference

    fun backup(uri: Uri, onSuccess: () -> Unit, onError: (String) -> Unit) {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    val data = snapshot.value
                    if (data == null) {
                        onError("No data to backup.")
                        return
                    }
                    val jsonString = Gson().toJson(data)
                    try {
                        context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                            outputStream.write(jsonString.toByteArray())
                        }
                        onSuccess()
                    } catch (e: Exception) {
                        onError("File system error: ${e.message}")
                    }
                } catch (e: Exception) {
                    onError("An error occurred during backup.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onError("Firebase error: ${error.message}")
            }
        })
    }

    fun restore(uri: Uri, onSuccess: () -> Unit, onError: (String) -> Unit) {
        try {
            context.contentResolver.openInputStream(uri)?.use { inputStream ->
                val reader = BufferedReader(InputStreamReader(inputStream))

                // Ensure the root of the backup is a Map
                val data = Gson().fromJson(reader, Map::class.java) as? Map<String, Any>
                    ?: run {
                        onError("Restore failed: The backup file is not in the correct format.")
                        return
                    }

                // We filter out system/protected nodes to avoid Permission Denied errors
                // and to prevent overwriting critical app configuration or user roles.
                val protectedNodes = setOf("roles", "app_config", "users")
                val nodesToRestore = data.filterKeys { it !in protectedNodes }

                if (nodesToRestore.isEmpty()) {
                    onError("Restore failed: No restorable data found in the backup file.")
                    return
                }

                var completedCount = 0
                var successCount = 0
                val totalNodes = nodesToRestore.size

                nodesToRestore.forEach { (key, value) ->
                    // We update each top-level node individually. 
                    // This bypasses the need for root-level write permissions 
                    // and allows partial success if some nodes are restricted.
                    database.child(key).setValue(value).addOnCompleteListener { task ->
                        completedCount++
                        if (task.isSuccessful) {
                            successCount++
                        }

                        if (completedCount == totalNodes) {
                            if (successCount == totalNodes) {
                                onSuccess()
                            } else if (successCount > 0) {
                                // Partial success: successfully restored what we have permission for.
                                onSuccess()
                            } else {
                                onError("Restore failed: Permission denied. Please ensure you have admin rights.")
                            }
                        }
                    }
                }
            }
        } catch (e: JsonParseException) {
            onError("Restore failed: The selected file is not a valid backup file or is corrupted.")
        } catch (e: Exception) {
            onError("File system error: ${e.message}")
        }
    }
}
