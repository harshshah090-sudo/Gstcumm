package com.example.gstcalculator

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun PaymentRemindersScreen(navController: NavController) {
    val viewModel: PaymentRemindersViewModel = viewModel()
    val reminders by viewModel.reminders.collectAsState()
    val horizontalScrollState = rememberScrollState()
    val context = LocalContext.current
    
    var showStatusDialog by remember { mutableStateOf(false) }
    var selectedReminder by remember { mutableStateOf<PaymentReminder?>(null) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    if (showStatusDialog && selectedReminder != null) {
        StatusLetterDialog(
            onDismiss = { showStatusDialog = false },
            onSelect = { letter ->
                viewModel.updateStatusLetter(selectedReminder!!, letter)
                showStatusDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Payment Reminders", color = Color.White) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2))
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color(0xFFF5F5F5))
                .padding(top = 4.dp)
                .horizontalScroll(horizontalScrollState)
        ) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                // Header Row (Sticky)
                stickyHeader {
                    Row(
                        modifier = Modifier
                            .background(Color(0xFF1976D2))
                            .padding(8.dp)
                            .zIndex(1f), // Keep header on top during bounce
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Date", modifier = Modifier.width(100.dp), fontWeight = FontWeight.Bold, color = Color.White)
                        
                        Box(modifier = Modifier.width(40.dp), contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Call, 
                                contentDescription = "Status", 
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        
                        Text("Customer", modifier = Modifier.width(150.dp), fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Amount", modifier = Modifier.width(100.dp), fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Time", modifier = Modifier.width(100.dp), fontWeight = FontWeight.Bold, color = Color.White)
                        Text("Call", modifier = Modifier.width(50.dp), fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }

                // Data Rows
                items(reminders, key = { it.customerId }) { reminder ->
                    val backgroundColor = when (reminder.statusLetter) {
                        "H" -> Color(0xFFA5D6A7)
                        "S" -> Color(0xFFEF9A9A)
                        "K" -> Color(0xFF90CAF9)
                        else -> Color.Transparent
                    }

                    Row(
                        modifier = Modifier
                            .animateItemPlacement(animationSpec = springSpec)
                            .background(backgroundColor)
                            .combinedClickable(
                                onClick = { navController.navigate("transaction/${reminder.customerId}/${reminder.customerType}") },
                                onLongClick = {
                                    selectedReminder = reminder
                                    showStatusDialog = true
                                }
                            )
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(formatDate(reminder.transactionDate), modifier = Modifier.width(100.dp))
                        
                        Text(
                            text = reminder.statusLetter,
                            modifier = Modifier.width(40.dp),
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = Color.DarkGray
                        )

                        Text(
                            text = reminder.customerName,
                            modifier = Modifier.width(150.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(formatAmount(reminder.runningBalance), modifier = Modifier.width(100.dp))
                        Text(reminder.daysPassed, modifier = Modifier.width(100.dp))
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Call Customer",
                            modifier = Modifier
                                .width(50.dp)
                                .clickable { 
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${reminder.phoneNumber}"))
                                    context.startActivity(intent)
                                }
                        )
                    }
                    HorizontalDivider(color = Color.LightGray)
                }
            }
        }
    }
}

@Composable
fun StatusLetterDialog(
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Select Status", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    StatusButton("H", Color(0xFF4CAF50)) { onSelect("H") }
                    StatusButton("S", Color(0xFFF44336)) { onSelect("S") }
                    StatusButton("K", Color(0xFF2196F3)) { onSelect("K") }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { onSelect("") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Clear Status")
                }
            }
        }
    }
}

@Composable
fun StatusButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = color),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.width(60.dp)
    ) {
        Text(label, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

private fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yy", Locale.getDefault())
    return sdf.format(Date(timestamp))
}
