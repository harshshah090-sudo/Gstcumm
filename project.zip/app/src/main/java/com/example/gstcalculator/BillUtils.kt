package com.example.gstcalculator

import android.content.Context
import android.content.Intent
import android.net.Uri

fun openBill(context: Context, billUrl: String) {
    val billUri = Uri.parse(billUrl)
    val intent = Intent(Intent.ACTION_VIEW)

    if (billUri.scheme == "https" || billUri.scheme == "http") {
        intent.data = billUri
    } else {
        intent.setDataAndType(billUri, "application/pdf")
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        // Could show a toast message that no app can open the PDF
    }
}
