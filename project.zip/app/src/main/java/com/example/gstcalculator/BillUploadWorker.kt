package com.example.gstcalculator

import android.content.Context
import android.net.Uri
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.tasks.await
import java.io.File

class BillUploadWorker(appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val customerId = inputData.getString("customerId") ?: return Result.failure()
        val transactionId = inputData.getString("transactionId") ?: return Result.failure()
        val customerType = inputData.getString("customerType") ?: "HOME"
        val pdfPath = inputData.getString("pdfPath") ?: return Result.failure()

        val dbPath = when (customerType) {
            "STAFF" -> "customers_staff"
            "LOCALS" -> "customers_locals"
            else -> "customers_home"
        }

        val database = FirebaseDatabase.getInstance().getReference(dbPath)
        val storageRef = FirebaseStorage.getInstance().reference.child("bills/${transactionId}.pdf")

        return try {
            val fileUri = Uri.fromFile(File(pdfPath))
            val fileSize = File(pdfPath).length()
            val uploadTask = storageRef.putFile(fileUri)
            val downloadUrl = uploadTask.continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let { throw it }
                }
                storageRef.downloadUrl
            }.await()

            // Update storage usage counter
            StorageTracker.incrementUsage(fileSize)

            val updates = mutableMapOf<String, Any?>(
                "billImageUrl" to downloadUrl.toString(),
                "syncing" to false,
                "syncFailed" to false
            )

            // Update transaction
            database.child(customerId).child("transactions").child(transactionId).updateChildren(updates).await()

            // Check if there are other syncing transactions for this customer
            val transactionsSnapshot = database.child(customerId).child("transactions").get().await()
            var stillSyncing = false
            for (snap in transactionsSnapshot.children) {
                if (snap.key != transactionId && snap.child("syncing").getValue(Boolean::class.java) == true) {
                    stillSyncing = true
                    break
                }
            }

            // Update customer syncing state
            database.child(customerId).child("syncing").setValue(stillSyncing).await()

            Result.success()
        } catch (e: Exception) {
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                // On permanent failure, set syncFailed flag
                try {
                    val updates = mapOf(
                        "syncing" to false,
                        "syncFailed" to true
                    )
                    database.child(customerId).child("transactions").child(transactionId).updateChildren(updates).await()
                    
                    val transactionsSnapshot = database.child(customerId).child("transactions").get().await()
                    val stillSyncing = transactionsSnapshot.children.any { it.key != transactionId && it.child("syncing").getValue(Boolean::class.java) == true }
                    database.child(customerId).child("syncing").setValue(stillSyncing).await()
                } catch (inner: Exception) {}
                Result.failure()
            }
        }
    }
}
