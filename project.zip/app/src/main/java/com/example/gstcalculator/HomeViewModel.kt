package com.example.gstcalculator

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import androidx.compose.runtime.derivedStateOf
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.TimeUnit
import android.content.Context
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import kotlinx.coroutines.tasks.await

// Properties are 'var' with default values to allow Firebase to deserialize the data.
data class Customer(
    var id: String? = null,
    var name: String = "",
    var phoneNumber: Any? = null,
    var initialBalance: Double? = 0.0,
    var lastUpdated: Long? = null,
    var creationDate: Long? = null,
    var transactionCount: Int = 0,
    var hasDraft: Boolean = false,
    var hasSyncError: Boolean = false,
    var paymentReminderDays: Int? = null,
    var customerType: String = "HOME",
    var syncing: Boolean = false
)

fun cleanPhoneNumber(phone: String?): String {
    if (phone == null) return ""
    // Remove all non-numeric characters (including +, spaces, hyphens)
    val numeric = phone.replace(Regex("[^0-9]"), "")
    
    return when {
        numeric.length == 12 && numeric.startsWith("91") -> numeric.substring(2)
        numeric.length == 11 && numeric.startsWith("0") -> numeric.substring(1)
        numeric.length > 10 -> numeric.takeLast(10)
        else -> numeric
    }
}

data class Transaction(
    var id: String? = null,
    var customerId: String? = null,
    var amount: Double? = 0.0,
    var type: String? = null, // "GAVE" or "GOT"
    var date: Long? = System.currentTimeMillis(),
    var billImageUrl: String? = null,
    var photoUrl: String? = null,
    var note: String? = null,
    var paid: Boolean = false,
    var paidAmount: Double? = 0.0,
    var paidDate: Long? = null,
    var version: Long = 0,
    var items: List<BillItem> = emptyList(),
    var profit: Double? = null,
    var syncing: Boolean = false,
    var syncFailed: Boolean = false
)

data class TransactionWithCustomer(
    val transaction: Transaction,
    val customerName: String,
    val customerId: String,
    val customerType: String,
    val phoneNumber: String = ""
)

enum class SortOption(val displayName: String) {
    MostRecent("Most Recent"),
    Oldest("Oldest"),
    AlphabeticalAZ("A-Z"),
    BalanceHighToLow("High to Low"),
    BalanceLowToHigh("Low to High"),
    HighestTransaction("Highest Transaction"),
    Date("Date")
}

class HomeViewModelFactory(private val context: Context, private val customerType: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class <T>): T {
        if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return HomeViewModel(context, customerType) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class HomeViewModel(context: Context, private val customerType: String = "HOME") : ViewModel() {
    private val userPreferences = UserPreferences(context)
    private val _customers = mutableStateOf<List<Customer>>(emptyList())
    val customers: State<List<Customer>> = _customers

    private val _customer = MutableStateFlow<Customer?>(null)
    val customer = _customer.asStateFlow()

    val showAddCustomerDialog = mutableStateOf(false)
    val totalYouWillGet = mutableStateOf(0.0)
    val totalYouWillGive = mutableStateOf(0.0)
    val searchQuery = mutableStateOf("")
    val sortOption = mutableStateOf(SortOption.MostRecent)
    val totalCustomerCount = derivedStateOf { _customers.value.size }
    val settledCustomerCount = derivedStateOf { _customers.value.count { it.initialBalance == 0.0 } }
    val isConnected = mutableStateOf(true)
    val hasNewReminders = mutableStateOf(false)
    val userRole = mutableStateOf<String?>(userPreferences.getLoginState())
    val userName = mutableStateOf<String?>(null)
    val hasNewOrders = mutableStateOf(false)

    private val _otherCustomers = mutableStateOf<List<Customer>>(emptyList())
    
    private val _gaveTransactions = mutableStateOf<List<TransactionWithCustomer>>(emptyList())

    val filteredCustomers = derivedStateOf { 
        val query = searchQuery.value
        val customersList = _customers.value
        val otherCustomersList = _otherCustomers.value

        val combinedCustomers = if (query.isBlank()) {
            customersList
        } else {
            val searchWords = query.split(" ").filter { it.isNotBlank() }
            val filterFunc: (Customer) -> Boolean = { cust ->
                searchWords.all { word ->
                    cust.name.contains(word, ignoreCase = true) || 
                    cust.phoneNumber?.toString()?.contains(word) == true
                }
            }
            customersList.filter(filterFunc) + otherCustomersList.filter(filterFunc)
        }

        when (sortOption.value) {
            SortOption.MostRecent -> combinedCustomers.sortedWith(
                compareByDescending<Customer> { it.hasDraft }
                    .thenByDescending { it.syncing || it.hasSyncError }
                    .thenByDescending { it.lastUpdated }
            )
            SortOption.Oldest -> combinedCustomers.sortedBy { it.lastUpdated }
            SortOption.AlphabeticalAZ -> combinedCustomers.sortedWith(compareBy(AlphaNumericComparator) { it.name })
            SortOption.BalanceHighToLow -> combinedCustomers.sortedByDescending { it.initialBalance }
            SortOption.BalanceLowToHigh -> combinedCustomers.sortedBy { it.initialBalance }
            SortOption.HighestTransaction -> combinedCustomers.sortedWith(
                compareByDescending<Customer> { it.hasDraft }
                    .thenByDescending { it.syncing || it.hasSyncError }
                    .thenByDescending { it.transactionCount }
                    .thenByDescending { it.lastUpdated }
            )
            SortOption.Date -> combinedCustomers // Not really used for list when Date sort is active
        }
    }

    val filteredTransactions = derivedStateOf {
        val query = searchQuery.value
        val transactions = _gaveTransactions.value
        
        val filtered = if (query.isBlank()) {
            transactions
        } else {
            val searchWords = query.split(" ").filter { it.isNotBlank() }
            transactions.filter { item ->
                searchWords.all { word ->
                    item.customerName.contains(word, ignoreCase = true) || 
                    item.transaction.note?.contains(word, ignoreCase = true) == true ||
                    item.phoneNumber.contains(word)
                }
            }
        }
        
        filtered.sortedByDescending { it.transaction.date }
    }
    
    private val database = when (customerType) {
        "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
        "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
        "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
        else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(customerType)
    }

    private val recycleBinDatabase = FirebaseDatabase.getInstance().getReference("recycle_bin")
    private val rolesDatabase = FirebaseDatabase.getInstance().getReference("roles")
    private val usersDatabase = FirebaseDatabase.getInstance().getReference("users")
    private val auth = FirebaseAuth.getInstance()
    private val ordersDatabase = FirebaseDatabase.getInstance().getReference("web_orders")

    init {
        database.keepSynced(true)
        // Eagerly load current data from repository
        val initialData = DataRepository.getDataFlow(customerType).value
        _customers.value = initialData.customers
        _gaveTransactions.value = initialData.gaveTransactions
        totalYouWillGet.value = initialData.totalYouWillGet
        totalYouWillGive.value = initialData.totalYouWillGive

        observeRepository()
        monitorFirebaseConnection()
        checkForNewReminders()
        fetchUserData()
        monitorOrders()
        migratePhoneNumbers()
    }

    private fun migratePhoneNumbers() {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val updates = mutableMapOf<String, Any?>()
                snapshot.children.forEach { customerSnap ->
                    val rawPhone = customerSnap.child("phoneNumber").value?.toString()
                    if (rawPhone != null) {
                        val cleaned = cleanPhoneNumber(rawPhone)
                        if (cleaned != rawPhone && cleaned.isNotEmpty()) {
                            updates["${customerSnap.key}/phoneNumber"] = cleaned
                        }
                    }
                }
                if (updates.isNotEmpty()) {
                    database.updateChildren(updates)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun observeRepository() {
        viewModelScope.launch {
            DataRepository.getDataFlow(customerType).collect { data ->
                _customers.value = data.customers
                _gaveTransactions.value = data.gaveTransactions
                totalYouWillGet.value = data.totalYouWillGet
                totalYouWillGive.value = data.totalYouWillGive
            }
        }

        val otherType = when (customerType) {
            "LOCALS" -> "HOME"
            "HOME" -> "LOCALS"
            else -> null
        }

        otherType?.let { type ->
            viewModelScope.launch {
                DataRepository.getDataFlow(type).collect { data ->
                    _otherCustomers.value = data.customers
                }
            }
        }
    }

    private fun monitorOrders() {
        auth.currentUser?.uid?.let { uid ->
            ordersDatabase.child(uid).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val hasPending = snapshot.children.any { it.child("status").getValue(String::class.java) == "Pending" }
                    hasNewOrders.value = hasPending
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    private fun fetchUserData() {
        auth.currentUser?.uid?.let { uid ->
            rolesDatabase.child(uid).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val role = snapshot.child("role").getValue(String::class.java)
                    userRole.value = role
                    userPreferences.setLoginState(role ?: "none")
                }

                override fun onCancelled(error: DatabaseError) {}
            })
            
            usersDatabase.child(uid).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    userName.value = snapshot.child("name").getValue(String::class.java) ?: auth.currentUser?.email?.substringBefore("@")
                }

                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    fun setUserRole(uid: String, role: String, onComplete: () -> Unit) {
        rolesDatabase.child(uid).child("role").setValue(role).addOnCompleteListener {
            onComplete()
        }
    }

    private fun checkForNewReminders() {
        database.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val today = System.currentTimeMillis()
                val defaultDays = userPreferences.getDefaultReminderDays()
                val foundReminder = snapshot.children.any { customerSnapshot ->
                    try {
                        val customer = customerSnapshot.getValue(Customer::class.java)
                        customer?.let { cust ->
                            val reminderDays = cust.paymentReminderDays ?: defaultDays
                            if (reminderDays > 0 && cust.initialBalance != 0.0) {
                                cust.lastUpdated?.let { transactionDate ->
                                    val diffInMillis = today - transactionDate
                                    val diffInDays = TimeUnit.MILLISECONDS.toDays(diffInMillis)
                                    if (diffInDays >= reminderDays) {
                                        return@any true
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // Ignore customers with corrupted data
                    }
                    false
                }
                hasNewReminders.value = foundReminder
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun remindersViewed() {
        hasNewReminders.value = false
    }

    private fun monitorFirebaseConnection() {
        val connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected")
        connectedRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                isConnected.value = connected
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun getCustomer(customerId: String, onCustomerLoaded: (Customer?) -> Unit) {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customer = snapshot.getValue(Customer::class.java)
                customer?.id = snapshot.key
                onCustomerLoaded(customer)
            }

            override fun onCancelled(error: DatabaseError) {
                onCustomerLoaded(null)
            }
        })
    }

    fun updateCustomer(customerId: String, name: String, phoneNumber: String, onComplete: () -> Unit) {
        val customerUpdates = mapOf(
            "name" to name,
            "phoneNumber" to phoneNumber
        )
        database.child(customerId).updateChildren(customerUpdates).addOnCompleteListener {
            onComplete()
        }
    }

    fun deleteCustomer(customer: Customer, onComplete: () -> Unit) {
        val deletedCustomerData = mapOf(
            "customer" to customer,
            "deletionDate" to System.currentTimeMillis()
        )
        recycleBinDatabase.child(customer.id!!).setValue(deletedCustomerData).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                database.child(customer.id!!).removeValue().addOnCompleteListener {
                    onComplete()
                }
            } else {
                // Handle error
                onComplete()
            }
        }
    }

    fun onSortOptionChange(newSortOption: SortOption) {
        sortOption.value = newSortOption
    }

    fun onSearchQueryChanged(newQuery: String) {
        searchQuery.value = newQuery
    }

    fun clearSearch() {
        searchQuery.value = ""
    }

    fun addCustomer(name: String, phoneNumber: String) {
        addCustomer(name, phoneNumber, 0.0, System.currentTimeMillis())
    }

    fun addCustomer(name: String, phoneNumber: String, initialBalance: Double, date: Long) {
        val customerId = database.push().key ?: return
        val currentTime = System.currentTimeMillis()
        val cleanedPhone = cleanPhoneNumber(phoneNumber)

        val customer = Customer(
            id = customerId,
            name = name,
            phoneNumber = cleanedPhone,
            initialBalance = 0.0, // Initial balance is handled by the transaction
            lastUpdated = date,
            creationDate = currentTime,
            customerType = this.customerType
        )
        database.child(customerId).setValue(customer)

        if (initialBalance != 0.0) {
            val transactionViewModel = TransactionViewModel(null, customerId, customerType) // Context pass null for now as it's not used in this path
            transactionViewModel.transactionType.value = "GAVE"
            transactionViewModel.addTransaction(
                amount = initialBalance,
                date = date,
                note = "L.B."
            )
        }
    }

    fun updateTransactionDate(item: TransactionWithCustomer, newDate: Long) {
        val transactionId = item.transaction.id ?: return
        val customerId = item.customerId
        
        database.child(customerId).child("transactions").child(transactionId).child("date").setValue(newDate)
        
        // Update customer's lastUpdated as well if needed to keep them in sync
        database.child(customerId).child("lastUpdated").setValue(System.currentTimeMillis())
    }

    fun generatePdfForTransaction(item: TransactionWithCustomer, context: Context, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val customerSnapshot = database.child(item.customerId).get().await()
            val customerObj = customerSnapshot.getValue(Customer::class.java)
            
            val allTransactionsSnap = customerSnapshot.child("transactions")
            val allTransactions = allTransactionsSnap.children.mapNotNull { it.getValue(Transaction::class.java)?.apply { id = it.key } }
            
            val sortedTransactions = allTransactions.sortedBy { it.date ?: 0L }
            val transactionsWithBalances = mutableListOf<Pair<Transaction, Double>>()
            var runningBalance = 0.0

            for (transaction in sortedTransactions) {
                runningBalance += if (transaction.type == "GAVE") {
                    transaction.amount ?: 0.0
                } else {
                    -(transaction.amount ?: 0.0)
                }
                transactionsWithBalances.add(Pair(transaction, runningBalance))
            }
            
            // Re-sort descending for the PDF generator if it expects it (TransactionViewModel sorts descending)
            val finalTransactionsWithBalances = transactionsWithBalances.sortedByDescending { it.first.date ?: 0L }

            // Find the full transaction matching the ID to get its complete items list
            val targetTransaction = allTransactions.find { it.id == item.transaction.id } ?: item.transaction

            val totalAmount = if (targetTransaction.paid) targetTransaction.paidAmount ?: 0.0 else targetTransaction.amount ?: 0.0
            val pdfData = PdfGenerator.createPdf(
                customer = customerObj,
                date = targetTransaction.date ?: 0,
                billItems = targetTransaction.items ?: emptyList(),
                totalAmount = totalAmount,
                transactionsWithBalances = finalTransactionsWithBalances,
                isPaid = targetTransaction.paid,
                isPurchaseReturn = targetTransaction.type == "GOT",
                printTwoCopies = false
            )

            val file = File(context.cacheDir, "bill_${targetTransaction.id}.pdf")
            FileOutputStream(file).use { it.write(pdfData) }

            withContext(Dispatchers.Main) {
                onComplete(file.absolutePath)
            }
        }
    }
}
