package com.example.gstcalculator

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class WebOrdersViewModel : ViewModel() {
    val orders = mutableStateOf<List<WebOrder>>(emptyList())
    val isLoading = mutableStateOf(true)

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().getReference("web_orders")

    init {
        fetchOrders()
    }

    private fun fetchOrders() {
        val uid = auth.currentUser?.uid ?: return
        database.child(uid).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val orderList = mutableListOf<WebOrder>()
                snapshot.children.forEach { child ->
                    WebOrder.fromSnapshot(child)?.let { orderList.add(it) }
                }
                orders.value = orderList.sortedByDescending { it.date }
                isLoading.value = false
            }

            override fun onCancelled(error: DatabaseError) {
                isLoading.value = false
            }
        })
    }

    fun updateOrderStatus(orderId: String, status: String) {
        val uid = auth.currentUser?.uid ?: return
        database.child(uid).child(orderId).child("status").setValue(status)
    }
    
    fun deleteOrder(orderId: String) {
        val uid = auth.currentUser?.uid ?: return
        database.child(uid).child(orderId).removeValue()
    }
}
