package com.example.gstcalculator

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.TimeUnit

data class PaymentReminder(
    val customerId: String,
    val customerName: String,
    val phoneNumber: String?,
    val transactionDate: Long,
    val runningBalance: Double,
    val daysPassed: String,
    val customerType: String,
    var statusLetter: String = "" // New field: H, S, or K
)

class PaymentRemindersViewModel(application: Application) : AndroidViewModel(application) {

    private val userPreferences = UserPreferences(application)
    private val customersHome = FirebaseDatabase.getInstance().getReference("customers_home")
    private val customersStaff = FirebaseDatabase.getInstance().getReference("customers_staff")
    private val customersLocals = FirebaseDatabase.getInstance().getReference("customers_locals")
    private val databases = listOf(customersHome, customersStaff, customersLocals)

    private val _reminders = MutableStateFlow<List<PaymentReminder>>(emptyList())
    val reminders = _reminders.asStateFlow()

    init {
        fetchReminders()
    }

    private fun fetchReminders() {
        val remindersList = mutableListOf<PaymentReminder>()

        databases.forEach { database ->
            val branchType = when (database) {
                customersStaff -> "STAFF"
                customersLocals -> "LOCALS"
                else -> "HOME"
            }
            database.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val today = System.currentTimeMillis()
                    val defaultDays = userPreferences.getDefaultReminderDays()
                    
                    // Filter this branch's reminders out before re-adding
                    remindersList.removeAll { it.customerType == branchType }

                    for (customerSnapshot in snapshot.children) {
                        try {
                            val customerMap = customerSnapshot.value as? Map<*, *> ?: continue
                            // Use customer-specific days if set, otherwise use the dynamic app default
                            val reminderDays = (customerMap["paymentReminderDays"] as? Number)?.toInt() ?: defaultDays
                            val initialBalance = (customerMap["initialBalance"] as? Number)?.toDouble() ?: 0.0
                            val statusLetter = customerMap["statusLetter"] as? String ?: ""

                            if (reminderDays > 0 && initialBalance != 0.0) {
                                val lastUpdated = (customerMap["lastUpdated"] as? Number)?.toLong()
                                lastUpdated?.let { transactionDate ->
                                    val diffInMillis = today - transactionDate
                                    val diffInDays = TimeUnit.MILLISECONDS.toDays(diffInMillis)

                                    if (diffInDays >= reminderDays) {
                                        remindersList.add(
                                            PaymentReminder(
                                                customerId = customerSnapshot.key!!,
                                                customerName = customerMap["name"] as? String ?: "",
                                                phoneNumber = customerMap["phoneNumber"]?.toString(),
                                                transactionDate = transactionDate,
                                                runningBalance = initialBalance,
                                                daysPassed = formatDaysPassed(diffInDays),
                                                customerType = branchType,
                                                statusLetter = statusLetter
                                            )
                                        )
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            // Ignore customers with corrupted data
                        }
                    }
                    _reminders.value = remindersList.sortedByDescending { it.transactionDate }.toList()
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle error
                }
            })
        }
    }

    fun updateStatusLetter(reminder: PaymentReminder, letter: String) {
        val dbPath = when (reminder.customerType) {
            "STAFF" -> "customers_staff"
            "LOCALS" -> "customers_locals"
            else -> "customers_home"
        }
        FirebaseDatabase.getInstance().getReference(dbPath)
            .child(reminder.customerId)
            .child("statusLetter")
            .setValue(letter)
    }

    private fun formatDaysPassed(days: Long): String {
        return when {
            days < 7 -> "$days days"
            days < 30 -> "${days / 7} weeks"
            else -> "${days / 30} months"
        }
    }
}
