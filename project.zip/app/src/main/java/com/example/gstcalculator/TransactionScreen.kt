package com.example.gstcalculator

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.exponentialDecay
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.AnchoredDraggableState
import androidx.compose.foundation.gestures.DraggableAnchors
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.anchoredDraggable
import androidx.compose.foundation.gestures.animateTo
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.SyncProblem
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DateRangePicker
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberDateRangePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.zIndex
import android.app.Activity
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import coil.compose.AsyncImage
import java.io.File
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.roundToInt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

private enum class SwipeState {
    Collapsed,
    RevealedRight
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun TransactionScreen(
    navController: NavController,
    customerId: String?,
    customerType: String
) {
    if (customerId == null) {
        return
    }
    val context = LocalContext.current
    val viewModel: TransactionViewModel = viewModel(factory = TransactionViewModelFactory(context, customerId, customerType))
    var revealedTransactionId by remember { mutableStateOf<String?>(null) }
    val coroutineScope = rememberCoroutineScope()
    var showDraftsDialog by remember { mutableStateOf(false) }
    var editingTransaction by remember { mutableStateOf<Transaction?>(null) }

    var showShareOptionsDialog by remember { mutableStateOf(false) }
    var showDateRangePicker by remember { mutableStateOf(false) }

    val customer by viewModel.customer
    val transactionsWithBalances by viewModel.transactionsWithBalances
    val isSelectionModeActive by viewModel.isSelectionModeActive
    val selectedTransactionIds by viewModel.selectedTransactionIds
    val drafts by viewModel.drafts

    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    BackHandler(enabled = isSelectionModeActive) {
        viewModel.clearTransactionSelection()
    }

    BackHandler(enabled = revealedTransactionId != null) {
        coroutineScope.launch {
            revealedTransactionId = null
        }
    }

    if (showDraftsDialog) {
        DraftsDialog(
            viewModel = viewModel,
            onDismiss = { showDraftsDialog = false },
            onDraftClick = { draftId ->
                if (viewModel.isConnected.value) {
                    showDraftsDialog = false
                    navController.navigate("createBill/$customerId/$customerType?draftId=$draftId")
                } else {
                    Toast.makeText(context, "Cannot open draft while offline", Toast.LENGTH_SHORT).show()
                }
            },
            onDeleteDraft = { draftId ->
                if (viewModel.isConnected.value) {
                    viewModel.deleteDraft(draftId)
                } else {
                    Toast.makeText(context, "Cannot delete draft while offline", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    if (showShareOptionsDialog) {
        ShareOptionsDialog(
            onDismiss = { showShareOptionsDialog = false },
            onEntireHistoryClick = {
                showShareOptionsDialog = false
                viewModel.generateReportAndGetPath(context) { path ->
                    val encodedPath = URLEncoder.encode(path, StandardCharsets.UTF_8.name())
                    val phone = customer?.phoneNumber?.toString() ?: ""
                    val name = customer?.name ?: ""
                    navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
                }
            },
            onSelectRangeClick = {
                showShareOptionsDialog = false
                showDateRangePicker = true
            }
        )
    }

    if (showDateRangePicker) {
        val initialStartDate = transactionsWithBalances.lastOrNull()?.first?.date ?: System.currentTimeMillis()
        val initialEndDate = System.currentTimeMillis()
        
        val dateRangePickerState = rememberDateRangePickerState(
            initialSelectedStartDateMillis = initialStartDate,
            initialSelectedEndDateMillis = initialEndDate
        )

        DatePickerDialog(
            onDismissRequest = { showDateRangePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val startDate = dateRangePickerState.selectedStartDateMillis
                        val endDate = dateRangePickerState.selectedEndDateMillis
                        if (startDate != null && endDate != null) {
                            showDateRangePicker = false
                            
                            val calendar = Calendar.getInstance()
                            calendar.timeInMillis = endDate
                            calendar.set(Calendar.HOUR_OF_DAY, 23)
                            calendar.set(Calendar.MINUTE, 59)
                            calendar.set(Calendar.SECOND, 59)
                            calendar.set(Calendar.MILLISECOND, 999)
                            val finalEndDate = calendar.timeInMillis

                            viewModel.generateReportAndGetPath(context, startDate, finalEndDate) { path ->
                                val encodedPath = URLEncoder.encode(path, StandardCharsets.UTF_8.name())
                                val phone = customer?.phoneNumber?.toString() ?: ""
                                val name = customer?.name ?: ""
                                navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
                            }
                        } else {
                            Toast.makeText(context, "Please select both dates", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDateRangePicker = false }, colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)) {
                    Text("Cancel")
                }
            }
        ) {
            DateRangePicker(
                state = dateRangePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                modifier = Modifier.weight(1f),
                colors = DatePickerDefaults.colors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF1976D2),
                    headlineContentColor = Color(0xFF1976D2),
                    selectedDayContainerColor = Color(0xFF1976D2),
                    selectedDayContentColor = Color.White,
                    todayContentColor = Color(0xFF1976D2),
                    todayDateBorderColor = Color(0xFF1976D2)
                )
            )
        }
    }

    Scaffold(
        containerColor = Color(0xFFF5F5F5),
        topBar = {
            Column(
                modifier = Modifier
                    .background(if (isSelectionModeActive) Color(0xFF0D47A1) else Color(0xFF1976D2))
                    .zIndex(1f)
            ) {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = customer?.name ?: "",
                                color = Color.White,
                                modifier = Modifier.combinedClickable(
                                    onClick = { navController.navigate("editCustomer/$customerId/$customerType") },
                                    onLongClick = { 
                                        val searchQuery = customer?.name ?: ""
                                        navController.navigate("profit?searchQuery=$searchQuery")
                                    }
                                )
                            )
                            if (!viewModel.isConnected.value) {
                                Text(
                                    text = "Offline",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier
                                        .background(
                                            color = Color(0xFFD50000),
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            if (isSelectionModeActive) {
                                viewModel.clearTransactionSelection()
                            } else {
                                navController.popBackStack()
                            }
                        }) {
                           Avatar(name = customer?.name ?: "")
                        }
                    },
                    actions = {
                        if (isSelectionModeActive) {
                            Text("${selectedTransactionIds.size}", color = Color.White, modifier = Modifier.padding(end = 16.dp))
                            IconButton(onClick = { viewModel.deleteSelectedTransactions() }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete Selected", tint = Color.White)
                            }
                        } else {
                            IconButton(onClick = { showDraftsDialog = true }) {
                                Icon(Icons.Default.Email, contentDescription = "Email", tint = if (drafts.isNotEmpty()) Color(0xFFFFA500) else Color.White)
                            }
                            IconButton(onClick = { 
                                showShareOptionsDialog = true
                            }) {
                                Icon(painter = painterResource(id = R.drawable.whatsapp_share_icon), contentDescription = "Share", modifier = Modifier.size(24.dp), tint = Color.White)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
                Card(
                    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end=16.dp, bottom = 16.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp, horizontal = 16.dp)
                    ) {
                        val balance = customer?.initialBalance ?: 0.0
                        val willGet = balance > 0

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (willGet) "You will Get" else "You will Give",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold
                            )
                            RollingAmount(
                                amount = kotlin.math.abs(balance), 
                                fontSize = 24.sp, 
                                fontWeight = FontWeight.Bold, 
                                color = if (willGet) Color(0xFFD50000) else Color(0xFF008800)
                            )
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            val groupedTransactions = transactionsWithBalances.groupBy {
                SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it.first.date ?: 0))
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp)
            ) {
                groupedTransactions.forEach { (date, transactions) ->
                    item(key = "date_$date") {
                        DateSeparator(
                            modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                            date = date
                        )
                    }
                    items(transactions, key = { it.first.id ?: UUID.randomUUID().toString() }) { (transaction, balance) ->
                        val isSelected = selectedTransactionIds.contains(transaction.id)
                        val isGaveTransaction = transaction.type == "GAVE"
                        val swipeEnabled = !transaction.syncing

                        val density = LocalDensity.current
                        val actionButtonWidth = 72.dp
                        val actionButtonWidthPx = with(density) { actionButtonWidth.toPx() }

                        val anchoredDraggableState = remember(transaction.id, actionButtonWidthPx) {
                            AnchoredDraggableState(
                                initialValue = SwipeState.Collapsed,
                                anchors = DraggableAnchors {
                                    SwipeState.Collapsed at 0f
                                    SwipeState.RevealedRight at -actionButtonWidthPx
                                },
                                positionalThreshold = { distance: Float -> distance * 0.5f },
                                velocityThreshold = { with(density) { 100.dp.toPx() } },
                                snapAnimationSpec = spring(),
                                decayAnimationSpec = exponentialDecay(),
                                confirmValueChange = { state: SwipeState ->
                                    if (state != SwipeState.Collapsed) {
                                        revealedTransactionId = transaction.id
                                    } else {
                                        if (revealedTransactionId == transaction.id) {
                                            revealedTransactionId = null
                                        }
                                    }
                                    true
                                }
                            )
                        }

                        LaunchedEffect(revealedTransactionId) {
                            if (revealedTransactionId != transaction.id && anchoredDraggableState.currentValue != SwipeState.Collapsed) {
                                anchoredDraggableState.animateTo(SwipeState.Collapsed)
                            }
                        }
                        
                        val revealedBrushRight = if (isGaveTransaction) {
                            Brush.verticalGradient(colors = listOf(Color(0xFF64B5F6), Color(0xFF1976D2)))
                        } else {
                            Brush.verticalGradient(colors = listOf(Color(0xFFF87970), Color(0xFFD50000)))
                        }

                        Box(
                            modifier = Modifier
                                .animateItemPlacement(animationSpec = springSpec)
                                .fillMaxWidth()
                                .height(IntrinsicSize.Min)
                                .padding(vertical = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.CenterEnd)
                                    .fillMaxHeight()
                                    .width(actionButtonWidth)
                                    .padding(vertical = 4.dp)
                                    .background(brush = revealedBrushRight, shape = RoundedCornerShape(8.dp)),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isGaveTransaction) {
                                    Box(
                                        modifier = Modifier.fillMaxSize().clickable {
                                            coroutineScope.launch {
                                                if (transaction.paid) {
                                                    transaction.id?.let { viewModel.markAsUnpaid(it) }
                                                } else {
                                                    transaction.id?.let { viewModel.markAsPaid(it) }
                                                }
                                                anchoredDraggableState.animateTo(SwipeState.Collapsed)
                                                revealedTransactionId = null
                                            }
                                        },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (transaction.paid) {
                                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                Text("Un", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                                Text("Paid", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                            }
                                        } else {
                                            Text("Paid", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                        }
                                    }
                                } else {
                                    IconButton(onClick = {
                                        coroutineScope.launch {
                                            viewModel.deleteTransaction(transaction.id)
                                            anchoredDraggableState.animateTo(SwipeState.Collapsed)
                                            revealedTransactionId = null
                                        }
                                    }) {
                                        Icon(
                                            Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = Color.White
                                        )
                                    }
                                }
                            }

                            TransactionItem(
                                modifier = Modifier
                                    .offset { 
                                        IntOffset(
                                            x = if (anchoredDraggableState.offset.isNaN()) 0 else anchoredDraggableState.offset.roundToInt(),
                                            y = 0
                                        )
                                    }
                                    .anchoredDraggable(
                                        state = anchoredDraggableState,
                                        orientation = Orientation.Horizontal,
                                        enabled = true
                                    ),
                                transaction = transaction,
                                runningBalance = balance,
                                isSelected = isSelected,
                                viewModel = viewModel,
                                navController = navController,
                                onClick = {
                                    coroutineScope.launch {
                                        if (transaction.syncing && transaction.photoUrl == null && viewModel.localImageUris[transaction.id] == null) {
                                            Toast.makeText(context, "Please wait for upload to complete", Toast.LENGTH_SHORT).show()
                                            return@launch
                                        }
                                        if (anchoredDraggableState.currentValue != SwipeState.Collapsed) {
                                            anchoredDraggableState.animateTo(SwipeState.Collapsed)
                                        } else if (revealedTransactionId != null) {
                                            revealedTransactionId = null
                                        } else {
                                            transaction.id?.let { id ->
                                                if (isSelectionModeActive) {
                                                    viewModel.toggleTransactionSelection(id)
                                                } else if (!transaction.paid) {
                                                    if (transaction.billImageUrl == null && !transaction.syncing) {
                                                        editingTransaction = transaction
                                                    } else if (transaction.items.isNotEmpty()) {
                                                        navController.navigate("createBill/$customerId/$customerType?transactionId=$id")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                },
                                onLongClick = {
                                    if (!transaction.syncing) {
                                        transaction.id?.let { id ->
                                            viewModel.toggleTransactionSelection(id)
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp, pressedElevation = 8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color(0xFFF87970), Color(0xFFD50000))
                                )
                            )
                            .combinedClickable(
                                onLongClick = {
                                    viewModel.transactionType.value = "GAVE"
                                    viewModel.showTransactionDialog.value = true
                                },
                                onClick = {
                                    navController.navigate("createBill/$customerId/$customerType")
                                }
                            )
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("YOU GAVE ₹", color = Color.White)
                    }
                }
                Spacer(modifier = Modifier.size(16.dp))
                Card(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp, pressedElevation = 8.dp),
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color(0xFF63D367), Color(0xFF008800))
                                )
                            )
                            .combinedClickable(
                                onClick = {
                                    viewModel.transactionType.value = "GOT"
                                    viewModel.showTransactionDialog.value = true
                                },
                                onLongClick = {
                                    navController.navigate("createBill/$customerId/$customerType?isPurchaseReturn=true")
                                }
                            )
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("YOU GOT ₹", color = Color.White)
                    }
                }
            }
        }
        val navBarPadding = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

        if (viewModel.showTransactionDialog.value) {
            AddTransactionDialog(viewModel = viewModel, navBarPadding = navBarPadding)
        }

        editingTransaction?.let { transaction ->
            EditTransactionDialog(
                transaction = transaction,
                viewModel = viewModel,
                onDismiss = { editingTransaction = null },
                navBarPadding = navBarPadding
            )
        }
    }
}

@Composable
fun ShareOptionsDialog(
    onDismiss: () -> Unit,
    onEntireHistoryClick: () -> Unit,
    onSelectRangeClick: () -> Unit
) {
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Share Report",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Column(modifier = Modifier.padding(24.dp)) {
                    Button(
                        onClick = onEntireHistoryClick,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        Text("Create Entire Report")
                    }
                    
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    Button(
                        onClick = onSelectRangeClick,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Select Date Range")
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss, colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)) {
                            Text("Cancel")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DateSeparator(
    modifier: Modifier = Modifier,
    date: String
) {
    Box(
        modifier = modifier
            .fillMaxWidth(),
        contentAlignment = Alignment.Center
    ) {
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White)
        ) {
            Text(
                text = date,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 0.dp),
                fontSize = 8.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
        }
    }
}

enum class ActiveField {
    AMOUNT, NOTE
}

fun evaluateExpression(expr: String): Double? {
    if (expr.isBlank()) return null
    val sanitized = expr.replace('÷', '/').replace('×', '*').trim()
    return try {
        object {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < sanitized.length) sanitized[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < sanitized.length) throw RuntimeException("Unexpected: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    when {
                        eat('+'.code) -> x += parseTerm()
                        eat('-'.code) -> x -= parseTerm()
                        else -> return x
                    }
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    when {
                        eat('*'.code) -> x *= parseFactor()
                        eat('/'.code) -> {
                            val divisor = parseFactor()
                            if (divisor == 0.0) throw ArithmeticException("Division by zero")
                            x /= divisor
                        }
                        else -> return x
                    }
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.code)) return parseFactor()
                if (eat('-'.code)) return -parseFactor()

                var x: Double
                val startPos = pos
                if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                    while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                    x = sanitized.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }
                return x
            }
        }.parse()
    } catch (_: Exception) {
        null
    }
}

fun handleCalculatorKey(
    key: String,
    currentAmount: String,
    onAmountChange: (String) -> Unit,
    onEvaluate: () -> Unit,
    onClear: () -> Unit
) {
    when (key) {
        "AC" -> onClear()
        "⌫" -> {
            if (currentAmount.isNotEmpty()) {
                onAmountChange(currentAmount.dropLast(1))
            }
        }
        "=" -> onEvaluate()
        "+", "-", "×", "÷" -> {
            if (currentAmount.isEmpty()) {
                if (key == "-") {
                    onAmountChange("-")
                }
            } else {
                val lastChar = currentAmount.last()
                if (lastChar == '+' || lastChar == '-' || lastChar == '×' || lastChar == '÷' || lastChar == '*' || lastChar == '/') {
                    onAmountChange(currentAmount.dropLast(1) + key)
                } else if (lastChar == '.') {
                    onAmountChange(currentAmount.dropLast(1) + key)
                } else {
                    onAmountChange(currentAmount + key)
                }
            }
        }
        "." -> {
            if (currentAmount.isEmpty()) {
                onAmountChange("0.")
            } else {
                val lastChar = currentAmount.last()
                if (lastChar == '+' || lastChar == '-' || lastChar == '×' || lastChar == '÷' || lastChar == '*' || lastChar == '/') {
                    onAmountChange(currentAmount + "0.")
                } else {
                    val lastNumberToken = currentAmount.split('+', '-', '×', '÷', '*', '/').lastOrNull() ?: ""
                    if (!lastNumberToken.contains('.')) {
                        onAmountChange(currentAmount + ".")
                    }
                }
            }
        }
        "00" -> {
            if (currentAmount.isEmpty() || currentAmount == "0") {
                onAmountChange("0")
            } else {
                val lastChar = currentAmount.last()
                if (lastChar in listOf('+', '-', '×', '÷', '*', '/')) {
                    onAmountChange(currentAmount + "0")
                } else {
                    onAmountChange(currentAmount + "00")
                }
            }
        }
        else -> {
            if (currentAmount == "0") {
                if (key != "0") {
                    onAmountChange(key)
                }
            } else {
                onAmountChange(currentAmount + key)
            }
        }
    }
}

@Composable
fun CalculatorKeypad(
    onKeyClick: (String) -> Unit,
    modifier: Modifier = Modifier,
    height: Dp = 265.dp
) {
    val spacing = 6.dp

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFFEDF3FB),
        shadowElevation = 4.dp,
        modifier = modifier
            .fillMaxWidth()
            .height(height)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 8.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(spacing)
        ) {
            // Row 1: [ AC ] [ × ] [ ÷ ] [ ⌫ ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                listOf("AC", "×", "÷", "⌫").forEach { key ->
                    CalculatorKeyButton(
                        label = key,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onClick = { onKeyClick(key) }
                    )
                }
            }

            // Row 2: [ 7 ] [ 8 ] [ 9 ] [ - ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                listOf("7", "8", "9", "-").forEach { key ->
                    CalculatorKeyButton(
                        label = key,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onClick = { onKeyClick(key) }
                    )
                }
            }

            // Rows 3 & 4: Left 3 columns for [4,5,6] and [1,2,3], Right column for tall [+] button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(2f),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                Column(
                    modifier = Modifier
                        .weight(3f)
                        .fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(spacing)
                ) {
                    // Row 3 Left: [ 4 ] [ 5 ] [ 6 ]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(spacing)
                    ) {
                        listOf("4", "5", "6").forEach { key ->
                            CalculatorKeyButton(
                                label = key,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                onClick = { onKeyClick(key) }
                            )
                        }
                    }
                    // Row 4 Left: [ 1 ] [ 2 ] [ 3 ]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(spacing)
                    ) {
                        listOf("1", "2", "3").forEach { key ->
                            CalculatorKeyButton(
                                label = key,
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight(),
                                onClick = { onKeyClick(key) }
                            )
                        }
                    }
                }

                // Row 3 & 4 Right: [ + ] spanning two rows
                CalculatorKeyButton(
                    label = "+",
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    onClick = { onKeyClick("+") }
                )
            }

            // Row 5: [ 0 ] [ 00 ] [ . ] [ = ]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(spacing)
            ) {
                listOf("0", "00", ".", "=").forEach { key ->
                    CalculatorKeyButton(
                        label = key,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        onClick = { onKeyClick(key) }
                    )
                }
            }
        }
    }
}

@Composable
fun CalculatorKeyButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    val isOperator = label in listOf("÷", "×", "-", "+")
    val isAction = label in listOf("AC", "⌫")
    val isEqual = label == "="

    val backgroundColor = when {
        isEqual -> Color(0xFF1976D2)
        isAction -> Color(0xFFFFEBEE)
        isOperator -> Color(0xFFE3F2FD)
        else -> Color.White
    }

    val textColor = when {
        isEqual -> Color.White
        isAction -> Color(0xFFD50000)
        isOperator -> Color(0xFF1976D2)
        else -> Color(0xFF1E293B)
    }

    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable {
            // Provide a crisp, subtle vibration like the system keyboard tap
            try {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
            } catch (_: Exception) {}

            try {
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (vibrator != null && vibrator.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        vibrator.vibrate(VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK))
                    } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        vibrator.vibrate(VibrationEffect.createOneShot(12, 60))
                    } else {
                        @Suppress("DEPRECATION")
                        vibrator.vibrate(12)
                    }
                }
            } catch (_: Exception) {}

            onClick()
        }
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = if (label.length > 1) 18.sp else 22.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun rememberNavigationBarBottomPadding(passedPadding: Dp = 0.dp): Dp {
    val context = LocalContext.current
    val density = LocalDensity.current
    val activity = context as? Activity

    return remember(activity, density, passedPadding) {
        val rootInsets = activity?.window?.decorView?.let { ViewCompat.getRootWindowInsets(it) }
        val navBarsPx = rootInsets?.getInsets(WindowInsetsCompat.Type.navigationBars())?.bottom ?: 0
        val gesturesPx = rootInsets?.getInsets(WindowInsetsCompat.Type.systemGestures())?.bottom ?: 0
        val mandatoryGesturesPx = rootInsets?.getInsets(WindowInsetsCompat.Type.mandatorySystemGestures())?.bottom ?: 0
        val tappablePx = rootInsets?.getInsets(WindowInsetsCompat.Type.tappableElement())?.bottom ?: 0
        val maxPx = maxOf(navBarsPx, gesturesPx, mandatoryGesturesPx, tappablePx)
        val detectedDp = if (maxPx > 0) with(density) { maxPx.toDp() } else passedPadding
        maxOf(detectedDp, 48.dp) + 8.dp
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    viewModel: TransactionViewModel,
    navBarPadding: Dp = 0.dp
) {
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }
    var showDatePicker by remember { mutableStateOf(false) }
    var amountErrorMsg by remember { mutableStateOf<String?>(null) }
    var activeField by remember { mutableStateOf(ActiveField.AMOUNT) }
    var capturedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }

    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current

    val imeInsets = WindowInsets.ime
    val imeBottom = imeInsets.getBottom(density)
    val isKeyboardOpen = imeBottom > 0
    val imeHeightDp = with(density) { imeBottom.toDp() }

    val actualNavBarPadding = rememberNavigationBarBottomPadding(navBarPadding)

    var keypadHeightDp by remember { mutableStateOf(265.dp) }
    LaunchedEffect(imeHeightDp) {
        if (imeHeightDp > 120.dp) {
            keypadHeightDp = imeHeightDp
        }
    }

    LaunchedEffect(isKeyboardOpen) {
        if (!isKeyboardOpen && activeField == ActiveField.NOTE) {
            activeField = ActiveField.AMOUNT
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            capturedPhotoUri = tempPhotoUri
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            capturedPhotoUri = uri
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val uri = createPhotoUri(context)
            tempPhotoUri = uri
            cameraLauncher.launch(uri)
        } else {
            Toast.makeText(context, "Camera permission required", Toast.LENGTH_SHORT).show()
        }
    }

    val transactionType = viewModel.transactionType.value
    val headerColor = if (transactionType == "GAVE") Color(0xFFD50000) else Color(0xFF008800)
    val title = if (transactionType == "GAVE") "You Gave" else "You Got"

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = date)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedDateMillis = datePickerState.selectedDateMillis ?: System.currentTimeMillis()
                        val selectedDateCalendar = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        val nowCalendar = Calendar.getInstance()

                        selectedDateCalendar.set(Calendar.HOUR_OF_DAY, nowCalendar.get(Calendar.HOUR_OF_DAY))
                        selectedDateCalendar.set(Calendar.MINUTE, nowCalendar.get(Calendar.MINUTE))
                        selectedDateCalendar.set(Calendar.SECOND, nowCalendar.get(Calendar.SECOND))
                        selectedDateCalendar.set(Calendar.MILLISECOND, nowCalendar.get(Calendar.MILLISECOND))

                        date = selectedDateCalendar.timeInMillis
                        showDatePicker = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDatePicker = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF1976D2),
                    headlineContentColor = Color(0xFF1976D2),
                    selectedDayContainerColor = Color(0xFF1976D2),
                    selectedDayContentColor = Color.White,
                    todayContentColor = Color(0xFF1976D2),
                    todayDateBorderColor = Color(0xFF1976D2)
                )
            )
        }
    }

    BouncyDialog(
        onDismissRequest = { viewModel.showTransactionDialog.value = false },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (isKeyboardOpen) {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    } else {
                        viewModel.showTransactionDialog.value = false
                    }
                }
        ) {
            // Popup Card positioned identically whether numeric keyboard or soft keyboard is active:
            // When soft keyboard (notes) is active: imePadding lifts the popup into the upper visible screen area.
            // When numeric keyboard (amount) is active: bottom padding of (keypadHeightDp + actualNavBarPadding) lifts it to the exact same position.
            val keypadOccupiedBottom = keypadHeightDp + actualNavBarPadding
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .padding(bottom = if (!isKeyboardOpen) keypadOccupiedBottom else 0.dp)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            // Consume clicks so tapping form doesn't dismiss dialog
                        }
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(headerColor)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = title,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        activeField = ActiveField.AMOUNT
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }
                            ) {
                                TextField(
                                    value = amount,
                                    onValueChange = { newText ->
                                        amount = newText
                                        amountErrorMsg = null
                                    },
                                    readOnly = true,
                                    label = { Text("Amount") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged {
                                            if (it.isFocused) {
                                                activeField = ActiveField.AMOUNT
                                                keyboardController?.hide()
                                                focusManager.clearFocus()
                                            }
                                        },
                                    isError = amountErrorMsg != null,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        disabledContainerColor = Color.White
                                    )
                                )
                            }
                            if (amountErrorMsg != null) {
                                Text(
                                    text = amountErrorMsg!!,
                                    color = Color(0xFFD50000),
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            TextField(
                                value = note,
                                onValueChange = { note = it },
                                label = { Text("Note") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.Words,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        activeField = ActiveField.AMOUNT
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged {
                                        if (it.isFocused) {
                                            activeField = ActiveField.NOTE
                                        }
                                    },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White,
                                    disabledContainerColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(date)))
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        showDatePicker = true
                                    }) {
                                        Icon(Icons.Default.DateRange, contentDescription = "Select Date", tint = Color(0xFF1976D2))
                                    }
                                }
                                
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                            val uri = createPhotoUri(context)
                                            tempPhotoUri = uri
                                            cameraLauncher.launch(uri)
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = "Capture Photo", tint = Color(0xFF1976D2))
                                    }
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        galleryLauncher.launch("image/*")
                                    }) {
                                        Icon(Icons.Default.Collections, contentDescription = "Gallery", tint = Color(0xFF1976D2))
                                    }
                                    
                                    if (capturedPhotoUri != null) {
                                        Box(modifier = Modifier.size(40.dp).clip(RoundedCornerShape(4.dp))) {
                                            AsyncImage(
                                                model = capturedPhotoUri,
                                                contentDescription = "Preview",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                            IconButton(
                                                onClick = { capturedPhotoUri = null },
                                                modifier = Modifier.align(Alignment.TopEnd).background(Color.Black.copy(alpha = 0.5f), CircleShape).size(16.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(10.dp))
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = { viewModel.showTransactionDialog.value = false },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                                ) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val hasOperators = amount.any { it in listOf('+', '-', '×', '÷', '*', '/') } && !(amount.startsWith("-") && amount.count { it in listOf('+', '-', '×', '÷', '*', '/') } == 1)
                                        val parsedAmount = amount.toDoubleOrNull()

                                        if (hasOperators) {
                                            amountErrorMsg = "Please press '=' to calculate total amount before saving"
                                        } else if (parsedAmount == null || parsedAmount <= 0.0) {
                                            amountErrorMsg = "Amount cannot be empty or zero"
                                        } else {
                                            viewModel.addTransaction(
                                                amount = parsedAmount,
                                                date = date,
                                                note = note,
                                                items = emptyList(),
                                                photoUri = capturedPhotoUri,
                                                context = context
                                            )
                                            viewModel.showTransactionDialog.value = false
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = headerColor)
                                ) {
                                    Text("Save")
                                }
                            }
                        }
                    }
                }
            }

            // Bottom docked calculator keypad (above gesture control bar)
            if (!isKeyboardOpen) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .padding(bottom = actualNavBarPadding)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            // Consume clicks so tapping keypad doesn't dismiss dialog
                        }
                ) {
                    CalculatorKeypad(
                        height = keypadHeightDp,
                        modifier = Modifier.fillMaxWidth(),
                        onKeyClick = { key ->
                            handleCalculatorKey(
                                key = key,
                                currentAmount = amount,
                                onAmountChange = {
                                    amount = it
                                    amountErrorMsg = null
                                },
                                onEvaluate = {
                                    val result = evaluateExpression(amount)
                                    if (result != null) {
                                        if (result <= 0.0) {
                                            amountErrorMsg = "Amount cannot be empty or zero"
                                        } else {
                                            amount = formatPrice(result)
                                            amountErrorMsg = null
                                        }
                                    } else {
                                        amountErrorMsg = "Invalid expression. Press = to calculate"
                                    }
                                },
                                onClear = {
                                    amount = ""
                                    amountErrorMsg = null
                                }
                            )
                        }
                    )
                }
            }
        }
    }
}

private fun createPhotoUri(context: Context): Uri {
    val file = File(context.cacheDir, "temp_photo_${UUID.randomUUID()}.jpg")
    return FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
}

private fun formatPrice(price: Double): String {
    return if (price % 1.0 == 0.0) {
        price.toLong().toString()
    } else {
        val df = DecimalFormat("#.##", DecimalFormatSymbols(Locale.US))
        df.format(price)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTransactionDialog(
    transaction: Transaction,
    viewModel: TransactionViewModel,
    onDismiss: () -> Unit,
    navBarPadding: Dp = 0.dp
) {
    var amount by remember { mutableStateOf(formatPrice(transaction.amount ?: 0.0)) }
    var note by remember { mutableStateOf(transaction.note ?: "") }
    var date by remember { mutableLongStateOf(transaction.date ?: System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var amountErrorMsg by remember { mutableStateOf<String?>(null) }
    var activeField by remember { mutableStateOf(ActiveField.AMOUNT) }
    
    var capturedPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var tempPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var removeExistingPhoto by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusManager = LocalFocusManager.current
    val density = LocalDensity.current

    val imeInsets = WindowInsets.ime
    val imeBottom = imeInsets.getBottom(density)
    val isKeyboardOpen = imeBottom > 0
    val imeHeightDp = with(density) { imeBottom.toDp() }

    val actualNavBarPadding = rememberNavigationBarBottomPadding(navBarPadding)

    var keypadHeightDp by remember { mutableStateOf(265.dp) }
    LaunchedEffect(imeHeightDp) {
        if (imeHeightDp > 120.dp) {
            keypadHeightDp = imeHeightDp
        }
    }

    LaunchedEffect(isKeyboardOpen) {
        if (!isKeyboardOpen && activeField == ActiveField.NOTE) {
            activeField = ActiveField.AMOUNT
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            capturedPhotoUri = tempPhotoUri
            removeExistingPhoto = false
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            capturedPhotoUri = uri
            removeExistingPhoto = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            val uri = createPhotoUri(context)
            tempPhotoUri = uri
            cameraLauncher.launch(uri)
        } else {
            Toast.makeText(context, "Camera permission required", Toast.LENGTH_SHORT).show()
        }
    }

    val headerColor = if (transaction.type == "GAVE") Color(0xFFD50000) else Color(0xFF008800)
    val title = "Edit " + if (transaction.type == "GAVE") "You Gave" else "You Got"

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = date)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedDateMillis = datePickerState.selectedDateMillis ?: System.currentTimeMillis()
                        val selectedDateCalendar = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        val nowCalendar = Calendar.getInstance()

                        selectedDateCalendar.set(Calendar.HOUR_OF_DAY, nowCalendar.get(Calendar.HOUR_OF_DAY))
                        selectedDateCalendar.set(Calendar.MINUTE, nowCalendar.get(Calendar.MINUTE))
                        selectedDateCalendar.set(Calendar.SECOND, nowCalendar.get(Calendar.SECOND))
                        selectedDateCalendar.set(Calendar.MILLISECOND, nowCalendar.get(Calendar.MILLISECOND))

                        date = selectedDateCalendar.timeInMillis
                        showDatePicker = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDatePicker = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                ) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(
                state = datePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF1976D2),
                    headlineContentColor = Color(0xFF1976D2),
                    selectedDayContainerColor = Color(0xFF1976D2),
                    selectedDayContentColor = Color.White,
                    todayContentColor = Color(0xFF1976D2),
                    todayDateBorderColor = Color(0xFF1976D2)
                )
            )
        }
    }

    BouncyDialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) {
                    if (isKeyboardOpen) {
                        keyboardController?.hide()
                        focusManager.clearFocus()
                    } else {
                        onDismiss()
                    }
                }
        ) {
            // Popup Card positioned identically whether numeric keyboard or soft keyboard is active:
            // When soft keyboard (notes) is active: imePadding lifts the popup into the upper visible screen area.
            // When numeric keyboard (amount) is active: bottom padding of (keypadHeightDp + actualNavBarPadding) lifts it to the exact same position.
            val keypadOccupiedBottom = keypadHeightDp + actualNavBarPadding
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .imePadding()
                    .padding(bottom = if (!isKeyboardOpen) keypadOccupiedBottom else 0.dp)
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            // Consume clicks so tapping form doesn't dismiss dialog
                        }
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(headerColor)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = title,
                                color = Color.White,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Column(
                            modifier = Modifier
                                .padding(16.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        activeField = ActiveField.AMOUNT
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                    }
                            ) {
                                TextField(
                                    value = amount,
                                    onValueChange = { newText ->
                                        amount = newText
                                        amountErrorMsg = null
                                    },
                                    readOnly = true,
                                    label = { Text("Amount") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .onFocusChanged {
                                            if (it.isFocused) {
                                                activeField = ActiveField.AMOUNT
                                                keyboardController?.hide()
                                                focusManager.clearFocus()
                                            }
                                        },
                                    isError = amountErrorMsg != null,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.White,
                                        unfocusedContainerColor = Color.White,
                                        disabledContainerColor = Color.White
                                    )
                                )
                            }
                            if (amountErrorMsg != null) {
                                Text(
                                    text = amountErrorMsg!!,
                                    color = Color(0xFFD50000),
                                    style = MaterialTheme.typography.bodySmall,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            TextField(
                                value = note,
                                onValueChange = { note = it },
                                label = { Text("Note") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(
                                    capitalization = KeyboardCapitalization.Words,
                                    imeAction = ImeAction.Done
                                ),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        activeField = ActiveField.AMOUNT
                                    }
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onFocusChanged {
                                        if (it.isFocused) {
                                            activeField = ActiveField.NOTE
                                        }
                                    },
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.White,
                                    unfocusedContainerColor = Color.White,
                                    disabledContainerColor = Color.White
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(date)))
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        showDatePicker = true
                                    }) {
                                        Icon(Icons.Default.DateRange, contentDescription = "Select Date", tint = Color(0xFF1976D2))
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                            val uri = createPhotoUri(context)
                                            tempPhotoUri = uri
                                            cameraLauncher.launch(uri)
                                        } else {
                                            permissionLauncher.launch(Manifest.permission.CAMERA)
                                        }
                                    }) {
                                        Icon(Icons.Default.CameraAlt, contentDescription = "Capture Photo", tint = Color(0xFF1976D2))
                                    }
                                    IconButton(onClick = {
                                        keyboardController?.hide()
                                        focusManager.clearFocus()
                                        galleryLauncher.launch("image/*")
                                    }) {
                                        Icon(Icons.Default.Collections, contentDescription = "Gallery", tint = Color(0xFF1976D2))
                                    }

                                    val displayUri = capturedPhotoUri ?: if (!removeExistingPhoto) transaction.photoUrl else null
                                    if (displayUri != null) {
                                        Box(modifier = Modifier.size(40.dp).clip(RoundedCornerShape(4.dp))) {
                                            AsyncImage(
                                                model = displayUri,
                                                contentDescription = "Preview",
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop
                                            )
                                            IconButton(
                                                onClick = {
                                                    if (capturedPhotoUri != null) {
                                                        capturedPhotoUri = null
                                                    } else {
                                                        removeExistingPhoto = true
                                                    }
                                                },
                                                modifier = Modifier.align(Alignment.TopEnd).background(Color.Black.copy(alpha = 0.5f), CircleShape).size(16.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(10.dp))
                                            }
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                Button(
                                    onClick = onDismiss,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                                ) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val hasOperators = amount.any { it in listOf('+', '-', '×', '÷', '*', '/') } && !(amount.startsWith("-") && amount.count { it in listOf('+', '-', '×', '÷', '*', '/') } == 1)
                                        val parsedAmount = amount.toDoubleOrNull()

                                        if (hasOperators) {
                                            amountErrorMsg = "Please press '=' to calculate total amount before saving"
                                        } else if (parsedAmount == null || parsedAmount <= 0.0) {
                                            amountErrorMsg = "Amount cannot be empty or zero"
                                        } else {
                                            transaction.id?.let {
                                                viewModel.updateTransactionAmount(
                                                    transactionId = it,
                                                    newAmount = parsedAmount,
                                                    newNote = note,
                                                    newDate = date,
                                                    photoUri = capturedPhotoUri,
                                                    removePhoto = removeExistingPhoto,
                                                    context = context
                                                )
                                            }
                                            onDismiss()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = headerColor)
                                ) {
                                    Text("Save")
                                }
                            }
                        }
                    }
                }
            }

            // Bottom docked calculator keypad (above gesture control bar)
            if (!isKeyboardOpen) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .padding(bottom = actualNavBarPadding)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            // Consume clicks so tapping keypad doesn't dismiss dialog
                        }
                ) {
                    CalculatorKeypad(
                        height = keypadHeightDp,
                        modifier = Modifier.fillMaxWidth(),
                        onKeyClick = { key ->
                            handleCalculatorKey(
                                key = key,
                                currentAmount = amount,
                                onAmountChange = {
                                    amount = it
                                    amountErrorMsg = null
                                },
                                onEvaluate = {
                                    val result = evaluateExpression(amount)
                                    if (result != null) {
                                        if (result <= 0.0) {
                                            amountErrorMsg = "Amount cannot be empty or zero"
                                        } else {
                                            amount = formatPrice(result)
                                            amountErrorMsg = null
                                        }
                                    } else {
                                        amountErrorMsg = "Invalid expression. Press = to calculate"
                                    }
                                },
                                onClear = {
                                    amount = ""
                                    amountErrorMsg = null
                                }
                            )
                        }
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalFoundationApi::class)
@Composable
fun TransactionItem(
    modifier: Modifier = Modifier,
    transaction: Transaction,
    runningBalance: Double,
    isSelected: Boolean,
    viewModel: TransactionViewModel,
    navController: NavController,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val alpha = if (transaction.paid) 0.5f else 1f
    val context = LocalContext.current
    var showFullPhoto by remember { mutableStateOf(false) }

    val positiveBalanceGreen = Color(0xFF008800)
    val negativeBalanceRed = Color(0xFFD50000)
    val runningBalanceColor = if (runningBalance < 0) positiveBalanceGreen else negativeBalanceRed

    val gaveColor = Color(0xFFD50000)
    val gotColor = Color(0xFF008800)
    val transactionTypeColor = if (transaction.type == "GAVE") gaveColor else gotColor
    
    val displayUrl = transaction.photoUrl ?: viewModel.localImageUris[transaction.id ?: ""]

    if (showFullPhoto) {
        ZoomableImage(
            model = displayUrl,
            onDismiss = { showFullPhoto = false }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = if (isSelected) Color(0xFFD3E3F3) else Color.White)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Spacer(
                    modifier = Modifier
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(transactionTypeColor.copy(alpha = alpha))
                )
                Row(
                    modifier = Modifier
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            transaction.date?.let {
                                Text(
                                    SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(it)),
                                    fontSize = 12.sp,
                                    color = Color.Gray.copy(alpha = alpha)
                                )
                            }
                            if (transaction.syncing) {
                                Spacer(modifier = Modifier.width(8.dp))
                                val infiniteTransition = rememberInfiniteTransition(label = "sync")
                                val rotate by infiniteTransition.animateFloat(
                                    initialValue = 0f,
                                    targetValue = -360f,
                                    animationSpec = infiniteRepeatable(
                                        animation = tween(1000, easing = LinearEasing),
                                        repeatMode = RepeatMode.Restart
                                    ),
                                    label = "rotate"
                                )
                                Icon(
                                    imageVector = Icons.Default.Sync,
                                    contentDescription = "Syncing",
                                    tint = Color(0xFFD50000),
                                    modifier = Modifier
                                        .size(12.dp)
                                        .rotate(rotate)
                                )
                            }
                        }
                        transaction.note?.let {
                            if (it.isNotBlank()) {
                                Text(
                                    it,
                                    fontSize = 12.sp,
                                    color = Color.Black.copy(alpha = alpha)
                                )
                            }
                        }
                        Text(
                            text = "Bal. ${formatAmount(runningBalance)}",
                            fontSize = 12.sp,
                            color = runningBalanceColor.copy(alpha = alpha)
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        Column(
                            modifier = if (transaction.type == "GOT") {
                                Modifier.align(Alignment.TopEnd).padding(end = 50.dp)
                            } else {
                                Modifier.align(Alignment.TopEnd)
                            },
                            horizontalAlignment = Alignment.End
                        ) {
                            Text(
                                text = formatAmount(transaction.amount),
                                fontWeight = FontWeight.Bold,
                                color = transactionTypeColor.copy(alpha = alpha)
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (transaction.syncFailed) {
                                    IconButton(onClick = { viewModel.retrySync(context, transaction) }) {
                                        Icon(
                                            imageVector = Icons.Default.SyncProblem,
                                            contentDescription = "Retry Sync",
                                            tint = Color(0xFFD50000),
                                            modifier = Modifier.size(24.dp)
                                        )
                                    }
                                }
                                if (transaction.billImageUrl != null || (transaction.syncing && transaction.items.isNotEmpty()) || transaction.items.isNotEmpty()) {
                                    IconButton(onClick = { 
                                        viewModel.generatePdfAndGetPath(transaction, context) { path ->
                                            val encodedPath = URLEncoder.encode(path, StandardCharsets.UTF_8.name())
                                            val phone = viewModel.customer.value?.phoneNumber?.toString() ?: ""
                                            val name = viewModel.customer.value?.name ?: ""
                                            navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
                                        }
                                    }) {
                                        Icon(
                                            imageVector = Icons.Default.PictureAsPdf,
                                            contentDescription = "PDF",
                                            tint = if (transaction.type == "GOT") Color(0xFF008800) else Color(0xFFD50000),
                                            modifier = Modifier.size(26.dp).padding(top = 4.dp)
                                        )
                                    }
                                }
                            }
                            if (displayUrl != null) {
                                Card(
                                    modifier = Modifier
                                        .size(30.dp)
                                        .padding(top = 4.dp)
                                        .clickable { showFullPhoto = true },
                                    shape = RoundedCornerShape(4.dp),
                                    elevation = CardDefaults.cardElevation(2.dp)
                                ) {
                                    AsyncImage(
                                        model = displayUrl,
                                        contentDescription = "Photo Thumbnail",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            }
            if (transaction.paid) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "PAID - ${formatAmount(transaction.paidAmount)}",
                        color = Color.Gray,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(transaction.paidDate ?: 0)),
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ZoomableImage(
    model: Any?,
    onDismiss: () -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale *= zoomChange
        offset += offsetChange
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.Black
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .combinedClickable(
                        onClick = { onDismiss() },
                        onDoubleClick = {
                            scale = 1f
                            offset = Offset.Zero
                        }
                    )
            ) {
                AsyncImage(
                    model = model,
                    contentDescription = "Zoomable Image",
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer(
                            scaleX = scale.coerceIn(1f, 5f),
                            scaleY = scale.coerceIn(1f, 5f),
                            translationX = offset.x,
                            translationY = offset.y
                        )
                        .transformable(state = state),
                    contentScale = ContentScale.Fit
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.TopEnd).padding(16.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
            }
        }
    }
}
