package com.example.gstcalculator

import android.util.Log
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class UomViewModel : ViewModel() {
    private val _uoms = MutableStateFlow<List<String>>(emptyList())
    val uoms: StateFlow<List<String>> = _uoms

    private val database = FirebaseDatabase.getInstance().getReference("uoms")

    private val uomsListener = object : ValueEventListener {
        override fun onDataChange(dataSnapshot: DataSnapshot) {
            if (dataSnapshot.exists()) {
                val uomList = dataSnapshot.children.mapNotNull { it.key }.sorted()
                _uoms.value = uomList
            } else {
                _uoms.value = emptyList()
            }
        }

        override fun onCancelled(databaseError: DatabaseError) {
            // Getting Post failed, log a message
            Log.w("UomViewModel", "loadUoms:onCancelled", databaseError.toException())
        }
    }

    init {
        database.addValueEventListener(uomsListener)
    }

    override fun onCleared() {
        super.onCleared()
        database.removeEventListener(uomsListener)
    }

    fun addUom(uom: String) {
        if (uom.isNotBlank() && _uoms.value.none { it.equals(uom, ignoreCase = true) }) {
            database.child(uom).setValue(true)
        }
    }

    fun deleteUom(uom: String) {
        database.child(uom).removeValue()
    }
}
