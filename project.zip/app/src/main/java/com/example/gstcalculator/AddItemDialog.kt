package com.example.gstcalculator

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

@Composable
fun BulkDetailsPopup(
    initialText: String,
    onDismiss: () -> Unit,
    onSave: (List<String>) -> Unit
) {
    var text by remember { mutableStateOf(initialText) }
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Enter Details (One per line)", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    placeholder = { Text("e.g.\nRed\nBlue\nNo. 5") },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        val list = text.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                        onSave(list)
                    }) { Text("Save") }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddItemDialog(
    onDismiss: () -> Unit,
    onAddItem: (String, String, String, List<String>) -> Unit,
    uomViewModel: UomViewModel,
    onEditUomClicked: () -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var basePrice by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    val uoms by uomViewModel.uoms.collectAsState()
    var selectedUom by remember(uoms) { mutableStateOf(uoms.firstOrNull() ?: "") }
    val context = LocalContext.current
    
    var detailsList by remember { mutableStateOf<List<String>>(emptyList()) }
    var showBulkPopup by remember { mutableStateOf(false) }

    if (showBulkPopup) {
        BulkDetailsPopup(
            initialText = detailsList.joinToString("\n"),
            onDismiss = { showBulkPopup = false },
            onSave = {
                detailsList = it
                showBulkPopup = false
            }
        )
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Text(text = "Add Item", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }

                LazyColumn(modifier = Modifier.padding(16.dp).heightIn(max = 500.dp)) {
                    item {
                        TextField(
                            value = itemName,
                            onValueChange = { itemName = it },
                            label = { Text("Item Name") },
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedLabelColor = Color(0xFF1976D2),
                                focusedIndicatorColor = Color(0xFF1976D2)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        TextField(
                            value = basePrice,
                            onValueChange = { basePrice = it },
                            label = { Text("Base Price") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = Color.White,
                                unfocusedContainerColor = Color.White,
                                focusedLabelColor = Color(0xFF1976D2),
                                focusedIndicatorColor = Color(0xFF1976D2)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.weight(1f)) {
                                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                                    TextField(
                                        modifier = Modifier.fillMaxWidth().menuAnchor(),
                                        readOnly = true,
                                        value = selectedUom,
                                        onValueChange = {},
                                        label = { Text("UOM") },
                                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                                        colors = ExposedDropdownMenuDefaults.textFieldColors(
                                            focusedContainerColor = Color.White,
                                            unfocusedContainerColor = Color.White,
                                            focusedLabelColor = Color(0xFF1976D2),
                                            focusedIndicatorColor = Color(0xFF1976D2)
                                        ),
                                    )
                                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        uoms.forEach { uom ->
                                            DropdownMenuItem(text = { Text(uom) }, onClick = { selectedUom = uom; expanded = false })
                                        }
                                    }
                                }
                            }
                            IconButton(onClick = onEditUomClicked) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF1976D2))
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        Button(
                            onClick = { showBulkPopup = true },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE3F2FD), contentColor = Color(0xFF1976D2)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (detailsList.isEmpty()) "Add Item Details/Variants" else "${detailsList.size} Details Added (Edit)")
                        }
                        
                        Spacer(modifier = Modifier.height(24.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            androidx.compose.material3.TextButton(onClick = onDismiss) { Text("Cancel", color = Color.Gray) }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (itemName.isBlank()) { Toast.makeText(context, "Empty name", Toast.LENGTH_SHORT).show(); return@Button }
                                    onAddItem(itemName, basePrice, selectedUom, detailsList)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                            ) { Text("Add") }
                        }
                    }
                }
            }
        }
    }
}
