package com.example.gstcalculator

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.getValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class ItemViewModelFactory(private val screenName: String = "Shah Stores") : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ItemViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ItemViewModel(screenName) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

class ItemViewModel(private val screenName: String = "Shah Stores") : ViewModel() {
    private val _items = MutableStateFlow<List<Item>>(emptyList())
    val allItems: StateFlow<List<Item>> = _items

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery

    private val _sortOption = MutableStateFlow("A-Z")
    val sortOption: StateFlow<String> = _sortOption

    val filteredItems: StateFlow<List<Item>> = combine(_items, _searchQuery, _sortOption) { items, query, sortOption ->
        val searchedItems = if (query.isBlank()) {
            items
        } else {
            val searchWords = query.split(" ").filter { it.isNotBlank() }
            items.filter { item ->
                searchWords.all { word ->
                    item.name.contains(word, ignoreCase = true)
                }
            }
        }

        when (sortOption) {
            "A-Z" -> searchedItems.sortedWith(compareBy(AlphaNumericComparator) { it.name })
            "Lowest" -> searchedItems.sortedBy { it.basePrice }
            "Recent" -> searchedItems.sortedByDescending { it.id } 
            else -> searchedItems
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private val _selectedItemIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedItemIds: StateFlow<Set<String>> = _selectedItemIds

    private val database = if (screenName == "Shah Stores") {
        FirebaseDatabase.getInstance().getReference("items")
    } else {
        FirebaseDatabase.getInstance().getReference("custom_items").child(screenName)
    }
    
    private val auth = FirebaseAuth.getInstance()
    private var isListenerAttached = false

    private val authStateListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        if (firebaseAuth.currentUser != null) {
            if (!isListenerAttached) {
                attachDatabaseListener()
            }
        } else {
            detachDatabaseListener()
            _items.value = emptyList()
        }
    }

    private fun parseItem(dataSnapshot: DataSnapshot): Item? {
        try {
            val itemKey = dataSnapshot.key
            if (itemKey.isNullOrBlank()) return null
            
            val name = dataSnapshot.child("name").getValue(String::class.java) ?: ""
            val basePrice = (dataSnapshot.child("basePrice").value as? Number)?.toDouble() ?: 0.0
            val uom = dataSnapshot.child("uom").getValue(String::class.java) ?: ""
            val isDeleted = dataSnapshot.child("isDeleted").getValue(Boolean::class.java) ?: false
            
            val detailsList = mutableListOf<String>()
            dataSnapshot.child("details").children.forEach { child ->
                child.getValue(String::class.java)?.let { detailsList.add(it) }
            }

            val oldNamesList = mutableListOf<String>()
            dataSnapshot.child("oldNames").children.forEach { child ->
                child.getValue(String::class.java)?.let { oldNamesList.add(it) }
            }

            return Item(
                id = itemKey,
                name = name,
                basePrice = basePrice,
                uom = uom,
                isDeleted = isDeleted,
                details = detailsList.distinct().sortedWith(AlphaNumericComparator),
                oldNames = oldNamesList.distinct()
            )
        } catch (e: Exception) {
            Log.e("ItemViewModel", "Failed to parse item: ${dataSnapshot.key}", e)
        }
        return null
    }

    private val itemsChildListener = object : ChildEventListener {
        override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {
            val item = parseItem(snapshot)
            if (item != null && !item.isDeleted) {
                val currentList = _items.value.toMutableList()
                if (currentList.none { it.id == item.id }) {
                    currentList.add(item)
                    _items.value = currentList
                }
            }
        }

        override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
            val item = parseItem(snapshot)
            if (item != null) {
                val currentList = _items.value.toMutableList()
                val index = currentList.indexOfFirst { it.id == item.id }
                if (index != -1) { 
                    if (item.isDeleted) {
                        currentList.removeAt(index)
                    } else {
                        currentList[index] = item
                    }
                } else { 
                    if (!item.isDeleted) {
                        currentList.add(item)
                    }
                }
                _items.value = currentList
            }
        }

        override fun onChildRemoved(snapshot: DataSnapshot) {
            val item = parseItem(snapshot)
            if (item != null) {
                val updatedList = _items.value.toMutableList().apply { removeAll { it.id == item.id } }
                _items.value = updatedList
            }
        }

        override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {}

        override fun onCancelled(error: DatabaseError) {
            Log.e("ItemViewModel", "loadItems:onCancelled. Code: ${error.code}, Message: ${error.message}")
        }
    }


    init {
        auth.addAuthStateListener(authStateListener)
    }

    private fun attachDatabaseListener() {
        database.keepSynced(true)
        database.addChildEventListener(itemsChildListener)
        isListenerAttached = true
    }

    private fun detachDatabaseListener() {
        if (isListenerAttached) {
            database.removeEventListener(itemsChildListener)
            isListenerAttached = false
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun sortItems(option: String) {
        _sortOption.value = option
    }

    fun toggleItemSelection(itemId: String) {
        val currentSelection = _selectedItemIds.value.toMutableSet()
        if (currentSelection.contains(itemId)) {
            currentSelection.remove(itemId)
        } else {
            currentSelection.add(itemId)
        }
        _selectedItemIds.value = currentSelection
    }

    fun clearSelection() {
        _selectedItemIds.value = emptySet()
    }

    fun addItem(name: String, basePrice: String, uom: String, details: List<String>) {
        val price = basePrice.toDoubleOrNull() ?: return
        val id = database.push().key ?: return
        val itemMap = mapOf(
            "name" to name,
            "basePrice" to price,
            "uom" to uom,
            "isDeleted" to false,
            "details" to details.distinct().sortedWith(AlphaNumericComparator),
            "oldNames" to emptyList<String>()
        )
        database.child(id).setValue(itemMap)
    }

    fun addMultipleItems(items: List<Item>) {
        val itemsMap = items.associateBy { database.push().key!! }
            .mapValues { (_, item) ->
                mapOf(
                    "name" to item.name,
                    "basePrice" to item.basePrice,
                    "uom" to item.uom,
                    "isDeleted" to false,
                    "details" to item.details.distinct().sortedWith(AlphaNumericComparator),
                    "oldNames" to item.oldNames
                )
            }
        database.updateChildren(itemsMap)
    }

    fun updateItem(item: Item) {
        if (item.id.isBlank()) {
            Log.e("ItemViewModel", "updateItem called with a blank ID. Aborting.")
            return
        }
        val itemMap = mapOf(
            "name" to item.name,
            "basePrice" to item.basePrice,
            "uom" to item.uom,
            "isDeleted" to item.isDeleted,
            "details" to item.details.distinct().sortedWith(AlphaNumericComparator),
            "oldNames" to item.oldNames
        )
        database.child(item.id).setValue(itemMap)
    }

    fun addVariantToItem(itemId: String, variant: String) {
        if (itemId.isBlank() || variant.isBlank()) return
        val trimmedVariant = variant.trim()
        
        database.child(itemId).child("details").runTransaction(object : Transaction.Handler {
            override fun doTransaction(mutableData: MutableData): Transaction.Result {
                val currentDetails = mutableData.children.mapNotNull { it.getValue(String::class.java) }.toMutableList()
                if (!currentDetails.contains(trimmedVariant)) {
                    currentDetails.add(trimmedVariant)
                    mutableData.value = currentDetails.distinct().sortedWith(AlphaNumericComparator)
                    return Transaction.success(mutableData)
                }
                return Transaction.success(mutableData)
            }

            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (error != null) Log.e("ItemViewModel", "Transaction failed", error.toException())
            }
        })
    }

    fun deleteItem(itemId: String) {
        if (itemId.isNotBlank()) {
            database.child(itemId).child("isDeleted").setValue(true)
        }
    }

    fun deleteSelectedItems() {
        val selectedIds = _selectedItemIds.value
        if (selectedIds.isEmpty()) return
        
        val updates = selectedIds.associate { id ->
            "$id/isDeleted" to true
        }
        database.updateChildren(updates).addOnSuccessListener {
            clearSelection()
        }
    }

    private fun sanitizeKey(key: String): String {
        return key.replace(".", ",").replace("/", "__slash__")
    }

    private fun desanitizeKey(key: String): String {
        return key.replace(",", ".").replace("__slash__", "/")
    }

    suspend fun getSalesHistoryForItem(itemName: String, itemUom: String, itemId: String? = null, oldNames: List<String> = emptyList()): List<ItemSale> = withContext(Dispatchers.IO) {
        val historyMap = mutableMapOf<String, ItemSale>() // Key: CustomerName-CustomerID
        val categories = listOf("STAFF", "LOCALS", "HOME") + DataRepository.customScreens.value
        val allSearchNames = (listOf(itemName) + oldNames).distinct()
        val sanitizedNameKeys = allSearchNames.map { sanitizeKey("$it-$itemUom") }
        val sanitizedIdKey = itemId?.let { sanitizeKey(it) }

        // PERMANENT & INSTANT HISTORY: Scan strictly from itemRates
        for (category in categories) {
            try {
                val type = when(category) {
                    "STAFF" -> "customers_staff"
                    "LOCALS" -> "customers_locals"
                    "HOME" -> "customers_home"
                    else -> "custom_customers/$category"
                }
                val snap = FirebaseDatabase.getInstance().getReference(type).get().await()
                
                for (cSnap in snap.children) {
                    val name = cSnap.child("name").getValue(String::class.java) ?: continue
                    val cId = cSnap.key ?: ""
                    
                    val ratesSnap = cSnap.child("itemRates")
                    val rateSnap = sanitizedIdKey?.let { ratesSnap.child(it).takeIf { it.exists() } } 
                                  ?: sanitizedNameKeys.mapNotNull { ratesSnap.child(it).takeIf { it.exists() } }.firstOrNull()
                    
                    if (rateSnap != null) {
                        val rate = if (rateSnap.hasChild("rate")) rateSnap.child("rate").value.toString().toDoubleOrNull() ?: 0.0
                                  else rateSnap.value.toString().toDoubleOrNull() ?: 0.0
                        
                        val date = if (rateSnap.hasChild("date")) (rateSnap.child("date").value as? Number)?.toLong() ?: 0L else 0L
                        val isBill = rateSnap.child("isBill").getValue(Boolean::class.java) ?: false
                        
                        // Show any rate present in itemRates, ignoring the isBill constraint
                        if (rate > 0.0) {
                            historyMap["$name-$cId"] = ItemSale(name, rate, date, isBill = isBill)
                        }
                    }
                }
            } catch (e: Exception) {}
        }
        
        return@withContext historyMap.values.sortedByDescending { it.date }
    }

    override fun onCleared() {
        super.onCleared()
        auth.removeAuthStateListener(authStateListener)
        detachDatabaseListener()
    }
}
