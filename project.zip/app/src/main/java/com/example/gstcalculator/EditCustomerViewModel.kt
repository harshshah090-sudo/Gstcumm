package com.example.gstcalculator

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EditCustomerViewModel(context: Context, private val customerId: String, private val customerType: String) : ViewModel() {

    private val userPreferences = UserPreferences(context)
    private val database = when (customerType) {
        "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
        "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
        "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
        else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(customerType)
    }

    private val recycleBinDatabase = FirebaseDatabase.getInstance().getReference("recycle_bin")
    private val auth = FirebaseAuth.getInstance()

    private val _customer = MutableStateFlow<Customer?>(null)
    val customer = _customer.asStateFlow()

    var customerName by mutableStateOf("")
    var customerPhoneNumber by mutableStateOf("")
    val itemRates = mutableStateOf<Map<String, Map<String, Any>>>(emptyMap())
    val paymentReminderDays = mutableStateOf(userPreferences.getDefaultReminderDays())

    val adminId: String? get() = auth.currentUser?.uid

    init {
        loadCustomer()
        loadItemRates()
    }

    private fun sanitizeKey(key: String): String {
        return key.replace(".", ",").replace("/", "__slash__")
    }

    private fun desanitizeKey(key: String): String {
        return key.replace(",", ".").replace("__slash__", "/")
    }

    private fun loadItemRates() {
        database.child(customerId).child("itemRates").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val rates = snapshot.children.associate { 
                    val rate = if (it.hasChild("rate")) it.child("rate").value.toString() else it.value.toString()
                    val date = if (it.hasChild("date")) (it.child("date").value as? Number)?.toLong() ?: 0L else 0L
                    desanitizeKey(it.key!!) to mapOf("rate" to rate, "date" to date)
                }
                itemRates.value = rates
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun migrateItemRates(allItems: List<Item>) {
        if (allItems.isEmpty() || itemRates.value.isEmpty()) return
        
        viewModelScope.launch {
            val currentRates = itemRates.value
            val updates = mutableMapOf<String, Any?>()
            val now = System.currentTimeMillis()
            
            allItems.forEach { item ->
                val sanitizedId = sanitizeKey(item.id)
                val currentNameKey = "${item.name}-${item.uom}"
                
                if (!currentRates.containsKey(item.id)) {
                    if (currentRates.containsKey(currentNameKey)) {
                        val data = currentRates[currentNameKey]
                        if (data is Map<*, *>) {
                            updates[sanitizedId] = data
                        } else {
                            updates[sanitizedId] = mapOf("rate" to data?.toString(), "date" to now)
                        }
                        updates[sanitizeKey(currentNameKey)] = null
                    } else {
                        item.oldNames.forEach { oldName ->
                            val oldKey = "${oldName}-${item.uom}"
                            if (currentRates.containsKey(oldKey)) {
                                val data = currentRates[oldKey]
                                if (data is Map<*, *>) {
                                    updates[sanitizedId] = data
                                } else {
                                    updates[sanitizedId] = mapOf("rate" to data?.toString(), "date" to now)
                                }
                                updates[sanitizeKey(oldKey)] = null
                                return@forEach
                            }
                        }
                    }
                } else {
                    if (currentRates.containsKey(currentNameKey)) {
                        updates[sanitizeKey(currentNameKey)] = null
                    }
                    item.oldNames.forEach { oldName ->
                        val oldKey = "${oldName}-${item.uom}"
                        if (currentRates.containsKey(oldKey)) {
                            updates[sanitizeKey(oldKey)] = null
                        }
                    }
                }
            }
            
            if (updates.isNotEmpty()) {
                database.child(customerId).child("itemRates").updateChildren(updates)
            }
        }
    }

    private fun loadCustomer() {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val loadedCustomer = snapshot.getValue(Customer::class.java)
                loadedCustomer?.id = snapshot.key
                _customer.value = loadedCustomer
                loadedCustomer?.let {
                    customerName = it.name
                    customerPhoneNumber = it.phoneNumber?.toString() ?: ""
                    paymentReminderDays.value = if (it.paymentReminderDays == 0 || it.paymentReminderDays == null) {
                        userPreferences.getDefaultReminderDays()
                    } else {
                        it.paymentReminderDays!!
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun updateCustomer(onComplete: () -> Unit) {
        val cleanedPhone = cleanPhoneNumber(customerPhoneNumber)
        val customerUpdates = mapOf(
            "name" to customerName,
            "phoneNumber" to cleanedPhone,
            "paymentReminderDays" to paymentReminderDays.value
        )
        database.child(customerId).updateChildren(customerUpdates).addOnCompleteListener {
            onComplete()
        }
    }

    fun saveItemRate(itemKey: String, newRate: String) {
        val r = newRate.toDoubleOrNull()
        if (r != null && r > 0.0) {
            val existingData = itemRates.value[itemKey]
            val existingDate = (existingData?.get("date") as? Number)?.toLong() ?: 0L
            val now = System.currentTimeMillis()
            
            // SMART UPDATE: Only update if today is newer or equal to the stored date
            if (now >= existingDate) {
                val rateData = mapOf("rate" to newRate, "date" to now, "isBill" to false)
                database.child(customerId).child("itemRates").child(sanitizeKey(itemKey)).setValue(rateData)
            }
        } else if (newRate.isEmpty()) {
            database.child(customerId).child("itemRates").child(sanitizeKey(itemKey)).removeValue()
        }
    }

    fun deleteCustomer(onComplete: () -> Unit) {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customerData = snapshot.value
                if (customerData != null) {
                    val deletedCustomerData = mapOf(
                        "customer" to customerData,
                        "deletionDate" to System.currentTimeMillis()
                    )
                    recycleBinDatabase.child(customerId).setValue(deletedCustomerData).addOnSuccessListener {
                        database.child(customerId).removeValue().addOnSuccessListener {
                            onComplete()
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun clearAllTransactions(onComplete: () -> Unit) {
        database.child(customerId).child("transactions").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val updates = mutableMapOf<String, Any?>()
                    val now = System.currentTimeMillis()
                    
                    snapshot.children.forEach { tSnap ->
                        val transactionId = tSnap.key ?: return@forEach
                        val transactionData = tSnap.value
                        
                        // Structure like standard deleted transactions in transaction recycle bin
                        val deletedData = mapOf(
                            "transaction" to transactionData,
                            "deletionDate" to now
                        )
                        updates["/deleted_transactions/$customerId/$transactionId"] = deletedData
                    }
                    
                    // Remove active transactions and reset balance safely using references instead of restricted path API
                    FirebaseDatabase.getInstance().reference.updateChildren(updates).addOnCompleteListener {
                        database.child(customerId).child("transactions").removeValue().addOnCompleteListener {
                            onComplete()
                        }
                    }
                } else {
                    onComplete()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onComplete()
            }
        })
    }

    fun moveCustomer(onComplete: (String) -> Unit) {
        val targetCustomerType = if (customerType == "HOME") "LOCALS" else "HOME"
        val targetDatabase = if (customerType == "HOME") {
            FirebaseDatabase.getInstance().getReference("customers_locals")
        } else {
            FirebaseDatabase.getInstance().getReference("customers_home")
        }

        database.child(customerId).addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customerData = snapshot.value
                if (customerData != null) {
                    targetDatabase.child(customerId).setValue(customerData).addOnSuccessListener {
                        database.child(customerId).removeValue().addOnSuccessListener {
                            onComplete(targetCustomerType)
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }
}

class EditCustomerViewModelFactory(private val context: Context, private val customerId: String, private val customerType: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EditCustomerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EditCustomerViewModel(context, customerId, customerType) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
