package com.example.gstcalculator

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class EditCustomerViewModel(context: Context, private val customerId: String, private val customerType: String) : ViewModel() {

    private val userPreferences = UserPreferences(context)
    private val database = when (customerType) {
        "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
        "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
        "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
        else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(customerType)
    }

    private val recycleBinDatabase = FirebaseDatabase.getInstance().getReference("recycle_bin")
    private val auth = FirebaseAuth.getInstance()

    private val _customer = MutableStateFlow<Customer?>(null)
    val customer = _customer.asStateFlow()

    var customerName by mutableStateOf("")
    var customerPhoneNumber by mutableStateOf("")
    val itemRates = mutableStateOf<Map<String, Map<String, Any>>>(emptyMap())
    val paymentReminderDays = mutableStateOf(userPreferences.getDefaultReminderDays())

    val adminId: String? get() = auth.currentUser?.uid

    init {
        loadCustomer()
        loadItemRates()
    }

    private fun sanitizeKey(key: String): String {
        return key.replace(".", ",").replace("/", "__slash__")
    }

    private fun desanitizeKey(key: String): String {
        return key.replace(",", ".").replace("__slash__", "/")
    }

    private fun loadItemRates() {
        database.child(customerId).child("itemRates").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val rates = snapshot.children.associate { 
                    val rate = if (it.hasChild("rate")) it.child("rate").value.toString() else it.value.toString()
                    val date = if (it.hasChild("date")) (it.child("date").value as? Number)?.toLong() ?: 0L else 0L
                    desanitizeKey(it.key!!) to mapOf("rate" to rate, "date" to date)
                }
                itemRates.value = rates
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun migrateItemRates(allItems: List<Item>) {
        if (allItems.isEmpty()) return
        
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val transactionsSnap = database.child(customerId).child("transactions").get().await()
                val ratesSnap = database.child(customerId).child("itemRates").get().await()

                val allBills = transactionsSnap.children.mapNotNull { snap ->
                    val t = snap.getValue(Transaction::class.java)
                    t?.id = snap.key
                    if (t != null && t.items.isEmpty() && snap.hasChild("items")) {
                        t.items = snap.child("items").children.mapNotNull { it.getValue(BillItem::class.java) }
                    }
                    t
                }.filter { it.type == "GAVE" }.sortedByDescending { it.date ?: 0L }

                val itemByNameUom = allItems.associateBy { "${it.name}-${it.uom}" }

                val latestRatesFromBills = mutableMapOf<String, MutableMap<String, Any?>>()
                val nameKeyToIdMap = mutableMapOf<String, String>()

                // 1. Collect all existing rates from ratesSnap as permanent baseline
                val permanentRates = mutableMapOf<String, MutableMap<String, Any?>>()
                val existingRateKeys = mutableSetOf<String>()

                for (rateChild in ratesSnap.children) {
                    val rawKey = rateChild.key ?: continue
                    if (rawKey == "history") continue
                    existingRateKeys.add(rawKey)
                    val desanitized = desanitizeKey(rawKey)
                    val r = rateChild.child("rate").value?.toString() ?: ""
                    val d = (rateChild.child("date").value as? Number)?.toLong() ?: 0L
                    val q = rateChild.child("qty").value?.toString() ?: ""
                    if (r.isNotEmpty() && (r.toDoubleOrNull() ?: 0.0) > 0.0) {
                        permanentRates[desanitized] = mutableMapOf(
                            "rate" to r,
                            "date" to d,
                            "qty" to q,
                            "isBill" to false // Permanent customer rate
                        )
                    }
                }

                for (bill in allBills) {
                    val billDate = bill.date ?: 0L
                    for (item in bill.items) {
                        val r = item.rate.toDoubleOrNull() ?: 0.0
                        if (r <= 0.0) continue

                        val resolvedId = if (item.itemId.isNotBlank()) item.itemId 
                            else (itemByNameUom["${item.name}-${item.uom}"]?.id ?: "")
                        val nameKey = "${item.name}-${item.uom}"
                        if (resolvedId.isNotBlank()) {
                            nameKeyToIdMap[nameKey] = resolvedId
                        }

                        val canonicalKey = if (resolvedId.isNotBlank()) resolvedId else nameKey
                        if (!latestRatesFromBills.containsKey(canonicalKey)) {
                            val existing = permanentRates[canonicalKey]
                                ?: (if (resolvedId.isNotBlank()) permanentRates[resolvedId] else null)
                                ?: permanentRates[nameKey]
                            val existingDate = (existing?.get("date") as? Number)?.toLong() ?: 0L

                            // If active bill is newer or equal, active bill sets the rate
                            if (billDate >= existingDate) {
                                latestRatesFromBills[canonicalKey] = mutableMapOf(
                                    "rate" to item.rate,
                                    "date" to billDate,
                                    "qty" to item.getQtyString(),
                                    "isBill" to true,
                                    "itemId" to resolvedId
                                )
                            } else {
                                // Existing rate is newer (from a deleted bill or manual rate), keep it!
                                latestRatesFromBills[canonicalKey] = existing!!
                            }
                        }
                    }
                }

                // Preserve all rates from deleted bills or manual entry
                for ((key, data) in permanentRates) {
                    if (!latestRatesFromBills.containsKey(key)) {
                        val mappedId = nameKeyToIdMap[key]
                        if (mappedId == null || !latestRatesFromBills.containsKey(mappedId)) {
                            latestRatesFromBills[key] = data
                        }
                    }
                }

                val updates = mutableMapOf<String, Any?>()
                for ((key, data) in latestRatesFromBills) {
                    val sanitized = sanitizeKey(key)
                    val rateStr = data["rate"]?.toString() ?: ""
                    val dateVal = (data["date"] as? Number)?.toLong() ?: 0L
                    val qtyVal = data["qty"]?.toString() ?: ""
                    val isBillVal = data["isBill"] as? Boolean ?: true

                    val currentValOnDb = ratesSnap.child(sanitized)
                    val currentRateOnDb = currentValOnDb.child("rate").value?.toString()
                    val currentDateOnDb = (currentValOnDb.child("date").value as? Number)?.toLong() ?: 0L

                    if (currentRateOnDb != rateStr || currentDateOnDb != dateVal) {
                        updates["$sanitized/rate"] = rateStr
                        updates["$sanitized/date"] = dateVal
                        updates["$sanitized/qty"] = qtyVal
                        updates["$sanitized/isBill"] = isBillVal
                    }

                    val idVal = data["itemId"]?.toString() ?: ""
                    if (idVal.isNotBlank()) {
                        for ((nameKey, mappedId) in nameKeyToIdMap) {
                            if (mappedId == idVal) {
                                val sanitizedName = sanitizeKey(nameKey)
                                if (sanitizedName != sanitized && existingRateKeys.contains(sanitizedName)) {
                                    updates[sanitizedName] = null
                                }
                            }
                        }
                    }
                }

                if (updates.isNotEmpty()) {
                    database.child(customerId).child("itemRates").updateChildren(updates).await()
                }
            } catch (e: Exception) {
                // Ignore
            }
        }
    }

    private fun loadCustomer() {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val loadedCustomer = snapshot.getValue(Customer::class.java)
                loadedCustomer?.id = snapshot.key
                _customer.value = loadedCustomer
                loadedCustomer?.let {
                    customerName = it.name
                    customerPhoneNumber = it.phoneNumber?.toString() ?: ""
                    paymentReminderDays.value = if (it.paymentReminderDays == 0 || it.paymentReminderDays == null) {
                        userPreferences.getDefaultReminderDays()
                    } else {
                        it.paymentReminderDays!!
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun updateCustomer(onComplete: () -> Unit) {
        val cleanedPhone = cleanPhoneNumber(customerPhoneNumber)
        val customerUpdates = mapOf(
            "name" to customerName,
            "phoneNumber" to cleanedPhone,
            "paymentReminderDays" to paymentReminderDays.value
        )
        database.child(customerId).updateChildren(customerUpdates).addOnCompleteListener {
            onComplete()
        }
    }

    fun saveItemRate(itemKey: String, newRate: String) {
        val r = newRate.toDoubleOrNull()
        val sanitized = sanitizeKey(itemKey)
        if (r != null && r > 0.0) {
            val now = System.currentTimeMillis()
            val rateData = mapOf("rate" to newRate, "date" to now, "isBill" to false)
            database.child(customerId).child("itemRates").child(sanitized).setValue(rateData)
        } else if (newRate.isEmpty()) {
            database.child(customerId).child("itemRates").child(sanitized).removeValue()
        }
    }

    fun deleteCustomer(onComplete: () -> Unit) {
        database.child(customerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customerData = snapshot.value
                if (customerData != null) {
                    val deletedCustomerData = mapOf(
                        "customer" to customerData,
                        "deletionDate" to System.currentTimeMillis()
                    )
                    recycleBinDatabase.child(customerId).setValue(deletedCustomerData).addOnSuccessListener {
                        database.child(customerId).removeValue().addOnSuccessListener {
                            onComplete()
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }

    fun clearAllTransactions(onComplete: () -> Unit) {
        database.child(customerId).child("transactions").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val updates = mutableMapOf<String, Any?>()
                    val now = System.currentTimeMillis()
                    
                    snapshot.children.forEach { tSnap ->
                        val transactionId = tSnap.key ?: return@forEach
                        val transactionData = tSnap.value
                        
                        // Structure like standard deleted transactions in transaction recycle bin
                        val deletedData = mapOf(
                            "transaction" to transactionData,
                            "deletionDate" to now
                        )
                        updates["/deleted_transactions/$customerId/$transactionId"] = deletedData
                    }
                    
                    // Remove active transactions and reset balance safely using references instead of restricted path API
                    FirebaseDatabase.getInstance().reference.updateChildren(updates).addOnCompleteListener {
                        database.child(customerId).child("transactions").removeValue().addOnCompleteListener {
                            database.child(customerId).child("itemRates").addListenerForSingleValueEvent(object : ValueEventListener {
                                override fun onDataChange(ratesSnap: DataSnapshot) {
                                    val rateUpdates = mutableMapOf<String, Any?>()
                                    for (c in ratesSnap.children) {
                                        val isBill = c.child("isBill").getValue(Boolean::class.java) ?: false
                                        if (isBill) rateUpdates[c.key!!] = null
                                    }
                                    if (rateUpdates.isNotEmpty()) {
                                        database.child(customerId).child("itemRates").updateChildren(rateUpdates)
                                    }
                                }
                                override fun onCancelled(error: DatabaseError) {}
                            })
                            onComplete()
                        }
                    }
                } else {
                    onComplete()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onComplete()
            }
        })
    }

    fun moveCustomer(onComplete: (String) -> Unit) {
        val targetCustomerType = if (customerType == "HOME") "LOCALS" else "HOME"
        val targetDatabase = if (customerType == "HOME") {
            FirebaseDatabase.getInstance().getReference("customers_locals")
        } else {
            FirebaseDatabase.getInstance().getReference("customers_home")
        }

        database.child(customerId).addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val customerData = snapshot.value
                if (customerData != null) {
                    targetDatabase.child(customerId).setValue(customerData).addOnSuccessListener {
                        database.child(customerId).removeValue().addOnSuccessListener {
                            onComplete(targetCustomerType)
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error
            }
        })
    }
}

class EditCustomerViewModelFactory(private val context: Context, private val customerId: String, private val customerType: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EditCustomerViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EditCustomerViewModel(context, customerId, customerType) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
