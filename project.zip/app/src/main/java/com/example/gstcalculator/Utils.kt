package com.example.gstcalculator

import java.text.DecimalFormat

fun formatAmount(amount: Double?): String {
    if (amount == null) return "₹0"
    val formatter = if (amount % 1 == 0.0) {
        DecimalFormat("#,##,##0")
    } else {
        DecimalFormat("#,##,##0.00")
    }
    return "₹${formatter.format(amount)}"
}

object AlphaNumericComparator : Comparator<String> {
    override fun compare(s1: String, s2: String): Int {
        var i = 0
        var j = 0
        while (i < s1.length && j < s2.length) {
            val char1 = s1[i]
            val char2 = s2[j]

            if (char1.isDigit() && char2.isDigit()) {
                val num1 = getChunk(s1, i)
                val num2 = getChunk(s2, j)
                
                // If the digits are preceded by a dot that follows a digit, 
                // treat them as a fractional part of a decimal.
                val isFraction1 = i > 0 && s1[i - 1] == '.' && i > 1 && s1[i - 2].isDigit()
                val isFraction2 = j > 0 && s2[j - 1] == '.' && j > 1 && s2[j - 2].isDigit()

                val result = if (isFraction1 && isFraction2) {
                    num1.compareTo(num2)
                } else {
                    compareNumbers(num1, num2)
                }
                
                if (result != 0) return result
                i += num1.length
                j += num2.length
            } else {
                val result = char1.lowercaseChar().compareTo(char2.lowercaseChar())
                if (result != 0) return result
                i++
                j++
            }
        }
        return s1.length - s2.length
    }

    private fun getChunk(s: String, startIndex: Int): String {
        val chunk = StringBuilder()
        var i = startIndex
        while (i < s.length && s[i].isDigit()) {
            chunk.append(s[i])
            i++
        }
        return chunk.toString()
    }

    private fun compareNumbers(num1: String, num2: String): Int {
        return if (num1.length != num2.length) {
            num1.length - num2.length
        } else {
            num1.compareTo(num2)
        }
    }
}
