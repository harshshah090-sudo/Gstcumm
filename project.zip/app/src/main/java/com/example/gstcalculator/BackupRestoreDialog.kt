package com.example.gstcalculator

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.functions.FirebaseFunctions

@Composable
fun BackupRestoreDialog(
    onDismiss: () -> Unit,
    backupManager: AppDataBackupManager,
    context: Context
) {
    val backupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json"),
        onResult = { uri: Uri? ->
            uri?.let {
                backupManager.backup(it,
                    onSuccess = { Toast.makeText(context, "Backup successful", Toast.LENGTH_SHORT).show() },
                    onError = { errorMessage -> Toast.makeText(context, "Backup failed: $errorMessage", Toast.LENGTH_SHORT).show() }
                )
            }
            onDismiss()
        }
    )

    val restoreLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let {
                backupManager.restore(it,
                    onSuccess = { Toast.makeText(context, "Restore successful", Toast.LENGTH_SHORT).show() },
                    onError = { errorMessage -> Toast.makeText(context, "Restore failed: $errorMessage", Toast.LENGTH_SHORT).show() }
                )
            }
            onDismiss()
        }
    )

    var isEmailLoading by remember { mutableStateOf(false) }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Backup & Restore",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }
                Column(modifier = Modifier.padding(16.dp)) {
                    Button(
                        onClick = { backupLauncher.launch("backup.json") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Backup Now (Local)")
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { restoreLauncher.launch("application/json") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Restore (Local)")
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    // Manual Email Backup Button
                    Button(
                        onClick = {
                            isEmailLoading = true
                            FirebaseFunctions.getInstance("us-central1")
                                .getHttpsCallable("triggerManualBackup")
                                .call()
                                .addOnSuccessListener {
                                    isEmailLoading = false
                                    Toast.makeText(context, "Full Backup sent to email successfully", Toast.LENGTH_LONG).show()
                                }
                                .addOnFailureListener { e ->
                                    isEmailLoading = false
                                    Toast.makeText(context, "Failed: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                        enabled = !isEmailLoading,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        if (isEmailLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(24.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Send Data Backup to Email")
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(20.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color.Gray)
                        }
                    }
                }
            }
        }
    }
}
