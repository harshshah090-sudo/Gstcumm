package com.example.gstcalculator

import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar

data class CustomerSalesData(
    val customerId: String,
    val customerName: String,
    val cashReceived: Double,
    val totalSales: Double,
    val customerType: String
)

data class YearMonth(val year: Int, val month: Int) // Month is 0-indexed (0=Jan)

class SalesAndCashReceivedViewModel : ViewModel() {
    private val _customers = mutableStateOf<List<Customer>>(emptyList())
    private val _allTransactions = mutableStateOf<List<Transaction>>(emptyList())
    
    val searchQuery = mutableStateOf("")
    val selectedMonths = mutableStateOf<Set<YearMonth>>(emptySet())
    
    // Set of months that actually contain transactions to disable others in picker
    val availableMonths = derivedStateOf {
        val months = mutableSetOf<YearMonth>()
        val cal = Calendar.getInstance()
        _allTransactions.value.forEach { t ->
            t.date?.let { date ->
                cal.timeInMillis = date
                months.add(YearMonth(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)))
            }
        }
        months
    }

    init {
        // Default to current month
        val cal = Calendar.getInstance()
        selectedMonths.value = setOf(YearMonth(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)))
        
        fetchAllData()
    }

    private fun fetchAllData() {
        val databases = listOf("customers_home", "customers_locals")
        val combinedCustomers = mutableListOf<Customer>()
        val combinedTransactions = mutableListOf<Transaction>()
        
        var loadedCount = 0
        databases.forEach { dbName ->
            FirebaseDatabase.getInstance().getReference(dbName).addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (customerSnap in snapshot.children) {
                        val customer = customerSnap.getValue(Customer::class.java)
                        customer?.id = customerSnap.key
                        customer?.customerType = if (dbName == "customers_home") "HOME" else "LOCALS"
                        if (customer != null) {
                            combinedCustomers.add(customer)
                            val transactionsSnap = customerSnap.child("transactions")
                            for (tSnap in transactionsSnap.children) {
                                val t = tSnap.getValue(Transaction::class.java)
                                if (t != null) {
                                    t.customerId = customer.id
                                    combinedTransactions.add(t)
                                }
                            }
                        }
                    }
                    loadedCount++
                    if (loadedCount == databases.size) {
                        _customers.value = combinedCustomers.distinctBy { it.id }
                        _allTransactions.value = combinedTransactions
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    val filteredCustomerSalesData = derivedStateOf {
        val months = selectedMonths.value
        if (months.isEmpty()) return@derivedStateOf emptyList<CustomerSalesData>()
        
        val query = searchQuery.value
        val cal = Calendar.getInstance()
        
        val transactionMap = _allTransactions.value
            .filter { t ->
                t.date?.let { date ->
                    cal.timeInMillis = date
                    YearMonth(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH)) in months
                } ?: false
            }
            .groupBy { it.customerId }

        _customers.value
            .filter { it.name.contains(query, ignoreCase = true) }
            .map { customer ->
                val transactions = transactionMap[customer.id] ?: emptyList()
                var cashReceived = 0.0
                var totalSales = 0.0
                
                transactions.forEach { t ->
                    val amount = t.amount ?: 0.0
                    if (t.type == "GOT") {
                        cashReceived += amount
                    }
                    if (t.type == "GAVE" && t.paid) {
                        cashReceived += amount
                    }
                    if (t.type == "GAVE") {
                        totalSales += amount
                    }
                }
                CustomerSalesData(
                    customerId = customer.id ?: "",
                    customerName = customer.name,
                    cashReceived = cashReceived,
                    totalSales = totalSales,
                    customerType = customer.customerType
                )
            }
            .filter { it.cashReceived != 0.0 || it.totalSales != 0.0 }
            .sortedByDescending { it.totalSales + it.cashReceived }
    }

    val summaryData = derivedStateOf {
        val data = filteredCustomerSalesData.value
        val totalCash = data.sumOf { it.cashReceived }
        val totalSales = data.sumOf { it.totalSales }
        Pair(totalCash, totalSales)
    }

    fun onSearchQueryChanged(newQuery: String) {
        searchQuery.value = newQuery
    }

    fun toggleMonth(yearMonth: YearMonth) {
        val current = selectedMonths.value.toMutableSet()
        if (yearMonth in current) {
            current.remove(yearMonth)
        } else {
            current.add(yearMonth)
        }
        selectedMonths.value = current
    }
}
