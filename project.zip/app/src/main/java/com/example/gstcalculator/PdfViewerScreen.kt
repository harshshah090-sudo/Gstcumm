package com.example.gstcalculator

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.provider.ContactsContract
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import java.io.File
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    navController: NavController,
    pdfPath: String,
    phoneNumber: String?,
    customerName: String?
) {
    val context = LocalContext.current
    val pdfFile = File(pdfPath)
    val bitmaps = remember(pdfPath) { renderPdfToBitmaps(context, pdfFile) }

    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 5f)
        offset += offsetChange
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(Manifest.permission.READ_CONTACTS)
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    var pendingPdfShare by remember { mutableStateOf(false) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (pendingPdfShare) {
                    pendingPdfShare = false
                    sharePdfFileToWhatsApp(context, pdfFile, phoneNumber, customerName)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val appHeaderColor = Color(0xFF1976D2)
    val lightGreyWorkspace = Color(0xFFE0E0E0)
    val whatsappGreen = Color(0xFF25D366)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Bill Preview", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = appHeaderColor)
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(lightGreyWorkspace)
        ) {
            // PDF Content with Zoom
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .transformable(state = state)
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offset.x,
                        translationY = offset.y
                    ),
                contentAlignment = Alignment.TopCenter
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(bitmaps) { bitmap ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White)
                                .border(0.5.dp, Color.Black)
                        ) {
                            Image(
                                bitmap = bitmap.asImageBitmap(),
                                contentDescription = "PDF Page",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .wrapContentHeight(),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                    }
                }
            }

            // Bottom Pill UI
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 24.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // WhatsApp Button
                    IconButton(
                        modifier = Modifier.size(32.dp),
                        onClick = {
                            val isSaved = isContactSaved(context, phoneNumber)
                            val digitsOnly = phoneNumber?.replace(Regex("\\D"), "") ?: ""
                            val formattedPhone = when {
                                digitsOnly.length == 10 -> "91$digitsOnly"
                                digitsOnly.length == 12 && digitsOnly.startsWith("91") -> digitsOnly
                                digitsOnly.length > 10 -> digitsOnly
                                digitsOnly.isNotEmpty() -> digitsOnly
                                else -> null
                            }

                            if (isSaved || formattedPhone == null) {
                                // Saved contact -> Directly send the bill PDF
                                sharePdfFileToWhatsApp(context, pdfFile, phoneNumber, customerName)
                            } else {
                                // Unsaved contact -> Open direct WhatsApp chat with "Your Bill" text first, then attach PDF on return
                                pendingPdfShare = true
                                openDirectWhatsAppChat(context, formattedPhone)
                            }
                        }
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.whatsapp_share_icon),
                            contentDescription = "WhatsApp",
                            tint = whatsappGreen,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    VerticalDivider(modifier = Modifier.height(20.dp), thickness = 1.dp, color = Color.LightGray)

                    // Print Button
                    IconButton(
                        modifier = Modifier.size(32.dp),
                        onClick = {
                            printPdf(context, pdfFile)
                        }
                    ) {
                        Icon(
                            Icons.Default.Print,
                            contentDescription = "Print",
                            tint = appHeaderColor,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

private fun renderPdfToBitmaps(context: Context, file: File): List<Bitmap> {
    val bitmaps = mutableListOf<Bitmap>()
    try {
        val parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val renderer = PdfRenderer(parcelFileDescriptor)
        val pageCount = renderer.pageCount
        for (i in 0 until pageCount) {
            val page = renderer.openPage(i)
            // Use 3x resolution for better quality and transparency handling
            val bitmap = Bitmap.createBitmap(page.width * 3, page.height * 3, Bitmap.Config.ARGB_8888)
            // Ensure white background before rendering
            bitmap.eraseColor(android.graphics.Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bitmaps.add(bitmap)
            page.close()
        }
        renderer.close()
    } catch (e: Exception) {
        e.printStackTrace()
    }
    return bitmaps
}

private fun printPdf(context: Context, file: File) {
    if (!file.exists()) {
        Toast.makeText(context, "PDF file not found. Please try opening the bill again.", Toast.LENGTH_SHORT).show()
        return
    }
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    val printAdapter = object : PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback?,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onLayoutCancelled()
                return
            }
            val info = PrintDocumentInfo.Builder(file.name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .build()
            callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback?
        ) {
            try {
                file.inputStream().use { input ->
                    ParcelFileDescriptor.AutoCloseOutputStream(destination).use { output ->
                        input.copyTo(output)
                    }
                }
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback?.onWriteFailed(e.message)
            }
        }
    }
    printManager.print("Bill Print", printAdapter, PrintAttributes.Builder().build())
}

private fun isContactSaved(context: Context, phoneNumber: String?): Boolean {
    if (phoneNumber.isNullOrBlank()) return false
    val digitsOnly = phoneNumber.replace(Regex("\\D"), "")
    if (digitsOnly.length < 10) return false
    val searchPhone = digitsOnly.takeLast(10)

    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
        return false
    }

    return try {
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val selection = "${ContactsContract.CommonDataKinds.Phone.NUMBER} LIKE ?"
        val selectionArgs = arrayOf("%$searchPhone%")

        context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            cursor.count > 0
        } ?: false
    } catch (e: Exception) {
        e.printStackTrace()
        false
    }
}

private fun openDirectWhatsAppChat(
    context: Context,
    formattedPhone: String
) {
    val messageText = "Your Bill"

    val encodedMessage = try {
        URLEncoder.encode(messageText, StandardCharsets.UTF_8.name())
    } catch (e: Exception) {
        ""
    }

    val url = "https://api.whatsapp.com/send?phone=$formattedPhone&text=$encodedMessage"
    val uri = Uri.parse(url)

    val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
    var launched = false

    for (pkg in packages) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage(pkg)
                if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            launched = true
            break
        } catch (e: Exception) {}
    }

    if (!launched) {
        try {
            val genericIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(genericIntent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp is not installed on this device", Toast.LENGTH_SHORT).show()
        }
    }
}

private fun sharePdfFileToWhatsApp(
    context: Context,
    file: File,
    phoneNumber: String?,
    customerName: String?
) {
    if (!file.exists()) {
        Toast.makeText(context, "PDF file not found. Please try opening the bill again.", Toast.LENGTH_SHORT).show()
        return
    }

    val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
    val digitsOnly = phoneNumber?.replace(Regex("\\D"), "") ?: ""
    val formattedPhone = when {
        digitsOnly.length == 10 -> "91$digitsOnly"
        digitsOnly.length == 12 && digitsOnly.startsWith("91") -> digitsOnly
        digitsOnly.length > 10 -> digitsOnly
        digitsOnly.isNotEmpty() -> digitsOnly
        else -> null
    }

    val baseSendIntent = Intent(Intent.ACTION_SEND).apply {
        type = "application/pdf"
        putExtra(Intent.EXTRA_STREAM, uri)
        if (formattedPhone != null) {
            putExtra("jid", "$formattedPhone@s.whatsapp.net")
            putExtra("phone", formattedPhone)
            putExtra("address", formattedPhone)
            putExtra(Intent.EXTRA_PHONE_NUMBER, formattedPhone)
        }
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        clipData = ClipData.newRawUri("Bill", uri)
    }

    val packages = listOf("com.whatsapp", "com.whatsapp.w4b")
    for (pkg in packages) {
        context.grantUriPermission(pkg, uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }

    var launched = false
    if (formattedPhone != null) {
        for (pkg in packages) {
            try {
                val sendIntent = Intent(baseSendIntent).apply {
                    setPackage(pkg)
                    if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(sendIntent)
                launched = true
                break
            } catch (e: Exception) {}
        }
    }

    if (!launched) {
        for (pkg in packages) {
            try {
                val genericIntent = Intent(baseSendIntent).apply {
                    setPackage(pkg)
                    if (context !is Activity) addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(genericIntent)
                launched = true
                break
            } catch (e: Exception) {}
        }
    }

    if (!launched) {
        val chooser = Intent.createChooser(baseSendIntent, "Share Bill")
        if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
