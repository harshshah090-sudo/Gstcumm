package com.example.gstcalculator

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun SalesAndCashReceivedScreen(
    navController: NavController,
    viewModel: SalesAndCashReceivedViewModel = viewModel()
) {
    val searchQuery by viewModel.searchQuery
    val customerSalesData by viewModel.filteredCustomerSalesData
    val summaryData by viewModel.summaryData
    val selectedMonths by viewModel.selectedMonths
    var showMonthPicker by remember { mutableStateOf(false) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    val displayDate = remember(selectedMonths) {
        if (selectedMonths.isEmpty()) "Select Month"
        else {
            val list = selectedMonths.toList().sortedWith(compareBy<YearMonth> { it.year }.thenBy { it.month })
            val sdf = SimpleDateFormat("MMM yy", Locale.getDefault())
            val cal = Calendar.getInstance()
            list.joinToString(", ") { 
                cal.set(it.year, it.month, 1)
                sdf.format(cal.time)
            }
        }
    }

    if (showMonthPicker) {
        MonthPickerDialog(
            availableMonths = viewModel.availableMonths.value,
            selectedMonths = selectedMonths,
            onMonthToggle = { viewModel.toggleMonth(it) },
            onDismiss = { showMonthPicker = false }
        )
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .background(Color(0xFF1976D2))
                    .zIndex(1f) // Ensure summary and search bar stay on top during bounce
            ) {
                TopAppBar(
                    title = { Text("Sales & Cash Received", color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { navController.popBackStack() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )

                // 1. Summary Card (Swapped to Top)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp, horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            @OptIn(ExperimentalMaterial3Api::class)
                            Text("Cash Received", color = Color.Black, fontSize = 12.sp)
                            RollingAmount(
                                amount = summaryData.first,
                                color = Color(0xFF008800),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        VerticalDivider(modifier = Modifier.height(40.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            @OptIn(ExperimentalMaterial3Api::class)
                            Text("Total Sales", color = Color.Black, fontSize = 12.sp)
                            RollingAmount(
                                amount = summaryData.second,
                                color = Color(0xFFD50000),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // 2. Search Bar and Month Selector (Swapped to Bottom)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp, top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .weight(1f)
                            .height(40.dp),
                        textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        decorationBox = { innerTextField ->
                            Row(
                                modifier = Modifier
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .padding(horizontal = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray)
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                    if (searchQuery.isEmpty()) Text("Search Customer", color = Color.Gray, fontSize = 14.sp)
                                    innerTextField()
                                }
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.onSearchQueryChanged("") }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Clear, contentDescription = null, tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { showMonthPicker = true },
                        modifier = Modifier.height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Icon(Icons.Default.DateRange, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        @OptIn(ExperimentalMaterial3Api::class)
                        Text(
                            displayDate, 
                            color = Color(0xFF1976D2), 
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 100.dp)
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentPadding = PaddingValues(vertical = 8.dp)
        ) {
            items(customerSalesData, key = { it.customerId }) { data ->
                SalesDataItem(
                    modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                    data = data,
                    onClick = {
                        navController.navigate("transaction/${data.customerId}/${data.customerType}")
                    }
                )
                HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp), color = Color.Black.copy(alpha = 0.08f))
            }
        }
    }
}

@Composable
fun MonthPickerDialog(
    availableMonths: Set<YearMonth>,
    selectedMonths: Set<YearMonth>,
    onMonthToggle: (YearMonth) -> Unit,
    onDismiss: () -> Unit
) {
    var currentYear by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR)) }
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column {
                // Header with Year and Arrows
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { currentYear-- }) {
                            Icon(Icons.Default.ChevronLeft, contentDescription = "Prev Year", tint = Color.White)
                        }
                        Text(
                            text = currentYear.toString(),
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = { currentYear++ }) {
                            Icon(Icons.Default.ChevronRight, contentDescription = "Next Year", tint = Color.White)
                        }
                    }
                }

                // Month Grid
                Column(modifier = Modifier.padding(16.dp)) {
                    val chunkedMonths = months.chunked(3)
                    chunkedMonths.forEachIndexed { rowIndex, rowMonths ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            rowMonths.forEachIndexed { colIndex, monthName ->
                                val monthIdx = rowIndex * 3 + colIndex
                                val yearMonth = YearMonth(currentYear, monthIdx)
                                val isSelected = yearMonth in selectedMonths
                                val isEnabled = yearMonth in availableMonths
                                
                                OutlinedButton(
                                    onClick = { onMonthToggle(yearMonth) },
                                    enabled = isEnabled,
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (isSelected) Color(0xFF1976D2) else Color.Transparent,
                                        contentColor = if (isSelected) Color.White else if (isEnabled) Color(0xFF1976D2) else Color.LightGray,
                                        disabledContentColor = Color.LightGray
                                    ),
                                    border = if (isEnabled) BorderStroke(1.dp, Color(0xFF1976D2)) else BorderStroke(1.dp, Color.LightGray),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    @OptIn(ExperimentalMaterial3Api::class)
                                    Text(monthName, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        @OptIn(ExperimentalMaterial3Api::class)
                        Text("Done")
                    }
                }
            }
        }
    }
}

@Composable
fun SalesDataItem(
    modifier: Modifier = Modifier,
    data: CustomerSalesData,
    onClick: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(data.customerName, fontWeight = FontWeight.Medium, fontSize = 16.sp)
                if (data.customerType == "LOCALS") {
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        "Locals",
                        color = Color.Red,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(Color(0xFFFFEBEE), RoundedCornerShape(4.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                }
            }
        }
        
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                @OptIn(ExperimentalMaterial3Api::class)
                Text("Cash: ", color = Color.Gray, fontSize = 12.sp)
                RollingAmount(
                    amount = data.cashReceived,
                    color = Color(0xFF008800),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                @OptIn(ExperimentalMaterial3Api::class)
                Text("Sales: ", color = Color.Gray, fontSize = 12.sp)
                RollingAmount(
                    amount = data.totalSales,
                    color = Color(0xFFD50000),
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }
    }
}
