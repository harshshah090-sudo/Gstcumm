package com.example.gstcalculator

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun WebOrdersScreen(navController: NavController) {
    val viewModel: WebOrdersViewModel = viewModel()
    val orders by viewModel.orders
    val isLoading by viewModel.isLoading
    val context = LocalContext.current
    var selectedOrder by remember { mutableStateOf<WebOrder?>(null) }
    var orderToDelete by remember { mutableStateOf<WebOrder?>(null) }
    
    var showSummaryDialog by remember { mutableStateOf(false) }
    var selectedSummaryItems by remember { mutableStateOf(setOf<String>()) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Customer Orders", color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    if (orders.isNotEmpty()) {
                        IconButton(onClick = {
                            selectedSummaryItems = emptySet()
                            showSummaryDialog = true
                        }) {
                            Icon(Icons.Default.Assignment, contentDescription = "Summary", tint = Color.White)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2))
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            if (isLoading) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            } else if (orders.isEmpty()) {
                Text(
                    "No orders yet",
                    modifier = Modifier.align(Alignment.Center),
                    color = Color.Gray
                )
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(orders, key = { it.id }) { order ->
                        OrderItem(
                            modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                            order = order,
                            onClick = { selectedOrder = order },
                            onDelete = { orderToDelete = order }
                        )
                        HorizontalDivider(modifier = Modifier.padding(horizontal = 16.dp))
                    }
                }
            }
        }

        if (selectedOrder != null) {
            OrderDetailsDialog(
                order = selectedOrder!!,
                onDismiss = { selectedOrder = null },
                onAccept = {
                    val order = selectedOrder!!
                    navController.navigate("createBill/${order.customerId}/${order.customerType}?webOrderId=${order.id}")
                    selectedOrder = null
                },
                onEdit = {
                    val order = selectedOrder!!
                    navController.navigate("customerCatalog/${order.customerId}/${order.customerType}")
                    selectedOrder = null
                },
                onCreatePdf = {
                    val pdfBytes = OrderPdfGenerator.createOrderPdf(selectedOrder!!.customerName, selectedOrder!!.items)
                    val pdfPath = saveOrderPdf(context, selectedOrder!!.customerName, pdfBytes)
                    if (pdfPath != null) {
                        val encodedPath = URLEncoder.encode(pdfPath, "UTF-8")
                        val encodedName = URLEncoder.encode(selectedOrder!!.customerName, "UTF-8")
                        navController.navigate("pdfViewer/$encodedPath?customerName=$encodedName")
                    }
                }
            )
        }

        if (showSummaryDialog) {
            val uniqueItemNames = orders.flatMap { it.items }.map { it.name }.distinct().sorted()
            
            ItemSelectionDialog(
                itemNames = uniqueItemNames,
                selectedItems = selectedSummaryItems,
                onSelectionChanged = { selectedSummaryItems = it },
                onDismiss = { showSummaryDialog = false },
                onSubmit = {
                    val pdfBytes = OrderPdfGenerator.createSummaryPdf(orders, selectedSummaryItems)
                    val pdfPath = saveOrderPdf(context, "Orders_Summary", pdfBytes)
                    if (pdfPath != null) {
                        val encodedPath = URLEncoder.encode(pdfPath, "UTF-8")
                        val encodedName = URLEncoder.encode("Orders Summary", "UTF-8")
                        navController.navigate("pdfViewer/$encodedPath?customerName=$encodedName")
                    }
                    showSummaryDialog = false
                }
            )
        }

        if (orderToDelete != null) {
            BouncyDialog(onDismissRequest = { orderToDelete = null }) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Delete Order?", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Are you sure you want to delete the order from ${orderToDelete?.customerName}?")
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { orderToDelete = null }) {
                                Text("Cancel", color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    viewModel.deleteOrder(orderToDelete!!.id)
                                    orderToDelete = null
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                            ) {
                                Text("Delete")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ItemSelectionDialog(
    itemNames: List<String>,
    selectedItems: Set<String>,
    onSelectionChanged: (Set<String>) -> Unit,
    onDismiss: () -> Unit,
    onSubmit: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredItems = remember(itemNames, searchQuery) {
        if (searchQuery.isEmpty()) itemNames else itemNames.filter { it.contains(searchQuery, ignoreCase = true) }
    }
    
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 16.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Text(
                        "Select Items for Summary",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
                
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        placeholder = { Text("Search Item", fontSize = 14.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(20.dp)) },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF1976D2),
                            unfocusedBorderColor = Color.LightGray,
                            cursorColor = Color(0xFF1976D2),
                            focusedLabelColor = Color(0xFF1976D2)
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                        items(filteredItems) { itemName ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val newSelection = if (selectedItems.contains(itemName)) {
                                            selectedItems - itemName
                                        } else {
                                            selectedItems + itemName
                                        }
                                        onSelectionChanged(newSelection)
                                    }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = selectedItems.contains(itemName),
                                    onCheckedChange = { checked ->
                                        val newSelection = if (checked == true) {
                                            selectedItems + itemName
                                        } else {
                                            selectedItems - itemName
                                        }
                                        onSelectionChanged(newSelection)
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
                                )
                                Text(itemName, modifier = Modifier.padding(start = 8.dp))
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(24.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onSubmit,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            enabled = selectedItems.isNotEmpty()
                        ) {
                            Text("Submit", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private fun saveOrderPdf(context: Context, customerName: String, pdfBytes: ByteArray): String? {
    return try {
        val file = File(context.cacheDir, "Order_${customerName.replace(" ", "_")}.pdf")
        FileOutputStream(file).use { it.write(pdfBytes) }
        file.absolutePath
    } catch (e: Exception) {
        e.printStackTrace()
        null
    }
}

@Composable
fun OrderItem(
    modifier: Modifier = Modifier,
    order: WebOrder, 
    onClick: () -> Unit, 
    onDelete: () -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = order.customerName,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Text(
                text = "${order.items.size} Items",
                color = Color.Gray,
                fontSize = 14.sp
            )
            Text(
                text = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(order.date)),
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
        
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (order.status == "Pending") {
                Box(
                    modifier = Modifier
                        .background(Color(0xFFFF9800), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("Pending", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OrderDetailsDialog(order: WebOrder, onDismiss: () -> Unit, onAccept: () -> Unit, onEdit: () -> Unit, onCreatePdf: () -> Unit) {
    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 16.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            "Order: ${order.customerName}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = onCreatePdf, modifier = Modifier.size(32.dp)) {
                            Icon(
                                Icons.Default.PictureAsPdf,
                                contentDescription = "Create PDF",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Date: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(order.date))}",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                        itemsIndexed(order.items, key = { index, item -> "${item.itemId}_${item.name}_${item.qty}_$index" }) { _, item ->
                            Column(
                                modifier = Modifier
                                    .animateItemPlacement(animationSpec = springSpec)
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("${item.name} (${item.uom})", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text("Qty: ${item.qty}", fontWeight = FontWeight.Bold)
                                }
                                
                                // Variants / Breakdown Display - Sorted A-Z
                                item.getBreakdownStrings()?.toSortedMap()?.let { sortedBreakdown ->
                                    sortedBreakdown.forEach { (detail, qty) ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, top = 2.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(detail, fontSize = 12.sp, color = Color.DarkGray)
                                            Text(qty, fontSize = 12.sp, color = Color.DarkGray)
                                        }
                                    }
                                }
                            }
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), thickness = 0.5.dp, color = Color.LightGray)
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onEdit) {
                            Text("Edit Order", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onAccept,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                        ) {
                            Text("Create Bill", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
