package com.example.gstcalculator

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class HistoryDialogMode {
    HISTORY, REPLACE_ITEM, REPLACE_QTY
}

@Composable
fun ItemSalesHistoryDialog(
    onDismiss: () -> Unit,
    itemName: String,
    salesHistory: List<ItemSale>,
    allItems: List<Item> = emptyList(),
    onReplace: (Item, String) -> Unit = { _, _ -> }
) {
    var mode by remember { mutableStateOf(HistoryDialogMode.HISTORY) }
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf("Most Recent") }
    var showSortMenu by remember { mutableStateOf(false) }
    var selectedItemForReplacement by remember { mutableStateOf<Item?>(null) }
    var qtyToReplace by remember { mutableStateOf("") }

    val focusRequester = remember { FocusRequester() }

    BouncyDialog(
        onDismissRequest = {
            if (mode == HistoryDialogMode.REPLACE_QTY && selectedItemForReplacement != null) {
                onReplace(selectedItemForReplacement!!, qtyToReplace)
            }
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column {
                // Header
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = when (mode) {
                                HistoryDialogMode.HISTORY -> itemName
                                HistoryDialogMode.REPLACE_ITEM -> "Replace Item"
                                HistoryDialogMode.REPLACE_QTY -> "Enter Quantity"
                            },
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp,
                            modifier = Modifier.weight(1f)
                        )
                        if (mode == HistoryDialogMode.HISTORY && allItems.isNotEmpty()) {
                            IconButton(onClick = { mode = HistoryDialogMode.REPLACE_ITEM }) {
                                Icon(
                                    imageVector = Icons.Default.SwapHoriz,
                                    contentDescription = "Replace",
                                    tint = Color.White
                                )
                            }
                        }
                    }

                    if (mode == HistoryDialogMode.HISTORY || mode == HistoryDialogMode.REPLACE_ITEM) {
                        Spacer(modifier = Modifier.height(8.dp))
                        // Search Bar inside Header
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .focusRequester(focusRequester),
                            textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                            decorationBox = { innerTextField ->
                                Row(
                                    modifier = Modifier
                                        .background(
                                            color = Color.White,
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .padding(horizontal = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Icon",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = if (mode == HistoryDialogMode.HISTORY) "Search Customer" else "Search Item",
                                                color = Color.Gray,
                                                fontSize = 14.sp
                                            )
                                        }
                                        innerTextField()
                                    }
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { searchQuery = "" },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Clear Search",
                                                tint = Color.Gray
                                            )
                                        }
                                    }
                                    
                                    if (mode == HistoryDialogMode.HISTORY) {
                                        Box {
                                            IconButton(
                                                onClick = { showSortMenu = true },
                                                modifier = Modifier.size(24.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.FilterList,
                                                    contentDescription = "Sort History",
                                                    tint = Color.Gray
                                                )
                                            }
                                            DropdownMenu(
                                                expanded = showSortMenu,
                                                onDismissRequest = { showSortMenu = false }
                                            ) {
                                                DropdownMenuItem(
                                                    text = { Text("Most Recent") },
                                                    onClick = { sortOption = "Most Recent"; showSortMenu = false }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("Low to High") },
                                                    onClick = { sortOption = "Low to High"; showSortMenu = false }
                                                )
                                                DropdownMenuItem(
                                                    text = { Text("High to Low") },
                                                    onClick = { sortOption = "High to Low"; showSortMenu = false }
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        )
                    }
                }

                // Content
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                        .height(400.dp) // Increased height to show more items
                ) {
                    when (mode) {
                        HistoryDialogMode.HISTORY -> {
                            val filteredHistory = remember(searchQuery, salesHistory, sortOption) {
                                val filtered = if (searchQuery.isBlank()) salesHistory 
                                               else salesHistory.filter { it.customerName.contains(searchQuery, ignoreCase = true) }
                                
                                when (sortOption) {
                                    "Low to High" -> filtered.sortedBy { it.rate }
                                    "High to Low" -> filtered.sortedByDescending { it.rate }
                                    else -> filtered.sortedByDescending { it.date }
                                }
                            }
                            if (filteredHistory.isEmpty()) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No customer records found", color = Color.Gray)
                                }
                            } else {
                                LazyColumn {
                                    items(filteredHistory) { sale ->
                                        Column {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp), // Shrunk row height
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        sale.customerName,
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 14.sp
                                                    )
                                                    if (sale.date > 0) {
                                                        Text(
                                                            text = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(sale.date)),
                                                            fontSize = 11.sp,
                                                            color = Color.Gray
                                                        )
                                                    }
                                                }
                                                Text(
                                                    formatPrice(sale.rate),
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF1976D2),
                                                    fontSize = 15.sp
                                                )
                                            }
                                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                        }
                                    }
                                }
                            }
                        }
                        HistoryDialogMode.REPLACE_ITEM -> {
                            val filteredItems = remember(searchQuery, allItems) {
                                if (searchQuery.isBlank()) allItems else allItems.filter { it.name.contains(searchQuery, ignoreCase = true) }
                            }
                            
                            LaunchedEffect(Unit) {
                                delay(300)
                                try {
                                    focusRequester.requestFocus()
                                } catch (e: Exception) {}
                            }

                            if (filteredItems.isEmpty()) {
                                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                    Text("No items found", color = Color.Gray)
                                }
                            } else {
                                LazyColumn {
                                    items(filteredItems) { item ->
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedItemForReplacement = item
                                                    mode = HistoryDialogMode.REPLACE_QTY
                                                }
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp), // Shrunk row height
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    item.name,
                                                    modifier = Modifier.weight(1f),
                                                    fontWeight = FontWeight.Medium
                                                )
                                                Text(
                                                    item.uom,
                                                    color = Color.Gray,
                                                    fontSize = 12.sp
                                                )
                                            }
                                            HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                        }
                                    }
                                }
                            }
                        }
                        HistoryDialogMode.REPLACE_QTY -> {
                            LaunchedEffect(Unit) {
                                delay(300)
                                try {
                                    focusRequester.requestFocus()
                                } catch (e: Exception) {}
                            }
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clickable(
                                        interactionSource = remember { MutableInteractionSource() },
                                        indication = null
                                    ) {
                                        selectedItemForReplacement?.let { onReplace(it, qtyToReplace) }
                                        onDismiss()
                                    },
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = selectedItemForReplacement?.name ?: "",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color(0xFF1976D2)
                                )
                                Spacer(modifier = Modifier.height(16.dp))
                                BasicTextField(
                                    value = qtyToReplace,
                                    onValueChange = { qtyToReplace = it },
                                    modifier = Modifier
                                        .width(150.dp)
                                        .background(Color(0xFFF0F0F0), RoundedCornerShape(8.dp))
                                        .padding(16.dp)
                                        .focusRequester(focusRequester),
                                    textStyle = TextStyle(
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    ),
                                    keyboardOptions = KeyboardOptions(
                                        keyboardType = KeyboardType.Number,
                                        imeAction = ImeAction.Done
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onDone = {
                                            selectedItemForReplacement?.let { onReplace(it, qtyToReplace) }
                                            onDismiss()
                                        }
                                    ),
                                    singleLine = true,
                                    decorationBox = { innerTextField ->
                                        Box(contentAlignment = Alignment.Center) {
                                            if (qtyToReplace.isEmpty()) Text("0", color = Color.Gray, fontSize = 20.sp)
                                            innerTextField()
                                        }
                                    }
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Enter Quantity", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Footer
                if (mode != HistoryDialogMode.HISTORY) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = { 
                            if (mode == HistoryDialogMode.REPLACE_QTY) {
                                mode = HistoryDialogMode.REPLACE_ITEM
                            } else {
                                mode = HistoryDialogMode.HISTORY
                                searchQuery = ""
                            }
                        }) {
                            Text("Back")
                        }
                    }
                } else {
                    // Small spacer at the bottom when in history mode
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }
        }
    }
}

private fun formatPrice(price: Double): String {
    return if (price % 1.0 == 0.0) "₹${price.toLong()}" else "₹${String.format("%.2f", price)}"
}
