package com.example.gstcalculator

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

class UserPreferences(context: Context) {
    private val sharedPreferences = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
    private val gson = Gson()

    fun setLoginState(state: String) {
        sharedPreferences.edit().putString("login_state", state).apply()
    }

    fun getLoginState(): String {
        return sharedPreferences.getString("login_state", "none") ?: "none"
    }

    fun getDeviceId(): String {
        var id = sharedPreferences.getString("device_id", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            sharedPreferences.edit().putString("device_id", id).apply()
        }
        return id
    }

    fun setDefaultReminderDays(days: Int) {
        sharedPreferences.edit().putInt("default_reminder_days", days).apply()
    }

    fun getDefaultReminderDays(): Int {
        return sharedPreferences.getInt("default_reminder_days", 30)
    }

    fun setBypassDisabled(disabled: Boolean) {
        sharedPreferences.edit().putBoolean("is_bypass_disabled", disabled).apply()
    }

    fun isBypassDisabled(): Boolean {
        return sharedPreferences.getBoolean("is_bypass_disabled", false)
    }

    fun addCustomScreen(screenName: String) {
        val screens = getCustomScreens().toMutableList()
        if (!screens.contains(screenName)) {
            screens.add(screenName)
            saveCustomScreens(screens)
        }
    }

    fun removeCustomScreen(screenName: String) {
        val screens = getCustomScreens().toMutableList()
        if (screens.remove(screenName)) {
            saveCustomScreens(screens)
        }
    }

    fun getCustomScreens(): List<String> {
        val json = sharedPreferences.getString("custom_screens", null) ?: return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(json, type)
    }

    private fun saveCustomScreens(screens: List<String>) {
        val json = gson.toJson(screens)
        sharedPreferences.edit().putString("custom_screens", json).apply()
    }

    fun clear() {
        sharedPreferences.edit().clear().apply()
    }
}