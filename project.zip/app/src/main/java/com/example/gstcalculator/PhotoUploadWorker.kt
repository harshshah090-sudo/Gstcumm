package com.example.gstcalculator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class PhotoUploadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val customerId = inputData.getString("customerId") ?: return@withContext Result.failure()
        val transactionId = inputData.getString("transactionId") ?: return@withContext Result.failure()
        val customerType = inputData.getString("customerType") ?: return@withContext Result.failure()
        val photoUriString = inputData.getString("photoUri") ?: return@withContext Result.failure()
        val photoUri = Uri.parse(photoUriString)

        val database = when (customerType) {
            "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
            "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
            "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
            else -> FirebaseDatabase.getInstance().getReference("customers_custom_$customerType")
        }

        try {
            val compressedFile = compressImage(applicationContext, photoUri)
            if (!compressedFile.exists()) return@withContext Result.failure()

            val storageRef = FirebaseStorage.getInstance().reference.child("transaction_photos/$customerId/$transactionId.jpg")
            val uploadTask = storageRef.putFile(Uri.fromFile(compressedFile)).await()
            val downloadUrl = storageRef.downloadUrl.await()

            database.child(customerId).child("transactions").child(transactionId).updateChildren(mapOf(
                "photoUrl" to downloadUrl.toString(),
                "syncing" to false,
                "syncFailed" to false
            )).await()

            // Check if anything else is still syncing for this customer
            val customerSyncingSnap = database.child(customerId).child("transactions").get().await()
            val stillSyncing = customerSyncingSnap.children.any { 
                it.child("syncing").getValue(Boolean::class.java) == true 
            }
            if (!stillSyncing) {
                database.child(customerId).child("syncing").setValue(false)
            }

            compressedFile.delete()
            Result.success()
        } catch (e: Exception) {
            database.child(customerId).child("transactions").child(transactionId).updateChildren(mapOf(
                "syncing" to false,
                "syncFailed" to true
            ))
            Result.retry()
        }
    }

    private fun compressImage(context: Context, uri: Uri): File {
        var inputStream = context.contentResolver.openInputStream(uri)
        
        // 1. Read EXIF Orientation
        val orientation = inputStream?.let {
            val exif = ExifInterface(it)
            exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        inputStream?.close()

        // 2. Decode Bitmap
        inputStream = context.contentResolver.openInputStream(uri)
        var originalBitmap = BitmapFactory.decodeStream(inputStream) ?: return File("")
        inputStream?.close()

        // 3. Rotate Bitmap based on EXIF
        if (orientation != ExifInterface.ORIENTATION_NORMAL) {
            val matrix = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> {
                    matrix.postRotate(90f)
                    matrix.postScale(-1f, 1f)
                }
                ExifInterface.ORIENTATION_TRANSVERSE -> {
                    matrix.postRotate(270f)
                    matrix.postScale(-1f, 1f)
                }
            }
            val rotatedBitmap = Bitmap.createBitmap(originalBitmap, 0, 0, originalBitmap.width, originalBitmap.height, matrix, true)
            if (rotatedBitmap != originalBitmap) {
                originalBitmap.recycle()
                originalBitmap = rotatedBitmap
            }
        }

        // 4. Scaling logic
        val maxDimension = 1024
        val ratio = originalBitmap.width.toFloat() / originalBitmap.height.toFloat()
        val (width, height) = if (originalBitmap.width > originalBitmap.height) {
            maxDimension to (maxDimension / ratio).toInt()
        } else {
            (maxDimension * ratio).toInt() to maxDimension
        }
        
        val scaledBitmap = if (originalBitmap.width > maxDimension || originalBitmap.height > maxDimension) {
            Bitmap.createScaledBitmap(originalBitmap, width, height, true)
        } else {
            originalBitmap
        }
        
        val outputFile = File(context.cacheDir, "compressed_${UUID.randomUUID()}.jpg")
        val outputStream = FileOutputStream(outputFile)
        scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 60, outputStream)
        outputStream.flush()
        outputStream.close()
        
        if (scaledBitmap != originalBitmap) scaledBitmap.recycle()
        originalBitmap.recycle()
        
        return outputFile
    }
}
