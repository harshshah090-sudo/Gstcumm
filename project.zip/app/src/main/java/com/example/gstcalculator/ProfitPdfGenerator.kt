package com.example.gstcalculator

import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.colors.DeviceRgb
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.property.TextAlignment
import com.itextpdf.layout.property.UnitValue
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ProfitPdfGenerator {

    private val APP_BLUE = DeviceRgb(25, 118, 210) // 0xFF1976D2
    private val LIGHT_GREY = DeviceRgb(245, 245, 245)

    fun createProfitPdf(
        customerName: String,
        billDate: Long,
        billItems: List<BillItem>,
        totalProfit: Double
    ): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A4)
        document.setMargins(36f, 36f, 36f, 36f)


        // Header
        val headerTable = Table(UnitValue.createPercentArray(floatArrayOf(1f))).useAllAvailableWidth()
        val headerCell = Cell().setBorder(Border.NO_BORDER).setBackgroundColor(APP_BLUE).setPadding(10f)
        val headerParagraph = Paragraph(customerName)
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(20f)
            .setBold()
            .setFontColor(ColorConstants.WHITE)
        headerCell.add(headerParagraph)

        val dateParagraph = Paragraph(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(billDate)))
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(12f)
            .setFontColor(ColorConstants.WHITE)
        headerCell.add(dateParagraph)

        headerTable.addCell(headerCell)
        document.add(headerTable)


        // Items Table
        val table = Table(UnitValue.createPercentArray(floatArrayOf(1f, 3f, 1f, 1f, 1f, 1f, 1f))).useAllAvailableWidth().setMarginTop(20f)
        table.setBorder(SolidBorder(ColorConstants.GRAY, 1f))

        // Table Header
        table.addHeaderCell(createHeaderCell("S.N."))
        table.addHeaderCell(createHeaderCell("Item Name"))
        table.addHeaderCell(createHeaderCell("Qty"))
        table.addHeaderCell(createHeaderCell("Rate"))
        table.addHeaderCell(createHeaderCell("B.P.")) // Changed from "Base Price"
        table.addHeaderCell(createHeaderCell("Amount"))
        table.addHeaderCell(createHeaderCell("Profit"))

        var totalAmount = 0.0

        billItems.forEachIndexed { index, item ->
            val qty = item.getQtyDouble()
            val rate = item.rate.toDoubleOrNull() ?: 0.0
            val basePrice = item.basePrice.toDoubleOrNull() ?: 0.0
            
            val amount = rate * qty
            val profit = amount - (basePrice * qty)
            totalAmount += amount

            table.addCell(createContentCell((index + 1).toString(), TextAlignment.CENTER))
            table.addCell(createContentCell(item.name, TextAlignment.LEFT))
            table.addCell(createContentCell(item.getQtyString(), TextAlignment.RIGHT))
            table.addCell(createContentCell(item.rate, TextAlignment.RIGHT))
            table.addCell(createContentCell(item.basePrice, TextAlignment.RIGHT))
            table.addCell(createContentCell(String.format("%.2f", amount), TextAlignment.RIGHT))
            table.addCell(createContentCell(String.format("%.2f", profit), TextAlignment.RIGHT))
        }

        document.add(table)

        // Totals Summary Row
        val summaryTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth().setMarginTop(10f)
        summaryTable.setBorder(Border.NO_BORDER)

        val totalAmountCell = Cell()
            .add(Paragraph("Total Amount: ${String.format("%.2f", totalAmount)}")
                .setFontSize(14f)
                .setBold()
            )
            .setTextAlignment(TextAlignment.CENTER)
            .setBorder(Border.NO_BORDER)
            .setBorderRight(SolidBorder(ColorConstants.GRAY, 1f))
            .setBackgroundColor(LIGHT_GREY)
            .setPadding(8f)

        val profitAmountCell = Cell()
            .add(Paragraph("Profit Amount: ${String.format("%.2f", totalProfit)}")
                .setFontSize(14f)
                .setBold()
            )
            .setTextAlignment(TextAlignment.CENTER)
            .setBorder(Border.NO_BORDER)
            .setBackgroundColor(LIGHT_GREY)
            .setPadding(8f)

        summaryTable.addCell(totalAmountCell)
        summaryTable.addCell(profitAmountCell)
        document.add(summaryTable)


        // Footer
        val footer = Paragraph("Report Generated on: ${SimpleDateFormat("dd/MM/yyyy hh:mm a", Locale.getDefault()).format(Date())}")
            .setTextAlignment(TextAlignment.CENTER)
            .setFontColor(ColorConstants.WHITE)
            .setBackgroundColor(APP_BLUE)
            .setPadding(5f)
            .setFixedPosition(document.leftMargin, document.bottomMargin, document.getPageEffectiveArea(PageSize.A4).width)
        document.add(footer)


        document.close()
        return outputStream.toByteArray()
    }

    private fun createHeaderCell(text: String): Cell {
        return Cell().add(Paragraph(text).setBold())
            .setTextAlignment(TextAlignment.CENTER)
            .setBackgroundColor(LIGHT_GREY)
            .setBorder(SolidBorder(ColorConstants.GRAY, 1f))
            .setPadding(8f)
    }

    private fun createContentCell(text: String, alignment: TextAlignment): Cell {
        return Cell().add(Paragraph(text))
            .setTextAlignment(alignment)
            .setBorder(SolidBorder(ColorConstants.GRAY, 0.5f))
            .setPadding(5f)
    }
}
