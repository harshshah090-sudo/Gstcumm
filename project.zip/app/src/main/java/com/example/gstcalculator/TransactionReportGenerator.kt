package com.example.gstcalculator

import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.colors.DeviceRgb
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.action.PdfAction
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Link
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.element.Text
import com.itextpdf.layout.property.TextAlignment
import com.itextpdf.layout.property.UnitValue
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TransactionReportGenerator {

    private val LIGHT_RED = DeviceRgb(255, 230, 230)
    private val LIGHT_GREEN = DeviceRgb(230, 255, 230)
    private val LIGHT_GREY = DeviceRgb(245, 245, 245)
    private val DARK_GREEN = DeviceRgb(0, 102, 0)
    private val APP_BLUE = DeviceRgb(25, 118, 210) // Color from 0xFF1976D2

    fun createTransactionReport(
        customer: Customer,
        transactions: List<Pair<Transaction, Double>>,
        openingBalance: Double? = null,
        reportStartDate: Long? = null,
        reportEndDate: Long? = null,
        historyStartDate: Long? = null,
        lastTransactionBeforeStart: Long? = null
    ): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A4)
        document.setMargins(36f, 36f, 36f, 36f)

        // Header
        val headerTable = Table(UnitValue.createPercentArray(floatArrayOf(1f))).useAllAvailableWidth()
        val headerCell = Cell().setBorder(Border.NO_BORDER).setBackgroundColor(APP_BLUE).setPadding(10f)

        val header = Paragraph(customer.name)
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(20f)
            .setBold()
            .setFontColor(ColorConstants.WHITE)
            .setMarginBottom(0f)
        headerCell.add(header)

        val startDateStr = if (reportStartDate != null) {
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(reportStartDate))
        } else {
            transactions.mapNotNull { it.first.date }.minOrNull()?.let { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it)) } ?: ""
        }
        
        val endDateStr = if (reportEndDate != null) {
            SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(reportEndDate))
        } else {
            transactions.mapNotNull { it.first.date }.maxOrNull()?.let { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(it)) } ?: ""
        }

        val dateRange = Paragraph("($startDateStr - $endDateStr)")
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(12f)
            .setFontColor(ColorConstants.WHITE)
            .setMarginTop(0f)
        headerCell.add(dateRange)
        headerTable.addCell(headerCell)
        document.add(headerTable)


        val infoTable = Table(UnitValue.createPercentArray(floatArrayOf(50f, 50f))).useAllAvailableWidth()
        infoTable.setMarginTop(20f)
        infoTable.addCell(createCell("No. of Entries: ${transactions.size}", TextAlignment.LEFT).setBorder(Border.NO_BORDER))
        infoTable.addCell(createCell(SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date()), TextAlignment.RIGHT).setBorder(Border.NO_BORDER))
        document.add(infoTable)

        // Opening Balance Row
        if (openingBalance != null) {
            val opTable = Table(UnitValue.createPercentArray(floatArrayOf(80f, 20f))).useAllAvailableWidth()
            opTable.setMarginTop(10f)
            
            val opRange = if (historyStartDate != null && lastTransactionBeforeStart != null) {
                val start = SimpleDateFormat("dd MMM yy", Locale.getDefault()).format(Date(historyStartDate))
                val end = SimpleDateFormat("dd MMM yy", Locale.getDefault()).format(Date(lastTransactionBeforeStart))
                if (start == end) " ($start)" else " ($start - $end)"
            } else ""
            
            val opLabelCell = createCell("Opening Balance$opRange", TextAlignment.RIGHT).setBold().setFontSize(12f).setBackgroundColor(LIGHT_GREY).setBorder(Border.NO_BORDER)
            val opValueCell = createCell(formatAmount(openingBalance), TextAlignment.RIGHT).setBold().setFontSize(12f).setFontColor(if (openingBalance < 0) DARK_GREEN else ColorConstants.RED).setBackgroundColor(LIGHT_GREY).setBorder(Border.NO_BORDER)
            opTable.addCell(opLabelCell)
            opTable.addCell(opValueCell)
            document.add(opTable)
        }

        // Table
        val sortedTransactions = transactions.sortedBy { it.first.date }
        val table = Table(UnitValue.createPercentArray(floatArrayOf(15f, 30f, 10f, 15f, 15f, 15f))).useAllAvailableWidth()
        table.setMarginTop(10f)
        table.setBorder(SolidBorder(ColorConstants.GRAY, 1f))

        // Table Header
        table.addHeaderCell(createHeaderCell("Date"))
        table.addHeaderCell(createHeaderCell("Details"))
        table.addHeaderCell(createHeaderCell("Bill"))
        table.addHeaderCell(createHeaderCell("Debit(-)"))
        table.addHeaderCell(createHeaderCell("Credit(+)"))
        table.addHeaderCell(createHeaderCell("Balance"))

        // Table Body
        var totalDebit = 0.0
        var totalCredit = 0.0

        for ((transaction, balance) in sortedTransactions) {
            val date = transaction.date?.let { SimpleDateFormat("dd MMM yy", Locale.getDefault()).format(Date(it)) } ?: ""
            table.addCell(createContentCell(date, TextAlignment.LEFT))

            // Details Cell (text only)
            val detailsCell = createStyledContentCell(TextAlignment.LEFT)
            val detailsParagraph = Paragraph()
            if (transaction.paid) {
                val paidText = Text("Paid: ${formatAmount(transaction.paidAmount)}").setFontColor(DARK_GREEN)
                val dateText = Text("\n" + SimpleDateFormat("dd MMM yy", Locale.getDefault()).format(Date(transaction.paidDate ?: 0))).setFontSize(8f)
                detailsParagraph.add(paidText)
                detailsParagraph.add(dateText)
            }
            if (!transaction.note.isNullOrBlank()) {
                if (transaction.paid) {
                    detailsParagraph.add("\n") // Add a separator
                }
                detailsParagraph.add(transaction.note)
            }
            detailsCell.add(detailsParagraph)
            table.addCell(detailsCell)

            // Bill Cell (link only) - Handle both billImageUrl and photoUrl
            val billCell = createStyledContentCell(TextAlignment.CENTER)
            val imageUrl = transaction.billImageUrl ?: transaction.photoUrl
            if (imageUrl != null) {
                val link = Link("View", PdfAction.createURI(imageUrl))
                link.setFontColor(ColorConstants.BLUE)
                billCell.add(Paragraph(link).setFontSize(10f))
            }
            table.addCell(billCell)

            if (transaction.type == "GAVE") {
                val amount = transaction.amount ?: 0.0
                totalDebit += amount
                table.addCell(createContentCell(formatAmount(amount), TextAlignment.RIGHT, LIGHT_RED))
                table.addCell(createContentCell("", TextAlignment.LEFT, LIGHT_GREEN))
            } else { // GOT
                val amount = transaction.amount ?: 0.0
                totalCredit += amount
                table.addCell(createContentCell("", TextAlignment.LEFT, LIGHT_RED))
                table.addCell(createContentCell(formatAmount(amount), TextAlignment.RIGHT, LIGHT_GREEN))
            }
            table.addCell(createContentCell(formatAmount(balance), TextAlignment.RIGHT).setFontColor(if (balance < 0) DARK_GREEN else ColorConstants.RED))
        }

        // Add Summary Totals Row inside the table
        table.addCell(createContentCell("TOTAL", TextAlignment.CENTER).setBold().setBackgroundColor(LIGHT_GREY))
        table.addCell(createContentCell("", TextAlignment.LEFT).setBackgroundColor(LIGHT_GREY))
        table.addCell(createContentCell("", TextAlignment.LEFT).setBackgroundColor(LIGHT_GREY))
        table.addCell(createContentCell(formatAmount(totalDebit), TextAlignment.RIGHT).setBold().setBackgroundColor(LIGHT_GREY))
        table.addCell(createContentCell(formatAmount(totalCredit), TextAlignment.RIGHT).setBold().setBackgroundColor(LIGHT_GREY))
        table.addCell(createContentCell("", TextAlignment.LEFT).setBackgroundColor(LIGHT_GREY))

        document.add(table)

        // Grand Total
        val grandTotal = sortedTransactions.lastOrNull()?.second ?: openingBalance ?: 0.0
        val totalTable = Table(UnitValue.createPercentArray(floatArrayOf(80f, 20f))).useAllAvailableWidth() // Adjusted for 6 columns
        totalTable.setMarginTop(10f)
        val totalLabelCell = createCell("Closing Balance", TextAlignment.RIGHT).setBold().setFontSize(14f).setBackgroundColor(LIGHT_GREY).setBorder(Border.NO_BORDER)
        val totalValueCell = createCell(formatAmount(grandTotal), TextAlignment.RIGHT).setBold().setFontSize(14f).setFontColor(if (grandTotal < 0) DARK_GREEN else ColorConstants.RED).setBackgroundColor(LIGHT_GREY).setBorder(Border.NO_BORDER)
        totalTable.addCell(totalLabelCell)
        totalTable.addCell(totalValueCell)
        document.add(totalTable)

        // Footer
        val footerText = "Report Generated: ${SimpleDateFormat("hh:mm a | dd MMM yy", Locale.getDefault()).format(Date())}"
        val footer = Paragraph(footerText)
            .setTextAlignment(TextAlignment.CENTER)
            .setFontSize(10f)
            .setFontColor(ColorConstants.WHITE)
            .setBackgroundColor(APP_BLUE)
            .setPadding(5f)
            .setFixedPosition(document.leftMargin, document.bottomMargin, document.getPageEffectiveArea(PageSize.A4).width)

        document.add(footer)

        document.close()
        return outputStream.toByteArray()
    }

    private fun createHeaderCell(text: String): Cell {
        return Cell().add(Paragraph(text).setBold())
            .setTextAlignment(TextAlignment.CENTER)
            .setBackgroundColor(LIGHT_GREY)
            .setBorder(SolidBorder(ColorConstants.GRAY, 1f))
            .setPadding(8f)
    }

    private fun createStyledContentCell(alignment: TextAlignment, backgroundColor: DeviceRgb? = null): Cell {
        val cell = Cell()
            .setTextAlignment(alignment)
            .setBorderRight(SolidBorder(ColorConstants.GRAY, 1f))
            .setBorderLeft(SolidBorder(ColorConstants.GRAY, 1f))
            .setBorderTop(SolidBorder(ColorConstants.GRAY, 1f))
            .setBorderBottom(SolidBorder(ColorConstants.GRAY, 1f))
            .setPadding(8f)
        backgroundColor?.let { cell.setBackgroundColor(it) }
        return cell
    }

    private fun createContentCell(text: String, alignment: TextAlignment, backgroundColor: DeviceRgb? = null): Cell {
        val cell = createStyledContentCell(alignment, backgroundColor)
        cell.add(Paragraph(text))
        return cell
    }

    private fun createCell(text: String, alignment: TextAlignment = TextAlignment.LEFT, color: com.itextpdf.kernel.colors.Color = ColorConstants.BLACK): Cell {
        val cell = Cell().add(Paragraph(text))
            .setTextAlignment(alignment)
            .setFontColor(color)
            .setBorder(Border.NO_BORDER)
            .setPadding(5f)

        return cell
    }
}
