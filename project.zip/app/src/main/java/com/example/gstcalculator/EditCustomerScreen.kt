package com.example.gstcalculator

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController

@Composable
fun EditCustomerScreen(navController: NavController, customerId: String, customerType: String) {
    val context = LocalContext.current
    val viewModel: EditCustomerViewModel = viewModel(factory = EditCustomerViewModelFactory(context, customerId, customerType))
    val itemViewModel: ItemViewModel = viewModel(factory = ItemViewModelFactory())
    val allItems by itemViewModel.allItems.collectAsState()
    
    val userPreferences = remember { UserPreferences(context) }
    val isAdmin = userPreferences.getLoginState() == "admin"
    
    var nameError by remember { mutableStateOf(false) }
    var showItemRatesDialog by remember { mutableStateOf(false) }
    var showPaymentReminderDialog by remember { mutableStateOf(false) }
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }
    var showClearTransactionsDialog by remember { mutableStateOf(false) }

    // Trigger migration of item rates to IDs and cleanup old name-based entries
    LaunchedEffect(allItems) {
        if (allItems.isNotEmpty()) {
            viewModel.migrateItemRates(allItems)
        }
    }

    if (showItemRatesDialog) {
        ItemRatesDialog(
            itemRates = viewModel.itemRates.value,
            allItems = allItems,
            onDismiss = { showItemRatesDialog = false },
            onRateChanged = { itemKey, rate ->
                viewModel.saveItemRate(itemKey, rate)
            }
        )
    }

    if (showPaymentReminderDialog) {
        PaymentReminderDialog(
            initialDays = viewModel.paymentReminderDays.value,
            onDismiss = { showPaymentReminderDialog = false },
            onSave = { days ->
                viewModel.paymentReminderDays.value = days
                showPaymentReminderDialog = false
            }
        )
    }

    if (showDeleteConfirmDialog) {
        DeleteConfirmationDialog(
            onDismiss = { showDeleteConfirmDialog = false },
            onConfirm = {
                viewModel.deleteCustomer {
                    navController.navigate("main") {
                        popUpTo("main") { inclusive = true }
                    }
                }
            }
        )
    }

    if (showClearTransactionsDialog) {
        ClearTransactionsConfirmationDialog(
            onDismiss = { showClearTransactionsDialog = false },
            onConfirm = {
                viewModel.clearAllTransactions {
                    Toast.makeText(context, "All transactions cleared successfully.", Toast.LENGTH_SHORT).show()
                    navController.navigate("transaction/$customerId/$customerType") {
                        popUpTo("main")
                    }
                }
                showClearTransactionsDialog = false
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().background(Color(0xFFF5F5F5))) {
        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF1976D2))
                .statusBarsPadding()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
            ) {
                Text(
                    text = "Edit Customer",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Start)
                )
                Spacer(modifier = Modifier.height(16.dp))
                BasicTextField(
                    value = viewModel.customerName,
                    onValueChange = {
                        viewModel.customerName = it
                        nameError = false
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = isAdmin,
                    textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    decorationBox = { innerTextField ->
                        Box(
                            contentAlignment = Alignment.CenterStart,
                            modifier = Modifier
                                .background(if (isAdmin) Color.White else Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            if (viewModel.customerName.isEmpty()) {
                                Text("Customer Name", color = Color.Gray)
                            }
                            innerTextField()
                        }
                    }
                )
                if (nameError) {
                    Text("Name cannot be empty", color = Color.White, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(modifier = Modifier.height(8.dp))
                BasicTextField(
                    value = viewModel.customerPhoneNumber,
                    onValueChange = { input ->
                        val digitsOnly = input.filter { it.isDigit() }
                        if (digitsOnly.length <= 10) {
                            viewModel.customerPhoneNumber = digitsOnly
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = isAdmin,
                    textStyle = TextStyle(color = Color.Black, fontSize = 16.sp),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                     decorationBox = { innerTextField ->
                        Box(
                            contentAlignment = Alignment.CenterStart,
                            modifier = Modifier
                                .background(if (isAdmin) Color.White else Color.LightGray.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            if (viewModel.customerPhoneNumber.isEmpty()) {
                                Text("Phone Number", color = Color.Gray)
                            }
                            innerTextField()
                        }
                    }
                )
            }
        }

        OptionItem(icon = Icons.Default.List, text = "Item Rates") {
            showItemRatesDialog = true
        }
        HorizontalDivider()
        OptionItem(icon = Icons.Default.ShoppingCart, text = "Order Window") {
            navController.navigate("customerCatalog/$customerId/$customerType")
        }
        HorizontalDivider()
        OptionItem(icon = Icons.Default.Notifications, text = "Payment Reminder Time") {
            showPaymentReminderDialog = true
        }
        
        if (isAdmin) {
            HorizontalDivider()
            OptionItem(icon = Icons.Default.MoveUp, text = if (customerType == "HOME") "Move to Locals" else "Move to Homescreen") {
                viewModel.moveCustomer { newCustomerType ->
                    navController.navigate("main?customerType=$newCustomerType") {
                        popUpTo("main") { inclusive = true }
                    }
                }
            }
        }
        
        HorizontalDivider()
        OptionItem(icon = Icons.Default.Delete, text = "Recycle Bin") {
            navController.navigate("transactionRecycleBin/$customerId/$customerType")
        }
        
        if (isAdmin) {
            HorizontalDivider()
            OptionItem(icon = Icons.Default.ClearAll, text = "Clear All Transactions") {
                showClearTransactionsDialog = true
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        // Buttons
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (isAdmin) {
                Button(
                    onClick = {
                        if (viewModel.customerName.isBlank()) {
                            nameError = true
                        } else {
                            viewModel.updateCustomer {
                                navController.navigate("transaction/$customerId/$customerType") {
                                    popUpTo("main")
                                }
                            }
                        }
                    },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                ) {
                    Text("Save")
                }
                Button(
                    onClick = { showDeleteConfirmDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000)),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Delete")
                }
            } else {
                Button(
                    onClick = { navController.popBackStack() },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                ) {
                    Text("Back")
                }
            }
        }
    }
}

@Composable
fun OptionItem(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = text, tint = Color(0xFF1976D2))
        Spacer(modifier = Modifier.padding(8.dp))
        Text(text, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun DeleteConfirmationDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Confirm Delete", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFFD50000))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Are you sure you want to delete this customer? All transactions will be moved to the recycle bin.")
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
                    ) {
                        Text("Delete")
                    }
                }
            }
        }
    }
}

@Composable
fun ClearTransactionsConfirmationDialog(onDismiss: () -> Unit, onConfirm: () -> Unit) {
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Clear Transactions", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFFD50000))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Are you sure you want to clear all transactions for this customer? All records will be moved to the recycle bin and permanently deleted after 60 days.")
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onConfirm() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD50000))
                    ) {
                        Text("Clear All")
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentReminderDialog(initialDays: Int, onDismiss: () -> Unit, onSave: (Int) -> Unit) {
    var days by remember { mutableStateOf(initialDays.toString()) }
    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            @OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Payment Reminder", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color(0xFF1976D2))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Set the number of days after which a payment reminder should be shown for this customer.")
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = days,
                    onValueChange = { if (it.all { char -> char.isDigit() }) days = it },
                    label = { Text("Number of Days") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { onDismiss() }) {
                        Text("Cancel", color = Color.Gray)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onSave(days.toIntOrNull() ?: 30) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2))
                    ) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
