package com.example.gstcalculator

import android.content.Context
import com.google.firebase.database.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.TimeUnit

data class RepositoryData(
    val customers: List<Customer> = emptyList(),
    val gaveTransactions: List<TransactionWithCustomer> = emptyList(),
    val totalYouWillGet: Double = 0.0,
    val totalYouWillGive: Double = 0.0,
    val hasNewReminders: Boolean = false
)

object DataRepository {
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _dataMap = mutableMapOf<String, MutableStateFlow<RepositoryData>>()
    private val listenersMap = mutableMapOf<String, ValueEventListener>()
    
    val isConnected = MutableStateFlow(true)
    val customScreens = MutableStateFlow<List<String>>(emptyList())
    
    private var appContext: Context? = null
    var isAdmin: Boolean = false
        set(value) {
            field = value
            if (value) triggerGlobalImageCaching()
        }

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun triggerGlobalImageCaching() {
        val context = appContext ?: return
        if (!isAdmin) return
        
        repositoryScope.launch(Dispatchers.Default) {
            _dataMap.values.forEach { flow ->
                flow.value.gaveTransactions.forEach { transactionWithCustomer ->
                    val t = transactionWithCustomer.transaction
                    ImageCacheManager.cacheImage(context, t.photoUrl)
                }
            }
        }
    }

    init {
        monitorConnection()
        monitorCustomScreens()
    }

    private fun monitorConnection() {
        try {
            FirebaseDatabase.getInstance().getReference(".info/connected")
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        isConnected.value = snapshot.getValue(Boolean::class.java) ?: false
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        } catch (e: Exception) {
            android.util.Log.e("DataRepository", "Error in monitorConnection: ${e.message}", e)
        }
    }

    private fun monitorCustomScreens() {
        try {
            FirebaseDatabase.getInstance().getReference("app_config/custom_screens")
                .addValueEventListener(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val screens = snapshot.children.mapNotNull { it.key }
                        customScreens.value = screens
                        screens.forEach { startListening(it) }
                    }
                    override fun onCancelled(error: DatabaseError) {}
                })
        } catch (e: Exception) {
            android.util.Log.e("DataRepository", "Error in monitorCustomScreens: ${e.message}", e)
        }
    }

    fun addCustomScreen(name: String) {
        FirebaseDatabase.getInstance().getReference("app_config/custom_screens").child(name).setValue(true)
    }

    fun removeCustomScreen(name: String) {
        FirebaseDatabase.getInstance().getReference("app_config/custom_screens").child(name).removeValue()
        FirebaseDatabase.getInstance().getReference("custom_customers").child(name).removeValue()
        
        listenersMap[name]?.let { listener ->
            val database = FirebaseDatabase.getInstance().getReference("custom_customers").child(name)
            database.removeEventListener(listener)
            listenersMap.remove(name)
        }
        _dataMap.remove(name)
    }

    fun getDataFlow(customerType: String): MutableStateFlow<RepositoryData> {
        val flow = _dataMap.getOrPut(customerType) {
            MutableStateFlow(RepositoryData())
        }
        startListening(customerType)
        return flow
    }

    fun preloadData(types: List<String>) {
        types.forEach { type ->
            startListening(type)
        }
    }

    private fun startListening(customerType: String) {
        if (listenersMap.containsKey(customerType)) return

        val database = when (customerType) {
            "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
            "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
            "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
            else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(customerType)
        }

        database.keepSynced(true)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                repositoryScope.launch(Dispatchers.Default) {
                    val customerList = mutableListOf<Customer>()
                    val gaveTransactionsList = mutableListOf<TransactionWithCustomer>()
                    var youWillGet = 0.0
                    var youWillGive = 0.0
                    var foundReminder = false
                    val today = System.currentTimeMillis()

                    for (customerSnapshot in snapshot.children) {
                        try {
                            val deserialized = customerSnapshot.getValue(Customer::class.java)
                            deserialized?.let {
                                val draftsSnap = customerSnapshot.child("drafts")
                                val hasDraft = draftsSnap.children.any { it.hasChild("items") }
                                val storedBalance = (customerSnapshot.child("initialBalance").value as? Number)?.toDouble() ?: it.initialBalance ?: 0.0
                                val isSyncing = (customerSnapshot.child("syncing").getValue(Boolean::class.java) ?: false)
                                
                                // RE-ENABLE LIGHTWEIGHT TRANSACTION COLLECTION for Date Filter
                                val transactionsSnapshot = customerSnapshot.child("transactions")
                                for (tSnap in transactionsSnapshot.children) {
                                    val type = tSnap.child("type").getValue(String::class.java)
                                    if (type == "GAVE") {
                                        val t = Transaction(
                                            id = tSnap.key,
                                            customerId = customerSnapshot.key,
                                            amount = (tSnap.child("amount").value as? Number)?.toDouble() ?: 0.0,
                                            type = type,
                                            date = (tSnap.child("date").value as? Number)?.toLong() ?: 0L,
                                            note = tSnap.child("note").getValue(String::class.java),
                                            paid = (tSnap.child("paid").getValue(Boolean::class.java) == true),
                                            // Dummy item to trigger PDF icon visibility without heavy parsing
                                            items = if (tSnap.hasChild("items")) listOf(BillItem(name = "exists")) else emptyList(),
                                            billImageUrl = tSnap.child("billImageUrl").getValue(String::class.java)
                                        )
                                        gaveTransactionsList.add(TransactionWithCustomer(t, it.name, customerSnapshot.key ?: "", customerType, it.phoneNumber?.toString() ?: ""))
                                    }
                                }

                                // RE-ENABLE REMINDER LOGIC
                                if (!foundReminder && storedBalance != 0.0) {
                                    val reminderDays = it.paymentReminderDays ?: 30
                                    it.lastUpdated?.let { lastDate ->
                                        if (TimeUnit.MILLISECONDS.toDays(today - lastDate) >= reminderDays) {
                                            foundReminder = true
                                        }
                                    }
                                }

                                val newCustomer = Customer(
                                    id = customerSnapshot.key,
                                    name = it.name,
                                    phoneNumber = it.phoneNumber,
                                    initialBalance = storedBalance,
                                    lastUpdated = it.lastUpdated,
                                    creationDate = it.creationDate,
                                    transactionCount = transactionsSnapshot.childrenCount.toInt(),
                                    hasDraft = hasDraft,
                                    hasSyncError = it.hasSyncError,
                                    customerType = customerType,
                                    syncing = isSyncing
                                )
                                customerList.add(newCustomer)
                                
                                newCustomer.initialBalance?.let { balance ->
                                    if (balance < 0) youWillGet += -balance else youWillGive += balance
                                }
                            }
                        } catch (e: Exception) { }
                    }
                    val flow = _dataMap.getOrPut(customerType) { MutableStateFlow(RepositoryData()) }
                    flow.value = RepositoryData(customerList, gaveTransactionsList, youWillGet, youWillGive, foundReminder)
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        }

        database.addValueEventListener(listener)
        listenersMap[customerType] = listener
    }
}
