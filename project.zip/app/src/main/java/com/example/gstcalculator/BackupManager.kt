
package com.example.gstcalculator

import android.app.backup.BackupManager
import android.content.Context

class BackupManager(private val context: Context) {

    fun backup() {
        BackupManager(context).dataChanged()
    }

    fun restore() {
        BackupManager(context).requestRestore(null)
    }
}
