package com.example.gstcalculator

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FabPosition
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun StaffLoginScreen(navController: NavController, userPreferences: UserPreferences) {
    val context = LocalContext.current
    val homeViewModel: HomeViewModel = viewModel(key = "home", factory = HomeViewModelFactory(context, "HOME"))
    val localsViewModel: HomeViewModel = viewModel(key = "locals", factory = HomeViewModelFactory(context, "LOCALS"))

    val homeCustomers by homeViewModel.customers
    val localsCustomers by localsViewModel.customers
    val isOnline = homeViewModel.isConnected.value

    val customersWithDrafts = (homeCustomers + localsCustomers).filter { it.hasDraft }

    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var showDraftsDialog by remember { mutableStateOf(false) }
    var showCustomerPickerDialog by remember { mutableStateOf(false) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Staff Login", color = Color.White)
                        if (!isOnline) {
                            Text(
                                text = "Offline",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier
                                    .background(
                                        color = Color.Red,
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1976D2)
                ),
                actions = {
                    IconButton(onClick = {
                        userPreferences.setLoginState("none")
                        navController.navigate("login") {
                            popUpTo("staffLogin") { inclusive = true }
                        }
                    }) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Logout",
                            tint = Color.White
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    if (isOnline) {
                        showCustomerPickerDialog = true
                    } else {
                        Toast.makeText(context, "Please connect to the internet to perform this action", Toast.LENGTH_SHORT).show()
                    }
                },
                containerColor = if (isOnline) Color(0xFF1976D2) else Color.Gray,
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Bill", tint = Color.White)
            }
        },
        floatingActionButtonPosition = FabPosition.Center
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (customersWithDrafts.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    Text("No customers with draft bills.")
                }
            } else {
                LazyColumn {
                    items(customersWithDrafts, key = { it.id ?: it.hashCode() }) { customer ->
                        Column(modifier = Modifier.animateItemPlacement(animationSpec = springSpec)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isOnline) {
                                            selectedCustomer = customer
                                            showDraftsDialog = true
                                        } else {
                                            Toast.makeText(context, "Please connect to the internet to perform this action", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                            ) {
                                Avatar(name = customer.name)
                                Text(
                                    text = customer.name,
                                    modifier = Modifier.padding(start = 16.dp)
                                )
                            }
                            HorizontalDivider(color = Color.LightGray, thickness = 1.dp)
                        }
                    }
                }
            }
        }
    }

    if (showDraftsDialog) {
        selectedCustomer?.let { customer ->
            val transactionViewModel: TransactionViewModel = viewModel(factory = TransactionViewModelFactory(context, customer.id!!, customer.customerType), key = customer.id)
            DraftsDialog(
                viewModel = transactionViewModel,
                onDismiss = { showDraftsDialog = false },
                onDraftClick = { draftId ->
                    if (isOnline) {
                        showDraftsDialog = false
                        navController.navigate("createBill/${customer.id}/${customer.customerType}?draftId=$draftId")
                    } else {
                        Toast.makeText(context, "Please connect to the internet to perform this action", Toast.LENGTH_SHORT).show()
                    }
                },
                onDeleteDraft = { draftId ->
                    if (isOnline) {
                        transactionViewModel.deleteDraft(draftId)
                    } else {
                        Toast.makeText(context, "Please connect to the internet to perform this action", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }
    }

    if (showCustomerPickerDialog) {
        CustomerPickerDialog(
            customers = homeCustomers + localsCustomers,
            onDismiss = { showCustomerPickerDialog = false },
            onCustomerSelected = { customer ->
                if (isOnline) {
                    showCustomerPickerDialog = false
                    navController.navigate("createBill/${customer.id}/${customer.customerType}")
                } else {
                    Toast.makeText(context, "Please connect to the internet to perform this action", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
private fun CustomerPickerDialog(
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onCustomerSelected: (Customer) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredCustomers = remember(searchQuery, customers) {
        if (searchQuery.isBlank()) {
            customers
        } else {
            customers.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                it.phoneNumber?.toString()?.contains(searchQuery) == true
            }
        }
    }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    BouncyDialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White
        ) {
            Column {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(bottom = 16.dp)
                        .zIndex(1f) // Keep header on top during list bounce
                ) {
                    Text(
                        text = "Search Customers",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(16.dp)
                    )
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White,
                            cursorColor = Color.Black,
                            focusedBorderColor = Color.White,
                            unfocusedBorderColor = Color.White.copy(alpha = 0.5f),
                            focusedLabelColor = Color.Gray,
                            unfocusedLabelColor = Color.Gray
                        ),
                        singleLine = true
                    )
                }
                LazyColumn(modifier = Modifier.padding(vertical = 8.dp)) {
                    items(filteredCustomers, key = { it.id ?: it.hashCode() }) { customer ->
                        ListItem(
                            headlineContent = { Text(customer.name) },
                            modifier = Modifier
                                .animateItemPlacement(animationSpec = springSpec)
                                .clickable { onCustomerSelected(customer) }
                        )
                    }
                }
                Box(modifier = Modifier.fillMaxWidth().padding(8.dp), contentAlignment = Alignment.CenterEnd) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                }
            }
        }
    }
}


data class Draft(
    val date: Long = 0L,
    val items: List<BillItem> = emptyList()
)
