package com.example.gstcalculator

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

data class ProfitTransaction(
    val transaction: Transaction,
    val customerName: String,
    val phoneNumber: String = ""
)

class ProfitViewModel(private val itemViewModel: ItemViewModel, initialSearchQuery: String? = null) : ViewModel() {
    private val _profitTransactions = MutableStateFlow<List<ProfitTransaction>>(emptyList())
    private val _searchQuery = MutableStateFlow(initialSearchQuery ?: "")
    val searchQuery = _searchQuery.asStateFlow()

    private val _monthFilter = MutableStateFlow<Pair<Int?, Int?>>(null to null)

    private val _availableYears = MutableStateFlow<List<Int>>(emptyList())
    val availableYears = _availableYears.asStateFlow()

    private val _availableMonths = MutableStateFlow<List<Int>>(emptyList())
    val availableMonths = _availableMonths.asStateFlow()

    val filteredProfitTransactions: StateFlow<List<ProfitTransaction>> = combine(
        _profitTransactions,
        searchQuery,
        _monthFilter,
        itemViewModel.allItems
    ) { transactions, query, monthFilter, allItems ->
        var filteredList = transactions.map { profitTransaction ->
            val updatedItems = profitTransaction.transaction.items.map { billItem ->
                val currentItem = allItems.find { it.name == billItem.name && it.uom == billItem.uom }
                val basePrice = currentItem?.basePrice?.toString() ?: billItem.basePrice
                billItem.copy(basePrice = basePrice)
            }
            val updatedProfit = updatedItems.sumOf { (it.rate.toDoubleOrNull() ?: 0.0) * (it.getQtyDouble()) - (it.basePrice.toDoubleOrNull() ?: 0.0) * (it.getQtyDouble()) }
            profitTransaction.copy(transaction = profitTransaction.transaction.copy(items = updatedItems, profit = updatedProfit))
        }

        if (query.isNotBlank()) {
            val searchWords = query.split(" ").filter { it.isNotBlank() }
            filteredList = filteredList.filter { item ->
                searchWords.all { word ->
                    item.customerName.contains(word, ignoreCase = true) ||
                    item.phoneNumber.contains(word)
                }
            }
        }
        monthFilter.let { (month, year) ->
            if (year != null) {
                filteredList = filteredList.filter {
                    val cal = Calendar.getInstance()
                    cal.timeInMillis = it.transaction.date ?: 0L
                    cal.get(Calendar.YEAR) == year
                }
            }
            if (month != null) {
                filteredList = filteredList.filter {
                    val cal = Calendar.getInstance()
                    cal.timeInMillis = it.transaction.date ?: 0L
                    cal.get(Calendar.MONTH) == month
                }
            }
        }
        filteredList
    }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())


    val totalProfit = filteredProfitTransactions.map { transactions ->
        transactions.sumOf { it.transaction.profit ?: 0.0 }
    }

    private val customersHome = FirebaseDatabase.getInstance().getReference("customers_home")
    private val customersStaff = FirebaseDatabase.getInstance().getReference("customers_staff")
    private val customersLocals = FirebaseDatabase.getInstance().getReference("customers_locals")
    private val databases = listOf(customersHome, customersStaff, customersLocals)

    init {
        fetchProfitTransactions()
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
    }

    fun filterByMonth(month: Int?, year: Int?) {
        _monthFilter.value = Pair(month, year)
        if (year != null) {
            getMonthsForYear(year)
        } else {
            _availableMonths.value = emptyList()
        }
    }

    fun getMonthsForYear(year: Int) {
        _availableMonths.value = _profitTransactions.value
            .filter {
                val cal = Calendar.getInstance()
                it.transaction.date?.let { it1 -> cal.timeInMillis = it1 }
                cal.get(Calendar.YEAR) == year
            }
            .map {
                val cal = Calendar.getInstance()
                it.transaction.date?.let { it1 -> cal.timeInMillis = it1 }
                cal.get(Calendar.MONTH)
            }
            .distinct()
            .sorted()
    }

    private fun fetchProfitTransactions() {
        viewModelScope.launch {
            val databaseTransactionsMap = mutableMapOf<String, List<ProfitTransaction>>()

            databases.forEach { db ->
                val listener = object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        val dbTransactions = mutableListOf<ProfitTransaction>()
                        for (customerSnapshot in snapshot.children) {
                            val customer = customerSnapshot.getValue(Customer::class.java)
                            customer?.let {
                                if (it.customerType != "DELETED") {
                                    for (transactionSnapshot in customerSnapshot.child("transactions").children) {
                                        val transaction = transactionSnapshot.getValue(Transaction::class.java)
                                        if (transaction?.type != "GOT") {
                                            if (transaction?.profit != null) {
                                                val txWithId = transaction.copy(id = transaction.id ?: transactionSnapshot.key)
                                                dbTransactions.add(
                                                    ProfitTransaction(
                                                        transaction = txWithId,
                                                        customerName = it.name ?: "",
                                                        phoneNumber = it.phoneNumber?.toString() ?: ""
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        databaseTransactionsMap[db.key ?: db.toString()] = dbTransactions
                        val combinedList = databaseTransactionsMap.values.flatten()
                            .distinctBy { it.transaction.id ?: it.hashCode() }
                            .sortedByDescending { it.transaction.date }

                        _profitTransactions.value = combinedList
                        _availableYears.value = combinedList.mapNotNull {
                            it.transaction.date?.let { date ->
                                Calendar.getInstance().apply { timeInMillis = date }.get(Calendar.YEAR)
                            }
                        }.distinct().sorted()
                    }

                    override fun onCancelled(error: DatabaseError) {
                        // Handle error
                    }
                }
                db.addValueEventListener(listener)
            }
        }
    }
}
