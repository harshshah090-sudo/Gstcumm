package com.example.gstcalculator

data class DraftBill(
    val id: String = "",
    val date: Long = 0,
    val items: List<BillItem> = emptyList(),
    val lockedBy: String? = null,
    val lockedByName: String? = null,
    val lockTimestamp: Long? = null
)
