package com.example.gstcalculator

data class Item(
    val id: String = "",
    val name: String = "",
    val basePrice: Double = 0.0,
    val uom: String = "",
    val isDeleted: Boolean = false,
    val details: List<String> = emptyList(),
    val oldNames: List<String> = emptyList()
)
