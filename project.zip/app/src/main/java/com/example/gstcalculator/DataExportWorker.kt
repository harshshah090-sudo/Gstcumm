package com.example.gstcalculator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DataExportWorker(private val appContext: Context, workerParams: WorkerParameters) : CoroutineWorker(appContext, workerParams) {

    private val notificationManager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val channelId = "export_channel"
    private val notificationId = 1

    override suspend fun doWork(): Result {
        createNotificationChannel()

        return try {
            val customers = getCustomers()
            val items = getItems()

            val workbook = XSSFWorkbook()
            val customerSheet = workbook.createSheet("Customers")
            val customerRatesSheet = workbook.createSheet("Customer Item Rates")
            val itemSheet = workbook.createSheet("Items")

            // --- Customers Sheet --- 
            val customerHeaderRow = customerSheet.createRow(0)
            customerHeaderRow.createCell(0).setCellValue("Customer Name")
            customerHeaderRow.createCell(1).setCellValue("Phone Number")
            customerHeaderRow.createCell(2).setCellValue("Running Balance")
            customerHeaderRow.createCell(3).setCellValue("Transaction Date")
            customerHeaderRow.createCell(4).setCellValue("Transaction Amount")
            customerHeaderRow.createCell(5).setCellValue("Transaction Note")

            // --- Customer Item Rates Sheet ---
            val ratesHeaderRow = customerRatesSheet.createRow(0)
            ratesHeaderRow.createCell(0).setCellValue("Customer Name")
            ratesHeaderRow.createCell(1).setCellValue("Item Name")
            ratesHeaderRow.createCell(2).setCellValue("Rate")

            // --- Items Sheet ---
            val itemHeaderRow = itemSheet.createRow(0)
            itemHeaderRow.createCell(0).setCellValue("Item Name")
            itemHeaderRow.createCell(1).setCellValue("Item Rate")
            itemHeaderRow.createCell(2).setCellValue("UOM")

            var customerSheetRow = 1
            var ratesSheetRow = 1

            for (customer in customers) {
                // Main customer info row
                val infoRow = customerSheet.createRow(customerSheetRow++)
                infoRow.createCell(0).setCellValue(customer.name)
                infoRow.createCell(1).setCellValue(customer.phoneNumber.toString())
                infoRow.createCell(2).setCellValue(customer.initialBalance ?: 0.0)

                val transactions = getTransactions(customer.id ?: "", customer.customerType)
                val uniqueCustomerRates = mutableSetOf<Pair<String, String>>()

                // Add each transaction to the Customers sheet
                for (transaction in transactions) {
                    val transactionRow = customerSheet.createRow(customerSheetRow++)
                    transaction.date?.let {
                        transactionRow.createCell(3).setCellValue(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(it)))
                    }
                    transactionRow.createCell(4).setCellValue(transaction.amount ?: 0.0)
                    transactionRow.createCell(5).setCellValue(transaction.note ?: "")

                    // Collect unique rates from this transaction's items
                    for (item in transaction.items) {
                        if (item.name.isNotBlank() && item.rate.isNotBlank()) {
                            uniqueCustomerRates.add(item.name to item.rate)
                        }
                    }
                }

                // Write all collected unique rates for this customer to the Customer Item Rates sheet
                for ((itemName, rate) in uniqueCustomerRates) {
                    val rateRow = customerRatesSheet.createRow(ratesSheetRow++)
                    rateRow.createCell(0).setCellValue(customer.name)
                    rateRow.createCell(1).setCellValue(itemName)
                    rateRow.createCell(2).setCellValue(rate)
                }

                if (transactions.isNotEmpty()) {
                    customerSheetRow++ // Add a blank separator row between customers
                }
            }
            
            // Populate the master Items sheet
            var itemSheetRow = 1
            for (item in items) {
                val row = itemSheet.createRow(itemSheetRow++)
                row.createCell(0).setCellValue(item.name)
                row.createCell(1).setCellValue(item.basePrice)
                row.createCell(2).setCellValue(item.uom)
            }

            val file = File(appContext.cacheDir, "ExportedData.xlsx")
            FileOutputStream(file).use { outputStream ->
                workbook.write(outputStream)
            }
            workbook.close()

            val uri: Uri = FileProvider.getUriForFile(appContext, "${appContext.packageName}.provider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val pendingIntent = PendingIntent.getActivity(appContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val successNotification = createNotification("Export Complete", "Tap to open the exported file.", pendingIntent)
            notificationManager.notify(notificationId, successNotification)

            Result.success()
        } catch (e: Exception) {
            val failureNotification = createNotification("Export Failed", "Error: ${e.localizedMessage}", null)
            notificationManager.notify(notificationId, failureNotification)
            Result.failure()
        }
    }

    private suspend fun getCustomers(): List<Customer> {
        val customerList = mutableListOf<Customer>()
        val dbRefs = listOf(
            FirebaseDatabase.getInstance().getReference("customers_home"),
            FirebaseDatabase.getInstance().getReference("customers_staff"),
            FirebaseDatabase.getInstance().getReference("customers_locals")
        )

        for (dbRef in dbRefs) {
            val snapshot: DataSnapshot = dbRef.get().await()
            for (customerSnapshot in snapshot.children) {
                val customer = customerSnapshot.getValue(Customer::class.java)
                customer?.let {
                    it.id = customerSnapshot.key
                    customerList.add(it)
                }
            }
        }
        return customerList
    }

    private suspend fun getItems(): List<Item> {
        val database = FirebaseDatabase.getInstance().getReference("items")
        val snapshot: DataSnapshot = database.get().await()
        val itemList = mutableListOf<Item>()
        for (itemSnapshot in snapshot.children) {
            val item = itemSnapshot.getValue(Item::class.java)
            item?.let { itemList.add(it) }
        }
        return itemList
    }

    private suspend fun getTransactions(customerId: String, customerType: String): List<Transaction> {
        val dbPath = when (customerType) {
            "STAFF" -> "customers_staff"
            "LOCALS" -> "customers_locals"
            else -> "customers_home"
        }
        val database = FirebaseDatabase.getInstance().getReference(dbPath).child(customerId).child("transactions")
        val snapshot: DataSnapshot = database.get().await()
        val transactionList = mutableListOf<Transaction>()
        for (transactionSnapshot in snapshot.children) {
            val transaction = transactionSnapshot.getValue(Transaction::class.java)
            transaction?.let { transactionList.add(it) }
        }
        return transactionList
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Data Export", NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(channel)
        }
    }

    private fun createNotification(title: String, text: String, pendingIntent: PendingIntent?): Notification {
        return NotificationCompat.Builder(appContext, channelId)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload) // Use a standard and safe system icon
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .build()
    }
}