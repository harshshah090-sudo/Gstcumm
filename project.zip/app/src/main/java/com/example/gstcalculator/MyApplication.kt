package com.example.gstcalculator

import android.app.Application
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.database.FirebaseDatabase

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:236813951336:android:84117ecd9b4c963183b6dd")
                    .setProjectId("gst-calculator-fad1d")
                    .setApiKey("AIzaSyBQEWWhkg4yJXsSd6Eo-EaoSoERCVz1t54")
                    .setDatabaseUrl("https://gst-calculator-fad1d-default-rtdb.asia-southeast1.firebasedatabase.app")
                    .setStorageBucket("gst-calculator-fad1d.firebasestorage.app")
                    .build()
                FirebaseApp.initializeApp(this, options)
                Log.d("MyApplication", "Initialized default FirebaseApp with project options")
            }
            // Enable offline persistence
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
            // Ensure the database starts connecting immediately
            FirebaseDatabase.getInstance().goOnline()
        } catch (e: Exception) {
            Log.e("MyApplication", "Firebase initialization error: ${e.message}", e)
        }

        // Initialize DataRepository with context
        try {
            DataRepository.init(this)
        } catch (e: Exception) {
            Log.e("MyApplication", "DataRepository init error: ${e.message}", e)
        }
    }
}

