package com.example.gstcalculator

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ItemPickerDialog(
    onDismiss: () -> Unit,
    onItemsSelected: (List<Pair<Item, String>>) -> Unit,
    uomViewModel: UomViewModel,
    isStaff: Boolean
) {
    val itemViewModel: ItemViewModel = viewModel(key = "ItemViewModel")
    val items by itemViewModel.allItems.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    
    val selectedOrder = remember { mutableStateListOf<Item>() }
    val selectedQtys = remember { mutableStateMapOf<Item, String>() }
    
    var showAddItemDialog by remember { mutableStateOf(false) }
    var showManageUomDialog by remember { mutableStateOf(false) }
    var editingItemId by remember { mutableStateOf<String?>(null) }
    val keyboardController = LocalSoftwareKeyboardController.current
    val searchFocusRequester = remember { FocusRequester() }
    var focusedItemId by remember { mutableStateOf<String?>(null) }

    val filteredItems = remember(searchQuery, items) {
        val baseList = if (searchQuery.isBlank()) {
            items
        } else {
            val searchTerms = searchQuery.split(" ").filter { it.isNotBlank() }
            items.filter { item ->
                searchTerms.all { term ->
                    item.name.contains(term, ignoreCase = true) || item.uom.contains(term, ignoreCase = true)
                }
            }
        }
        baseList.sortedWith { a, b -> AlphaNumericComparator.compare(a.name, b.name) }
    }

    // Fix for Issue 4: Improved keyboard opening logic
    LaunchedEffect(Unit) {
        // Wait for the dialog animation to settle
        delay(600)
        try {
            searchFocusRequester.requestFocus()
            keyboardController?.show()
        } catch (e: Exception) {}
        
        // Secondary attempt in case the first one was too early
        delay(200)
        try {
            searchFocusRequester.requestFocus()
            keyboardController?.show()
        } catch (e: Exception) {}
    }

    if (showAddItemDialog) {
        AddItemDialog(
            onDismiss = { showAddItemDialog = false },
            onAddItem = { name: String, basePrice: String, uom: String, details: List<String> ->
                itemViewModel.addItem(name, basePrice, uom, details)
                showAddItemDialog = false
            },
            uomViewModel = uomViewModel,
            onEditUomClicked = { showManageUomDialog = true }
        )
    }

    if (showManageUomDialog) {
        ManageUomDialog(onDismiss = { showManageUomDialog = false }, uomViewModel = uomViewModel)
    }

    editingItemId?.let { id ->
        val item = items.find { it.id == id }
        if (item != null) {
            EditItemDialog(
                item = item,
                onDismiss = { editingItemId = null },
                onSave = { updatedItem: Item ->
                    itemViewModel.updateItem(updatedItem)
                    editingItemId = null
                },
                onDelete = {
                    itemViewModel.deleteItem(id)
                    editingItemId = null
                },
                uomViewModel = uomViewModel
            )
        } else {
            editingItemId = null
        }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card {
            Column {
                Column(
                    modifier = Modifier
                        .background(Color(0xFF1976D2))
                        .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Add Items",
                            color = Color.White,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        if (!isStaff) {
                            IconButton(onClick = { showAddItemDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = "Add Item", tint = Color.White)
                            }
                        }
                        IconButton(onClick = {
                            val result = selectedOrder.map { it to (selectedQtys[it] ?: "") }
                            onItemsSelected(result)
                            onDismiss()
                        }) {
                            Icon(Icons.Default.Check, contentDescription = "Done", tint = Color.White)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        BasicTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            modifier = Modifier
                                .fillMaxWidth()
                                .focusRequester(searchFocusRequester),
                            textStyle = TextStyle(fontSize = 16.sp, color = Color.Black),
                            singleLine = true,
                            cursorBrush = SolidColor(Color(0xFF1976D2)),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(
                                onDone = {
                                    val result = selectedOrder.map { it to (selectedQtys[it] ?: "") }
                                    onItemsSelected(result)
                                    onDismiss()
                                }
                            ),
                            decorationBox = { innerTextField ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Search,
                                        contentDescription = "Search Icon",
                                        tint = Color(0xFF1976D2)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                        if (searchQuery.isEmpty()) {
                                            Text("Search Items...", color = Color.Gray, fontSize = 16.sp)
                                        }
                                        innerTextField()
                                    }
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { 
                                            searchQuery = ""
                                            searchFocusRequester.requestFocus()
                                            keyboardController?.show()
                                        }) {
                                            Icon(
                                                imageVector = Icons.Default.Clear,
                                                contentDescription = "Clear Search",
                                                tint = Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        )
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .height(400.dp)
                        .background(Color(0xFFF5F5F5))
                        .pointerInput(Unit) {
                            detectVerticalDragGestures { change, dragAmount ->
                                change.consume()
                                if (dragAmount > 0) {
                                    searchQuery = ""
                                }
                            }
                        }
                        .padding(top = 8.dp)
                ) {
                    items(filteredItems, key = { it.id }) { item ->
                        ItemPickerRow(
                            item = item,
                            isSelected = selectedQtys.containsKey(item),
                            onCheckedChange = { checked ->
                                if (checked) {
                                    if (!selectedQtys.containsKey(item)) {
                                        selectedOrder.add(item)
                                        selectedQtys[item] = ""
                                    }
                                    focusedItemId = item.id
                                } else {
                                    selectedOrder.remove(item)
                                    selectedQtys.remove(item)
                                }
                            },
                            qty = selectedQtys[item] ?: "",
                            onQtyChange = { qty -> selectedQtys[item] = qty },
                            onLongClick = { if (!isStaff) editingItemId = item.id },
                            isFocused = focusedItemId == item.id,
                            onFocusHandled = { focusedItemId = null },
                            onDone = {
                                val result = selectedOrder.map { it to (selectedQtys[it] ?: "") }
                                onItemsSelected(result)
                                onDismiss()
                            },
                            onSearchNext = {
                                searchQuery = ""
                                try {
                                    searchFocusRequester.requestFocus()
                                    keyboardController?.show()
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.animateItemPlacement(
                                animationSpec = spring(
                                    dampingRatio = Spring.DampingRatioMediumBouncy,
                                    stiffness = Spring.StiffnessLow
                                )
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemPickerRow(
    item: Item,
    isSelected: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    qty: String,
    onQtyChange: (String) -> Unit,
    onLongClick: () -> Unit,
    isFocused: Boolean,
    onFocusHandled: () -> Unit,
    onDone: () -> Unit,
    onSearchNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(isFocused) {
        if (isFocused) {
            delay(100)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {}
            onFocusHandled()
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { onCheckedChange(!isSelected) },
                onLongClick = onLongClick
            )
            .background(Color.White)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Checkbox(
                checked = isSelected,
                onCheckedChange = onCheckedChange,
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.name,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )
                Text(
                    text = item.uom,
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            }
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .width(80.dp)
                        .height(40.dp)
                        .border(1.dp, Color(0xFF1976D2), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    BasicTextField(
                        value = qty,
                        onValueChange = onQtyChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        textStyle = TextStyle(
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = Color(0xFF1976D2)
                        ),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Search
                        ),
                        keyboardActions = KeyboardActions(
                            onSearch = { onSearchNext() },
                            onDone = {
                                keyboardController?.hide()
                                onDone()
                            }
                        ),
                        singleLine = true,
                        decorationBox = { innerTextField ->
                            if (qty.isEmpty()) {
                                Text(
                                    "Qty",
                                    color = Color.LightGray,
                                    fontSize = 16.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            innerTextField()
                        }
                    )
                }
            }
        }
        HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
    }
}
