package com.example.gstcalculator

import com.itextpdf.io.font.constants.StandardFonts
import com.itextpdf.kernel.colors.DeviceGray
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.layout.Canvas
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.AreaBreak
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.IBlockElement
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.property.TextAlignment
import com.itextpdf.layout.property.UnitValue
import com.itextpdf.layout.property.VerticalAlignment
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfGenerator {

    fun createDraftPdf(
        customer: Customer?,
        date: Long,
        billItems: List<BillItem>,
        printTwoCopies: Boolean = false
    ): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A5, false)
        val margin = 5 * 2.83465f
        document.setMargins(margin, margin, margin, margin)

        val draftContent = createDraftContent(customer, date, billItems)
        draftContent.forEach { document.add(it) }

        if (printTwoCopies) {
            if (billItems.size <= 7) {
                // 2-in-1 flipped on same page for short bills
                document.flush()
                val pSize = PageSize.A5
                val numberOfPages = pdf.numberOfPages
                if (numberOfPages > 0) {
                    val draftContentForFlip = createDraftContent(customer, date, billItems)
                    for (i in 1..numberOfPages) {
                        val page = pdf.getPage(i)
                        val pdfCanvas = PdfCanvas(page)
                        pdfCanvas.saveState()
                        pdfCanvas.concatMatrix(-1.0, 0.0, 0.0, -1.0, pSize.width.toDouble(), pSize.height.toDouble())
                        val canvasArea = pSize.clone()
                        canvasArea.applyMargins(margin, margin, margin, margin, false)
                        val layoutCanvas = Canvas(pdfCanvas, canvasArea)
                        draftContentForFlip.forEach { layoutCanvas.add(it) }
                        layoutCanvas.close()
                        pdfCanvas.restoreState()
                    }
                }
            } else {
                // SEPARATE PAGES for long bills
                document.add(AreaBreak())
                createDraftContent(customer, date, billItems).forEach { document.add(it) }
            }
        }

        document.close()
        return outputStream.toByteArray()
    }

    private fun createDraftContent(
        customer: Customer?,
        date: Long,
        billItems: List<BillItem>
    ): List<IBlockElement> {
        val boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD)
        val regularFont = PdfFontFactory.createFont(StandardFonts.HELVETICA)
        val greyColor = DeviceGray(0.5f)
        val elements = mutableListOf<IBlockElement>()

        elements.add(
            Paragraph("Drafted Bill")
                .setFont(boldFont)
                .setFontSize(20f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(8f)
        )

        val customerInfoTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth()
        customerInfoTable.addCell(
            Cell().add(Paragraph(customer?.name ?: "")
                .setFont(boldFont)
                .setFontSize(12f))
                .setBorder(Border.NO_BORDER)
        )
        customerInfoTable.addCell(
            Cell().add(Paragraph(SimpleDateFormat("dd / MMM / yyyy", Locale.getDefault()).format(Date(date)))
                .setFont(regularFont)
                .setFontSize(12f))
                .setTextAlignment(TextAlignment.RIGHT)
                .setBorder(Border.NO_BORDER)
        )
        elements.add(customerInfoTable)

        val columnWidths = floatArrayOf(10f, 40f, 15f, 15f, 20f)
        val table = Table(UnitValue.createPercentArray(columnWidths)).useAllAvailableWidth()
        table.setBorder(SolidBorder(greyColor, 1f))

        val headers = listOf("S.N.", "Item Names", "Qty", "UOM", "Rate")
        headers.forEach { header ->
            table.addHeaderCell(
                Cell().add(Paragraph(header)
                    .setFont(boldFont)
                    .setFontSize(12f)
                    .setTextAlignment(TextAlignment.CENTER))
                    .setBorder(Border.NO_BORDER)
                    .setBorderBottom(SolidBorder(greyColor, 1f))
            )
        }

        billItems.forEachIndexed { index, billItem ->
            val cellAlignments = listOf(TextAlignment.CENTER, TextAlignment.LEFT, TextAlignment.RIGHT, TextAlignment.CENTER, TextAlignment.RIGHT)
            val cellData = listOf(
                (index + 1).toString(),
                billItem.name,
                billItem.getQtyString(),
                billItem.uom,
                billItem.rate
            )

            cellData.forEachIndexed { cellIndex, text ->
                val cell = Cell().add(Paragraph(text))
                    .setFont(regularFont)
                    .setFontSize(12f)
                    .setTextAlignment(cellAlignments[cellIndex])
                    .setBorder(Border.NO_BORDER)
                
                if (cellIndex > 0) {
                    cell.setBorderLeft(SolidBorder(greyColor, 1f))
                }
                table.addCell(cell)
            }
        }
        elements.add(table)

        elements.add(
            Paragraph("*The Bill will be sent to you after completion")
                .setFont(regularFont)
                .setFontSize(10f)
                .setMarginTop(8f)
        )
        
        return elements
    }

    fun createPdf(
        customer: Customer?,
        date: Long,
        billItems: List<BillItem>,
        totalAmount: Double,
        transactionsWithBalances: List<Pair<Transaction, Double>>,
        isPaid: Boolean,
        isPurchaseReturn: Boolean,
        printTwoCopies: Boolean,
        currentTransactionId: String? = null
    ): ByteArray {
        val outputStream = ByteArrayOutputStream()
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A5, false)

        val margin = 5 * 2.83465f
        document.setMargins(margin, margin, margin, margin)

        val billContent = createBillContent(customer, date, billItems, totalAmount, transactionsWithBalances, isPaid, isPurchaseReturn, currentTransactionId)
        billContent.forEach { document.add(it) }
        
        if (printTwoCopies) {
            if (billItems.size <= 7) {
                // 2-in-1 flipped on same page for short bills
                document.flush()
                val pSize = PageSize.A5
                val numberOfPages = pdf.numberOfPages
                if (numberOfPages > 0) {
                    val billContentForFlip = createBillContent(customer, date, billItems, totalAmount, transactionsWithBalances, isPaid, isPurchaseReturn, currentTransactionId)
                    for (i in 1..numberOfPages) {
                        val page = pdf.getPage(i)
                        val pdfCanvas = PdfCanvas(page)
                        pdfCanvas.saveState()
                        pdfCanvas.concatMatrix(-1.0, 0.0, 0.0, -1.0, pSize.width.toDouble(), pSize.height.toDouble())
                        val canvasArea = pSize.clone()
                        canvasArea.applyMargins(margin, margin, margin, margin, false)
                        val layoutCanvas = Canvas(pdfCanvas, canvasArea)
                        billContentForFlip.forEach { layoutCanvas.add(it) }
                        layoutCanvas.close()
                        pdfCanvas.restoreState()
                    }
                }
            } else {
                // SEPARATE PAGES for long bills
                document.add(AreaBreak())
                createBillContent(customer, date, billItems, totalAmount, transactionsWithBalances, isPaid, isPurchaseReturn, currentTransactionId).forEach { document.add(it) }
            }
        }

        if (isPaid) {
            val font = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD)
            val pSize = PageSize.A5
            val watermark = Paragraph("PAID")
                .setFont(font)
                .setFontSize(80f)
                .setOpacity(0.25f)
                .setFontColor(DeviceGray(0.75f))

            for (i in 1..pdf.numberOfPages) {
                document.showTextAligned(
                    watermark,
                    pSize.width / 2,
                    pSize.height / 2,
                    i, TextAlignment.CENTER, VerticalAlignment.MIDDLE, 45f
                )
            }
        }

        document.close()
        return outputStream.toByteArray()
    }

    private fun createBillContent(
        customer: Customer?,
        date: Long,
        billItems: List<BillItem>,
        totalAmount: Double,
        transactionsWithBalances: List<Pair<Transaction, Double>>,
        isPaid: Boolean,
        isPurchaseReturn: Boolean,
        currentTransactionId: String? = null
    ): List<IBlockElement> {
        val regularFont = PdfFontFactory.createFont(StandardFonts.HELVETICA)
        val boldFont = PdfFontFactory.createFont(StandardFonts.HELVETICA_BOLD)
        val greyColor = DeviceGray(0.5f)

        val elements = mutableListOf<IBlockElement>()

        elements.add(
            Paragraph(if (isPurchaseReturn) "PURCHASE RETURN" else "QUOTATION")
                .setFont(boldFont)
                .setFontSize(20f)
                .setTextAlignment(TextAlignment.CENTER)
                .setMargin(0f)
                .setMarginBottom(8f)
        )

        val customerInfoTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth()
        val customerNameCell = Cell().add(Paragraph(customer?.name ?: "")
            .setFont(boldFont)
            .setFontSize(12f))
            .setBorder(Border.NO_BORDER)
        val dateCell = Cell().add(Paragraph(SimpleDateFormat("dd / MMM / yyyy", Locale.getDefault()).format(Date(date)))
            .setFont(regularFont)
            .setFontSize(12f))
            .setTextAlignment(TextAlignment.RIGHT)
            .setBorder(Border.NO_BORDER)

        customerInfoTable.addCell(customerNameCell)
        customerInfoTable.addCell(dateCell)
        customerInfoTable.setMarginBottom(8f)
        elements.add(customerInfoTable)


        val columnWidths = floatArrayOf(8f, 49f, 10f, 10f, 10f, 13f)
        val table = Table(UnitValue.createPercentArray(columnWidths)).useAllAvailableWidth()
        table.setBorder(SolidBorder(greyColor, 1f))

        val headers = listOf("S.N", "Item Name", "Qty", "UOM", "Rate", "Amount")
        val headerAlignments = listOf(TextAlignment.CENTER, TextAlignment.CENTER, TextAlignment.RIGHT, TextAlignment.CENTER, TextAlignment.RIGHT, TextAlignment.RIGHT)

        headers.forEachIndexed { index, headerText ->
            val cell = Cell().add(Paragraph(headerText))
                .setPaddingTop(2f)
                .setPaddingBottom(2f)
                .setPaddingLeft(6f)
                .setPaddingRight(6f)
                .setFont(boldFont)
                .setFontSize(12f)
                .setTextAlignment(headerAlignments[index])
                .setBorder(Border.NO_BORDER)
                .setBorderBottom(SolidBorder(greyColor, 1f))
            table.addHeaderCell(cell)
        }

        billItems.forEachIndexed { index, billItem ->
            val qtyDouble = billItem.getQtyDouble()
            val rateDouble = billItem.rate.toDoubleOrNull() ?: 0.0
            val amount = qtyDouble * rateDouble

            val cellData = listOf(
                (index + 1).toString(),
                billItem.name,
                billItem.getQtyString(),
                billItem.uom,
                formatDecimal(rateDouble),
                formatDecimal(amount)
            )

            val cellAlignments = listOf(TextAlignment.CENTER, TextAlignment.LEFT, TextAlignment.RIGHT, TextAlignment.CENTER, TextAlignment.RIGHT, TextAlignment.RIGHT)

            cellData.forEachIndexed { cellIndex, text ->
                val cell = Cell().add(Paragraph(text))
                    .setPaddingTop(2f)
                    .setPaddingBottom(2f)
                    .setPaddingLeft(6f)
                    .setPaddingRight(6f)
                    .setFont(regularFont)
                    .setFontSize(12f)
                    .setTextAlignment(cellAlignments[cellIndex])
                    .setBorder(Border.NO_BORDER)

                if (cellIndex > 0) {
                    cell.setBorderLeft(SolidBorder(greyColor, 1f))
                }
                table.addCell(cell)
            }
        }

        // Robust recalculation of balance for any date/time change
        val lastRunningBalance = transactionsWithBalances
            .map { it.first } // Get just the transactions
            .filter { it.id != currentTransactionId } // Exclude the current bill being edited
            .filter { (it.date ?: 0L) <= date } // Only transactions on or before the new date
            .sortedWith(compareBy<Transaction> { it.date ?: 0L }.thenBy { it.id ?: "" })
            .sumOf { t -> if (t.type == "GAVE") (t.amount ?: 0.0) else -(t.amount ?: 0.0) }

        val netAmount = if (isPaid) {
            lastRunningBalance
        } else if (isPurchaseReturn) {
            lastRunningBalance - totalAmount
        } else {
            lastRunningBalance + totalAmount
        }

        val summaryTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f, 1f))).useAllAvailableWidth()

        val netAmountCell = Cell().add(Paragraph("Net: ${formatDecimal(netAmount)}"))
            .setFont(boldFont)
            .setFontSize(12f)
            .setTextAlignment(TextAlignment.LEFT)
            .setBorder(Border.NO_BORDER)
            .setPadding(4f)

        val lastBalanceCell = Cell().add(Paragraph("L.B. : ${formatDecimal(lastRunningBalance)}"))
            .setFont(boldFont)
            .setFontSize(12f)
            .setTextAlignment(TextAlignment.CENTER)
            .setBorder(Border.NO_BORDER)
            .setBorderLeft(SolidBorder(greyColor, 1f))
            .setPadding(4f)

        val totalAmountCell = Cell().add(Paragraph("Total: ${formatDecimal(totalAmount)}"))
            .setFont(boldFont)
            .setFontSize(12f)
            .setTextAlignment(TextAlignment.RIGHT)
            .setBorder(Border.NO_BORDER)
            .setBorderLeft(SolidBorder(greyColor, 1f))
            .setPadding(4f)

        summaryTable.addCell(netAmountCell)
        summaryTable.addCell(lastBalanceCell)
        summaryTable.addCell(totalAmountCell)

        val summaryContainerCell = Cell(1, 6).add(summaryTable).setPadding(0f).setBorder(Border.NO_BORDER).setBorderTop(SolidBorder(greyColor, 1f))
        table.addCell(summaryContainerCell)

        elements.add(table)
        return elements
    }

    private fun formatDecimal(value: Double): String {
        return if (value == value.toLong().toDouble()) {
            String.format("%d", value.toLong())
        } else {
            String.format("%.2f", value)
        }
    }
}
