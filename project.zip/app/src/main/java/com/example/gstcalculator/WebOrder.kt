package com.example.gstcalculator

import android.util.Log
import com.google.firebase.database.DataSnapshot

data class WebOrder(
    var id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerType: String = "HOME",
    val date: Long = 0,
    val items: List<BillItem> = emptyList(),
    val status: String = "Pending"
) {
    companion object {
        fun fromSnapshot(snapshot: DataSnapshot): WebOrder? {
            return try {
                val map = snapshot.value as? Map<*, *> ?: return null
                
                val itemsList = mutableListOf<BillItem>()
                val itemsSnapshot = snapshot.child("items")
                if (itemsSnapshot.exists()) {
                    itemsSnapshot.children.forEach { itemSnap ->
                        val itemMap = itemSnap.value as? Map<*, *>
                        if (itemMap != null) {
                            itemsList.add(BillItem(
                                itemId = itemMap["itemId"] as? String ?: "",
                                name = itemMap["name"] as? String ?: "",
                                qty = itemMap["qty"],
                                rate = itemMap["rate"] as? String ?: "",
                                uom = itemMap["uom"] as? String ?: "",
                                basePrice = itemMap["basePrice"] as? String ?: "",
                                breakdown = itemMap["breakdown"]
                            ))
                        }
                    }
                }

                WebOrder(
                    id = snapshot.key ?: "",
                    customerId = map["customerId"] as? String ?: "",
                    customerName = map["customerName"] as? String ?: "",
                    customerType = map["customerType"] as? String ?: "HOME",
                    date = (map["date"] as? Number)?.toLong() ?: 0L,
                    items = itemsList,
                    status = map["status"] as? String ?: "Pending"
                )
            } catch (e: Exception) {
                Log.e("WebOrder", "Error parsing WebOrder", e)
                null
            }
        }
    }
}
