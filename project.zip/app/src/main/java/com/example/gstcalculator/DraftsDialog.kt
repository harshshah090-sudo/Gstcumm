package com.example.gstcalculator

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun DraftsDialog(
    viewModel: TransactionViewModel,
    onDismiss: () -> Unit,
    onDraftClick: (String) -> Unit,
    onDeleteDraft: (String) -> Unit
) {
    val drafts by viewModel.drafts
    var showDeleteConfirmDialog by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val userPreferences = remember { UserPreferences(context) }
    val deviceId = remember { userPreferences.getDeviceId() }
    val userName by viewModel.userName
    
    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    // To prevent the "flicker" on open, we only auto-dismiss after a small delay 
    // to give Firebase time to sync.
    var hasInitialized by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(1000) // 1 second grace period for loading
        hasInitialized = true
    }

    // Auto-dismiss if drafts become empty (e.g. after completing a bill)
    LaunchedEffect(drafts) {
        if (hasInitialized && drafts.isEmpty()) {
            onDismiss()
        }
    }

    showDeleteConfirmDialog?.let { draftIdToDelete ->
        BouncyDialog(onDismissRequest = { showDeleteConfirmDialog = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Delete Draft", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Are you sure you want to delete this draft?")
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showDeleteConfirmDialog = null }) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                onDeleteDraft(draftIdToDelete)
                                showDeleteConfirmDialog = null
                            }
                        ) {
                            Text("Delete", color = Color(0xFF1976D2))
                        }
                    }
                }
            }
        }
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color.White
        ) {
            Column {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                        .zIndex(1f), // Keep header on top
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Drafts",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                }

                if (drafts.isEmpty()) {
                    Box(
                        modifier = Modifier.padding(32.dp).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("No draft bills for this customer.", color = Color.Gray)
                    }
                } else {
                    LazyColumn(modifier = Modifier.padding(vertical = 8.dp)) {
                        itemsIndexed(drafts, key = { _, draft -> draft.id }) { index, draft ->
                            val currentTime = System.currentTimeMillis()
                            val lockTimestamp = draft.lockTimestamp
                            val isLocked = draft.lockedBy != null && 
                                           draft.lockedBy != deviceId && 
                                           lockTimestamp != null && 
                                           (currentTime - lockTimestamp) < 5 * 60 * 1000

                            Column(
                                modifier = Modifier
                                    .animateItemPlacement(animationSpec = springSpec)
                                    .pointerInput(Unit) {
                                        detectTapGestures(
                                            onTap = { 
                                                if (isLocked) {
                                                    Toast.makeText(context, "Another user editing the draft", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    if (viewModel.isConnected.value) {
                                                        viewModel.tryLockDraft(draft.id, deviceId, userName ?: "Unknown User") { success, _ ->
                                                            if (success) {
                                                                onDraftClick(draft.id)
                                                            } else {
                                                                Toast.makeText(context, "Another user editing the draft", Toast.LENGTH_SHORT).show()
                                                            }
                                                        }
                                                    } else {
                                                        Toast.makeText(context, "Cannot open draft while offline", Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            },
                                            onLongPress = { 
                                                if (!isLocked) {
                                                    showDeleteConfirmDialog = draft.id 
                                                }
                                            }
                                        )
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "${index + 1}.", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                                    Column(modifier = Modifier.padding(start = 16.dp).weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Drafted on - ",
                                                color = Color.Black
                                            )
                                            Text(
                                                text = SimpleDateFormat(
                                                    "dd MMM yy : hh:mma",
                                                    Locale.getDefault()
                                                ).format(Date(draft.date)),
                                                fontSize = 12.sp,
                                                color = Color(0xFF1976D2),
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                        if (isLocked) {
                                            Text(
                                                text = "Another user editing the draft",
                                                color = Color(0xFFD50000),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                    if (isLocked) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = "Locked",
                                            tint = Color(0xFFD50000),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                if (index < drafts.size - 1) {
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f), thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }

                // Close Button
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp),
                    contentAlignment = Alignment.CenterEnd
                ) {
                    TextButton(
                        onClick = onDismiss,
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                    ) {
                        Text("Close", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
