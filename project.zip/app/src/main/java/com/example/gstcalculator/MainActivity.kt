package com.example.gstcalculator

import android.app.Activity
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.gstcalculator.ui.theme.GSTCalculatorTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val view = LocalView.current
            SideEffect {
                val window = (view.context as? Activity)?.window
                if (window != null) {
                    WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
                }
            }
            GSTCalculatorTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color.White
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    var showAddItemDialog by remember { mutableStateOf(false) }
    val itemViewModel: ItemViewModel = viewModel()
    val context = LocalContext.current
    val userPreferences = remember { UserPreferences(context) }
    
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    var isGlobalLockActive by remember { mutableStateOf(userPreferences.isBypassDisabled()) }

    // Start preloading if user is already logged in
    LaunchedEffect(Unit) {
        if (FirebaseAuth.getInstance().currentUser != null) {
            val role = userPreferences.getLoginState()
            DataRepository.isAdmin = role == "admin"
            DataRepository.preloadData(listOf("HOME", "LOCALS", "STAFF"))
        }
    }

    // 1. GLOBAL KILL-SWITCH OBSERVER
    LaunchedEffect(Unit) {
        val database = FirebaseDatabase.getInstance()
        val bypassLockRef = database.getReference("app_config/is_bypass_disabled")
        
        bypassLockRef.keepSynced(true)
        
        bypassLockRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val disabled = snapshot.getValue(Boolean::class.java) ?: false
                isGlobalLockActive = disabled
                userPreferences.setBypassDisabled(disabled)
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    // 2. AUTO-LOGOUT & HARD RESET LOGIC (Triggers on ALL devices instantly)
    LaunchedEffect(isGlobalLockActive) {
        if (isGlobalLockActive) {
            // A. Force Hard Logout on this device instantly
            if (FirebaseAuth.getInstance().currentUser != null) {
                FirebaseAuth.getInstance().signOut()
                userPreferences.setLoginState("none")
                mainVibrate(context, 1000)
            }
            
            // B. Kick user back to calculator and clear entire backstack
            if (currentRoute != null && currentRoute != "calculator") {
                navController.navigate("calculator") {
                    popUpTo(0) { inclusive = true }
                }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = "calculator",
        enterTransition = { fadeIn(animationSpec = tween(150)) },
        exitTransition = { fadeOut(animationSpec = tween(150)) },
        popEnterTransition = { fadeIn(animationSpec = tween(150)) },
        popExitTransition = { fadeOut(animationSpec = tween(150)) }
    ) {
        composable("calculator") {
            CalculatorScreen(navController = navController, onBypass = {
                val currentUser = FirebaseAuth.getInstance().currentUser
                val destination = if (currentUser == null) {
                    "login"
                } else {
                    // Preload data the moment bypass happens
                    DataRepository.preloadData(listOf("HOME", "LOCALS", "STAFF"))
                    when (userPreferences.getLoginState()) {
                        "admin" -> "main"
                        "staff" -> "staffLogin"
                        else -> "login"
                    }
                }
                navController.navigate(destination) {
                    popUpTo("calculator") { inclusive = true }
                }
            }) { (context as? Activity)?.finish() }
        }
        composable("login") {
            LoginScreen(
                onLoginSuccess = { userRole ->
                    userPreferences.setLoginState(userRole)
                    DataRepository.isAdmin = userRole == "admin"
                    // Preload data on successful login
                    DataRepository.preloadData(listOf("HOME", "LOCALS", "STAFF"))
                    val destination = when (userRole) {
                        "admin" -> "main"
                        "staff" -> "staffLogin"
                        else -> "main"
                    }
                    navController.navigate(destination) {
                        popUpTo("login") { inclusive = true }
                    }
                },
                onBackPressed = {
                    navController.navigate("calculator") {
                        popUpTo("login") { inclusive = true }
                    }
                }
            )
        }
        composable("staffLogin") {
            HandleBackPress(navController) {
                StaffLoginScreen(navController = navController, userPreferences = userPreferences)
            }
        }
        composable(
            route = "main?customerType={customerType}",
            arguments = listOf(navArgument("customerType") { type = NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val customerType = backStackEntry.arguments?.getString("customerType")
            HandleBackPress(navController) {
                MainScreen(
                    navController = navController,
                    showAddItemDialog = showAddItemDialog,
                    onShowAddItemDialogChange = { value -> showAddItemDialog = value },
                    itemViewModel = itemViewModel,
                    initialCustomerType = customerType
                )
            }
        }
        composable("settings") {
            SettingsScreen(navController)
        }
        composable("recycleBin") {
            RecycleBinScreen(navController)
        }
        composable("paymentReminders") {
            PaymentRemindersScreen(navController)
        }
        composable("webOrders") {
            WebOrdersScreen(navController)
        }
        composable(
            route = "profit?searchQuery={searchQuery}",
            arguments = listOf(navArgument("searchQuery") { type = NavType.StringType; nullable = true })
        ) { backStackEntry ->
            val searchQuery = backStackEntry.arguments?.getString("searchQuery")
            ProfitScreen(itemViewModel = itemViewModel, searchQuery = searchQuery, navController = navController)
        }
        composable("salesAndCashReceived") {
            SalesAndCashReceivedScreen(navController = navController)
        }
        composable("transaction/{customerId}/{customerType}") { backStackEntry ->
            val customerId = backStackEntry.arguments?.getString("customerId")
            val customerType = backStackEntry.arguments?.getString("customerType") ?: ""
            TransactionScreen(navController, customerId, customerType)
        }
        composable("editCustomer/{customerId}/{customerType}") { backStackEntry ->
            val customerId = backStackEntry.arguments?.getString("customerId")
            val customerType = backStackEntry.arguments?.getString("customerType") ?: ""
            customerId?.let {
                EditCustomerScreen(navController, it, customerType)
            }
        }
        composable("customerCatalog/{customerId}/{customerType}") { backStackEntry ->
            val customerId = backStackEntry.arguments?.getString("customerId") ?: ""
            val customerType = backStackEntry.arguments?.getString("customerType") ?: ""
            CustomerCatalogScreen(navController, customerId, customerType)
        }
        composable("transactionRecycleBin/{customerId}/{customerType}") { backStackEntry ->
            val customerId = backStackEntry.arguments?.getString("customerId") ?: ""
            val customerType = backStackEntry.arguments?.getString("customerType") ?: ""
            TransactionRecycleBinScreen(navController, customerId, customerType)
        }
        composable(
            route = "createBill/{customerId}/{customerType}?transactionId={transactionId}&draftId={draftId}&webOrderId={webOrderId}&isPurchaseReturn={isPurchaseReturn}",
            arguments = listOf(
                navArgument("customerId") { type = NavType.StringType },
                navArgument("customerType") { type = NavType.StringType },
                navArgument("transactionId") { type = NavType.StringType; nullable = true },
                navArgument("draftId") { type = NavType.StringType; nullable = true },
                navArgument("webOrderId") { type = NavType.StringType; nullable = true },
                navArgument("isPurchaseReturn") { type = NavType.BoolType; defaultValue = false }
            )
        ) { backStackEntry ->
            val customerId = backStackEntry.arguments?.getString("customerId")
            val customerType = backStackEntry.arguments?.getString("customerType") ?: ""
            val transactionId = backStackEntry.arguments?.getString("transactionId")
            val draftId = backStackEntry.arguments?.getString("draftId")
            val webOrderId = backStackEntry.arguments?.getString("webOrderId")
            val isPurchaseReturn = backStackEntry.arguments?.getBoolean("isPurchaseReturn") ?: false
            CreateBill(
                navController = navController,
                customerId = customerId,
                transactionId = transactionId,
                draftId = draftId,
                webOrderId = webOrderId,
                isPurchaseReturn = isPurchaseReturn,
                customerType = customerType,
                userPreferences = userPreferences,
                itemViewModel = itemViewModel
            )
        }
        composable(
            route = "pdfViewer/{pdfPath}?phoneNumber={phoneNumber}&customerName={customerName}",
            arguments = listOf(
                navArgument("pdfPath") { type = NavType.StringType },
                navArgument("phoneNumber") { type = NavType.StringType; nullable = true },
                navArgument("customerName") { type = NavType.StringType; nullable = true }
            )
        ) { backStackEntry ->
            val pdfPath = URLDecoder.decode(backStackEntry.arguments?.getString("pdfPath") ?: "", StandardCharsets.UTF_8.name())
            val phoneNumber = backStackEntry.arguments?.getString("phoneNumber")
            val customerName = backStackEntry.arguments?.getString("customerName")
            PdfViewerScreen(navController, pdfPath, phoneNumber, customerName)
        }
    }
}

fun mainVibrate(context: Context, duration: Long) {
    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE))
    else @Suppress("DEPRECATION") vibrator.vibrate(duration)
}

@Composable
fun HandleBackPress(navController: NavHostController, content: @Composable () -> Unit) {
    var lastBackPress by remember { mutableStateOf(0L) }
    val context = LocalContext.current

    BackHandler {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBackPress < 1000) {
            navController.navigate("calculator") {
                popUpTo(0) { inclusive = true }
            }
        } else {
            Toast.makeText(context, "Press back again to go to Calculator", Toast.LENGTH_SHORT).show()
            lastBackPress = currentTime
        }
    }
    content()
}
