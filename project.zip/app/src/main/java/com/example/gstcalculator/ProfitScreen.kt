package com.example.gstcalculator

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import java.io.File
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class ProfitViewModelFactory(
    private val itemViewModel: ItemViewModel,
    private val initialSearchQuery: String?
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ProfitViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ProfitViewModel(itemViewModel, initialSearchQuery) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ProfitScreen(itemViewModel: ItemViewModel = viewModel(), searchQuery: String? = null, navController: NavController) {
    val viewModel: ProfitViewModel = viewModel(factory = ProfitViewModelFactory(itemViewModel, searchQuery))
    val profitTransactions by viewModel.filteredProfitTransactions.collectAsState()
    val totalProfit by viewModel.totalProfit.collectAsState(initial = 0.0)
    val currentSearchQuery by viewModel.searchQuery.collectAsState()
    var showDatePicker by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    if (showDatePicker) {
        DatePickerDialog(
            onDismiss = { showDatePicker = false },
            onDateSelected = { month, year ->
                viewModel.filterByMonth(month, year)
                showDatePicker = false
            },
            viewModel = viewModel
        )
    }

    Scaffold(
        topBar = {
            Column(
                modifier = Modifier
                    .background(Color(0xFF1976D2))
                    .zIndex(1f)
            ) {
                TopAppBar(
                    title = { Text("Profit", color = Color.White) },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.Transparent
                    )
                )
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Total Profit", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        RollingAmount(
                            amount = totalProfit,
                            color = if (totalProfit >= 0) Color(0xFF008800) else Color.Red,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = currentSearchQuery,
                        onValueChange = { viewModel.onSearchQueryChanged(it) },
                        modifier = Modifier
                            .weight(0.85f)
                            .height(40.dp)
                            .background(Color.White, RoundedCornerShape(8.dp)),
                        textStyle = TextStyle(fontSize = 14.sp, color = Color.Black),
                        singleLine = true,
                        decorationBox = { innerTextField ->
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 12.dp)
                                    .fillMaxHeight(),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (currentSearchQuery.isEmpty()) {
                                    Text(
                                        text = "Search Customer",
                                        color = Color.Gray,
                                        fontSize = 14.sp
                                    )
                                }
                                innerTextField()
                            }
                        }
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = { showDatePicker = true }, modifier = Modifier.weight(0.15f)) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Select Month", tint = Color.White)
                    }
                }
            }
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(Color.White)
        ) {
            itemsIndexed(
                profitTransactions,
                key = { index, profitTransaction ->
                    val id = profitTransaction.transaction.id
                    if (!id.isNullOrEmpty()) "${id}_$index" else "$index"
                }
            ) { _, profitTransaction ->
                ProfitTransactionItem(
                    modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                    profitTransaction = profitTransaction,
                    onClick = {
                        val pdfData = ProfitPdfGenerator.createProfitPdf(
                            customerName = profitTransaction.customerName,
                            billDate = profitTransaction.transaction.date ?: 0L,
                            billItems = profitTransaction.transaction.items,
                            totalProfit = profitTransaction.transaction.profit ?: 0.0
                        )
                        val file = File(context.cacheDir, "profit_report_${System.currentTimeMillis()}.pdf")
                        file.writeBytes(pdfData)
                        val encodedPath = URLEncoder.encode(file.absolutePath, StandardCharsets.UTF_8.name())
                        navController.navigate("pdfViewer/$encodedPath?customerName=${profitTransaction.customerName}&phoneNumber=${profitTransaction.phoneNumber}")
                    }
                )
            }
        }
    }
}

@Composable
fun DatePickerDialog(
    onDismiss: () -> Unit,
    onDateSelected: (Int?, Int?) -> Unit,
    viewModel: ProfitViewModel
) {
    val availableYears by viewModel.availableYears.collectAsState()
    val availableMonths by viewModel.availableMonths.collectAsState()

    var expandedYear by remember { mutableStateOf(false) }
    var selectedYear by remember { mutableStateOf<Int?>(null) }

    var expandedMonth by remember { mutableStateOf(false) }
    var selectedMonth by remember { mutableStateOf<Int?>(null) }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp), 
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Select Date", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    Box {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedYear = true }
                                .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedYear?.toString() ?: "Select Year", modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                        }
                        DropdownMenu(
                            expanded = expandedYear,
                            onDismissRequest = { expandedYear = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            DropdownMenuItem(text = { Text("None") }, onClick = {
                                selectedYear = null
                                expandedYear = false
                                viewModel.getMonthsForYear(0)
                            })
                            availableYears.forEach { year ->
                                DropdownMenuItem(text = { Text(year.toString()) }, onClick = {
                                    selectedYear = year
                                    expandedYear = false
                                    viewModel.getMonthsForYear(year)
                                })
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Box {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedMonth = true }
                                .background(Color(0xFFF5F5F5), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(selectedMonth?.let { monthToString(it) } ?: "Select Month", modifier = Modifier.weight(1f))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                        }
                        DropdownMenu(
                            expanded = expandedMonth,
                            onDismissRequest = { expandedMonth = false },
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            DropdownMenuItem(text = { Text("None") }, onClick = {
                                selectedMonth = null
                                expandedMonth = false
                            })
                            availableMonths.forEach { month ->
                                DropdownMenuItem(text = { Text(monthToString(month)) }, onClick = {
                                    selectedMonth = month
                                    expandedMonth = false
                                })
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onDateSelected(selectedMonth, selectedYear) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1976D2)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("OK")
                        }
                    }
                }
            }
        }
    }
}

fun monthToString(month: Int): String {
    return when (month) {
        0 -> "January"
        1 -> "February"
        2 -> "March"
        3 -> "April"
        4 -> "May"
        5 -> "June"
        6 -> "July"
        7 -> "August"
        8 -> "September"
        9 -> "October"
        10 -> "November"
        11 -> "December"
        else -> ""
    }
}


@Composable
fun ProfitTransactionItem(
    modifier: Modifier = Modifier,
    profitTransaction: ProfitTransaction,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .clickable { onClick() },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = profitTransaction.customerName,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(profitTransaction.transaction.date ?: 0L)),
                    color = Color.Gray,
                    fontSize = 10.sp
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                IconButton(onClick = onClick) {
                    Icon(Icons.Default.PictureAsPdf, contentDescription = "View Profit PDF", tint = Color(0xFF1976D2))
                }
                Text(
                    text = "₹${String.format(Locale.getDefault(), "%.2f", profitTransaction.transaction.profit)}",
                    color = if ((profitTransaction.transaction.profit ?: 0.0) >= 0) Color(0xFF008800) else Color.Red,
                )
            }
        }
    }
}
