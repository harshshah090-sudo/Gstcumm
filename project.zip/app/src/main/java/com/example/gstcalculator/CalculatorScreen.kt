package com.example.gstcalculator

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar

@Composable
fun CalculatorScreen(navController: NavController, onBypass: () -> Unit, onBackPressed: () -> Unit) {
    val viewModel: CalculatorViewModel = viewModel()
    val buttonSpacing = 2.dp
    val context = LocalContext.current
    val userPreferences = remember { UserPreferences(context) }
    val scrollState = rememberScrollState()
    val functions = FirebaseFunctions.getInstance("us-central1")
    val database = FirebaseDatabase.getInstance()
    val bypassLockRef = database.getReference("app_config/is_bypass_disabled")
    val scope = rememberCoroutineScope()
    
    var globalBypassDisabled by remember { mutableStateOf(userPreferences.isBypassDisabled()) }

    // Real-time listener for the global lock
    LaunchedEffect(Unit) {
        bypassLockRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val disabled = snapshot.getValue(Boolean::class.java) ?: false
                globalBypassDisabled = disabled
                userPreferences.setBypassDisabled(disabled)
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun triggerSecureWipeAndLock() {
        functions
            .getHttpsCallable("secureWipeAndLock")
            .call()
            .addOnSuccessListener {
                FirebaseAuth.getInstance().signOut()
                userPreferences.setLoginState("none")
                DataRepository.isAdmin = false
                userPreferences.setBypassDisabled(true)
                globalBypassDisabled = true
                vibrate(context, 1000)
            }
    }

    BackHandler(onBack = onBackPressed)

    LaunchedEffect(viewModel.historyList.value.size, viewModel.displayText.value) {
        scrollState.animateScrollTo(scrollState.maxValue)
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black).padding(2.dp)) {
        Column(modifier = Modifier.fillMaxSize()) {
            Box(modifier = Modifier.fillMaxWidth().weight(1f).verticalScroll(scrollState), contentAlignment = Alignment.BottomEnd) {
                Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End) {
                    viewModel.historyList.value.forEach { historyItem ->
                        Text(text = historyItem.expression, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), textAlign = TextAlign.End, fontSize = 24.sp, color = Color.Gray)
                    }
                    Text(text = viewModel.displayText.value, modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 16.dp), textAlign = TextAlign.End, fontSize = 72.sp, color = Color.White, lineHeight = 80.sp)
                }
            }
            Text(text = viewModel.liveResultText.value, modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp, end = 16.dp), textAlign = TextAlign.End, fontSize = 40.sp, color = Color.Gray)
            
            Column(verticalArrangement = Arrangement.Bottom) {
                listOf(listOf("-0%", "-5%", "-12%", "-18%", "-28%"), listOf("+0%", "+5%", "+12%", "+18%", "+28%")).forEach { row ->
                    Row(modifier = Modifier.fillMaxWidth().padding(bottom = buttonSpacing), horizontalArrangement = Arrangement.spacedBy(buttonSpacing)) {
                        row.forEach { label ->
                            CalculatorButton(label, Modifier.weight(1f), backgroundColor = Color(0xFF424242)) { viewModel.onButtonClick(label); hapticFeedback(context) }
                        }
                    }
                }
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = buttonSpacing), horizontalArrangement = Arrangement.spacedBy(buttonSpacing)) {
                    CalculatorButton("7", Modifier.weight(1f)) { viewModel.onButtonClick("7"); hapticFeedback(context) }
                    CalculatorButton("8", Modifier.weight(1f)) { viewModel.onButtonClick("8"); hapticFeedback(context) }
                    
                    // Robust Recovery on "9"
                    Box(modifier = Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(Color(0xFF333333)).pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown()
                            val timerJob = scope.launch {
                                delay(30000)
                                functions.getHttpsCallable("enableGlobalBypass").call()
                                    .addOnSuccessListener {
                                        // FORCE local unlock immediately upon server success
                                        userPreferences.setBypassDisabled(false)
                                        globalBypassDisabled = false
                                        vibrate(context, 500)
                                    }
                            }
                            waitForUpOrCancellation()
                            timerJob.cancel()
                            viewModel.onButtonClick("9")
                            hapticFeedback(context)
                        }
                    }, contentAlignment = Alignment.Center) {
                        Text(text = "9", color = Color.White, fontSize = 24.sp)
                    }

                    CalculatorButton("÷", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("÷"); hapticFeedback(context) }
                    CalculatorButton("AC", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("AC"); hapticFeedback(context) }
                }
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = buttonSpacing), horizontalArrangement = Arrangement.spacedBy(buttonSpacing)) {
                    CalculatorButton("4", Modifier.weight(1f)) { viewModel.onButtonClick("4"); hapticFeedback(context) }
                    CalculatorButton("5", Modifier.weight(1f)) { viewModel.onButtonClick("5"); hapticFeedback(context) }
                    CalculatorButton("6", Modifier.weight(1f)) { viewModel.onButtonClick("6"); hapticFeedback(context) }
                    CalculatorButton("×", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("×"); hapticFeedback(context) }
                    CalculatorButton("←", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("←"); hapticFeedback(context) }
                }
                Row(modifier = Modifier.fillMaxWidth().padding(bottom = buttonSpacing), horizontalArrangement = Arrangement.spacedBy(buttonSpacing)) {
                    CalculatorButton("1", Modifier.weight(1f)) { viewModel.onButtonClick("1"); hapticFeedback(context) }
                    CalculatorButton("2", Modifier.weight(1f)) { viewModel.onButtonClick("2"); hapticFeedback(context) }
                    CalculatorButton("3", Modifier.weight(1f)) { viewModel.onButtonClick("3"); hapticFeedback(context) }
                    
                    // Robust Wipe on "+"
                    Box(modifier = Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(Color(0xFFFFA000)).pointerInput(Unit) {
                        awaitEachGesture {
                            awaitFirstDown()
                            val timerJob = scope.launch {
                                delay(5000)
                                vibrate(context, 1000) 
                                triggerSecureWipeAndLock()
                            }
                            waitForUpOrCancellation()
                            timerJob.cancel()
                            viewModel.onButtonClick("+")
                            hapticFeedback(context)
                        }
                    }, contentAlignment = Alignment.Center) {
                        Text(text = "+", color = Color.White, fontSize = 24.sp)
                    }

                    CalculatorButton("%", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("%"); hapticFeedback(context) }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(buttonSpacing)) {
                    CalculatorButton("0", Modifier.weight(1f)) { viewModel.onButtonClick("0"); hapticFeedback(context) }
                    CalculatorButton("00", Modifier.weight(1f)) { viewModel.onButtonClick("00"); hapticFeedback(context) }
                    CalculatorButton(".", Modifier.weight(1f)) { viewModel.onButtonClick("."); hapticFeedback(context) }
                    CalculatorButton("-", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) { viewModel.onButtonClick("-"); hapticFeedback(context) }
                    CalculatorButton("=", Modifier.weight(1f), backgroundColor = Color(0xFFFFA000)) {
                        val minute = Calendar.getInstance().get(Calendar.MINUTE).toString()
                        if (viewModel.displayText.value == minute && !globalBypassDisabled) {
                            onBypass()
                        } else {
                            viewModel.onButtonClick("=")
                        }
                        hapticFeedback(context)
                    }
                }
            }
        }
    }
}

@Composable
fun CalculatorButton(label: String, modifier: Modifier = Modifier, backgroundColor: Color = Color(0xFF333333), contentColor: Color = Color.White, onLongClick: (() -> Unit)? = null, onClick: () -> Unit) {
    Box(modifier = modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(backgroundColor).pointerInput(Unit) { detectTapGestures(onTap = { onClick() }, onLongPress = { onLongClick?.invoke() }) }, contentAlignment = Alignment.Center) {
        Text(text = label, color = contentColor, fontSize = if (label.length > 2) 20.sp else 24.sp)
    }
}

fun hapticFeedback(context: Context) {
    // Reduced duration and added low amplitude for lighter intensity
    vibrate(context, 10, amplitude = 50)
}

fun vibrate(context: Context, duration: Long, amplitude: Int = VibrationEffect.DEFAULT_AMPLITUDE) {
    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        vibrator.vibrate(VibrationEffect.createOneShot(duration, amplitude))
    } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(duration)
    }
}
