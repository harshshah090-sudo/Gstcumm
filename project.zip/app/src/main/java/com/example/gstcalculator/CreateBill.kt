package com.example.gstcalculator

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoveUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDefaults
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.TriStateCheckbox
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlin.math.roundToInt
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

data class BillItemState(
    val id: UUID = UUID.randomUUID(),
    var item: Item,
    val qty: androidx.compose.runtime.MutableState<String>,
    val rate: androidx.compose.runtime.MutableState<String>,
    val basePrice: androidx.compose.runtime.MutableState<String>,
    val isChecked: androidx.compose.runtime.MutableState<Boolean>,
    val breakdown: Map<String, String>? = null,
    val focusRequester: FocusRequester = FocusRequester()
)

fun BillItemState.toBillItem(): BillItem = BillItem(
    itemId = item.id,
    name = item.name,
    qty = qty.value,
    rate = rate.value,
    uom = item.uom,
    basePrice = basePrice.value,
    breakdown = breakdown
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun CreateBill(
    navController: NavController,
    customerId: String?,
    transactionId: String?,
    draftId: String?,
    webOrderId: String? = null,
    isPurchaseReturn: Boolean?,
    customerType: String,
    userPreferences: UserPreferences,
    uomViewModel: UomViewModel = viewModel(),
    itemViewModel: ItemViewModel = viewModel(factory = ItemViewModelFactory())
) {
    if (customerId == null) return

    val context = LocalContext.current
    val userRole = userPreferences.getLoginState()
    val isStaff = userRole == "staff"

    val keyboardController = LocalSoftwareKeyboardController.current
    val viewModel: TransactionViewModel = viewModel(factory = TransactionViewModelFactory(context, customerId, customerType))
    val customer by viewModel.customer
    val drafts by viewModel.drafts
    val userName by viewModel.userName
    val itemRates by viewModel.itemRates
    val transactionsWithBalances by viewModel.transactionsWithBalances
    val allItems by itemViewModel.allItems.collectAsState()
    val coroutineScope = rememberCoroutineScope()
    var date by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showItemPicker by remember { mutableStateOf(false) }
    val billItems = remember { mutableStateListOf<BillItemState>() }
    var isProcessing by remember { mutableStateOf(false) }
    var showBackButtonDialog by remember { mutableStateOf(false) }
    var printTwoCopies by remember { mutableStateOf(false) }

    var initialItems by remember { mutableStateOf<List<BillItem>?>(null) }
    var initialDate by remember { mutableLongStateOf(0L) }

    var showSalesHistoryDialog by remember { mutableStateOf(false) }
    var salesHistory by remember { mutableStateOf<List<ItemSale>>(emptyList()) }
    var selectedBillItemForHistory by remember { mutableStateOf<BillItemState?>(null) }
    
    var showBreakdownDialog by remember { mutableStateOf<Map<String, String>?>(null) }
    var showCustomerTransferDialog by remember { mutableStateOf(false) }

    var itemToFocus by remember { mutableStateOf<UUID?>(null) }
    val lazyListState = rememberLazyListState()

    var initialLoadId by remember { mutableStateOf<String?>(null) }
    var showLockConflictDialog by remember { mutableStateOf<String?>(null) }

    // Custom Spring Specification for "Springy Bounce"
    val springSpec = spring<IntOffset>(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )

    val checkedCount by remember {
        derivedStateOf { billItems.count { it.isChecked.value } }
    }

    LaunchedEffect(itemToFocus) {
        itemToFocus?.let { id ->
            val index = billItems.indexOfFirst { it.id == id }
            if (index != -1) {
                delay(300)
                try {
                    lazyListState.scrollToItem(index)
                    delay(100)
                    if (index < billItems.size) {
                        billItems[index].focusRequester.requestFocus()
                        keyboardController?.show()
                    }
                } catch (e: Exception) { /* Ignored */ }
            }
            itemToFocus = null
        }
    }

    // Proactive migration: Link old name-based rates to IDs
    LaunchedEffect(allItems) {
        if (allItems.isNotEmpty()) {
            viewModel.migrateItemRates(allItems)
        }
    }

    val deviceId = remember { userPreferences.getDeviceId() }

    // Lock Verification & Monitoring
    LaunchedEffect(draftId) {
        if (draftId != null && viewModel.isConnected.value) {
            viewModel.tryLockDraft(draftId, deviceId, userName ?: "Unknown User") { success, lockedBy ->
                if (!success) {
                    showLockConflictDialog = lockedBy ?: "Another user"
                }
            }
        }
    }

    LaunchedEffect(draftId, drafts) {
        if (draftId != null) {
            val currentDraft = drafts.find { it.id == draftId }
            if (currentDraft != null) {
                val isLockedBySomeoneElse = currentDraft.lockedBy != null &&
                        currentDraft.lockedBy != deviceId &&
                        (System.currentTimeMillis() - (currentDraft.lockTimestamp ?: 0)) < 5 * 60 * 1000
                if (isLockedBySomeoneElse) {
                    showLockConflictDialog = currentDraft.lockedByName ?: "Another user"
                }
            }
        }
    }

    if (showLockConflictDialog != null) {
        BouncyDialog(onDismissRequest = { }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = Color(0xFFD50000),
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Draft Locked", color = Color(0xFFD50000), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "This draft is currently being edited by another user. You cannot make changes at this time.",
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                    TextButton(
                        onClick = {
                            showLockConflictDialog = null
                            navController.popBackStack()
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                    ) {
                        Text("Go Back", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showSalesHistoryDialog) {
        selectedBillItemForHistory?.let { billItemState ->
            ItemSalesHistoryDialog(
                onDismiss = { showSalesHistoryDialog = false },
                itemName = billItemState.item.name,
                salesHistory = salesHistory,
                allItems = allItems,
                uom = billItemState.item.uom,
                onReplace = { newItem: Item, newQty: String ->
                    val index = billItems.indexOfFirst { it.id == billItemState.id }
                    if (index != -1) {
                        val rate = viewModel.getLastRateForItem(
                            itemId = newItem.id,
                            itemName = newItem.name,
                            itemUom = newItem.uom,
                            oldNames = newItem.oldNames
                        )
                        val newState = BillItemState(
                            item = newItem,
                            qty = mutableStateOf(newQty),
                            rate = mutableStateOf(rate),
                            basePrice = mutableStateOf(formatPrice(newItem.basePrice)),
                            isChecked = mutableStateOf(true)
                        )
                        billItems[index] = newState
                        itemToFocus = newState.id
                    }
                }
            )
        }
    }
    
    if (showBreakdownDialog != null) {
        BouncyDialog(onDismissRequest = { showBreakdownDialog = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Item Details", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2), fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    showBreakdownDialog?.toList()
                        ?.sortedWith(compareBy(AlphaNumericComparator) { it.first })
                        ?.forEach { (variant, qty) ->
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(variant, fontWeight = FontWeight.Medium)
                                Text(qty, fontWeight = FontWeight.Bold)
                            }
                        }
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showBreakdownDialog = null }) {
                            Text("Close")
                        }
                    }
                }
            }
        }
    }

    if (showCustomerTransferDialog) {
        CustomerTransferDialog(
            currentCustomerId = customerId,
            onDismiss = { showCustomerTransferDialog = false },
            onTransfer = { targetCustomer ->
                coroutineScope.launch {
                    isProcessing = true
                    try {
                        val itemsToTransfer = billItems.map { it.toBillItem() }
                        viewModel.transferBill(
                            context = context,
                            targetCustomer = targetCustomer,
                            items = itemsToTransfer,
                            date = date,
                            originalTransactionId = transactionId,
                            originalDraftId = draftId,
                            originalWebOrderId = webOrderId,
                            onComplete = { newDraftId ->
                                showCustomerTransferDialog = false
                                navController.popBackStack()
                                navController.navigate("createBill/${targetCustomer.id}/${targetCustomer.customerType}?draftId=$newDraftId")
                            }
                        )
                    } catch (e: Exception) {
                        Toast.makeText(context, "Transfer failed: ${e.message}", Toast.LENGTH_SHORT).show()
                    } finally {
                        isProcessing = false
                    }
                }
            }
        )
    }

    BackHandler(enabled = billItems.isNotEmpty()) {
        showBackButtonDialog = true
    }

    if (showBackButtonDialog) {
        BouncyDialog(onDismissRequest = { showBackButtonDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Confirm Back", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Going back will erase the data of this Bill. Are you sure you want to go back?")
                    Spacer(modifier = Modifier.height(24.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showBackButtonDialog = false }) {
                            Text("No", color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                showBackButtonDialog = false
                                navController.popBackStack()
                            }
                        ) {
                            Text("Yes", color = Color(0xFF1976D2))
                        }
                    }
                }
            }
        }
    }

    DisposableEffect(draftId) {
        onDispose {
            if (draftId != null) {
                viewModel.releaseLock(draftId)
            }
        }
    }

    LaunchedEffect(transactionId, draftId, webOrderId) {
        val currentId = transactionId ?: draftId ?: webOrderId ?: return@LaunchedEffect
        if (currentId == initialLoadId) return@LaunchedEffect
        
        if (transactionId != null) {
            initialLoadId = transactionId
            val transaction = withContext(Dispatchers.IO) { viewModel.getTransaction(transactionId) }
            if (transaction != null && billItems.isEmpty()) {
                date = transaction.date ?: System.currentTimeMillis()
                val newItems = transaction.items.map { billItem ->
                    val foundItem = if (billItem.itemId.isNotBlank()) {
                        allItems.find { it.id == billItem.itemId }
                    } else {
                        allItems.find { it.name == billItem.name && it.uom == billItem.uom }
                    }
                    BillItemState(
                        item = foundItem ?: Item(id = billItem.itemId, name = billItem.name, uom = billItem.uom),
                        qty = mutableStateOf(billItem.getQtyString()),
                        rate = mutableStateOf(billItem.rate),
                        basePrice = mutableStateOf(billItem.basePrice.ifEmpty { foundItem?.let { formatPrice(it.basePrice) } ?: "0" }),
                        isChecked = mutableStateOf(true),
                        breakdown = billItem.getBreakdownStrings()
                    )
                }
                billItems.addAll(newItems)
                initialItems = newItems.map { it.toBillItem() }
                initialDate = date
            }
        } else if (draftId != null) {
            initialLoadId = draftId
            viewModel.getDraft(draftId) { draft ->
                if (draft != null && billItems.isEmpty()) {
                    date = draft.date
                    val newItems = draft.items.map { billItem ->
                        val foundItem = if (billItem.itemId.isNotBlank()) {
                            allItems.find { it.id == billItem.itemId }
                        } else {
                            allItems.find { it.name == billItem.name && it.uom == billItem.uom }
                        }
                        BillItemState(
                            item = foundItem ?: Item(id = billItem.itemId, name = billItem.name, uom = billItem.uom),
                            qty = mutableStateOf(billItem.getQtyString()),
                            rate = mutableStateOf(billItem.rate),
                            basePrice = mutableStateOf(billItem.basePrice.ifEmpty { foundItem?.let { formatPrice(it.basePrice) } ?: "0" }),
                            isChecked = mutableStateOf(true),
                            breakdown = billItem.getBreakdownStrings()
                        )
                    }
                    billItems.addAll(newItems)
                    initialItems = newItems.map { it.toBillItem() }
                    initialDate = date
                }
            }
        } else if (webOrderId != null) {
            initialLoadId = webOrderId
            isProcessing = true
            try {
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                if (uid != null) {
                    val snapshot = withContext(Dispatchers.IO) {
                        FirebaseDatabase.getInstance().getReference("web_orders").child(uid).child(webOrderId).get().await()
                    }
                    val order = WebOrder.fromSnapshot(snapshot)
                    if (order != null && billItems.isEmpty()) {
                        date = System.currentTimeMillis()
                        val newItems = order.items.map { billItem ->
                            val foundItem = if (billItem.itemId.isNotBlank()) {
                                allItems.find { it.id == billItem.itemId }
                            } else {
                                allItems.find { it.name == billItem.name && it.uom == billItem.uom }
                            }
                            val rateFromHistory = viewModel.getLastRateForItem(
                                itemId = foundItem?.id ?: billItem.itemId, 
                                itemName = billItem.name, 
                                itemUom = billItem.uom,
                                oldNames = foundItem?.oldNames ?: emptyList()
                            )
                            BillItemState(
                                item = foundItem ?: Item(id = billItem.itemId, name = billItem.name, uom = billItem.uom),
                                qty = mutableStateOf(billItem.getQtyString()),
                                rate = mutableStateOf(rateFromHistory),
                                basePrice = mutableStateOf(if (foundItem != null) formatPrice(foundItem.basePrice) else billItem.basePrice.ifEmpty { "0" }),
                                isChecked = mutableStateOf(true),
                                breakdown = billItem.getBreakdownStrings()
                            )
                        }
                        billItems.addAll(newItems)
                        initialItems = newItems.map { it.toBillItem() }
                        initialDate = date
                    }
                }
            } catch (e: Exception) { /* Ignored */ } finally {
                isProcessing = false
            }
        }
    }

    val allItemsById = remember(allItems) {
        allItems.associateBy { it.id }
    }

    LaunchedEffect(allItemsById, itemRates, transactionsWithBalances) {
        if (billItems.isNotEmpty()) {
            billItems.forEach { billItem ->
                if (billItem.rate.value.isEmpty()) {
                    val rate = viewModel.getLastRateForItem(
                        itemId = billItem.item.id, 
                        itemName = billItem.item.name, 
                        itemUom = billItem.item.uom,
                        oldNames = billItem.item.oldNames
                    )
                    if (rate.isNotEmpty()) {
                        billItem.rate.value = rate
                    }
                }
                
                val foundItem = if (billItem.item.id.isNotBlank()) {
                    allItemsById[billItem.item.id]
                } else {
                    allItems.find { it.name == billItem.item.name && it.uom == billItem.item.uom }
                }
                if (foundItem != null) {
                    billItem.item = foundItem
                    if (billItem.basePrice.value == "0" || billItem.basePrice.value.isEmpty()) {
                        billItem.basePrice.value = formatPrice(foundItem.basePrice)
                    }
                }
            }
        }
    }

    val isDraftEnabled by remember(billItems.size, isProcessing, transactionId, isPurchaseReturn, isStaff, viewModel.isConnected.value) {
        derivedStateOf {
            val baseEnabled = !isProcessing && billItems.any { it.isChecked.value } && isPurchaseReturn != true
            if (isStaff) baseEnabled && viewModel.isConnected.value else baseEnabled
        }
    }

    val isSaveEnabled by remember(billItems.size, isProcessing, isStaff) {
        derivedStateOf {
            if (isStaff || isProcessing) return@derivedStateOf false
            val checkedItems = billItems.filter { it.isChecked.value }
            if (checkedItems.isEmpty()) return@derivedStateOf false
            checkedItems.all { (it.qty.value.toDoubleOrNull() ?: 0.0) > 0.0 && (it.rate.value.toDoubleOrNull() ?: -1.0) >= 0.0 }
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(initialSelectedDateMillis = date)
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val selectedDateMillis = datePickerState.selectedDateMillis ?: System.currentTimeMillis()
                        val selectedDateCalendar = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        val nowCalendar = Calendar.getInstance()
                        selectedDateCalendar.set(Calendar.HOUR_OF_DAY, nowCalendar.get(Calendar.HOUR_OF_DAY))
                        selectedDateCalendar.set(Calendar.MINUTE, nowCalendar.get(Calendar.MINUTE))
                        selectedDateCalendar.set(Calendar.SECOND, nowCalendar.get(Calendar.SECOND))
                        selectedDateCalendar.set(Calendar.MILLISECOND, nowCalendar.get(Calendar.MILLISECOND))
                        date = selectedDateCalendar.timeInMillis
                        showDatePicker = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF1976D2))
                ) { Text("OK") }
            },
            dismissButton = {
                TextButton(
                    onClick = { showDatePicker = false },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Gray)
                ) { Text("Cancel") }
            }
        ) {
            DatePicker(
                state = datePickerState,
                showModeToggle = false,
                title = null,
                headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = Color.White,
                    titleContentColor = Color(0xFF1976D2),
                    headlineContentColor = Color(0xFF1976D2),
                    selectedDayContainerColor = Color(0xFF1976D2),
                    selectedDayContentColor = Color.White,
                    todayContentColor = Color(0xFF1976D2),
                    todayDateBorderColor = Color(0xFF1976D2)
                )
            )
        }
    }

    if (showItemPicker) {
        ItemPickerDialog(
            onDismiss = { showItemPicker = false },
            onItemsSelected = { items ->
                if (items.isNotEmpty()) {
                    val newBillItems = items.map { (item, qty) ->
                        val rate = viewModel.getLastRateForItem(
                            itemId = item.id, 
                            itemName = item.name, 
                            itemUom = item.uom,
                            oldNames = item.oldNames
                        )
                        BillItemState(
                            item = item,
                            qty = mutableStateOf(qty),
                            rate = mutableStateOf(rate),
                            basePrice = mutableStateOf(formatPrice(item.basePrice)),
                            isChecked = mutableStateOf(true)
                        )
                    }
                    billItems.addAll(newBillItems)
                    itemToFocus = newBillItems.first().id
                }
                showItemPicker = false
            },
            uomViewModel = uomViewModel,
            isStaff = isStaff
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(customer?.name ?: "", color = Color.White)
                        if (!viewModel.isConnected.value) {
                            Text(
                                text = "Offline",
                                color = Color.White,
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier
                                    .background(color = Color(0xFFD50000), shape = RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = {
                        if (billItems.isNotEmpty()) showBackButtonDialog = true else navController.popBackStack()
                    }) {
                        Avatar(name = customer?.name ?: "")
                    }
                },
                actions = {
                    IconButton(onClick = { showCustomerTransferDialog = true }) {
                        Icon(Icons.Default.MoveUp, contentDescription = "Transfer Bill", tint = Color.White)
                    }
                    if (billItems.any { it.isChecked.value }) {
                        Switch(
                            checked = printTwoCopies,
                            onCheckedChange = { printTwoCopies = it },
                            modifier = Modifier.scale(0.7f),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.White,
                                checkedTrackColor = Color(0xFF81C784),
                                disabledCheckedTrackColor = Color.Gray,
                                disabledUncheckedTrackColor = Color.DarkGray
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF1976D2))
            )
        }
    ) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().padding(paddingValues)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFFF5F5F5))
            ) {
                Spacer(modifier = Modifier.height(0.5.dp))
                val horizontalTableScrollState = rememberScrollState()
                var revealedBillItemId by remember { mutableStateOf<UUID?>(null) }
                Column(modifier = Modifier.horizontalScroll(horizontalTableScrollState)) {
                    val allItemsChecked = billItems.isNotEmpty() && billItems.all { it.isChecked.value }
                    val indeterminate = billItems.any { it.isChecked.value } && !allItemsChecked
                    val headerCheckboxState = when {
                        allItemsChecked -> ToggleableState.On
                        indeterminate -> ToggleableState.Indeterminate
                        else -> ToggleableState.Off
                    }

                    val tableWidth = if (isStaff) 350.dp else 530.dp

                    Column(
                        modifier = Modifier
                            .width(tableWidth)
                            .background(Color(0xFF1976D2))
                            .zIndex(1f) // Keep table header on top
                    ) {
                        HorizontalDivider(color = Color.White, thickness = 1.dp)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 1.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TriStateCheckbox(
                                state = headerCheckboxState,
                                onClick = {
                                    val newCheckedState = !allItemsChecked
                                    billItems.forEach { it.isChecked.value = newCheckedState }
                                    keyboardController?.hide()
                                },
                                colors = CheckboxDefaults.colors(checkedColor = Color.White, uncheckedColor = Color.White, checkmarkColor = Color(0xFF1976D2))
                            )
                            @OptIn(ExperimentalMaterial3Api::class)
                            Text(
                                "Item Name",
                                modifier = Modifier
                                    .width(150.dp)
                                    .clickable {
                                        val newCheckedState = !allItemsChecked
                                        billItems.forEach { it.isChecked.value = newCheckedState }
                                        keyboardController?.hide()
                                    },
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text("UOM", modifier = Modifier.width(70.dp), fontWeight = FontWeight.Bold, color = Color.White)
                            Row(
                                modifier = Modifier
                                    .width(70.dp)
                                    .clickable {
                                        if (!isStaff) {
                                            coroutineScope.launch {
                                                if (horizontalTableScrollState.value == 0) {
                                                    horizontalTableScrollState.animateScrollTo(horizontalTableScrollState.maxValue)
                                                } else {
                                                    horizontalTableScrollState.animateScrollTo(0)
                                                }
                                            }
                                        }
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Qty", fontWeight = FontWeight.Bold, color = Color.White)
                                if (!isStaff) {
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Icon(
                                        imageVector = if (horizontalTableScrollState.value == 0) Icons.AutoMirrored.Filled.ArrowForward else Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "Slide Table",
                                        tint = Color.White.copy(alpha = 0.85f),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            if (!isStaff) {
                                Text(
                                    "Rate",
                                    modifier = Modifier
                                        .width(80.dp)
                                        .clickable {
                                            coroutineScope.launch {
                                                horizontalTableScrollState.animateScrollTo(0)
                                            }
                                        },
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text("Base Price", modifier = Modifier.width(100.dp), fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }
                    }
                    LazyColumn(state = lazyListState, modifier = Modifier.width(tableWidth)) {
                        items(
                            items = billItems,
                            key = { it.id }
                        ) { billItem ->
                            BillItemRow(
                                modifier = Modifier.animateItemPlacement(animationSpec = springSpec),
                                billItem = billItem,
                                isStaff = isStaff,
                                isProcessing = isProcessing,
                                isRevealed = revealedBillItemId == billItem.id,
                                horizontalTableScrollState = horizontalTableScrollState,
                                onRevealChange = { isRevealed ->
                                    if (isRevealed) {
                                        revealedBillItemId = billItem.id
                                        coroutineScope.launch {
                                            horizontalTableScrollState.animateScrollTo(0)
                                        }
                                    } else {
                                        if (revealedBillItemId == billItem.id) {
                                            revealedBillItemId = null
                                        }
                                    }
                                },
                                onAddToOrder = {
                                    coroutineScope.launch {
                                        val custId = customer?.id ?: customerId
                                        val custName = customer?.name ?: ""
                                        val custType = customer?.customerType ?: customerType
                                        val success = addItemToCustomerOrder(
                                            customerId = custId,
                                            customerName = custName,
                                            customerType = custType,
                                            billItemState = billItem
                                        )
                                        if (success) {
                                            billItems.remove(billItem)
                                            if (revealedBillItemId == billItem.id) {
                                                revealedBillItemId = null
                                            }
                                            Toast.makeText(context, "${billItem.item.name} added to order", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "Failed to add item to order", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onHistoryClick = {
                                    coroutineScope.launch {
                                        salesHistory = viewModel.getSalesHistoryForItem(billItem.item.name, billItem.item.uom, billItem.item.id)
                                        selectedBillItemForHistory = billItem
                                        showSalesHistoryDialog = true
                                    }
                                },
                                onBreakdownClick = { showBreakdownDialog = billItem.breakdown }
                            )
                        }
                        item { Spacer(modifier = Modifier.height(300.dp)) }
                    }
                }
            }
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp)
            ) {
                val totalAmount by remember {
                    derivedStateOf {
                        billItems.filter { it.isChecked.value }.sumOf { (it.qty.value.toDoubleOrNull() ?: 0.0) * (it.rate.value.toDoubleOrNull() ?: 0.0) }
                    }
                }
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Box(modifier = Modifier.fillMaxWidth()) {
                            if (!isStaff) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.align(Alignment.CenterStart)
                                ) {
                                    Text("Total: ${formatAmount(totalAmount)}", fontWeight = FontWeight.Bold, color = Color(0xFF1976D2))
                                }
                            }
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .align(Alignment.Center)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(brush = Brush.verticalGradient(colors = listOf(Color(0xFF63D367), Color(0xFF008800))))
                                    .clickable { showItemPicker = true },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                            }
                            if (!isStaff) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.align(Alignment.CenterEnd)
                                ) {
                                    Text(
                                        text = SimpleDateFormat("dd / MMM / yyyy", Locale.getDefault()).format(Date(date)),
                                        modifier = Modifier.clickable { showDatePicker = true },
                                        color = Color(0xFF1976D2),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(brush = Brush.verticalGradient(colors = if (isDraftEnabled) listOf(Color(0xFFF87970), Color(0xFFD50000)) else listOf(Color.Gray, Color.DarkGray)))
                                    .clickable(enabled = isDraftEnabled) {
                                            if (!viewModel.isConnected.value) {
                                                Toast.makeText(context, "Please connect to the internet to save draft", Toast.LENGTH_SHORT).show()
                                                return@clickable
                                            }
                                            coroutineScope.launch {
                                                isProcessing = true
                                                try {
                                                    val checkedBillItems = billItems.filter { it.isChecked.value }
                                                    saveUpdatedBasePrices(checkedBillItems, itemViewModel)

                                                    val itemsToSave = checkedBillItems.map { it.toBillItem() }
                                                    
                                                    val currentBillItems = billItems.map { it.toBillItem() }
                                                    val hasChanges = date != initialDate || currentBillItems != initialItems
                                                    val finalDate = if (hasChanges) mergeDateWithCurrentTime(date) else date

                                                    viewModel.saveDraft(draftId, finalDate, itemsToSave)

                                                    if (transactionId != null) {
                                                        withContext(Dispatchers.IO) {
                                                            FirebaseDatabase.getInstance().getReference(when(customerType) {
                                                                "STAFF" -> "customers_staff"
                                                                "LOCALS" -> "customers_locals"
                                                                "HOME" -> "customers_home"
                                                                else -> "custom_customers/$customerType"
                                                            }).child(customerId).child("transactions").child(transactionId).removeValue().await()
                                                        }
                                                    }

                                                    if (webOrderId != null) {
                                                        val uid = FirebaseAuth.getInstance().currentUser?.uid
                                                        if (uid != null) FirebaseDatabase.getInstance().getReference("web_orders").child(uid).child(webOrderId).removeValue().await()
                                                    }

                                                    if (!isStaff) {
                                                        val pdfData = PdfGenerator.createDraftPdf(customer, finalDate, itemsToSave, printTwoCopies)
                                                        val file = File(context.cacheDir, "draft_${UUID.randomUUID()}.pdf")
                                                        FileOutputStream(file).use { it.write(pdfData) }
                                                        val encodedPath = URLEncoder.encode(file.absolutePath, StandardCharsets.UTF_8.name())
                                                        val phone = customer?.phoneNumber?.toString() ?: ""
                                                        val name = customer?.name ?: ""
                                                        navController.popBackStack()
                                                        navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
                                                    } else {
                                                        navController.popBackStack()
                                                    }
                                                } finally { isProcessing = false }
                                            }
                                        }
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text("DRAFT", color = Color.White, fontWeight = FontWeight.Bold) }
                            }
                            Card(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(brush = Brush.verticalGradient(colors = if (isSaveEnabled) listOf(Color(0xFF64B5F6), Color(0xFF1976D2)) else listOf(Color.Gray, Color.DarkGray)))
                                        .clickable(enabled = isSaveEnabled) {
                                            coroutineScope.launch {
                                                isProcessing = true
                                                try {
                                                    val currentBillItems = billItems.map { it.toBillItem() }
                                                    val hasChanges = date != initialDate || currentBillItems != initialItems
                                                    val finalDate = if (hasChanges) mergeDateWithCurrentTime(date) else date
                                                    saveAndCreatePdfInstant(context, viewModel, itemViewModel, customer, finalDate, billItems, totalAmount, navController, transactionId, draftId, webOrderId, isPurchaseReturn, transactionsWithBalances, printTwoCopies, isStaff)
                                                } finally { isProcessing = false }
                                            }
                                        }
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) { Text("SAVE", color = Color.White, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }

            if (isProcessing) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.3f)).pointerInput(Unit) {},
                    contentAlignment = Alignment.Center
                ) { CircularProgressIndicator(color = Color(0xFF1976D2)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerTransferDialog(
    currentCustomerId: String,
    onDismiss: () -> Unit,
    onTransfer: (Customer) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    
    // Collect data from all categories
    val staffData by DataRepository.getDataFlow("STAFF").collectAsState()
    val localsData by DataRepository.getDataFlow("LOCALS").collectAsState()
    val homeData by DataRepository.getDataFlow("HOME").collectAsState()
    val customScreens by DataRepository.customScreens.collectAsState()

    val customCategoriesData = remember { mutableStateMapOf<String, RepositoryData>() }
    
    LaunchedEffect(customScreens) {
        customScreens.forEach { screen ->
            launch {
                DataRepository.getDataFlow(screen).collect { data ->
                    customCategoriesData[screen] = data
                }
            }
        }
    }

    val allCustomers = remember(staffData, localsData, homeData, customCategoriesData.size) {
        val list = mutableListOf<Customer>()
        list.addAll(staffData.customers)
        list.addAll(localsData.customers)
        list.addAll(homeData.customers)
        customCategoriesData.values.forEach { list.addAll(it.customers) }
        
        list.filter { it.id != currentCustomerId }.distinctBy { it.id }
    }

    val filteredCustomers = remember(allCustomers, searchQuery) {
        allCustomers.filter {
            it.name.contains(searchQuery, ignoreCase = true) ||
            it.phoneNumber?.toString()?.contains(searchQuery) == true
        }.sortedBy { it.name }
    }

    // Fix the rotating icon issue: only show loader if we have NO data AND a timeout hasn't reached
    var showInitialLoading by remember { mutableStateOf(true) }
    LaunchedEffect(allCustomers) {
        if (allCustomers.isNotEmpty()) {
            showInitialLoading = false
        }
    }
    LaunchedEffect(Unit) {
        delay(2500) // Timeout for loader
        showInitialLoading = false
    }

    BouncyDialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 16.dp)
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF1976D2))
                        .padding(16.dp)
                ) {
                    Text(
                        "Transfer Bill to Customer",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = Color.White
                    )
                }
                
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        placeholder = { Text("Search Customer", fontSize = 14.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFF1976D2), modifier = Modifier.size(20.dp)) },
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF1976D2),
                            unfocusedBorderColor = Color.LightGray,
                            cursorColor = Color(0xFF1976D2),
                            focusedLabelColor = Color(0xFF1976D2)
                        )
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Box(modifier = Modifier.heightIn(min = 100.dp, max = 400.dp)) {
                        if (allCustomers.isEmpty() && showInitialLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.align(Alignment.Center),
                                color = Color(0xFF1976D2)
                            )
                        } else if (filteredCustomers.isEmpty()) {
                            Text(
                                if (searchQuery.isEmpty()) "No other customers found" else "No customers match '$searchQuery'",
                                modifier = Modifier.align(Alignment.Center).padding(vertical = 24.dp),
                                color = Color.Gray
                            )
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(filteredCustomers, key = { it.id ?: UUID.randomUUID().toString() }) { customer ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { onTransfer(customer) }
                                            .padding(vertical = 12.dp, horizontal = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Avatar(name = customer.name, hasDraft = customer.hasDraft)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(customer.name, fontWeight = FontWeight.Bold, color = Color.Black)
                                        }
                                    }
                                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.5f))
                                }
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = Color(0xFF1976D2), fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

private fun mergeDateWithCurrentTime(selectedDate: Long): Long {
    val selectedCal = Calendar.getInstance().apply { timeInMillis = selectedDate }
    val nowCal = Calendar.getInstance()
    return Calendar.getInstance().apply {
        set(Calendar.YEAR, selectedCal.get(Calendar.YEAR))
        set(Calendar.MONTH, selectedCal.get(Calendar.MONTH))
        set(Calendar.DAY_OF_MONTH, selectedCal.get(Calendar.DAY_OF_MONTH))
        set(Calendar.HOUR_OF_DAY, nowCal.get(Calendar.HOUR_OF_DAY))
        set(Calendar.MINUTE, nowCal.get(Calendar.MINUTE))
        set(Calendar.SECOND, nowCal.get(Calendar.SECOND))
        set(Calendar.MILLISECOND, nowCal.get(Calendar.MILLISECOND))
    }.timeInMillis
}

@Composable
fun BillItemRow(
    modifier: Modifier = Modifier,
    billItem: BillItemState,
    isStaff: Boolean,
    isProcessing: Boolean,
    isRevealed: Boolean,
    horizontalTableScrollState: ScrollState,
    onRevealChange: (Boolean) -> Unit,
    onAddToOrder: () -> Unit,
    onHistoryClick: () -> Unit,
    onBreakdownClick: () -> Unit
) {
    val keyboardController = LocalSoftwareKeyboardController.current
    val rowCoroutineScope = rememberCoroutineScope()
    val isChecked = billItem.isChecked.value
    val qty = billItem.qty.value
    val rate = billItem.rate.value
    val basePrice = billItem.basePrice.value

    val rowWidth = if (isStaff) 350.dp else 530.dp
    val actionButtonWidth = 64.dp
    val actionButtonWidthPx = with(LocalDensity.current) { actionButtonWidth.toPx() }

    var offsetX by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isRevealed) {
        if (!isRevealed) {
            offsetX = 0f
        } else {
            offsetX = actionButtonWidthPx
        }
    }

    val animatedOffsetX by animateFloatAsState(
        targetValue = offsetX,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "billItemSwipeOffset"
    )

    Box(
        modifier = modifier
            .width(rowWidth)
            .height(IntrinsicSize.Min)
    ) {
        // Background Orange Action Button on the left (Behind the Checkbox)
        Box(
            modifier = Modifier
                .matchParentSize(),
            contentAlignment = Alignment.CenterStart
        ) {
            Box(
                modifier = Modifier
                    .width(actionButtonWidth)
                    .fillMaxHeight()
                    .background(Color(0xFFFF9800))
                    .clickable {
                        onAddToOrder()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ShoppingCart,
                    contentDescription = "Add to Order",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        // Foreground Slidable Content
        Column(
            modifier = Modifier
                .offset { IntOffset(animatedOffsetX.roundToInt(), 0) }
                .fillMaxWidth()
                .background(Color.White)
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        if (delta < 0f) {
                            // Swiping right-to-left
                            if (offsetX > 0f) {
                                val newOffset = (offsetX + delta).coerceAtLeast(0f)
                                offsetX = newOffset
                                if (newOffset == 0f) {
                                    onRevealChange(false)
                                }
                            } else {
                                // Entire item table slides from right to left!
                                horizontalTableScrollState.dispatchRawDelta(-delta)
                            }
                        } else {
                            // Swiping left-to-right (delta > 0f)
                            if (horizontalTableScrollState.value > 0) {
                                // Slide the entire item table back to the left
                                horizontalTableScrollState.dispatchRawDelta(-delta)
                            } else {
                                // Table is at start (0): reveal action button for this row
                                val newOffset = (offsetX + delta).coerceIn(0f, actionButtonWidthPx)
                                offsetX = newOffset
                            }
                        }
                    },
                    onDragStopped = { velocity ->
                        if (offsetX > 0f) {
                            if (offsetX > actionButtonWidthPx / 2 && velocity >= -300f) {
                                offsetX = actionButtonWidthPx
                                onRevealChange(true)
                            } else {
                                offsetX = 0f
                                onRevealChange(false)
                            }
                        } else {
                            // Entire table fling animation
                            if (velocity < -400f) {
                                rowCoroutineScope.launch {
                                    horizontalTableScrollState.animateScrollTo(horizontalTableScrollState.maxValue)
                                }
                            } else if (velocity > 400f && horizontalTableScrollState.value > 0) {
                                rowCoroutineScope.launch {
                                    horizontalTableScrollState.animateScrollTo(0)
                                }
                            }
                        }
                    }
                )
                .clickable(enabled = isRevealed) {
                    offsetX = 0f
                    onRevealChange(false)
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = isChecked,
                    onCheckedChange = { 
                        billItem.isChecked.value = it
                        keyboardController?.hide()
                    },
                    colors = CheckboxDefaults.colors(checkedColor = Color(0xFF1976D2))
                )
                Row(
                    modifier = Modifier
                        .width(150.dp)
                        .pointerInput(Unit) {
                            detectTapGestures(
                                onLongPress = { onHistoryClick() },
                                onTap = {
                                    if (isRevealed) {
                                        offsetX = 0f
                                        onRevealChange(false)
                                    } else {
                                        billItem.isChecked.value = !billItem.isChecked.value
                                        keyboardController?.hide()
                                    }
                                }
                            )
                        },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(billItem.item.name, modifier = Modifier.weight(1f))
                    if (billItem.breakdown != null) {
                        @OptIn(ExperimentalMaterial3Api::class)
                        IconButton(onClick = onBreakdownClick, modifier = Modifier.size(24.dp)) {
                            Icon(Icons.Default.Info, contentDescription = "Breakdown", tint = Color(0xFF1976D2), modifier = Modifier.size(16.dp))
                        }
                    }
                }
                Text(billItem.item.uom, modifier = Modifier.width(70.dp))
                BasicTextField(
                    value = qty,
                    onValueChange = { billItem.qty.value = it },
                    modifier = Modifier.width(70.dp).focusRequester(billItem.focusRequester),
                    singleLine = true,
                    enabled = !isProcessing,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                    decorationBox = { innerTextField ->
                        Box(contentAlignment = Alignment.CenterStart) {
                            if (qty.isEmpty()) Text("Qty", color = Color.Gray)
                            innerTextField()
                        }
                    }
                )
                if (!isStaff) {
                    BasicTextField(
                        value = rate,
                        onValueChange = { billItem.rate.value = it },
                        modifier = Modifier.width(80.dp),
                        singleLine = true,
                        enabled = !isProcessing,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                        decorationBox = { innerTextField ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (rate.isEmpty()) Text("Rate", color = Color.Gray)
                                innerTextField()
                            }
                        }
                    )
                    BasicTextField(
                        value = basePrice,
                        onValueChange = { billItem.basePrice.value = it },
                        modifier = Modifier.width(100.dp),
                        singleLine = true,
                        enabled = !isProcessing,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                        decorationBox = { innerTextField ->
                            Box(contentAlignment = Alignment.CenterStart) {
                                if (basePrice.isEmpty()) Text("Base Price", color = Color.Gray)
                                innerTextField()
                            }
                        }
                    )
                }
            }
            HorizontalDivider(color = Color.LightGray)
        }
    }
}

private suspend fun saveAndCreatePdfInstant(
    context: Context,
    viewModel: TransactionViewModel,
    itemViewModel: ItemViewModel,
    customer: Customer?,
    date: Long,
    billItems: List<BillItemState>,
    totalAmount: Double,
    navController: NavController,
    transactionId: String?,
    draftId: String?,
    webOrderId: String?,
    isPurchaseReturn: Boolean?,
    transactionsWithBalances: List<Pair<Transaction, Double>>,
    printTwoCopies: Boolean,
    isStaff: Boolean
) {
    withContext(Dispatchers.IO) {
        val checkedBillItems = billItems.filter { it.isChecked.value }
        saveUpdatedBasePrices(checkedBillItems, itemViewModel)
        val checkedItems = checkedBillItems.map { it.toBillItem() }
        if (customer == null || checkedItems.isEmpty()) return@withContext
        val originalTransaction = if (transactionId != null) viewModel.getTransaction(transactionId) else null
        val isPaid = originalTransaction?.paid ?: false
        val displayAmount = if (isPaid) originalTransaction?.paidAmount ?: totalAmount else totalAmount
        val pdfData = PdfGenerator.createPdf(customer, date, checkedItems, displayAmount, transactionsWithBalances, isPaid, isPurchaseReturn ?: false, printTwoCopies, transactionId)
        val file = File(context.cacheDir, "bill_${UUID.randomUUID()}.pdf")
        FileOutputStream(file).use { it.write(pdfData) }
        withContext(Dispatchers.Main) {
            val phone = customer.phoneNumber?.toString() ?: ""
            val name = customer.name
            val encodedPath = URLEncoder.encode(file.absolutePath, StandardCharsets.UTF_8.name())
            if (transactionId == null) {
                viewModel.addTransactionWithBackgroundBill(context, totalAmount, date, file.absolutePath, checkedItems, draftId, isPurchaseReturn ?: false)
            } else if (originalTransaction != null) {
                viewModel.updateTransactionWithBackgroundBill(context, originalTransaction, totalAmount, date, null, checkedItems, file.absolutePath)
            }
            if (webOrderId != null) {
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                if (uid != null) FirebaseDatabase.getInstance().getReference("web_orders").child(uid).child(webOrderId).removeValue().await()
            }
            navController.popBackStack()
            if (!isStaff) navController.navigate("pdfViewer/$encodedPath?phoneNumber=$phone&customerName=$name")
        }
    }
}

private fun saveUpdatedBasePrices(
    checkedBillItems: List<BillItemState>,
    itemViewModel: ItemViewModel
) {
    checkedBillItems.forEach { billItemState ->
        val itemId = billItemState.item.id
        val newPrice = billItemState.basePrice.value.toDoubleOrNull()
        if (itemId.isNotBlank() && newPrice != null && newPrice != billItemState.item.basePrice) {
            itemViewModel.updateItemBasePrice(itemId, newPrice)
            billItemState.item = billItemState.item.copy(basePrice = newPrice)
        }
    }
}

private fun formatPrice(price: Double): String {
    return if (price % 1.0 == 0.0) price.toLong().toString() else price.toString()
}

private suspend fun addItemToCustomerOrder(
    customerId: String,
    customerName: String,
    customerType: String,
    billItemState: BillItemState
): Boolean = withContext(Dispatchers.IO) {
    val auth = FirebaseAuth.getInstance()
    val uid = auth.currentUser?.uid ?: return@withContext false
    val ordersRef = FirebaseDatabase.getInstance().getReference("web_orders").child(uid)

    val qtyStr = billItemState.qty.value.trim()
    val finalQty: Any = if (qtyStr.isEmpty()) "?" else qtyStr
    val finalRate = billItemState.rate.value.trim().ifEmpty { billItemState.item.basePrice.toString() }
    val finalBasePrice = billItemState.basePrice.value.trim().ifEmpty { billItemState.item.basePrice.toString() }

    val orderItem = BillItem(
        itemId = billItemState.item.id,
        name = billItemState.item.name,
        qty = finalQty,
        rate = finalRate,
        uom = billItemState.item.uom,
        basePrice = finalBasePrice,
        breakdown = billItemState.breakdown
    )

    try {
        val snapshot = ordersRef.orderByChild("customerId").equalTo(customerId).get().await()
        val pendingOrderSnap = snapshot.children.find {
            it.child("status").getValue(String::class.java) == "Pending"
        }

        if (pendingOrderSnap != null) {
            val existingOrder = WebOrder.fromSnapshot(pendingOrderSnap)
            val updatedItems = (existingOrder?.items?.toMutableList() ?: mutableListOf()).apply {
                add(orderItem)
            }
            val orderKey = pendingOrderSnap.key ?: existingOrder?.id ?: ""
            if (orderKey.isNotEmpty()) {
                val updatedOrder = (existingOrder ?: WebOrder()).copy(
                    id = orderKey,
                    items = updatedItems
                )
                ordersRef.child(orderKey).setValue(updatedOrder).await()
            }
        } else {
            val newRef = ordersRef.push()
            val newOrder = WebOrder(
                id = newRef.key ?: "",
                customerId = customerId,
                customerName = customerName,
                customerType = customerType,
                date = System.currentTimeMillis(),
                items = listOf(orderItem),
                status = "Pending"
            )
            newRef.setValue(newOrder).await()
        }
        true
    } catch (e: Exception) {
        android.util.Log.e("CreateBill", "Error adding item to order", e)
        false
    }
}
