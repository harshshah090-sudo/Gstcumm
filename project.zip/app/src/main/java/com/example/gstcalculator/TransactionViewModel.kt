package com.example.gstcalculator

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.ValueEventListener
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.database.Transaction as FirebaseTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import kotlin.coroutines.resume

data class SaleHistoryEntry(
    val date: Long = 0L,
    val qty: String = "",
    val rate: Double = 0.0
)

data class ItemSale(
    val customerName: String,
    val rate: Double,
    val date: Long,
    val isBill: Boolean = true,
    val qty: String = "",
    val history: List<SaleHistoryEntry> = emptyList()
)

class TransactionViewModel(context: Context?, private val customerId: String, private val customerType: String) : ViewModel() {
    val customer = mutableStateOf<Customer?>(null)
    val transactionsWithBalances = mutableStateOf<List<Pair<Transaction, Double>>>(emptyList())
    val showTransactionDialog = mutableStateOf(false)
    val transactionType = mutableStateOf("GAVE")
    val editingTransaction = mutableStateOf<Transaction?>(null)
    val drafts = mutableStateOf<List<DraftBill>>(emptyList())
    val itemRates = mutableStateOf<Map<String, Map<String, Any>>>(emptyMap())
    val isConnected = mutableStateOf(true)
    val userName = mutableStateOf<String?>(null)
    val localImageUris = mutableStateMapOf<String, Uri>()

    val selectedTransactionIds = mutableStateOf<Set<String>>(emptySet())
    val isSelectionModeActive = derivedStateOf { selectedTransactionIds.value.isNotEmpty() }

    private val database = when (customerType) {
        "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
        "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
        "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
        else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(customerType)
    }
    private val deletedTransactionsDatabase = FirebaseDatabase.getInstance().getReference("deleted_transactions")
    private val auth = FirebaseAuth.getInstance()
    private val usersDatabase = FirebaseDatabase.getInstance().getReference("users")

    private var heartbeatJob: Job? = null
    private var currentDraftId: String? = null

    init {
        database.child(customerId).keepSynced(true)
        loadData()
        loadDrafts()
        loadItemRates()
        monitorFirebaseConnection()
        fetchUserName()
    }

    private fun fetchUserName() {
        auth.currentUser?.uid?.let { uid ->
            usersDatabase.child(uid).child("name").addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    userName.value = snapshot.getValue(String::class.java) ?: auth.currentUser?.email?.substringBefore("@")
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        }
    }

    private fun sanitizeKey(key: String): String = key.replace(".", ",").replace("/", "__slash__")
    private fun desanitizeKey(key: String): String = key.replace(",", ".").replace("__slash__", "/")

    private fun loadData() {
        database.child(customerId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                viewModelScope.launch {
                    val newCustomer = try {
                        snapshot.getValue(Customer::class.java)?.also {
                            val balanceValue = snapshot.child("initialBalance").value
                            if (balanceValue is Number) it.initialBalance = balanceValue.toDouble()
                            // Force hasDraft from actual folder existence, ignoring any stored boolean
                            it.hasDraft = snapshot.child("drafts").hasChildren()
                        }
                    } catch (e: Exception) { null }

                    val currentTime = System.currentTimeMillis()
                    var stuckTransactionDetected = false
                    val allTransactions = snapshot.child("transactions").children.mapNotNull { dataSnapshot ->
                        dataSnapshot.key?.let { id ->
                            val t = parseTransaction(dataSnapshot)
                            if (t != null && t.syncing && (currentTime - t.version) > 60 * 1000) {
                                database.child(customerId).child("transactions").child(id).updateChildren(mapOf("syncing" to false, "syncFailed" to true))
                                stuckTransactionDetected = true
                                t.copy(syncing = false, syncFailed = true)
                            } else t
                        }
                    }

                    if (stuckTransactionDetected) {
                        database.child(customerId).child("syncing").setValue(allTransactions.any { it.syncing })
                    }

                    val transactionsWithBalancesList = withContext(Dispatchers.Default) {
                        val sortedTransactions = allTransactions.sortedBy { it.date ?: 0L }
                        val result = mutableListOf<Pair<Transaction, Double>>()
                        var runningBalance = 0.0
                        for (transaction in sortedTransactions) {
                            runningBalance += if (transaction.type == "GAVE") (transaction.amount ?: 0.0) else -(transaction.amount ?: 0.0)
                            result.add(Pair(transaction, runningBalance))
                        }
                        if (newCustomer != null && kotlin.math.abs(runningBalance - (newCustomer.initialBalance ?: 0.0)) > 0.01) {
                            database.child(customerId).child("initialBalance").setValue(runningBalance)
                        }
                        result.sortedByDescending { it.first.date ?: 0L }
                    }

                    withContext(Dispatchers.Main) {
                        customer.value = newCustomer
                        transactionsWithBalances.value = transactionsWithBalancesList
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    private fun parseTransaction(snapshot: DataSnapshot): Transaction? {
        val t = snapshot.getValue(Transaction::class.java) ?: return null
        t.id = snapshot.key
        if (t.items.isEmpty() && snapshot.hasChild("items")) {
            t.items = snapshot.child("items").children.mapNotNull { it.getValue(BillItem::class.java) }
        }
        return t
    }

    suspend fun getTransaction(transactionId: String): Transaction? = suspendCancellableCoroutine { continuation ->
        val ref = database.child(customerId).child("transactions").child(transactionId)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (continuation.isActive) continuation.resume(parseTransaction(snapshot))
            }
            override fun onCancelled(error: DatabaseError) {
                if (continuation.isActive) continuation.resume(null)
            }
        }
        ref.addListenerForSingleValueEvent(listener)
        continuation.invokeOnCancellation { ref.removeEventListener(listener) }
    }

    fun addTransaction(amount: Double, date: Long, note: String?, items: List<BillItem> = emptyList(), photoUri: Uri? = null, context: Context? = null) {
        val newTransactionId = database.child(customerId).child("transactions").push().key ?: return
        val transaction = Transaction(id = newTransactionId, amount = amount, type = transactionType.value, date = date, note = note, version = System.currentTimeMillis(), items = items, syncing = photoUri != null)
        
        if (photoUri != null) {
            localImageUris[newTransactionId] = photoUri
        }
        
        viewModelScope.launch {
            database.child(customerId).child("transactions").child(newTransactionId).setValue(transaction)
            updateCustomerBalance(if (transaction.type == "GAVE") amount else -amount)
            updateLastUpdatedToLatestTransaction()
            if (photoUri != null && context != null) {
                database.child(customerId).child("syncing").setValue(true)
                enqueuePhotoUpload(context, newTransactionId, photoUri)
            }
        }
    }

    private fun enqueuePhotoUpload(context: Context, transactionId: String, photoUri: Uri) {
        val request = OneTimeWorkRequestBuilder<PhotoUploadWorker>()
            .setInputData(Data.Builder()
                .putString("customerId", customerId)
                .putString("transactionId", transactionId)
                .putString("customerType", customerType)
                .putString("photoUri", photoUri.toString())
                .build())
            .build()
        WorkManager.getInstance(context).enqueue(request)
    }

    fun retrySync(context: Context, transaction: Transaction) {
        val transactionId = transaction.id ?: return
        database.child(customerId).child("transactions").child(transactionId).updateChildren(mapOf("syncing" to true, "syncFailed" to false, "version" to System.currentTimeMillis()))
        database.child(customerId).child("syncing").setValue(true)
        
        if (transaction.items.isNotEmpty()) {
            viewModelScope.launch(Dispatchers.IO) {
                val totalAmount = if (transaction.paid) transaction.paidAmount ?: 0.0 else transaction.amount ?: 0.0
                val pdfData = PdfGenerator.createPdf(customer.value, transaction.date ?: 0, transaction.items, totalAmount, transactionsWithBalances.value, transaction.paid, transaction.type == "GOT", false)
                val file = File(context.cacheDir, "bill_${transactionId}.pdf")
                FileOutputStream(file).use { it.write(pdfData) }
                withContext(Dispatchers.Main) {
                    val request = OneTimeWorkRequestBuilder<BillUploadWorker>().setInputData(Data.Builder().putString("customerId", customerId).putString("transactionId", transactionId).putString("customerType", customerType).putString("pdfPath", file.absolutePath).build()).build()
                    WorkManager.getInstance(context).enqueue(request)
                }
            }
        } else if (transaction.photoUrl != null || transaction.syncFailed) {
            // ...
        }
    }

    suspend fun addTransactionWithBackgroundBill(context: Context, amount: Double, date: Long, localPdfPath: String, items: List<BillItem> = emptyList(), draftId: String? = null, isPurchaseReturn: Boolean) {
        val newTransactionId = database.child(customerId).child("transactions").push().key ?: return
        val type = if (isPurchaseReturn) "GOT" else "GAVE"
        val profit = if (!isPurchaseReturn) items.sumOf { it.getQtyDouble() * ((it.rate.toDoubleOrNull() ?: 0.0) - (it.basePrice.toDoubleOrNull() ?: 0.0)) } else 0.0
        val transaction = Transaction(id = newTransactionId, customerId = customerId, amount = amount, type = type, date = date, version = System.currentTimeMillis(), items = items, profit = profit, syncing = true)
        
        val updates = mutableMapOf<String, Any?>()
        updates["transactions/$newTransactionId"] = transaction
        updates["syncing"] = true
        
        if (draftId != null) {
            updates["drafts/$draftId"] = null
            // Instant local update to remove signal immediately
            val updatedDrafts = drafts.value.filter { it.id != draftId }
            drafts.value = updatedDrafts
            
            if (updatedDrafts.isEmpty()) {
                updates["hasDraft"] = false
                customer.value = customer.value?.copy(hasDraft = false)
            }
        }
        
        database.child(customerId).updateChildren(updates).await()
        updateLastUpdatedToLatestTransaction()
        
        updateCustomerBalance(if (type == "GAVE") amount else -amount)
        saveItemRates(items, date, isBill = true)
        
        val request = OneTimeWorkRequestBuilder<BillUploadWorker>().setInputData(Data.Builder().putString("customerId", customerId).putString("transactionId", newTransactionId).putString("customerType", customerType).putString("pdfPath", localPdfPath).build()).build()
        WorkManager.getInstance(context).enqueue(request)
    }

    suspend fun updateTransactionWithBackgroundBill(context: Context, originalTransaction: Transaction, newAmount: Double, newDate: Long, newNote: String?, newItems: List<BillItem>, localPdfPath: String?) {
        val transactionId = originalTransaction.id ?: return
        val profit = if (originalTransaction.type != "GOT") newItems.sumOf { it.getQtyDouble() * ((it.rate.toDoubleOrNull() ?: 0.0) - (it.basePrice.toDoubleOrNull() ?: 0.0)) } else 0.0
        val updates = mutableMapOf<String, Any?>("amount" to newAmount, "date" to newDate, "note" to newNote, "version" to System.currentTimeMillis(), "items" to newItems, "profit" to profit)
        if (localPdfPath != null) { updates["syncing"] = true; updates["syncFailed"] = false }
        val balanceChange = (if (originalTransaction.type == "GAVE") newAmount else -newAmount) - getTransactionValue(originalTransaction)
        updateCustomerBalance(balanceChange)
        database.child(customerId).child("transactions").child(transactionId).updateChildren(updates).await()
        if (localPdfPath != null) database.child(customerId).child("syncing").setValue(true)
        updateLastUpdatedToLatestTransaction()
        saveItemRates(newItems, newDate, isBill = true)
        if (localPdfPath != null) {
            val request = OneTimeWorkRequestBuilder<BillUploadWorker>().setInputData(Data.Builder().putString("customerId", customerId).putString("transactionId", transactionId).putString("customerType", customerType).putString("pdfPath", localPdfPath).build()).build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }

    fun updateTransactionAmount(transactionId: String, newAmount: Double, newNote: String, newDate: Long, photoUri: Uri? = null, removePhoto: Boolean = false, context: Context? = null) {
        if (photoUri != null) {
            localImageUris[transactionId] = photoUri
        }
        viewModelScope.launch {
            val original = getTransaction(transactionId) ?: return@launch
            val updates = mutableMapOf<String, Any?>("amount" to newAmount, "note" to newNote, "date" to newDate, "version" to System.currentTimeMillis())
            if (removePhoto) updates["photoUrl"] = null
            if (photoUri != null) { updates["syncing"] = true; updates["syncFailed"] = false }
            updateCustomerBalance((if (original.type == "GAVE") newAmount else -newAmount) - getTransactionValue(original))
            database.child(customerId).child("transactions").child(transactionId).updateChildren(updates)
            updateLastUpdatedToLatestTransaction()
            if (photoUri != null && context != null) { 
                database.child(customerId).child("syncing").setValue(true)
                enqueuePhotoUpload(context, transactionId, photoUri) 
            }
        }
    }

    suspend fun getSalesHistoryForItem(itemName: String, itemUom: String, itemId: String? = null, oldNames: List<String> = emptyList()): List<ItemSale> = withContext(Dispatchers.IO) {
        val historyMap = mutableMapOf<String, ItemSale>() // Key: CustomerName-CustomerID
        val categories = listOf("STAFF", "LOCALS", "HOME") + DataRepository.customScreens.value
        val allSearchNames = (listOf(itemName) + oldNames).distinct()
        val sanitizedNameKeys = allSearchNames.map { sanitizeKey("$it-$itemUom") }
        val sanitizedIdKey = itemId?.takeIf { it.isNotBlank() }?.let { sanitizeKey(it) }
        val oneYearAgo = System.currentTimeMillis() - (365L * 24 * 60 * 60 * 1000L)

        // PERMANENT & INSTANT HISTORY: Scan strictly from itemRates
        // This node is updated on Save and survives Bill Deletion.
        for (category in categories) {
            try {
                val type = when(category) {
                    "STAFF" -> "customers_staff"
                    "LOCALS" -> "customers_locals"
                    "HOME" -> "customers_home"
                    else -> "custom_customers/$category"
                }
                val snap = FirebaseDatabase.getInstance().getReference(type).get().await()
                
                for (cSnap in snap.children) {
                    val name = cSnap.child("name").getValue(String::class.java) ?: continue
                    val cId = cSnap.key ?: ""
                    
                    val ratesSnap = cSnap.child("itemRates")
                    // Find the best match (by ID or Name+UOM)
                    val rateSnap = sanitizedIdKey?.let { ratesSnap.child(it).takeIf { it.exists() } } 
                                  ?: sanitizedNameKeys.mapNotNull { ratesSnap.child(it).takeIf { it.exists() } }.firstOrNull()
                    
                    if (rateSnap != null && rateSnap.exists()) {
                        val rate = if (rateSnap.hasChild("rate")) rateSnap.child("rate").value.toString().toDoubleOrNull() ?: 0.0
                                  else rateSnap.value.toString().toDoubleOrNull() ?: 0.0
                        
                        val date = if (rateSnap.hasChild("date")) (rateSnap.child("date").value as? Number)?.toLong() ?: 0L else 0L
                        val isBill = rateSnap.child("isBill").getValue(Boolean::class.java) ?: false
                        var qty = if (rateSnap.hasChild("qty")) rateSnap.child("qty").value?.toString() ?: "" else ""
                        
                        val historyList = mutableListOf<SaleHistoryEntry>()
                        val expiredKeys = mutableListOf<String>()

                        // 1. Read persistent history from itemRates
                        if (rateSnap.hasChild("history")) {
                            for (hSnap in rateSnap.child("history").children) {
                                val hDate = (hSnap.child("date").value as? Number)?.toLong() ?: 0L
                                if (hDate < oneYearAgo) {
                                    hSnap.key?.let { expiredKeys.add(it) }
                                } else {
                                    val hQty = hSnap.child("qty").value?.toString() ?: ""
                                    val hRate = (hSnap.child("rate").value as? Number)?.toDouble()
                                        ?: hSnap.child("rate").value?.toString()?.toDoubleOrNull() ?: 0.0
                                    if (hRate > 0.0) {
                                        historyList.add(SaleHistoryEntry(date = hDate, qty = hQty, rate = hRate))
                                    }
                                }
                            }
                        }

                        // Erase expired history entries past 365 days
                        if (expiredKeys.isNotEmpty()) {
                            val updates = expiredKeys.associate { "$it" to null }
                            rateSnap.ref.child("history").updateChildren(updates)
                        }

                        // 2. Backfill from existing customer transactions within 365 days if any
                        val transSnap = cSnap.child("transactions")
                        if (transSnap.exists()) {
                            for (tSnap in transSnap.children) {
                                val tDate = (tSnap.child("date").value as? Number)?.toLong() ?: 0L
                                val tType = tSnap.child("type").getValue(String::class.java) ?: ""
                                if (tType == "GAVE" && tDate >= oneYearAgo) {
                                    val itemsSnap = tSnap.child("items")
                                    for (itemSnap in itemsSnap.children) {
                                        val tItemId = itemSnap.child("itemId").getValue(String::class.java) ?: ""
                                        val tName = itemSnap.child("name").getValue(String::class.java) ?: ""
                                        val tUom = itemSnap.child("uom").getValue(String::class.java) ?: ""
                                        val match = (itemId != null && itemId.isNotBlank() && tItemId == itemId) ||
                                                    (allSearchNames.contains(tName) && tUom == itemUom)
                                        if (match) {
                                            val tRate = itemSnap.child("rate").value?.toString()?.toDoubleOrNull() ?: 0.0
                                            val tQty = itemSnap.child("qty").value?.toString() ?: ""
                                            if (tRate > 0.0) {
                                                historyList.add(SaleHistoryEntry(date = tDate, qty = tQty, rate = tRate))
                                                val entryKey = "${tDate}_${tRate.toLong()}_${tQty.filter { it.isLetterOrDigit() }}"
                                                rateSnap.ref.child("history").child(entryKey).setValue(mapOf(
                                                    "date" to tDate,
                                                    "qty" to tQty,
                                                    "rate" to tRate
                                                ))
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        // If no sub-history existed yet but main rate has date >= oneYearAgo, add it
                        if (historyList.isEmpty() && date >= oneYearAgo && rate > 0.0) {
                            historyList.add(SaleHistoryEntry(date = date, qty = qty, rate = rate))
                        }

                        // Deduplicate history entries by date + rate + qty
                        val sortedHistory = historyList
                            .filter { it.date >= oneYearAgo }
                            .distinctBy { "${it.date}_${it.rate}_${it.qty}" }
                            .sortedByDescending { it.date }

                        if (qty.isBlank() && sortedHistory.isNotEmpty()) {
                            qty = sortedHistory.first().qty
                        }

                        // ONLY show if it was a real bill sale
                        if (rate > 0.0 && isBill) {
                            historyMap["$name-$cId"] = ItemSale(
                                customerName = name,
                                rate = rate,
                                date = date,
                                isBill = true,
                                qty = qty,
                                history = sortedHistory
                            )
                        }
                    }
                }
            } catch (e: Exception) {}
        }
        
        return@withContext historyMap.values.sortedByDescending { it.date }
    }

    fun generatePdfAndGetPath(transaction: Transaction, context: Context, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val pdfData = PdfGenerator.createPdf(customer.value, transaction.date ?: 0, transaction.items, if (transaction.paid) transaction.paidAmount ?: 0.0 else transaction.amount ?: 0.0, transactionsWithBalances.value, transaction.paid, transaction.type == "GOT", false, transaction.id)
            val file = File(context.cacheDir, "bill_${transaction.id}.pdf")
            FileOutputStream(file).use { it.write(pdfData) }
            withContext(Dispatchers.Main) { onComplete(file.absolutePath) }
        }
    }

    fun generateReportAndGetPath(context: Context, startDate: Long? = null, endDate: Long? = null, onComplete: (String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            val cust = customer.value ?: return@launch
            val all = transactionsWithBalances.value.sortedBy { it.first.date }
            val (filtered, opBal) = if (startDate != null && endDate != null) {
                val before = all.filter { (it.first.date ?: 0) < startDate }
                all.filter { (it.first.date ?: 0) in startDate..endDate } to (before.lastOrNull()?.second ?: 0.0)
            } else all to null
            val pdfData = TransactionReportGenerator.createTransactionReport(cust, filtered, opBal, startDate, endDate, all.firstOrNull()?.first?.date, all.filter { (it.first.date ?: 0) < (startDate ?: 0) }.lastOrNull()?.first?.date)
            val file = File(context.externalCacheDir ?: context.cacheDir, "Report_${cust.name.replace(" ", "_")}_${System.currentTimeMillis()}.pdf")
            FileOutputStream(file).use { it.write(pdfData) }
            withContext(Dispatchers.Main) { onComplete(file.absolutePath) }
        }
    }

    fun toggleTransactionSelection(id: String) {
        val current = selectedTransactionIds.value.toMutableSet()
        if (current.contains(id)) current.remove(id) else current.add(id)
        selectedTransactionIds.value = current
    }

    fun clearTransactionSelection() { selectedTransactionIds.value = emptySet() }

    fun markAsPaid(id: String) {
        val original = transactionsWithBalances.value.firstOrNull { it.first.id == id }?.first ?: return
        val now = System.currentTimeMillis()
        updateCustomerBalance(-(original.amount ?: 0.0))
        database.child(customerId).child("transactions").child(id).updateChildren(mapOf("amount" to 0.0, "paid" to true, "paidAmount" to original.amount, "paidDate" to now, "version" to now)).addOnSuccessListener { updateLastUpdated(now) }
    }

    fun markAsUnpaid(id: String) {
        val original = transactionsWithBalances.value.firstOrNull { it.first.id == id }?.first ?: return
        if (!original.paid) return
        val amount = original.paidAmount ?: 0.0
        val now = System.currentTimeMillis()
        updateCustomerBalance(amount)
        database.child(customerId).child("transactions").child(id).updateChildren(mapOf("amount" to amount, "paid" to false, "paidAmount" to null, "paidDate" to null, "version" to now)).addOnSuccessListener { updateLastUpdated(now) }
    }

    fun deleteTransaction(id: String?) {
        id ?: return
        viewModelScope.launch {
            val t = transactionsWithBalances.value.firstOrNull { it.first.id == id }?.first ?: return@launch
            updateCustomerBalance(-getTransactionValue(t))
            deletedTransactionsDatabase.child(customerId).child(id).setValue(mapOf("transaction" to t, "deletionDate" to System.currentTimeMillis()))
            database.child(customerId).child("transactions").child(id).removeValue().addOnSuccessListener { updateLastUpdatedToLatestTransaction() }
        }
    }

    fun deleteSelectedTransactions() {
        viewModelScope.launch {
            val selection = selectedTransactionIds.value
            if (selection.isEmpty()) return@launch
            val toDelete = transactionsWithBalances.value.filter { it.first.id in selection }.map { it.first }
            val change = toDelete.sumOf { getTransactionValue(it) }
            val now = System.currentTimeMillis()
            val updates = mutableMapOf<String, Any?>("$customerId/initialBalance" to (customer.value?.initialBalance ?: 0.0) - change)
            selection.forEach { id ->
                val t = toDelete.find { it.id == id } ?: return@forEach
                deletedTransactionsDatabase.child(customerId).child(id).setValue(mapOf("transaction" to t, "deletionDate" to now))
                updates["$customerId/transactions/$id"] = null
            }
            database.updateChildren(updates).addOnSuccessListener { selectedTransactionIds.value = emptySet(); updateLastUpdatedToLatestTransaction() }
        }
    }

    private fun getTransactionValue(t: Transaction): Double = if (t.type == "GAVE") (t.amount ?: 0.0) else -(t.amount ?: 0.0)

    private fun updateCustomerBalance(change: Double) {
        database.child(customerId).child("initialBalance").runTransaction(object : FirebaseTransaction.Handler {
            override fun doTransaction(data: MutableData): FirebaseTransaction.Result {
                data.value = ((data.value as? Number)?.toDouble() ?: 0.0) + change
                return FirebaseTransaction.success(data)
            }
            override fun onComplete(e: DatabaseError?, c: Boolean, s: DataSnapshot?) {}
        })
    }

    private fun updateLastUpdated(ts: Long) { database.child(customerId).child("lastUpdated").setValue(ts) }

    private fun updateLastUpdatedToLatestTransaction() {
        database.child(customerId).child("transactions").orderByChild("date").limitToLast(1).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val last = s.children.firstOrNull()?.getValue(Transaction::class.java)
                database.child(customerId).child("lastUpdated").setValue(last?.date ?: customer.value?.creationDate ?: System.currentTimeMillis())
            }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    suspend fun saveDraft(id: String?, date: Long, items: List<BillItem>) {
        if (items.isEmpty()) return
        val draftId = id ?: database.child(customerId).child("drafts").push().key ?: return
        
        // Instant local update for immediate UI feedback
        customer.value = customer.value?.copy(hasDraft = true)
        
        val updates = mutableMapOf<String, Any?>()
        updates["drafts/$draftId"] = mapOf("id" to draftId, "date" to date, "items" to items)
        updates["hasDraft"] = true // Explicit small field for fast signaling
        
        database.child(customerId).updateChildren(updates).await()
        saveItemRates(items, date, isBill = false)
    }

    private fun loadDrafts() {
        database.child(customerId).child("drafts").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                val draftList = mutableListOf<DraftBill>()
                val toRemove = mutableMapOf<String, Any?>()
                
                s.children.forEach { snap ->
                    val draft = snap.getValue(DraftBill::class.java)?.copy(id = snap.key ?: "")
                    if (draft != null) {
                        if (draft.items.isEmpty()) {
                            toRemove[snap.key!!] = null
                        } else {
                            draftList.add(draft)
                        }
                    }
                }
                
                // Immediate local update for UI
                drafts.value = draftList
                
                // Clean up ghost drafts in background
                if (toRemove.isNotEmpty()) {
                    database.child(customerId).child("drafts").updateChildren(toRemove)
                }

                // Robust local state update for instant UI feedback
                val shouldHaveDraft = draftList.isNotEmpty()
                if (customer.value?.hasDraft != shouldHaveDraft) {
                    customer.value = customer.value?.copy(hasDraft = shouldHaveDraft)
                    // SELF-HEALING: Fix the database signal if it's out of sync
                    database.child(customerId).child("hasDraft").setValue(shouldHaveDraft)
                }
            }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    fun getDraft(id: String, onLoaded: (DraftBill?) -> Unit) {
        database.child(customerId).child("drafts").child(id).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { onLoaded(s.getValue(DraftBill::class.java)?.copy(id = s.key ?: "")) }
            override fun onCancelled(e: DatabaseError) { onLoaded(null) }
        })
    }

    fun tryLockDraft(id: String, deviceId: String, name: String = "", onResult: (Boolean, String?) -> Unit) {
        currentDraftId = id
        database.child(customerId).child("drafts").child(id).runTransaction(object : FirebaseTransaction.Handler {
            override fun doTransaction(data: MutableData): FirebaseTransaction.Result {
                val d = data.getValue(DraftBill::class.java) ?: return FirebaseTransaction.success(data)
                val locked = d.lockedBy != null && (System.currentTimeMillis() - (d.lockTimestamp ?: 0)) < 300000 && d.lockedBy != deviceId
                if (!locked) { data.child("lockedBy").value = deviceId; data.child("lockedByName").value = name; data.child("lockTimestamp").value = System.currentTimeMillis(); return FirebaseTransaction.success(data) }
                return FirebaseTransaction.abort()
            }
            override fun onComplete(e: DatabaseError?, c: Boolean, s: DataSnapshot?) {
                if (c) { setupOnDisconnectLock(id); startHeartbeat(id); onResult(true, null) }
                else onResult(false, s?.child("lockedByName")?.getValue(String::class.java) ?: "Another user")
            }
        })
    }

    private fun setupOnDisconnectLock(id: String) {
        val ref = database.child(customerId).child("drafts").child(id)
        ref.child("lockedBy").onDisconnect().removeValue()
        ref.child("lockedByName").onDisconnect().removeValue()
        ref.child("lockTimestamp").onDisconnect().removeValue()
    }

    private fun startHeartbeat(id: String) {
        heartbeatJob?.cancel()
        heartbeatJob = viewModelScope.launch {
            while (true) { delay(60000); database.child(customerId).child("drafts").child(id).child("lockTimestamp").setValue(System.currentTimeMillis()) }
        }
    }

    fun releaseLock(id: String) {
        if (currentDraftId == id) { heartbeatJob?.cancel(); heartbeatJob = null; currentDraftId = null }
        database.child(customerId).child("drafts").child(id).updateChildren(mapOf("lockedBy" to null, "lockedByName" to null, "lockTimestamp" to null))
    }

    fun deleteDraft(id: String) {
        if (currentDraftId == id) { heartbeatJob?.cancel(); heartbeatJob = null; currentDraftId = null }
        
        // Optimistic UI update
        val updatedList = drafts.value.filter { it.id != id }
        drafts.value = updatedList
        
        val updates = mutableMapOf<String, Any?>()
        updates["drafts/$id"] = null
        
        // Atomic cleanup of the flag if this was the last draft
        if (updatedList.isEmpty()) {
            updates["hasDraft"] = false
        }
        
        database.child(customerId).updateChildren(updates)
    }

    private fun loadItemRates() {
        database.child(customerId).child("itemRates").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { 
                itemRates.value = s.children.associate { 
                    val rate = if (it.hasChild("rate")) it.child("rate").value.toString() else it.value.toString()
                    val date = if (it.hasChild("date")) (it.child("date").value as? Number)?.toLong() ?: 0L else 0L
                    val isBill = it.child("isBill").getValue(Boolean::class.java) ?: false
                    desanitizeKey(it.key!!) to mapOf("rate" to rate, "date" to date, "isBill" to isBill)
                } 
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun migrateItemRates(allItems: List<Item>) {
        if (allItems.isEmpty()) return
        database.child(customerId).child("itemRates").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) {
                viewModelScope.launch {
                    val updates = mutableMapOf<String, Any?>()
                    val now = System.currentTimeMillis()
                    
                    allItems.forEach { item ->
                        val sanitizedId = sanitizeKey(item.id)
                        val currentNameKey = sanitizeKey("${item.name}-${item.uom}")
                        
                        val idSnap = s.child(sanitizedId)
                        val nameSnap = s.child(currentNameKey)
                        
                        if (idSnap.exists() && !idSnap.hasChild("rate")) {
                            val plainRate = idSnap.value.toString()
                            if (plainRate != "null") {
                                // Try to get date from transaction history if missing
                                val histDate = transactionsWithBalances.value.map { it.first }
                                    .filter { it.type == "GAVE" }
                                    .firstOrNull { t -> t.items.any { bi -> bi.itemId == item.id } }?.date ?: now
                                updates[sanitizedId] = mapOf("rate" to plainRate, "date" to histDate)
                            }
                        }
                        
                        if (nameSnap.exists()) {
                            val nameData = nameSnap.value
                            if (nameData is Map<*, *>) {
                                // Preserve existing map data (rate, date, isBill)
                                updates[sanitizedId] = nameData
                            } else {
                                val nameRate = nameData.toString()
                                val finalDate = transactionsWithBalances.value.map { it.first }
                                        .filter { it.type == "GAVE" }
                                        .firstOrNull { t -> t.items.any { it.name == item.name && it.uom == item.uom } }?.date ?: 0L
                                
                                if (nameRate != "null") {
                                    updates[sanitizedId] = mapOf("rate" to nameRate, "date" to finalDate, "isBill" to (finalDate > 0))
                                }
                            }
                            updates[currentNameKey] = null
                        }
                    }
                    
                    if (updates.isNotEmpty()) {
                        database.child(customerId).child("itemRates").updateChildren(updates)
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    fun getLastRateForItem(itemId: String, itemName: String, itemUom: String, oldNames: List<String> = emptyList()): String {
        if (itemRates.value.containsKey(itemId)) return itemRates.value[itemId]?.get("rate")?.toString() ?: ""
        val nameKey = "$itemName-$itemUom"
        if (itemRates.value.containsKey(nameKey)) return itemRates.value[nameKey]?.get("rate")?.toString() ?: ""
        
        // Check transaction history for the last sold rate
        val transactionWithItem = transactionsWithBalances.value
            .map { it.first }
            .filter { it.type == "GAVE" }
            .firstOrNull { t -> 
                t.items.any { it.itemId == itemId || (it.name == itemName && it.uom == itemUom) || it.name in oldNames }
            }
            
        if (transactionWithItem != null) {
            val billItem = transactionWithItem.items.firstOrNull { 
                it.itemId == itemId || (it.name == itemName && it.uom == itemUom) || it.name in oldNames 
            }
            val rate = billItem?.rate ?: ""
            if (rate.isNotEmpty()) {
                // Use the date from the actual transaction and mark as a real bill
                saveItemRate(itemId, itemName, itemUom, rate, transactionWithItem.date ?: System.currentTimeMillis(), isBill = true)
                return rate
            }
        }
        return ""
    }

    fun saveItemRate(itemId: String?, itemName: String, itemUom: String, rate: String, date: Long = System.currentTimeMillis(), isBill: Boolean = false, qty: String = "") {
        val r = rate.toDoubleOrNull()
        if (r != null && r > 0.0) {
            val key = if (!itemId.isNullOrEmpty()) itemId else "$itemName-$itemUom"
            val sanitized = sanitizeKey(key)
            val existingData = itemRates.value[key]
            val existingDate = (existingData?.get("date") as? Number)?.toLong() ?: 0L
            val oneYearAgo = System.currentTimeMillis() - (365L * 24 * 60 * 60 * 1000L)
            
            val rateData = mutableMapOf<String, Any?>(
                "rate" to rate,
                "date" to date,
                "isBill" to isBill
            )
            if (qty.isNotBlank()) rateData["qty"] = qty
            
            // SMART UPDATE: Only update main fields if the new date is more recent or the same as the existing record
            if (date >= existingDate) {
                database.child(customerId).child("itemRates").child(sanitized).updateChildren(rateData)
            }
            if (date >= oneYearAgo) {
                val histKey = "${date}_${r.toLong()}_${qty.filter { it.isLetterOrDigit() }}"
                database.child(customerId).child("itemRates").child(sanitized).child("history").child(histKey).setValue(mapOf(
                    "date" to date,
                    "qty" to qty,
                    "rate" to r
                ))
            }
        }
    }

    fun saveItemRates(items: List<BillItem>, date: Long, isBill: Boolean) {
        viewModelScope.launch {
            val oneYearAgo = System.currentTimeMillis() - (365L * 24 * 60 * 60 * 1000L)
            val updates = mutableMapOf<String, Any?>()
            items.filter { (it.itemId.isNotEmpty() || it.name.isNotEmpty()) && (it.rate.toDoubleOrNull() ?: 0.0) > 0.0 }.forEach { it ->
                val key = if (it.itemId.isNotEmpty()) it.itemId else "${it.name}-${it.uom}"
                val sanitized = sanitizeKey(key)
                val existingData = itemRates.value[key]
                val existingDate = (existingData?.get("date") as? Number)?.toLong() ?: 0L
                val qtyStr = it.getQtyString()
                val r = it.rate.toDoubleOrNull() ?: 0.0
                
                if (date >= existingDate) {
                    updates["$sanitized/rate"] = it.rate
                    updates["$sanitized/qty"] = qtyStr
                    updates["$sanitized/date"] = date
                    updates["$sanitized/isBill"] = isBill
                }
                
                if (date >= oneYearAgo) {
                    val histKey = "${date}_${r.toLong()}_${qtyStr.filter { c -> c.isLetterOrDigit() }}"
                    updates["$sanitized/history/$histKey"] = mapOf(
                        "date" to date,
                        "qty" to qtyStr,
                        "rate" to r
                    )
                }
            }
            if (updates.isNotEmpty()) database.child(customerId).child("itemRates").updateChildren(updates)
        }
    }

    fun transferBill(
        context: Context,
        targetCustomer: Customer,
        items: List<BillItem>,
        date: Long,
        originalTransactionId: String?,
        originalDraftId: String?,
        originalWebOrderId: String?,
        onComplete: (String) -> Unit
    ) {
        viewModelScope.launch {
            val targetRef = when (targetCustomer.customerType) {
                "STAFF" -> FirebaseDatabase.getInstance().getReference("customers_staff")
                "LOCALS" -> FirebaseDatabase.getInstance().getReference("customers_locals")
                "HOME" -> FirebaseDatabase.getInstance().getReference("customers_home")
                else -> FirebaseDatabase.getInstance().getReference("custom_customers").child(targetCustomer.customerType)
            }.child(targetCustomer.id!!)

            // 1. Fetch target item rates
            val ratesSnap = targetRef.child("itemRates").get().await()
            val targetRates = ratesSnap.children.associate { 
                val rateValue = if (it.hasChild("rate")) it.child("rate").value.toString() else it.value.toString()
                desanitizeKey(it.key!!) to rateValue 
            }

            // 2. Adjust rates
            val adjustedItems = items.map { item ->
                val newRate = if (targetRates.containsKey(item.itemId)) {
                    targetRates[item.itemId]!!
                } else if (targetRates.containsKey("${item.name}-${item.uom}")) {
                    targetRates["${item.name}-${item.uom}"]!!
                } else {
                    ""
                }
                item.copy(rate = newRate)
            }

            // 3. Create new draft for target
            val newDraftId = targetRef.child("drafts").push().key ?: return@launch
            val draftData = mapOf(
                "id" to newDraftId,
                "date" to date,
                "items" to adjustedItems
            )
            val targetUpdates = mutableMapOf<String, Any?>()
            targetUpdates["drafts/$newDraftId"] = draftData
            targetRef.updateChildren(targetUpdates).await()

            // 4. Delete original from source
            if (originalTransactionId != null) {
                deleteTransaction(originalTransactionId)
            }
            if (originalDraftId != null) {
                deleteDraft(originalDraftId)
            }
            if (originalWebOrderId != null) {
                val uid = FirebaseAuth.getInstance().currentUser?.uid
                if (uid != null) {
                    FirebaseDatabase.getInstance().getReference("web_orders").child(uid).child(originalWebOrderId).removeValue().await()
                }
            }

            onComplete(newDraftId)
        }
    }

    private fun monitorFirebaseConnection() {
        FirebaseDatabase.getInstance().getReference(".info/connected").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(s: DataSnapshot) { isConnected.value = s.getValue(Boolean::class.java) ?: false }
            override fun onCancelled(e: DatabaseError) {}
        })
    }

    override fun onCleared() { super.onCleared() ; heartbeatJob?.cancel() }
}

class TransactionViewModelFactory(private val context: Context, private val customerId: String, private val customerType: String) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(TransactionViewModel::class.java)) return TransactionViewModel(context, customerId, customerType) as T
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
