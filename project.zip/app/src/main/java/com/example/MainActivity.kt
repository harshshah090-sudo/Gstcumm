package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.ui.FormScreen
import com.example.ui.FormViewModel
import com.example.ui.FundScreen
import com.example.ui.HomeScreen
import com.example.ui.RecycleBinScreen
import com.example.ui.SanghAllottedScreen
import com.example.ui.SanghRegistrationsScreen
import com.example.ui.SettingsScreen
import com.example.ui.SwadhyaiRegistrationsScreen
import com.example.ui.theme.SwadhyayiMandalTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      SwadhyayiMandalTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          SwadhyayiAppNavigation()
        }
      }
    }
  }
}

@Composable
fun SwadhyayiAppNavigation() {
  val navController = rememberNavController()
  val viewModel: FormViewModel = viewModel()
  val context = LocalContext.current

  val openWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app"))
    context.startActivity(intent)
  }

  val openSwadhyaiWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app/swadhyai.html"))
    context.startActivity(intent)
  }

  NavHost(
    navController = navController,
    startDestination = "home"
  ) {
    composable("home") {
      HomeScreen(
        viewModel = viewModel,
        onNavigateToNewForm = openWebForm,
        onNavigateToSanghRegistrations = { navController.navigate("sangh_registrations") },
        onNavigateToSwadhyaiRegistrations = { navController.navigate("swadhyai_registrations") },
        onNavigateToSanghAllotted = { navController.navigate("sangh_allotted") },
        onNavigateToFund = { navController.navigate("fund") },
        onNavigateToSettings = { navController.navigate("settings") }
      )
    }

    composable("settings") {
      SettingsScreen(
        onNavigateBack = { navController.popBackStack() },
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") }
      )
    }

    composable("recycle_bin") {
      RecycleBinScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("sangh_registrations") {
      SanghRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToNewForm = openWebForm,
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") }
      )
    }

    composable("swadhyai_registrations") {
      SwadhyaiRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onOpenWebForm = openSwadhyaiWebForm
      )
    }

    composable("sangh_allotted") {
      SanghAllottedScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("fund") {
      FundScreen(
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable(
      route = "form",
      deepLinks = listOf(
        navDeepLink { uriPattern = "https://ais-pre-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://ais-dev-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "http://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "svsm://form" }
      )
    ) {
      FormScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onFormSubmitted = { _ ->
          navController.navigate("sangh_registrations") {
            popUpTo("home")
          }
        }
      )
    }
  }
}
