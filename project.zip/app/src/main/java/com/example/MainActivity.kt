package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.ui.DetailScreen
import com.example.ui.FormScreen
import com.example.ui.FormViewModel
import com.example.ui.HomeScreen
import com.example.ui.theme.SwadhyayiMandalTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      SwadhyayiMandalTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          SwadhyayiAppNavigation()
        }
      }
    }
  }
}

@Composable
fun SwadhyayiAppNavigation() {
  val navController = rememberNavController()
  val viewModel: FormViewModel = viewModel()

  NavHost(
    navController = navController,
    startDestination = "home"
  ) {
    composable("home") {
      HomeScreen(
        viewModel = viewModel,
        onNavigateToNewForm = { navController.navigate("form") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") }
      )
    }

    composable(
      route = "form",
      deepLinks = listOf(
        navDeepLink { uriPattern = "https://ais-pre-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://ais-dev-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "http://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "svsm://form" }
      )
    ) {
      FormScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onFormSubmitted = { newId ->
          navController.navigate("detail/$newId") {
            popUpTo("home")
          }
        }
      )
    }

    composable(
      route = "detail/{formId}",
      arguments = listOf(navArgument("formId") { type = NavType.LongType })
    ) { backStackEntry ->
      val formId = backStackEntry.arguments?.getLong("formId") ?: 0L
      DetailScreen(
        formId = formId,
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }
  }
}
