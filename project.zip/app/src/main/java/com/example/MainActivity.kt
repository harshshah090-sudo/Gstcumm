package com.example

import android.content.Intent
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import com.example.ui.AboutUsScreen
import com.example.ui.DigitalPanchangScreen
import com.example.ui.FormScreen
import com.example.ui.FormViewModel
import com.example.ui.FundScreen
import com.example.ui.GyanShalaScreen
import com.example.ui.HomeScreen
import com.example.ui.ProfileScreen
import com.example.ui.RecycleBinScreen
import com.example.ui.RegistrationHistoryScreen
import com.example.ui.RegistrationHistoryDetailScreen
import com.example.ui.SanghAllottedScreen
import com.example.ui.SanghRegistrationsScreen
import com.example.ui.SettingsScreen
import com.example.ui.SwadhyaiRegistrationsScreen
import com.example.ui.WidgetCustomizerScreen
import com.example.ui.components.AppBottomNavigationBar
import com.example.ui.theme.SwadhyayiMandalTheme

private const val PROGRESSIVE_BOTTOM_BLUR_SHADER = """
    uniform shader composable;
    uniform float2 size;
    uniform float blurTop;
    uniform float blurRadius;

    half4 main(float2 fragCoord) {
        if (fragCoord.y < blurTop) {
            return composable.eval(fragCoord);
        }
        
        float progress = clamp((fragCoord.y - blurTop) / max(size.y - blurTop, 1.0), 0.0, 1.0);
        float currentRadius = blurRadius * (0.35 + 0.65 * progress);
        
        // Multi-tap Poisson & Gaussian disc sampling of underlying screen content
        half4 color = composable.eval(fragCoord) * 0.18;
        
        // Inner Ring (4 orthogonal samples)
        float r1 = currentRadius * 0.40;
        color += composable.eval(fragCoord + float2(0.0, -r1)) * 0.12;
        color += composable.eval(fragCoord + float2(0.0, r1)) * 0.12;
        color += composable.eval(fragCoord + float2(-r1, 0.0)) * 0.12;
        color += composable.eval(fragCoord + float2(r1, 0.0)) * 0.12;
        
        // Middle Ring (8 diagonal & axis samples)
        float r2 = currentRadius * 0.75;
        float d1 = r2 * 0.7071;
        color += composable.eval(fragCoord + float2(-d1, -d1)) * 0.05;
        color += composable.eval(fragCoord + float2(d1, -d1)) * 0.05;
        color += composable.eval(fragCoord + float2(-d1, d1)) * 0.05;
        color += composable.eval(fragCoord + float2(d1, d1)) * 0.05;
        color += composable.eval(fragCoord + float2(0.0, -r2)) * 0.04;
        color += composable.eval(fragCoord + float2(0.0, r2)) * 0.04;
        color += composable.eval(fragCoord + float2(-r2, 0.0)) * 0.04;
        color += composable.eval(fragCoord + float2(r2, 0.0)) * 0.04;
        
        // Outer Ring (4 corner samples for rich frosted dispersion)
        float r3 = currentRadius * 1.15;
        float d2 = r3 * 0.7071;
        color += composable.eval(fragCoord + float2(-d2, -d2)) * 0.02;
        color += composable.eval(fragCoord + float2(d2, -d2)) * 0.02;
        color += composable.eval(fragCoord + float2(-d2, d2)) * 0.02;
        color += composable.eval(fragCoord + float2(d2, d2)) * 0.02;
        
        return color;
    }
"""

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    com.example.widget.TithiAppWidget.updateAllWidgets(this)
    setContent {
      SwadhyayiMandalTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          SwadhyayiAppNavigation()
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    com.example.widget.TithiAppWidget.updateAllWidgets(this)
  }
}

@Composable
fun SwadhyayiAppNavigation() {
  val navController = rememberNavController()
  val viewModel: FormViewModel = viewModel()
  val gyanViewModel: com.example.ui.GyanViewModel = viewModel()
  val context = LocalContext.current
  val activity = context as? ComponentActivity

  LaunchedEffect(activity?.intent) {
    activity?.intent?.let { intent ->
      val destination = intent.getStringExtra("destination")
      if (destination == "gyan_shala") {
        val catId = intent.getLongExtra("target_category_id", -1L)
        val topId = intent.getLongExtra("target_topic_id", -1L)
        if (catId != -1L && topId != -1L) {
          gyanViewModel.navigateToCategoryAndTopic(catId, topId)
          navController.navigate("gyan_shala") {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
          }
        }
      }
    }
  }

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val bottomBarRoutes = setOf("home", "gyan_shala", "swadhyai_registrations", "profile", "about_us")
  val showBottomBar = currentRoute in bottomBarRoutes

  var bottomBarHeightPx by remember { mutableFloatStateOf(0f) }

  val openWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app"))
    context.startActivity(intent)
  }

  val openSwadhyaiWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app/swadhyai.html"))
    context.startActivity(intent)
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(com.example.ui.theme.AppBackground)
  ) {
    NavHost(
      navController = navController,
      startDestination = "home",
      modifier = Modifier
        .fillMaxSize()
        .graphicsLayer {
          if (showBottomBar && bottomBarHeightPx > 0f && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val shader = RuntimeShader(PROGRESSIVE_BOTTOM_BLUR_SHADER).apply {
              setFloatUniform("size", size.width, size.height)
              setFloatUniform("blurTop", size.height - bottomBarHeightPx)
              setFloatUniform("blurRadius", 36f)
            }
            renderEffect = RenderEffect.createRuntimeShaderEffect(shader, "composable").asComposeRenderEffect()
          }
        }
    ) {
      composable("home") {
        HomeScreen(
          viewModel = viewModel,
          onNavigateToNewForm = openWebForm,
          onNavigateToSanghRegistrations = { navController.navigate("sangh_registrations") },
          onNavigateToSwadhyaiRegistrations = { navController.navigate("swadhyai_registrations") },
          onNavigateToSanghAllotted = { navController.navigate("sangh_allotted") },
          onNavigateToFund = { navController.navigate("fund") },
          onNavigateToPanchang = { navController.navigate("panchang") },
          onNavigateToSettings = { navController.navigate("settings") },
          onNavigateToGyanShala = { categoryId, topicId ->
            gyanViewModel.navigateToCategoryAndTopic(categoryId, topicId)
            navController.navigate("gyan_shala") {
              popUpTo("home") {
                saveState = true
              }
              launchSingleTop = true
              restoreState = true
            }
          }
        )
      }

      composable("gyan_shala") {
        GyanShalaScreen(viewModel = gyanViewModel)
      }

      composable("profile") {
        ProfileScreen(
          viewModel = viewModel,
          onNavigateToSettings = { navController.navigate("settings") },
          onNavigateToSanghRegistrations = { navController.navigate("sangh_registrations") },
          onNavigateToSwadhyaiRegistrations = { navController.navigate("swadhyai_registrations") },
          onNavigateToFund = { navController.navigate("fund") },
          onNavigateToPanchang = { navController.navigate("panchang") }
        )
      }

      composable("about_us") {
        AboutUsScreen()
      }

      composable("panchang") {
        DigitalPanchangScreen(
          viewModel = viewModel,
          onNavigateBack = { navController.popBackStack() }
        )
      }

    composable("settings") {
      SettingsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToWidgetCustomizer = { navController.navigate("widget_settings") }
      )
    }

    composable("widget_settings") {
      WidgetCustomizerScreen(
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("recycle_bin") {
      RecycleBinScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("sangh_registrations") {
      SanghRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToNewForm = openWebForm,
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToRegistrationHistory = { navController.navigate("registration_history") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") },
        initialTab = 0
      )
    }

    composable("registration_history") {
      RegistrationHistoryScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToDetail = { year -> navController.navigate("registration_history_detail/$year") }
      )
    }

    composable("registration_history_detail/{year}") { backStackEntry ->
      val yearStr = backStackEntry.arguments?.getString("year")
      val year = yearStr?.toIntOrNull() ?: 0
      RegistrationHistoryDetailScreen(
        year = year,
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("swadhyai_registrations") {
      SwadhyaiRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onOpenWebForm = openSwadhyaiWebForm
      )
    }

    composable("sangh_allotted") {
      SanghRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToNewForm = openWebForm,
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToRegistrationHistory = { navController.navigate("registration_history") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") },
        initialTab = 1
      )
    }

    composable("fund") {
      FundScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable(
      route = "form",
      deepLinks = listOf(
        navDeepLink { uriPattern = "https://ais-pre-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://ais-dev-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "http://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "svsm://form" }
      )
    ) {
      FormScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onFormSubmitted = { _ ->
          navController.navigate("sangh_registrations") {
            popUpTo("home")
          }
        }
      )
    }
  }

  val swadhyaiList by viewModel.allSwadhyaiForms.collectAsStateWithLifecycle()
  val seenSignal by com.example.utils.SwadhyaiSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
  val hasSwadhyaiUnread = remember(swadhyaiList, seenSignal) {
    com.example.utils.SwadhyaiSeenTracker.hasAnyUnreadOrUpdated(context, swadhyaiList)
  }

  if (showBottomBar) {
    AppBottomNavigationBar(
      currentRoute = currentRoute,
      onNavigateToRoute = { targetRoute ->
        navController.navigate(targetRoute) {
          popUpTo("home") {
            saveState = true
          }
          launchSingleTop = true
          restoreState = true
        }
      },
      hasSwadhyaiUnread = hasSwadhyaiUnread,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .onGloballyPositioned {
          bottomBarHeightPx = it.size.height.toFloat()
        }
    )
  }
}
}
