package com.example

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navDeepLink
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.ui.AboutUsScreen
import com.example.ui.AuthAndRegistrationScreen
import com.example.ui.DigitalPanchangScreen
import com.example.ui.FormScreen
import com.example.ui.FormViewModel
import com.example.ui.FundScreen
import com.example.ui.GyanShalaScreen
import com.example.ui.HomeScreen
import com.example.ui.NotificationsScreen
import com.example.ui.ProfileScreen
import com.example.ui.RecycleBinScreen
import com.example.ui.RegistrationHistoryScreen
import com.example.ui.RegistrationHistoryDetailScreen
import com.example.ui.SanghAllottedScreen
import com.example.ui.SanghRegistrationsScreen
import com.example.ui.SettingsScreen
import com.example.ui.SwadhyaiRegistrationsScreen
import com.example.ui.WidgetCustomizerScreen
import com.example.ui.components.AppBottomNavigationBar
import com.example.ui.theme.SwadhyayiMandalTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    try {
      com.example.data.CityPreferences.init(this)
    } catch (e: Exception) {
      e.printStackTrace()
    }
    try {
      com.example.data.UserSessionManager.init(this)
    } catch (e: Exception) {
      e.printStackTrace()
    }
    try {
      com.example.widget.TithiAppWidget.updateAllWidgets(this)
    } catch (e: Exception) {
      e.printStackTrace()
    }
    setContent {
      SwadhyayiMandalTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
          SwadhyayiAppNavigation()
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    try {
      com.example.widget.TithiAppWidget.updateAllWidgets(this)
    } catch (e: Exception) {
      e.printStackTrace()
    }
  }
}

@Composable
fun SwadhyayiAppNavigation() {
  val navController = rememberNavController()
  val viewModel: FormViewModel = viewModel()
  val gyanViewModel: com.example.ui.GyanViewModel = viewModel()
  val context = LocalContext.current
  val activity = context as? ComponentActivity

  val notifPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { _ -> }

  LaunchedEffect(Unit) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val permission = android.Manifest.permission.POST_NOTIFICATIONS
      if (ContextCompat.checkSelfPermission(context, permission) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
        notifPermissionLauncher.launch(permission)
      }
    }
  }

  LaunchedEffect(activity?.intent) {
    activity?.intent?.let { intent ->
      val notifId = intent.getLongExtra("notification_id", -1L)
      if (notifId != -1L) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          com.example.data.AppDatabase.getDatabase(context).appNotificationDao().markAsSeen(notifId)
        }
      }
      val destination = intent.getStringExtra("destination")
      if (destination == "gyan_shala") {
        val catId = intent.getLongExtra("target_category_id", -1L)
        val topId = intent.getLongExtra("target_topic_id", -1L)
        if (catId != -1L && topId != -1L) {
          gyanViewModel.navigateToCategoryAndTopic(catId, topId)
          navController.navigate("gyan_shala") {
            popUpTo("home") { saveState = true }
            launchSingleTop = true
            restoreState = true
          }
        }
      } else if (destination == "swadhyai_registrations") {
        navController.navigate("swadhyai_registrations") {
          popUpTo("home") { saveState = true }
          launchSingleTop = true
          restoreState = true
        }
      } else if (destination == "notifications") {
        navController.navigate("notifications")
      }
    }
  }

  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = navBackStackEntry?.destination?.route

  val bottomBarRoutes = setOf("home", "gyan_shala", "swadhyai_registrations", "profile", "about_us")
  val showBottomBar = currentRoute in bottomBarRoutes

  var bottomBarHeightPx by remember { mutableFloatStateOf(0f) }

  val openWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app"))
    context.startActivity(intent)
  }

  val openSwadhyaiWebForm = {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app/swadhyai.html"))
    context.startActivity(intent)
  }

  val session by com.example.data.UserSessionManager.sessionState.collectAsStateWithLifecycle()
  val initialStartDest = remember {
    if (com.example.data.UserSessionManager.isLoggedIn()) "home" else "auth"
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(com.example.ui.theme.AppBackground)
  ) {
    NavHost(
      navController = navController,
      startDestination = initialStartDest,
      modifier = Modifier
        .fillMaxSize()
    ) {
      composable("auth") {
        AuthAndRegistrationScreen(
          viewModel = viewModel,
          onLoginSuccess = {
            navController.navigate("home") {
              popUpTo("auth") { inclusive = true }
            }
          }
        )
      }

      composable("home") {
        HomeScreen(
          viewModel = viewModel,
          onNavigateToNewForm = openWebForm,
          onNavigateToSanghRegistrations = { navController.navigate("sangh_registrations") },
          onNavigateToSwadhyaiRegistrations = { navController.navigate("swadhyai_registrations") },
          onNavigateToSanghAllotted = { navController.navigate("sangh_allotted") },
          onNavigateToFund = { navController.navigate("fund") },
          onNavigateToPanchang = { navController.navigate("panchang") },
          onNavigateToSettings = { navController.navigate("settings") },
          onNavigateToRegistrationHistory = { navController.navigate("registration_history") },
          onNavigateToNotifications = { navController.navigate("notifications") },
          onNavigateToGyanShala = { categoryId, topicId ->
            gyanViewModel.navigateToCategoryAndTopic(categoryId, topicId)
            navController.navigate("gyan_shala") {
              popUpTo("home") {
                saveState = true
              }
              launchSingleTop = true
              restoreState = true
            }
          }
        )
      }

      composable("notifications") {
        NotificationsScreen(
          onNavigateBack = { navController.popBackStack() },
          onNavigateToGyanNote = { categoryId, topicId ->
            gyanViewModel.navigateToCategoryAndTopic(categoryId, topicId)
            navController.navigate("gyan_shala") {
              popUpTo("home") { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          },
          onNavigateToSwadhyai = { swadhyaiId ->
            navController.navigate("swadhyai_registrations") {
              popUpTo("home") { saveState = true }
              launchSingleTop = true
              restoreState = true
            }
          }
        )
      }

      composable("gyan_shala") {
        GyanShalaScreen(viewModel = gyanViewModel)
      }

      composable("profile") {
        ProfileScreen(
          viewModel = viewModel,
          onNavigateToSettings = { navController.navigate("settings") },
          onNavigateToSanghRegistrations = { navController.navigate("sangh_registrations") },
          onNavigateToSwadhyaiRegistrations = { navController.navigate("swadhyai_registrations") },
          onNavigateToFund = { navController.navigate("fund") },
          onNavigateToPanchang = { navController.navigate("panchang") },
          onLogout = {
            navController.navigate("auth") {
              popUpTo(0) { inclusive = true }
            }
          }
        )
      }

      composable("about_us") {
        AboutUsScreen()
      }

      composable("panchang") {
        DigitalPanchangScreen(
          viewModel = viewModel,
          onNavigateBack = { navController.popBackStack() }
        )
      }

    composable("settings") {
      SettingsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToWidgetCustomizer = { navController.navigate("widget_settings") }
      )
    }

    composable("widget_settings") {
      WidgetCustomizerScreen(
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("recycle_bin") {
      RecycleBinScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("sangh_registrations") {
      SanghRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToNewForm = openWebForm,
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToRegistrationHistory = { navController.navigate("registration_history") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") },
        initialTab = 0
      )
    }

    composable("registration_history") {
      RegistrationHistoryScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToDetail = { year -> navController.navigate("registration_history_detail/$year") }
      )
    }

    composable("registration_history_detail/{year}") { backStackEntry ->
      val yearStr = backStackEntry.arguments?.getString("year")
      val year = yearStr?.toIntOrNull() ?: 0
      RegistrationHistoryDetailScreen(
        year = year,
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable("swadhyai_registrations") {
      SwadhyaiRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onOpenWebForm = openSwadhyaiWebForm
      )
    }

    composable("sangh_allotted") {
      SanghRegistrationsScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onNavigateToNewForm = openWebForm,
        onNavigateToRecycleBin = { navController.navigate("recycle_bin") },
        onNavigateToRegistrationHistory = { navController.navigate("registration_history") },
        onNavigateToDetail = { formId -> navController.navigate("detail/$formId") },
        initialTab = 1
      )
    }

    composable("fund") {
      FundScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() }
      )
    }

    composable(
      route = "form",
      deepLinks = listOf(
        navDeepLink { uriPattern = "https://ais-pre-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://ais-dev-owvwu7ofge4acav3s57gk5-1023321145276.asia-southeast1.run.app.*" },
        navDeepLink { uriPattern = "https://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "http://svsm-paryushan.app/form" },
        navDeepLink { uriPattern = "svsm://form" }
      )
    ) {
      FormScreen(
        viewModel = viewModel,
        onNavigateBack = { navController.popBackStack() },
        onFormSubmitted = { _ ->
          navController.navigate("sangh_registrations") {
            popUpTo("home")
          }
        }
      )
    }
  }

  val swadhyaiList by viewModel.allSwadhyaiForms.collectAsStateWithLifecycle()
  val seenSignal by com.example.utils.SwadhyaiSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
  val hasSwadhyaiUnread = remember(swadhyaiList, seenSignal, session.phone) {
    com.example.utils.SwadhyaiSeenTracker.hasAnyUnreadOrUpdated(context, swadhyaiList, session.phone)
  }

  val gyanCategories by gyanViewModel.categories.collectAsStateWithLifecycle()
  val gyanAllTopics by gyanViewModel.allTopics.collectAsStateWithLifecycle()
  val gyanSeenSignal by com.example.utils.GyanSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
  val hasGyanShalaUnread = remember(gyanCategories, gyanAllTopics, gyanSeenSignal) {
    com.example.utils.GyanSeenTracker.hasAnyGyanUnreadOrUpdated(context, gyanCategories, gyanAllTopics)
  }

  if (showBottomBar) {
    AppBottomNavigationBar(
      currentRoute = currentRoute,
      onNavigateToRoute = { targetRoute ->
        navController.navigate(targetRoute) {
          popUpTo("home") {
            saveState = true
          }
          launchSingleTop = true
          restoreState = true
        }
      },
      hasSwadhyaiUnread = hasSwadhyaiUnread,
      hasGyanShalaUnread = hasGyanShalaUnread,
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .onGloballyPositioned {
          bottomBarHeightPx = it.size.height.toFloat()
        }
    )
  }
}
}
