package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * A collapsible dynamic list of string items (used for Other Religious Learnings and Lifetime Tapasya).
 * When the user fills in an entry and leaves focus (taps outside or presses Done),
 * the text box shrinks and slides into a sleek summary badge with a pencil icon to edit,
 * removing the text box from view.
 */
@Composable
fun CollapsibleStringListSection(
    title: String,
    items: List<String>,
    onItemsChange: (List<String>) -> Unit,
    placeholder: String,
    addButtonText: String,
    leadingIcon: ImageVector,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current

    // Set of indices that are actively in editing (expanded) state
    var editingIndices by remember {
        val initialEditing = mutableSetOf<Int>()
        items.forEachIndexed { index, text ->
            if (text.isBlank()) {
                initialEditing.add(index)
            }
        }
        if (initialEditing.isEmpty() && items.isNotEmpty() && items.first().isBlank()) {
            initialEditing.add(0)
        }
        mutableStateOf(initialEditing.toSet())
    }

    // Keep any blank items in editing mode
    LaunchedEffect(items) {
        val blanks = items.indices.filter { items[it].isBlank() }.toSet()
        if (blanks.isNotEmpty()) {
            editingIndices = editingIndices + blanks
        }
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AppDeepSurface,
        border = BorderStroke(1.dp, AppBorder),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = leadingIcon,
                    contentDescription = null,
                    tint = AppPrimaryGold,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary,
                    style = MaterialTheme.typography.titleSmall
                )
            }

            items.forEachIndexed { index, text ->
                val isEditing = index in editingIndices || text.isBlank()
                var isFocused by remember { mutableStateOf(false) }
                var hasEverBeenFocused by remember { mutableStateOf(false) }

                AnimatedContent(
                    targetState = isEditing,
                    transitionSpec = {
                        if (targetState) {
                            (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)))
                                .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
                        } else {
                            (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)) + slideInVertically(animationSpec = tween(280)))
                                .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
                        }
                    },
                    label = "CollapsibleStringListTransition_$index"
                ) { editingState ->
                    if (editingState) {
                        // --- EDITABLE TEXT FIELD BOX ---
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                            border = BorderStroke(1.dp, AppBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedTextField(
                                    value = text,
                                    onValueChange = { newVal ->
                                        val list = items.toMutableList()
                                        list[index] = capitalizeWords(newVal)
                                        onItemsChange(list)
                                    },
                                    placeholder = { Text(placeholder) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(
                                        capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Words,
                                        imeAction = ImeAction.Done
                                    ),
                                    keyboardActions = KeyboardActions(
                                        onDone = {
                                            focusManager.clearFocus()
                                            if (text.isNotBlank()) {
                                                editingIndices = editingIndices - index
                                            }
                                        }
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .onFocusChanged { focusState ->
                                            isFocused = focusState.isFocused
                                            if (focusState.isFocused) {
                                                hasEverBeenFocused = true
                                            } else if (hasEverBeenFocused && text.isNotBlank()) {
                                                editingIndices = editingIndices - index
                                            }
                                        }
                                )

                                if (text.isNotBlank()) {
                                    FilledTonalIconButton(
                                        onClick = {
                                            focusManager.clearFocus()
                                            editingIndices = editingIndices - index
                                        },
                                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                                            containerColor = AppPrimaryGold.copy(alpha = 0.2f),
                                            contentColor = AppPrimaryGold
                                        ),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Done",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                if (items.size > 1) {
                                    IconButton(
                                        onClick = {
                                            val list = items.toMutableList()
                                            list.removeAt(index)
                                            editingIndices = editingIndices.filter { it != index }
                                                .map { if (it > index) it - 1 else it }
                                                .toSet()
                                            onItemsChange(list)
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Delete",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // --- SHRUNK & SLIDED COMPACT SUMMARY BADGE WITH PENCIL ICON ---
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = AppSurfaceNested,
                            border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable {
                                    editingIndices = editingIndices + index
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .background(AppPrimaryGold.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = leadingIcon,
                                        contentDescription = null,
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = AppTextPrimary,
                                        fontSize = 14.sp
                                    ),
                                    modifier = Modifier.weight(1f)
                                )

                                // Pencil icon to re-edit
                                IconButton(
                                    onClick = {
                                        editingIndices = editingIndices + index
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                if (items.size > 1) {
                                    IconButton(
                                        onClick = {
                                            val list = items.toMutableList()
                                            list.removeAt(index)
                                            editingIndices = editingIndices.filter { it != index }
                                                .map { if (it > index) it - 1 else it }
                                                .toSet()
                                            onItemsChange(list)
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            val canAddMore = items.isNotEmpty() && items.last().isNotBlank()
            TextButton(
                onClick = {
                    if (canAddMore) {
                        val nextIndex = items.size
                        editingIndices = editingIndices + nextIndex
                        onItemsChange(items + "")
                    }
                },
                enabled = canAddMore
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add")
                Spacer(modifier = Modifier.width(4.dp))
                Text(addButtonText)
            }
        }
    }
}

/**
 * A collapsible single text field (used for Specify Other Speciality).
 * When the user enters their speciality and leaves focus (taps outside or presses Done),
 * the text field shrinks and slides into a sleek summary badge with a pencil icon to edit,
 * removing the text box from view.
 */
@Composable
fun CollapsibleSingleTextField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    leadingIcon: ImageVector,
    placeholder: String = "Specify here",
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    var isEditing by remember { mutableStateOf(value.isBlank()) }
    var isFocused by remember { mutableStateOf(false) }
    var hasEverBeenFocused by remember { mutableStateOf(false) }

    LaunchedEffect(value) {
        if (value.isBlank()) {
            isEditing = true
        }
    }

    AnimatedContent(
        targetState = isEditing,
        transitionSpec = {
            if (targetState) {
                (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)))
                    .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
            } else {
                (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)) + slideInVertically(animationSpec = tween(280)))
                    .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
            }
        },
        label = "CollapsibleSingleTextFieldTransition",
        modifier = modifier.fillMaxWidth()
    ) { editingState ->
        if (editingState) {
            // --- EDITABLE TEXT FIELD BOX ---
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedTextField(
                    value = value,
                    onValueChange = onValueChange,
                    label = { Text(label) },
                    placeholder = { Text(placeholder) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (value.isNotBlank()) {
                                isEditing = false
                            }
                        }
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .onFocusChanged { focusState ->
                            isFocused = focusState.isFocused
                            if (focusState.isFocused) {
                                hasEverBeenFocused = true
                            } else if (hasEverBeenFocused && value.isNotBlank()) {
                                isEditing = false
                            }
                        }
                )

                if (value.isNotBlank()) {
                    FilledTonalIconButton(
                        onClick = {
                            focusManager.clearFocus()
                            isEditing = false
                        },
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = AppPrimaryGold.copy(alpha = 0.2f),
                            contentColor = AppPrimaryGold
                        ),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Done",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        } else {
            // --- SHRUNK & SLIDED COMPACT SUMMARY BADGE WITH PENCIL ICON ---
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AppDeepSurface,
                border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp)
                    .clickable {
                        isEditing = true
                    }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(30.dp)
                            .background(AppPrimaryGold.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = leadingIcon,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = label.replace("*", "").trim(),
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted,
                                fontSize = 11.sp
                            )
                        )
                        Text(
                            text = value,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary,
                                fontSize = 14.5.sp
                            )
                        )
                    }

                    // Pencil icon to edit
                    IconButton(
                        onClick = {
                            isEditing = true
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Speciality",
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
