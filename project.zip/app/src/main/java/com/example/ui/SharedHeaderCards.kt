package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AppDeepSurface
import com.example.ui.theme.AppPrimaryGold
import com.example.ui.theme.AppSurface
import com.example.ui.theme.AppTextMuted
import com.example.ui.theme.AppTextPrimary

/**
 * Standard fixed height for both Calendar tab header card and Kalyanak tab header card
 * to ensure 100% mathematical equality in height and identical visual framing.
 */
val HEADER_CARD_HEIGHT = 138.dp

@Composable
fun SharedHeaderCardContainer(
    modifier: Modifier = Modifier,
    testTag: String,
    bgDrawableResId: Int? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(HEADER_CARD_HEIGHT)
            .padding(horizontal = 6.dp, vertical = 2.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    AppPrimaryGold.copy(alpha = 0.65f),
                    AppPrimaryGold.copy(alpha = 0.25f),
                    AppPrimaryGold.copy(alpha = 0.65f)
                )
            )
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            AppPrimaryGold.copy(alpha = 0.12f),
                            AppSurface,
                            AppDeepSurface.copy(alpha = 0.6f)
                        )
                    )
                )
        ) {
            if (bgDrawableResId != null) {
                Image(
                    painter = painterResource(id = bgDrawableResId),
                    contentDescription = null,
                    modifier = Modifier.matchParentSize(),
                    contentScale = ContentScale.Crop,
                    alpha = 0.38f
                )
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                content = content
            )
        }
    }
}
