package com.example.ui

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import com.example.data.*
import com.google.android.gms.auth.GoogleAuthUtil
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.Scope
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

enum class SyncStatus {
    IDLE, SIGNING_IN, SYNCING, SUCCESS, ERROR
}

class GoogleDriveSyncManager(
    private val context: Context,
    private val database: AppDatabase
) {
    private val TAG = "GoogleDriveSync"
    private val BACKUP_FILE_NAME = "gst_ledger_backup.json"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    private val prefs: SharedPreferences = context.getSharedPreferences("google_drive_sync_prefs", Context.MODE_PRIVATE)

    // State flows for UI observation
    val signInAccount = MutableStateFlow<GoogleSignInAccount?>(null)
    val syncStatus = MutableStateFlow(SyncStatus.IDLE)
    val syncMessage = MutableStateFlow("")
    val lastSyncTime = MutableStateFlow(0L)
    val configuredWebClientId = MutableStateFlow(
        prefs.getString("web_client_id", null) ?: "983001449808-bs2e2i9nfoh8tm0jufsbh8799cf5n5cu.apps.googleusercontent.com"
    )

    private fun buildSignInClient(): GoogleSignInClient {
        val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestEmail()
            .requestProfile()
            .requestScopes(Scope("https://www.googleapis.com/auth/drive.appdata"))

        val webId = configuredWebClientId.value.trim()
        if (webId.isNotBlank() && webId.contains("bs2e2i9nfoh8tm0jufsbh8799cf5n5cu")) {
            builder.requestIdToken(webId)
        }
        return GoogleSignIn.getClient(context, builder.build())
    }

    private var googleSignInClient: GoogleSignInClient = buildSignInClient()

    fun updateWebClientId(newClientId: String) {
        val cleanId = newClientId.trim()
        prefs.edit().putString("web_client_id", cleanId).apply()
        configuredWebClientId.value = cleanId
        googleSignInClient = buildSignInClient()
    }

    fun parseAndSetCredentialsFromJson(jsonString: String): String? {
        try {
            val jsonObject = org.json.JSONObject(jsonString)
            var extractedClientId: String? = null

            if (jsonObject.has("web")) {
                extractedClientId = jsonObject.getJSONObject("web").optString("client_id")
            } else if (jsonObject.has("installed")) {
                extractedClientId = jsonObject.getJSONObject("installed").optString("client_id")
            } else if (jsonObject.has("client_id")) {
                extractedClientId = jsonObject.optString("client_id")
            } else if (jsonObject.has("client")) {
                val clientArr = jsonObject.getJSONArray("client")
                if (clientArr.length() > 0) {
                    val client0 = clientArr.getJSONObject(0)
                    if (client0.has("oauth_client")) {
                        val oauthArr = client0.getJSONArray("oauth_client")
                        if (oauthArr.length() > 0) {
                            extractedClientId = oauthArr.getJSONObject(0).optString("client_id")
                        }
                    }
                }
            }

            if (!extractedClientId.isNullOrEmpty()) {
                updateWebClientId(extractedClientId!!)
                return extractedClientId
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing client credentials JSON", e)
        }
        return null
    }

    private fun String?.isNull0orEmpty(): Boolean = this == null || this.isEmpty()

    init {
        val currentId = prefs.getString("web_client_id", "")
        if (currentId.isNullOrEmpty() || currentId.contains("c1opgcdf3hq5d8tfc5c0erh1n0851sck")) {
            updateWebClientId("983001449808-bs2e2i9nfoh8tm0jufsbh8799cf5n5cu.apps.googleusercontent.com")
        }
        loadLastSyncTime()
    }

    fun getSignInIntent(): Intent {
        return googleSignInClient.signInIntent
    }

    suspend fun handleSignInResult(data: Intent?) {
        syncStatus.value = SyncStatus.SIGNING_IN
        syncMessage.value = "Signing in with Google..."
        try {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            val account = task.getResult(Exception::class.java)
            if (account != null) {
                signInAccount.value = account
                syncStatus.value = SyncStatus.SUCCESS
                syncMessage.value = "Signed in as ${account.email}"
                // Immediately trigger initial sync
                sync(forceUpload = false)
            } else {
                syncStatus.value = SyncStatus.ERROR
                syncMessage.value = "Sign-in failed."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Google Sign-in failed", e)
            syncStatus.value = SyncStatus.ERROR
            val statusCode = (e as? com.google.android.gms.common.api.ApiException)?.statusCode ?: -1
            val errorMsg = e.message ?: e.localizedMessage ?: ""
            if (statusCode == 10 || errorMsg.contains("10")) {
                syncMessage.value = "Sign-in error 10 (Developer Configuration Required):\nGoogle Play Services requires registering this APK's SHA-1 certificate fingerprint and package name in Google Cloud Console. Use the instant Backup & Restore tools below to safely backup and transfer your ledger data across devices!"
            } else if (statusCode == 12500 || errorMsg.contains("12500")) {
                syncMessage.value = "Sign-in was cancelled or Google Play Services is missing or outdated."
            } else {
                syncMessage.value = "Sign-in failed (${if (statusCode != -1) "Code $statusCode" else errorMsg}). You can use Backup & Restore below to transfer your data."
            }
        }
    }

    suspend fun signOut(onComplete: () -> Unit = {}) {
        syncStatus.value = SyncStatus.SYNCING
        syncMessage.value = "Signing out..."
        withContext(Dispatchers.IO) {
            try {
                // Clear active token cache
                val account = signInAccount.value
                if (account != null) {
                    val token = fetchAccessToken(account)
                    if (token != null) {
                        GoogleAuthUtil.clearToken(context, token)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error clearing token", e)
            }
            
            googleSignInClient.signOut().addOnCompleteListener {
                signInAccount.value = null
                syncStatus.value = SyncStatus.IDLE
                syncMessage.value = "Signed out successfully"
                saveLastSyncTime(0L)
                onComplete()
            }
        }
    }

    private fun loadLastSyncTime() {
        val prefs = context.getSharedPreferences("sync_prefs", Context.MODE_PRIVATE)
        lastSyncTime.value = prefs.getLong("last_sync_time", 0L)
    }

    private fun saveLastSyncTime(time: Long) {
        lastSyncTime.value = time
        val prefs = context.getSharedPreferences("sync_prefs", Context.MODE_PRIVATE)
        prefs.edit().putLong("last_sync_time", time).apply()
    }

    // High level sync routine
    suspend fun sync(forceUpload: Boolean = false) {
        val account = signInAccount.value
        if (account == null) {
            syncStatus.value = SyncStatus.ERROR
            syncMessage.value = "Please sign in to Google first."
            return
        }

        syncStatus.value = SyncStatus.SYNCING
        syncMessage.value = "Connecting to Google Drive..."

        withContext(Dispatchers.IO) {
            try {
                val token = fetchAccessToken(account)
                if (token == null) {
                    syncStatus.value = SyncStatus.ERROR
                    syncMessage.value = "Failed to retrieve Google Auth token."
                    return@withContext
                }

                syncMessage.value = "Checking backup file..."
                val driveFileId = findBackupFileId(token)

                // Fetch local records
                val localCustomers = database.customerDao().getAllCustomersDirect()
                val localBills = database.billDao().getAllBillsDirect()
                val localPayments = database.paymentDao().getAllPaymentsDirect()
                
                val hasLocalData = localCustomers.isNotEmpty()

                if (driveFileId == null) {
                    // No remote backup exists
                    if (hasLocalData || forceUpload) {
                        syncMessage.value = "Creating new cloud backup..."
                        val backupPayload = BackupPayload(
                            lastUpdated = System.currentTimeMillis(),
                            customers = localCustomers,
                            bills = localBills,
                            payments = localPayments
                        )
                        createBackupFile(token, backupPayload)
                        saveLastSyncTime(System.currentTimeMillis())
                        syncStatus.value = SyncStatus.SUCCESS
                        syncMessage.value = "Cloud backup created successfully!"
                    } else {
                        // Empty local and empty remote
                        saveLastSyncTime(System.currentTimeMillis())
                        syncStatus.value = SyncStatus.SUCCESS
                        syncMessage.value = "No data to sync. Ready!"
                    }
                } else {
                    // Remote backup exists!
                    syncMessage.value = "Downloading cloud backup..."
                    val remotePayload = downloadBackupFile(token, driveFileId)
                    
                    if (remotePayload == null) {
                        syncStatus.value = SyncStatus.ERROR
                        syncMessage.value = "Could not parse Google Drive backup."
                        return@withContext
                    }

                    if (forceUpload) {
                        // Force overwrite cloud with local
                        syncMessage.value = "Overwriting cloud backup..."
                        val backupPayload = BackupPayload(
                            lastUpdated = System.currentTimeMillis(),
                            customers = localCustomers,
                            bills = localBills,
                            payments = localPayments
                        )
                        updateBackupFile(token, driveFileId, backupPayload)
                        saveLastSyncTime(System.currentTimeMillis())
                        syncStatus.value = SyncStatus.SUCCESS
                        syncMessage.value = "Backup uploaded successfully!"
                    } else {
                        // Auto-merge / conflict resolve:
                        // Decide whether to restore (remote is newer or local is empty) or upload (local is non-empty and has newer/more info)
                        val isLocalEmpty = !hasLocalData
                        val remoteIsNewer = remotePayload.lastUpdated > lastSyncTime.value
                        
                        if (isLocalEmpty || remoteIsNewer) {
                            // Restore from remote
                            syncMessage.value = "Restoring ledger from cloud..."
                            restoreBackupToLocal(remotePayload)
                            saveLastSyncTime(remotePayload.lastUpdated)
                            syncStatus.value = SyncStatus.SUCCESS
                            syncMessage.value = "Ledger synchronized from cloud!"
                        } else {
                            // Local is newer or we have modifications locally. Upload local.
                            syncMessage.value = "Updating cloud backup..."
                            val backupPayload = BackupPayload(
                                lastUpdated = System.currentTimeMillis(),
                                customers = localCustomers,
                                bills = localBills,
                                payments = localPayments
                            )
                            updateBackupFile(token, driveFileId, backupPayload)
                            saveLastSyncTime(System.currentTimeMillis())
                            syncStatus.value = SyncStatus.SUCCESS
                            syncMessage.value = "Backup synchronized to cloud!"
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Sync error", e)
                syncStatus.value = SyncStatus.ERROR
                syncMessage.value = "Sync error: ${e.localizedMessage ?: "Connection lost"}"
            }
        }
    }

    private suspend fun fetchAccessToken(account: GoogleSignInAccount): String? = withContext(Dispatchers.IO) {
        try {
            val scopes = "oauth2:https://www.googleapis.com/auth/drive.appdata https://www.googleapis.com/auth/userinfo.email https://www.googleapis.com/auth/userinfo.profile"
            GoogleAuthUtil.getToken(context, account.account ?: return@withContext null, scopes)
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching access token", e)
            null
        }
    }

    private fun findBackupFileId(token: String): String? {
        val url = "https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='$BACKUP_FILE_NAME' and trashed=false"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e(TAG, "Find files failed: ${response.code} ${response.message}")
                return null
            }
            val bodyStr = response.body?.string() ?: return null
            val json = JSONObject(bodyStr)
            val filesArray = json.optJSONArray("files")
            if (filesArray != null && filesArray.length() > 0) {
                return filesArray.getJSONObject(0).optString("id")
            }
        }
        return null
    }

    private fun downloadBackupFile(token: String, fileId: String): BackupPayload? {
        val url = "https://www.googleapis.com/drive/v3/files/$fileId?alt=media"
        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .get()
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e(TAG, "Download failed: ${response.code}")
                return null
            }
            val bodyStr = response.body?.string() ?: return null
            return try {
                val adapter = moshi.adapter(BackupPayload::class.java)
                adapter.fromJson(bodyStr)
            } catch (e: Exception) {
                Log.e(TAG, "JSON parsing error on download", e)
                null
            }
        }
    }

    private fun createBackupFile(token: String, payload: BackupPayload): Boolean {
        // 1. Create metadata
        val metadataUrl = "https://www.googleapis.com/drive/v3/files"
        val metaBody = JSONObject().apply {
            put("name", BACKUP_FILE_NAME)
            put("parents", org.json.JSONArray().put("appDataFolder"))
        }.toString()

        val metaRequest = Request.Builder()
            .url(metadataUrl)
            .header("Authorization", "Bearer $token")
            .post(metaBody.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(metaRequest).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e(TAG, "Meta creation failed: ${response.code}")
                return false
            }
            val bodyStr = response.body?.string() ?: return false
            val fileId = JSONObject(bodyStr).optString("id") ?: return false
            
            // 2. Upload media
            return updateBackupFile(token, fileId, payload)
        }
    }

    private fun updateBackupFile(token: String, fileId: String, payload: BackupPayload): Boolean {
        val url = "https://www.googleapis.com/upload/drive/v3/files/$fileId?uploadType=media"
        val adapter = moshi.adapter(BackupPayload::class.java)
        val jsonContent = adapter.toJson(payload)

        val request = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $token")
            .patch(jsonContent.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                Log.e(TAG, "Media update failed: ${response.code} ${response.message}")
                return false
            }
            return true
        }
    }

    private suspend fun restoreBackupToLocal(payload: BackupPayload) {
        withContext(Dispatchers.IO) {
            database.runInTransaction {
                // Clear local
                database.customerDao().clearAll() // cascades to bills and payments because of CASCADE foreign key rules!
                
                // Restore customers
                for (customer in payload.customers) {
                    database.customerDao().insertCustomerDirect(customer)
                }
                
                // Restore bills
                for (bill in payload.bills) {
                    database.billDao().insertBillDirect(bill)
                }
                
                // Restore payments
                for (payment in payload.payments) {
                    database.paymentDao().insertPaymentDirect(payment)
                }
            }
        }
    }

    suspend fun exportToJson(outputStream: java.io.OutputStream): Boolean = withContext(Dispatchers.IO) {
        try {
            val localCustomers = database.customerDao().getAllCustomersDirect()
            val localBills = database.billDao().getAllBillsDirect()
            val localPayments = database.paymentDao().getAllPaymentsDirect()

            val backupPayload = BackupPayload(
                lastUpdated = System.currentTimeMillis(),
                customers = localCustomers,
                bills = localBills,
                payments = localPayments
            )

            val adapter = moshi.adapter(BackupPayload::class.java)
            val jsonString = adapter.toJson(backupPayload)
            outputStream.use { stream ->
                stream.write(jsonString.toByteArray(Charsets.UTF_8))
                stream.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to export backup", e)
            false
        }
    }

    suspend fun importFromJson(inputStream: java.io.InputStream): Boolean = withContext(Dispatchers.IO) {
        try {
            val jsonString = inputStream.use { stream ->
                stream.bufferedReader(Charsets.UTF_8).readText()
            }
            val adapter = moshi.adapter(BackupPayload::class.java)
            val payload = adapter.fromJson(jsonString) ?: return@withContext false
            restoreBackupToLocal(payload)
            saveLastSyncTime(payload.lastUpdated)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to import backup", e)
            false
        }
    }
}

// Support data class for backup payload
data class BackupPayload(
    val lastUpdated: Long,
    val customers: List<Customer>,
    val bills: List<Bill>,
    val payments: List<Payment>
)
