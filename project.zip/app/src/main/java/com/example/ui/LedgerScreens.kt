package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.app.DatePickerDialog
import android.content.Context
import android.content.Intent
import kotlinx.coroutines.launch
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LedgerAppContent(viewModel: AppViewModel) {
    var currentTab by remember { mutableStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }
    
    // Dialog states
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var showAddBillDialog by remember { mutableStateOf(false) }
    var showAddPaymentDialog by remember { mutableStateOf(false) }
    var showSyncDialog by remember { mutableStateOf(false) }
    
    // Select context customer for pre-filling dialogs
    var selectedPreCustomer by remember { mutableStateOf<Customer?>(null) }
    
    // View active Customer Ledger Detail
    var activeLedgerCustomer by remember { mutableStateOf<Customer?>(null) }

    val accountState by viewModel.syncManager.signInAccount.collectAsState()

    Scaffold(
        topBar = {
            LargeTopAppBar(
                title = {
                    Text(
                        text = "GST Bill Ledger",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.SansSerif
                    )
                },
                actions = {
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(
                            imageVector = if (accountState != null) Icons.Default.CloudDone else Icons.Outlined.CloudSync,
                            contentDescription = "Google Account Sync",
                            tint = if (accountState != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = {
                        selectedPreCustomer = null
                        showAddCustomerDialog = true
                    }) {
                        Icon(
                            imageVector = Icons.Default.PersonAdd,
                            contentDescription = "Add Customer",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    scrolledContainerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            )
        },
        bottomBar = {
            val navItems = remember {
                listOf(
                    NavItemData("Dashboard", Icons.Outlined.Dashboard, Icons.Default.Dashboard),
                    NavItemData("Customers", Icons.Outlined.People, Icons.Default.People),
                    NavItemData("Bills", Icons.Outlined.ReceiptLong, Icons.Default.ReceiptLong),
                    NavItemData("Deposits", Icons.Outlined.Payment, Icons.Default.Payment)
                )
            }
            IosLiquidTubeNavBar(
                items = navItems,
                selectedTab = currentTab,
                onTabSelected = { currentTab = it }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { IosTabTransitionSpec },
                label = "IosTabTransition"
            ) { tab ->
                when (tab) {
                    0 -> DashboardScreen(
                        viewModel = viewModel,
                        searchQuery = searchQuery,
                        onSearchQueryChange = { searchQuery = it },
                        onCustomerClick = { customer -> activeLedgerCustomer = customer },
                        onAddBillClick = { customer ->
                            selectedPreCustomer = customer
                            showAddBillDialog = true
                        },
                        onAddPaymentClick = { customer ->
                            selectedPreCustomer = customer
                            showAddPaymentDialog = true
                        }
                    )
                    1 -> CustomersScreen(
                        viewModel = viewModel,
                        onCustomerClick = { customer -> activeLedgerCustomer = customer },
                        onAddCustomerClick = { showAddCustomerDialog = true },
                        onAddBill = { customer ->
                            selectedPreCustomer = customer
                            showAddBillDialog = true
                        },
                        onAddPayment = { customer ->
                            selectedPreCustomer = customer
                            showAddPaymentDialog = true
                        }
                    )
                    2 -> BillsScreen(
                        viewModel = viewModel,
                        onAddBillClick = {
                            selectedPreCustomer = null
                            showAddBillDialog = true
                        }
                    )
                    3 -> PaymentsScreen(
                        viewModel = viewModel,
                        onAddPaymentClick = {
                            selectedPreCustomer = null
                            showAddPaymentDialog = true
                        }
                    )
                }
            }
        }
    }

    // Customer Sheet/Details Ledger
    activeLedgerCustomer?.let { customer ->
        CustomerLedgerDetailsScreen(
            customer = customer,
            viewModel = viewModel,
            onDismiss = { activeLedgerCustomer = null },
            onAddBill = {
                selectedPreCustomer = customer
                showAddBillDialog = true
            },
            onAddPayment = {
                selectedPreCustomer = customer
                showAddPaymentDialog = true
            }
        )
    }

    // Add Customer Dialog
    if (showAddCustomerDialog) {
        AddCustomerDialog(
            viewModel = viewModel,
            onDismiss = { showAddCustomerDialog = false }
        )
    }

    // Add Bill Dialog
    if (showAddBillDialog) {
        AddBillDialog(
            viewModel = viewModel,
            preSelectedCustomer = selectedPreCustomer,
            onDismiss = {
                showAddBillDialog = false
                selectedPreCustomer = null
            }
        )
    }

    // Add Payment Dialog
    if (showAddPaymentDialog) {
        AddPaymentDialog(
            viewModel = viewModel,
            preSelectedCustomer = selectedPreCustomer,
            onDismiss = {
                showAddPaymentDialog = false
                selectedPreCustomer = null
            }
        )
    }

    // Google Cloud Sync Dialog
    if (showSyncDialog) {
        GoogleSyncDialog(
            viewModel = viewModel,
            onDismiss = { showSyncDialog = false }
        )
    }
}

@Composable
fun DashboardScreen(
    viewModel: AppViewModel,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    onCustomerClick: (Customer) -> Unit,
    onAddBillClick: (Customer) -> Unit,
    onAddPaymentClick: (Customer) -> Unit
) {
    val summaries by viewModel.customerSummaries.collectAsState()
    val totalOutstanding by viewModel.totalOutstandingAmount.collectAsState()
    val totalBilled by viewModel.totalBilledAmount.collectAsState()
    val totalCollected by viewModel.totalDepositedAmount.collectAsState()
    val totalCommissions by viewModel.totalCommissionAmount.collectAsState()

    val filteredSummaries = remember(summaries, searchQuery) {
        if (searchQuery.isBlank()) summaries
        else summaries.filter { it.customer.name.contains(searchQuery, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // KPI Overview Panel
        item {
            IosGlassCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(24.dp),
                elevation = 10.dp
            ) {
                Column(
                    modifier = Modifier.padding(4.dp)
                ) {
                    Text(
                        text = "Outstanding Receivable Summary",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = formatCurrency(totalOutstanding),
                        style = MaterialTheme.typography.displayMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (totalOutstanding > 0) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Total Billed",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Text(
                                text = formatCurrency(totalBilled),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Total Collected",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Text(
                                text = formatCurrency(totalCollected),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Commissions",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                            Text(
                                text = formatCurrency(totalCommissions),
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }

        // Search bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dashboard_search_input"),
                placeholder = { Text("Search customers...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedContainerColor = MaterialTheme.colorScheme.surface
                )
            )
        }

        // List Header label
        item {
            Text(
                text = "Outstanding Balances per Customer",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        // List of Customers
        if (filteredSummaries.isEmpty()) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Inventory,
                        contentDescription = "No customers found",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (searchQuery.isEmpty()) "No customers registered yet." else "No matching customer found.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
        } else {
            items(filteredSummaries, key = { it.customer.id }) { summary ->
                CustomerOutstandingCard(
                    summary = summary,
                    onCardClick = { onCustomerClick(summary.customer) },
                    onAddBill = { onAddBillClick(summary.customer) },
                    onAddPayment = { onAddPaymentClick(summary.customer) }
                )
            }
        }
        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun GoogleDriveSyncCard(viewModel: AppViewModel) {
    val account by viewModel.syncManager.signInAccount.collectAsState()
    val status by viewModel.syncManager.syncStatus.collectAsState()
    val message by viewModel.syncManager.syncMessage.collectAsState()
    val lastSync by viewModel.syncManager.lastSyncTime.collectAsState()
    
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        coroutineScope.launch {
            viewModel.syncManager.handleSignInResult(result.data)
        }
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp, 
            if (account != null) MaterialTheme.colorScheme.primary.copy(alpha = 0.3f) 
            else MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.CloudSync,
                    contentDescription = "Cloud Backup",
                    tint = if (account != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Automatic Cloud Sync",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (account != null) "Synchronized with harsh.shah090@gmail.com" else "Sync ledger data across your personal devices",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
                }
                
                if (account != null) {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                viewModel.syncManager.signOut()
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Logout,
                            contentDescription = "Disconnect Sync",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.6f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(12.dp))
            
            if (account == null) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "This app is configured to automatically synchronize database records with harsh.shah090@gmail.com Google Drive.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                    Button(
                        onClick = {
                            val intent = viewModel.syncManager.getSignInIntent()
                            launcher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Google Sync",
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Activate Auto-Sync",
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            } else {
                Surface(
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.8f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountCircle,
                                contentDescription = "Profile",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "harsh.shah090@gmail.com",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    text = "Connected Cloud Ledger",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                        
                        Divider(
                            modifier = Modifier.padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f)
                        )
                        
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = when (status) {
                                        SyncStatus.SYNCING -> "Status: Syncing..."
                                        SyncStatus.SUCCESS -> "Status: Synced"
                                        SyncStatus.ERROR -> "Status: Sync Failed"
                                        else -> "Status: Connected"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.SemiBold,
                                    color = when (status) {
                                        SyncStatus.SYNCING -> MaterialTheme.colorScheme.primary
                                        SyncStatus.ERROR -> MaterialTheme.colorScheme.error
                                        else -> Color(0xFF2E7D32)
                                    }
                                )
                                Text(
                                    text = if (lastSync > 0L) "Last Synced: ${formatLastSyncTime(lastSync)}" else "Last Synced: Never",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                                )
                            }
                            
                            Button(
                                onClick = {
                                    coroutineScope.launch {
                                        viewModel.syncManager.sync()
                                    }
                                },
                                enabled = status != SyncStatus.SYNCING,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            ) {
                                if (status == SyncStatus.SYNCING) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Sync,
                                        contentDescription = "Sync Now",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sync Now", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                        
                        if (message.isNotEmpty() && status == SyncStatus.ERROR) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

fun formatLastSyncTime(timestamp: Long): String {
    val diff = System.currentTimeMillis() - timestamp
    return when {
        diff < 60000 -> "Just now"
        diff < 3600000 -> "${diff / 60000}m ago"
        diff < 86400000 -> "${diff / 3600000}h ago"
        else -> {
            val sdf = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
            sdf.format(Date(timestamp))
        }
    }
}

@Composable
fun CustomerOutstandingCard(
    summary: CustomerSummary,
    onCardClick: () -> Unit,
    onAddBill: () -> Unit,
    onAddPayment: () -> Unit
) {
    IosGlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("customer_outstanding_card_${summary.customer.id}"),
        shape = RoundedCornerShape(22.dp),
        elevation = 6.dp,
        onClick = onCardClick
    ) {
        Column(
            modifier = Modifier.padding(2.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = summary.customer.name,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (summary.customer.phone.isNotEmpty()) {
                        Text(
                            text = summary.customer.phone,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }

                // Balance display
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = getBalanceBackgroundColor(summary.outstandingBalance),
                    contentColor = getBalanceTextColor(summary.outstandingBalance)
                ) {
                    Text(
                        text = formatCurrency(summary.outstandingBalance),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
            Spacer(modifier = Modifier.height(12.dp))

            // Stats view
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Receipt,
                            contentDescription = "Bills check",
                            modifier = Modifier.size(14.dp),
                            tint = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Billed: ${formatCurrency(summary.totalBilled)} (${summary.billCount})",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Payment,
                            contentDescription = "Payments check",
                            modifier = Modifier.size(14.dp),
                            tint = Color(0xFF2E7D32)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Paid: ${formatCurrency(summary.totalPaid)} (${summary.paymentCount})",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                // Row of shortcut action buttons
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedButton(
                        onClick = onAddBill,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.testTag("customer_outstanding_bill_button_${summary.customer.id}")
                    ) {
                        Icon(
                            Icons.Default.Add,
                            contentDescription = "New Bill icon",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Bill", fontSize = 12.sp)
                    }

                    ElevatedButton(
                        onClick = onAddPayment,
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer,
                            contentColor = MaterialTheme.colorScheme.onTertiaryContainer
                        ),
                        modifier = Modifier.testTag("customer_outstanding_payment_button_${summary.customer.id}")
                    ) {
                        Icon(
                            Icons.Default.AttachMoney,
                            contentDescription = "Record Cash icon",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Pay", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomersScreen(
    viewModel: AppViewModel,
    onCustomerClick: (Customer) -> Unit,
    onAddCustomerClick: () -> Unit,
    onAddBill: (Customer) -> Unit,
    onAddPayment: (Customer) -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val summaries by viewModel.customerSummaries.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Our Active Customers",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = onAddCustomerClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("New")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (customers.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 80.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.AccountCircle,
                            contentDescription = "no content",
                            modifier = Modifier.size(80.dp),
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "You don't have any customers yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(onClick = onAddCustomerClick) {
                            Text("Register Customer First")
                        }
                    }
                }
            } else {
                items(customers, key = { it.id }) { customer ->
                    val summary = summaries.find { it.customer.id == customer.id }
                    val outstanding = summary?.outstandingBalance ?: 0.0

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onCustomerClick(customer) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = customer.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                if (customer.phone.isNotEmpty()) {
                                    Text(
                                        text = customer.phone,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                                if (customer.email.isNotEmpty()) {
                                    Text(
                                        text = customer.email,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                }
                            }

                            Column(
                                horizontalAlignment = Alignment.End
                            ) {
                                Text(
                                    text = "Outstanding",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text(
                                    text = formatCurrency(outstanding),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (outstanding > 0) Color(0xFFD32F2F) else Color(0xFF1B5E20)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    IconButton(
                                        onClick = { onAddBill(customer) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Receipt,
                                            contentDescription = "Invoice creator",
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onAddPayment(customer) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Payment,
                                            contentDescription = "Payment Collector",
                                            tint = Color(0xFF2E7D32),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun BillsScreen(
    viewModel: AppViewModel,
    onAddBillClick: () -> Unit
) {
    val bills by viewModel.bills.collectAsState()
    val customers by viewModel.customers.collectAsState()
    var billToDelete by remember { mutableStateOf<Bill?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Generated Bills & GST",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = onAddBillClick,
                        shape = RoundedCornerShape(8.dp),
                        enabled = customers.isNotEmpty()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Bill")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Bill")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (bills.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 80.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Description,
                            contentDescription = "No generated bills yet",
                            modifier = Modifier.size(80.dp),
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (customers.isEmpty()) "Register a customer to add bills." else "No bills generated yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                items(bills, key = { it.id }) { bill ->
                    val customer = customers.find { it.id == bill.customerId }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = bill.billName,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = customer?.name ?: "Unknown Customer",
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                Text(
                                    text = viewModel.formatDate(bill.date),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { billToDelete = bill },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete Bill",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.08f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        "Base: ${formatCurrency(bill.baseAmount)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "GST (${bill.gstPercentage}%): ${formatCurrency(bill.gstAmount)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        "Comm (${bill.commissionRate}%): ${formatCurrency(bill.commissionAmount)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                                Column(
                                    horizontalAlignment = Alignment.End,
                                    modifier = Modifier.align(Alignment.Bottom)
                                ) {
                                    Text(
                                        text = "Total Billing",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.outline
                                    )
                                    Text(
                                        text = formatCurrency(bill.totalAmount),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (billToDelete != null) {
        IosGlassDialog(
            onDismissRequest = { billToDelete = null }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Delete Bill Confirmation",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Are you sure you want to permanently delete this bill? This action will reverse the entry in customer's outstanding balances.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { billToDelete = null },
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            billToDelete?.let { viewModel.deleteBill(it) }
                            billToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Delete")
                    }
                }
            }
        }
    }
}

@Composable
fun PaymentsScreen(
    viewModel: AppViewModel,
    onAddPaymentClick: () -> Unit
) {
    val payments by viewModel.payments.collectAsState()
    val customers by viewModel.customers.collectAsState()
    var paymentToDelete by remember { mutableStateOf<Payment?>(null) }

    Box(modifier = Modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Deposits & Received Payments",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Button(
                        onClick = onAddPaymentClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        enabled = customers.isNotEmpty()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Record Deposit")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Payment")
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            if (payments.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 80.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.AccountBalanceWallet,
                            contentDescription = "No payments recorded yet",
                            modifier = Modifier.size(80.dp),
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = if (customers.isEmpty()) "Register a customer to record payments." else "No payments recorded yet.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            } else {
                items(payments, key = { it.id }) { payment ->
                    val customer = customers.find { it.id == payment.customerId }

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = customer?.name ?: "Unknown Customer",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B5E20)
                                )
                                if (payment.note.isNotEmpty()) {
                                    Text(
                                        text = "Note: ${payment.note}",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color(0xFF2E7D32)
                                    )
                                }
                                Text(
                                    text = viewModel.formatDate(payment.date),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color(0xFF4CAF50)
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "-${formatCurrency(payment.amount)}",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B5E20)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { paymentToDelete = payment },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete Deposit Entry",
                                        tint = MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (paymentToDelete != null) {
        IosGlassDialog(
            onDismissRequest = { paymentToDelete = null }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Delete Payment Entry",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Are you sure you want to permanently delete this deposited payment record? Outstanding balance will be recalculated accordingly.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { paymentToDelete = null },
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            paymentToDelete?.let { viewModel.deletePayment(it) }
                            paymentToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Delete")
                    }
                }
            }
        }
    }
}

// Dialogs and Sheets Components

@Composable
fun AddCustomerDialog(
    viewModel: AppViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var openingBalanceStr by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "New Customer Registration",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *") },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        keyboardType = KeyboardType.Text
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = openingBalanceStr,
                    onValueChange = { openingBalanceStr = it },
                    label = { Text("Opening Balance (Outstanding)") },
                    placeholder = { Text("e.g. 500.00 (Customer owes you)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val openingBal = openingBalanceStr.toDoubleOrNull() ?: 0.0
                        viewModel.addCustomer(
                            name = name.trim(),
                            phone = phone.trim(),
                            email = email.trim(),
                            openingBalance = openingBal,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Register")
                }
            }
        }
    }
}

@Composable
fun EditCustomerDialog(
    customer: Customer,
    viewModel: AppViewModel,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(customer.name) }
    var phone by remember { mutableStateOf(customer.phone) }
    var email by remember { mutableStateOf(customer.email) }
    var openingBalanceStr by remember { mutableStateOf(customer.openingBalance.toString()) }
    var errorMessage by remember { mutableStateOf("") }

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Edit Customer Details",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *") },
                    keyboardOptions = KeyboardOptions(
                        capitalization = KeyboardCapitalization.Words,
                        keyboardType = KeyboardType.Text
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = openingBalanceStr,
                    onValueChange = { openingBalanceStr = it },
                    label = { Text("Opening Balance (Outstanding)") },
                    placeholder = { Text("e.g. 500.00 (Customer owes you)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val openingBal = openingBalanceStr.toDoubleOrNull() ?: 0.0
                        val updatedCustomer = customer.copy(
                            name = name.trim(),
                            phone = phone.trim(),
                            email = email.trim(),
                            openingBalance = openingBal
                        )
                        viewModel.updateCustomer(
                            customer = updatedCustomer,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Save")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddBillDialog(
    viewModel: AppViewModel,
    preSelectedCustomer: Customer?,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val bills by viewModel.bills.collectAsState()
    
    var selectedCustomer by remember { mutableStateOf(preSelectedCustomer ?: customers.firstOrNull()) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    
    var billName by remember { mutableStateOf("") }
    var baseAmountStr by remember { mutableStateOf("") }
    var gstTier by remember { mutableStateOf(12) } // default tier 12%
    var customCommissionStr by remember { mutableStateOf((viewModel.commissionDefaults[12] ?: 2.5).toString()) }

    var selectedDate by remember { mutableStateOf(System.currentTimeMillis()) }
    val formattedDate = viewModel.formatDate(selectedDate)
    val context = LocalContext.current
    var errorMessage by remember { mutableStateOf("") }
    val customerPaid = false

    // Aggregate previously used bill names from ALL bills in the app
    val allPreviousNames = remember(bills) {
        bills.map { it.billName }.distinct().filter { it.isNotBlank() }
    }

    // Live computations
    val baseAmount = baseAmountStr.toDoubleOrNull() ?: 0.0
    val gstRate = gstTier.toDouble()
    val commissionRate = customCommissionStr.toDoubleOrNull() ?: 0.0
    
    val calculatedGst = baseAmount * (gstRate / 100.0)
    val calculatedComm = baseAmount * (commissionRate / 100.0)
    val totalCalculated = baseAmount + calculatedGst + calculatedComm

    val companyAmount = baseAmount + calculatedGst
    val amountGivenToCustomer = baseAmount + calculatedGst
    val amountPaidToCompany = baseAmount + calculatedGst

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Generate New Bill",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
            ) {
                if (errorMessage.isNotEmpty()) {
                    item {
                        Text(
                            text = errorMessage,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                // Customer Selection
                item {
                    if (preSelectedCustomer != null) {
                        OutlinedTextField(
                            value = preSelectedCustomer.name,
                            onValueChange = {},
                            label = { Text("Selected Customer") },
                            enabled = false,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        ExposedDropdownMenuBox(
                            expanded = dropdownExpanded,
                            onExpandedChange = { dropdownExpanded = it }
                        ) {
                            OutlinedTextField(
                                value = selectedCustomer?.name ?: "Select Customer",
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Select Customer *") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor()
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = dropdownExpanded,
                                onDismissRequest = { dropdownExpanded = false }
                            ) {
                                customers.forEach { cust ->
                                    DropdownMenuItem(
                                        text = { Text(cust.name) },
                                        onClick = {
                                            selectedCustomer = cust
                                            dropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Bill Name input (autocomplete dropdown of created bill names)
                item {
                    var nameDropdownExpanded by remember { mutableStateOf(false) }
                    val filteredNames = remember(allPreviousNames, billName) {
                        if (billName.isEmpty()) allPreviousNames
                        else allPreviousNames.filter { it.contains(billName, ignoreCase = true) }
                    }

                    ExposedDropdownMenuBox(
                        expanded = nameDropdownExpanded,
                        onExpandedChange = { nameDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = billName,
                            onValueChange = { newValue ->
                                billName = newValue
                                nameDropdownExpanded = true
                                // Search if there's any matching previous bill name to auto populate GST & commission rate
                                val matched = bills.find { it.billName.trim().equals(newValue.trim(), ignoreCase = true) }
                                if (matched != null) {
                                    gstTier = matched.gstPercentage
                                    customCommissionStr = matched.commissionRate.toString()
                                }
                            },
                            label = { Text("Name *") },
                            placeholder = { Text("Enter or select bill name") },
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Text
                            ),
                            singleLine = true,
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .onFocusChanged { focusState ->
                                    if (focusState.isFocused) {
                                        nameDropdownExpanded = true
                                    }
                                }
                        )

                        if (filteredNames.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = nameDropdownExpanded,
                                onDismissRequest = { nameDropdownExpanded = false }
                            ) {
                                filteredNames.forEach { name ->
                                    DropdownMenuItem(
                                        text = { Text(name) },
                                        onClick = {
                                            billName = name
                                            nameDropdownExpanded = false
                                            // Auto-populate GST & Commission rate
                                            val matched = bills.find { it.billName.trim().equals(name.trim(), ignoreCase = true) }
                                            if (matched != null) {
                                                gstTier = matched.gstPercentage
                                                customCommissionStr = matched.commissionRate.toString()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Base amount pre-tax
                item {
                    OutlinedTextField(
                        value = baseAmountStr,
                        onValueChange = { baseAmountStr = it },
                        label = { Text("Base Pre-Tax Amount *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        placeholder = { Text("0.00") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // GST percentage Selection
                item {
                    Text(
                        text = "GST Percentage Tier",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0, 5, 12, 18).forEach { percentage ->
                            ElevatedFilterChip(
                                selected = gstTier == percentage,
                                onClick = {
                                    gstTier = percentage
                                    val defaultRate = viewModel.commissionDefaults[percentage] ?: 0.0
                                    customCommissionStr = defaultRate.toString()
                                },
                                label = { Text("$percentage%") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Commission percentage input
                item {
                    OutlinedTextField(
                        value = customCommissionStr,
                        onValueChange = { customCommissionStr = it },
                        label = { Text("Commission Rate (%) for $gstTier% Tier") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        placeholder = { Text("0.0") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }



                // Date Picker
                item {
                    OutlinedTextField(
                        value = formattedDate,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Bill Generation Date") },
                        trailingIcon = {
                            IconButton(onClick = {
                                showNativeDatePicker(context, selectedDate) { dateMs ->
                                    selectedDate = dateMs
                                }
                            }) {
                                Icon(Icons.Default.DateRange, contentDescription = "Pick Date")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Live calculation Summary Box
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                "Live Invoice Calculations:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Base Amount:")
                                Text(formatCurrency(baseAmount))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("GST Amount ($gstTier%):")
                                Text("+ " + formatCurrency(calculatedGst))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Commission Amount ($commissionRate%):")
                                Text("+ " + formatCurrency(calculatedComm))
                            }
                            Divider(
                                modifier = Modifier.padding(vertical = 6.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (commissionRate == 0.0) "Customer Owed Amount (Base+GST):" else "Company Bill Amount (Base+GST):",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    formatCurrency(companyAmount),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val customer = selectedCustomer
                        if (customer == null) {
                            errorMessage = "Please select or register a customer."
                            return@Button
                        }
                        val amt = baseAmountStr.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            errorMessage = "Please enter valid pre-tax dollar amount greater than 0."
                            return@Button
                        }
                        val commRate = customCommissionStr.toDoubleOrNull() ?: 0.0

                        viewModel.addBill(
                            customerId = customer.id,
                            billName = billName.trim(),
                            baseAmount = amt,
                            gstPercent = gstTier,
                            commissionRate = commRate,
                            amountGivenToCustomer = amountGivenToCustomer,
                            amountPaidToCompany = amountPaidToCompany,
                            date = selectedDate,
                            customerPaid = false,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Generate")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPaymentDialog(
    viewModel: AppViewModel,
    preSelectedCustomer: Customer?,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    
    var selectedCustomer by remember { mutableStateOf(preSelectedCustomer ?: customers.firstOrNull()) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    
    var amountStr by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var selectedDate by remember { mutableStateOf(System.currentTimeMillis()) }
    val formattedDate = viewModel.formatDate(selectedDate)
    val context = LocalContext.current
    var errorMessage by remember { mutableStateOf("") }
    var isGivenToCustomer by remember { mutableStateOf(false) }

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isGivenToCustomer) "Record Payment Given to Customer" else "Record Received Payment",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                // Payment Direction Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedFilterChip(
                        selected = !isGivenToCustomer,
                        onClick = { isGivenToCustomer = false },
                        label = { Text("Customer to Company", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    ElevatedFilterChip(
                        selected = isGivenToCustomer,
                        onClick = { isGivenToCustomer = true },
                        label = { Text("Given to Customer", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Customer selection
                if (preSelectedCustomer != null) {
                    OutlinedTextField(
                        value = preSelectedCustomer.name,
                        onValueChange = {},
                        label = { Text("Selected Customer") },
                        enabled = false,
                        modifier = Modifier.fillMaxWidth()
                    )
                } else {
                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCustomer?.name ?: "Select Customer",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Select Customer *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = { Text(cust.name) },
                                    onClick = {
                                        selectedCustomer = cust
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Payment amount
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text(if (isGivenToCustomer) "Amount Given (Payout) *" else "Amount Received (Deposit) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("0.00") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Date Picker
                OutlinedTextField(
                    value = formattedDate,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Payment Date") },
                    trailingIcon = {
                        IconButton(onClick = {
                            showNativeDatePicker(context, selectedDate) { dateMs ->
                                selectedDate = dateMs
                            }
                        }) {
                            Icon(Icons.Default.DateRange, contentDescription = "Pick Date")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Transaction Details / Notes") },
                    placeholder = { Text("e.g. Cash, GPay, Cheque #20311") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val customer = selectedCustomer
                        if (customer == null) {
                            errorMessage = "Please select a customer."
                            return@Button
                        }
                        val amt = amountStr.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            errorMessage = "Please enter valid payment format greater than 0."
                            return@Button
                        }

                        viewModel.addPayment(
                            customerId = customer.id,
                            amount = amt,
                            date = selectedDate,
                            note = note.trim(),
                            isGivenToCustomer = isGivenToCustomer,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isGivenToCustomer) MaterialTheme.colorScheme.error else Color(0xFF2E7D32)),
                    modifier = Modifier.iosTapScale()
                ) {
                    Text(if (isGivenToCustomer) "Record Given" else "Record Receipt")
                }
            }
        }
    }
}

// Full Customer Ledger Statement BottomSheet Screen
@Composable
fun CustomerLedgerDetailsScreen(
    customer: Customer,
    viewModel: AppViewModel,
    onDismiss: () -> Unit,
    onAddBill: () -> Unit,
    onAddPayment: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val bills by viewModel.bills.collectAsState()
    val payments by viewModel.payments.collectAsState()
    val summaries by viewModel.customerSummaries.collectAsState()
    val context = LocalContext.current

    val currentCustomer = remember(customers, customer) {
        customers.find { it.id == customer.id } ?: customer
    }

    val customerBills = remember(bills, currentCustomer) {
        bills.filter { it.customerId == currentCustomer.id }
    }
    val customerPayments = remember(payments, currentCustomer) {
        payments.filter { it.customerId == currentCustomer.id }
    }
    val summary = remember(summaries, currentCustomer) {
        summaries.find { it.customer.id == currentCustomer.id }
    }

    // Combine into timeline ledger entries (sorted desc with date)
    val ledgerTimeline = remember(customerBills, customerPayments) {
        val list = mutableListOf<LedgerItem>()
        customerBills.forEach {
            list.add(LedgerItem.BillEntry(it))
        }
        customerPayments.forEach {
            list.add(LedgerItem.PaymentEntry(it))
        }
        list.sortedByDescending { it.date }
    }

    var transactionToDelete by remember { mutableStateOf<LedgerItem?>(null) }
    var editingBill by remember { mutableStateOf<Bill?>(null) }
    var editingPayment by remember { mutableStateOf<Payment?>(null) }
    var editingCustomer by remember { mutableStateOf<Customer?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 10.dp, vertical = 20.dp)
                .liquidGlass(
                    shape = RoundedCornerShape(28.dp),
                    elevation = 16.dp,
                    isOpaque = true
                ),
            color = Color.Transparent
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Toolbar headers
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "Customer Ledger",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.weight(1f)
                    )
                    Row {
                        IconButton(onClick = {
                            PdfReportGenerator.generateAndSharePdf(context, currentCustomer, ledgerTimeline, summary?.outstandingBalance ?: 0.0)
                        }) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "Export PDF",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = {
                            shareCustomerStatement(context, currentCustomer, ledgerTimeline, summary?.outstandingBalance ?: 0.0)
                        }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "Share",
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Profile Box & Outstanding balance
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = currentCustomer.name,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { editingCustomer = currentCustomer },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = "Edit Customer",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        if (currentCustomer.phone.isNotEmpty()) {
                            Text("Phone: ${currentCustomer.phone}", style = MaterialTheme.typography.bodyMedium)
                        }
                        if (currentCustomer.email.isNotEmpty()) {
                            Text("Email: ${currentCustomer.email}", style = MaterialTheme.typography.bodyMedium)
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.1f))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Outstanding Balance",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Text(
                                    text = formatCurrency(summary?.outstandingBalance ?: 0.0),
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if ((summary?.outstandingBalance ?: 0.0) > 0) Color(0xFFD32F2F) else Color(0xFF2E7D32)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Total Billed: ${formatCurrency(summary?.totalBilled ?: 0.0)}", style = MaterialTheme.typography.bodySmall)
                                Text("Total Paid: ${formatCurrency(summary?.totalPaid ?: 0.0)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = {
                                PdfReportGenerator.generateAndSharePdf(context, currentCustomer, ledgerTimeline, summary?.outstandingBalance ?: 0.0)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "Download PDF Report",
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Download PDF Report", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Quick Action bars inside dialog
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            onDismiss() // Close first
                            onAddBill() // Open creator
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Bill")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Bill", fontSize = 13.sp)
                    }

                    Button(
                        onClick = {
                            onDismiss()
                            onAddPayment()
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.AttachMoney, contentDescription = "Add Payment")
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Record Pay", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "Transaction History Ledger",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Transaction timeline list
                if (ledgerTimeline.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No ledger entries generated yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ledgerTimeline) { item ->
                            when (item) {
                                is LedgerItem.BillEntry -> {
                                    LedgerBillItemRow(
                                        bill = item.bill,
                                        dateStr = viewModel.formatDate(item.date),
                                        onDelete = { transactionToDelete = item },
                                        onClick = { editingBill = item.bill }
                                    )
                                }
                                is LedgerItem.PaymentEntry -> {
                                    LedgerPaymentItemRow(
                                        payment = item.payment,
                                        dateStr = viewModel.formatDate(item.date),
                                        onDelete = { transactionToDelete = item },
                                        onClick = { editingPayment = item.payment }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (transactionToDelete != null) {
        val isBill = transactionToDelete is LedgerItem.BillEntry
        IosGlassDialog(
            onDismissRequest = { transactionToDelete = null }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (isBill) "Delete Bill Entry" else "Delete Payment Entry",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Confirming deletion will recalculate outstanding balance. This action cannot be undone.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = { transactionToDelete = null },
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val toDel = transactionToDelete
                            if (toDel is LedgerItem.BillEntry) {
                                viewModel.deleteBill(toDel.bill)
                            } else if (toDel is LedgerItem.PaymentEntry) {
                                viewModel.deletePayment(toDel.payment)
                            }
                            transactionToDelete = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Delete")
                    }
                }
            }
        }
    }

    if (editingBill != null) {
        EditBillDialog(
            viewModel = viewModel,
            bill = editingBill!!,
            onDismiss = { editingBill = null }
        )
    }

    if (editingPayment != null) {
        EditPaymentDialog(
            viewModel = viewModel,
            payment = editingPayment!!,
            onDismiss = { editingPayment = null }
        )
    }

    if (editingCustomer != null) {
        EditCustomerDialog(
            customer = editingCustomer!!,
            viewModel = viewModel,
            onDismiss = { editingCustomer = null }
        )
    }
}

sealed class LedgerItem(val date: Long) {
    data class BillEntry(val bill: Bill) : LedgerItem(bill.date)
    data class PaymentEntry(val payment: Payment) : LedgerItem(payment.date)
}

@Composable
fun LedgerBillItemRow(
    bill: Bill,
    dateStr: String,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            "BILL",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    Text(
                        text = bill.billName,
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Base: ${formatCurrency(bill.baseAmount)} | GST (${bill.gstPercentage}%): ${formatCurrency(bill.gstAmount)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.outline
                )
                Text(
                    text = "Commission (${bill.commissionRate}%): ${formatCurrency(bill.commissionAmount)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Medium
                )
                if (bill.commissionRate == 0.0) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Text(
                            text = "Owed by Customer",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                } else if (bill.amountGivenToCustomer != 0.0 || bill.amountPaidToCompany != 0.0) {
                    Text(
                        text = "Given: ${formatCurrency(bill.amountGivenToCustomer)} | Paid Co: ${formatCurrency(bill.amountPaidToCompany)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.outline.copy(alpha = 0.8f)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "+${formatCurrency(bill.totalAmount)}",
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete entry",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun LedgerPaymentItemRow(
    payment: Payment,
    dateStr: String,
    onDelete: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (payment.isGivenToCustomer) Color(0xFFFFEBEE) else Color(0xFFF1F8E9)
        ),
        modifier = Modifier.clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        color = if (payment.isGivenToCustomer) Color(0xFFFFCDD2) else Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            if (payment.isGivenToCustomer) "GIVEN / OUT" else "PAID / DEP",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (payment.isGivenToCustomer) Color(0xFFB71C1C) else Color(0xFF1B5E20),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                    if (payment.note.isNotEmpty()) {
                        Text(
                            text = payment.note,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (payment.isGivenToCustomer) Color(0xFFB71C1C) else Color(0xFF1B5E20)
                        )
                    } else {
                        Text(
                            text = if (payment.isGivenToCustomer) "Amount Given" else "Deposit Receipt",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (payment.isGivenToCustomer) Color(0xFFB71C1C) else Color(0xFF1B5E20)
                        )
                    }
                }
                Text(
                    text = dateStr,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (payment.isGivenToCustomer) Color(0xFFEF5350) else Color(0xFF4CAF50)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = if (payment.isGivenToCustomer) "+${formatCurrency(payment.amount)}" else "-${formatCurrency(payment.amount)}",
                    fontWeight = FontWeight.Bold,
                    color = if (payment.isGivenToCustomer) Color(0xFFB71C1C) else Color(0xFF1B5E20),
                    style = MaterialTheme.typography.bodyLarge
                )
                Spacer(modifier = Modifier.width(4.dp))
                IconButton(onClick = onDelete, modifier = Modifier.size(24.dp)) {
                    Icon(
                        Icons.Default.Delete,
                        contentDescription = "Delete deposit",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

// Helpers
fun formatCurrency(amount: Double): String {
    return try {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.format(amount)
    } catch (e: Exception) {
        val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
        "₹" + formatter.format(amount)
    }
}

fun getBalanceBackgroundColor(balance: Double): Color {
    return when {
        balance > 0 -> Color(0xFFFFEBEE)
        balance == 0.0 -> Color(0xFFF1F8E9)
        else -> Color(0xFFE8F5E9)
    }
}

fun getBalanceTextColor(balance: Double): Color {
    return when {
        balance > 0 -> Color(0xFFC62828)
        balance == 0.0 -> Color(0xFF558B2F)
        else -> Color(0xFF2E7D32)
    }
}

fun showNativeDatePicker(context: Context, currentMs: Long, onDateSelected: (Long) -> Unit) {
    val calendar = Calendar.getInstance().apply { timeInMillis = currentMs }
    val year = calendar.get(Calendar.YEAR)
    val month = calendar.get(Calendar.MONTH)
    val day = calendar.get(Calendar.DAY_OF_MONTH)

    DatePickerDialog(
        context,
        { _, selYear, selMonth, selDay ->
            val resultCal = Calendar.getInstance().apply {
                set(Calendar.YEAR, selYear)
                set(Calendar.MONTH, selMonth)
                set(Calendar.DAY_OF_MONTH, selDay)
            }
            onDateSelected(resultCal.timeInMillis)
        },
        year,
        month,
        day
    ).show()
}

fun shareCustomerStatement(
    context: Context,
    customer: Customer,
    timeline: List<LedgerItem>,
    outstanding: Double
) {
    val sdf = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
    val statement = StringBuilder()
    statement.append("❖ LEDGER STATEMENT: ${customer.name} ❖\n")
    if (customer.phone.isNotEmpty()) statement.append("Phone: ${customer.phone}\n")
    if (customer.email.isNotEmpty()) statement.append("Email: ${customer.email}\n")
    statement.append("-------------------------------------------\n")
    statement.append("OUTSTANDING BALANCE: ${formatCurrency(outstanding)}\n")
    statement.append("-------------------------------------------\n\n")
    statement.append("TRANSACTION HISTORY:\n")

    timeline.forEach { item ->
        val dateStr = sdf.format(Date(item.date))
        when (item) {
            is LedgerItem.BillEntry -> {
                val b = item.bill
                statement.append("• [$dateStr] Bill: ${b.billName}\n")
                statement.append("  Base: ${formatCurrency(b.baseAmount)} | GST (${b.gstPercentage}%): ${formatCurrency(b.gstAmount)}\n")
                statement.append("  Comm (${b.commissionRate}%): ${formatCurrency(b.commissionAmount)}\n")
                statement.append("  Total Added: +${formatCurrency(b.totalAmount)}\n")
            }
            is LedgerItem.PaymentEntry -> {
                val p = item.payment
                val noteStr = if (p.note.isNotEmpty()) " (${p.note})" else ""
                statement.append("• [$dateStr] Payment Received$noteStr\n")
                statement.append("  Amount Deposited: -${formatCurrency(p.amount)}\n")
            }
        }
        statement.append("\n")
    }
    statement.append("Generated via GST Bill Ledger App.")

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Ledger Statement for ${customer.name}")
        putExtra(Intent.EXTRA_TEXT, statement.toString())
    }
    
    context.startActivity(Intent.createChooser(intent, "Share Ledger via"))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditBillDialog(
    viewModel: AppViewModel,
    bill: Bill,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    val bills by viewModel.bills.collectAsState()
    
    var selectedCustomer by remember { mutableStateOf(customers.find { it.id == bill.customerId } ?: customers.firstOrNull()) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    
    var billName by remember { mutableStateOf(bill.billName) }
    var baseAmountStr by remember { mutableStateOf(bill.baseAmount.toString()) }
    var gstTier by remember { mutableStateOf(bill.gstPercentage) }
    var customCommissionStr by remember { mutableStateOf(bill.commissionRate.toString()) }

    var selectedDate by remember { mutableStateOf(bill.date) }
    val formattedDate = viewModel.formatDate(selectedDate)
    val context = LocalContext.current
    var errorMessage by remember { mutableStateOf("") }
    val customerPaid = false

    // Aggregate previously used bill names from ALL bills in the app
    val allPreviousNames = remember(bills) {
        bills.map { it.billName }.distinct().filter { it.isNotBlank() }
    }

    // Live computations
    val baseAmount = baseAmountStr.toDoubleOrNull() ?: 0.0
    val gstRate = gstTier.toDouble()
    val commissionRate = customCommissionStr.toDoubleOrNull() ?: 0.0
    
    val calculatedGst = baseAmount * (gstRate / 100.0)
    val calculatedComm = baseAmount * (commissionRate / 100.0)
    val totalCalculated = baseAmount + calculatedGst + calculatedComm

    val companyAmount = baseAmount + calculatedGst
    val amountGivenToCustomer = baseAmount + calculatedGst
    val amountPaidToCompany = baseAmount + calculatedGst

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Edit Bill Entry",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f, fill = false)
            ) {
                if (errorMessage.isNotEmpty()) {
                    item {
                        Text(
                            text = errorMessage,
                            color = MaterialTheme.colorScheme.error,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }

                // Customer selection
                item {
                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedCustomer?.name ?: "Select Customer",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Customer *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = { Text(cust.name) },
                                    onClick = {
                                        selectedCustomer = cust
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Bill Name input (autocomplete dropdown of created bill names)
                item {
                    var nameDropdownExpanded by remember { mutableStateOf(false) }
                    val filteredNames = remember(allPreviousNames, billName) {
                        if (billName.isEmpty()) allPreviousNames
                        else allPreviousNames.filter { it.contains(billName, ignoreCase = true) }
                    }

                    ExposedDropdownMenuBox(
                        expanded = nameDropdownExpanded,
                        onExpandedChange = { nameDropdownExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = billName,
                            onValueChange = {
                                billName = it
                                nameDropdownExpanded = true
                            },
                            label = { Text("Bill name / Particulars *") },
                            placeholder = { Text("e.g. Rice Batch 3, Wheat Box") },
                            keyboardOptions = KeyboardOptions(
                                capitalization = KeyboardCapitalization.Words,
                                keyboardType = KeyboardType.Text
                            ),
                            singleLine = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = nameDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .onFocusChanged { focusState ->
                                    if (focusState.isFocused) {
                                        nameDropdownExpanded = true
                                    }
                                }
                        )

                        if (filteredNames.isNotEmpty()) {
                            ExposedDropdownMenu(
                                expanded = nameDropdownExpanded,
                                onDismissRequest = { nameDropdownExpanded = false }
                            ) {
                                filteredNames.forEach { name ->
                                    DropdownMenuItem(
                                        text = { Text(name) },
                                        onClick = {
                                            billName = name
                                            nameDropdownExpanded = false
                                            // Auto-populate GST & Commission rate
                                            val matched = bills.find { it.billName.trim().equals(name.trim(), ignoreCase = true) }
                                            if (matched != null) {
                                                gstTier = matched.gstPercentage
                                                customCommissionStr = matched.commissionRate.toString()
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Base amount input
                item {
                    OutlinedTextField(
                        value = baseAmountStr,
                        onValueChange = { baseAmountStr = it },
                        label = { Text("Pre-tax Amount *") },
                        placeholder = { Text("0.00") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // GST tier selector (Filter chips)
                item {
                    Text("GST Rates Selection", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(0, 5, 12, 18).forEach { percentage ->
                            ElevatedFilterChip(
                                selected = gstTier == percentage,
                                onClick = {
                                    gstTier = percentage
                                    val defaultRate = viewModel.commissionDefaults[percentage] ?: 0.0
                                    customCommissionStr = defaultRate.toString()
                                },
                                label = { Text("$percentage%") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Custom Commission Rate percentage input
                item {
                    OutlinedTextField(
                        value = customCommissionStr,
                        onValueChange = { customCommissionStr = it },
                        label = { Text("Commission Rate (%) *") },
                        placeholder = { Text("2.5") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }



                // Date selection
                item {
                    OutlinedTextField(
                        value = formattedDate,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Transaction Date") },
                        trailingIcon = {
                            IconButton(onClick = {
                                showNativeDatePicker(context, selectedDate) { dateMs ->
                                    selectedDate = dateMs
                                }
                            }) {
                                Icon(Icons.Default.DateRange, contentDescription = "Choose Date")
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Computed figures Summary Card
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.3f)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text("Summary & Recalculations", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Pre-Tax Base Amount:")
                                Text(formatCurrency(baseAmount))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("GST Amount ($gstTier%):")
                                Text("+ " + formatCurrency(calculatedGst))
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Commission Amount ($commissionRate%):")
                                Text("+ " + formatCurrency(calculatedComm))
                            }
                            Divider(
                                modifier = Modifier.padding(vertical = 6.dp),
                                color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    if (commissionRate == 0.0) "Customer Owed Amount (Base+GST):" else "Company Bill Amount (Base+GST):",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    formatCurrency(companyAmount),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val customer = selectedCustomer
                        if (customer == null) {
                            errorMessage = "Please select or register a customer."
                            return@Button
                        }
                        val amt = baseAmountStr.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            errorMessage = "Please enter valid pre-tax dollar amount greater than 0."
                            return@Button
                        }
                        val commRate = customCommissionStr.toDoubleOrNull() ?: 0.0

                        viewModel.updateBill(
                            billId = bill.id,
                            customerId = customer.id,
                            billName = billName.trim(),
                            baseAmount = amt,
                            gstPercent = gstTier,
                            commissionRate = commRate,
                            amountGivenToCustomer = amountGivenToCustomer,
                            amountPaidToCompany = amountPaidToCompany,
                            date = selectedDate,
                            customerPaid = false,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Save Changes")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPaymentDialog(
    viewModel: AppViewModel,
    payment: Payment,
    onDismiss: () -> Unit
) {
    val customers by viewModel.customers.collectAsState()
    
    var selectedCustomer by remember { mutableStateOf(customers.find { it.id == payment.customerId } ?: customers.firstOrNull()) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    
    var amountStr by remember { mutableStateOf(payment.amount.toString()) }
    var note by remember { mutableStateOf(payment.note) }
    var selectedDate by remember { mutableStateOf(payment.date) }
    val formattedDate = viewModel.formatDate(selectedDate)
    val context = LocalContext.current
    var errorMessage by remember { mutableStateOf("") }
    var isGivenToCustomer by remember { mutableStateOf(payment.isGivenToCustomer) }

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (isGivenToCustomer) "Edit Payment Given to Customer" else "Edit Received Payment",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (errorMessage.isNotEmpty()) {
                    Text(
                        text = errorMessage,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                // Payment Direction Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ElevatedFilterChip(
                        selected = !isGivenToCustomer,
                        onClick = { isGivenToCustomer = false },
                        label = { Text("Customer to Company", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                    ElevatedFilterChip(
                        selected = isGivenToCustomer,
                        onClick = { isGivenToCustomer = true },
                        label = { Text("Given to Customer", fontSize = 11.sp) },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Customer selection
                ExposedDropdownMenuBox(
                    expanded = dropdownExpanded,
                    onExpandedChange = { dropdownExpanded = it }
                ) {
                    OutlinedTextField(
                        value = selectedCustomer?.name ?: "Select Customer",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Select Customer *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = dropdownExpanded,
                        onDismissRequest = { dropdownExpanded = false }
                    ) {
                        customers.forEach { cust ->
                            DropdownMenuItem(
                                text = { Text(cust.name) },
                                onClick = {
                                    selectedCustomer = cust
                                    dropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                // Payment amount
                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { amountStr = it },
                    label = { Text(if (isGivenToCustomer) "Amount Given (Payout) *" else "Amount Received (Deposit) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    placeholder = { Text("0.00") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Date Picker
                OutlinedTextField(
                    value = formattedDate,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Payment Date") },
                    trailingIcon = {
                        IconButton(onClick = {
                            showNativeDatePicker(context, selectedDate) { dateMs ->
                                selectedDate = dateMs
                            }
                        }) {
                            Icon(Icons.Default.DateRange, contentDescription = "Pick Date")
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                )

                // Notes
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Transaction Details / Notes") },
                    placeholder = { Text("e.g. Cash, GPay, Cheque #20311") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Text("Cancel")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = {
                        val customer = selectedCustomer
                        if (customer == null) {
                            errorMessage = "Please select a customer."
                            return@Button
                        }
                        val amt = amountStr.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            errorMessage = "Please enter valid payment format greater than 0."
                            return@Button
                        }

                        viewModel.updatePayment(
                            paymentId = payment.id,
                            customerId = customer.id,
                            amount = amt,
                            date = selectedDate,
                            note = note.trim(),
                            isGivenToCustomer = isGivenToCustomer,
                            onSuccess = { onDismiss() },
                            onFailure = { errorMessage = it }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = if (isGivenToCustomer) MaterialTheme.colorScheme.error else Color(0xFF2E7D32)),
                    modifier = Modifier.iosTapScale()
                ) {
                    Text(if (isGivenToCustomer) "Update Given" else "Update Receipt")
                }
            }
        }
    }
}

@Composable
fun GoogleSyncDialog(
    viewModel: AppViewModel,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val syncManager = viewModel.syncManager
    val account by syncManager.signInAccount.collectAsState()
    val syncStatus by syncManager.syncStatus.collectAsState()
    val syncMessage by syncManager.syncMessage.collectAsState()
    val lastSyncTime by syncManager.lastSyncTime.collectAsState()

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val intent = result.data
        coroutineScope.launch {
            syncManager.handleSignInResult(intent)
        }
    }

    IosGlassDialog(
        onDismissRequest = onDismiss
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .liquidGlass(shape = CircleShape, elevation = 2.dp)
                            .padding(8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudSync,
                            contentDescription = "Google Sync",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(
                        text = "Google Cloud Sync",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.iosTapScale()
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            Text(
                text = "Sync your customer bills, deposits, and ledger entries securely to your Google Drive AppData space across all your devices.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (account != null) {
                IosGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "SIGNED IN AS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = account?.displayName ?: account?.email ?: "Google Account",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = account?.email ?: "",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (lastSyncTime > 0) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val sdf = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
                            Text(
                                text = "Last synced: ${sdf.format(Date(lastSyncTime))}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                            )
                        }
                    }
                }

                if (syncMessage.isNotEmpty()) {
                    Text(
                        text = syncMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (syncStatus == SyncStatus.ERROR) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            coroutineScope.launch {
                                syncManager.sync(forceUpload = true)
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .iosTapScale(),
                        enabled = syncStatus != SyncStatus.SYNCING && syncStatus != SyncStatus.SIGNING_IN
                    ) {
                        if (syncStatus == SyncStatus.SYNCING) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Syncing...")
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Sync Now")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            coroutineScope.launch {
                                syncManager.signOut()
                            }
                        },
                        modifier = Modifier.iosTapScale()
                    ) {
                        Text("Sign Out")
                    }
                }
            } else {
                IosGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Multi-Device Sync",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Sign in with your Google account to automatically sync ledger data whenever you add or edit bills. Install this app on another phone or tablet with the same Google account to access your ledger anywhere.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (syncMessage.isNotEmpty()) {
                    Text(
                        text = syncMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (syncStatus == SyncStatus.ERROR) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                    )
                }

                Button(
                    onClick = {
                        val intent = syncManager.getSignInIntent()
                        googleSignInLauncher.launch(intent)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .iosTapScale(),
                    enabled = syncStatus != SyncStatus.SIGNING_IN
                ) {
                    if (syncStatus == SyncStatus.SIGNING_IN) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp,
                            color = MaterialTheme.colorScheme.onPrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Connecting...")
                    } else {
                        Icon(Icons.Default.AccountCircle, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Sign in with Google")
                    }
                }
            }
        }
    }
}

