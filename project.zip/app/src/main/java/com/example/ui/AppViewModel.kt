package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    private val repository = AppRepository(
        database.customerDao(),
        database.billDao(),
        database.paymentDao()
    )
    val syncManager = GoogleDriveSyncManager(application, database)

    // Flow observation
    val customers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bills: StateFlow<List<Bill>> = repository.allBills
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val payments: StateFlow<List<Payment>> = repository.allPayments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customerSummaries: StateFlow<List<CustomerSummary>> = repository.customerSummaries
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Commission Defaults mapping
    // Key is GST percentage, Value is default Commission percentage
    var commissionDefaults = mutableStateMapOf<Int, Double>(
        0 to 0.0,
        5 to 1.5,
        12 to 2.5,
        18 to 3.5
    )

    // Analytics state
    val totalBilledAmount: StateFlow<Double> = bills
        .map { list -> list.sumOf { it.totalAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalDepositedAmount: StateFlow<Double> = payments
        .map { list -> list.sumOf { it.amount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalCommissionAmount: StateFlow<Double> = bills
        .map { list -> list.sumOf { it.commissionAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalOutstandingAmount: StateFlow<Double> = customerSummaries
        .map { summaries -> summaries.sumOf { it.outstandingBalance } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Helper functions for actions
    fun addCustomer(name: String, phone: String, email: String, openingBalance: Double = 0.0, onSuccess: () -> Unit = {}, onFailure: (String) -> Unit = {}) {
        if (name.isBlank()) {
            onFailure("Name cannot be blank.")
            return
        }
        val capitalizedName = name.trim().capitalizeWords()
        viewModelScope.launch {
            try {
                // Check uniqueness since we have unique index
                val alreadyExists = customers.value.any { it.name.trim().lowercase() == name.trim().lowercase() }
                if (alreadyExists) {
                    onFailure("Customer standard name '$capitalizedName' already exists.")
                    return@launch
                }
                repository.insertCustomer(Customer(name = capitalizedName, phone = phone, email = email, openingBalance = openingBalance))
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to add customer")
            }
        }
    }

    fun addBill(
        customerId: Int,
        billName: String,
        baseAmount: Double,
        gstPercent: Int,
        commissionRate: Double,
        amountGivenToCustomer: Double,
        amountPaidToCompany: Double,
        date: Long,
        customerPaid: Boolean = false,
        onSuccess: () -> Unit = {},
        onFailure: (String) -> Unit = {}
    ) {
        if (customerId <= 0) {
            onFailure("Please select a customer.")
            return
        }
        if (billName.isBlank()) {
            onFailure("Please enter a bill or invoice identifier.")
            return
        }
        if (baseAmount <= 0) {
            onFailure("Base amount must be greater than zero.")
            return
        }

        val formattedBillName = billName.trim().capitalizeWords()
        val gstAmount = baseAmount * (gstPercent.toDouble() / 100.0)
        val commissionAmount = baseAmount * (commissionRate / 100.0)
        val totalAmount = baseAmount + gstAmount + commissionAmount

        viewModelScope.launch {
            try {
                repository.insertBill(
                    Bill(
                        customerId = customerId,
                        billName = formattedBillName,
                        baseAmount = baseAmount,
                        gstPercentage = gstPercent,
                        gstAmount = gstAmount,
                        commissionRate = commissionRate,
                        commissionAmount = commissionAmount,
                        totalAmount = totalAmount,
                        amountGivenToCustomer = amountGivenToCustomer,
                        amountPaidToCompany = amountPaidToCompany,
                        date = date,
                        customerPaid = customerPaid
                    )
                )
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to add bill")
            }
        }
    }

    fun addPayment(
        customerId: Int,
        amount: Double,
        date: Long,
        note: String,
        isGivenToCustomer: Boolean = false,
        onSuccess: () -> Unit = {},
        onFailure: (String) -> Unit = {}
    ) {
        if (customerId <= 0) {
            onFailure("Please select a customer.")
            return
        }
        if (amount <= 0) {
            onFailure("Payment amount must be greater than zero.")
            return
        }
        val formattedNote = note.trim().capitalizeWords()
        viewModelScope.launch {
            try {
                repository.insertPayment(
                    Payment(
                        customerId = customerId,
                        amount = amount,
                        date = date,
                        note = formattedNote,
                        isGivenToCustomer = isGivenToCustomer
                    )
                )
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to record payment")
            }
        }
    }

    fun deleteBill(bill: Bill) {
        viewModelScope.launch {
            repository.deleteBill(bill)
            syncManager.sync()
        }
    }

    fun updateBill(
        billId: Int,
        customerId: Int,
        billName: String,
        baseAmount: Double,
        gstPercent: Int,
        commissionRate: Double,
        amountGivenToCustomer: Double,
        amountPaidToCompany: Double,
        date: Long,
        customerPaid: Boolean = false,
        onSuccess: () -> Unit = {},
        onFailure: (String) -> Unit = {}
    ) {
        if (customerId <= 0) {
            onFailure("Please select a customer.")
            return
        }
        if (baseAmount <= 0) {
            onFailure("Pre-tax amount must be greater than zero.")
            return
        }

        val formattedBillName = billName.trim().capitalizeWords()
        val gstRate = gstPercent.toDouble()
        val gstAmount = baseAmount * (gstRate / 100.0)
        val commissionAmount = baseAmount * (commissionRate / 100.0)
        val totalAmount = baseAmount + gstAmount + commissionAmount

        viewModelScope.launch {
            try {
                repository.updateBill(
                    Bill(
                        id = billId,
                        customerId = customerId,
                        billName = formattedBillName,
                        baseAmount = baseAmount,
                        gstPercentage = gstPercent,
                        gstAmount = gstAmount,
                        commissionRate = commissionRate,
                        commissionAmount = commissionAmount,
                        totalAmount = totalAmount,
                        amountGivenToCustomer = amountGivenToCustomer,
                        amountPaidToCompany = amountPaidToCompany,
                        date = date,
                        customerPaid = customerPaid
                    )
                )
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to update bill")
            }
        }
    }

    fun updatePayment(
        paymentId: Int,
        customerId: Int,
        amount: Double,
        date: Long,
        note: String,
        isGivenToCustomer: Boolean = false,
        onSuccess: () -> Unit = {},
        onFailure: (String) -> Unit = {}
    ) {
        if (customerId <= 0) {
            onFailure("Please select a customer.")
            return
        }
        if (amount <= 0) {
            onFailure("Payment amount must be greater than zero.")
            return
        }
        val formattedNote = note.trim().capitalizeWords()
        viewModelScope.launch {
            try {
                repository.updatePayment(
                    Payment(
                        id = paymentId,
                        customerId = customerId,
                        amount = amount,
                        date = date,
                        note = formattedNote,
                        isGivenToCustomer = isGivenToCustomer
                    )
                )
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to update payment")
            }
        }
    }

    fun deletePayment(payment: Payment) {
        viewModelScope.launch {
            repository.deletePayment(payment)
            syncManager.sync()
        }
    }

    fun deleteCustomer(customer: Customer) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
            syncManager.sync()
        }
    }

    fun updateCustomer(customer: Customer, onSuccess: () -> Unit = {}, onFailure: (String) -> Unit = {}) {
        if (customer.name.isBlank()) {
            onFailure("Name cannot be blank.")
            return
        }
        val capitalizedName = customer.name.trim().capitalizeWords()
        viewModelScope.launch {
            try {
                val alreadyExists = customers.value.any { 
                    it.id != customer.id && it.name.trim().lowercase() == customer.name.trim().lowercase() 
                }
                if (alreadyExists) {
                    onFailure("Customer name '$capitalizedName' already exists.")
                    return@launch
                }
                repository.updateCustomer(customer.copy(name = capitalizedName))
                onSuccess()
                viewModelScope.launch { syncManager.sync() }
            } catch (e: Exception) {
                onFailure(e.localizedMessage ?: "Failed to update customer")
            }
        }
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}

// Utility to create a mutable map for defaults
fun <K, V> Any.mutableStateMapOf(vararg pairs: Pair<K, V>): androidx.compose.runtime.snapshots.SnapshotStateMap<K, V> {
    return androidx.compose.runtime.mutableStateMapOf(*pairs)
}

fun String.capitalizeWords(): String {
    if (this.isBlank()) return ""
    return this.split(" ")
        .filter { it.isNotEmpty() }
        .joinToString(" ") { word ->
            if (word.isEmpty()) ""
            else word.substring(0, 1).uppercase() + word.substring(1)
        }
}
