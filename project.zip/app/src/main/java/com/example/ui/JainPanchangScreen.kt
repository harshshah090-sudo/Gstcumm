package com.example.ui

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Event
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Notifications
import com.example.data.JainCityManager
import com.example.ui.components.CitySelectionDialog
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.DayPanchang
import com.example.data.JainEvent
import com.example.data.JainEventCategory
import com.example.data.JainPanchangRepository
import com.example.ui.theme.*
import com.example.util.JainPanchangNotificationManager
import java.util.Calendar
import java.util.TimeZone

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JainPanchangScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val todayCal = remember { Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")) }
    val defaultYr = todayCal.get(Calendar.YEAR).coerceIn(2025, 2027)
    val defaultMo = todayCal.get(Calendar.MONTH) + 1
    val defaultDy = todayCal.get(Calendar.DAY_OF_MONTH)

    var selectedYear by remember { mutableIntStateOf(defaultYr) }
    var selectedMonth by remember { mutableIntStateOf(defaultMo) }
    var selectedDay by remember { mutableIntStateOf(defaultDy) }

    var lastMonthNavTime by remember { mutableLongStateOf(0L) }

    val navigatePreviousMonth: () -> Unit = {
        val now = System.currentTimeMillis()
        if (now - lastMonthNavTime > 350L) {
            lastMonthNavTime = now
            if (selectedMonth > 1) {
                selectedMonth--
            } else if (selectedYear > 2025) {
                selectedYear--
                selectedMonth = 12
            }
            selectedDay = 1
        }
    }

    val navigateNextMonth: () -> Unit = {
        val now = System.currentTimeMillis()
        if (now - lastMonthNavTime > 350L) {
            lastMonthNavTime = now
            if (selectedMonth < 12) {
                selectedMonth++
            } else if (selectedYear < 2027) {
                selectedYear++
                selectedMonth = 1
            }
            selectedDay = 1
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Calendar Grid, 1: Major Events, 2: Notification Alerts
    var selectedCity by remember { mutableStateOf(JainCityManager.getSelectedCity(context)) }
    var showCityDialog by remember { mutableStateOf(false) }

    val monthEvents = remember(selectedYear, selectedMonth) {
        JainPanchangRepository.getEventsForMonth(selectedYear, selectedMonth)
    }

    val selectedDayPanchang = remember(selectedYear, selectedMonth, selectedDay, selectedCity) {
        JainPanchangRepository.getDayPanchang(selectedYear, selectedMonth, selectedDay, selectedCity)
    }

    if (showCityDialog) {
        CitySelectionDialog(
            currentCity = selectedCity,
            onCitySelected = { newCity ->
                selectedCity = newCity
                JainCityManager.setSelectedCity(context, newCity)
            },
            onDismissRequest = { showCityDialog = false }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "जैन पंचांग एवं कैलेंडर",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "विक्रम संवत ${selectedYear + 57} • जैन तिथियाँ एवं पर्व",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 11.sp
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("panchang_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { selectedTab = 2 },
                        modifier = Modifier.testTag("panchang_notification_settings_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications Settings",
                            tint = AppPrimaryGold
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Navigation Tabs Header
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = AppSurface,
                contentColor = AppPrimaryGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = AppPrimaryGold
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("कैलेंडर", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("प्रमुख पर्व list", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("अलर्ट / रिमाइंडर", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                )
            }

            when (selectedTab) {
                0 -> {
                    // Calendar Tab
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        // 0. City Selector Banner
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = AppSurfaceNested,
                                border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { showCityDialog = true }
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(32.dp)
                                                .clip(CircleShape)
                                                .background(AppPrimaryGold.copy(alpha = 0.2f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.LocationOn,
                                                contentDescription = null,
                                                tint = AppPrimaryGold,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Column {
                                            Text(
                                                text = "पंचांग स्थान (शहर / Location)",
                                                fontSize = 11.sp,
                                                color = AppTextMuted
                                            )
                                            Text(
                                                text = selectedCity,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = AppTextPrimary
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = AppPrimaryGold.copy(alpha = 0.15f),
                                        border = BorderStroke(0.8.dp, AppPrimaryGold)
                                    ) {
                                        Text(
                                            text = "शहर बदलें ▾",
                                            fontSize = 11.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AppPrimaryGold,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // 1. Year Selector Chips
                        item {
                            YearSelectorRow(
                                selectedYear = selectedYear,
                                onYearSelected = { yr ->
                                    selectedYear = yr
                                    selectedDay = 1
                                }
                            )
                        }

                        // 2. Month Navigation Bar
                        item {
                            MonthHeaderBar(
                                year = selectedYear,
                                month = selectedMonth,
                                onPreviousMonth = navigatePreviousMonth,
                                onNextMonth = navigateNextMonth
                            )
                        }

                        // 3. Month Calendar Grid
                        item {
                            MonthCalendarGrid(
                                year = selectedYear,
                                month = selectedMonth,
                                selectedDay = selectedDay,
                                monthEvents = monthEvents,
                                onDayClick = { day -> selectedDay = day }
                            )
                        }

                        // 4. Selected Day Panchang Details
                        item {
                            DayPanchangDetailsCard(
                                panchang = selectedDayPanchang,
                                onChangeCityClick = { showCityDialog = true },
                                onScheduleReminder = { event ->
                                    JainPanchangNotificationManager.scheduleEventReminder(
                                        context,
                                        event.titleHindi,
                                        event.dateString,
                                        event.description
                                    )
                                }
                            )
                        }
                    }
                }
                1 -> {
                    // Major Events List
                    MajorEventsListTab(
                        selectedYear = selectedYear,
                        onYearChange = { selectedYear = it }
                    )
                }
                2 -> {
                    // Notification Alerts Settings Tab
                    NotificationSettingsTab()
                }
            }
        }
    }
}

@Composable
private fun YearSelectorRow(
    selectedYear: Int,
    onYearSelected: (Int) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "वर्ष:",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        )

        JainPanchangRepository.supportedYears.forEach { yr ->
            val isSelected = (yr == selectedYear)
            FilterChip(
                selected = isSelected,
                onClick = { onYearSelected(yr) },
                label = {
                    Text(
                        text = "$yr (सं. ${yr + 57})",
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontSize = 12.5.sp
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = AppPrimaryGold,
                    selectedLabelColor = Color.Black
                )
            )
        }
    }
}

@Composable
private fun MonthHeaderBar(
    year: Int,
    month: Int,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit
) {
    val monthNamesEnglish = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    val monthNamesHindi = listOf("जनवरी", "फरवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितंबर", "अक्टूबर", "नवंबर", "दिसंबर")

    val monthNameEng = monthNamesEnglish.getOrElse(month - 1) { "" }
    val monthNameHin = monthNamesHindi.getOrElse(month - 1) { "" }

    Card(
        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onPreviousMonth) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Previous Month",
                    tint = AppPrimaryGold
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "$monthNameHin $year ($monthNameEng)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
            }

            IconButton(onClick = onNextMonth) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Next Month",
                    tint = AppPrimaryGold
                )
            }
        }
    }
}

private fun getEventCategoryColor(category: JainEventCategory): Color {
    return when (category) {
        JainEventCategory.MAHAPARVA -> AppTertiaryMaroon
        JainEventCategory.KALYANAK -> Color(0xFFE65100) // Vibrant Orange
        JainEventCategory.OLI_PARVA -> Color(0xFF9E6200) // Saffron / Amber
        JainEventCategory.TITHI_FASTING -> AppSecondaryGreenDeep
    }
}

@Composable
private fun MonthCalendarGrid(
    year: Int,
    month: Int,
    selectedDay: Int,
    monthEvents: List<JainEvent>,
    onDayClick: (Int) -> Unit
) {
    val todayCal = remember { Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")) }
    val realTodayYear = todayCal.get(Calendar.YEAR)
    val realTodayMonth = todayCal.get(Calendar.MONTH) + 1
    val realTodayDay = todayCal.get(Calendar.DAY_OF_MONTH)

    val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).apply {
        set(Calendar.YEAR, year)
        set(Calendar.MONTH, month - 1)
        set(Calendar.DAY_OF_MONTH, 1)
    }

    val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday, 2 = Monday, ... 7 = Saturday
    val startOffset = firstDayOfWeek - 1 // Number of blank cells before day 1

    val daysOfWeek = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")

    val eventsMap = remember(monthEvents) {
        monthEvents.associateBy { it.day }
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Calendar Legend Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LegendChip(color = AppTertiaryMaroon, label = "🔴 महापर्व")
                LegendChip(color = Color(0xFFE65100), label = "🟧 कल्याणक")
                LegendChip(color = Color(0xFF9E6200), label = "🟨 ओली")
                LegendChip(color = AppSecondaryGreenDeep, label = "🟩 अठम-चौदस")
            }

            HorizontalDivider(color = AppBorder.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Days of Week Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                daysOfWeek.forEach { dayLabel ->
                    Text(
                        text = dayLabel,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold,
                            fontSize = 11.5.sp
                        ),
                        modifier = Modifier.weight(1f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = AppBorder)
            Spacer(modifier = Modifier.height(8.dp))

            // Grid Cells
            val totalCells = startOffset + daysInMonth
            val rows = (totalCells + 6) / 7

            for (r in 0 until rows) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - startOffset + 1

                        if (dayNum in 1..daysInMonth) {
                            val dayPanchang = JainPanchangRepository.getDayPanchang(year, month, dayNum)
                            val isSelected = (dayNum == selectedDay)
                            val dayEvents = dayPanchang.events
                            val topEvent = dayEvents.firstOrNull()
                            val isAthamOrChaudas = dayPanchang.isAthamOrChaudas

                            val cellBgColor = when {
                                isSelected -> AppPrimaryGold
                                topEvent != null -> getEventCategoryColor(topEvent.category)
                                isAthamOrChaudas -> AppSecondaryGreenDeep.copy(alpha = 0.5f)
                                else -> AppSurfaceNested
                            }

                            val cellBorderColor = when {
                                isSelected -> Color.White
                                topEvent != null -> AppPrimaryGold.copy(alpha = 0.8f)
                                isAthamOrChaudas -> AppSecondaryGreen
                                else -> AppBorder
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .aspectRatio(1f)
                                    .padding(2.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(cellBgColor)
                                    .border(
                                        width = if (isSelected) 1.5.dp else 0.5.dp,
                                        color = cellBorderColor,
                                        shape = RoundedCornerShape(8.dp)
                                    )
                                    .clickable { onDayClick(dayNum) },
                                contentAlignment = Alignment.Center
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Text(
                                        text = "$dayNum",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = if (isSelected || topEvent != null) FontWeight.Bold else FontWeight.Medium,
                                            color = when {
                                                isSelected -> Color.Black
                                                topEvent != null -> AppPrimaryGold
                                                isAthamOrChaudas -> AppSecondaryGreen
                                                else -> AppTextPrimary
                                            },
                                            fontSize = 12.5.sp
                                        )
                                    )

                                    if (topEvent != null) {
                                        val badgeText = when (topEvent.category) {
                                            JainEventCategory.MAHAPARVA -> "★"
                                            JainEventCategory.KALYANAK -> "ॐ"
                                            JainEventCategory.OLI_PARVA -> "ओली"
                                            JainEventCategory.TITHI_FASTING -> "व्रत"
                                        }
                                        Text(
                                            text = badgeText,
                                            color = if (isSelected) Color.Black else AppPrimaryGold,
                                            fontSize = 8.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else if (isAthamOrChaudas) {
                                        Text(
                                            text = "८/१४",
                                            color = if (isSelected) Color.Black else AppSecondaryGreen,
                                            fontSize = 7.5.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DayPanchangDetailsCard(
    panchang: DayPanchang,
    onScheduleReminder: (JainEvent) -> Unit,
    onChangeCityClick: (() -> Unit)? = null
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WbSunny,
                        contentDescription = null,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "दैनिक तिथि एवं पंचांग • ${panchang.day}/${panchang.month}/${panchang.year}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Location Bar
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = AppPrimaryGold.copy(alpha = 0.12f),
                border = BorderStroke(0.8.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onChangeCityClick?.invoke() }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = "स्थान: ${panchang.cityName}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                    Text(
                        text = "शहर बदलें ▾",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.5.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Detailed Tithi Info Card
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AppDeepSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = panchang.tithiName,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppPrimaryGold,
                                    fontSize = 15.sp
                                )
                            )
                            Text(
                                text = "${panchang.masNameHindi} ${if (panchang.paksha == "सुद") "सुदि (शुक्ल पक्ष)" else "वदि (कृष्ण पक्ष)"}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AppTextMuted,
                                    fontSize = 12.sp
                                )
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (panchang.paksha == "सुद") Color(0xFF1B5E20) else Color(0xFF4A148C),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = if (panchang.paksha == "सुद") "सुदि (शुक्ल)" else "वदि (कृष्ण)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = AppBorder.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        DetailPill(label = "विक्रम संवत", value = "सं. ${panchang.vikramSamvat}")
                        DetailPill(label = "वीर नि. संवत", value = "वीर ${panchang.vikramSamvat + 470}")
                        DetailPill(label = "मास (महीना)", value = panchang.masNameHindi)
                        DetailPill(label = "पक्ष", value = if (panchang.paksha == "सुद") "सुदि" else "वदि")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Timings Row (Sunrise, Sunset, Navkarsi, Chauvihar)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TimingBox(label = "सूर्योदय", time = panchang.sunriseTime)
                TimingBox(label = "सूर्यास्त", time = panchang.sunsetTime)
                TimingBox(label = "नवकारसी", time = panchang.navkarsiTime)
                TimingBox(label = "चौविहार", time = panchang.chauviharTime)
            }

            if (panchang.isAthamOrChaudas) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AppTertiaryMaroon.copy(alpha = 0.3f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppTertiaryMaroon),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "विशेष तिथि नियम: अष्टमी / चतुर्दशी (अठम-चौदस) त्याग एवं उपवास नियम पालन करें।",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppTextPrimary,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            // Events on this day
            if (panchang.events.isNotEmpty()) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = AppBorder)
                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "आज का विशेष पर्व / कल्याणक:",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )

                panchang.events.forEach { ev ->
                    Spacer(modifier = Modifier.height(6.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = getEventCategoryColor(ev.category),
                                        border = androidx.compose.foundation.BorderStroke(0.5.dp, AppPrimaryGold.copy(alpha = 0.5f))
                                    ) {
                                        Text(
                                            text = ev.category.labelHindi,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = AppPrimaryGold,
                                                fontSize = 9.5.sp,
                                                fontWeight = FontWeight.Bold
                                            ),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = ev.titleHindi,
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppPrimaryGold
                                        )
                                    )
                                }

                                Button(
                                    onClick = { onScheduleReminder(ev) },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = AppPrimaryGold,
                                        contentColor = Color.Black
                                    ),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Alarm,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("रिमाइंडर सेट करें", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = ev.description,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AppTextPrimary,
                                    fontSize = 11.5.sp
                                )
                            )

                            if (ev.fastingRule.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "तप/आराधना: ${ev.fastingRule}",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AppSecondaryGreen,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.5.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailPill(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontSize = 10.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold,
                fontSize = 11.5.sp
            )
        )
    }
}

@Composable
private fun TimingBox(label: String, time: String) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = AppSurfaceNested,
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextMuted,
                    fontSize = 10.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = time,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AppPrimaryGold,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
private fun MajorEventsListTab(
    selectedYear: Int,
    onYearChange: (Int) -> Unit
) {
    val context = LocalContext.current
    val allYearEvents = remember(selectedYear) {
        JainPanchangRepository.getAllEventsForYear(selectedYear)
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "वर्ष $selectedYear के प्रमुख जैन पर्व एवं महोत्सव",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )

                Row {
                    JainPanchangRepository.supportedYears.forEach { yr ->
                        FilterChip(
                            selected = yr == selectedYear,
                            onClick = { onYearChange(yr) },
                            label = { Text("$yr", fontSize = 11.sp) },
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                }
            }
        }

        items(allYearEvents) { ev ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = getEventCategoryColor(ev.category),
                                modifier = Modifier.padding(bottom = 4.dp)
                            ) {
                                Text(
                                    text = "${ev.category.labelHindi} • ${ev.dateString} (${ev.tithiHindi})",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.5.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = ev.titleHindi,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary,
                                    fontSize = 15.sp
                                )
                            )
                        }

                        IconButton(
                            onClick = {
                                JainPanchangNotificationManager.scheduleEventReminder(
                                    context,
                                    ev.titleHindi,
                                    ev.dateString,
                                    ev.description
                                )
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.NotificationsActive,
                                contentDescription = "Remind",
                                tint = AppPrimaryGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = ev.description,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppTextMuted,
                            fontSize = 12.sp
                        )
                    )

                    if (ev.fastingRule.isNotBlank()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "नियम: ${ev.fastingRule}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppSecondaryGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationSettingsTab() {
    val context = LocalContext.current

    var dailyTithiEnabled by remember {
        mutableStateOf(JainPanchangNotificationManager.isDailyTithiEnabled(context))
    }
    var paryushanAlertsEnabled by remember {
        mutableStateOf(JainPanchangNotificationManager.isParyushanAlertsEnabled(context))
    }
    var kalyanakAlertsEnabled by remember {
        mutableStateOf(JainPanchangNotificationManager.isKalyanakAlertsEnabled(context))
    }

    val hasNotificationPermission = remember {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        if (!hasNotificationPermission && android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF5C1D00)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "नोटिफिकेशन अनुमति आवश्यक है",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = "प्रातः तिथि व नवकारसी रिमाइंडर पाने के लिए ऐप को अनुमति दें।",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.8f))
                            )
                        }
                        Button(
                            onClick = {
                                (context as? android.app.Activity)?.let { act ->
                                    androidx.core.app.ActivityCompat.requestPermissions(
                                        act,
                                        arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                                        101
                                    )
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold, contentColor = AppSurface)
                        ) {
                            Text("अनुमति दें", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "जैन पर्व एवं तिथि नोटिफिकेशन सेटिंग्स",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "आपको विशेष पर्व, तिथि एवं नवकारसी-चौविहार समय के अलर्ट प्राप्त होंगे।",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = AppBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Toggle 1: Daily Morning Alert
                    NotificationToggleRow(
                        title = "दैनिक प्रातः पंचांग नोटिफिकेशन (6:00 AM)",
                        description = "प्रतिदिन सुबह आज की तिथि, नवकारसी एवं चौविहार समय का स्वचालित रिमाइंडर",
                        checked = dailyTithiEnabled,
                        onCheckedChange = { checked ->
                            dailyTithiEnabled = checked
                            JainPanchangNotificationManager.setDailyTithiEnabled(context, checked)
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = AppBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Toggle 2: Paryushan & Major Festivals
                    NotificationToggleRow(
                        title = "पर्यूषण एवं महाउत्सव अलर्ट",
                        description = "पर्यूषण महापर्व, संवत्सरी, जन्म वांचन, दीपावली, महावीर जयंती आदि का पूर्व रिमाइंडर",
                        checked = paryushanAlertsEnabled,
                        onCheckedChange = { checked ->
                            paryushanAlertsEnabled = checked
                            JainPanchangNotificationManager.setParyushanAlertsEnabled(context, checked)
                        }
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = AppBorder)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Toggle 3: Kalyanak Alerts
                    NotificationToggleRow(
                        title = "तीर्थंकर कल्याणक अलर्ट",
                        description = "२४ तीर्थंकरों के च्यावन, जन्म, दीक्षा, केवलज्ञान एवं मोक्ष कल्याणक तिथि रिमाइंडर",
                        checked = kalyanakAlertsEnabled,
                        onCheckedChange = { checked ->
                            kalyanakAlertsEnabled = checked
                            JainPanchangNotificationManager.setKalyanakAlertsEnabled(context, checked)
                        }
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = {
                            JainPanchangNotificationManager.triggerInstantTestNotification(context)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AppTertiaryMaroon,
                            contentColor = AppPrimaryGold
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NotificationsActive,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "तत्काल परीक्षण नोटिफिकेशन भेजें (Test Now)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun NotificationToggleRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AppTextMuted,
                    fontSize = 11.5.sp
                )
            )
        }

        Spacer(modifier = Modifier.width(8.dp))

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AppPrimaryGold,
                checkedTrackColor = AppTertiaryMaroon
            )
        )
    }
}

@Composable
private fun LegendChip(color: Color, label: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color.copy(alpha = 0.25f),
        border = androidx.compose.foundation.BorderStroke(0.8.dp, color)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.5.sp,
                    color = AppTextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            )
        }
    }
}
