package com.example.ui.theme

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/**
 * Modifier extension to apply iOS Liquid Glass effect to any component.
 */
@Composable
fun Modifier.liquidGlass(
    shape: Shape = RoundedCornerShape(24.dp),
    elevation: Dp = 8.dp,
    borderAlpha: Float = 0.45f,
    isOpaque: Boolean = false
): Modifier {
    val isDark = isSystemInDarkTheme()
    val glassBg = if (isDark) {
        if (isOpaque) {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF242832),
                    Color(0xFF181A20)
                )
            )
        } else {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0x33FFFFFF),
                    Color(0x1A1A1A26)
                )
            )
        }
    } else {
        if (isOpaque) {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFFFFFFFF),
                    Color(0xFFF0F4F8)
                )
            )
        } else {
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xE6FFFFFF),
                    Color(0xB3F0F4F8)
                )
            )
        }
    }

    val borderBrush = if (isDark) {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = borderAlpha * 0.8f),
                Color.White.copy(alpha = 0.05f),
                Color.White.copy(alpha = borderAlpha * 0.4f)
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                Color.White.copy(alpha = borderAlpha * 1.5f),
                Color.White.copy(alpha = 0.2f),
                Color.White.copy(alpha = borderAlpha * 0.8f)
            )
        )
    }

    val shadowColor = if (isDark) Color.Black.copy(alpha = 0.5f) else Color(0x1F000000)

    return this
        .shadow(
            elevation = elevation,
            shape = shape,
            clip = false,
            ambientColor = shadowColor,
            spotColor = shadowColor
        )
        .clip(shape)
        .background(glassBg)
        .border(1.dp, borderBrush, shape)
}

/**
 * iOS-style interactive press scaling effect with bouncy spring physics.
 */
@Composable
fun Modifier.iosTapScale(
    pressedScale: Float = 0.95f,
    onClick: (() -> Unit)? = null
): Modifier {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) pressedScale else 1f,
        animationSpec = spring(
            stiffness = Spring.StiffnessMediumLow,
            dampingRatio = Spring.DampingRatioMediumBouncy
        ),
        label = "iosTapScale"
    )

    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .then(
            if (onClick != null) {
                Modifier.clickable(
                    interactionSource = interactionSource,
                    indication = null,
                    onClick = onClick
                )
            } else Modifier
        )
}

/**
 * iOS Liquid Glass Floating Tube Navigation Item Data
 */
data class NavItemData(
    val title: String,
    val icon: ImageVector,
    val selectedIcon: ImageVector = icon
)

/**
 * Floating Tube Liquid Glass Bottom Navigation Bar styled like iOS.
 * Features a sliding liquid bubble indicator with bouncy spring animation.
 */
@Composable
fun IosLiquidTubeNavBar(
    items: List<NavItemData>,
    selectedTab: Int,
    onTabSelected: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isDark = isSystemInDarkTheme()

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        // Floating Glass Tube Outer Container
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .liquidGlass(
                    shape = CircleShape,
                    elevation = 16.dp,
                    borderAlpha = 0.7f
                ),
            color = Color.Transparent
        ) {
            androidx.compose.foundation.layout.BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 6.dp, vertical = 6.dp)
            ) {
                val totalWidth = maxWidth
                val tabCount = items.size
                val tabWidth = totalWidth / tabCount

                val indicatorOffset by animateFloatAsState(
                    targetValue = selectedTab.toFloat(),
                    animationSpec = spring(
                        stiffness = Spring.StiffnessLow,
                        dampingRatio = Spring.DampingRatioLowBouncy
                    ),
                    label = "liquidTubeIndicatorOffset"
                )

                // Active Sliding Liquid Bubble Pill
                Box(
                    modifier = Modifier
                        .width(tabWidth)
                        .height(52.dp)
                        .graphicsLayer {
                            translationX = indicatorOffset * tabWidth.toPx()
                        }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                        .clip(CircleShape)
                        .background(
                            brush = if (isDark) {
                                Brush.verticalGradient(
                                    colors = listOf(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.45f),
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.20f)
                                    )
                                )
                            } else {
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.White,
                                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)
                                    )
                                )
                            }
                        )
                        .shadow(
                            elevation = 6.dp,
                            shape = CircleShape,
                            ambientColor = MaterialTheme.colorScheme.primary,
                            spotColor = MaterialTheme.colorScheme.primary
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.White.copy(alpha = 0.8f),
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                                )
                            ),
                            shape = CircleShape
                        )
                )

                // Interactive Tab Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    items.forEachIndexed { index, item ->
                        val isSelected = selectedTab == index

                        val scale by animateFloatAsState(
                            targetValue = if (isSelected) 1.08f else 0.95f,
                            animationSpec = spring(
                                stiffness = Spring.StiffnessLow,
                                dampingRatio = Spring.DampingRatioLowBouncy
                            ),
                            label = "tabItemScale"
                        )

                        val contentColor by animateColorAsState(
                            targetValue = if (isSelected) {
                                MaterialTheme.colorScheme.primary
                            } else {
                                if (isDark) Color.White.copy(alpha = 0.55f) else Color.Black.copy(alpha = 0.50f)
                            },
                            animationSpec = spring(stiffness = Spring.StiffnessMedium),
                            label = "tabContentColor"
                        )

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                                .graphicsLayer {
                                    scaleX = scale
                                    scaleY = scale
                                }
                                .iosTapScale(pressedScale = 0.88f) {
                                    onTabSelected(index)
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.icon,
                                    contentDescription = item.title,
                                    tint = contentColor,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.title,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = contentColor
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * iOS Liquid Glass Card Container
 */
@Composable
fun IosGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(20.dp),
    elevation: Dp = 6.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .liquidGlass(shape = shape, elevation = elevation)
            .then(
                if (onClick != null) {
                    Modifier.iosTapScale(pressedScale = 0.97f, onClick = onClick)
                } else Modifier
            )
            .padding(16.dp)
    ) {
        content()
    }
}

/**
 * iOS-style Spring Dialog with Liquid Glass styling and open/close scale & fade animation.
 */
@Composable
fun IosGlassDialog(
    onDismissRequest: () -> Unit,
    properties: DialogProperties = DialogProperties(usePlatformDefaultWidth = false),
    content: @Composable () -> Unit
) {
    Dialog(
        onDismissRequest = onDismissRequest,
        properties = properties
    ) {
        var visible by remember { mutableStateOf(false) }
        
        LaunchedEffect(Unit) {
            visible = true
        }

        AnimatedVisibility(
            visible = visible,
            enter = scaleIn(
                animationSpec = spring(
                    stiffness = Spring.StiffnessMediumLow,
                    dampingRatio = Spring.DampingRatioMediumBouncy
                ),
                initialScale = 0.85f
            ) + fadeIn(animationSpec = tween(200)),
            exit = scaleOut(
                animationSpec = tween(150, easing = FastOutSlowInEasing),
                targetScale = 0.85f
            ) + fadeOut(animationSpec = tween(150))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(16.dp)
                    .liquidGlass(
                        shape = RoundedCornerShape(28.dp),
                        elevation = 20.dp,
                        borderAlpha = 0.7f,
                        isOpaque = true
                    )
                    .padding(20.dp)
            ) {
                content()
            }
        }
    }
}

/**
 * iOS Style Screen Tab Transition Spec
 */
val IosTabTransitionSpec = (slideInVertically(
    initialOffsetY = { 20 },
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow, dampingRatio = Spring.DampingRatioLowBouncy)
) + scaleIn(
    initialScale = 0.96f,
    animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
) + fadeIn(animationSpec = tween(250))).togetherWith(
    fadeOut(animationSpec = tween(150)) + scaleOut(
        targetScale = 0.98f,
        animationSpec = tween(150)
    )
)
