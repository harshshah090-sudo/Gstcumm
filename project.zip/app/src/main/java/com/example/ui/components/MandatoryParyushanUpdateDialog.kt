package com.example.ui.components

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.SwadhyaiFormEntity
import com.example.data.UserSessionManager
import com.example.ui.FormViewModel
import com.example.ui.ParyushanHistoryEntry
import com.example.ui.theme.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * A mandatory non-dismissible dialog that notifies already registered users about
 * the recently added Paryushan Aaradhna questions and collects their response
 * before granting access to the Home Screen.
 */
@Composable
fun MandatoryParyushanUpdateDialog(
    userProfile: SwadhyaiFormEntity,
    viewModel: FormViewModel,
    onCompleted: (SwadhyaiFormEntity) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    // Phase 1: Notification popup informing user of the update
    // Phase 2: Input form for the new question
    var isNoticeStep by remember { mutableStateOf(true) }

    // Paryushan History list state
    var paryushanHistoryList by remember {
        val initialList = mutableListOf<ParyushanHistoryEntry>()
        val existingLog = userProfile.paryushanHistoryLog.trim()
        if (existingLog.isNotBlank()) {
            val lines = existingLog.split("\n").map { it.trim() }.filter { it.isNotBlank() }
            for (line in lines) {
                val parts = line.split("-", limit = 2).map { it.trim() }
                if (parts.size == 2) {
                    initialList.add(ParyushanHistoryEntry(parts[0], parts[1]))
                } else if (parts.isNotEmpty()) {
                    initialList.add(ParyushanHistoryEntry(parts[0], ""))
                }
            }
        }
        if (initialList.isEmpty()) {
            initialList.add(ParyushanHistoryEntry("", ""))
        }
        mutableStateOf(initialList.toList())
    }

    var isSaving by remember { mutableStateOf(false) }

    // Strictly intercept back press - user cannot navigate away without completing
    BackHandler {
        Toast.makeText(
            context,
            "कृपया आगे बढ़ने के लिए जानकारी भरें / Please complete the details to proceed",
            Toast.LENGTH_SHORT
        ).show()
    }

    Dialog(
        onDismissRequest = { /* Non-dismissible */ },
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false,
            usePlatformDefaultWidth = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .padding(horizontal = 16.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = AppSurface,
                border = BorderStroke(1.5.dp, AppPrimaryGold.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 520.dp)
                    .wrapContentHeight()
            ) {
                AnimatedContent(
                    targetState = isNoticeStep,
                    label = "NoticeVsInputForm"
                ) { showingNotice ->
                    if (showingNotice) {
                        // --- STEP 1: NOTICE POPUP ---
                        Column(
                            modifier = Modifier
                                .padding(24.dp)
                                .fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .background(AppPrimaryGold.copy(alpha = 0.15f), CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Update,
                                    contentDescription = "Update Required",
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(34.dp)
                                )
                            }

                            Text(
                                text = "आवश्यक जानकारी अपडेट करें\nProfile Update Required",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                ),
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = "जय जिनेन्द्र, ${userProfile.fullName}!",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = AppPrimaryGold
                                ),
                                textAlign = TextAlign.Center
                            )

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = AppDeepSurface,
                                border = BorderStroke(1.dp, AppBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = "पर्यूषण आराधना पंजीकरण में एक नया प्रश्न जोड़ा गया है:",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = AppTextPrimary
                                        )
                                    )
                                    Text(
                                        text = "• \"When and where did you last time went for Paryushan?\"\n(अंतिम बार कब और कहाँ पर्यूषण आराधना के लिए गए थे?)",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.Medium,
                                            color = AppPrimaryGold
                                        )
                                    )
                                    Text(
                                        text = "ऐप की होम स्क्रीन का उपयोग करने के लिए कृपया इस जानकारी को पूरा करें।\n\nPlease complete this required detail to continue to the Home screen.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = AppTextMuted,
                                            lineHeight = 18.sp
                                        )
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Button(
                                onClick = { isNoticeStep = false },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AppPrimaryGold,
                                    contentColor = AppBackground
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.EditCalendar,
                                    contentDescription = null,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "अभी भरें (Update Now)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    } else {
                        // --- STEP 2: MANDATORY INPUT FORM ---
                        val scrollState = rememberScrollState()

                        val focusManager = androidx.compose.ui.platform.LocalFocusManager.current

                        Column(
                            modifier = Modifier
                                .padding(20.dp)
                                .fillMaxWidth()
                                .clickable(
                                    interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                                    indication = null
                                ) {
                                    focusManager.clearFocus()
                                }
                                .verticalScroll(scrollState),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .background(AppPrimaryGold.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EventNote,
                                        contentDescription = null,
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Paryushan Aaradhna Details",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    )
                                    Text(
                                        text = "Total Paryushan attended: ${userProfile.paryushanCount}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                                    )
                                }
                            }

                            HorizontalDivider(color = AppBorder)

                            ParyushanHistoryInputSection(
                                paryushanCount = userProfile.paryushanCount,
                                paryushanHistoryList = paryushanHistoryList,
                                onParyushanHistoryListChange = { paryushanHistoryList = it }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // Submit & Save Button
                            Button(
                                onClick = {
                                    val first = paryushanHistoryList.firstOrNull()
                                    if (first == null || first.year.length != 4 || first.place.isBlank()) {
                                        Toast.makeText(
                                            context,
                                            "Please enter 4-digit Year and Sangh Place Name for last Paryushan",
                                            Toast.LENGTH_LONG
                                        ).show()
                                        return@Button
                                    }

                                    // Validate any additional filled entries
                                    for (i in 1 until paryushanHistoryList.size) {
                                        val entry = paryushanHistoryList[i]
                                        if (entry.year.length != 4 || entry.place.isBlank()) {
                                            Toast.makeText(
                                                context,
                                                "Please complete entry #${i + 1} or remove it",
                                                Toast.LENGTH_SHORT
                                            ).show()
                                            return@Button
                                        }
                                    }

                                    isSaving = true

                                    val formattedLog = paryushanHistoryList
                                        .filter { it.year.isNotBlank() && it.place.isNotBlank() }
                                        .joinToString("\n") { "${it.year.trim()} - ${it.place.trim()}" }

                                    val cleanPhone = userProfile.whatsappNo.replace("[^0-9]".toRegex(), "").takeLast(10)
                                    val updatedEntity = userProfile.copy(
                                        paryushanHistoryLog = formattedLog,
                                        updatedAt = System.currentTimeMillis()
                                    )

                                    coroutineScope.launch {
                                        // 1. Save to Room database
                                        withContext(Dispatchers.IO) {
                                            try {
                                                if (updatedEntity.id > 0L) {
                                                    viewModel.updateSwadhyaiForm(updatedEntity)
                                                } else {
                                                    viewModel.insertSwadhyaiForm(updatedEntity)
                                                }
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                        }

                                        // 2. Save to UserSessionManager
                                        UserSessionManager.updateProfileData(updatedEntity)

                                        // 3. Save to Firebase Firestore
                                        withContext(Dispatchers.IO) {
                                            try {
                                                val db = FirebaseFirestore.getInstance()
                                                val updateMap = hashMapOf<String, Any>(
                                                    "paryushanHistoryLog" to formattedLog,
                                                    "updatedAt" to System.currentTimeMillis()
                                                )
                                                db.collection("swadhyai_forms")
                                                    .document("phone_$cleanPhone")
                                                    .set(updateMap, SetOptions.merge())

                                                if (userProfile.firestoreDocId.isNotBlank()) {
                                                    db.collection("swadhyai_forms")
                                                        .document(userProfile.firestoreDocId)
                                                        .set(updateMap, SetOptions.merge())
                                                }
                                            } catch (e: Exception) {
                                                e.printStackTrace()
                                            }
                                        }

                                        isSaving = false
                                        Toast.makeText(
                                            context,
                                            "Paryushan details updated successfully! Welcome to Home.",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        onCompleted(updatedEntity)
                                    }
                                },
                                enabled = !isSaving,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AppPrimaryGold,
                                    contentColor = AppBackground
                                ),
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                            ) {
                                if (isSaving) {
                                    CircularProgressIndicator(
                                        color = AppBackground,
                                        modifier = Modifier.size(24.dp),
                                        strokeWidth = 2.5.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Saving...", fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Save & Proceed to Home",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
