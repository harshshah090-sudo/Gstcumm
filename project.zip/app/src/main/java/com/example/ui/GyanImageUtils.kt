package com.example.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.util.Log
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import java.io.ByteArrayOutputStream
import java.io.InputStream

object GyanImageUtils {
    private const val TAG = "GyanImageUtils"
    private val bitmapCache = LruCache<String, Bitmap>(50)

    /**
     * Converts a content Uri from Android Gallery into a high-quality, lightweight Base64 string
     */
    fun processImageUriToBase64(context: Context, uri: Uri, targetDimension: Int = 280): String? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) return null

            // Handle EXIF orientation
            val rotatedBitmap = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val exifStream = context.contentResolver.openInputStream(uri)
                    if (exifStream != null) {
                        val exif = ExifInterface(exifStream)
                        val orientation = exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                        exifStream.close()
                        rotateBitmapIfRequired(originalBitmap, orientation)
                    } else originalBitmap
                } else {
                    originalBitmap
                }
            } catch (e: Exception) {
                originalBitmap
            }

            // Crop to center square
            val width = rotatedBitmap.width
            val height = rotatedBitmap.height
            val cropDimension = minOf(width, height)
            val cropX = (width - cropDimension) / 2
            val cropY = (height - cropDimension) / 2

            val squaredBitmap = Bitmap.createBitmap(
                rotatedBitmap,
                cropX,
                cropY,
                cropDimension,
                cropDimension
            )

            // Resize to target dimension (e.g. 280x280)
            val scaledBitmap = if (cropDimension != targetDimension) {
                Bitmap.createScaledBitmap(squaredBitmap, targetDimension, targetDimension, true)
            } else {
                squaredBitmap
            }

            // Preserve alpha / transparency for PNGs and icons
            val outputStream = ByteArrayOutputStream()
            if (scaledBitmap.hasAlpha()) {
                scaledBitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
            } else {
                scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 88, outputStream)
            }
            val byteArray = outputStream.toByteArray()

            Base64.encodeToString(byteArray, Base64.NO_WRAP)
        } catch (e: Exception) {
            Log.e(TAG, "Error processing image uri to Base64", e)
            null
        }
    }

    /**
     * Decodes Base64 string to Bitmap with LRU memory caching
     */
    fun getCachedBitmapFromBase64(base64String: String): Bitmap? {
        if (base64String.isBlank()) return null
        val cached = bitmapCache.get(base64String)
        if (cached != null && !cached.isRecycled) {
            return cached
        }
        return try {
            val cleanBase64 = if (base64String.contains(",")) {
                base64String.substringAfter(",")
            } else {
                base64String
            }
            val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
            if (bitmap != null) {
                bitmapCache.put(base64String, bitmap)
            }
            bitmap
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding Base64 string to Bitmap", e)
            null
        }
    }

    private fun rotateBitmapIfRequired(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}

/**
 * Reusable Composable that renders either an uploaded custom photo or an emoji/icon
 */
@Composable
fun GyanVisualDisplay(
    visualType: String,
    visualValue: String,
    modifier: Modifier = Modifier,
    emojiFontSize: TextUnit = 32.sp
) {
    val isImage = visualType.equals("IMAGE_BASE64", ignoreCase = true) ||
            visualType.equals("IMAGE", ignoreCase = true) ||
            visualValue.length > 80

    if (isImage) {
        val bitmap = remember(visualValue) {
            GyanImageUtils.getCachedBitmapFromBase64(visualValue)
        }
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = "Category Visual",
                contentScale = ContentScale.Crop,
                modifier = modifier
                    .fillMaxSize()
                    .clip(CircleShape)
            )
        } else {
            Text(
                text = "📖",
                fontSize = emojiFontSize,
                textAlign = TextAlign.Center
            )
        }
    } else {
        Text(
            text = visualValue.ifEmpty { "📖" },
            fontSize = emojiFontSize,
            textAlign = TextAlign.Center
        )
    }
}
