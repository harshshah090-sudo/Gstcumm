package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ParyushanHistoryEntry
import com.example.ui.theme.*

/**
 * An interactive Paryushan Aaradhna history input section.
 * Whenever the user fills in the Year and Sangh Place Name and taps outside / leaves
 * the text fields, the boxes shrink and slide into a sleek summary pill below the question
 * with a pencil icon to re-edit, removing the text boxes from view.
 */
@Composable
fun ParyushanHistoryInputSection(
    paryushanCount: Int,
    paryushanHistoryList: List<ParyushanHistoryEntry>,
    onParyushanHistoryListChange: (List<ParyushanHistoryEntry>) -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val maxAllowed = if (paryushanCount > 0) paryushanCount else 1
    val isZeroOrDisabled = (paryushanCount == 0)

    // Set of indices that are actively in editing (expanded) state
    var editingIndices by remember {
        val initialEditing = mutableSetOf<Int>()
        paryushanHistoryList.forEachIndexed { index, entry ->
            if (entry.year.length != 4 || entry.place.isBlank()) {
                initialEditing.add(index)
            }
        }
        if (initialEditing.isEmpty() && paryushanHistoryList.isNotEmpty()) {
            // If nothing is filled yet
            if (paryushanHistoryList.firstOrNull()?.year.isNullOrBlank()) {
                initialEditing.add(0)
            }
        }
        mutableStateOf(initialEditing.toSet())
    }

    // Ensure incomplete entries are kept open
    LaunchedEffect(paryushanHistoryList) {
        val incomplete = paryushanHistoryList.indices.filter {
            val e = paryushanHistoryList[it]
            e.year.length != 4 || e.place.isBlank()
        }.toSet()
        if (incomplete.isNotEmpty()) {
            editingIndices = editingIndices + incomplete
        }
    }

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "When and where did you last time went for Paryushan? " + if (isZeroOrDisabled) "(Disabled - Count is 0)" else "*",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = if (isZeroOrDisabled) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else AppTextPrimary
            )
        )

        if (isZeroOrDisabled) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "Not applicable (Paryushan Aaradhna count is 0)",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    modifier = Modifier.padding(12.dp)
                )
            }
        } else {
            paryushanHistoryList.forEachIndexed { index, entry ->
                key(index) {
                    val isFirst = index == 0
                    val isEditing = index in editingIndices || entry.year.length != 4 || entry.place.isBlank()

                    var yearFocused by remember { mutableStateOf(false) }
                    var placeFocused by remember { mutableStateOf(false) }
                    var wasFocusedInThisSession by remember(isEditing) { mutableStateOf(false) }
                    val yearFocusRequester = remember { FocusRequester() }

                    LaunchedEffect(isEditing) {
                        if (isEditing) {
                            kotlinx.coroutines.delay(60)
                            try {
                                yearFocusRequester.requestFocus()
                            } catch (_: Exception) {}
                        }
                    }

                    AnimatedContent(
                    targetState = isEditing,
                    transitionSpec = {
                        if (targetState) {
                            // Expanding to edit
                            (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)))
                                .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
                        } else {
                            // Shrinking and sliding down to compact summary badge
                            (fadeIn(animationSpec = tween(280)) + expandVertically(animationSpec = tween(280)) + slideInVertically(animationSpec = tween(280)))
                                .togetherWith(fadeOut(animationSpec = tween(200)) + shrinkVertically(animationSpec = tween(200)))
                        }
                    },
                    label = "ParyushanHistoryTransition_$index"
                ) { editingState ->
                    if (editingState) {
                        // --- EDITABLE TEXT FIELD BOXES ---
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.65f),
                            border = BorderStroke(1.dp, AppBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (isFirst) "Last Paryushan Aaradhna *" else "Paryushan Aaradhna #${index + 1}",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppPrimaryGold
                                        )
                                    )

                                    // Checkmark button to collapse when valid
                                    if (entry.year.length == 4 && entry.place.isNotBlank()) {
                                        FilledTonalIconButton(
                                            onClick = {
                                                focusManager.clearFocus()
                                                editingIndices = editingIndices - index
                                            },
                                            colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                containerColor = AppPrimaryGold.copy(alpha = 0.2f),
                                                contentColor = AppPrimaryGold
                                            ),
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = "Done",
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = entry.year,
                                        onValueChange = { y ->
                                            val filteredYear = y.filter { c -> c.isDigit() }.take(4)
                                            val updated = paryushanHistoryList.toMutableList()
                                            updated[index] = entry.copy(year = filteredYear)
                                            onParyushanHistoryListChange(updated)
                                        },
                                        placeholder = { Text("YYYY") },
                                        label = { Text("Year") },
                                        keyboardOptions = KeyboardOptions(
                                            keyboardType = KeyboardType.Number,
                                            imeAction = ImeAction.Next
                                        ),
                                        singleLine = true,
                                        modifier = Modifier
                                            .width(96.dp)
                                            .focusRequester(yearFocusRequester)
                                            .onFocusChanged { focusState ->
                                                yearFocused = focusState.isFocused
                                                if (focusState.isFocused) {
                                                    wasFocusedInThisSession = true
                                                } else if (!placeFocused && wasFocusedInThisSession && entry.year.length == 4 && entry.place.isNotBlank()) {
                                                    editingIndices = editingIndices - index
                                                }
                                            }
                                    )

                                    Text(
                                        text = "-",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppPrimaryGold
                                        )
                                    )

                                    OutlinedTextField(
                                        value = entry.place,
                                        onValueChange = { p ->
                                            val updated = paryushanHistoryList.toMutableList()
                                            updated[index] = entry.copy(place = capitalizeWords(p))
                                            onParyushanHistoryListChange(updated)
                                        },
                                        placeholder = { Text("Sangh Place Name") },
                                        label = { Text("Place Name") },
                                        keyboardOptions = KeyboardOptions(
                                            capitalization = androidx.compose.ui.text.input.KeyboardCapitalization.Words,
                                            imeAction = ImeAction.Done
                                        ),
                                        keyboardActions = KeyboardActions(
                                            onDone = {
                                                focusManager.clearFocus()
                                                if (entry.year.length == 4 && entry.place.isNotBlank()) {
                                                    editingIndices = editingIndices - index
                                                }
                                            }
                                        ),
                                        singleLine = true,
                                        modifier = Modifier
                                            .weight(1f)
                                            .onFocusChanged { focusState ->
                                                placeFocused = focusState.isFocused
                                                if (focusState.isFocused) {
                                                    wasFocusedInThisSession = true
                                                } else if (!yearFocused && wasFocusedInThisSession && entry.year.length == 4 && entry.place.isNotBlank()) {
                                                    editingIndices = editingIndices - index
                                                }
                                            }
                                    )

                                    if (!isFirst) {
                                        IconButton(
                                            onClick = {
                                                val updated = paryushanHistoryList.toMutableList()
                                                updated.removeAt(index)
                                                editingIndices = editingIndices.filter { it != index }
                                                    .map { if (it > index) it - 1 else it }
                                                    .toSet()
                                                onParyushanHistoryListChange(updated)
                                            }
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "Remove",
                                                tint = MaterialTheme.colorScheme.error
                                            )
                                        }
                                    }
                                }

                                if (entry.year.isNotBlank() || entry.place.isNotBlank()) {
                                    Text(
                                        text = "Answer: \"${entry.year.ifBlank { "YYYY" }} - ${entry.place.ifBlank { "Place" }}\"",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = FontWeight.Medium,
                                            color = if (entry.year.length == 4 && entry.place.isNotBlank()) Color(0xFF81C784) else MaterialTheme.colorScheme.onSurfaceVariant
                                        ),
                                        modifier = Modifier.padding(start = 4.dp, top = 2.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        // --- SHRUNK & SLIDED COMPACT SUMMARY BADGE WITH PENCIL ICON ---
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AppDeepSurface,
                            border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.55f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clickable {
                                    editingIndices = editingIndices + index
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .background(AppPrimaryGold.copy(alpha = 0.15f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.EventAvailable,
                                        contentDescription = null,
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isFirst) "Last Paryushan Aaradhna" else "Paryushan Aaradhna #${index + 1}",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = AppTextMuted,
                                            fontSize = 11.sp
                                        )
                                    )
                                    Text(
                                        text = "${entry.year} - ${entry.place}",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppTextPrimary,
                                            fontSize = 15.sp
                                        )
                                    )
                                }

                                // Pencil icon to re-edit
                                IconButton(
                                    onClick = {
                                        editingIndices = editingIndices + index
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Paryushan Details",
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                if (!isFirst) {
                                    IconButton(
                                        onClick = {
                                            val updated = paryushanHistoryList.toMutableList()
                                            updated.removeAt(index)
                                            editingIndices = editingIndices.filter { it != index }
                                                .map { if (it > index) it - 1 else it }
                                                .toSet()
                                            onParyushanHistoryListChange(updated)
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
            }

            // Add More Button (bounded by declared paryushanCount and completeness of last entry)
            val canAddMore = paryushanHistoryList.size < maxAllowed &&
                    paryushanHistoryList.lastOrNull()?.let { it.year.length == 4 && it.place.isNotBlank() } == true

            if (paryushanHistoryList.size < maxAllowed) {
                TextButton(
                    onClick = {
                        if (canAddMore) {
                            val nextIndex = paryushanHistoryList.size
                            editingIndices = editingIndices + nextIndex
                            onParyushanHistoryListChange(paryushanHistoryList + ParyushanHistoryEntry("", ""))
                        }
                    },
                    enabled = canAddMore,
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add More Paryushan Aaradhna (${paryushanHistoryList.size}/$maxAllowed)")
                }
            }
        }
    }
}
