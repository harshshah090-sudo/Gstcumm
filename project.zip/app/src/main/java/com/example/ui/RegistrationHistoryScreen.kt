package com.example.ui

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.RegistrationHistoryEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ArchivedSwadhyaiModel(
    val swadhyaiId: Long,
    val fullName: String,
    val city: String,
    val state: String = ""
)

data class ArchivedFullSanghModel(
    val sanghId: Long = 0L,
    val firestoreDocId: String = "",
    val sanghName: String = "",
    val sanghAddress: String = "",
    val cityName: String = "",
    val stateName: String = "",
    val contact1: String = "",
    val contact2: String = "",
    val mulnayakBhagwan: String = "",
    val totalFamilies: String = "",
    val hasOtherSangh: String = "नहीं",
    val gacchList: String = "",
    val pratikramanTradition: String = "",
    val hasMusicianGroup: String = "नहीं",
    val callsOutsideMusician: String = "नहीं",
    val hasPanchPratikramanPerson: String = "नहीं",
    val hasToiletFacility: String = "नहीं",
    val aradhanaSamagriList: String = "",
    val countRaiPratikraman: String = "",
    val countDevasiPratikraman: String = "",
    val countPravachan: String = "",
    val countSandhyaBhakti: String = "",
    val mainTrustees: String = "",
    val agreedToTerms: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val donationAmount: Double = 0.0,
    val swadhyayis: List<ArchivedSwadhyaiModel> = emptyList(),
    val isAllotted: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationHistoryScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToDetail: (Int) -> Unit
) {
    val histories by viewModel.allRegistrationHistories.collectAsState()
    val sortedHistories = remember(histories) {
        histories.sortedByDescending { it.year }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Registration History",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("history_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (sortedHistories.isEmpty()) {
                // Empty state
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(90.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HistoryEdu,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(48.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    Text(
                        text = "No Registration History",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Archived registrations will appear here after Paryushan Aaradhana is marked complete.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = AppTextMuted
                        ),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(sortedHistories, key = { it.year }) { history ->
                        HistoryYearSummaryCard(
                            history = history,
                            onCardClick = { onNavigateToDetail(history.year) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryYearSummaryCard(
    history: RegistrationHistoryEntity,
    onCardClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onCardClick)
            .testTag("history_card_${history.year}"),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Year Title + Forward Arrow (No badge as requested)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Year ${history.year}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Details",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Paryushan Dates Row
            if (history.paryushanStartDate.isNotBlank() && history.paryushanEndDate.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.DateRange,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Paryushan Dates: ${history.paryushanStartDate} - ${history.paryushanEndDate}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Summary Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricItem(
                    label = "Total Sanghs",
                    value = "${history.totalSanghCount}",
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "Allotted Sanghs",
                    value = "${history.allottedSanghCount}",
                    color = Color(0xFF2E7D32),
                    modifier = Modifier.weight(1f)
                )
                MetricItem(
                    label = "Unallotted",
                    value = "${history.unallottedSanghCount}",
                    color = Color(0xFFE65100),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricItem(
                    label = "Allotted Swadhyayis",
                    value = "${history.totalAllottedSwadhyayisCount}",
                    color = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )

                val formattedDonation = remember(history.totalDonationReceived) {
                    val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
                    format.maximumFractionDigits = 0
                    format.format(history.totalDonationReceived)
                }
                MetricItem(
                    label = "Total Donation",
                    value = formattedDonation,
                    color = Color(0xFF00695C),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Tap prompt
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap to open details window",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium
                    )
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationHistoryDetailScreen(
    year: Int,
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit
) {
    val histories by viewModel.allRegistrationHistories.collectAsState()
    val history = remember(histories, year) {
        histories.find { it.year == year }
    }
    val latestYear = remember(histories) {
        histories.maxByOrNull { it.year }?.year
    }
    val isLatest = history != null && history.year == latestYear

    var showRestoreDialog by remember { mutableStateOf(false) }
    var restoreErrorMessage by remember { mutableStateOf<String?>(null) }
    var selectedSanghForPopup by remember { mutableStateOf<ArchivedFullSanghModel?>(null) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val allottedSanghs = remember(history?.archivedAllotmentsJson) {
        parseArchivedAllotmentsFull(history?.archivedAllotmentsJson ?: "")
    }

    val unallottedSanghs = remember(history?.archivedUnallottedSanghsJson) {
        parseArchivedUnallottedSanghsFull(history?.archivedUnallottedSanghsJson ?: "")
    }

    val pagerState = rememberPagerState(pageCount = { 2 })

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Year $year Registration",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("detail_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }
                },
                actions = {
                    // Restore option on the inside window on the right side of the header
                    if (isLatest) {
                        TextButton(
                            onClick = { showRestoreDialog = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.primary),
                            modifier = Modifier.testTag("header_restore_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Restore,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Restore",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (history == null) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No registration record found for Year $year")
                }
            } else {
                // Tab Row connected to HorizontalPager
                TabRow(
                    selectedTabIndex = pagerState.currentPage,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.primary,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            modifier = Modifier.tabIndicatorOffset(tabPositions[pagerState.currentPage]),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                ) {
                    Tab(
                        selected = pagerState.currentPage == 0,
                        onClick = {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(0)
                            }
                        },
                        text = {
                            Text(
                                text = "Allotted Sanghs (${allottedSanghs.size})",
                                fontWeight = if (pagerState.currentPage == 0) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                        }
                    )
                    Tab(
                        selected = pagerState.currentPage == 1,
                        onClick = {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(1)
                            }
                        },
                        text = {
                            Text(
                                text = "Unallotted Sanghs (${unallottedSanghs.size})",
                                fontWeight = if (pagerState.currentPage == 1) FontWeight.Bold else FontWeight.Medium,
                                fontSize = 14.sp
                            )
                        }
                    )
                }

                // Horizontal Pager enabling smooth sliding left and right
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                ) { page ->
                    if (page == 0) {
                        // Allotted Sanghs List
                        if (allottedSanghs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No allotted sanghs recorded.",
                                    style = MaterialTheme.typography.bodyLarge.copy(color = AppTextMuted)
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(allottedSanghs, key = { it.sanghId }) { sangh ->
                                    MinimalAllottedSanghCard(
                                        sangh = sangh,
                                        onSanghClick = { selectedSanghForPopup = sangh }
                                    )
                                }
                            }
                        }
                    } else {
                        // Unallotted Sanghs List
                        if (unallottedSanghs.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(32.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "No unallotted sanghs.",
                                    style = MaterialTheme.typography.bodyLarge.copy(color = AppTextMuted)
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(unallottedSanghs, key = { it.sanghId }) { sangh ->
                                    MinimalUnallottedSanghCard(
                                        sangh = sangh,
                                        onSanghClick = { selectedSanghForPopup = sangh }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Restore confirmation dialog
    if (showRestoreDialog && history != null) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Restore,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Restore Year $year Registration?",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to restore the registration of Year $year? This will restore all Sangh registrations to the active window, restore allotments, revert Swadhyai profile counts and logs, and remove this archive record.",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val targetYear = year
                        showRestoreDialog = false
                        viewModel.restoreRegistrationHistory(
                            year = targetYear,
                            onSuccess = {
                                android.widget.Toast.makeText(
                                    context,
                                    "Year $targetYear registration restored successfully",
                                    android.widget.Toast.LENGTH_SHORT
                                ).show()
                                onNavigateBack()
                            },
                            onError = { err ->
                                restoreErrorMessage = err
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("confirm_restore_button")
                ) {
                    Text("Restore")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showRestoreDialog = false },
                    modifier = Modifier.testTag("cancel_restore_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    // Full Sangh Registration Detail Popup Dialog
    selectedSanghForPopup?.let { sangh ->
        SanghRegistrationDetailPopup(
            sangh = sangh,
            onDismiss = { selectedSanghForPopup = null }
        )
    }

    // Error Dialog
    restoreErrorMessage?.let { err ->
        AlertDialog(
            onDismissRequest = { restoreErrorMessage = null },
            title = { Text("Error") },
            text = { Text(err) },
            confirmButton = {
                TextButton(onClick = { restoreErrorMessage = null }) {
                    Text("OK")
                }
            }
        )
    }
}

/**
 * Allotted Sangh Card: Strictly Sangh Name & City, and Swadhyai Name & City only.
 * Tapping triggers popup with full information.
 */
@Composable
private fun MinimalAllottedSanghCard(
    sangh: ArchivedFullSanghModel,
    onSanghClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onSanghClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Sangh Name
            Text(
                text = sangh.sanghName.ifBlank { "श्रीसंघ" },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )

            // City (Only city / state)
            val cityText = listOf(sangh.cityName, sangh.stateName).filter { it.isNotBlank() }.joinToString(", ")
            if (cityText.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "📍 $cityText",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                )
            }

            // Swadhyayis List (Strictly Name & City only)
            if (sangh.swadhyayis.isNotEmpty()) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "Allotted Swadhyayis:",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.secondary,
                        fontSize = 11.sp
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))

                sangh.swadhyayis.forEach { sw ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = sw.fullName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = 13.sp
                                )
                            )
                            if (sw.city.isNotBlank()) {
                                Text(
                                    text = sw.city,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = AppTextMuted,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Unallotted Sangh Card: Strictly Sangh Name & City.
 * Tapping triggers popup with full information.
 */
@Composable
private fun MinimalUnallottedSanghCard(
    sangh: ArchivedFullSanghModel,
    onSanghClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .border(
                1.dp,
                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                RoundedCornerShape(12.dp)
            )
            .clickable(onClick = onSanghClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = sangh.sanghName.ifBlank { "श्रीसंघ" },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
            val cityText = listOf(sangh.cityName, sangh.stateName).filter { it.isNotBlank() }.joinToString(", ")
            if (cityText.isNotBlank()) {
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "📍 $cityText",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 13.sp
                    )
                )
            }
        }
    }
}

/**
 * Full Sangh Registration Information Popup Dialog
 */
@Composable
private fun SanghRegistrationDetailPopup(
    sangh: ArchivedFullSanghModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.88f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Dialog Header
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Apartment,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "श्री संघ पंजीकरण विवरण",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Sangh Header Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = sangh.sanghName.ifBlank { "श्री संघ" },
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            if (sangh.mulnayakBhagwan.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "मूलनायक भगवान: ${sangh.mulnayakBhagwan}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                            if (sangh.cityName.isNotBlank() || sangh.stateName.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "स्थान: ${listOf(sangh.cityName, sangh.stateName).filter { it.isNotBlank() }.joinToString(", ")}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                            if (sangh.sanghAddress.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "पूरा पता: ${sangh.sanghAddress}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = AppTextMuted
                                    )
                                )
                            }
                            if (sangh.totalFamilies.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "घर संख्या: ${sangh.totalFamilies}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }

                    // Contact Persons Section
                    DetailSection(title = "संपर्क सूत्र") {
                        if (sangh.contact1.isNotBlank()) {
                            DetailRow(label = "स्वाध्यायी भाई संपर्क (नाम, पद)", value = sangh.contact1)
                        }
                        if (sangh.contact2.isNotBlank()) {
                            DetailRow(label = "WhatsApp न.", value = sangh.contact2)
                        }
                        if (sangh.mainTrustees.isNotBlank()) {
                            DetailRow(label = "मुख्य ३ अग्रणी/ट्रस्टी", value = sangh.mainTrustees)
                        }
                    }

                    // Tradition & Facilities Section
                    DetailSection(title = "परंपरा एवं व्यवस्था") {
                        if (sangh.gacchList.isNotBlank()) {
                            DetailRow(label = "संघ में गच्छ", value = sangh.gacchList)
                        }
                        if (sangh.pratikramanTradition.isNotBlank()) {
                            DetailRow(label = "प्रतिकमण परंपरा", value = sangh.pratikramanTradition)
                        }
                        DetailRow(label = "अन्य संघ उपस्थित है", value = sangh.hasOtherSangh)
                        DetailRow(label = "संगीतकार / मंडल उपस्थित है", value = sangh.hasMusicianGroup)
                        DetailRow(label = "बाहर से संगीतकार बुलाते हों", value = sangh.callsOutsideMusician)
                        DetailRow(label = "पंच प्रतिकमण जानकर व्यक्ति", value = sangh.hasPanchPratikramanPerson)
                        DetailRow(label = "मात्रू-ठल्ले (Toilet) व्यवस्था", value = sangh.hasToiletFacility)
                        if (sangh.aradhanaSamagriList.isNotBlank()) {
                            DetailRow(label = "उपलब्ध आराधना सामग्री", value = sangh.aradhanaSamagriList)
                        }
                    }

                    // Attendance Numbers Section
                    if (sangh.countRaiPratikraman.isNotBlank() || sangh.countDevasiPratikraman.isNotBlank() ||
                        sangh.countPravachan.isNotBlank() || sangh.countSandhyaBhakti.isNotBlank()
                    ) {
                        DetailSection(title = "प्रवृत्तियों में हाजिर व्यक्तियों की संख्या") {
                            if (sangh.countRaiPratikraman.isNotBlank()) DetailRow(label = "राई प्रतिकमण", value = sangh.countRaiPratikraman)
                            if (sangh.countDevasiPratikraman.isNotBlank()) DetailRow(label = "देवसी प्रतिकमण", value = sangh.countDevasiPratikraman)
                            if (sangh.countPravachan.isNotBlank()) DetailRow(label = "प्रवचन", value = sangh.countPravachan)
                            if (sangh.countSandhyaBhakti.isNotBlank()) DetailRow(label = "संध्या भक्ति", value = sangh.countSandhyaBhakti)
                        }
                    }

                    // Allotted Swadhyayis & Donation Section (if allotted)
                    if (sangh.isAllotted || sangh.swadhyayis.isNotEmpty()) {
                        DetailSection(title = "आवंटन एवं दान विवरण") {
                            if (sangh.swadhyayis.isNotEmpty()) {
                                Text(
                                    text = "आवंटित स्वाध्यायी:",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                )
                                sangh.swadhyayis.forEach { sw ->
                                    Text(
                                        text = "• ${sw.fullName}${if (sw.city.isNotBlank()) " (${sw.city})" else ""}",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurface)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                            if (sangh.donationAmount > 0) {
                                val format = NumberFormat.getCurrencyInstance(Locale("en", "IN")).apply {
                                    maximumFractionDigits = 0
                                }
                                DetailRow(label = "प्राप्त दान राशि", value = format.format(sangh.donationAmount))
                            }
                        }
                    }

                    // Registration Date
                    val dateStr = SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault()).format(Date(sangh.createdAt))
                    Text(
                        text = "पंजीकरण दिनांक: $dateStr",
                        style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted)
                    )
                }

                // Dialog Footer Actions
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                val shareText = buildShareableSanghText(sangh)
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, shareText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(sendIntent, "Share Sangh Details"))
                            },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share")
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Button(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Close")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailSection(
    title: String,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String
) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontSize = 11.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

private fun buildShareableSanghText(sangh: ArchivedFullSanghModel): String {
    val dateStr = SimpleDateFormat("dd/MM/yyyy, hh:mm a", Locale.getDefault()).format(Date(sangh.createdAt))
    return """
    *श्री वर्धमान स्वाध्यायी मंडल*
    *पर्वाधीराज पर्यूषण आराधना - संघ विवरण*
    ======================================
    १. श्री संघ का नाम: ${sangh.sanghName}
    २. श्री संघ का पूरा पता: ${sangh.sanghAddress}
    ३. शहर/गांव का नाम: ${if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName}
    --------------------------------------
    ४. स्वाध्याई भाई संपर्क (नाम, पद): ${sangh.contact1}
    ५. स्वाध्याई भाई WhatsApp न.: ${sangh.contact2}
    ६. मुलनायक भगवान: ${sangh.mulnayakBhagwan}
    ७. अन्य संघ उपस्थित है: ${sangh.hasOtherSangh}
    ८. संघ में गच्छ: ${sangh.gacchList}
    ९. प्रतिकमण परंपरा: ${sangh.pratikramanTradition}
    १०. संगीतकार / मंडल उपस्थित है: ${sangh.hasMusicianGroup}
    ११. बाहर से संगीतकार बुलाते हों: ${sangh.callsOutsideMusician}
    १२. पंच प्रतिकमण जानकर व्यक्ति: ${sangh.hasPanchPratikramanPerson}
    १३. मात्रू-ठल्ले (Toilet) व्यवस्था: ${sangh.hasToiletFacility}
    १४. उपलब्ध आराधना सामग्री: ${sangh.aradhanaSamagriList}
    १५. प्रवृत्तियों में हाजिर व्यक्तियों की संख्या:
       • राई प्रतिकमण: ${sangh.countRaiPratikraman}
       • देवसी प्रतिकमण: ${sangh.countDevasiPratikraman}
       • प्रवचन: ${sangh.countPravachan}
       • संध्या भक्ति: ${sangh.countSandhyaBhakti}
    १६. मुख्य ३ अग्रणी/ट्रस्टी: ${sangh.mainTrustees}
    ======================================
    दिनांक: $dateStr
    """.trimIndent()
}

@Composable
private fun MetricItem(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = color.copy(alpha = 0.08f),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontSize = 15.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextMuted,
                    fontSize = 10.sp
                ),
                maxLines = 1
            )
        }
    }
}

private fun parseArchivedAllotmentsFull(jsonStr: String): List<ArchivedFullSanghModel> {
    if (jsonStr.isBlank()) return emptyList()
    val list = mutableListOf<ArchivedFullSanghModel>()
    try {
        val arr = JSONArray(jsonStr)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val swList = mutableListOf<ArchivedSwadhyaiModel>()
            val swArr = obj.optJSONArray("swadhyayis")
            if (swArr != null) {
                for (j in 0 until swArr.length()) {
                    val swObj = swArr.getJSONObject(j)
                    swList.add(
                        ArchivedSwadhyaiModel(
                            swadhyaiId = swObj.optLong("swadhyaiId", 0L),
                            fullName = swObj.optString("fullName", ""),
                            city = swObj.optString("city", ""),
                            state = swObj.optString("state", "")
                        )
                    )
                }
            }

            list.add(
                ArchivedFullSanghModel(
                    sanghId = obj.optLong("sanghId", obj.optLong("id", 0L)),
                    firestoreDocId = obj.optString("firestoreDocId", ""),
                    sanghName = obj.optString("sanghName", ""),
                    sanghAddress = obj.optString("sanghAddress", ""),
                    cityName = obj.optString("cityName", ""),
                    stateName = obj.optString("stateName", ""),
                    contact1 = obj.optString("contact1", ""),
                    contact2 = obj.optString("contact2", ""),
                    mulnayakBhagwan = obj.optString("mulnayakBhagwan", ""),
                    totalFamilies = obj.optString("totalFamilies", ""),
                    hasOtherSangh = obj.optString("hasOtherSangh", "नहीं"),
                    gacchList = obj.optString("gacchList", ""),
                    pratikramanTradition = obj.optString("pratikramanTradition", ""),
                    hasMusicianGroup = obj.optString("hasMusicianGroup", "नहीं"),
                    callsOutsideMusician = obj.optString("callsOutsideMusician", "नहीं"),
                    hasPanchPratikramanPerson = obj.optString("hasPanchPratikramanPerson", "नहीं"),
                    hasToiletFacility = obj.optString("hasToiletFacility", "नहीं"),
                    aradhanaSamagriList = obj.optString("aradhanaSamagriList", ""),
                    countRaiPratikraman = obj.optString("countRaiPratikraman", ""),
                    countDevasiPratikraman = obj.optString("countDevasiPratikraman", ""),
                    countPravachan = obj.optString("countPravachan", ""),
                    countSandhyaBhakti = obj.optString("countSandhyaBhakti", ""),
                    mainTrustees = obj.optString("mainTrustees", ""),
                    agreedToTerms = obj.optBoolean("agreedToTerms", true),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                    donationAmount = obj.optDouble("donationAmount", 0.0),
                    swadhyayis = swList,
                    isAllotted = true
                )
            )
        }
    } catch (e: Exception) {
        android.util.Log.e("RegistrationHistory", "Error parsing archived allotments: ${e.message}")
    }
    return list
}

private fun parseArchivedUnallottedSanghsFull(jsonStr: String): List<ArchivedFullSanghModel> {
    if (jsonStr.isBlank()) return emptyList()
    val list = mutableListOf<ArchivedFullSanghModel>()
    try {
        val arr = JSONArray(jsonStr)
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            list.add(
                ArchivedFullSanghModel(
                    sanghId = obj.optLong("sanghId", obj.optLong("id", 0L)),
                    firestoreDocId = obj.optString("firestoreDocId", ""),
                    sanghName = obj.optString("sanghName", ""),
                    sanghAddress = obj.optString("sanghAddress", ""),
                    cityName = obj.optString("cityName", ""),
                    stateName = obj.optString("stateName", ""),
                    contact1 = obj.optString("contact1", ""),
                    contact2 = obj.optString("contact2", ""),
                    mulnayakBhagwan = obj.optString("mulnayakBhagwan", ""),
                    totalFamilies = obj.optString("totalFamilies", ""),
                    hasOtherSangh = obj.optString("hasOtherSangh", "नहीं"),
                    gacchList = obj.optString("gacchList", ""),
                    pratikramanTradition = obj.optString("pratikramanTradition", ""),
                    hasMusicianGroup = obj.optString("hasMusicianGroup", "नहीं"),
                    callsOutsideMusician = obj.optString("callsOutsideMusician", "नहीं"),
                    hasPanchPratikramanPerson = obj.optString("hasPanchPratikramanPerson", "नहीं"),
                    hasToiletFacility = obj.optString("hasToiletFacility", "नहीं"),
                    aradhanaSamagriList = obj.optString("aradhanaSamagriList", ""),
                    countRaiPratikraman = obj.optString("countRaiPratikraman", ""),
                    countDevasiPratikraman = obj.optString("countDevasiPratikraman", ""),
                    countPravachan = obj.optString("countPravachan", ""),
                    countSandhyaBhakti = obj.optString("countSandhyaBhakti", ""),
                    mainTrustees = obj.optString("mainTrustees", ""),
                    agreedToTerms = obj.optBoolean("agreedToTerms", true),
                    createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                    donationAmount = 0.0,
                    swadhyayis = emptyList(),
                    isAllotted = false
                )
            )
        }
    } catch (e: Exception) {
        android.util.Log.e("RegistrationHistory", "Error parsing archived unallotted: ${e.message}")
    }
    return list
}
