package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color

// --- Light Theme Palette ---
val LightBackground = Color(0xFFF7F5EE)          // #F7F5EE App base
val LightSurface = Color(0xFFFFFFFF)             // #FFFFFF Cards, search bar, header logo bg
val LightSurfaceNested = Color(0xFFF0EDE1)       // #F0EDE1 Countdown box background
val LightBorder = Color(0xFFE3DFCF)              // #E3DFCF Card borders, inactive tab borders

val LightPrimaryGold = Color(0xFFC1861F)         // #C1861F Buttons, headings, tags, active tab, FAB
val LightPrimaryGoldDeep = Color(0xFF9C6C15)     // #9C6C15 Hero border, "Sangh Allotted" card
val LightSecondaryGreen = Color(0xFF2F6B4F)      // #2F6B4F "Swadhyai Registrations" card, borders, inactive tab text
val LightSecondaryGreenDeep = Color(0xFF1F4D39)  // #1F4D39 Green gradient end
val LightTertiaryMaroon = Color(0xFF8A2E3F)      // #8A2E3F "Sangh Registrations" card, first countdown digit, Day 1 date pill
val LightTertiaryMaroonDeep = Color(0xFF6B2130)  // #6B2130 Maroon gradient end
val LightQuaternaryTeal = Color(0xFF1F5C58)      // #1F5C58 "Funds" stat card
val LightQuaternaryTealDeep = Color(0xFF154440)  // #154440 Teal gradient end

val LightTextPrimary = Color(0xFF241E15)         // #241E15 Titles, values
val LightTextMuted = Color(0xFF736C5C)           // #736C5C Labels, secondary sub text

// --- Dark Theme Palette ---
val AppBackground = Color(0xFF101614)           // #101614 App base
val AppSurface = Color(0xFF1B2420)              // #1B2420 Cards, search bar, header logo bg
val AppSurfaceNested = Color(0xFF212D27)        // #212D27 Countdown digit boxes, inactive tabs
val AppDeepSurface = Color(0xFF141A17)          // #141A17 Countdown box background
val AppBorder = Color(0xFF2A3830)               // #2A3830 Card borders, dividers

val AppPrimaryGold = Color(0xFFD4A24C)          // #D4A24C Buttons, headings, tags, FAB, active tab
val AppPrimaryGoldDeep = Color(0xFFB8863C)      // #B8863C Hero card border, Sangh Allotted stat card
val AppSecondaryGreen = Color(0xFF2F6B4F)       // #2F6B4F Hero gradient start, Swadhyai Registrations card, borders
val AppSecondaryGreenDeep = Color(0xFF173829)   // #173829 Hero gradient end
val AppTertiaryMaroon = Color(0xFF7A2635)       // #7A2635 Sangh Registrations card, first countdown digit, Day 1 date pill
val AppTertiaryMaroonDeep = Color(0xFF4A1620)   // #4A1620 Maroon gradient end
val AppQuaternaryTeal = Color(0xFF1F4D4A)       // #1F4D4A Funds stat card
val AppQuaternaryTealDeep = Color(0xFF0E2624)   // #0E2624 Teal gradient end

val AppTextPrimary = Color(0xFFEDE7DA)          // #EDE7DA Titles, values
val AppTextMuted = Color(0xFF8FA096)            // #8FA096 Labels, secondary sub text
val AppSuccessPaleGreen = Color(0xFF8FCB9E)     // #8FCB9E Tag text, inactive tab labels

// Aliases for MaterialTheme mapping
val AppPrimaryAccent = AppPrimaryGold
val AppSecondaryAccent = AppSecondaryGreen
val AppSurfaceVariant = AppSurface
val AppPrimaryContainer = Color(0xFF212D27)
val AppOnPrimaryContainer = AppTextPrimary
val AppSecondaryContainer = Color(0xFF173829)
val AppOnSecondaryContainer = AppSuccessPaleGreen

// Backward compatible aliases
val DarkAmberPrimary = LightPrimaryGold
val LightAmberPrimary = LightPrimaryGold
val LightAmberSecondary = LightSecondaryGreen
val LightBrownTextPrimary = LightTextPrimary
val LightCreamBackground = LightBackground
val LightSurfaceVariant = LightSurfaceNested
val LightCreamContainer = LightSurfaceNested
val LightTextMutedBrown = LightTextMuted
val LightSoftBrownBorder = LightBorder





