package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// --- Light Theme Palette (#713600, #C05800, #38240D, #FDFBD4) ---
val LightAmberPrimary = Color(0xFF713600)       // #713600 Primary
val LightAmberSecondary = Color(0xFFC05800)     // #C05800 Secondary
val LightBrownTextPrimary = Color(0xFF38240D)   // #38240D Text Primary
val LightCreamBackground = Color(0xFFFDFBD4)    // #FDFBD4 Background

val LightSurface = Color(0xFFFFFEEB)
val LightSurfaceVariant = Color(0xFFF6F0B5)
val LightCreamContainer = Color(0xFFFAF6C4)
val LightTextMutedBrown = Color(0xFF634D35)
val LightSoftBrownBorder = Color(0xFFE2D6A2)

// --- Dark Theme Palette (#101614, #1B2420, #D4A24C, #2F6B4F, #EDE7DA, #8FA096, #8FCB9E) ---
val AppBackground = Color(0xFF101614)       // #101614 Background
val AppSurface = Color(0xFF1B2420)          // #1B2420 Surface/card
val AppPrimaryAccent = Color(0xFFD4A24C)    // #D4A24C Primary accent (Buttons, headings, tags, FAB)
val AppSecondaryAccent = Color(0xFF2F6B4F)  // #2F6B4F Secondary accent (Hero gradient, borders)
val AppTextPrimary = Color(0xFFEDE7DA)      // #EDE7DA Text (primary)
val AppTextMuted = Color(0xFF8FA096)        // #8FA096 Text (muted)
val AppSuccessPaleGreen = Color(0xFF8FCB9E) // #8FCB9E Success/pale green tag text

// Derived Dark Tones
val AppSurfaceVariant = Color(0xFF232E29)
val AppPrimaryContainer = Color(0xFF332B1A)
val AppOnPrimaryContainer = Color(0xFFF3E1BE)
val AppSecondaryContainer = Color(0xFF1F3D30)
val AppOnSecondaryContainer = Color(0xFFBBE5D0)

// Backward compatible aliases
val DarkAmberPrimary = LightAmberPrimary
val VibrantAmberSecondary = LightAmberSecondary
val DeepBrownDark = LightBrownTextPrimary
val CreamParchmentLight = LightCreamBackground

val SaffronPrimary = AppPrimaryAccent
val SaffronDark = Color(0xFFA27830)
val SaffronLight = AppPrimaryAccent
val SaffronContainer = AppPrimaryContainer
val OnSaffronContainer = AppOnPrimaryContainer

val TealSecondary = AppSecondaryAccent
val TealDark = Color(0xFF1E4834)
val TealContainer = AppSecondaryContainer

val VioletTertiary = AppSuccessPaleGreen
val VioletContainer = AppSecondaryContainer

val SacredParchmentBg = LightCreamBackground
val SacredSurface = LightSurface
val SacredSurfaceVariant = LightSurfaceVariant
val SacredBorder = LightSoftBrownBorder

val TextPrimaryDark = LightBrownTextPrimary
val TextSecondaryMuted = LightTextMutedBrown

val SaffronPrimaryDark = AppPrimaryAccent
val DarkBackground = AppBackground
val DarkSurface = AppSurface
val DarkSurfaceVariant = AppSurfaceVariant




