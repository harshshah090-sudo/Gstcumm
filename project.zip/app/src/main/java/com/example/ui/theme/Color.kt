package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SaffronPrimary = Color(0xFFD97706)
val SaffronDark = Color(0xFFB45309)
val SaffronLight = Color(0xFFFBBF24)
val SaffronContainer = Color(0xFFFEF3C7)
val OnSaffronContainer = Color(0xFF78350F)

val TealSecondary = Color(0xFF0D9488)
val TealDark = Color(0xFF0F766E)
val TealContainer = Color(0xFFCCFBF1)

val VioletTertiary = Color(0xFF7C3AED)
val VioletContainer = Color(0xFFEDE9FE)

val SacredParchmentBg = Color(0xFFFFFDF5)
val SacredSurface = Color(0xFFFFFFFF)
val SacredSurfaceVariant = Color(0xFFF7F3E9)
val SacredBorder = Color(0xFFE5DDCB)

val TextPrimaryDark = Color(0xFF261C14)
val TextSecondaryMuted = Color(0xFF6B5E52)

// Dark theme variants
val SaffronPrimaryDark = Color(0xFFF59E0B)
val DarkBackground = Color(0xFF1C1917)
val DarkSurface = Color(0xFF292524)
val DarkSurfaceVariant = Color(0xFF38332E)

