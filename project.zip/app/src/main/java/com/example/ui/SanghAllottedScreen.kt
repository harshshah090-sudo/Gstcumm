package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ParyushanFormEntity
import com.example.data.SwadhyaiFormEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllottedScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allForms by viewModel.allForms.collectAsState()
    val allSwadhyaiForms by viewModel.allSwadhyaiForms.collectAsState()
    val allAllotments by viewModel.allAllotments.collectAsState()

    var showSanghDialog by remember { mutableStateOf(false) }
    var selectedSanghForSwadhyaiAllotment by remember { mutableStateOf<ParyushanFormEntity?>(null) }

    // Active allotments containing valid swadhyai IDs
    val activeAllotments = remember(allAllotments, allSwadhyaiForms) {
        val swadhyaiMap = allSwadhyaiForms.associateBy { it.id }
        allAllotments.mapNotNull { allotment ->
            val parsedIds = allotment.swadhyaiIds.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .filter { swadhyaiMap.containsKey(it) }
            if (parsedIds.isEmpty()) null
            else allotment to parsedIds
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sangh Allotted",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("allotted_count_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AssignmentTurnedIn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${activeAllotments.size}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSanghDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_allotment_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Sangh Allotment",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (activeAllotments.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Sangh Allotted Yet",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tap the '+' button at the bottom right corner to allocate Swadhyai to a Sangh.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(activeAllotments, key = { it.first.sanghId }) { (allotment, swadhyaiIds) ->
                        val sanghForm = allForms.find { it.id == allotment.sanghId }
                        val sanghName = sanghForm?.sanghName ?: allotment.sanghName
                        val cityName = sanghForm?.cityName ?: allotment.cityName
                        val stateName = sanghForm?.stateName ?: allotment.stateName

                        val swadhyaiMap = remember(allSwadhyaiForms) { allSwadhyaiForms.associateBy { it.id } }
                        val swadhyaiList = swadhyaiIds.mapNotNull { swadhyaiMap[it] }

                        AllottedSanghCard(
                            sanghName = sanghName,
                            cityName = cityName,
                            stateName = stateName,
                            swadhyaiList = swadhyaiList,
                            onClick = {
                                val form = sanghForm ?: ParyushanFormEntity(
                                    id = allotment.sanghId,
                                    sanghName = allotment.sanghName,
                                    cityName = allotment.cityName,
                                    stateName = allotment.stateName,
                                    sanghAddress = "", contact1 = "", contact2 = "",
                                    mulnayakBhagwan = "", totalFamilies = "", hasOtherSangh = "No",
                                    gacchList = "", pratikramanTradition = "", hasMusicianGroup = "No",
                                    callsOutsideMusician = "No", hasPanchPratikramanPerson = "No",
                                    hasToiletFacility = "No", aradhanaSamagriList = "", countRaiPratikraman = "",
                                    countDevasiPratikraman = "", countPravachan = "", countSandhyaBhakti = "",
                                    mainTrustees = "", agreedToTerms = true
                                )
                                selectedSanghForSwadhyaiAllotment = form
                            }
                        )
                    }
                }
            }
        }
    }

    // Popup 1: Sangh Allotment Dialog
    if (showSanghDialog) {
        val allocatedSanghIds = remember(allAllotments) {
            allAllotments.filter { it.swadhyaiIds.isNotBlank() }.map { it.sanghId }.toSet()
        }
        val unallottedSanghs = remember(allForms, allocatedSanghIds) {
            allForms.filter { !allocatedSanghIds.contains(it.id) }
        }

        SanghAllotmentDialog(
            unallottedSanghs = unallottedSanghs,
            onDismiss = { showSanghDialog = false },
            onSanghSelected = { sangh ->
                showSanghDialog = false
                selectedSanghForSwadhyaiAllotment = sangh
            }
        )
    }

    // Popup 2: Swadhyai Allotment Dialog
    selectedSanghForSwadhyaiAllotment?.let { sangh ->
        val currentAllotment = allAllotments.find { it.sanghId == sangh.id }
        val currentSwadhyaiIds = remember(currentAllotment) {
            currentAllotment?.swadhyaiIds?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()
        }

        // Swadhyais allotted to OTHER sanghs cannot be selected (prevent duplicate)
        val swadhyaiIdsInOtherSanghs = remember(allAllotments, sangh.id) {
            allAllotments.filter { it.sanghId != sangh.id && it.swadhyaiIds.isNotBlank() }
                .flatMap { it.swadhyaiIds.split(",").mapNotNull { idStr -> idStr.trim().toLongOrNull() } }
                .toSet()
        }

        val availableSwadhyaiForms = remember(allSwadhyaiForms, swadhyaiIdsInOtherSanghs) {
            allSwadhyaiForms.filter { !swadhyaiIdsInOtherSanghs.contains(it.id) }
        }

        SwadhyaiAllotmentDialog(
            sangh = sangh,
            allSwadhyaiForms = availableSwadhyaiForms,
            initiallySelectedIds = currentSwadhyaiIds,
            onDismiss = { selectedSanghForSwadhyaiAllotment = null },
            onSelectionChanged = { selectedIds ->
                viewModel.saveAllotment(
                    sanghId = sangh.id,
                    sanghName = sangh.sanghName,
                    cityName = sangh.cityName,
                    stateName = sangh.stateName,
                    swadhyaiIds = selectedIds
                )
            }
        )
    }
}

@Composable
fun AllottedSanghCard(
    sanghName: String,
    cityName: String,
    stateName: String,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onClick: () -> Unit
) {
    val locationText = if (stateName.isNotBlank()) "$cityName / $stateName" else cityName

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("allotted_sangh_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // City / State (Top Left Corner)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = locationText,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sangh Name in Hindi as inputted
            Text(
                text = sanghName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // Swadhyai Name row divided into 3 equal columns with vertical dividers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 3) {
                    val swadhyai = swadhyaiList.getOrNull(i)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (swadhyai != null) {
                            Text(
                                text = "${i + 1}. ${swadhyai.fullName.ifBlank { "Swadhyai" }}",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = "-",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (i < 2) {
                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 1.dp),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllotmentDialog(
    unallottedSanghs: List<ParyushanFormEntity>,
    onDismiss: () -> Unit,
    onSanghSelected: (ParyushanFormEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    val filteredSanghs = remember(unallottedSanghs, searchQuery) {
        if (searchQuery.isBlank()) unallottedSanghs
        else {
            val q = searchQuery.trim().lowercase()
            unallottedSanghs.filter {
                it.cityName.lowercase().contains(q) ||
                it.stateName.lowercase().contains(q) ||
                it.sanghName.lowercase().contains(q)
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sangh Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the sangh for allotment",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_sangh_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search City/State", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.ContainerBox(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // List of Sangh Registrations
                if (filteredSanghs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Sangh available for allotment" else "No matching Sangh found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSanghs, key = { it.id }) { sangh ->
                            Card(
                                onClick = { onSanghSelected(sangh) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sangh.sanghName,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.5.sp
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiAllotmentDialog(
    sangh: ParyushanFormEntity,
    allSwadhyaiForms: List<SwadhyaiFormEntity>,
    initiallySelectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onSelectionChanged: (List<Long>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(initiallySelectedIds) }
    val focusRequester = remember { FocusRequester() }

    val filteredSwadhyaiList = remember(allSwadhyaiForms, searchQuery) {
        if (searchQuery.isBlank()) allSwadhyaiForms
        else {
            val q = searchQuery.trim().lowercase()
            allSwadhyaiForms.filter {
                it.fullName.lowercase().contains(q) ||
                it.city.lowercase().contains(q) ||
                convertHindiToEnglishCity(it.city).lowercase().contains(q)
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Swadhyai Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the swadhyai for the allotment of ${sangh.sanghName}, ${sangh.cityName}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_swadhyai_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search Name/City", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.ContainerBox(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Counter bar (Selected: X / 3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Selected: ${selectedIds.size} / 3",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    Button(
                        onClick = onDismiss,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Done", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Swadhyai List
                if (filteredSwadhyaiList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Swadhyai registrations available" else "No matching Swadhyai found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSwadhyaiList, key = { it.id }) { swadhyai ->
                            val isSelected = selectedIds.contains(swadhyai.id)
                            Card(
                                onClick = {
                                    val newSet = selectedIds.toMutableSet()
                                    if (isSelected) {
                                        newSet.remove(swadhyai.id)
                                    } else {
                                        if (newSet.size < 3) {
                                            newSet.add(swadhyai.id)
                                        }
                                    }
                                    selectedIds = newSet
                                    val updatedList = newSet.toList()
                                    onSelectionChanged(updatedList)

                                    if (!isSelected && newSet.size == 3) {
                                        onDismiss()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 0.5.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = swadhyai.fullName.ifBlank { "Swadhyai" },
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        if (swadhyai.city.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = swadhyai.city,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            )
                                        }
                                    }

                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = null
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
