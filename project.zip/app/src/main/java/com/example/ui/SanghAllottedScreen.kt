package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.ParyushanFormEntity
import com.example.data.SwadhyaiFormEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllottedScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allForms by viewModel.allForms.collectAsState()
    val allSwadhyaiForms by viewModel.allSwadhyaiForms.collectAsState()
    val allAllotments by viewModel.allAllotments.collectAsState()

    var showSanghDialog by remember { mutableStateOf(false) }
    var selectedSanghForSwadhyaiAllotment by remember { mutableStateOf<ParyushanFormEntity?>(null) }
    var selectedAllotmentForOptions by remember { mutableStateOf<Pair<ParyushanFormEntity, List<SwadhyaiFormEntity>>?>(null) }
    var selectedAllotmentForSwadhyaiShare by remember { mutableStateOf<Pair<ParyushanFormEntity, List<SwadhyaiFormEntity>>?>(null) }
    var selectedAllotmentForSanghShare by remember { mutableStateOf<Pair<ParyushanFormEntity, List<SwadhyaiFormEntity>>?>(null) }

    // Active allotments containing valid swadhyai IDs
    val activeAllotments = remember(allAllotments, allSwadhyaiForms) {
        val swadhyaiMap = allSwadhyaiForms.associateBy { it.id }
        allAllotments.mapNotNull { allotment ->
            val parsedIds = allotment.swadhyaiIds.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .filter { swadhyaiMap.containsKey(it) }
            if (parsedIds.isEmpty()) null
            else allotment to parsedIds
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sangh Allotted",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("allotted_count_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AssignmentTurnedIn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${activeAllotments.size}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSanghDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_allotment_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Sangh Allotment",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (activeAllotments.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Sangh Allotted Yet",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tap the '+' button at the bottom right corner to allocate Swadhyai to a Sangh.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(activeAllotments, key = { it.first.sanghId }) { (allotment, swadhyaiIds) ->
                        val sanghForm = allForms.find { it.id == allotment.sanghId }
                        val sanghName = sanghForm?.sanghName ?: allotment.sanghName
                        val cityName = sanghForm?.cityName ?: allotment.cityName
                        val stateName = sanghForm?.stateName ?: allotment.stateName

                        val swadhyaiMap = remember(allSwadhyaiForms) { allSwadhyaiForms.associateBy { it.id } }
                        val swadhyaiList = swadhyaiIds.mapNotNull { swadhyaiMap[it] }

                        val form = sanghForm ?: ParyushanFormEntity(
                            id = allotment.sanghId,
                            sanghName = allotment.sanghName,
                            cityName = allotment.cityName,
                            stateName = allotment.stateName,
                            sanghAddress = "", contact1 = "", contact2 = "",
                            mulnayakBhagwan = "", totalFamilies = "", hasOtherSangh = "No",
                            gacchList = "", pratikramanTradition = "", hasMusicianGroup = "No",
                            callsOutsideMusician = "No", hasPanchPratikramanPerson = "No",
                            hasToiletFacility = "No", aradhanaSamagriList = "", countRaiPratikraman = "",
                            countDevasiPratikraman = "", countPravachan = "", countSandhyaBhakti = "",
                            mainTrustees = "", agreedToTerms = true
                        )

                        AllottedSanghCard(
                            sanghName = sanghName,
                            cityName = cityName,
                            stateName = stateName,
                            swadhyaiList = swadhyaiList,
                            onClick = {
                                selectedSanghForSwadhyaiAllotment = form
                            },
                            onLongClick = {
                                selectedAllotmentForOptions = form to swadhyaiList
                            }
                        )
                    }
                }
            }
        }
    }

    // Popup 1: Sangh Allotment Dialog
    if (showSanghDialog) {
        val allocatedSanghIds = remember(allAllotments) {
            allAllotments.filter { it.swadhyaiIds.isNotBlank() }.map { it.sanghId }.toSet()
        }
        val unallottedSanghs = remember(allForms, allocatedSanghIds) {
            allForms.filter { !allocatedSanghIds.contains(it.id) }
        }

        SanghAllotmentDialog(
            unallottedSanghs = unallottedSanghs,
            onDismiss = { showSanghDialog = false },
            onSanghSelected = { sangh ->
                showSanghDialog = false
                selectedSanghForSwadhyaiAllotment = sangh
            }
        )
    }

    // Popup 2: Swadhyai Allotment Dialog
    selectedSanghForSwadhyaiAllotment?.let { sangh ->
        val currentAllotment = allAllotments.find { it.sanghId == sangh.id }
        val currentSwadhyaiIds = remember(currentAllotment) {
            currentAllotment?.swadhyaiIds?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()
        }

        // Swadhyais allotted to OTHER sanghs cannot be selected (prevent duplicate)
        val swadhyaiIdsInOtherSanghs = remember(allAllotments, sangh.id) {
            allAllotments.filter { it.sanghId != sangh.id && it.swadhyaiIds.isNotBlank() }
                .flatMap { it.swadhyaiIds.split(",").mapNotNull { idStr -> idStr.trim().toLongOrNull() } }
                .toSet()
        }

        val availableSwadhyaiForms = remember(allSwadhyaiForms, swadhyaiIdsInOtherSanghs) {
            allSwadhyaiForms.filter { !swadhyaiIdsInOtherSanghs.contains(it.id) }
        }

        SwadhyaiAllotmentDialog(
            sangh = sangh,
            allSwadhyaiForms = availableSwadhyaiForms,
            initiallySelectedIds = currentSwadhyaiIds,
            onDismiss = { selectedSanghForSwadhyaiAllotment = null },
            onSelectionChanged = { selectedIds ->
                viewModel.saveAllotment(
                    sanghId = sangh.id,
                    sanghName = sangh.sanghName,
                    cityName = sangh.cityName,
                    stateName = sangh.stateName,
                    swadhyaiIds = selectedIds
                )
            }
        )
    }

    // Long Press Action Options Dialog
    selectedAllotmentForOptions?.let { (sangh, swadhyaiList) ->
        AllotmentActionOptionsDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            onDismiss = { selectedAllotmentForOptions = null },
            onSendToSwadhyay = {
                selectedAllotmentForSwadhyaiShare = sangh to swadhyaiList
                selectedAllotmentForOptions = null
            },
            onSendToSangh = {
                selectedAllotmentForSanghShare = sangh to swadhyaiList
                selectedAllotmentForOptions = null
            },
            onEditAllotment = {
                selectedSanghForSwadhyaiAllotment = sangh
                selectedAllotmentForOptions = null
            }
        )
    }

    // Share to Swadhyay Dialog
    selectedAllotmentForSwadhyaiShare?.let { (sangh, swadhyaiList) ->
        ShareToSwadhyayDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            onDismiss = { selectedAllotmentForSwadhyaiShare = null }
        )
    }

    // Share to Sangh Dialog
    selectedAllotmentForSanghShare?.let { (sangh, swadhyaiList) ->
        ShareToSanghDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            onDismiss = { selectedAllotmentForSanghShare = null }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AllottedSanghCard(
    sanghName: String,
    cityName: String,
    stateName: String,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    val locationText = if (stateName.isNotBlank()) "$cityName / $stateName" else cityName

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("allotted_sangh_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // City / State (Top Left Corner)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = locationText,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sangh Name in Hindi as inputted
            Text(
                text = sanghName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // Swadhyai Name row divided into 3 equal columns with vertical dividers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 3) {
                    val swadhyai = swadhyaiList.getOrNull(i)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (swadhyai != null) {
                            Text(
                                text = swadhyai.fullName.ifBlank { "Swadhyai" },
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = "-",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (i < 2) {
                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 1.dp),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllotmentDialog(
    unallottedSanghs: List<ParyushanFormEntity>,
    onDismiss: () -> Unit,
    onSanghSelected: (ParyushanFormEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    val filteredSanghs = remember(unallottedSanghs, searchQuery) {
        if (searchQuery.isBlank()) unallottedSanghs
        else {
            val q = searchQuery.trim().lowercase()
            unallottedSanghs.filter {
                it.cityName.lowercase().contains(q) ||
                it.stateName.lowercase().contains(q) ||
                it.sanghName.lowercase().contains(q)
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sangh Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the sangh for allotment",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_sangh_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search City/State", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.Container(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // List of Sangh Registrations
                if (filteredSanghs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Sangh available for allotment" else "No matching Sangh found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSanghs, key = { it.id }) { sangh ->
                            Card(
                                onClick = { onSanghSelected(sangh) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sangh.sanghName,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.5.sp
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiAllotmentDialog(
    sangh: ParyushanFormEntity,
    allSwadhyaiForms: List<SwadhyaiFormEntity>,
    initiallySelectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onSelectionChanged: (List<Long>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(initiallySelectedIds) }
    val focusRequester = remember { FocusRequester() }

    val filteredSwadhyaiList = remember(allSwadhyaiForms, searchQuery) {
        if (searchQuery.isBlank()) allSwadhyaiForms
        else {
            val q = searchQuery.trim().lowercase()
            allSwadhyaiForms.filter {
                it.fullName.lowercase().contains(q) ||
                it.city.lowercase().contains(q) ||
                convertHindiToEnglishCity(it.city).lowercase().contains(q)
            }
        }
    }

    LaunchedEffect(Unit) {
        focusRequester.requestFocus()
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.85f)
                .padding(vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Swadhyai Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the swadhyai for the allotment of ${sangh.sanghName}, ${sangh.cityName}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_swadhyai_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search Name/City", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.Container(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Counter bar (Selected: X / 3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Selected: ${selectedIds.size} / 3",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    Button(
                        onClick = onDismiss,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Done", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Swadhyai List
                if (filteredSwadhyaiList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Swadhyai registrations available" else "No matching Swadhyai found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSwadhyaiList, key = { it.id }) { swadhyai ->
                            val isSelected = selectedIds.contains(swadhyai.id)
                            Card(
                                onClick = {
                                    val newSet = selectedIds.toMutableSet()
                                    if (isSelected) {
                                        newSet.remove(swadhyai.id)
                                    } else {
                                        if (newSet.size < 3) {
                                            newSet.add(swadhyai.id)
                                        }
                                    }
                                    selectedIds = newSet
                                    val updatedList = newSet.toList()
                                    onSelectionChanged(updatedList)

                                    if (!isSelected && newSet.size == 3) {
                                        onDismiss()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 0.5.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = swadhyai.fullName.ifBlank { "Swadhyai" },
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        if (swadhyai.city.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = swadhyai.city,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            )
                                        }
                                    }

                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = null
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AllotmentActionOptionsDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onDismiss: () -> Unit,
    onSendToSwadhyay: () -> Unit,
    onSendToSangh: () -> Unit,
    onEditAllotment: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Text(
                    text = sangh.sanghName,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                if (sangh.cityName.isNotBlank()) {
                    Text(
                        text = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(16.dp))

                // Option 1: Send detail to Swadhyay
                Card(
                    onClick = onSendToSwadhyay,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Send detail to Swadhyay",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Share Sangh registration details to all allotted Swadhyayis on WhatsApp",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.5.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Option 2: Send detail to Sangh
                Card(
                    onClick = onSendToSangh,
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Send detail to Sangh",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Share allotted Swadhyai(s) details to Sangh contact person on WhatsApp",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.5.sp
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Option 3: Edit Allotment
                OutlinedCard(
                    onClick = onEditAllotment,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(14.dp))
                        Text(
                            text = "Edit Swadhyai Allotment",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
fun ShareToSwadhyayDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val message = remember(sangh, swadhyaiList) { buildMessageForSwadhyai(sangh, swadhyaiList) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Send detail to Swadhyay",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = "${sangh.sanghName}, ${sangh.cityName}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        shareText(context, message, "Send Sangh Details to Swadhyay")
                    },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Share to All Swadhyayi (1-Click)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                val availablePhones = remember(swadhyaiList) {
                    swadhyaiList.mapNotNull { s ->
                        val phone = s.whatsappNo.ifBlank { s.contactNo }.trim()
                        if (phone.isNotBlank()) s to phone else null
                    }
                }

                if (availablePhones.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Direct WhatsApp Message:",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        availablePhones.forEach { (swadhyai, phone) ->
                            OutlinedButton(
                                onClick = {
                                    openWhatsApp(context, phone, message)
                                },
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "💬 WhatsApp ${swadhyai.fullName.ifBlank { "Swadhyai" }} ($phone)",
                                    fontSize = 12.5.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

@Composable
fun ShareToSanghDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val message = remember(sangh, swadhyaiList) { buildMessageForSangh(sangh, swadhyaiList) }
    val sanghPhone = remember(sangh) { sangh.contact2.ifBlank { sangh.contact1 }.trim() }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Send detail to Sangh",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        )
                        Text(
                            text = "${sangh.sanghName}, ${sangh.cityName}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 220.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        Text(
                            text = message,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (sanghPhone.isNotBlank()) {
                    Button(
                        onClick = {
                            openWhatsApp(context, sanghPhone, message)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text(
                            text = "💬 WhatsApp Sangh Contact ($sanghPhone)",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                OutlinedButton(
                    onClick = {
                        shareText(context, message, "Send Swadhyai Details to Sangh")
                    },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Share via WhatsApp / App Chooser",
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.5.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Close")
                }
            }
        }
    }
}

private fun buildMessageForSwadhyai(sangh: ParyushanFormEntity, swadhyaiList: List<SwadhyaiFormEntity>): String {
    val swadhyaiTeam = swadhyaiList.mapIndexed { idx, s ->
        "• Swadhyai ${idx + 1}: ${s.fullName.ifBlank { "N/A" }} (${s.city.ifBlank { "N/A" }}) - Ph: ${s.whatsappNo.ifBlank { s.contactNo.ifBlank { "N/A" } }}"
    }.joinToString("\n")

    return """
    *श्री वर्धमान स्वाध्यायी मंडल*
    *पर्वाधीराज पर्यूषण आराधना - संघ विवरण*
    ======================================
    जय जिनेंद्र!
    पर्यूषण महापर्व की आराधना हेतु संघ आवंटन का विवरण:
    
    *१. श्री संघ:* ${sangh.sanghName}
    *२. शहर/गांव:* ${if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName}
    *३. पता:* ${sangh.sanghAddress.ifBlank { "निर्दिष्ट नहीं" }}
    *४. संपर्क व्यक्ति:* ${sangh.contact1.ifBlank { "निर्दिष्ट नहीं" }}
    *५. WhatsApp नंबर:* ${sangh.contact2.ifBlank { "निर्दिष्ट नहीं" }}
    *६. मुलनायक भगवान:* ${sangh.mulnayakBhagwan.ifBlank { "निर्दिष्ट नहीं" }}
    *७. संघ में कुल परिवार:* ${sangh.totalFamilies.ifBlank { "निर्दिष्ट नहीं" }}
    
    *आबंटित स्वाध्यायी टीम:*
    $swadhyaiTeam
    ======================================
    जय जिनेंद्र!
    """.trimIndent()
}

private fun buildMessageForSangh(sangh: ParyushanFormEntity, swadhyaiList: List<SwadhyaiFormEntity>): String {
    val swadhyaiDetails = swadhyaiList.mapIndexed { idx, s ->
        """
        *स्वाध्यायी ${idx + 1}:* ${s.fullName.ifBlank { "N/A" }}
        • शहर: ${s.city.ifBlank { "N/A" }} (${s.state.ifBlank { "" }})
        • WhatsApp / मोबाइल: ${s.whatsappNo.ifBlank { s.contactNo.ifBlank { "N/A" } }}
        • विशेषता / अनुभव: ${s.specialities.ifBlank { "निर्दिष्ट नहीं" }}
        """.trimIndent()
    }.joinToString("\n--------------------------------------\n")

    return """
    *श्री वर्धमान स्वाध्यायी मंडल*
    *पर्वाधीराज पर्यूषण आराधना - स्वाध्यायी विवरण*
    ======================================
    आदरणीय संघ अधिकारी (श्री ${sangh.sanghName}, ${sangh.cityName}),
    
    जय जिनेंद्र!
    पर्यूषण महापर्व की आराधना हेतु आपके संघ में निम्नलिखित स्वाध्यायी जी आवंटित किए गए हैं:
    
    $swadhyaiDetails
    ======================================
    कृपया स्वाध्यायी बंधुओं से संपर्क स्थापित करें।
    जय जिनेंद्र!
    """.trimIndent()
}

private fun openWhatsApp(context: Context, phoneNumber: String, message: String) {
    val cleanPhone = phoneNumber.filter { it.isDigit() }.let {
        if (it.length == 10) "91$it" else it
    }
    if (cleanPhone.isNotEmpty()) {
        val url = "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        try {
            context.startActivity(intent)
            return
        } catch (e: Exception) {
            // Fallback to chooser
        }
    }
    shareText(context, message, "Share via WhatsApp")
}

private fun shareText(context: Context, text: String, title: String = "Share") {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, title))
}
