package com.example.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.data.SwadhyaiFormEntity
import com.example.utils.SanghPdfGenerator
import com.example.utils.SanghPdfItem
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.FileProvider
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.foundation.lazy.itemsIndexed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllottedScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val allForms by viewModel.allForms.collectAsState()
    val allSwadhyaiForms by viewModel.allSwadhyaiForms.collectAsState()
    val allAllotments by viewModel.allAllotments.collectAsState()
    val allFundTransactions by viewModel.allFundTransactions.collectAsState()
    val allFundPersons by viewModel.allFundPersons.collectAsState()
    val personCashBalances by viewModel.personCashBalances.collectAsState()
    val totalBankFund by viewModel.totalBankFund.collectAsState()

    var showSanghDialog by remember { mutableStateOf(false) }
    var selectedSanghForSwadhyaiAllotment by remember { mutableStateOf<ParyushanFormEntity?>(null) }
    var selectedAllotmentForOptions by remember { mutableStateOf<Triple<ParyushanFormEntity, List<SwadhyaiFormEntity>, Double>?>(null) }
    var selectedAllotmentForSwadhyaiShare by remember { mutableStateOf<Pair<ParyushanFormEntity, List<SwadhyaiFormEntity>>?>(null) }
    var selectedAllotmentForSanghShare by remember { mutableStateOf<Pair<ParyushanFormEntity, List<SwadhyaiFormEntity>>?>(null) }
    var selectedSanghForDonation by remember { mutableStateOf<ParyushanFormEntity?>(null) }
    var pdfFileToView by remember { mutableStateOf<File?>(null) }
    var showNoDonationWarningDialog by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var showFinalTransferConfirmationDialog by remember { mutableStateOf(false) }
    var archiveErrorMessage by remember { mutableStateOf<String?>(null) }
    val haptic = LocalHapticFeedback.current
    val contextForPdf = LocalContext.current

    // Active allotments containing valid swadhyai IDs
    val activeAllotments = remember(allAllotments, allSwadhyaiForms) {
        val swadhyaiMap = allSwadhyaiForms.associateBy { it.id }
        allAllotments.mapNotNull { allotment ->
            val parsedIds = allotment.swadhyaiIds.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .filter { swadhyaiMap.containsKey(it) }
            if (parsedIds.isEmpty()) null
            else allotment to parsedIds
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Sangh Allotted",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    if (activeAllotments.isNotEmpty()) {
                        IconButton(
                            onClick = {
                                val pdfItems = activeAllotments.mapIndexed { index, (allotment, swadhyaiIds) ->
                                    val sanghForm = allForms.find { it.id == allotment.sanghId }
                                    val sanghName = sanghForm?.sanghName ?: allotment.sanghName
                                    val cityName = sanghForm?.cityName ?: allotment.cityName
                                    val stateName = sanghForm?.stateName ?: allotment.stateName
                                    val sanghCityState = if (cityName.isNotBlank() && stateName.isNotBlank()) {
                                        "$cityName, $stateName"
                                    } else if (cityName.isNotBlank()) {
                                        cityName
                                    } else {
                                        stateName
                                    }

                                    val contact1 = sanghForm?.contact1.orEmpty()
                                    val contact2 = sanghForm?.contact2.orEmpty()

                                    val swadhyaiMap = allSwadhyaiForms.associateBy { it.id }
                                    val swadhyaiForms = swadhyaiIds.mapNotNull { swadhyaiMap[it] }
                                    val swadhyaiListText = swadhyaiForms.mapIndexed { idx, sw ->
                                        val swCity = if (sw.city.isNotBlank()) "(${sw.city})" else ""
                                        val phone = if (sw.whatsappNo.isNotBlank()) sw.whatsappNo else sw.contactNo
                                        val phoneStr = if (phone.isNotBlank()) " - $phone" else ""
                                        "${if (swadhyaiForms.size > 1) "${idx + 1}. " else ""}${sw.fullName} $swCity$phoneStr".trim()
                                    }

                                    SanghPdfItem(
                                        sNo = index + 1,
                                        sanghName = sanghName,
                                        sanghCityState = sanghCityState,
                                        sanghContactName = contact1,
                                        sanghContactPhone = contact2,
                                        swadhyaiListText = swadhyaiListText
                                    )
                                }
                                val file = SanghPdfGenerator.generatePdf(contextForPdf, pdfItems)
                                pdfFileToView = file
                            },
                            modifier = Modifier.testTag("export_pdf_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PictureAsPdf,
                                contentDescription = "PDF जनरेट करें",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(end = 12.dp)
                            .testTag("allotted_count_badge")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AssignmentTurnedIn,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "${activeAllotments.size}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.5.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showSanghDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                shape = CircleShape,
                modifier = Modifier
                    .padding(16.dp)
                    .testTag("add_allotment_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Sangh Allotment",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (activeAllotments.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No Sangh Allotted Yet",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Tap the '+' button at the bottom right corner to allocate Swadhyai to a Sangh.",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(activeAllotments, key = { it.first.sanghId }) { (allotment, swadhyaiIds) ->
                        val sanghForm = allForms.find { it.id == allotment.sanghId }
                        val sanghName = sanghForm?.sanghName ?: allotment.sanghName
                        val cityName = sanghForm?.cityName ?: allotment.cityName
                        val stateName = sanghForm?.stateName ?: allotment.stateName

                        val swadhyaiMap = remember(allSwadhyaiForms) { allSwadhyaiForms.associateBy { it.id } }
                        val swadhyaiList = swadhyaiIds.mapNotNull { swadhyaiMap[it] }

                        val form = sanghForm ?: ParyushanFormEntity(
                            id = allotment.sanghId,
                            sanghName = allotment.sanghName,
                            cityName = allotment.cityName,
                            stateName = allotment.stateName,
                            sanghAddress = "", contact1 = "", contact2 = "",
                            mulnayakBhagwan = "", totalFamilies = "", hasOtherSangh = "No",
                            gacchList = "", pratikramanTradition = "", hasMusicianGroup = "No",
                            callsOutsideMusician = "No", hasPanchPratikramanPerson = "No",
                            hasToiletFacility = "No", aradhanaSamagriList = "", countRaiPratikraman = "",
                            countDevasiPratikraman = "", countPravachan = "", countSandhyaBhakti = "",
                            mainTrustees = "", agreedToTerms = true
                        )

                        val sanghDonations = remember(allFundTransactions, sanghName, cityName) {
                            allFundTransactions
                                .filter { tx ->
                                    tx.type == "INCOMING" && (
                                        (sanghName.isNotBlank() && tx.description.contains(sanghName, ignoreCase = true)) ||
                                        (sanghName.isNotBlank() && tx.personName.contains(sanghName, ignoreCase = true))
                                    )
                                }
                                .sumOf { it.amount }
                        }

                        AllottedSanghCard(
                            sanghName = sanghName,
                            cityName = cityName,
                            stateName = stateName,
                            donationAmount = sanghDonations,
                            swadhyaiList = swadhyaiList,
                            onClick = {},
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedAllotmentForOptions = Triple(form, swadhyaiList, sanghDonations)
                            }
                        )
                    }

                    if (activeAllotments.isNotEmpty()) {
                        item {
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = {
                                    val nonDonatedSanghs = activeAllotments.mapNotNull { (allotment, _) ->
                                        val sanghForm = allForms.find { it.id == allotment.sanghId }
                                        val sName = sanghForm?.sanghName ?: allotment.sanghName
                                        val cName = sanghForm?.cityName ?: allotment.cityName
                                        val donation = allFundTransactions
                                            .filter { tx ->
                                                !tx.isDeleted && tx.type == "INCOMING" && (
                                                    (sName.isNotBlank() && tx.description.contains(sName, ignoreCase = true)) ||
                                                    (sName.isNotBlank() && tx.personName.contains(sName, ignoreCase = true))
                                                )
                                            }
                                            .sumOf { it.amount }
                                        if (donation <= 0.0) {
                                            Pair(sName, cName)
                                        } else null
                                    }

                                    if (nonDonatedSanghs.isNotEmpty()) {
                                        showNoDonationWarningDialog = nonDonatedSanghs
                                    } else {
                                        showFinalTransferConfirmationDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("complete_paryushan_aradhana_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF1B5E20)
                                ),
                                elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TaskAlt,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "पर्यूषण आराधन संपूर्ण",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = Color.White
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(40.dp))
                        }
                    }
                }
            }
        }
    }

    // Popup 1: Sangh Allotment Dialog
    if (showSanghDialog) {
        val allocatedSanghIds = remember(allAllotments) {
            allAllotments.filter { it.swadhyaiIds.isNotBlank() }.map { it.sanghId }.toSet()
        }
        val unallottedSanghs = remember(allForms, allocatedSanghIds) {
            allForms.filter { !allocatedSanghIds.contains(it.id) }
        }

        SanghAllotmentDialog(
            unallottedSanghs = unallottedSanghs,
            onDismiss = { showSanghDialog = false },
            onSanghSelected = { sangh ->
                showSanghDialog = false
                selectedSanghForSwadhyaiAllotment = sangh
            }
        )
    }

    // Popup 2: Swadhyai Allotment Dialog
    selectedSanghForSwadhyaiAllotment?.let { sangh ->
        val currentAllotment = allAllotments.find { it.sanghId == sangh.id }
        val currentSwadhyaiIds = remember(currentAllotment) {
            currentAllotment?.swadhyaiIds?.split(",")?.mapNotNull { it.trim().toLongOrNull() }?.toSet() ?: emptySet()
        }

        // Swadhyais allotted to OTHER sanghs cannot be selected (prevent duplicate)
        val swadhyaiIdsInOtherSanghs = remember(allAllotments, sangh.id) {
            allAllotments.filter { it.sanghId != sangh.id && it.swadhyaiIds.isNotBlank() }
                .flatMap { it.swadhyaiIds.split(",").mapNotNull { idStr -> idStr.trim().toLongOrNull() } }
                .toSet()
        }

        val availableSwadhyaiForms = remember(allSwadhyaiForms, swadhyaiIdsInOtherSanghs) {
            allSwadhyaiForms.filter { !swadhyaiIdsInOtherSanghs.contains(it.id) }
        }

        SwadhyaiAllotmentDialog(
            sangh = sangh,
            allSwadhyaiForms = availableSwadhyaiForms,
            initiallySelectedIds = currentSwadhyaiIds,
            onDismiss = { selectedSanghForSwadhyaiAllotment = null },
            onSelectionChanged = { selectedIds ->
                viewModel.saveAllotment(
                    sanghId = sangh.id,
                    sanghName = sangh.sanghName,
                    cityName = sangh.cityName,
                    stateName = sangh.stateName,
                    swadhyaiIds = selectedIds
                )
            }
        )
    }

    // Long Press Action Options Dialog
    val context = LocalContext.current
    selectedAllotmentForOptions?.let { (sangh, swadhyaiList, sanghDonations) ->
        AllotmentActionOptionsDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            donationAmount = sanghDonations,
            onDismiss = { selectedAllotmentForOptions = null },
            onSendToSwadhyay = {
                selectedAllotmentForSwadhyaiShare = sangh to swadhyaiList
                selectedAllotmentForOptions = null
            },
            onSendToSangh = {
                val sanghPhone = sangh.contact2.ifBlank { sangh.contact1 }.trim()
                val message = buildMessageForSangh(sangh, swadhyaiList)
                selectedAllotmentForOptions = null
                if (sanghPhone.isNotBlank()) {
                    openWhatsApp(context, sanghPhone, message)
                } else {
                    selectedAllotmentForSanghShare = sangh to swadhyaiList
                }
            },
            onEditAllotment = {
                selectedSanghForSwadhyaiAllotment = sangh
                selectedAllotmentForOptions = null
            },
            onAddDonation = {
                selectedSanghForDonation = sangh
                selectedAllotmentForOptions = null
            }
        )
    }

    // Add or Update Donation Dialog
    selectedSanghForDonation?.let { sangh ->
        val availablePersons = remember(allFundPersons, personCashBalances) {
            (allFundPersons.map { it.name } + personCashBalances.keys).filter { it.isNotBlank() }.distinct()
        }
        val defaultDesc = if (sangh.cityName.isNotBlank()) "${sangh.sanghName}, ${sangh.cityName}" else sangh.sanghName
        val sanghName = sangh.sanghName

        val existingDonationTx = remember(allFundTransactions, sanghName) {
            allFundTransactions.firstOrNull { tx ->
                tx.type == "INCOMING" && (
                    (sanghName.isNotBlank() && tx.description.contains(sanghName, ignoreCase = true)) ||
                    (sanghName.isNotBlank() && tx.personName.contains(sanghName, ignoreCase = true))
                )
            }
        }

        AddOrEditTransactionDialog(
            type = "INCOMING",
            editingTransaction = existingDonationTx,
            initialDescription = defaultDesc,
            availablePersons = availablePersons,
            personCashBalances = personCashBalances,
            totalBankFund = totalBankFund,
            onAddPerson = { viewModel.addFundPerson(it) },
            onDeletePerson = { viewModel.deleteFundPerson(it) },
            onDismiss = { selectedSanghForDonation = null },
            onConfirm = { mode, personName, dateMillis, amount, description ->
                if (existingDonationTx != null) {
                    val oldTx = existingDonationTx
                    val currencyFormatter = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("en", "IN"))
                    val changes = mutableListOf<String>()
                    val nowStr = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())

                    if (kotlin.math.abs(oldTx.amount - amount) > 0.001) {
                        changes.add("Amount changed from ${currencyFormatter.format(oldTx.amount)} to ${currencyFormatter.format(amount)} on $nowStr")
                    }
                    if (oldTx.description.trim() != description.trim()) {
                        val oldDesc = oldTx.description.ifEmpty { "None" }
                        val newDesc = description.trim().ifEmpty { "None" }
                        changes.add("Notes changed from '$oldDesc' to '$newDesc' on $nowStr")
                    }
                    if (oldTx.mode != mode || (mode == "CASH" && oldTx.personName != personName)) {
                        val oldModeStr = if (oldTx.mode == "BANK") "Bank" else "Cash (${oldTx.personName})"
                        val newModeStr = if (mode == "BANK") "Bank" else "Cash ($personName)"
                        changes.add("Mode changed from $oldModeStr to $newModeStr on $nowStr")
                    }
                    if (changes.isEmpty()) {
                        changes.add("Donation details updated on $nowStr")
                    }

                    val newHistory = if (oldTx.editHistory.isBlank()) {
                        changes.joinToString("\n")
                    } else {
                        "${oldTx.editHistory}\n${changes.joinToString("\n")}"
                    }

                    val updatedTx = oldTx.copy(
                        mode = mode,
                        amount = amount,
                        description = description.trim(),
                        personName = if (mode == "CASH") personName else "",
                        date = dateMillis,
                        isEdited = true,
                        editHistory = newHistory
                    )
                    viewModel.updateFundTransaction(updatedTx)
                } else {
                    viewModel.addFundTransaction(
                        type = "INCOMING",
                        mode = mode,
                        amount = amount,
                        title = "Donation",
                        description = description,
                        personName = if (mode == "CASH") personName else "",
                        date = dateMillis
                    )
                }
                selectedSanghForDonation = null
            }
        )
    }

    // Share to Swadhyay Dialog
    selectedAllotmentForSwadhyaiShare?.let { (sangh, swadhyaiList) ->
        ShareToSwadhyayDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            onDismiss = { selectedAllotmentForSwadhyaiShare = null }
        )
    }

    // Share to Sangh Dialog
    selectedAllotmentForSanghShare?.let { (sangh, swadhyaiList) ->
        ShareToSanghDialog(
            sangh = sangh,
            swadhyaiList = swadhyaiList,
            onDismiss = { selectedAllotmentForSanghShare = null }
        )
    }

    // PDF Viewer Dialog
    pdfFileToView?.let { file ->
        PdfViewerDialog(
            pdfFile = file,
            onDismiss = { pdfFileToView = null },
            onShare = { pdfFile ->
                sharePdfFile(context, pdfFile)
            }
        )
    }

    // Popup 1: No Donation Warning Dialog
    showNoDonationWarningDialog?.let { nonDonatedList ->
        AlertDialog(
            onDismissRequest = { showNoDonationWarningDialog = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = Color(0xFFE65100),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "यह संघ से कुछ भी राशि प्राप्त नहीं हुई है",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB71C1C)
                    ),
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 280.dp)
                ) {
                    Text(
                        text = "निम्नलिखित संघों से कोई भी दान राशि प्राप्त नहीं हुई है:",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(nonDonatedList) { (sName, cName) ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "• $sName",
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        ),
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (cName.isNotBlank()) {
                                        Text(
                                            text = "($cName)",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(14.dp))
                    Text(
                        text = "Proceed without getting the Donation?",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showNoDonationWarningDialog = null
                        showFinalTransferConfirmationDialog = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                    modifier = Modifier.testTag("confirm_proceed_without_donation")
                ) {
                    Text("Yes")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showNoDonationWarningDialog = null },
                    modifier = Modifier.testTag("cancel_proceed_without_donation")
                ) {
                    Text("No")
                }
            }
        )
    }

    // Popup 2: Final Transfer Confirmation Dialog
    if (showFinalTransferConfirmationDialog) {
        val currentYear = remember { java.util.Calendar.getInstance().get(java.util.Calendar.YEAR) }
        AlertDialog(
            onDismissRequest = { showFinalTransferConfirmationDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.TaskAlt,
                    contentDescription = null,
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text(
                    text = "Transfer to History?",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to transfer the allotment list in the Registration History?",
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showFinalTransferConfirmationDialog = false
                        viewModel.archiveParyushanAradhana(
                            year = currentYear,
                            onSuccess = {
                                android.widget.Toast.makeText(
                                    context,
                                    "पर्यूषण आराधन संपूर्ण - इतिहास में सुरक्षित कर दिया गया है",
                                    android.widget.Toast.LENGTH_LONG
                                ).show()
                            },
                            onError = { err ->
                                archiveErrorMessage = err
                            }
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                    modifier = Modifier.testTag("confirm_final_archive_yes")
                ) {
                    Text("Yes")
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showFinalTransferConfirmationDialog = false },
                    modifier = Modifier.testTag("cancel_final_archive_no")
                ) {
                    Text("No")
                }
            }
        )
    }

    // Error Dialog
    archiveErrorMessage?.let { err ->
        AlertDialog(
            onDismissRequest = { archiveErrorMessage = null },
            title = { Text("Error") },
            text = { Text(err) },
            confirmButton = {
                TextButton(onClick = { archiveErrorMessage = null }) {
                    Text("OK")
                }
            }
        )
    }
}

private fun sharePdfFile(context: Context, pdfFile: File) {
    try {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            pdfFile
        )
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "PDF शेयर करें"))
    } catch (e: Exception) {
        e.printStackTrace()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerDialog(
    pdfFile: File,
    onDismiss: () -> Unit,
    onShare: (File) -> Unit
) {
    var pageBitmaps by remember { mutableStateOf<List<ImageBitmap>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }

    LaunchedEffect(pdfFile) {
        withContext(Dispatchers.IO) {
            try {
                val pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
                val renderer = PdfRenderer(pfd)
                val bitmaps = mutableListOf<ImageBitmap>()
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    val width = page.width * 2
                    val height = page.height * 2
                    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

                    val canvas = android.graphics.Canvas(bitmap)
                    canvas.drawColor(android.graphics.Color.WHITE)

                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmaps.add(bitmap.asImageBitmap())
                    page.close()
                }
                renderer.close()
                pfd.close()
                pageBitmaps = bitmaps
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                isLoading = false
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "संघ एवं निर्धारित स्वाध्यायी (PDF)",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onDismiss) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "बंद करें"
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { onShare(pdfFile) }) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = "शेयर / प्रिंट करें"
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                } else if (pageBitmaps.isEmpty()) {
                    Text(
                        text = "PDF लोडिंग में समस्या आई",
                        modifier = Modifier.align(Alignment.Center),
                        color = MaterialTheme.colorScheme.error
                    )
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        itemsIndexed(pageBitmaps) { pageIdx, bitmap ->
                            Card(
                                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp)
                            ) {
                                Image(
                                    bitmap = bitmap,
                                    contentDescription = "PDF Page ${pageIdx + 1}",
                                    contentScale = ContentScale.FillWidth,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AllottedSanghCard(
    sanghName: String,
    cityName: String,
    stateName: String,
    donationAmount: Double = 0.0,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    val locationText = if (stateName.isNotBlank()) "$cityName / $stateName" else cityName

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("allotted_sangh_card")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            // City / State (Top Left Corner)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = locationText,
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Sangh Name in Hindi as inputted
            Text(
                text = sanghName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(6.dp))

            // Swadhyai Name row divided into 3 equal columns with vertical dividers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(IntrinsicSize.Min),
                verticalAlignment = Alignment.CenterVertically
            ) {
                for (i in 0 until 3) {
                    val swadhyai = swadhyaiList.getOrNull(i)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        if (swadhyai != null) {
                            Text(
                                text = swadhyai.fullName.ifBlank { "Swadhyai" },
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = "-",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (i < 2) {
                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 1.dp),
                            color = MaterialTheme.colorScheme.outlineVariant
                        )
                    }
                }
            }

            // Donation Row below allotted swadhyai row
            if (donationAmount > 0.0) {
                val currencyFormatter = remember {
                    val format = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("en", "IN"))
                    format.maximumFractionDigits = 0
                    format
                }
                Spacer(modifier = Modifier.height(6.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.35f))
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolunteerActivism,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Donation: ${currencyFormatter.format(donationAmount)}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghAllotmentDialog(
    unallottedSanghs: List<ParyushanFormEntity>,
    onDismiss: () -> Unit,
    onSanghSelected: (ParyushanFormEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    val filteredSanghs = remember(unallottedSanghs, searchQuery) {
        if (searchQuery.isBlank()) unallottedSanghs
        else {
            val q = searchQuery.trim().lowercase()
            unallottedSanghs.filter {
                it.cityName.lowercase().contains(q) ||
                it.stateName.lowercase().contains(q) ||
                it.sanghName.lowercase().contains(q)
            }
        }
    }

    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
        focusRequester.requestFocus()
    }
    val scale by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "sanghAllotmentScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0f,
        animationSpec = tween(150),
        label = "sanghAllotmentAlpha"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.85f)
                    .padding(vertical = 16.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {} // Prevent click through
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.header_logo),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        alpha = 0.18f,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .fillMaxSize(0.65f)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp)
                    ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Sangh Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the sangh for allotment",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_sangh_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search City/State", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.Container(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(14.dp))

                // List of Sangh Registrations
                if (filteredSanghs.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Sangh available for allotment" else "No matching Sangh found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSanghs, key = { it.id }) { sangh ->
                            Card(
                                onClick = { onSanghSelected(sangh) },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sangh.sanghName,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.5.sp
                                            )
                                        )
                                        Spacer(modifier = Modifier.height(3.dp))
                                        Text(
                                            text = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Medium
                                            )
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.LocationOn,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiAllotmentDialog(
    sangh: ParyushanFormEntity,
    allSwadhyaiForms: List<SwadhyaiFormEntity>,
    initiallySelectedIds: Set<Long>,
    onDismiss: () -> Unit,
    onSelectionChanged: (List<Long>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedIds by remember { mutableStateOf(initiallySelectedIds) }
    val focusRequester = remember { FocusRequester() }

    val filteredSwadhyaiList = remember(allSwadhyaiForms, searchQuery) {
        if (searchQuery.isBlank()) allSwadhyaiForms
        else {
            val q = searchQuery.trim().lowercase()
            allSwadhyaiForms.filter {
                it.fullName.lowercase().contains(q) ||
                it.city.lowercase().contains(q) ||
                convertHindiToEnglishCity(it.city).lowercase().contains(q)
            }
        }
    }

    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
        focusRequester.requestFocus()
    }
    val scale by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "sanghAllotmentScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0f,
        animationSpec = tween(150),
        label = "sanghAllotmentAlpha"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.85f)
                    .padding(vertical = 16.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {}
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.header_logo),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        alpha = 0.18f,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .fillMaxSize(0.65f)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp)
                    ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Swadhyai Allotment",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Select the swadhyai for the allotment of ${sangh.sanghName}, ${sangh.cityName}",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 13.sp
                            )
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Search Bar with height 42.dp
                val searchInteractionSource = remember { MutableInteractionSource() }
                BasicTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp)
                        .focusRequester(focusRequester)
                        .testTag("dialog_swadhyai_search_input"),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(
                        fontSize = 13.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true,
                    interactionSource = searchInteractionSource,
                    decorationBox = @Composable { innerTextField ->
                        OutlinedTextFieldDefaults.DecorationBox(
                            value = searchQuery,
                            innerTextField = innerTextField,
                            enabled = true,
                            singleLine = true,
                            visualTransformation = VisualTransformation.None,
                            interactionSource = searchInteractionSource,
                            placeholder = { Text("Search Name/City", fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(
                                        onClick = { searchQuery = "" },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                    }
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            container = {
                                OutlinedTextFieldDefaults.Container(
                                    enabled = true,
                                    isError = false,
                                    interactionSource = searchInteractionSource,
                                    colors = OutlinedTextFieldDefaults.colors(),
                                    shape = RoundedCornerShape(10.dp)
                                )
                            }
                        )
                    }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Counter bar (Selected: X / 3)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Selected: ${selectedIds.size} / 3",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    Button(
                        onClick = onDismiss,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Done", fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Swadhyai List
                if (filteredSwadhyaiList.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (searchQuery.isBlank()) "No Swadhyai registrations available" else "No matching Swadhyai found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                        items(filteredSwadhyaiList, key = { it.id }) { swadhyai ->
                            val isSelected = selectedIds.contains(swadhyai.id)
                            Card(
                                onClick = {
                                    val newSet = selectedIds.toMutableSet()
                                    if (isSelected) {
                                        newSet.remove(swadhyai.id)
                                    } else {
                                        if (newSet.size < 3) {
                                            newSet.add(swadhyai.id)
                                        }
                                    }
                                    selectedIds = newSet
                                    val updatedList = newSet.toList()
                                    onSelectionChanged(updatedList)

                                    if (!isSelected && newSet.size == 3) {
                                        onDismiss()
                                    }
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
                                ),
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 0.5.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = swadhyai.fullName.ifBlank { "Swadhyai" },
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                            )
                                        )
                                        if (swadhyai.city.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(2.dp))
                                            Text(
                                                text = swadhyai.city,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            )
                                        }
                                    }

                                    Checkbox(
                                        checked = isSelected,
                                        onCheckedChange = null
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}
}

@Composable
fun AllotmentActionOptionsDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    donationAmount: Double = 0.0,
    onDismiss: () -> Unit,
    onSendToSwadhyay: () -> Unit,
    onSendToSangh: () -> Unit,
    onEditAllotment: () -> Unit,
    onAddDonation: () -> Unit
) {
    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }

    val offsetY by animateFloatAsState(
        targetValue = if (animateIn) 0f else 220f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetY"
    )

    val offsetX by animateFloatAsState(
        targetValue = if (animateIn) 0f else -75f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetX"
    )

    val animRotation by animateFloatAsState(
        targetValue = if (animateIn) 0f else -5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardRotation"
    )

    val animScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardScale"
    )

    val animAlpha by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0f,
        animationSpec = spring(
            stiffness = Spring.StiffnessHigh
        ),
        label = "cardAlpha"
    )

    val optionsScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "optionsScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .graphicsLayer {
                        translationX = offsetX * density
                        translationY = offsetY * density
                        rotationZ = animRotation
                        scaleX = animScale
                        scaleY = animScale
                        this.alpha = animAlpha
                    }
                    .clickable(enabled = false) {}, // prevent click-through
                horizontalAlignment = Alignment.End
            ) {
                // Centered Animated Card
                AllottedSanghCard(
                    sanghName = sangh.sanghName,
                    cityName = sangh.cityName,
                    stateName = sangh.stateName,
                    donationAmount = donationAmount,
                    swadhyaiList = swadhyaiList,
                    onClick = {},
                    onLongClick = {}
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Options Container anchored at right bottom of card
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .graphicsLayer {
                            scaleX = optionsScale
                            scaleY = optionsScale
                            transformOrigin = androidx.compose.ui.graphics.TransformOrigin(1f, 0f)
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Option 1: Send detail to Swadhyay
                        Surface(
                            onClick = onSendToSwadhyay,
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "1. Send detail to Swadhyay",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }

                        // Option 2: Send detail to Sangh
                        Surface(
                            onClick = onSendToSangh,
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "2. Send detail to Sangh",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }

                        // Option 3: Edit Swadhyai Allotment
                        Surface(
                            onClick = onEditAllotment,
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "3. Edit Swadhyai Allotment",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }

                        // Option 4: Add/Update Donation
                        Surface(
                            onClick = onAddDonation,
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolunteerActivism,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = if (donationAmount > 0.0) "4. Update Donation" else "4. Add Donation",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShareToSwadhyayDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val message = remember(sangh, swadhyaiList) { buildMessageForSwadhyai(sangh, swadhyaiList) }

    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }
    val scale by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "swadhyaiDialogScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0f,
        animationSpec = tween(150),
        label = "swadhyaiDialogAlpha"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(16.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {} // Prevent click through to dismiss background
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Send detail to Swadhyay",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${sangh.sanghName}, ${sangh.cityName}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (swadhyaiList.isEmpty()) {
                        Text(
                            text = "No Swadhyayi allotted to this Sangh yet.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    } else {
                        Text(
                            text = "Allotted Swadhyayis:",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            swadhyaiList.forEachIndexed { idx, swadhyai ->
                                val phone = swadhyai.whatsappNo.ifBlank { swadhyai.contactNo }.trim()
                                Card(
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp)
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = swadhyai.fullName.ifBlank { "Swadhyai ${idx + 1}" },
                                                style = MaterialTheme.typography.titleMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 14.5.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                            )
                                            if (phone.isNotBlank() || swadhyai.city.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(2.dp))
                                                Text(
                                                    text = listOf(swadhyai.city, phone).filter { it.isNotBlank() }.joinToString(" • "),
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        fontSize = 12.sp
                                                    )
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Button(
                                            onClick = {
                                                if (phone.isNotBlank()) {
                                                    openWhatsApp(context, phone, message)
                                                } else {
                                                    shareText(context, message, "Send Sangh Details to ${swadhyai.fullName}")
                                                }
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = MaterialTheme.colorScheme.primary,
                                                contentColor = MaterialTheme.colorScheme.onPrimary
                                            ),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                        ) {
                                            Text(
                                                text = "Send Detail",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.5.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

@Composable
fun ShareToSanghDialog(
    sangh: ParyushanFormEntity,
    swadhyaiList: List<SwadhyaiFormEntity>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val message = remember(sangh, swadhyaiList) { buildMessageForSangh(sangh, swadhyaiList) }
    val sanghPhone = remember(sangh) { sangh.contact2.ifBlank { sangh.contact1 }.trim() }

    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }
    val scale by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0.5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "sanghDialogScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (animateIn) 1f else 0f,
        animationSpec = tween(150),
        label = "sanghDialogAlpha"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .padding(16.dp)
                    .graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        this.alpha = alpha
                    }
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {} // Prevent click through
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Send detail to Sangh",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            )
                            Text(
                                text = "${sangh.sanghName}, ${sangh.cityName}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 220.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            Text(
                                text = message,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (sanghPhone.isNotBlank()) {
                        Button(
                            onClick = {
                                openWhatsApp(context, sanghPhone, message)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Text(
                                text = "💬 WhatsApp Sangh Contact ($sanghPhone)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.5.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    OutlinedButton(
                        onClick = {
                            shareText(context, message, "Send Swadhyai Details to Sangh")
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Share via WhatsApp / App Chooser",
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.5.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    TextButton(
                        onClick = onDismiss,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }
}

private fun formatListItems(raw: String, emptyFallback: String = "निर्दिष्ट नहीं"): String {
    val commaNotInParensRegex = Regex(",(?![^()]*\\))")
    val items = raw.split(commaNotInParensRegex).map { it.trim() }.filter { it.isNotBlank() && it != "null" }
    if (items.isEmpty() || raw.trim() == "कोई नहीं" || raw.trim() == "निर्दिष्ट नहीं") return emptyFallback
    return items.joinToString(", ")
}

private fun formatBulletList(raw: String, emptyFallback: String = "कोई नहीं"): String {
    val commaNotInParensRegex = Regex(",(?![^()]*\\))")
    val items = raw.split(commaNotInParensRegex).map { it.trim() }.filter { it.isNotBlank() && it != "null" }
    if (items.isEmpty() || raw.trim() == "कोई नहीं" || raw.trim() == "निर्दिष्ट नहीं") return emptyFallback
    return items.joinToString("\n") { "• $it" }
}

private fun buildMessageForSwadhyai(sangh: ParyushanFormEntity, swadhyaiList: List<SwadhyaiFormEntity>): String {
    val location = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName
    val traditionFormatted = formatListItems(sangh.pratikramanTradition, "निर्दिष्ट नहीं")
    val toiletFormatted = if (sangh.hasToiletFacility.trim() == "हाँ") "✅ हाँ" else sangh.hasToiletFacility.ifBlank { "निर्दिष्ट नहीं" }
    val samagriFormatted = formatBulletList(sangh.aradhanaSamagriList, "कोई नहीं")

    val swadhyaiTeam = if (swadhyaiList.isEmpty()) "कोई स्वाध्यायी आवंटित नहीं" else swadhyaiList.mapIndexed { idx, s ->
        val cityStr = if (s.city.isNotBlank()) " (${s.city})" else ""
        """
        🔹 स्वाध्यायी ${idx + 1}
        ${s.fullName.ifBlank { "N/A" }}$cityStr
        📞 ${s.whatsappNo.ifBlank { s.contactNo.ifBlank { "N/A" } }}
        """.trimIndent()
    }.joinToString("\n\n")

    return """
    🌸 श्री वर्द्धमान स्वाध्यायी संघ 🌸

    पर्वाधिराज पर्यूषण आराधना – संघ जानकारी

    ━━━━━━━━━━━━━━━━━━

    🙏 जय जिनेंद्र!

    पर्यूषण महापर्व के मौके पर आपकी आराधना के लिए निम्न संघ निर्धारित किया गया है।

    🏛️ संघ का नाम
    ${sangh.sanghName.ifBlank { "निर्दिष्ट नहीं" }}

    📍 स्थान
    ${location.ifBlank { "निर्दिष्ट नहीं" }}

    🏠 पता
    ${sangh.sanghAddress.ifBlank { "निर्दिष्ट नहीं" }}

    👤 संपर्क
    ${sangh.contact1.ifBlank { "निर्दिष्ट नहीं" }}

    📱 मोबाइल / WhatsApp
    ${sangh.contact2.ifBlank { "निर्दिष्ट नहीं" }}

    🛕 मूलनायक भगवान
    ${sangh.mulnayakBhagwan.ifBlank { "निर्दिष्ट नहीं" }}

    📿 प्रतिक्रमण परंपरा
    $traditionFormatted

    🚻 पौषध के लिए शौचालय की व्यवस्था
    $toiletFormatted

    📚 उपलब्ध सामग्री
    $samagriFormatted

    ━━━━━━━━━━━━━━━━━━

    👥 स्वाध्यायी टीम

    $swadhyaiTeam

    ━━━━━━━━━━━━━━━━━━

    🙏 जय जिनेंद्र! 🌼
    """.trimIndent()
}

private fun formatSpecialitiesForSanghMessage(specialitiesRaw: String): String {
    if (specialitiesRaw.isBlank()) {
        return "⭐ विशेषता: निर्दिष्ट नहीं"
    }
    val regex = Regex("(Other:|other:|अन्य:)", RegexOption.IGNORE_CASE)
    val parts = specialitiesRaw.split(regex, 2)
    val spec = parts[0].trim().trimEnd(',', ' ')
    val other = if (parts.size > 1) parts[1].trim() else ""

    return if (other.isNotBlank()) {
        if (spec.isNotBlank()) {
            "⭐ विशेषता: $spec\n➕ अन्य सेवाएँ: $other"
        } else {
            "➕ अन्य सेवाएँ: $other"
        }
    } else {
        "⭐ विशेषता: $spec"
    }
}

private fun buildMessageForSangh(sangh: ParyushanFormEntity, swadhyaiList: List<SwadhyaiFormEntity>): String {
    val sanghLocation = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName
    val swadhyaiDetails = if (swadhyaiList.isEmpty()) "कोई स्वाध्यायी आवंटित नहीं" else swadhyaiList.mapIndexed { idx, s ->
        val cityState = if (s.state.isNotBlank()) "${s.city.ifBlank { "N/A" }} (${s.state})" else s.city.ifBlank { "N/A" }
        val formattedSpec = formatSpecialitiesForSanghMessage(s.specialities)
        """
        👤 स्वाध्यायी ${idx + 1} – ${s.fullName.ifBlank { "N/A" }}

        📍 शहर: $cityState
        📞 मोबाइल: ${s.whatsappNo.ifBlank { s.contactNo.ifBlank { "N/A" } }}
        💼 व्यवसाय: ${s.workingStatus.ifBlank { "निर्दिष्ट नहीं" }}
        📝 कार्य विवरण: ${s.workDescription.ifBlank { "निर्दिष्ट नहीं" }}
        📿 पर्यूषण पर्व की आराधना करवाई है: ${if (s.paryushanCount > 0) "${s.paryushanCount} बार" else "0"}
        $formattedSpec
        """.trimIndent()
    }.joinToString("\n\n━━━━━━━━━━━━━━━━━━\n\n")

    return """
    🌸 श्री वर्द्धमान स्वाध्यायी संघ 🌸

    📖 पर्वाधिराज पर्यूषण आराधना – स्वाध्यायी जानकारी

    ━━━━━━━━━━━━━━━━━━

    🙏 आदरणीय संघ अधिकारी,
    ${sangh.sanghName.ifBlank { "श्री संघ" }}
    📍 ${sanghLocation.ifBlank { "निर्दिष्ट नहीं" }}

    जय जिनेंद्र!

    पर्यूषण महापर्व की आराधना हेतु आपके संघ में निम्न स्वाध्यायी बंधुओं की नियुक्ति की गई है।

    ━━━━━━━━━━━━━━━━━━

    $swadhyaiDetails

    ━━━━━━━━━━━━━━━━━━

    📞 कृपया सभी स्वाध्यायी बंधुओं से समय पर संपर्क स्थापित करें।

    🌼 जय जिनेंद्र! 🌼
    """.trimIndent()
}

private fun isPackageInstalled(pm: android.content.pm.PackageManager, packageName: String): Boolean {
    return try {
        pm.getPackageInfo(packageName, 0)
        true
    } catch (e: Exception) {
        false
    }
}

private fun openWhatsApp(context: Context, phoneNumber: String, message: String) {
    val cleanPhone = phoneNumber.filter { it.isDigit() }.let {
        if (it.length == 10) "91$it" else it
    }
    val uriString = if (cleanPhone.isNotEmpty()) {
        "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
    } else {
        "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
    }
    val uri = Uri.parse(uriString)

    val pm = context.packageManager
    val whatsappInstalled = isPackageInstalled(pm, "com.whatsapp")
    val businessInstalled = isPackageInstalled(pm, "com.whatsapp.w4b")

    val targetIntents = mutableListOf<Intent>()
    if (whatsappInstalled) {
        targetIntents.add(Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
        })
    }
    if (businessInstalled) {
        targetIntents.add(Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp.w4b")
        })
    }

    if (targetIntents.size > 1) {
        // Both WhatsApp & WhatsApp Business installed: force app chooser with both choices
        val mainIntent = targetIntents.removeAt(0)
        val chooserIntent = Intent.createChooser(mainIntent, "Select WhatsApp App").apply {
            putExtra(Intent.EXTRA_INITIAL_INTENTS, targetIntents.toTypedArray())
        }
        try {
            context.startActivity(chooserIntent)
            return
        } catch (e: Exception) {
            // Fallback
        }
    } else if (targetIntents.size == 1) {
        try {
            context.startActivity(targetIntents[0])
            return
        } catch (e: Exception) {
            // Fallback
        }
    }

    // Generic fallback if package detection is unavailable or fails
    val genericIntent = Intent(Intent.ACTION_VIEW, uri)
    val chooser = Intent.createChooser(genericIntent, "Select WhatsApp App")
    try {
        context.startActivity(chooser)
    } catch (e: Exception) {
        shareText(context, message, "Share via WhatsApp")
    }
}

private fun shareText(context: Context, text: String, title: String = "Share") {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text)
    }
    context.startActivity(Intent.createChooser(intent, title))
}
