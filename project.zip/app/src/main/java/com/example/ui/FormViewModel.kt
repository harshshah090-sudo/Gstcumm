package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FormRepository
import com.example.data.ParyushanFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FormViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FormRepository

    val searchQuery = MutableStateFlow("")

    val allForms: StateFlow<List<ParyushanFormEntity>>

    val filteredForms: StateFlow<List<ParyushanFormEntity>>

    init {
        val dao = AppDatabase.getDatabase(application).formDao()
        repository = FormRepository(dao)

        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }

        allForms = repository.allForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredForms = combine(allForms, searchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.sanghName.lowercase().contains(q) ||
                    it.sanghAddress.lowercase().contains(q) ||
                    it.cityName.lowercase().contains(q) ||
                    it.mulnayakBhagwan.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.cityName }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun getFormFlow(id: Long) = repository.getFormFlow(id)

    fun insertForm(form: ParyushanFormEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.insertForm(form)
            onComplete(id)
        }
    }

    fun deleteForm(id: Long) {
        viewModelScope.launch {
            repository.deleteFormById(id)
        }
    }

    fun refreshCloudData() {
        repository.refreshCloudData()
    }

    fun getFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी मंडल*
        *पर्वाधीराज पर्यूषण आराधना २०२६*

        जय जिनेन्द्र 🙏

        पर्यूषणा महापर्व में स्वाध्यायी भाइयों की आराधना प्राप्त करने हेतु आपके श्रीसंघ की संपूर्ण जानकारी दर्ज करने के लिए नीचे दी गई लिंक पर क्लिक करके फॉर्म खोलें:

        📌 फॉर्म लिंक:
        https://svsm-a67d9.web.app

        (यह लिंक किसी भी वेब ब्राउज़र (Chrome/Safari) में खुलती है और सीधे फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी मंडल*
        """.trimIndent()
    }
}
