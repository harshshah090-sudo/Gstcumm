package com.example.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FormRepository
import com.example.data.ParyushanFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.ParyushanCalendarRepository
import com.example.data.SwadhyaiFormEntity
import com.example.data.AllotmentEntity
import com.example.data.FundTransactionEntity
import com.example.data.PanchangEventEntity
import com.example.utils.PanchangNotificationHelper
import com.example.utils.PanchangScannerService
import android.net.Uri
import kotlinx.coroutines.flow.map
import java.text.SimpleDateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

enum class SyncState {
    CONNECTED,
    SYNCING,
    OFFLINE
}

class FormViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FormRepository

    val searchQuery = MutableStateFlow("")
    val swadhyaiSearchQuery = MutableStateFlow("")

    val allForms: StateFlow<List<ParyushanFormEntity>>
    val deletedForms: StateFlow<List<ParyushanFormEntity>>
    val filteredForms: StateFlow<List<ParyushanFormEntity>>

    val allSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>
    val deletedSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>
    val filteredSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>

    val allAllotments: StateFlow<List<AllotmentEntity>>

    val isSanghRegistrationStopped: StateFlow<Boolean>

    val allFundTransactions: StateFlow<List<FundTransactionEntity>>
    val deletedFundTransactions: StateFlow<List<FundTransactionEntity>>
    val allFundPersons: StateFlow<List<com.example.data.FundPersonEntity>>
    val personCashBalances: StateFlow<Map<String, Double>>
    val totalBankFund: StateFlow<Double>
    val totalCashFund: StateFlow<Double>
    val totalFund: StateFlow<Double>

    val allTimelinePosts: StateFlow<List<com.example.data.TimelinePostEntity>>

    val allPanchangEvents: StateFlow<List<PanchangEventEntity>>
    val allRegistrationHistories: StateFlow<List<com.example.data.RegistrationHistoryEntity>>
    val hiddenCalendarEventNames: StateFlow<Set<String>>
    val hiddenRepoEventNames: StateFlow<Set<String>>
    val hiddenEventNames: StateFlow<Set<String>>
    val isScanningPanchang = MutableStateFlow(false)
    val scanPanchangError = MutableStateFlow<String?>(null)
    val extractedPanchangDraft = MutableStateFlow<List<PanchangEventEntity>>(emptyList())

    val isOnline = MutableStateFlow(true)
    val syncStatus: StateFlow<SyncState>

    private fun checkNetworkStatus(): Boolean {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = cm.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkCallback() {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        isOnline.value = true
                        viewModelScope.launch {
                            try {
                                repository.refreshCloudData()
                            } catch (e: Exception) {
                                android.util.Log.e("FormViewModel", "Error refreshing cloud data on network available: ${e.message}")
                            }
                        }
                    }

                    override fun onLost(network: Network) {
                        isOnline.value = checkNetworkStatus()
                    }

                    override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                        val hasInternet = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        val isValidated = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                        isOnline.value = hasInternet && isValidated
                    }

                    override fun onUnavailable() {
                        isOnline.value = false
                    }
                })
            } else {
                val request = NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()
                cm.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        isOnline.value = true
                        viewModelScope.launch {
                            try {
                                repository.refreshCloudData()
                            } catch (e: Exception) {
                                android.util.Log.e("FormViewModel", "Error refreshing cloud data: ${e.message}")
                            }
                        }
                    }

                    override fun onLost(network: Network) {
                        isOnline.value = false
                    }

                    override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                        isOnline.value = networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    }
                })
            }
        } catch (e: Exception) {
            android.util.Log.e("FormViewModel", "Error registering network callback: ${e.message}")
        }
    }

    init {
        val db = AppDatabase.getDatabase(application)
        val dao = db.formDao()
        val swadhyaiDao = db.swadhyaiDao()
        val allotmentDao = db.allotmentDao()
        val fundDao = db.fundDao()
        val fundPersonDao = db.fundPersonDao()
        val panchangDao = db.panchangDao()
        val registrationHistoryDao = db.registrationHistoryDao()
        val timelineDao = db.timelineDao()
        repository = FormRepository(dao, swadhyaiDao, allotmentDao, fundDao, fundPersonDao, panchangDao, registrationHistoryDao, timelineDao, application.applicationContext)

        val initialOnlineStatus = checkNetworkStatus()
        isOnline.value = initialOnlineStatus
        registerNetworkCallback()

        syncStatus = combine(isOnline, repository.isSyncing) { online, syncing ->
            when {
                !online -> SyncState.OFFLINE
                syncing -> SyncState.SYNCING
                else -> SyncState.CONNECTED
            }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = if (initialOnlineStatus) SyncState.CONNECTED else SyncState.OFFLINE
        )

        viewModelScope.launch {
            repository.purgeOldDeletedForms()
            repository.prepopulateIfEmpty()
        }

        allPanchangEvents = repository.allPanchangEvents.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        viewModelScope.launch {
            allPanchangEvents.collect { events ->
                if (events.isNotEmpty()) {
                    PanchangNotificationHelper.scheduleNotificationsForEvents(getApplication(), events)
                }
            }
        }

        hiddenCalendarEventNames = repository.hiddenCalendarEventNames.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptySet()
        )

        hiddenRepoEventNames = repository.hiddenRepoEventNames.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptySet()
        )

        hiddenEventNames = hiddenCalendarEventNames

        allForms = repository.allForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        deletedForms = repository.deletedForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredForms = combine(allForms, searchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.sanghName.lowercase().contains(q) ||
                    it.sanghAddress.lowercase().contains(q) ||
                    it.cityName.lowercase().contains(q) ||
                    it.stateName.lowercase().contains(q) ||
                    it.mulnayakBhagwan.lowercase().contains(q) ||
                    it.contact1.lowercase().contains(q) ||
                    it.mainTrustees.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.cityName }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allSwadhyaiForms = repository.allSwadhyaiForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        deletedSwadhyaiForms = repository.deletedSwadhyaiForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredSwadhyaiForms = combine(
            allSwadhyaiForms,
            swadhyaiSearchQuery,
            com.example.data.UserSessionManager.sessionState
        ) { rawList, query, session ->
            val list = rawList.filter { it.fullName.isNotBlank() }
            val loggedInPhone = session.phone.replace("[^0-9]".toRegex(), "").takeLast(10)
            val withoutLoggedInUser = if (session.isLoggedIn && loggedInPhone.isNotBlank()) {
                list.filterNot { entity ->
                    val entityWhatsapp = entity.whatsappNo.replace("[^0-9]".toRegex(), "").takeLast(10)
                    val entityContact = entity.contactNo.replace("[^0-9]".toRegex(), "").takeLast(10)
                    val idMatch = session.profileData?.id != null && session.profileData?.id != 0L && entity.id == session.profileData?.id
                    val docIdMatch = session.profileData?.firestoreDocId?.isNotBlank() == true && entity.firestoreDocId.isNotBlank() && entity.firestoreDocId == session.profileData?.firestoreDocId
                    entityWhatsapp == loggedInPhone || entityContact == loggedInPhone || idMatch || docIdMatch
                }
            } else {
                list
            }

            val filtered = if (query.isBlank()) {
                withoutLoggedInUser
            } else {
                val q = query.trim().lowercase()
                withoutLoggedInUser.filter {
                    it.fullName.lowercase().contains(q) ||
                    it.city.lowercase().contains(q) ||
                    convertHindiToEnglishCity(it.city).lowercase().contains(q) ||
                    it.state.lowercase().contains(q) ||
                    it.whatsappNo.contains(q) ||
                    it.contactNo.contains(q) ||
                    it.specialities.lowercase().contains(q) ||
                    it.religiousLearnings.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.fullName.trim().lowercase() }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allAllotments = repository.allAllotments.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        isSanghRegistrationStopped = repository.isSanghRegistrationStopped.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

        allFundTransactions = repository.allFundTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

        deletedFundTransactions = repository.deletedFundTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

        allFundPersons = repository.allFundPersons.stateIn(
            scope = viewModelScope,
            started = SharingStarted.Eagerly,
            initialValue = emptyList()
        )

        personCashBalances = combine(allFundPersons, allFundTransactions) { persons, txs ->
            val transferNames = txs.filter { it.type == "TRANSFER" }
                .flatMap { listOf(it.transferFrom, it.transferTo) }
                .filter { it.isNotBlank() && !it.equals("Bank", ignoreCase = true) }

            val personNames = (persons.map { it.name } + txs.filter { it.mode == "CASH" }.map { it.personName } + transferNames)
                .filter { it.isNotBlank() && !it.equals("Bank", ignoreCase = true) }
                .distinct()

            val map = mutableMapOf<String, Double>()
            personNames.forEach { name ->
                var net = 0.0
                txs.forEach { item ->
                    if (item.type == "INCOMING" && item.mode == "CASH" && item.personName.equals(name, ignoreCase = true)) {
                        net += item.amount
                    } else if (item.type == "EXPENDITURE" && item.mode == "CASH" && item.personName.equals(name, ignoreCase = true)) {
                        net -= item.amount
                    } else if (item.type == "TRANSFER") {
                        if (item.transferFrom.equals(name, ignoreCase = true)) {
                            net -= item.amount
                        }
                        if (item.transferTo.equals(name, ignoreCase = true)) {
                            net += item.amount
                        }
                    }
                }
                map[name] = net
            }
            map
        }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

        totalBankFund = allFundTransactions.map { list ->
            var net = 0.0
            list.forEach { item ->
                if (item.type == "INCOMING" && item.mode == "BANK") {
                    net += item.amount
                } else if (item.type == "EXPENDITURE" && item.mode == "BANK") {
                    net -= item.amount
                } else if (item.type == "TRANSFER") {
                    if (item.transferFrom.equals("Bank", ignoreCase = true)) {
                        net -= item.amount
                    }
                    if (item.transferTo.equals("Bank", ignoreCase = true)) {
                        net += item.amount
                    }
                }
            }
            net
        }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

        totalCashFund = personCashBalances.map { map ->
            map.values.sum()
        }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

        totalFund = combine(totalBankFund, totalCashFund) { bank, cash ->
            bank + cash
        }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

        allRegistrationHistories = repository.allRegistrationHistories.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allTimelinePosts = repository.allTimelinePosts.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun addTimelinePost(
        heading: String,
        subHeading: String,
        description: String,
        dateMillis: Long,
        photoUris: List<String> = emptyList(),
        onComplete: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val context = getApplication<Application>().applicationContext
            // Option A: Compress selected photo Uris into compact Base64 strings so they sync to Firestore without Firebase Storage
            val processedPhotos = photoUris.mapNotNull { uriStr ->
                try {
                    com.example.utils.TimelineImageUtils.processUriToBase64(context, uriStr, maxDimension = 800, quality = 75) ?: uriStr
                } catch (e: Exception) {
                    uriStr
                }
            }

            val post = com.example.data.TimelinePostEntity(
                heading = heading.trim(),
                subHeading = subHeading.trim(),
                description = description.trim(),
                dateEpochMillis = dateMillis,
                photoUris = com.example.utils.TimelineImageUtils.serializePhotoUris(processedPhotos),
                createdAtEpochMillis = System.currentTimeMillis()
            )
            repository.insertTimelinePost(post)
            onComplete?.invoke()
        }
    }

    fun updateTimelinePost(
        post: com.example.data.TimelinePostEntity,
        heading: String,
        subHeading: String,
        description: String,
        dateMillis: Long,
        photoUris: List<String> = emptyList(),
        onComplete: (() -> Unit)? = null
    ) {
        viewModelScope.launch {
            val context = getApplication<Application>().applicationContext
            // Option A: Compress any newly added photo Uris into compact Base64 strings
            val processedPhotos = photoUris.mapNotNull { uriStr ->
                try {
                    com.example.utils.TimelineImageUtils.processUriToBase64(context, uriStr, maxDimension = 800, quality = 75) ?: uriStr
                } catch (e: Exception) {
                    uriStr
                }
            }

            val updatedPost = post.copy(
                heading = heading.trim(),
                subHeading = subHeading.trim(),
                description = description.trim(),
                dateEpochMillis = dateMillis,
                photoUris = com.example.utils.TimelineImageUtils.serializePhotoUris(processedPhotos)
            )
            repository.updateTimelinePost(updatedPost)
            onComplete?.invoke()
        }
    }

    fun deleteTimelinePost(postId: Long) {
        viewModelScope.launch {
            repository.deleteTimelinePost(postId)
        }
    }

    fun getParyushanDatesForYear(year: Int): Pair<String, String> {
        val events = allPanchangEvents.value
        val schedule = ParyushanCalendarRepository.getPanchangParyushanSchedule(events, year, com.example.data.JainGacch.TAPAGACCH)
        return if (schedule != null) {
            val startFormatted = ParyushanCalendarRepository.formatDate(schedule.startDateMillis)
            val endFormatted = ParyushanCalendarRepository.formatDate(schedule.endDateMillis)
            Pair(startFormatted, endFormatted)
        } else {
            val staticSch = ParyushanCalendarRepository.allSchedules.find { it.year == year && it.gacch == com.example.data.JainGacch.TAPAGACCH }
            if (staticSch != null) {
                Pair(ParyushanCalendarRepository.formatDate(staticSch.startDateMillis), ParyushanCalendarRepository.formatDate(staticSch.endDateMillis))
            } else {
                Pair("Paryushan $year", "Samvatsari $year")
            }
        }
    }

    fun archiveParyushanAradhana(
        year: Int,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val dates = getParyushanDatesForYear(year)
                val currentForms = allForms.value
                val currentSwadhyayis = allSwadhyaiForms.value
                val currentAllotments = allAllotments.value
                val currentFundTxs = allFundTransactions.value

                val activeAllotmentsList = currentAllotments.map { allotment ->
                    val ids = allotment.swadhyaiIds.split(",")
                        .mapNotNull { it.trim().toLongOrNull() }
                    Pair(allotment, ids)
                }.filter { it.second.isNotEmpty() }

                repository.archiveParyushanAradhana(
                    year = year,
                    paryushanStartDate = dates.first,
                    paryushanEndDate = dates.second,
                    allFormsList = currentForms,
                    allSwadhyaiFormsList = currentSwadhyayis,
                    activeAllotmentsList = activeAllotmentsList,
                    allFundTransactionsList = currentFundTxs
                )
                onSuccess()
            } catch (e: Exception) {
                android.util.Log.e("FormViewModel", "Error archiving Paryushan Aradhana: ${e.message}")
                onError(e.message ?: "Archive failed")
            }
        }
    }

    fun restoreRegistrationHistory(
        year: Int,
        onSuccess: () -> Unit = {},
        onError: (String) -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                repository.restoreRegistrationHistory(year)
                onSuccess()
            } catch (e: Exception) {
                android.util.Log.e("FormViewModel", "Error restoring registration history: ${e.message}")
                onError(e.message ?: "Restore failed")
            }
        }
    }

    fun addFundPerson(name: String) {
        viewModelScope.launch {
            repository.insertFundPerson(name)
        }
    }

    fun addFundTransaction(
        type: String,
        mode: String,
        amount: Double,
        description: String = "",
        personName: String = "",
        title: String = "",
        date: Long = System.currentTimeMillis(),
        transferFrom: String = "",
        transferTo: String = "",
        createdByName: String = ""
    ) {
        viewModelScope.launch {
            val transaction = FundTransactionEntity(
                type = type,
                mode = mode,
                amount = amount,
                title = title,
                description = description,
                personName = personName,
                date = date,
                transferFrom = transferFrom,
                transferTo = transferTo,
                createdByName = createdByName
            )
            repository.insertFundTransaction(transaction)
        }
    }

    fun updateFundTransaction(transaction: FundTransactionEntity) {
        viewModelScope.launch {
            repository.insertFundTransaction(transaction)
        }
    }

    fun deleteFundPerson(personName: String) {
        viewModelScope.launch {
            val person = allFundPersons.value.find { it.name.equals(personName, ignoreCase = true) }
            if (person != null) {
                repository.deleteFundPerson(person)
            }
        }
    }

    data class TransactionStep(
        val tx: FundTransactionEntity,
        val balanceBefore: Double,
        val amountDelta: Double,
        val balanceAfter: Double
    )

    private fun getAffectedAccounts(tx: FundTransactionEntity?): Set<String> {
        if (tx == null) return emptySet()
        val accounts = mutableSetOf<String>()
        if (tx.type == "TRANSFER") {
            if (tx.transferFrom.isNotBlank()) accounts.add(tx.transferFrom)
            if (tx.transferTo.isNotBlank()) accounts.add(tx.transferTo)
        } else {
            if (tx.mode == "BANK") {
                accounts.add("Bank")
            } else if (tx.mode == "CASH" && tx.personName.isNotBlank()) {
                accounts.add(tx.personName)
            }
        }
        return accounts
    }

    private fun simulateAccountTimeline(
        account: String,
        txList: List<FundTransactionEntity>
    ): List<TransactionStep> {
        val isBank = account.equals("Bank", ignoreCase = true)
        val sorted = txList.sortedWith(
            compareBy<FundTransactionEntity> { it.date }
                .thenBy {
                    when (it.type) {
                        "INCOMING" -> 0
                        "TRANSFER" -> 1
                        else -> 2
                    }
                }
                .thenBy { it.id }
        )

        var running = 0.0
        val steps = mutableListOf<TransactionStep>()

        for (item in sorted) {
            var delta = 0.0
            var isRelevant = false

            if (item.type == "INCOMING") {
                if (isBank && item.mode == "BANK") {
                    delta = item.amount
                    isRelevant = true
                } else if (!isBank && item.mode == "CASH" && item.personName.equals(account, ignoreCase = true)) {
                    delta = item.amount
                    isRelevant = true
                }
            } else if (item.type == "EXPENDITURE") {
                if (isBank && item.mode == "BANK") {
                    delta = -item.amount
                    isRelevant = true
                } else if (!isBank && item.mode == "CASH" && item.personName.equals(account, ignoreCase = true)) {
                    delta = -item.amount
                    isRelevant = true
                }
            } else if (item.type == "TRANSFER") {
                if (item.transferFrom.equals(account, ignoreCase = true)) {
                    delta = -item.amount
                    isRelevant = true
                }
                if (item.transferTo.equals(account, ignoreCase = true)) {
                    delta += item.amount
                    isRelevant = true
                }
            }

            if (isRelevant) {
                val before = running
                running += delta
                steps.add(TransactionStep(item, before, delta, running))
            }
        }
        return steps
    }

    private fun getBalanceOnDate(steps: List<TransactionStep>, dateMillis: Long): Double {
        val pastSteps = steps.filter { it.tx.date <= dateMillis }
        return pastSteps.lastOrNull()?.balanceAfter ?: 0.0
    }

    private fun validateProposedChange(
        editingTx: FundTransactionEntity?,
        proposedTx: FundTransactionEntity?,
        actionPrefix: String = "Cannot process:"
    ): Pair<Boolean, String> {
        val dateFormatter = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale("en", "IN"))

        val currentActive = allFundTransactions.value

        val affectedAccounts = (getAffectedAccounts(editingTx) + getAffectedAccounts(proposedTx))
            .filter { it.isNotBlank() }
            .toSet()

        if (affectedAccounts.isEmpty()) return Pair(true, "")

        val simulatedActive = if (editingTx != null) {
            val filtered = currentActive.filterNot { item ->
                if (editingTx.id != 0L && item.id != 0L) {
                    item.id == editingTx.id
                } else if (editingTx.remoteId.isNotBlank() && item.remoteId.isNotBlank()) {
                    item.remoteId == editingTx.remoteId
                } else {
                    false
                }
            }
            if (proposedTx != null) filtered + proposedTx else filtered
        } else {
            if (proposedTx != null) currentActive + proposedTx else currentActive
        }

        for (account in affectedAccounts) {
            val curSteps = simulateAccountTimeline(account, currentActive)
            val simSteps = simulateAccountTimeline(account, simulatedActive)

            for (step in simSteps) {
                if (step.balanceAfter < -0.001) {
                    val curBalAtDate = getBalanceOnDate(curSteps, step.tx.date)
                    // If balance was non-negative on current list OR if proposed change made it worse:
                    if (curBalAtDate >= -0.001 || step.balanceAfter < curBalAtDate - 0.001) {
                        val dateStr = dateFormatter.format(Date(step.tx.date))
                        val displayName = if (account.equals("Bank", ignoreCase = true)) "Bank" else "\"$account\""
                        val formattedRequested = currencyFormat.format(kotlin.math.abs(step.amountDelta))
                        val formattedAvailable = currencyFormat.format(kotlin.math.max(0.0, step.balanceBefore))

                        val msg = if (actionPrefix.contains("delete", ignoreCase = true)) {
                            val amountStr = currencyFormat.format(kotlin.math.abs(step.balanceAfter))
                            "Cannot delete: Deleting this transaction will cause $displayName balance to become negative (-$amountStr)."
                        } else if (actionPrefix.contains("restore", ignoreCase = true)) {
                            val amountStr = currencyFormat.format(kotlin.math.abs(step.balanceAfter))
                            "Cannot restore: Restoring this transaction will cause $displayName balance to become negative (-$amountStr)."
                        } else {
                            val txTypeWord = if (step.tx.type == "TRANSFER") "Transfer" else "Expenditure"
                            "Cannot process: $txTypeWord of $formattedRequested exceeds available balance for $displayName on $dateStr (Available on that date: $formattedAvailable)."
                        }

                        return Pair(false, msg)
                    }
                }
            }
        }

        return Pair(true, "")
    }

    fun canSaveFundTransaction(
        editingTx: FundTransactionEntity?,
        proposedTx: FundTransactionEntity
    ): Pair<Boolean, String> {
        return validateProposedChange(editingTx, proposedTx, "Cannot process:")
    }

    fun canDeleteFundTransaction(transaction: FundTransactionEntity): Pair<Boolean, String> {
        return validateProposedChange(editingTx = transaction, proposedTx = null, "Cannot delete:")
    }

    fun canRestoreFundTransaction(transaction: FundTransactionEntity): Pair<Boolean, String> {
        return validateProposedChange(editingTx = null, proposedTx = transaction, "Cannot restore:")
    }

    fun deleteFundTransaction(transaction: FundTransactionEntity, deletedByName: String = ""): Pair<Boolean, String> {
        val (canDelete, reason) = canDeleteFundTransaction(transaction)
        if (!canDelete) {
            return Pair(false, reason)
        }
        viewModelScope.launch {
            repository.softDeleteFundTransaction(transaction, deletedByName = deletedByName)
        }
        return Pair(true, "")
    }

    fun restoreFundTransaction(transaction: FundTransactionEntity): Pair<Boolean, String> {
        val (canRestore, reason) = canRestoreFundTransaction(transaction)
        if (!canRestore) {
            return Pair(false, reason)
        }
        viewModelScope.launch {
            repository.restoreFundTransaction(transaction)
        }
        return Pair(true, "")
    }

    fun deleteFundTransactionPermanently(transaction: FundTransactionEntity) {
        viewModelScope.launch {
            repository.deleteFundTransactionPermanently(transaction)
        }
    }

    fun setSanghRegistrationStopped(stopped: Boolean) {
        repository.setSanghRegistrationStopped(stopped)
    }

    fun saveAllotment(sanghId: Long, sanghName: String, cityName: String, stateName: String, swadhyaiIds: List<Long>) {
        viewModelScope.launch {
            if (swadhyaiIds.isEmpty()) {
                repository.deleteAllotment(sanghId)
            } else {
                val entity = AllotmentEntity(
                    sanghId = sanghId,
                    sanghName = sanghName,
                    cityName = cityName,
                    stateName = stateName,
                    swadhyaiIds = swadhyaiIds.joinToString(",")
                )
                repository.saveAllotment(entity)
            }
        }
    }

    fun deleteAllotment(sanghId: Long) {
        viewModelScope.launch {
            repository.deleteAllotment(sanghId)
        }
    }

    fun getFormFlow(id: Long) = repository.getFormFlow(id)

    fun insertForm(form: ParyushanFormEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.insertForm(form)
            onComplete(id)
        }
    }

    fun deleteForm(id: Long) {
        viewModelScope.launch {
            repository.softDeleteFormById(id)
        }
    }

    fun updateForm(form: ParyushanFormEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateForm(form)
            onComplete()
        }
    }

    fun restoreForm(id: Long) {
        viewModelScope.launch {
            repository.restoreFormById(id)
        }
    }

    fun deleteFormPermanently(id: Long) {
        viewModelScope.launch {
            repository.deleteFormPermanentlyById(id)
        }
    }

    fun insertSwadhyaiForm(form: SwadhyaiFormEntity, onComplete: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertSwadhyaiForm(form)
            onComplete(id)
        }
    }

    fun updateSwadhyaiForm(form: SwadhyaiFormEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateSwadhyaiForm(form)
            onComplete()
        }
    }

    fun deleteSwadhyaiForm(id: Long) {
        viewModelScope.launch {
            repository.softDeleteSwadhyaiFormById(id)
        }
    }

    fun restoreSwadhyaiForm(id: Long) {
        viewModelScope.launch {
            repository.restoreSwadhyaiFormById(id)
        }
    }

    val adminPhoneNumbers: StateFlow<Set<String>> = com.example.data.UserSessionManager.adminPhoneNumbers

    fun setSwadhyaiAdminStatus(targetPhone: String, newStatus: Boolean, onResult: (Boolean, String?) -> Unit = { _, _ -> }) {
        com.example.data.UserSessionManager.setAdminStatus(targetPhone, newStatus, onResult)
    }

    fun deleteSwadhyaiFormPermanently(id: Long) {
        viewModelScope.launch {
            repository.deleteSwadhyaiFormPermanentlyById(id)
        }
    }

    fun getSwadhyaiFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी संघ*
        *Swadhyai Registration Form*

        जय जिनेन्द्र 🙏

        स्वाध्यायी मंडल से जुड़ने एवं स्वाध्यायी पंजीकरण हेतु नीचे दी गई लिंक पर क्लिक करके फॉर्म भरें:

        📌 स्वाध्यायी फॉर्म लिंक:
        https://svsm-a67d9.web.app/swadhyai.html

        (यह लिंक किसी भी वेब ब्राउज़र में खुलती है और आसानी से फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी संघ*
        """.trimIndent()
    }

    fun refreshCloudData() {
        repository.refreshCloudData()
    }

    fun getFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी मंडल*
        *पर्वाधीराज पर्यूषण आराधना २०२६*

        जय जिनेन्द्र 🙏

        पर्यूषणा महापर्व में स्वाध्यायी भाइयों की आराधना प्राप्त करने हेतु आपके श्रीसंघ की संपूर्ण जानकारी दर्ज करने के लिए नीचे दी गई लिंक पर क्लिक करके फॉर्म खोलें:

        📌 फॉर्म लिंक:
        https://svsm-a67d9.web.app

        (यह लिंक किसी भी वेब ब्राउज़र (Chrome/Safari) में खुलती है और सीधे फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी मंडल*
        """.trimIndent()
    }

    fun scanPanchangImage(
        context: Context,
        imageUri: Uri,
        customApiKey: String? = null,
        allowDemoFallback: Boolean = false
    ) {
        viewModelScope.launch {
            isScanningPanchang.value = true
            scanPanchangError.value = null
            extractedPanchangDraft.value = emptyList()

            if (!customApiKey.isNullOrBlank()) {
                PanchangScannerService.saveCustomApiKey(context, customApiKey)
            }

            val result = PanchangScannerService.analyzePanchangImage(context, imageUri, customApiKey, allowDemoFallback)
            isScanningPanchang.value = false

            if (result.isSuccess) {
                extractedPanchangDraft.value = result.getOrDefault(emptyList())
            } else {
                scanPanchangError.value = result.exceptionOrNull()?.message ?: "Extraction failed"
            }
        }
    }

    fun processPastedPanchangJson(pastedText: String) {
        viewModelScope.launch {
            isScanningPanchang.value = true
            scanPanchangError.value = null
            extractedPanchangDraft.value = emptyList()

            val result = PanchangScannerService.parsePastedTextToEntities(pastedText)
            isScanningPanchang.value = false

            if (result.isSuccess) {
                extractedPanchangDraft.value = result.getOrDefault(emptyList())
            } else {
                scanPanchangError.value = result.exceptionOrNull()?.message ?: "Parsing failed"
            }
        }
    }

    fun saveExtractedDraftPanchangEvents(selectedEvents: List<PanchangEventEntity>) {
        viewModelScope.launch {
            if (selectedEvents.isNotEmpty()) {
                repository.insertPanchangEvents(selectedEvents)
            }
            extractedPanchangDraft.value = emptyList()
            scanPanchangError.value = null
        }
    }

    fun clearPanchangDraft() {
        extractedPanchangDraft.value = emptyList()
        scanPanchangError.value = null
    }

    fun addOrUpdatePanchangEvent(event: PanchangEventEntity) {
        viewModelScope.launch {
            repository.insertPanchangEvent(event)
        }
    }

    fun deletePanchangEvent(id: Long) {
        viewModelScope.launch {
            repository.deletePanchangEvent(id)
        }
    }

    fun deletePanchangEventByDate(dateString: String) {
        viewModelScope.launch {
            repository.deletePanchangEventByDate(dateString)
        }
    }

    fun updateHiddenEventNames(hiddenSet: Set<String>) {
        viewModelScope.launch {
            repository.updateHiddenEventNames(hiddenSet)
        }
    }

    fun updateEventVisibility(hiddenCalendar: Set<String>, hiddenRepo: Set<String>) {
        viewModelScope.launch {
            repository.updateEventVisibility(hiddenCalendar, hiddenRepo)
        }
    }
}
