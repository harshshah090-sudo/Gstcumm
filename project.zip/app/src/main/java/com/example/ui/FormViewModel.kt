package com.example.ui

import android.app.Application
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FormRepository
import com.example.data.ParyushanFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.SwadhyaiFormEntity
import com.example.data.AllotmentEntity
import com.example.data.FundTransactionEntity
import kotlinx.coroutines.flow.map

class FormViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FormRepository

    val searchQuery = MutableStateFlow("")
    val swadhyaiSearchQuery = MutableStateFlow("")

    val allForms: StateFlow<List<ParyushanFormEntity>>
    val deletedForms: StateFlow<List<ParyushanFormEntity>>
    val filteredForms: StateFlow<List<ParyushanFormEntity>>

    val allSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>
    val filteredSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>

    val allAllotments: StateFlow<List<AllotmentEntity>>

    val isSanghRegistrationStopped: StateFlow<Boolean>

    val allFundTransactions: StateFlow<List<FundTransactionEntity>>
    val allFundPersons: StateFlow<List<com.example.data.FundPersonEntity>>
    val personCashBalances: StateFlow<Map<String, Double>>
    val totalBankFund: StateFlow<Double>
    val totalCashFund: StateFlow<Double>
    val totalFund: StateFlow<Double>

    val isOnline = MutableStateFlow(true)

    private fun checkNetworkStatus(): Boolean {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNetwork = cm?.activeNetwork ?: return false
        val capabilities = cm.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun registerNetworkCallback() {
        val cm = getApplication<Application>().getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        try {
            cm?.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    isOnline.value = true
                    viewModelScope.launch {
                        try {
                            repository.refreshCloudData()
                        } catch (e: Exception) {
                            android.util.Log.e("FormViewModel", "Error refreshing cloud data on network available: ${e.message}")
                        }
                    }
                }
                override fun onLost(network: Network) {
                    isOnline.value = checkNetworkStatus()
                }
            })
        } catch (e: Exception) {
            android.util.Log.e("FormViewModel", "Error registering network callback: ${e.message}")
        }
    }

    init {
        val db = AppDatabase.getDatabase(application)
        val dao = db.formDao()
        val swadhyaiDao = db.swadhyaiDao()
        val allotmentDao = db.allotmentDao()
        val fundDao = db.fundDao()
        val fundPersonDao = db.fundPersonDao()
        repository = FormRepository(dao, swadhyaiDao, allotmentDao, fundDao, fundPersonDao, application.applicationContext)

        isOnline.value = checkNetworkStatus()
        registerNetworkCallback()

        viewModelScope.launch {
            repository.purgeOldDeletedForms()
            repository.prepopulateIfEmpty()
        }

        allForms = repository.allForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        deletedForms = repository.deletedForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredForms = combine(allForms, searchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.sanghName.lowercase().contains(q) ||
                    it.sanghAddress.lowercase().contains(q) ||
                    it.cityName.lowercase().contains(q) ||
                    it.stateName.lowercase().contains(q) ||
                    it.mulnayakBhagwan.lowercase().contains(q) ||
                    it.contact1.lowercase().contains(q) ||
                    it.mainTrustees.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.cityName }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allSwadhyaiForms = repository.allSwadhyaiForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredSwadhyaiForms = combine(allSwadhyaiForms, swadhyaiSearchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.fullName.lowercase().contains(q) ||
                    it.city.lowercase().contains(q) ||
                    convertHindiToEnglishCity(it.city).lowercase().contains(q) ||
                    it.state.lowercase().contains(q) ||
                    it.whatsappNo.contains(q) ||
                    it.contactNo.contains(q) ||
                    it.specialities.lowercase().contains(q) ||
                    it.religiousLearnings.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.fullName.trim().lowercase() }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allAllotments = repository.allAllotments.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        isSanghRegistrationStopped = repository.isSanghRegistrationStopped.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false
        )

        allFundTransactions = repository.allFundTransactions.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allFundPersons = repository.allFundPersons.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        personCashBalances = combine(allFundPersons, allFundTransactions) { persons, txs ->
            val cashTxs = txs.filter { it.mode == "CASH" }
            val personNames = (persons.map { it.name } + cashTxs.map { it.personName })
                .filter { it.isNotBlank() }
                .distinct()

            val map = mutableMapOf<String, Double>()
            personNames.forEach { name ->
                val net = cashTxs.filter { it.personName.equals(name, ignoreCase = true) }
                    .fold(0.0) { acc, item ->
                        if (item.type == "INCOMING") acc + item.amount else acc - item.amount
                    }
                map[name] = net
            }
            map
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

        totalBankFund = allFundTransactions.map { list ->
            list.filter { it.mode == "BANK" }.fold(0.0) { acc, item ->
                if (item.type == "INCOMING") acc + item.amount else acc - item.amount
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

        totalCashFund = allFundTransactions.map { list ->
            list.filter { it.mode == "CASH" }.fold(0.0) { acc, item ->
                if (item.type == "INCOMING") acc + item.amount else acc - item.amount
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

        totalFund = combine(totalBankFund, totalCashFund) { bank, cash ->
            bank + cash
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    }

    fun addFundPerson(name: String) {
        viewModelScope.launch {
            repository.insertFundPerson(name)
        }
    }

    fun addFundTransaction(
        type: String,
        mode: String,
        amount: Double,
        description: String = "",
        personName: String = "",
        title: String = "",
        date: Long = System.currentTimeMillis()
    ) {
        viewModelScope.launch {
            val transaction = FundTransactionEntity(
                type = type,
                mode = mode,
                amount = amount,
                title = title,
                description = description,
                personName = personName,
                date = date
            )
            repository.insertFundTransaction(transaction)
        }
    }

    fun updateFundTransaction(transaction: FundTransactionEntity) {
        viewModelScope.launch {
            repository.insertFundTransaction(transaction)
        }
    }

    fun deleteFundPerson(personName: String) {
        viewModelScope.launch {
            val person = allFundPersons.value.find { it.name.equals(personName, ignoreCase = true) }
            if (person != null) {
                repository.deleteFundPerson(person)
            }
        }
    }

    fun deleteFundTransaction(transaction: FundTransactionEntity) {
        viewModelScope.launch {
            repository.deleteFundTransaction(transaction)
        }
    }

    fun setSanghRegistrationStopped(stopped: Boolean) {
        repository.setSanghRegistrationStopped(stopped)
    }

    fun saveAllotment(sanghId: Long, sanghName: String, cityName: String, stateName: String, swadhyaiIds: List<Long>) {
        viewModelScope.launch {
            if (swadhyaiIds.isEmpty()) {
                repository.deleteAllotment(sanghId)
            } else {
                val entity = AllotmentEntity(
                    sanghId = sanghId,
                    sanghName = sanghName,
                    cityName = cityName,
                    stateName = stateName,
                    swadhyaiIds = swadhyaiIds.joinToString(",")
                )
                repository.saveAllotment(entity)
            }
        }
    }

    fun deleteAllotment(sanghId: Long) {
        viewModelScope.launch {
            repository.deleteAllotment(sanghId)
        }
    }

    fun getFormFlow(id: Long) = repository.getFormFlow(id)

    fun insertForm(form: ParyushanFormEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.insertForm(form)
            onComplete(id)
        }
    }

    fun deleteForm(id: Long) {
        viewModelScope.launch {
            repository.softDeleteFormById(id)
        }
    }

    fun updateForm(form: ParyushanFormEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateForm(form)
            onComplete()
        }
    }

    fun restoreForm(id: Long) {
        viewModelScope.launch {
            repository.restoreFormById(id)
        }
    }

    fun deleteFormPermanently(id: Long) {
        viewModelScope.launch {
            repository.deleteFormPermanentlyById(id)
        }
    }

    fun deleteSwadhyaiForm(id: Long) {
        viewModelScope.launch {
            repository.deleteSwadhyaiFormById(id)
        }
    }

    fun getSwadhyaiFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी संघ*
        *Swadhyai Registration Form*

        जय जिनेन्द्र 🙏

        स्वाध्यायी मंडल से जुड़ने एवं स्वाध्यायी पंजीकरण हेतु नीचे दी गई लिंक पर क्लिक करके फॉर्म भरें:

        📌 स्वाध्यायी फॉर्म लिंक:
        https://svsm-a67d9.web.app/swadhyai.html

        (यह लिंक किसी भी वेब ब्राउज़र में खुलती है और आसानी से फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी संघ*
        """.trimIndent()
    }

    fun refreshCloudData() {
        repository.refreshCloudData()
    }

    fun getFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी मंडल*
        *पर्वाधीराज पर्यूषण आराधना २०२६*

        जय जिनेन्द्र 🙏

        पर्यूषणा महापर्व में स्वाध्यायी भाइयों की आराधना प्राप्त करने हेतु आपके श्रीसंघ की संपूर्ण जानकारी दर्ज करने के लिए नीचे दी गई लिंक पर क्लिक करके फॉर्म खोलें:

        📌 फॉर्म लिंक:
        https://svsm-a67d9.web.app

        (यह लिंक किसी भी वेब ब्राउज़र (Chrome/Safari) में खुलती है और सीधे फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी मंडल*
        """.trimIndent()
    }
}
