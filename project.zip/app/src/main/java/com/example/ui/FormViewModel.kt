package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.FormRepository
import com.example.data.ParyushanFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

import com.example.data.SwadhyaiFormEntity

class FormViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: FormRepository

    val searchQuery = MutableStateFlow("")
    val swadhyaiSearchQuery = MutableStateFlow("")

    val allForms: StateFlow<List<ParyushanFormEntity>>
    val deletedForms: StateFlow<List<ParyushanFormEntity>>
    val filteredForms: StateFlow<List<ParyushanFormEntity>>

    val allSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>
    val filteredSwadhyaiForms: StateFlow<List<SwadhyaiFormEntity>>

    init {
        val db = AppDatabase.getDatabase(application)
        val dao = db.formDao()
        val swadhyaiDao = db.swadhyaiDao()
        repository = FormRepository(dao, swadhyaiDao)

        viewModelScope.launch {
            repository.purgeOldDeletedForms()
            repository.prepopulateIfEmpty()
        }

        allForms = repository.allForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        deletedForms = repository.deletedForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredForms = combine(allForms, searchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.sanghName.lowercase().contains(q) ||
                    it.sanghAddress.lowercase().contains(q) ||
                    it.cityName.lowercase().contains(q) ||
                    it.mulnayakBhagwan.lowercase().contains(q)
                }
            }
            filtered.sortedBy { it.cityName }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        allSwadhyaiForms = repository.allSwadhyaiForms.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        filteredSwadhyaiForms = combine(allSwadhyaiForms, swadhyaiSearchQuery) { list, query ->
            val filtered = if (query.isBlank()) {
                list
            } else {
                val q = query.trim().lowercase()
                list.filter {
                    it.fullName.lowercase().contains(q) ||
                    it.city.lowercase().contains(q) ||
                    it.state.lowercase().contains(q) ||
                    it.whatsappNo.contains(q) ||
                    it.contactNo.contains(q) ||
                    it.specialities.lowercase().contains(q) ||
                    it.religiousLearnings.lowercase().contains(q)
                }
            }
            filtered.sortedByDescending { it.createdAt }
        }.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
    }

    fun getFormFlow(id: Long) = repository.getFormFlow(id)

    fun insertForm(form: ParyushanFormEntity, onComplete: (Long) -> Unit) {
        viewModelScope.launch {
            val id = repository.insertForm(form)
            onComplete(id)
        }
    }

    fun deleteForm(id: Long) {
        viewModelScope.launch {
            repository.softDeleteFormById(id)
        }
    }

    fun updateForm(form: ParyushanFormEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateForm(form)
            onComplete()
        }
    }

    fun restoreForm(id: Long) {
        viewModelScope.launch {
            repository.restoreFormById(id)
        }
    }

    fun deleteFormPermanently(id: Long) {
        viewModelScope.launch {
            repository.deleteFormPermanentlyById(id)
        }
    }

    fun deleteSwadhyaiForm(id: Long) {
        viewModelScope.launch {
            repository.deleteSwadhyaiFormById(id)
        }
    }

    fun getSwadhyaiFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी मंडल*
        *स्वाध्यायी पंजीकरण फॉर्म*

        जय जिनेन्द्र 🙏

        स्वाध्यायी मंडल से जुड़ने एवं स्वाध्यायी पंजीकरण हेतु नीचे दी गई लिंक पर क्लिक करके फॉर्म भरें:

        📌 स्वाध्यायी फॉर्म लिंक:
        https://svsm-a67d9.web.app/swadhyai.html

        (यह लिंक किसी भी वेब ब्राउज़र में खुलती है और आसानी से फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी मंडल*
        """.trimIndent()
    }

    fun refreshCloudData() {
        repository.refreshCloudData()
    }

    fun getFormShareInviteText(): String {
        return """
        *श्री वर्धमान स्वाध्यायी मंडल*
        *पर्वाधीराज पर्यूषण आराधना २०२६*

        जय जिनेन्द्र 🙏

        पर्यूषणा महापर्व में स्वाध्यायी भाइयों की आराधना प्राप्त करने हेतु आपके श्रीसंघ की संपूर्ण जानकारी दर्ज करने के लिए नीचे दी गई लिंक पर क्लिक करके फॉर्म खोलें:

        📌 फॉर्म लिंक:
        https://svsm-a67d9.web.app

        (यह लिंक किसी भी वेब ब्राउज़र (Chrome/Safari) में खुलती है और सीधे फॉर्म सबमिट करती है)

        निवेदक:
        *श्री वर्धमान स्वाध्यायी मंडल*
        """.trimIndent()
    }
}
