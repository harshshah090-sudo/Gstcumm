package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.data.toShareableText
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

data class SanghFilterField(
    val key: String,
    val label: String,
    val getValue: (ParyushanFormEntity) -> String
)

val sanghFilterFields = listOf(
    SanghFilterField("sanghName", "१. श्री संघ का नाम") { it.sanghName },
    SanghFilterField("sanghAddress", "२. श्री संघ का पूरा पता") { it.sanghAddress },
    SanghFilterField("cityName", "३. आपके शहर/गांव का नाम एवं राज्य") { formatCityAndState(it.cityName, it.stateName) },
    SanghFilterField("contact1", "४. स्वाध्याई भाई संपर्क (नाम, पद)") { it.contact1 },
    SanghFilterField("contact2", "५. स्वाध्याई भाई WhatsApp न.") { it.contact2 },
    SanghFilterField("mulnayakBhagwan", "६. आपके संघ में मुलनायक भगवान कौन से हैं?") { it.mulnayakBhagwan },
    SanghFilterField("totalFamilies", "७. आपके संघ में कितने परिवार है?") { it.totalFamilies },
    SanghFilterField("hasOtherSangh", "८. क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?") { it.hasOtherSangh },
    SanghFilterField("gacchList", "९. आपके संघ में कौन-कौन से गच्छ हैं?") { it.gacchList },
    SanghFilterField("pratikramanTradition", "१०. आपके संघ में कौनसी परंपरा से प्रतिक्रमण किया जाता हैं?") { it.pratikramanTradition },
    SanghFilterField("hasMusicianGroup", "११. आपके श्रीसंघ में कोई संगीतकार/मंडल हैं?") { it.hasMusicianGroup },
    SanghFilterField("callsOutsideMusician", "१२. क्या आप बाहर से संगीतकार बुलाते हों?") { it.callsOutsideMusician },
    SanghFilterField("hasPanchPratikramanPerson", "१३. पंच प्रतिक्रमण जानकर व्यक्ति उपस्थित है?") { it.hasPanchPratikramanPerson },
    SanghFilterField("hasToiletFacility", "१४. क्या आपके श्रीसंघ मैं मातृ-ठल्ले (Toilet) की व्यवस्था हैं?") { it.hasToiletFacility },
    SanghFilterField("aradhanaSamagriList", "१५. आपके श्रीसंघ में यह आराधना सामग्री होने पर लगाइए") { it.aradhanaSamagriList },
    SanghFilterField("countRaiPratikraman", "१६.१. राई प्रतिक्रमण हाजिरी") { it.countRaiPratikraman },
    SanghFilterField("countDevasiPratikraman", "१६.२. देवसी प्रतिक्रमण हाजिरी") { it.countDevasiPratikraman },
    SanghFilterField("countPravachan", "१६.३. प्रवचन हाजिरी") { it.countPravachan },
    SanghFilterField("countSandhyaBhakti", "१६.४. संध्या भक्ति हाजिरी") { it.countSandhyaBhakti },
    SanghFilterField("mainTrustees", "१७. श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर") { it.mainTrustees },
    SanghFilterField("agreedToTerms", "१८. सर्व अग्रणियों की सम्मति") { if (it.agreedToTerms) "हाँ (स्वीकृत)" else "नहीं" }
)

@Composable
private fun SanghBadgeNumber(number: String) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
        )
    }
}

@Composable
private fun SanghSectionHeaderBadge(title: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SanghQuestionAnswerCard(
    number: String,
    questionText: String,
    answerText: String,
    isHighlight: Boolean = false,
    placeholderText: String = "निर्दिष्ट नहीं",
    isCheckboxList: Boolean = false
) {
    val trimmed = answerText.trim()
    val isAnswered = trimmed.isNotBlank() && trimmed != "0" && trimmed != "null"
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = questionText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Spacer(modifier = Modifier.height(2.dp))

            if (isCheckboxList) {
                val commaNotInParensRegex = Regex(",(?![^()]*\\))")
                val items = trimmed.split(commaNotInParensRegex)
                    .map { it.trim() }
                    .filter { it.isNotBlank() && it != "null" }

                if (items.isEmpty() || trimmed == "कोई नहीं" || trimmed == "निर्दिष्ट नहीं") {
                    Text(
                        text = placeholderText,
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.padding(start = 4.dp)
                    )
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        items.forEach { item ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(text = "✔️", fontSize = 15.sp)
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }
                    }
                }
            } else if (isAnswered) {
                Text(
                    text = trimmed,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            } else {
                Text(
                    text = placeholderText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghRegistrationsScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToNewForm: () -> Unit,
    onNavigateToDetail: (Long) -> Unit = {},
    onNavigateToRecycleBin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val forms by viewModel.filteredForms.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    var formToDelete by remember { mutableStateOf<ParyushanFormEntity?>(null) }
    var selectedSangh by remember { mutableStateOf<ParyushanFormEntity?>(null) }
    var selectedFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var showFilterDialog by remember { mutableStateOf(false) }
    var tempFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }

    val isFilterOrSearchActive = selectedFilterKeys.isNotEmpty() || searchQuery.isNotEmpty()

    fun handleBackPress() {
        if (isFilterOrSearchActive) {
            selectedFilterKeys = emptySet()
            viewModel.searchQuery.value = ""
        } else {
            onNavigateBack()
        }
    }

    BackHandler(enabled = isFilterOrSearchActive) {
        handleBackPress()
    }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    if (showFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Filter Questions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    TextButton(onClick = { tempFilterKeys = if (tempFilterKeys.size == sanghFilterFields.size) emptySet() else sanghFilterFields.map { it.key }.toSet() }) {
                        Text(if (tempFilterKeys.size == sanghFilterFields.size) "Clear All" else "Select All", fontSize = 12.sp)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Select questions to display on registration cards:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    sanghFilterFields.forEach { field ->
                        val isChecked = tempFilterKeys.contains(field.key)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    tempFilterKeys = if (isChecked) {
                                        tempFilterKeys - field.key
                                    } else {
                                        tempFilterKeys + field.key
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    tempFilterKeys = if (it == true) {
                                        tempFilterKeys + field.key
                                    } else {
                                        tempFilterKeys - field.key
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = field.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedFilterKeys = tempFilterKeys
                        showFilterDialog = false
                    }
                ) {
                    Text("Apply Filter")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFilterDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (formToDelete != null) {
        val targetForm = formToDelete!!
        AlertDialog(
            onDismissRequest = { formToDelete = null },
            title = { Text("Delete Registration", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to move \"${targetForm.sanghName}\" to the Recycle Bin?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteForm(targetForm.id)
                        Toast.makeText(context, "Registration moved to Recycle Bin", Toast.LENGTH_SHORT).show()
                        formToDelete = null
                    },
                    modifier = Modifier.testTag("delete_sangh_confirm_button")
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { formToDelete = null },
                    modifier = Modifier.testTag("delete_sangh_cancel_button")
                ) {
                    Text("Cancel")
                }
            }
        )
    }

    if (selectedSangh != null) {
        val form = selectedSangh!!
        Dialog(
            onDismissRequest = { selectedSangh = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.92f)
                    .padding(4.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Subtle transparent background watermark image
                    Image(
                        painter = painterResource(id = R.drawable.header_logo),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        alpha = 0.18f,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .fillMaxSize(0.65f)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = form.sanghName.ifBlank { "Sangh Registration Details" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val cityStateText = formatCityAndState(form.cityName, form.stateName)
                            if (cityStateText.isNotBlank()) {
                                Text(
                                    text = "City: $cityStateText",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(onClick = { selectedSangh = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                    // Questions & Answers scrollable list
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Section 1: Basic Sangh Information
                        SanghSectionHeaderBadge("सामान्य जानकारी (प्रश्न १ - ६)")
                        SanghQuestionAnswerCard("1", "१. श्री संघ का नाम", form.sanghName, isHighlight = true)
                        SanghQuestionAnswerCard("2", "२. श्री संघ का पूरा पता", form.sanghAddress, isHighlight = true)
                        val cityStateDisp = formatCityAndState(form.cityName, form.stateName)
                        SanghQuestionAnswerCard("3", "३. आपके शहर/गांव का नाम एवं राज्य", cityStateDisp)
                        SanghQuestionAnswerCard("4", "४. स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद", form.contact1)
                        SanghQuestionAnswerCard("5", "५. स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका WhatsApp न.", form.contact2)
                        SanghQuestionAnswerCard("6", "६. आपके संघ में मुलनायक भगवान कौन से हैं?", form.mulnayakBhagwan)

                        // Section 2: Sangh Details
                        SanghSectionHeaderBadge("संघ विवरण (प्रश्न ७ - १२)")
                        SanghQuestionAnswerCard("7", "७. आपके संघ में कितने परिवार है?", form.totalFamilies)
                        SanghQuestionAnswerCard("8", "८. क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?", form.hasOtherSangh)
                        SanghQuestionAnswerCard("9", "९. आपके संघ में कौन-कौन से गच्छ हैं?", form.gacchList, isCheckboxList = true)
                        SanghQuestionAnswerCard("10", "१०. आपके संघ में कौनसी परंपरा से प्रतिक्रमण किया जाता हैं?", form.pratikramanTradition, isCheckboxList = true)
                        SanghQuestionAnswerCard("11", "११. आपके श्रीसंघ में कोई संगीतकार/मंडल हैं?", form.hasMusicianGroup)
                        SanghQuestionAnswerCard("12", "१२. क्या आप बाहर से संगीतकार बुलाते हों?", form.callsOutsideMusician)

                        // Section 3: Traditions & Facilities
                        SanghSectionHeaderBadge("व्यवस्थाएँ एवं आराधना सामग्री (प्रश्न १३ - १५)")
                        SanghQuestionAnswerCard("13", "१३. आपके श्रीसंघ में ऐसा कोई व्यक्ति है जिसको पंच प्रतिक्रमण आता हो और वह पर्युषण पर्व में हाजिर हो?", form.hasPanchPratikramanPerson)
                        SanghQuestionAnswerCard("14", "१४. क्या आपके श्रीसंघ मैं मातृ-ठल्ले (Toilet) की व्यवस्था हैं?", form.hasToiletFacility)
                        SanghQuestionAnswerCard("15", "१५. आपके श्रीसंघ में यह आराधना सामग्री होने पर लगाइए", form.aradhanaSamagriList, isCheckboxList = true)

                        // Section 4: Activity Attendance Counts
                        SanghSectionHeaderBadge("प्रवृत्तियों में हाजिरी संख्या (प्रश्न १६)")
                        SanghQuestionAnswerCard("16", "१६. पर्युषण दौरान श्री संघ की प्रवृत्तियों में हाजिर व्यक्तियों की संख्या:", "")
                        SanghQuestionAnswerCard("16.1", "• राई प्रतिक्रमण हाजिरी", form.countRaiPratikraman)
                        SanghQuestionAnswerCard("16.2", "• देवसी प्रतिक्रमण हाजिरी", form.countDevasiPratikraman)
                        SanghQuestionAnswerCard("16.3", "• प्रवचन हाजिरी", form.countPravachan)
                        SanghQuestionAnswerCard("16.4", "• संध्या भक्ति हाजिरी", form.countSandhyaBhakti)

                        // Section 5: Key Bearers & Consent
                        SanghSectionHeaderBadge("ट्रस्टी एवं सम्मति (प्रश्न १७ - १८)")
                        SanghQuestionAnswerCard("17", "१७. श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर", form.mainTrustees)
                        SanghQuestionAnswerCard("18", "१८. सर्व अग्रणियों की सम्मति", if (form.agreedToTerms) "आपके श्रीसंघ के तमाम अग्रणी की सर्वसम्मति से ही आप स्वाध्याई भाइयों को आराधना करवाने के लिए बुला रहे हैं एवं निर्धारित किए हुए सारे नियम समस्त अग्रणियों को स्वीकार है। ✔️" else "नहीं ❌")

                        SanghSectionHeaderBadge("पंजीकरण विवरण")
                        val regDateStr = if (form.createdAt > 0) java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(form.createdAt)) else ""
                        SanghQuestionAnswerCard("ℹ️", "पंजीकरण तिथि एवं समय", regDateStr)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Bottom Buttons Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { selectedSangh = null }) {
                            Text("Close")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, form.toShareableText())
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Sangh Details"))
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Details")
                        }
                    }
                }
            }
        }
    }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Sangh Registrations",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Details of Registered Shree Sangh Registrations",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { handleBackPress() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${forms.size}",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val shareIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, viewModel.getFormShareInviteText())
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "फॉर्म लिंक शेयर करें"))
                },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("share_sangh_form_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "फॉर्म लिंक शेयर करें",
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Search Filter with Filter Button on Right
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val searchInteractionSource = remember { MutableInteractionSource() }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.searchQuery.value = it },
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("sangh_search_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        singleLine = true,
                        interactionSource = searchInteractionSource,
                        decorationBox = @Composable { innerTextField ->
                            OutlinedTextFieldDefaults.DecorationBox(
                                value = searchQuery,
                                innerTextField = innerTextField,
                                enabled = true,
                                singleLine = true,
                                visualTransformation = VisualTransformation.None,
                                interactionSource = searchInteractionSource,
                                placeholder = { Text("Search State", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { viewModel.searchQuery.value = "" },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                container = {
                                    OutlinedTextFieldDefaults.Container(
                                        enabled = true,
                                        isError = false,
                                        interactionSource = searchInteractionSource,
                                        colors = OutlinedTextFieldDefaults.colors(),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            )
                        }
                    )

                    Surface(
                        onClick = {
                            tempFilterKeys = selectedFilterKeys
                            showFilterDialog = true
                        },
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("filter_sangh_questions_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter Questions",
                                modifier = Modifier.size(18.dp),
                                tint = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Filter (${selectedFilterKeys.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Registration List or Empty State
            if (forms.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "अभी तक कोई फॉर्म जमा नहीं हुआ है" else "कोई परिणाम नहीं मिला",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "नया फॉर्म भरने के लिए ऊपर + बटन पर क्लिक करें अथवा नीचे शेयर बटन से लिंक भेजें।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(
                    items = forms,
                    key = { it.id }
                ) { form ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SanghListItemCard(
                            form = form,
                            onClick = { selectedSangh = form },
                            onLongClick = { formToDelete = form },
                            onDeleteClick = { formToDelete = form },
                            selectedFilterKeys = selectedFilterKeys
                        )
                    }
                }
            }
        }
    }
}

fun levenshteinDistance(s1: String, s2: String): Int {
    val dp = IntArray(s2.length + 1) { it }
    for (i in 1..s1.length) {
        var prev = dp[0]
        dp[0] = i
        for (j in 1..s2.length) {
            val temp = dp[j]
            if (s1[i - 1] == s2[j - 1]) {
                dp[j] = prev
            } else {
                dp[j] = 1 + minOf(prev, dp[j], dp[j - 1])
            }
            prev = temp
        }
    }
    return dp[s2.length]
}

fun convertHindiToEnglishCity(cityName: String): String {
    val trimmed = cityName.trim()
    if (trimmed.isBlank()) return "Location"

    val knownCitiesWithState = mapOf(
        // Alwar / Aalavar / Rajasthan
        "अलवर" to "Alwar, Rajasthan",
        "आलवर" to "Alwar, Rajasthan",
        "अल्वार" to "Alwar, Rajasthan",
        "आलवार" to "Alwar, Rajasthan",
        "अलवर (राजस्थान)" to "Alwar, Rajasthan",

        // Gujarat
        "अहमदाबाद" to "Ahmedabad, Gujarat",
        "अमदावाद" to "Ahmedabad, Gujarat",
        "अहमदाबाद (गुजरात)" to "Ahmedabad, Gujarat",
        "अहमदाबाद, गुजरात" to "Ahmedabad, Gujarat",
        "सूरत" to "Surat, Gujarat",
        "सुरत" to "Surat, Gujarat",
        "सूरत (गुजरात)" to "Surat, Gujarat",
        "राजकोट" to "Rajkot, Gujarat",
        "वडोदरा" to "Vadodara, Gujarat",
        "बरोडा" to "Vadodara, Gujarat",
        "भावनगर" to "Bhavnagar, Gujarat",
        "भाव नगर" to "Bhavnagar, Gujarat",
        "जामनगर" to "Jamnagar, Gujarat",
        "जूनागढ़" to "Junagadh, Gujarat",
        "पालिताना" to "Palitana, Gujarat",
        "पालीताना" to "Palitana, Gujarat",
        "कच्छ" to "Kutch, Gujarat",
        "भुज" to "Bhuj, Gujarat",
        "आनंद" to "Anand, Gujarat",
        "नडियाद" to "Nadiad, Gujarat",
        "गांधीनगर" to "Gandhinagar, Gujarat",
        "सुरेंद्रनगर" to "Surendranagar, Gujarat",
        "सुरेन्द्रनगर" to "Surendranagar, Gujarat",
        "महसाणा" to "Mehsana, Gujarat",
        "मेहसाणा" to "Mehsana, Gujarat",
        "पाटन" to "Patan, Gujarat",
        "अमरेली" to "Amreli, Gujarat",
        "नवसारी" to "Navsari, Gujarat",
        "वलसाड" to "Valsad, Gujarat",
        "भरूच" to "Bharuch, Gujarat",
        "गोधरा" to "Godhra, Gujarat",
        "पालनपुर" to "Palanpur, Gujarat",
        "धानेरा" to "Dhanera, Gujarat",
        "डीसा" to "Deesa, Gujarat",
        "थराद" to "Tharad, Gujarat",
        "ईडर" to "Idar, Gujarat",
        "मोडासा" to "Modasa, Gujarat",
        "हिम्मतनगर" to "Himmatnagar, Gujarat",
        "ऊँझा" to "Unjha, Gujarat",
        "उंझा" to "Unjha, Gujarat",
        "कडी" to "Kadi, Gujarat",
        "कलोल" to "Kalol, Gujarat",
        "शंखेश्वर" to "Sankheshwar, Gujarat",
        "तारंगा" to "Taranga, Gujarat",

        // Maharashtra
        "मुंबई" to "Mumbai, Maharashtra",
        "मुम्बई" to "Mumbai, Maharashtra",
        "पुणे" to "Pune, Maharashtra",
        "नासिक" to "Nashik, Maharashtra",
        "नागपुर" to "Nagpur, Maharashtra",
        "शिरडी" to "Shirdi, Maharashtra",
        "ठाणे" to "Thane, Maharashtra",
        "कल्याण" to "Kalyan, Maharashtra",
        "डोंबिवली" to "Dombivli, Maharashtra",
        "नवी मुंबई" to "Navi Mumbai, Maharashtra",
        "सोलापुर" to "Solapur, Maharashtra",
        "कोल्हापुर" to "Kolhapur, Maharashtra",
        "सांगली" to "Sangli, Maharashtra",
        "औरंगाबाद" to "Chhatrapati Sambhajinagar, Maharashtra",
        "लोनावला" to "Lonavala, Maharashtra",

        // Madhya Pradesh
        "इंदौर" to "Indore, Madhya Pradesh",
        "इन्दौर" to "Indore, Madhya Pradesh",
        "भोपाल" to "Bhopal, Madhya Pradesh",
        "रतलाम" to "Ratlam, Madhya Pradesh",
        "उज्जैन" to "Ujjain, Madhya Pradesh",
        "मंदसौर" to "Mandsaur, Madhya Pradesh",
        "नीमच" to "Neemuch, Madhya Pradesh",
        "जबलपुर" to "Jabalpur, Madhya Pradesh",
        "ग्वालियर" to "Gwalior, Madhya Pradesh",
        "सागर" to "Sagar, Madhya Pradesh",
        "विदिशा" to "Vidisha, Madhya Pradesh",

        // Rajasthan
        "नागौर" to "Nagaur, Rajasthan",
        "नागौर (राजस्थान)" to "Nagaur, Rajasthan",
        "नागौर, राजस्थान" to "Nagaur, Rajasthan",
        "नागोर" to "Nagaur, Rajasthan",
        "नागौड़" to "Nagaur, Rajasthan",
        "जयपुर" to "Jaipur, Rajasthan",
        "जोधपुर" to "Jodhpur, Rajasthan",
        "उदयपुर" to "Udaipur, Rajasthan",
        "अजमेर" to "Ajmer, Rajasthan",
        "पाली" to "Pali, Rajasthan",
        "सिरोही" to "Sirohi, Rajasthan",
        "जालौर" to "Jalore, Rajasthan",
        "जालोर" to "Jalore, Rajasthan",
        "भीलवाड़ा" to "Bhilwara, Rajasthan",
        "कोटा" to "Kota, Rajasthan",
        "बीकानेर" to "Bikaner, Rajasthan",
        "सीकर" to "Sikar, Rajasthan",

        // Punjab & Haryana
        "अमृतसर" to "Amritsar, Punjab",
        "अमृतसर, पंजाब" to "Amritsar, Punjab",
        "लुधियाना" to "Ludhiana, Punjab",
        "जालंधर" to "Jalandhar, Punjab",
        "पटियाला" to "Patiala, Punjab",
        "बठिंडा" to "Bathinda, Punjab",
        "मोहाली" to "Mohali, Punjab",
        "चंडीगढ़" to "Chandigarh",
        "अंबाला" to "Ambala, Haryana",
        "करनाल" to "Karnal, Haryana",
        "पानीपत" to "Panipat, Haryana",
        "गुरुग्राम" to "Gurugram, Haryana",
        "गुड़गांव" to "Gurugram, Haryana",
        "फरीदाबाद" to "Faridabad, Haryana",

        // Other States & Union Territories
        "दिल्ली" to "Delhi",
        "नई दिल्ली" to "New Delhi",
        "कोलकाता" to "Kolkata, West Bengal",
        "चेन्नई" to "Chennai, Tamil Nadu",
        "बेंगलुरु" to "Bengaluru, Karnataka",
        "बंगलोर" to "Bengaluru, Karnataka",
        "हैदराबाद" to "Hyderabad, Telangana",
        "पटना" to "Patna, Bihar",
        "ललितपुर" to "Lalitpur, Uttar Pradesh",
        "आगरा" to "Agra, Uttar Pradesh",
        "वाराणसी" to "Varanasi, Uttar Pradesh",
        "बनारस" to "Varanasi, Uttar Pradesh",
        "लखनऊ" to "Lucknow, Uttar Pradesh",
        "कानपुर" to "Kanpur, Uttar Pradesh"
    )

    knownCitiesWithState[trimmed]?.let { return it }

    val englishCityStateMap = mapOf(
        // Alwar variants & Typos
        "aalavar" to "Alwar, Rajasthan",
        "aalwar" to "Alwar, Rajasthan",
        "alwar" to "Alwar, Rajasthan",
        "alvar" to "Alwar, Rajasthan",

        // Navi Mumbai & Mumbai Typos
        "navi mumbao" to "Navi Mumbai, Maharashtra",
        "navi mambai" to "Navi Mumbai, Maharashtra",
        "navimumbai" to "Navi Mumbai, Maharashtra",
        "navimumbao" to "Navi Mumbai, Maharashtra",
        "mumbao" to "Mumbai, Maharashtra",
        "mambai" to "Mumbai, Maharashtra",
        "ahmedbad" to "Ahmedabad, Gujarat",
        "vadodra" to "Vadodara, Gujarat",
        "baroda" to "Vadodara, Gujarat",

        // Gujarat
        "ahmedabad" to "Ahmedabad, Gujarat",
        "surat" to "Surat, Gujarat",
        "rajkot" to "Rajkot, Gujarat",
        "vadodara" to "Vadodara, Gujarat",
        "baroda" to "Vadodara, Gujarat",
        "bhavnagar" to "Bhavnagar, Gujarat",
        "jamnagar" to "Jamnagar, Gujarat",
        "junagadh" to "Junagadh, Gujarat",
        "palitana" to "Palitana, Gujarat",
        "kutch" to "Kutch, Gujarat",
        "bhuj" to "Bhuj, Gujarat",
        "anand" to "Anand, Gujarat",
        "nadiad" to "Nadiad, Gujarat",
        "gandhinagar" to "Gandhinagar, Gujarat",
        "surendranagar" to "Surendranagar, Gujarat",
        "mehsana" to "Mehsana, Gujarat",
        "patan" to "Patan, Gujarat",
        "amreli" to "Amreli, Gujarat",
        "navsari" to "Navsari, Gujarat",
        "valsad" to "Valsad, Gujarat",
        "bharuch" to "Bharuch, Gujarat",
        "godhra" to "Godhra, Gujarat",
        "palanpur" to "Palanpur, Gujarat",
        "dhanera" to "Dhanera, Gujarat",
        "deesa" to "Deesa, Gujarat",
        "tharad" to "Tharad, Gujarat",
        "idar" to "Idar, Gujarat",
        "modasa" to "Modasa, Gujarat",
        "himmatnagar" to "Himmatnagar, Gujarat",
        "unjha" to "Unjha, Gujarat",
        "kadi" to "Kadi, Gujarat",
        "kalol" to "Kalol, Gujarat",
        "sankheshwar" to "Sankheshwar, Gujarat",
        "taranga" to "Taranga, Gujarat",

        // Maharashtra
        "mumbai" to "Mumbai, Maharashtra",
        "pune" to "Pune, Maharashtra",
        "nashik" to "Nashik, Maharashtra",
        "nagpur" to "Nagpur, Maharashtra",
        "shirdi" to "Shirdi, Maharashtra",
        "thane" to "Thane, Maharashtra",
        "kalyan" to "Kalyan, Maharashtra",
        "dombivli" to "Dombivli, Maharashtra",
        "navi mumbai" to "Navi Mumbai, Maharashtra",
        "solapur" to "Solapur, Maharashtra",
        "kolhapur" to "Kolhapur, Maharashtra",
        "sangli" to "Sangli, Maharashtra",
        "aurangabad" to "Chhatrapati Sambhajinagar, Maharashtra",
        "lonavala" to "Lonavala, Maharashtra",

        // Madhya Pradesh
        "indore" to "Indore, Madhya Pradesh",
        "bhopal" to "Bhopal, Madhya Pradesh",
        "ratlam" to "Ratlam, Madhya Pradesh",
        "ujjain" to "Ujjain, Madhya Pradesh",
        "mandsaur" to "Mandsaur, Madhya Pradesh",
        "neemuch" to "Neemuch, Madhya Pradesh",
        "jabalpur" to "Jabalpur, Madhya Pradesh",
        "gwalior" to "Gwalior, Madhya Pradesh",
        "sagar" to "Sagar, Madhya Pradesh",
        "vidisha" to "Vidisha, Madhya Pradesh",

        // Rajasthan
        "nagaur" to "Nagaur, Rajasthan",
        "nagour" to "Nagaur, Rajasthan",
        "nagore" to "Nagaur, Rajasthan",
        "jaipur" to "Jaipur, Rajasthan",
        "jodhpur" to "Jodhpur, Rajasthan",
        "udaipur" to "Udaipur, Rajasthan",
        "ajmer" to "Ajmer, Rajasthan",
        "pali" to "Pali, Rajasthan",
        "sirohi" to "Sirohi, Rajasthan",
        "jalore" to "Jalore, Rajasthan",
        "bhilwara" to "Bhilwara, Rajasthan",
        "kota" to "Kota, Rajasthan",
        "bikaner" to "Bikaner, Rajasthan",
        "sikar" to "Sikar, Rajasthan",

        // Punjab & Haryana
        "amritsar" to "Amritsar, Punjab",
        "amrtsar" to "Amritsar, Punjab",
        "amritser" to "Amritsar, Punjab",
        "ambarsar" to "Amritsar, Punjab",
        "ludhiana" to "Ludhiana, Punjab",
        "jalandhar" to "Jalandhar, Punjab",
        "patiala" to "Patiala, Punjab",
        "bathinda" to "Bathinda, Punjab",
        "mohali" to "Mohali, Punjab",
        "chandigarh" to "Chandigarh",
        "ambala" to "Ambala, Haryana",
        "karnal" to "Karnal, Haryana",
        "panipat" to "Panipat, Haryana",
        "gurgaon" to "Gurugram, Haryana",
        "gurugram" to "Gurugram, Haryana",
        "faridabad" to "Faridabad, Haryana",
        "shimla" to "Shimla, Himachal Pradesh",
        "jammu" to "Jammu, Jammu and Kashmir",
        "srinagar" to "Srinagar, Jammu and Kashmir",
        "guwahati" to "Guwahati, Assam",
        "ranchi" to "Ranchi, Jharkhand",
        "raipur" to "Raipur, Chhattisgarh",
        "bhubaneswar" to "Bhubaneswar, Odisha",
        "cuttack" to "Cuttack, Odisha",

        // Others
        "delhi" to "Delhi",
        "new delhi" to "New Delhi",
        "kolkata" to "Kolkata, West Bengal",
        "chennai" to "Chennai, Tamil Nadu",
        "bengaluru" to "Bengaluru, Karnataka",
        "bangalore" to "Bengaluru, Karnataka",
        "hyderabad" to "Hyderabad, Telangana",
        "patna" to "Patna, Bihar",
        "lalitpur" to "Lalitpur, Uttar Pradesh",
        "agra" to "Agra, Uttar Pradesh",
        "varanasi" to "Varanasi, Uttar Pradesh",
        "lucknow" to "Lucknow, Uttar Pradesh",
        "kanpur" to "Kanpur, Uttar Pradesh"
    )

    val lowerTrimmed = trimmed.lowercase()
    englishCityStateMap[lowerTrimmed]?.let { return it }

    fun findFuzzyMatch(input: String): String? {
        if (input.length < 5) return null
        var bestMatch: String? = null
        var minDistance = Int.MAX_VALUE
        for ((key, value) in englishCityStateMap) {
            val dist = levenshteinDistance(input, key)
            val maxAllowed = if (key.length >= 8) 2 else if (key.length >= 7) 1 else 0
            if (dist <= maxAllowed && dist < minDistance) {
                minDistance = dist
                bestMatch = value
            }
        }
        return bestMatch
    }

    val hasDevanagari = trimmed.any { it.code in 0x0900..0x097F }
    if (!hasDevanagari) {
        findFuzzyMatch(lowerTrimmed)?.let { return it }
        return trimmed.split(" ").joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
        }
    }

    val charMap = mapOf(
        'अ' to "A", 'आ' to "Aa", 'इ' to "I", 'ई' to "Ee", 'उ' to "U", 'ऊ' to "Oo", 'ऋ' to "Ri", 'ए' to "E", 'ऐ' to "Ai", 'ओ' to "O", 'औ' to "Au",
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "ny",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
        'ष' to "sh", 'स' to "s", 'ह' to "h"
    )
    val matraMap = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ं' to "n", 'ः' to "h", 'ँ' to "n", '्' to ""
    )

    val sb = StringBuilder()
    var i = 0
    while (i < trimmed.length) {
        val ch = trimmed[i]
        if (charMap.containsKey(ch)) {
            val base = charMap[ch]!!
            if (i + 1 < trimmed.length && matraMap.containsKey(trimmed[i + 1])) {
                val matra = matraMap[trimmed[i + 1]]!!
                sb.append(base).append(matra)
                i += 2
            } else {
                val addA = if (i + 1 < trimmed.length && trimmed[i + 1] != ' ' && !matraMap.containsKey(trimmed[i + 1])) "a" else ""
                sb.append(base).append(addA)
                i += 1
            }
        } else if (matraMap.containsKey(ch)) {
            sb.append(matraMap[ch])
            i += 1
        } else {
            sb.append(ch)
            i += 1
        }
    }

    val transliterated = sb.toString().trim()
    val transliteratedLower = transliterated.lowercase()
    englishCityStateMap[transliteratedLower]?.let { return it }
    findFuzzyMatch(transliteratedLower)?.let { return it }

    return transliterated.split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
    }
}

fun formatCityAndState(cityName: String, stateName: String): String {
    val baseCity = convertHindiToEnglishCity(cityName).trim()
    val state = stateName.trim()

    if (baseCity.isBlank() || baseCity.equals("Location", ignoreCase = true)) {
        return state.ifBlank { "Location" }
    }
    if (state.isBlank()) {
        return baseCity
    }

    if (baseCity.contains(",")) {
        val parts = baseCity.split(",").map { it.trim() }
        val cityPart = parts[0]
        val mappedState = parts.getOrNull(1) ?: ""

        if (mappedState.equals(state, ignoreCase = true) ||
            mappedState.contains(state, ignoreCase = true) ||
            state.contains(mappedState, ignoreCase = true)
        ) {
            return baseCity
        } else {
            return "$cityPart, $state"
        }
    } else {
        return "$baseCity, $state"
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SanghListItemCard(
    form: ParyushanFormEntity,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDeleteClick: () -> Unit,
    selectedFilterKeys: Set<String> = emptySet(),
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val englishCity = remember(form.cityName, form.stateName) {
        formatCityAndState(form.cityName, form.stateName)
    }

    fun openMapForCity() {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(englishCity)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(englishCity)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("sangh_card_${form.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive GPS Tag for City Name in English
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { openMapForCity() }
                        .testTag("city_gps_tag_${form.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Open Google Maps",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = englishCity,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Details",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sangh Name only
            Text(
                text = form.sanghName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            // Dynamic filter fields selected by user
            val activeFilterItems = remember(selectedFilterKeys, form) {
                selectedFilterKeys.mapNotNull { key ->
                    val field = sanghFilterFields.find { it.key == key }
                    if (field != null) {
                        val valStr = field.getValue(form)
                        if (valStr.isNotBlank()) field.label to valStr else null
                    } else null
                }
            }

            if (activeFilterItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                if (activeFilterItems.size == 1) {
                    val (label, value) = activeFilterItems.first()
                    Text(
                        text = "$label: $value",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                } else {
                    val leftItems = activeFilterItems.filterIndexed { index, _ -> index % 2 == 0 }
                    val rightItems = activeFilterItems.filterIndexed { index, _ -> index % 2 != 0 }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            leftItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 2.dp),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            rightItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
