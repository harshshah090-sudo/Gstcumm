package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ParyushanFormEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SanghRegistrationsScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onNavigateToNewForm: () -> Unit,
    onNavigateToDetail: (Long) -> Unit,
    onNavigateToRecycleBin: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val forms by viewModel.filteredForms.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    var formToDelete by remember { mutableStateOf<ParyushanFormEntity?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    if (formToDelete != null) {
        val targetForm = formToDelete!!
        AlertDialog(
            onDismissRequest = { formToDelete = null },
            title = { Text("फॉर्म हटाएं (Recycle Bin)") },
            text = { Text("क्या आप \"${targetForm.sanghName}\" का यह फॉर्म रीसाइकिल बिन में भेजना चाहते हैं?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteForm(targetForm.id)
                        Toast.makeText(context, "फॉर्म रीसाइकिल बिन में भेज दिया गया है", Toast.LENGTH_SHORT).show()
                        formToDelete = null
                    }
                ) {
                    Text("हटाएं", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { formToDelete = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "श्रीसंघ पंजीकरण अर्जियाँ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "जमा किए गए श्रीसंघों का विवरण",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.refreshCloudData()
                            Toast.makeText(context, "डेटा रिफ्रेश हो रहा है...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("refresh_sangh_forms_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "रिफ्रेश करें",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = onNavigateToRecycleBin,
                        modifier = Modifier.testTag("open_recycle_bin_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "रीसाइकिल बिन",
                            tint = MaterialTheme.colorScheme.error
                        )
                    }
                    IconButton(
                        onClick = {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://svsm-a67d9.web.app"))
                            context.startActivity(intent)
                        },
                        modifier = Modifier.testTag("open_web_form_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "नया फॉर्म भरें (ब्राउज़र में)",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    val shareIntent = Intent().apply {
                        action = Intent.ACTION_SEND
                        putExtra(Intent.EXTRA_TEXT, viewModel.getFormShareInviteText())
                        type = "text/plain"
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "फॉर्म लिंक शेयर करें"))
                },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.testTag("share_sangh_form_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "फॉर्म लिंक शेयर करें"
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primaryContainer,
                                    MaterialTheme.colorScheme.secondaryContainer
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "पर्वाधीराज पर्यूषण आराधना",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.primary
                            ) {
                                Text(
                                    text = "2026",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "पर्यूषणा महापर्व में आराधना करवाने हेतु जमा किए गए श्रीसंघों की सूची।",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                            )
                        )
                    }
                }
            }

            // 2. Search Filter
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.searchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                        .testTag("sangh_search_input"),
                    placeholder = { Text("श्री संघ का नाम या शहर खोजें...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "साफ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // 3. Section Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "प्राप्त श्रीसंघ अर्जियाँ (${forms.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = "टैप करके पूरा विवरण देखें",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // 4. Registration List or Empty State
            if (forms.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Description,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "अभी तक कोई फॉर्म जमा नहीं हुआ है" else "कोई परिणाम नहीं मिला",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "नया फॉर्म भरने के लिए ऊपर + बटन पर क्लिक करें अथवा नीचे शेयर बटन से लिंक भेजें।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                items(
                    items = forms,
                    key = { it.id }
                ) { form ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SanghListItemCard(
                            form = form,
                            onClick = { onNavigateToDetail(form.id) },
                            onLongClick = { formToDelete = form },
                            onDeleteClick = { formToDelete = form }
                        )
                    }
                }
            }
        }
    }
}

fun levenshteinDistance(s1: String, s2: String): Int {
    val dp = IntArray(s2.length + 1) { it }
    for (i in 1..s1.length) {
        var prev = dp[0]
        dp[0] = i
        for (j in 1..s2.length) {
            val temp = dp[j]
            if (s1[i - 1] == s2[j - 1]) {
                dp[j] = prev
            } else {
                dp[j] = 1 + minOf(prev, dp[j], dp[j - 1])
            }
            prev = temp
        }
    }
    return dp[s2.length]
}

fun convertHindiToEnglishCity(cityName: String): String {
    val trimmed = cityName.trim()
    if (trimmed.isBlank()) return "Location"

    val knownCitiesWithState = mapOf(
        // Alwar / Aalavar / Rajasthan
        "अलवर" to "Alwar, Rajasthan",
        "आलवर" to "Alwar, Rajasthan",
        "अल्वार" to "Alwar, Rajasthan",
        "आलवार" to "Alwar, Rajasthan",
        "अलवर (राजस्थान)" to "Alwar, Rajasthan",

        // Gujarat
        "अहमदाबाद" to "Ahmedabad, Gujarat",
        "अमदावाद" to "Ahmedabad, Gujarat",
        "अहमदाबाद (गुजरात)" to "Ahmedabad, Gujarat",
        "अहमदाबाद, गुजरात" to "Ahmedabad, Gujarat",
        "सूरत" to "Surat, Gujarat",
        "सुरत" to "Surat, Gujarat",
        "सूरत (गुजरात)" to "Surat, Gujarat",
        "राजकोट" to "Rajkot, Gujarat",
        "वडोदरा" to "Vadodara, Gujarat",
        "बरोडा" to "Vadodara, Gujarat",
        "भावनगर" to "Bhavnagar, Gujarat",
        "भाव नगर" to "Bhavnagar, Gujarat",
        "जामनगर" to "Jamnagar, Gujarat",
        "जूनागढ़" to "Junagadh, Gujarat",
        "पालिताना" to "Palitana, Gujarat",
        "पालीताना" to "Palitana, Gujarat",
        "कच्छ" to "Kutch, Gujarat",
        "भुज" to "Bhuj, Gujarat",
        "आनंद" to "Anand, Gujarat",
        "नडियाद" to "Nadiad, Gujarat",
        "गांधीनगर" to "Gandhinagar, Gujarat",
        "सुरेंद्रनगर" to "Surendranagar, Gujarat",
        "सुरेन्द्रनगर" to "Surendranagar, Gujarat",
        "महसाणा" to "Mehsana, Gujarat",
        "मेहसाणा" to "Mehsana, Gujarat",
        "पाटन" to "Patan, Gujarat",
        "अमरेली" to "Amreli, Gujarat",
        "नवसारी" to "Navsari, Gujarat",
        "वलसाड" to "Valsad, Gujarat",
        "भरूच" to "Bharuch, Gujarat",
        "गोधरा" to "Godhra, Gujarat",
        "पालनपुर" to "Palanpur, Gujarat",
        "धानेरा" to "Dhanera, Gujarat",
        "डीसा" to "Deesa, Gujarat",
        "थराद" to "Tharad, Gujarat",
        "ईडर" to "Idar, Gujarat",
        "मोडासा" to "Modasa, Gujarat",
        "हिम्मतनगर" to "Himmatnagar, Gujarat",
        "ऊँझा" to "Unjha, Gujarat",
        "उंझा" to "Unjha, Gujarat",
        "कडी" to "Kadi, Gujarat",
        "कलोल" to "Kalol, Gujarat",
        "शंखेश्वर" to "Sankheshwar, Gujarat",
        "तारंगा" to "Taranga, Gujarat",

        // Maharashtra
        "मुंबई" to "Mumbai, Maharashtra",
        "मुम्बई" to "Mumbai, Maharashtra",
        "पुणे" to "Pune, Maharashtra",
        "नासिक" to "Nashik, Maharashtra",
        "नागपुर" to "Nagpur, Maharashtra",
        "शिरडी" to "Shirdi, Maharashtra",
        "ठाणे" to "Thane, Maharashtra",
        "कल्याण" to "Kalyan, Maharashtra",
        "डोंबिवली" to "Dombivli, Maharashtra",
        "नवी मुंबई" to "Navi Mumbai, Maharashtra",
        "सोलापुर" to "Solapur, Maharashtra",
        "कोल्हापुर" to "Kolhapur, Maharashtra",
        "सांगली" to "Sangli, Maharashtra",
        "औरंगाबाद" to "Chhatrapati Sambhajinagar, Maharashtra",
        "लोनावला" to "Lonavala, Maharashtra",

        // Madhya Pradesh
        "इंदौर" to "Indore, Madhya Pradesh",
        "इन्दौर" to "Indore, Madhya Pradesh",
        "भोपाल" to "Bhopal, Madhya Pradesh",
        "रतलाम" to "Ratlam, Madhya Pradesh",
        "उज्जैन" to "Ujjain, Madhya Pradesh",
        "मंदसौर" to "Mandsaur, Madhya Pradesh",
        "नीमच" to "Neemuch, Madhya Pradesh",
        "जबलपुर" to "Jabalpur, Madhya Pradesh",
        "ग्वालियर" to "Gwalior, Madhya Pradesh",
        "सागर" to "Sagar, Madhya Pradesh",
        "विदिशा" to "Vidisha, Madhya Pradesh",

        // Rajasthan
        "जयपुर" to "Jaipur, Rajasthan",
        "जोधपुर" to "Jodhpur, Rajasthan",
        "उदयपुर" to "Udaipur, Rajasthan",
        "अजमेर" to "Ajmer, Rajasthan",
        "पाली" to "Pali, Rajasthan",
        "सिरोही" to "Sirohi, Rajasthan",
        "जालौर" to "Jalore, Rajasthan",
        "जालोर" to "Jalore, Rajasthan",
        "भीलवाड़ा" to "Bhilwara, Rajasthan",
        "कोटा" to "Kota, Rajasthan",
        "बीकानेर" to "Bikaner, Rajasthan",
        "सीकर" to "Sikar, Rajasthan",

        // Punjab & Haryana
        "अमृतसर" to "Amritsar, Punjab",
        "अमृतसर, पंजाब" to "Amritsar, Punjab",
        "लुधियाना" to "Ludhiana, Punjab",
        "जालंधर" to "Jalandhar, Punjab",
        "पटियाला" to "Patiala, Punjab",
        "बठिंडा" to "Bathinda, Punjab",
        "मोहाली" to "Mohali, Punjab",
        "चंडीगढ़" to "Chandigarh",
        "अंबाला" to "Ambala, Haryana",
        "करनाल" to "Karnal, Haryana",
        "पानीपत" to "Panipat, Haryana",
        "गुरुग्राम" to "Gurugram, Haryana",
        "गुड़गांव" to "Gurugram, Haryana",
        "फरीदाबाद" to "Faridabad, Haryana",

        // Other States & Union Territories
        "दिल्ली" to "Delhi",
        "नई दिल्ली" to "New Delhi",
        "कोलकाता" to "Kolkata, West Bengal",
        "चेन्नई" to "Chennai, Tamil Nadu",
        "बेंगलुरु" to "Bengaluru, Karnataka",
        "बंगलोर" to "Bengaluru, Karnataka",
        "हैदराबाद" to "Hyderabad, Telangana",
        "पटना" to "Patna, Bihar",
        "ललितपुर" to "Lalitpur, Uttar Pradesh",
        "आगरा" to "Agra, Uttar Pradesh",
        "वाराणसी" to "Varanasi, Uttar Pradesh",
        "बनारस" to "Varanasi, Uttar Pradesh",
        "लखनऊ" to "Lucknow, Uttar Pradesh",
        "कानपुर" to "Kanpur, Uttar Pradesh"
    )

    knownCitiesWithState[trimmed]?.let { return it }

    val englishCityStateMap = mapOf(
        // Alwar variants & Typos
        "aalavar" to "Alwar, Rajasthan",
        "aalwar" to "Alwar, Rajasthan",
        "alwar" to "Alwar, Rajasthan",
        "alvar" to "Alwar, Rajasthan",

        // Navi Mumbai & Mumbai Typos
        "navi mumbao" to "Navi Mumbai, Maharashtra",
        "navi mambai" to "Navi Mumbai, Maharashtra",
        "navimumbai" to "Navi Mumbai, Maharashtra",
        "navimumbao" to "Navi Mumbai, Maharashtra",
        "mumbao" to "Mumbai, Maharashtra",
        "mambai" to "Mumbai, Maharashtra",
        "ahmedbad" to "Ahmedabad, Gujarat",
        "vadodra" to "Vadodara, Gujarat",
        "baroda" to "Vadodara, Gujarat",

        // Gujarat
        "ahmedabad" to "Ahmedabad, Gujarat",
        "surat" to "Surat, Gujarat",
        "rajkot" to "Rajkot, Gujarat",
        "vadodara" to "Vadodara, Gujarat",
        "baroda" to "Vadodara, Gujarat",
        "bhavnagar" to "Bhavnagar, Gujarat",
        "jamnagar" to "Jamnagar, Gujarat",
        "junagadh" to "Junagadh, Gujarat",
        "palitana" to "Palitana, Gujarat",
        "kutch" to "Kutch, Gujarat",
        "bhuj" to "Bhuj, Gujarat",
        "anand" to "Anand, Gujarat",
        "nadiad" to "Nadiad, Gujarat",
        "gandhinagar" to "Gandhinagar, Gujarat",
        "surendranagar" to "Surendranagar, Gujarat",
        "mehsana" to "Mehsana, Gujarat",
        "patan" to "Patan, Gujarat",
        "amreli" to "Amreli, Gujarat",
        "navsari" to "Navsari, Gujarat",
        "valsad" to "Valsad, Gujarat",
        "bharuch" to "Bharuch, Gujarat",
        "godhra" to "Godhra, Gujarat",
        "palanpur" to "Palanpur, Gujarat",
        "dhanera" to "Dhanera, Gujarat",
        "deesa" to "Deesa, Gujarat",
        "tharad" to "Tharad, Gujarat",
        "idar" to "Idar, Gujarat",
        "modasa" to "Modasa, Gujarat",
        "himmatnagar" to "Himmatnagar, Gujarat",
        "unjha" to "Unjha, Gujarat",
        "kadi" to "Kadi, Gujarat",
        "kalol" to "Kalol, Gujarat",
        "sankheshwar" to "Sankheshwar, Gujarat",
        "taranga" to "Taranga, Gujarat",

        // Maharashtra
        "mumbai" to "Mumbai, Maharashtra",
        "pune" to "Pune, Maharashtra",
        "nashik" to "Nashik, Maharashtra",
        "nagpur" to "Nagpur, Maharashtra",
        "shirdi" to "Shirdi, Maharashtra",
        "thane" to "Thane, Maharashtra",
        "kalyan" to "Kalyan, Maharashtra",
        "dombivli" to "Dombivli, Maharashtra",
        "navi mumbai" to "Navi Mumbai, Maharashtra",
        "solapur" to "Solapur, Maharashtra",
        "kolhapur" to "Kolhapur, Maharashtra",
        "sangli" to "Sangli, Maharashtra",
        "aurangabad" to "Chhatrapati Sambhajinagar, Maharashtra",
        "lonavala" to "Lonavala, Maharashtra",

        // Madhya Pradesh
        "indore" to "Indore, Madhya Pradesh",
        "bhopal" to "Bhopal, Madhya Pradesh",
        "ratlam" to "Ratlam, Madhya Pradesh",
        "ujjain" to "Ujjain, Madhya Pradesh",
        "mandsaur" to "Mandsaur, Madhya Pradesh",
        "neemuch" to "Neemuch, Madhya Pradesh",
        "jabalpur" to "Jabalpur, Madhya Pradesh",
        "gwalior" to "Gwalior, Madhya Pradesh",
        "sagar" to "Sagar, Madhya Pradesh",
        "vidisha" to "Vidisha, Madhya Pradesh",

        // Rajasthan
        "jaipur" to "Jaipur, Rajasthan",
        "jodhpur" to "Jodhpur, Rajasthan",
        "udaipur" to "Udaipur, Rajasthan",
        "ajmer" to "Ajmer, Rajasthan",
        "pali" to "Pali, Rajasthan",
        "sirohi" to "Sirohi, Rajasthan",
        "jalore" to "Jalore, Rajasthan",
        "bhilwara" to "Bhilwara, Rajasthan",
        "kota" to "Kota, Rajasthan",
        "bikaner" to "Bikaner, Rajasthan",
        "sikar" to "Sikar, Rajasthan",

        // Punjab & Haryana
        "amritsar" to "Amritsar, Punjab",
        "amrtsar" to "Amritsar, Punjab",
        "amritser" to "Amritsar, Punjab",
        "ambarsar" to "Amritsar, Punjab",
        "ludhiana" to "Ludhiana, Punjab",
        "jalandhar" to "Jalandhar, Punjab",
        "patiala" to "Patiala, Punjab",
        "bathinda" to "Bathinda, Punjab",
        "mohali" to "Mohali, Punjab",
        "chandigarh" to "Chandigarh",
        "ambala" to "Ambala, Haryana",
        "karnal" to "Karnal, Haryana",
        "panipat" to "Panipat, Haryana",
        "gurgaon" to "Gurugram, Haryana",
        "gurugram" to "Gurugram, Haryana",
        "faridabad" to "Faridabad, Haryana",
        "shimla" to "Shimla, Himachal Pradesh",
        "jammu" to "Jammu, Jammu and Kashmir",
        "srinagar" to "Srinagar, Jammu and Kashmir",
        "guwahati" to "Guwahati, Assam",
        "ranchi" to "Ranchi, Jharkhand",
        "raipur" to "Raipur, Chhattisgarh",
        "bhubaneswar" to "Bhubaneswar, Odisha",
        "cuttack" to "Cuttack, Odisha",

        // Others
        "delhi" to "Delhi",
        "new delhi" to "New Delhi",
        "kolkata" to "Kolkata, West Bengal",
        "chennai" to "Chennai, Tamil Nadu",
        "bengaluru" to "Bengaluru, Karnataka",
        "bangalore" to "Bengaluru, Karnataka",
        "hyderabad" to "Hyderabad, Telangana",
        "patna" to "Patna, Bihar",
        "lalitpur" to "Lalitpur, Uttar Pradesh",
        "agra" to "Agra, Uttar Pradesh",
        "varanasi" to "Varanasi, Uttar Pradesh",
        "lucknow" to "Lucknow, Uttar Pradesh",
        "kanpur" to "Kanpur, Uttar Pradesh"
    )

    val lowerTrimmed = trimmed.lowercase()
    englishCityStateMap[lowerTrimmed]?.let { return it }

    fun findFuzzyMatch(input: String): String? {
        var bestMatch: String? = null
        var minDistance = Int.MAX_VALUE
        for ((key, value) in englishCityStateMap) {
            val dist = levenshteinDistance(input, key)
            val maxAllowed = if (key.length >= 7) 2 else 1
            if (dist <= maxAllowed && dist < minDistance) {
                minDistance = dist
                bestMatch = value
            }
        }
        return bestMatch
    }

    findFuzzyMatch(lowerTrimmed)?.let { return it }

    val hasDevanagari = trimmed.any { it.code in 0x0900..0x097F }
    if (!hasDevanagari) {
        return trimmed.split(" ").joinToString(" ") { word ->
            word.lowercase().replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
        }
    }

    val charMap = mapOf(
        'अ' to "A", 'आ' to "Aa", 'इ' to "I", 'ई' to "Ee", 'उ' to "U", 'ऊ' to "Oo", 'ऋ' to "Ri", 'ए' to "E", 'ऐ' to "Ai", 'ओ' to "O", 'औ' to "Au",
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "ny",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
        'ष' to "sh", 'स' to "s", 'ह' to "h"
    )
    val matraMap = mapOf(
        'ा' to "a", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri", 'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au",
        'ं' to "n", 'ः' to "h", 'ँ' to "n", '्' to ""
    )

    val sb = StringBuilder()
    var i = 0
    while (i < trimmed.length) {
        val ch = trimmed[i]
        if (charMap.containsKey(ch)) {
            val base = charMap[ch]!!
            if (i + 1 < trimmed.length && matraMap.containsKey(trimmed[i + 1])) {
                val matra = matraMap[trimmed[i + 1]]!!
                sb.append(base).append(matra)
                i += 2
            } else {
                val addA = if (i + 1 < trimmed.length && trimmed[i + 1] != ' ' && !matraMap.containsKey(trimmed[i + 1])) "a" else ""
                sb.append(base).append(addA)
                i += 1
            }
        } else if (matraMap.containsKey(ch)) {
            sb.append(matraMap[ch])
            i += 1
        } else {
            sb.append(ch)
            i += 1
        }
    }

    val transliterated = sb.toString().trim()
    val transliteratedLower = transliterated.lowercase()
    englishCityStateMap[transliteratedLower]?.let { return it }
    findFuzzyMatch(transliteratedLower)?.let { return it }

    return transliterated.split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.getDefault()) else it.toString() }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SanghListItemCard(
    form: ParyushanFormEntity,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val englishCity = remember(form.cityName, form.stateName) {
        val baseCity = convertHindiToEnglishCity(form.cityName)
        if (form.stateName.isNotBlank() && !baseCity.contains(form.stateName, ignoreCase = true)) {
            "$baseCity, ${form.stateName}"
        } else {
            baseCity
        }
    }

    fun openMapForCity() {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(englishCity)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(englishCity)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("sangh_card_${form.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive GPS Tag for City Name in English
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .clickable { openMapForCity() }
                        .testTag("city_gps_tag_${form.id}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Open Google Maps",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = englishCity,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Details",
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Sangh Name only
            Text(
                text = form.sanghName,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
