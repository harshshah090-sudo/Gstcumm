package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JainCityManager
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CitySelectionDialog(
    currentCity: String,
    onCitySelected: (String) -> Unit,
    onDismissRequest: () -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val filteredCities = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            JainCityManager.citiesList
        } else {
            JainCityManager.citiesList.filter {
                it.cityNameHindi.contains(searchQuery, ignoreCase = true) ||
                it.cityNameEnglish.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("बंद करें (Close)", color = AppPrimaryGold, fontWeight = FontWeight.Bold)
            }
        },
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = AppPrimaryGold
                )
                Text(
                    text = "स्थान (शहर / City) चुनें",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
            ) {
                Text(
                    text = "सूर्योदय, सूर्यास्त एवं नवकारसी समय आपके चुने हुए शहर के अनुसार अपडेट होंगे।",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted, fontSize = 11.5.sp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("शहर खोजें (Search city)...", fontSize = 13.sp, color = AppTextMuted) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AppPrimaryGold) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedContainerColor = AppDeepSurface,
                        unfocusedContainerColor = AppDeepSurface,
                        focusedTextColor = AppTextPrimary,
                        unfocusedTextColor = AppTextPrimary
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredCities) { city ->
                        val isSelected = city.cityNameHindi.contains(currentCity, ignoreCase = true) || 
                                         currentCity.contains(city.cityNameEnglish, ignoreCase = true)

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) AppPrimaryGold.copy(alpha = 0.2f) else AppDeepSurface,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 0.8.dp,
                                color = if (isSelected) AppPrimaryGold else AppBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onCitySelected(city.cityNameHindi)
                                    onDismissRequest()
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = city.cityNameHindi,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                            color = if (isSelected) AppPrimaryGold else AppTextPrimary
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "सूर्योदय: ${city.sunriseTime} • नवकारसी: ${city.navkarsiTime} • सूर्यास्त: ${city.sunsetTime}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = AppTextMuted,
                                            fontSize = 10.5.sp
                                        )
                                    )
                                }

                                if (isSelected) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = "Selected",
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (filteredCities.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "कोई शहर नहीं मिला",
                                    color = AppTextMuted,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = {
                                        if (searchQuery.isNotBlank()) {
                                            onCitySelected(searchQuery.trim())
                                            onDismissRequest()
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold)
                                ) {
                                    Text("\"${searchQuery.trim()}\" शहर चुनें", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        },
        containerColor = AppSurface,
        shape = RoundedCornerShape(18.dp)
    )
}
