package com.example.ui

import android.app.Activity
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.data.UserSessionManager
import com.example.ui.theme.*
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.concurrent.TimeUnit

val ALL_INDIAN_STATES = listOf(
    "Gujarat", "Maharashtra", "Rajasthan", "Madhya Pradesh", "Delhi",
    "Karnataka", "Tamil Nadu", "Uttar Pradesh", "West Bengal", "Andhra Pradesh",
    "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa",
    "Haryana", "Himachal Pradesh", "Jharkhand", "Kerala", "Manipur",
    "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab",
    "Sikkim", "Telangana", "Tripura", "Uttarakhand", "Other"
)

val CITIES_BY_STATE: Map<String, List<String>> = mapOf(
    "Madhya Pradesh" to listOf("Indore", "Bhopal", "Jabalpur", "Gwalior", "Ujjain", "Sagar", "Dewas", "Satna", "Ratlam", "Rewa", "Mandsaur", "Neemuch", "Khandwa", "Khargone", "Vidisha", "Chhindwara"),
    "Gujarat" to listOf("Ahmedabad", "Surat", "Vadodara", "Rajkot", "Bhavnagar", "Jamnagar", "Junagadh", "Gandhinagar", "Anand", "Nadiad", "Bharuch", "Vapi", "Valsad", "Mehsana", "Bhuj", "Navsari", "Morbi", "Patan", "Porbandar", "Godhra", "Palanpur", "Palitana"),
    "Maharashtra" to listOf("Mumbai", "Pune", "Nagpur", "Nashik", "Thane", "Aurangabad", "Solapur", "Amravati", "Kolhapur", "Navi Mumbai", "Akola", "Latur", "Dhule", "Ahmednagar", "Jalgaon"),
    "Rajasthan" to listOf("Jaipur", "Jodhpur", "Udaipur", "Kota", "Bikaner", "Ajmer", "Bhilwara", "Alwar", "Sikar", "Pali", "Chittorgarh", "Sri Ganganagar", "Mount Abu"),
    "Delhi" to listOf("Delhi", "New Delhi", "North Delhi", "South Delhi", "West Delhi", "East Delhi"),
    "Karnataka" to listOf("Bengaluru", "Mysuru", "Hubballi", "Mangaluru", "Belagavi"),
    "Tamil Nadu" to listOf("Chennai", "Coimbatore", "Madurai", "Tiruchirappalli", "Salem"),
    "Uttar Pradesh" to listOf("Lucknow", "Kanpur", "Varanasi", "Agra", "Meerut", "Noida", "Ghaziabad", "Prayagraj"),
    "West Bengal" to listOf("Kolkata", "Howrah", "Durgapur", "Asansol", "Siliguri")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthAndRegistrationScreen(
    viewModel: FormViewModel,
    onLoginSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 5 })

    // Step 0: Phone & OTP States
    var phoneInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var isSendingOtp by remember { mutableStateOf(false) }
    var isVerifyingOtp by remember { mutableStateOf(false) }
    var isOtpSent by remember { mutableStateOf(false) }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var resendToken by remember { mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null) }
    var phoneError by remember { mutableStateOf<String?>(null) }
    var otpError by remember { mutableStateOf<String?>(null) }
    var isExistingUserRecord by remember { mutableStateOf(false) }
    var existingRecordFetched by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }

    // Step 1: Rules & Regulations
    var rule1Agreed by remember { mutableStateOf(false) }
    var rule2Agreed by remember { mutableStateOf(false) }
    var rulesError by remember { mutableStateOf(false) }

    // Step 2: Personal Details
    var fullName by remember { mutableStateOf("") }
    var fatherName by remember { mutableStateOf("") }
    var motherName by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var age by remember { mutableStateOf("") }
    var bloodGroup by remember { mutableStateOf("") }
    var maritalStatus by remember { mutableStateOf("Unmarried") }
    var anniversaryDate by remember { mutableStateOf("") }
    var education by remember { mutableStateOf("") }
    var workingStatus by remember { mutableStateOf("") }
    var otherProfession by remember { mutableStateOf("") }
    var workDescription by remember { mutableStateOf("") }

    // Step 3: Contact Details
    var contactNo by remember { mutableStateOf("") }
    var emailId by remember { mutableStateOf("") }
    var emergencyName by remember { mutableStateOf("") }
    var emergencyRelation by remember { mutableStateOf("") }
    var emergencyContactNo by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var state by remember { mutableStateOf("Madhya Pradesh") }
    var city by remember { mutableStateOf("Indore") }
    var pincode by remember { mutableStateOf("") }

    // Step 4: Religious Details
    // Mandir Vidhi
    var subMandirDohe by remember { mutableStateOf(false) }
    var subMandirChaitya by remember { mutableStateOf(false) }
    // 2 Pratikraman
    var sub2Vanditu by remember { mutableStateOf(false) }
    var sub2Jagchintamani by remember { mutableStateOf(false) }
    var sub2Bharser by remember { mutableStateOf(false) }
    var sub2LaghuShanti by remember { mutableStateOf(false) }
    var sub2SakalaTirth by remember { mutableStateOf(false) }
    // 5 Pratikraman
    var sub5Saklarhat by remember { mutableStateOf(false) }
    var sub5Snatasya by remember { mutableStateOf(false) }
    var sub5Atichar by remember { mutableStateOf(false) }
    var sub5AjitShanti by remember { mutableStateOf(false) }
    var sub5BadiShanti by remember { mutableStateOf(false) }
    var sub5Santikaram by remember { mutableStateOf(false) }
    // Other Learning
    var otherLearnings by remember { mutableStateOf(listOf("")) }

    // Specialities
    var specPratikraman by remember { mutableStateOf(false) }
    var specVaanchan by remember { mutableStateOf(false) }
    var specBhakti by remember { mutableStateOf(false) }
    var specOther by remember { mutableStateOf(false) }
    var specOtherText by remember { mutableStateOf("") }

    var joiningYear by remember { mutableStateOf("") }
    var paryushanCount by remember { mutableStateOf("") }
    var isParyushanCountLocked by remember { mutableStateOf(false) }

    var anotherGroup by remember { mutableStateOf("") }
    var postInGroup by remember { mutableStateOf("") }

    // Daily routine activities
    var actNavkarshi by remember { mutableStateOf(false) }
    var actPrabhuPujan by remember { mutableStateOf(false) }
    var actRatriBhojanTyag by remember { mutableStateOf(false) }
    var actTithiPalan by remember { mutableStateOf(false) }
    var actNavkarPakkiMala by remember { mutableStateOf(false) }
    var actSamaiyk by remember { mutableStateOf(false) }
    var actPratikaman by remember { mutableStateOf(false) }
    var actOther by remember { mutableStateOf(false) }
    var otherDailyActivities by remember { mutableStateOf(listOf("")) }

    // Lifetime tapasya
    var lifetimeTapasyaList by remember { mutableStateOf(listOf("")) }

    var isSubmitting by remember { mutableStateOf(false) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var datePickerTarget by remember { mutableStateOf("dob") } // "dob" or "anniversary"

    fun populateFromEntity(data: SwadhyaiFormEntity) {
        existingRecordFetched = data
        isExistingUserRecord = true
        fullName = data.fullName
        fatherName = data.fatherName
        motherName = data.motherName
        dob = data.dob
        age = if (data.age > 0) data.age.toString() else ""
        bloodGroup = data.bloodGroup
        maritalStatus = if (data.maritalStatus.isNotBlank()) data.maritalStatus else "Unmarried"
        anniversaryDate = data.anniversaryDate
        education = data.education
        
        if (data.workingStatus.startsWith("Other: ")) {
            workingStatus = "Others"
            otherProfession = data.workingStatus.removePrefix("Other: ")
        } else {
            workingStatus = data.workingStatus
        }
        workDescription = data.workDescription

        contactNo = data.contactNo
        emailId = data.email
        emergencyName = data.emergencyContactName
        emergencyRelation = data.emergencyContactRelation
        emergencyContactNo = data.emergencyContactNo
        address = data.address
        if (data.state.isNotBlank()) state = data.state
        if (data.city.isNotBlank()) city = data.city
        pincode = data.pincode

        joiningYear = if (data.joiningYear > 0) data.joiningYear.toString() else ""
        if (data.paryushanCount >= 0) {
            paryushanCount = data.paryushanCount.toString()
            isParyushanCountLocked = true
        }

        anotherGroup = data.anotherGroup
        postInGroup = data.postInGroup

        // Parse specialities
        val specs = data.specialities.split(",").map { it.trim() }
        specPratikraman = specs.any { it.equals("Pratikraman", true) }
        specVaanchan = specs.any { it.equals("Vaanchan", true) || it.equals("Vaachna", true) }
        specBhakti = specs.any { it.equals("Bhakti", true) }
        val otherSpec = specs.firstOrNull { it.startsWith("Other: ") }
        if (otherSpec != null) {
            specOther = true
            specOtherText = otherSpec.removePrefix("Other: ")
        }

        // Parse religious learnings
        val learnings = data.religiousLearnings
        subMandirDohe = learnings.contains("Asht Prakari Puja ke Dohe")
        subMandirChaitya = learnings.contains("Chaityawandan Vidhi")
        sub2Vanditu = learnings.contains("Vanditu")
        sub2Jagchintamani = learnings.contains("Jagchintamani")
        sub2Bharser = learnings.contains("Bharser")
        sub2LaghuShanti = learnings.contains("Laghu Shanti")
        sub2SakalaTirth = learnings.contains("Sakala Tirth")
        sub5Saklarhat = learnings.contains("Saklarhat")
        sub5Snatasya = learnings.contains("Snatasya")
        sub5Atichar = learnings.contains("Atichar")
        sub5AjitShanti = learnings.contains("Ajit Shanti")
        sub5BadiShanti = learnings.contains("Badi Shanti")
        sub5Santikaram = learnings.contains("Santikaram")

        // Daily activities
        val acts = data.dailyRoutineActivities.split(",").map { it.trim() }
        actNavkarshi = acts.any { it.equals("Navkarshi", true) }
        actPrabhuPujan = acts.any { it.equals("Prabhu Pujan", true) }
        actRatriBhojanTyag = acts.any { it.equals("Ratri Bhojan Tyag", true) }
        actTithiPalan = acts.any { it.equals("Tithi Palan", true) }
        actNavkarPakkiMala = acts.any { it.equals("Navkar Pakki Mala", true) }
        actSamaiyk = acts.any { it.equals("Samaiyk", true) }
        actPratikaman = acts.any { it.equals("Pratikaman", true) }

        // Lifetime tapasya
        val tapasya = data.lifetimeTapasya.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
        if (tapasya.isNotEmpty()) {
            lifetimeTapasyaList = tapasya
        }
    }

    suspend fun checkExistingRecordInFirestore(cleanPhone: String): SwadhyaiFormEntity? {
        return withContext(Dispatchers.IO) {
            try {
                val db = FirebaseFirestore.getInstance()

                // Helper to extract entity from DocumentSnapshot safely
                fun extractEntity(doc: com.google.firebase.firestore.DocumentSnapshot): SwadhyaiFormEntity {
                    fun getStr(vararg keys: String): String {
                        for (k in keys) {
                            val v = doc.get(k)
                            if (v != null) {
                                val s = v.toString().trim()
                                if (s.isNotEmpty()) return s
                            }
                        }
                        return ""
                    }
                    fun getNum(vararg keys: String): Int {
                        for (k in keys) {
                            val v = doc.get(k)
                            if (v is Number) return v.toInt()
                            if (v is String) v.toIntOrNull()?.let { return it }
                        }
                        return 0
                    }
                    fun getListStr(vararg keys: String): String {
                        for (k in keys) {
                            val v = doc.get(k)
                            if (v is List<*>) {
                                return v.filterNotNull().map { it.toString() }.joinToString(", ")
                            } else if (v is String && v.isNotBlank()) {
                                return v
                            }
                        }
                        return ""
                    }
                    fun getLearnings(vararg keys: String): String {
                        for (k in keys) {
                            val v = doc.get(k)
                            if (v is List<*>) {
                                return v.filterNotNull().map { it.toString() }.joinToString("\n")
                            } else if (v is String && v.isNotBlank()) {
                                return v
                            }
                        }
                        return ""
                    }

                    val fName = getStr("fullName", "full_name", "name", "swadhyaiName", "swadhyai_name")
                    val fthName = getStr("fatherName", "father_name", "father")
                    val mthName = getStr("motherName", "mother_name", "mother")
                    val gndr = getStr("gender", "sex", "genderName", "ling").ifEmpty { "Male" }
                    val dOfB = getStr("dob", "dateOfBirth", "date_of_birth", "birthDate")
                    val uAge = getNum("age")
                    val bGroup = getStr("bloodGroup", "blood_group", "bloodgroup")
                    val mStatus = getStr("maritalStatus", "marital_status", "marital").ifEmpty { "Unmarried" }
                    val annivDate = getStr("anniversaryDate", "anniversary_date", "anniversary")
                    val mail = getStr("email", "emailId", "email_id", "emailAddress")
                    val wPhone = getStr("whatsappNo", "whatsapp_no", "whatsappNumber", "whatsapp", "userPhone", "searchPhone", "mobile", "phone").ifEmpty { cleanPhone }
                    val cPhone = getStr("contactNo", "contact_no", "contactNumber", "contact")
                    val eName = getStr("emergencyContactName", "emergency_contact_name", "emergencyContactPerson")
                    val eRel = getStr("emergencyContactRelation", "emergency_contact_relation", "emergencyRelation")
                    val eNo = getStr("emergencyContactNo", "emergency_contact_no", "emergencyNo", "emergency")
                    val addr = getStr("address", "full_address", "residenceAddress")
                    val cty = getStr("city", "cityName", "city_name", "district")
                    val pin = getStr("pincode", "pin_code", "pin", "zip")
                    val st = getStr("state", "stateName", "state_name")
                    val nat = getStr("nativePlace", "native_place", "moolNiwas", "mool_niwas")
                    val edu = getStr("education", "qualification", "degree")
                    val wStatus = getStr("workingStatus", "working_status", "occupation", "profession")
                    val wDesc = getStr("workDescription", "work_description", "occupationDetail", "businessDetail")
                    val jYear = getNum("joiningYear")
                    val specs = getListStr("specialities", "speciality", "specialSkills", "specialityList")
                    val rLearnings = getLearnings("religiousLearningsFormatted", "religiousLearnings", "religious_learnings", "religiousLearning", "dharmikGyan")
                    val aGroup = getStr("anotherGroup", "another_group", "otherGroup", "groupName")
                    val pGroup = getStr("postInGroup", "post_in_group", "postName", "designation")
                    val pCount = getNum("paryushanCount")
                    val pHist = getStr("paryushanHistoryLog", "paryushan_history_log", "aradhanaHistory")
                    val dActivities = getListStr("dailyRoutineActivities", "daily_routine_activities", "dailyRoutineActivity", "dailyActivities")
                    val lTapasya = getListStr("lifetimeTapasya", "lifetime_tapasya", "lifetimeTyag", "tapasya")
                    val pWill = getStr("paryushanWillingness", "paryushan_willingness", "availableForParyushan")
                    val accRules = try { (doc.get("acceptedRules") as? Boolean) ?: true } catch (e: Exception) { true }
                    val rem = getStr("remarks", "remark", "comments", "additionalInfo", "notes")
                    val pImg = getStr("profileImageUri", "profileImage", "photoUrl", "photo", "imageUrl", "image")

                    return SwadhyaiFormEntity(
                        id = doc.id.toLongOrNull() ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L),
                        firestoreDocId = doc.id,
                        fullName = fName,
                        fatherName = fthName,
                        motherName = mthName,
                        gender = gndr,
                        dob = dOfB,
                        age = uAge,
                        bloodGroup = bGroup,
                        maritalStatus = mStatus,
                        anniversaryDate = annivDate,
                        email = mail,
                        whatsappNo = wPhone,
                        contactNo = cPhone,
                        emergencyContactName = eName,
                        emergencyContactRelation = eRel,
                        emergencyContactNo = eNo,
                        address = addr,
                        city = cty,
                        pincode = pin,
                        state = st,
                        nativePlace = nat,
                        education = edu,
                        workingStatus = wStatus,
                        workDescription = wDesc,
                        joiningYear = jYear,
                        specialities = specs,
                        religiousLearnings = rLearnings,
                        anotherGroup = aGroup,
                        postInGroup = pGroup,
                        paryushanCount = pCount,
                        paryushanHistoryLog = pHist,
                        dailyRoutineActivities = dActivities,
                        lifetimeTapasya = lTapasya,
                        paryushanWillingness = pWill,
                        acceptedRules = accRules,
                        remarks = rem,
                        profileImageUri = pImg
                    )
                }

                // 1. Direct doc ID lookups: phone_$cleanPhone, $cleanPhone, +91$cleanPhone
                val potentialDocIds = listOf("phone_$cleanPhone", cleanPhone, "+91$cleanPhone")
                for (docId in potentialDocIds) {
                    try {
                        val task = db.collection("swadhyai_forms").document(docId).get()
                        val doc = com.google.android.gms.tasks.Tasks.await(task)
                        if (doc != null && doc.exists() && doc.data != null) {
                            val entity = extractEntity(doc)
                            if (entity.fullName.isNotBlank() || entity.address.isNotBlank()) {
                                return@withContext entity
                            }
                        }
                    } catch (_: Exception) {}
                }

                // 2. Query by searchPhone / whatsappNo / contactNo / userPhone
                val phoneFields = listOf("searchPhone", "whatsappNo", "userPhone", "contactNo", "mobile", "phone")
                for (field in phoneFields) {
                    for (phoneVariant in listOf(cleanPhone, "+91$cleanPhone", "+91 $cleanPhone")) {
                        try {
                            val queryTask = db.collection("swadhyai_forms")
                                .whereEqualTo(field, phoneVariant)
                                .limit(1)
                                .get()
                            val snapshot = com.google.android.gms.tasks.Tasks.await(queryTask)
                            if (snapshot != null && !snapshot.isEmpty) {
                                val doc = snapshot.documents.first()
                                val entity = extractEntity(doc)
                                if (entity.fullName.isNotBlank() || entity.address.isNotBlank()) {
                                    return@withContext entity
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }

                // 3. Fallback: Query all documents and scan for cleanPhone matching inside whatsappNo, contactNo, or userPhone
                try {
                    val allDocsTask = db.collection("swadhyai_forms").get()
                    val allDocs = com.google.android.gms.tasks.Tasks.await(allDocsTask)
                    if (allDocs != null) {
                        for (doc in allDocs.documents) {
                            val entity = extractEntity(doc)
                            val wClean = entity.whatsappNo.replace("[^0-9]".toRegex(), "").takeLast(10)
                            val cClean = entity.contactNo.replace("[^0-9]".toRegex(), "").takeLast(10)
                            if (wClean == cleanPhone || cClean == cleanPhone) {
                                return@withContext entity
                            }
                        }
                    }
                } catch (_: Exception) {}

                null
            } catch (e: Exception) {
                null
            }
        }
    }

    // Phone Auth verification callbacks
    val phoneAuthCallback = remember {
        object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                isSendingOtp = false
                isVerifyingOtp = true
                val code = credential.smsCode
                if (!code.isNullOrBlank()) {
                    otpInput = code
                }
                coroutineScope.launch {
                    val cleanPhone = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
                    val existing = checkExistingRecordInFirestore(cleanPhone)
                    if (existing != null) {
                        populateFromEntity(existing)
                    }
                    isVerifyingOtp = false
                    pagerState.animateScrollToPage(1)
                }
            }

            override fun onVerificationFailed(e: FirebaseException) {
                isSendingOtp = false
                phoneError = e.localizedMessage ?: "OTP sending failed. Check phone number."
            }

            override fun onCodeSent(
                vId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                isSendingOtp = false
                isOtpSent = true
                verificationId = vId
                resendToken = token
                Toast.makeText(context, "OTP sent successfully to +91 $phoneInput", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun sendOtp() {
        val clean = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (clean.length != 10) {
            phoneError = "Please enter a valid 10-digit WhatsApp number"
            return
        }
        phoneError = null
        isSendingOtp = true

        val activity = context as? Activity
        if (activity == null) {
            // Testing fallback
            isSendingOtp = false
            isOtpSent = true
            verificationId = "test_verification_id"
            Toast.makeText(context, "Testing mode: Enter your 6-digit OTP", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val options = PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
                .setPhoneNumber("+91$clean")
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(activity)
                .setCallbacks(phoneAuthCallback)
                .build()
            PhoneAuthProvider.verifyPhoneNumber(options)
        } catch (e: Exception) {
            isSendingOtp = false
            isOtpSent = true
            verificationId = "test_verification_id"
            Toast.makeText(context, "Enter your configured OTP", Toast.LENGTH_SHORT).show()
        }
    }

    fun verifyOtp() {
        if (otpInput.length < 4) {
            otpError = "Please enter valid OTP"
            return
        }
        otpError = null
        isVerifyingOtp = true

        coroutineScope.launch {
            val cleanPhone = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
            
            // Check existing records in cloud
            val existing = checkExistingRecordInFirestore(cleanPhone)
            if (existing != null) {
                populateFromEntity(existing)
            }
            
            isVerifyingOtp = false
            pagerState.animateScrollToPage(1)
        }
    }

    fun calculateAgeFromDob(dobStr: String) {
        try {
            val parts = dobStr.split("/")
            if (parts.size == 3) {
                val day = parts[0].toIntOrNull() ?: 1
                val monthName = parts[1]
                val year = parts[2].toIntOrNull() ?: 2000
                val monthMap = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                val month = monthMap.indexOfFirst { it.equals(monthName, true) }.let { if (it >= 0) it else 0 }

                val dobCal = Calendar.getInstance().apply { set(year, month, day) }
                val today = Calendar.getInstance()
                var calculatedAge = today.get(Calendar.YEAR) - dobCal.get(Calendar.YEAR)
                if (today.get(Calendar.DAY_OF_YEAR) < dobCal.get(Calendar.DAY_OF_YEAR)) {
                    calculatedAge--
                }
                if (calculatedAge >= 0) {
                    age = calculatedAge.toString()
                }
            }
        } catch (_: Exception) {}
    }

    fun handleProceedFromRules() {
        if (!rule1Agreed || !rule2Agreed) {
            rulesError = true
            return
        }
        rulesError = false

        coroutineScope.launch {
            val cleanPhone = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
            val existing = existingRecordFetched ?: checkExistingRecordInFirestore(cleanPhone)

            if (existing != null && existing.fullName.isNotBlank() && existing.address.isNotBlank()) {
                // If user details already exist and are fully populated -> Directly log in to Home!
                val isAdmin = UserSessionManager.isMasterAdminPhone(cleanPhone)
                UserSessionManager.login(
                    phone = cleanPhone,
                    fullName = existing.fullName,
                    profile = existing,
                    isAdminOverride = isAdmin
                )
                Toast.makeText(context, "Welcome back, ${UserSessionManager.extractFirstName(existing.fullName)}!", Toast.LENGTH_SHORT).show()
                onLoginSuccess()
            } else {
                // New user or needs completion -> Move to Personal Details step
                pagerState.animateScrollToPage(2)
            }
        }
    }

    fun submitRegistration() {
        val cleanPhone = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (fullName.isBlank()) {
            Toast.makeText(context, "Please enter Full Name", Toast.LENGTH_SHORT).show()
            coroutineScope.launch { pagerState.animateScrollToPage(2) }
            return
        }
        if (emergencyContactNo.isBlank()) {
            Toast.makeText(context, "Please enter Emergency Contact No.", Toast.LENGTH_SHORT).show()
            coroutineScope.launch { pagerState.animateScrollToPage(3) }
            return
        }
        if (address.isBlank()) {
            Toast.makeText(context, "Please enter Address", Toast.LENGTH_SHORT).show()
            coroutineScope.launch { pagerState.animateScrollToPage(3) }
            return
        }

        isSubmitting = true

        coroutineScope.launch {
            val specialitiesList = mutableListOf<String>()
            if (specPratikraman) specialitiesList.add("Pratikraman")
            if (specVaanchan) specialitiesList.add("Vaanchan")
            if (specBhakti) specialitiesList.add("Bhakti")
            if (specOther && specOtherText.isNotBlank()) specialitiesList.add("Other: $specOtherText")

            val religiousLearningsList = mutableListOf<String>()
            if (subMandirDohe) religiousLearningsList.add("Asht Prakari Puja ke Dohe")
            if (subMandirChaitya) religiousLearningsList.add("Chaityawandan Vidhi")
            if (sub2Vanditu) religiousLearningsList.add("Vanditu")
            if (sub2Jagchintamani) religiousLearningsList.add("Jagchintamani Chaityawandan")
            if (sub2Bharser) religiousLearningsList.add("Bharser Sajjhay")
            if (sub2LaghuShanti) religiousLearningsList.add("Laghu Shanti")
            if (sub2SakalaTirth) religiousLearningsList.add("Sakala Tirth")
            if (sub5Saklarhat) religiousLearningsList.add("Saklarhat Chaityawandan")
            if (sub5Snatasya) religiousLearningsList.add("Snatasya Thui")
            if (sub5Atichar) religiousLearningsList.add("Atichar")
            if (sub5AjitShanti) religiousLearningsList.add("Ajit Shanti")
            if (sub5BadiShanti) religiousLearningsList.add("Badi Shanti")
            if (sub5Santikaram) religiousLearningsList.add("Santikaram")
            otherLearnings.filter { it.isNotBlank() }.forEach { religiousLearningsList.add("Other: $it") }

            val dailyActivitiesList = mutableListOf<String>()
            if (actNavkarshi) dailyActivitiesList.add("Navkarshi")
            if (actPrabhuPujan) dailyActivitiesList.add("Prabhu Pujan")
            if (actRatriBhojanTyag) dailyActivitiesList.add("Ratri Bhojan Tyag")
            if (actTithiPalan) dailyActivitiesList.add("Tithi Palan")
            if (actNavkarPakkiMala) dailyActivitiesList.add("Navkar Pakki Mala")
            if (actSamaiyk) dailyActivitiesList.add("Samaiyk")
            if (actPratikaman) dailyActivitiesList.add("Pratikaman")
            otherDailyActivities.filter { it.isNotBlank() }.forEach { dailyActivitiesList.add("Other: $it") }

            val lifetimeList = lifetimeTapasyaList.filter { it.isNotBlank() }

            val pCount = paryushanCount.toIntOrNull() ?: 0
            val jYear = joiningYear.toIntOrNull() ?: 0
            val userAge = age.toIntOrNull() ?: 0

            val workVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) {
                "Other: $otherProfession"
            } else {
                workingStatus
            }

            val entity = SwadhyaiFormEntity(
                firestoreDocId = "phone_$cleanPhone",
                fullName = fullName.trim(),
                fatherName = fatherName.trim(),
                motherName = motherName.trim(),
                gender = "Male",
                dob = dob.trim(),
                age = userAge,
                bloodGroup = bloodGroup.trim(),
                maritalStatus = maritalStatus,
                anniversaryDate = if (maritalStatus == "Married") anniversaryDate.trim() else "",
                email = emailId.trim(),
                whatsappNo = cleanPhone,
                contactNo = contactNo.trim(),
                emergencyContactName = emergencyName.trim(),
                emergencyContactRelation = emergencyRelation.trim(),
                emergencyContactNo = emergencyContactNo.trim(),
                address = address.trim(),
                city = city.trim(),
                pincode = pincode.trim(),
                state = state.trim(),
                education = education.trim(),
                workingStatus = workVal.trim(),
                workDescription = workDescription.trim(),
                joiningYear = jYear,
                specialities = specialitiesList.joinToString(", "),
                religiousLearnings = religiousLearningsList.joinToString("\n"),
                anotherGroup = anotherGroup.trim(),
                postInGroup = postInGroup.trim(),
                paryushanCount = pCount,
                dailyRoutineActivities = dailyActivitiesList.joinToString(", "),
                lifetimeTapasya = lifetimeList.joinToString(", "),
                acceptedRules = true
            )

            // Save to Firestore
            withContext(Dispatchers.IO) {
                try {
                    val db = FirebaseFirestore.getInstance()
                    val map = hashMapOf(
                        "userPhone" to "+91$cleanPhone",
                        "searchPhone" to cleanPhone,
                        "isPhoneVerified" to true,
                        "fullName" to entity.fullName,
                        "fatherName" to entity.fatherName,
                        "motherName" to entity.motherName,
                        "dob" to entity.dob,
                        "age" to entity.age,
                        "bloodGroup" to entity.bloodGroup,
                        "maritalStatus" to entity.maritalStatus,
                        "anniversaryDate" to entity.anniversaryDate,
                        "whatsappNo" to cleanPhone,
                        "contactNo" to entity.contactNo,
                        "emailId" to entity.email,
                        "emergencyContactName" to entity.emergencyContactName,
                        "emergencyContactRelation" to entity.emergencyContactRelation,
                        "emergencyContactNo" to entity.emergencyContactNo,
                        "address" to entity.address,
                        "city" to entity.city,
                        "pincode" to entity.pincode,
                        "state" to entity.state,
                        "education" to entity.education,
                        "workingStatus" to entity.workingStatus,
                        "workDescription" to entity.workDescription,
                        "joiningYear" to entity.joiningYear,
                        "specialities" to specialitiesList,
                        "religiousLearnings" to religiousLearningsList,
                        "anotherGroup" to entity.anotherGroup,
                        "postInGroup" to entity.postInGroup,
                        "paryushanCount" to entity.paryushanCount,
                        "dailyRoutineActivities" to dailyActivitiesList,
                        "lifetimeTapasya" to lifetimeList,
                        "acceptedRules" to true,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    db.collection("swadhyai_forms").document("phone_$cleanPhone").set(map, SetOptions.merge())
                } catch (e: Exception) {
                    // Ignore offline failure, local state persists
                }
            }

            val isAdmin = UserSessionManager.isMasterAdminPhone(cleanPhone)
            UserSessionManager.login(
                phone = cleanPhone,
                fullName = entity.fullName,
                profile = entity,
                isAdminOverride = isAdmin
            )

            isSubmitting = false
            Toast.makeText(context, "Registration saved successfully!", Toast.LENGTH_LONG).show()
            onLoginSuccess()
        }
    }

    BackHandler(enabled = pagerState.currentPage > 0) {
        coroutineScope.launch {
            pagerState.animateScrollToPage(pagerState.currentPage - 1)
        }
    }

    Scaffold(
        containerColor = AppBackground,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Top Progress Bar for Registration Steps
            if (pagerState.currentPage > 0) {
                Surface(
                    color = AppDeepSurface,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when (pagerState.currentPage) {
                                    1 -> "Step 1: Rules & Regulations"
                                    2 -> "Step 2: Personal Details"
                                    3 -> "Step 3: Contact Details"
                                    4 -> "Step 4: Religious Details"
                                    else -> ""
                                },
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppPrimaryGold
                                )
                            )
                            Text(
                                text = "Step ${pagerState.currentPage} of 4",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    color = AppTextMuted
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { pagerState.currentPage / 4f },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = AppPrimaryGold,
                            trackColor = AppSurface
                        )
                    }
                }
            }

            HorizontalPager(
                state = pagerState,
                userScrollEnabled = false,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) { page ->
                when (page) {
                    0 -> WelcomePhoneLoginStep(
                        phoneInput = phoneInput,
                        onPhoneChange = { phoneInput = it; phoneError = null },
                        otpInput = otpInput,
                        onOtpChange = { otpInput = it; otpError = null },
                        isOtpSent = isOtpSent,
                        isSendingOtp = isSendingOtp,
                        isVerifyingOtp = isVerifyingOtp,
                        phoneError = phoneError,
                        otpError = otpError,
                        onSendOtp = { sendOtp() },
                        onVerifyOtp = { verifyOtp() },
                        onChangePhone = {
                            isOtpSent = false
                            otpInput = ""
                            otpError = null
                        }
                    )

                    1 -> RulesAndRegulationsStep(
                        rule1Agreed = rule1Agreed,
                        onRule1Change = { rule1Agreed = it; rulesError = false },
                        rule2Agreed = rule2Agreed,
                        onRule2Change = { rule2Agreed = it; rulesError = false },
                        rulesError = rulesError,
                        onProceed = { handleProceedFromRules() }
                    )

                    2 -> PersonalDetailsStep(
                        fullName = fullName,
                        onFullNameChange = { fullName = it },
                        fatherName = fatherName,
                        onFatherNameChange = { fatherName = it },
                        motherName = motherName,
                        onMotherNameChange = { motherName = it },
                        dob = dob,
                        age = age,
                        onOpenDatePicker = {
                            datePickerTarget = "dob"
                            showDatePickerDialog = true
                        },
                        bloodGroup = bloodGroup,
                        onBloodGroupChange = { bloodGroup = it },
                        maritalStatus = maritalStatus,
                        onMaritalStatusChange = { maritalStatus = it },
                        anniversaryDate = anniversaryDate,
                        onOpenAnniversaryDatePicker = {
                            datePickerTarget = "anniversary"
                            showDatePickerDialog = true
                        },
                        education = education,
                        onEducationChange = { education = it },
                        workingStatus = workingStatus,
                        onWorkingStatusChange = { workingStatus = it },
                        otherProfession = otherProfession,
                        onOtherProfessionChange = { otherProfession = it },
                        workDescription = workDescription,
                        onWorkDescriptionChange = { workDescription = it },
                        onNext = {
                            if (fullName.isBlank() || fatherName.isBlank() || motherName.isBlank() || dob.isBlank() || workingStatus.isBlank()) {
                                Toast.makeText(context, "Please fill in all mandatory fields (*)", Toast.LENGTH_SHORT).show()
                            } else {
                                coroutineScope.launch { pagerState.animateScrollToPage(3) }
                            }
                        }
                    )

                    3 -> ContactDetailsStep(
                        whatsappNo = phoneInput.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10),
                        contactNo = contactNo,
                        onContactNoChange = { contactNo = it },
                        emailId = emailId,
                        onEmailChange = { emailId = it },
                        emergencyName = emergencyName,
                        onEmergencyNameChange = { emergencyName = it },
                        emergencyRelation = emergencyRelation,
                        onEmergencyRelationChange = { emergencyRelation = it },
                        emergencyContactNo = emergencyContactNo,
                        onEmergencyContactNoChange = { emergencyContactNo = it },
                        address = address,
                        onAddressChange = { address = it },
                        state = state,
                        onStateChange = { state = it },
                        city = city,
                        onCityChange = { city = it },
                        pincode = pincode,
                        onPincodeChange = { pincode = it },
                        onBack = { coroutineScope.launch { pagerState.animateScrollToPage(2) } },
                        onNext = {
                            if (emergencyName.isBlank() || emergencyContactNo.isBlank() || address.isBlank() || city.isBlank() || pincode.isBlank()) {
                                Toast.makeText(context, "Please fill in all mandatory fields (*)", Toast.LENGTH_SHORT).show()
                            } else {
                                coroutineScope.launch { pagerState.animateScrollToPage(4) }
                            }
                        }
                    )

                    4 -> ReligiousDetailsStep(
                        subMandirDohe = subMandirDohe,
                        onSubMandirDoheChange = { subMandirDohe = it },
                        subMandirChaitya = subMandirChaitya,
                        onSubMandirChaityaChange = { subMandirChaitya = it },
                        sub2Vanditu = sub2Vanditu,
                        onSub2VandituChange = { sub2Vanditu = it },
                        sub2Jagchintamani = sub2Jagchintamani,
                        onSub2JagchintamaniChange = { sub2Jagchintamani = it },
                        sub2Bharser = sub2Bharser,
                        onSub2BharserChange = { sub2Bharser = it },
                        sub2LaghuShanti = sub2LaghuShanti,
                        onSub2LaghuShantiChange = { sub2LaghuShanti = it },
                        sub2SakalaTirth = sub2SakalaTirth,
                        onSub2SakalaTirthChange = { sub2SakalaTirth = it },
                        sub5Saklarhat = sub5Saklarhat,
                        onSub5SaklarhatChange = { sub5Saklarhat = it },
                        sub5Snatasya = sub5Snatasya,
                        onSub5SnatasyaChange = { sub5Snatasya = it },
                        sub5Atichar = sub5Atichar,
                        onSub5AticharChange = { sub5Atichar = it },
                        sub5AjitShanti = sub5AjitShanti,
                        onSub5AjitShantiChange = { sub5AjitShanti = it },
                        sub5BadiShanti = sub5BadiShanti,
                        onSub5BadiShantiChange = { sub5BadiShanti = it },
                        sub5Santikaram = sub5Santikaram,
                        onSub5SantikaramChange = { sub5Santikaram = it },
                        otherLearnings = otherLearnings,
                        onOtherLearningsChange = { otherLearnings = it },
                        specPratikraman = specPratikraman,
                        onSpecPratikramanChange = { specPratikraman = it },
                        specVaanchan = specVaanchan,
                        onSpecVaanchanChange = { specVaanchan = it },
                        specBhakti = specBhakti,
                        onSpecBhaktiChange = { specBhakti = it },
                        specOther = specOther,
                        onSpecOtherChange = { specOther = it },
                        specOtherText = specOtherText,
                        onSpecOtherTextChange = { specOtherText = it },
                        joiningYear = joiningYear,
                        onJoiningYearChange = { joiningYear = it },
                        paryushanCount = paryushanCount,
                        onParyushanCountChange = { paryushanCount = it },
                        isParyushanCountLocked = isParyushanCountLocked,
                        anotherGroup = anotherGroup,
                        onAnotherGroupChange = { anotherGroup = it },
                        postInGroup = postInGroup,
                        onPostInGroupChange = { postInGroup = it },
                        actNavkarshi = actNavkarshi,
                        onActNavkarshiChange = { actNavkarshi = it },
                        actPrabhuPujan = actPrabhuPujan,
                        onActPrabhuPujanChange = { actPrabhuPujan = it },
                        actRatriBhojanTyag = actRatriBhojanTyag,
                        onActRatriBhojanTyagChange = { actRatriBhojanTyag = it },
                        actTithiPalan = actTithiPalan,
                        onActTithiPalanChange = { actTithiPalan = it },
                        actNavkarPakkiMala = actNavkarPakkiMala,
                        onActNavkarPakkiMalaChange = { actNavkarPakkiMala = it },
                        actSamaiyk = actSamaiyk,
                        onActSamaiykChange = { actSamaiyk = it },
                        actPratikaman = actPratikaman,
                        onActPratikamanChange = { actPratikaman = it },
                        otherDailyActivities = otherDailyActivities,
                        onOtherDailyActivitiesChange = { otherDailyActivities = it },
                        lifetimeTapasyaList = lifetimeTapasyaList,
                        onLifetimeTapasyaListChange = { lifetimeTapasyaList = it },
                        isSubmitting = isSubmitting,
                        onBack = { coroutineScope.launch { pagerState.animateScrollToPage(3) } },
                        onSubmit = { submitRegistration() }
                    )
                }
            }
        }
    }

    if (showDatePickerDialog) {
        CustomJainDatePickerDialog(
            title = if (datePickerTarget == "dob") "Select Date of Birth" else "Select Anniversary Date",
            onDateSelected = { dateStr ->
                if (datePickerTarget == "dob") {
                    dob = dateStr
                    calculateAgeFromDob(dateStr)
                } else {
                    anniversaryDate = dateStr
                }
                showDatePickerDialog = false
            },
            onDismiss = { showDatePickerDialog = false }
        )
    }
}

// ----------------------------------------------------
// Step 0: Welcome Screen with Big Logo & Phone Login
// ----------------------------------------------------
@Composable
fun WelcomePhoneLoginStep(
    phoneInput: String,
    onPhoneChange: (String) -> Unit,
    otpInput: String,
    onOtpChange: (String) -> Unit,
    isOtpSent: Boolean,
    isSendingOtp: Boolean,
    isVerifyingOtp: Boolean,
    phoneError: String?,
    otpError: String?,
    onSendOtp: () -> Unit,
    onVerifyOtp: () -> Unit,
    onChangePhone: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize()
    ) {
        val availableHeight = maxHeight
        // Only shrink slightly when the device height is constrained to prevent touching/cropping at the top
        val logoSize = when {
            availableHeight < 620.dp -> 180.dp
            availableHeight < 700.dp -> 205.dp
            availableHeight < 780.dp -> 228.dp
            else -> 248.dp
        }
        val topSpacer = if (availableHeight < 680.dp) 4.dp else 8.dp
        val bottomCardSpacer = if (availableHeight < 680.dp) 18.dp else 26.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(topSpacer))

            // App Logo Center with adaptive size so it never touches or gets cropped by the top screen
            Image(
                painter = painterResource(id = R.drawable.header_logo),
                contentDescription = "Swadhyai Sangh Logo",
                modifier = Modifier
                    .size(logoSize)
                    .clip(CircleShape)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "श्री वर्द्धमान स्वाध्याय संघ",
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFF8E7),
                    fontSize = 23.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Welcome Swadhyai",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = AppPrimaryGold,
                    fontSize = 20.sp,
                    letterSpacing = 1.sp
                ),
                textAlign = TextAlign.Center
            )

            Text(
                text = "।। जिन आज्ञा परमो धर्मः ।।",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = AppTextMuted,
                    fontWeight = FontWeight.Medium
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(bottomCardSpacer))

        // Phone Authentication Card
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header & Phone Number Section
                Column(
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "WhatsApp Number Verification",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )

                    // 1. Sliding WhatsApp Number Display with Plain Refresh Icon (no circle, zero extra space)
                    AnimatedVisibility(
                        visible = isOtpSent,
                        enter = expandVertically(animationSpec = tween(350)) + fadeIn(animationSpec = tween(300)) + slideInVertically(animationSpec = tween(350)) { -it / 2 },
                        exit = shrinkVertically(animationSpec = tween(300)) + fadeOut(animationSpec = tween(250)) + slideOutVertically(animationSpec = tween(300)) { -it / 2 }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val formattedPhone = if (phoneInput.length == 10) {
                                "+91 ${phoneInput.take(5)} ${phoneInput.drop(5)}"
                            } else {
                                "+91 $phoneInput"
                            }
                            Text(
                                text = formattedPhone,
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppPrimaryGold,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )

                            // Plain refresh icon button on right side (no circle, no background, no border)
                            IconButton(
                                onClick = onChangePhone,
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Change WhatsApp Number",
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                        }
                    }
                }

                // 2. Animated Input Box: WhatsApp Number converts smoothly to Verification OTP
                AnimatedContent(
                    targetState = isOtpSent,
                    transitionSpec = {
                        if (targetState) {
                            (slideInHorizontally(animationSpec = tween(320)) { width -> width / 3 } + fadeIn(animationSpec = tween(300)))
                                .togetherWith(slideOutHorizontally(animationSpec = tween(280)) { width -> -width / 3 } + fadeOut(animationSpec = tween(250)))
                        } else {
                            (slideInHorizontally(animationSpec = tween(320)) { width -> -width / 3 } + fadeIn(animationSpec = tween(300)))
                                .togetherWith(slideOutHorizontally(animationSpec = tween(280)) { width -> width / 3 } + fadeOut(animationSpec = tween(250)))
                        }
                    },
                    label = "InputBoxMorphAnimation"
                ) { otpSentState ->
                    if (!otpSentState) {
                        OutlinedTextField(
                            value = phoneInput,
                            onValueChange = { input ->
                                val digits = input.filter { it.isDigit() }.take(10)
                                onPhoneChange(digits)
                            },
                            label = { Text("WhatsApp Number") },
                            placeholder = { Text("Enter 10-digit WhatsApp No.") },
                            leadingIcon = {
                                Text(
                                    text = "+91 ",
                                    fontWeight = FontWeight.Bold,
                                    color = AppPrimaryGold,
                                    modifier = Modifier.padding(start = 12.dp)
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            isError = phoneError != null,
                            supportingText = {
                                if (phoneError != null) {
                                    Text(text = phoneError, color = MaterialTheme.colorScheme.error)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = { input ->
                                val digits = input.filter { it.isDigit() }.take(6)
                                onOtpChange(digits)
                            },
                            label = { Text("Verification OTP") },
                            placeholder = { Text("Enter 6-digit OTP") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "OTP Lock",
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.padding(start = 4.dp).size(20.dp)
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            isError = otpError != null,
                            supportingText = {
                                if (otpError != null) {
                                    Text(text = otpError, color = MaterialTheme.colorScheme.error)
                                } else {
                                    Text(text = "Enter 6-digit verification code", color = AppTextMuted, fontSize = 11.sp)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // 3. Action Buttons: Full-width button animates and divides into Resend OTP (left) & Verify (right)
                AnimatedContent(
                    targetState = isOtpSent,
                    transitionSpec = {
                        (fadeIn(animationSpec = tween(300)) + expandHorizontally(animationSpec = tween(320)))
                            .togetherWith(fadeOut(animationSpec = tween(220)) + shrinkHorizontally(animationSpec = tween(260)))
                    },
                    label = "ActionButtonSplitAnimation"
                ) { otpSentState ->
                    if (!otpSentState) {
                        Button(
                            onClick = onSendOtp,
                            enabled = phoneInput.length == 10 && !isSendingOtp,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AppPrimaryGold,
                                disabledContainerColor = AppPrimaryGold.copy(alpha = 0.4f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                        ) {
                            if (isSendingOtp) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sending OTP...", fontWeight = FontWeight.Bold)
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Send,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = Color.Black
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Send OTP", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.Black)
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left Button: Resend OTP
                            OutlinedButton(
                                onClick = onSendOtp,
                                enabled = !isSendingOtp,
                                border = BorderStroke(1.2.dp, AppPrimaryGold),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = AppDeepSurface,
                                    contentColor = AppPrimaryGold
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                            ) {
                                if (isSendingOtp) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = AppPrimaryGold, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Sending...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Refresh,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = AppPrimaryGold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Resend OTP", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                                }
                            }

                            // Right Button: Verify
                            Button(
                                onClick = onVerifyOtp,
                                enabled = otpInput.length >= 4 && !isVerifyingOtp,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AppSecondaryGreen,
                                    disabledContainerColor = AppSecondaryGreen.copy(alpha = 0.4f)
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(50.dp)
                            ) {
                                if (isVerifyingOtp) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Verifying...", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("Verify", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
}

// ----------------------------------------------------
// Step 1: Rules & Regulations
// ----------------------------------------------------
@Composable
fun RulesAndRegulationsStep(
    rule1Agreed: Boolean,
    onRule1Change: (Boolean) -> Unit,
    rule2Agreed: Boolean,
    onRule2Change: (Boolean) -> Unit,
    rulesError: Boolean,
    onProceed: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp)
            ) {
                // Header inside box
                Text(
                    text = "🌹 णमो वियरागाणां 🌹",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = AppPrimaryGold
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "धर्मानुरागी • जिन शासन प्रेमी • कल्याण मित्र • सादर प्रणाम",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFFFFD54F),
                        fontWeight = FontWeight.SemiBold
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppPrimaryGold.copy(alpha = 0.12f),
                    border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "।। प्रभु वीतराग स्वामी, यह प्रार्थना है मेरी,\nमैं निज स्वरूप पाऊँ, पाऊँ दशा तुम्हारी ।।",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFE082)
                        ),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "इसी शुभ भावना के साथ परम पूज्य गुरुवर्या \"जिन शिशु\" प्रज्ञा श्रीजी महाराज साहब ने हम सबको एक धागे में पिरोकर श्री वर्धमान स्वाध्याय संघ (मंडल) नाम की एक संस्था तैयार की है।\n\nइस संस्था का मुख्य उद्देश्य पर्वाधिराज पर्युषण महापर्व में जहाँ गुरु भगवंत का सान्निध्य उपलब्ध न हो, ऐसे श्रीसंघों में जाकर निःस्वार्थ भाव से स्वयं आराधना करना एवं करवाना है।\n\nपर्युषण में स्वाध्यायी बनकर जाने वाले प्रत्येक आराधक के लिए निम्नलिखित नियम एवं दिशा-निर्देश मान्य होंगे :",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextPrimary,
                        lineHeight = 20.sp
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                RuleSectionItem(
                    title = "1. धार्मिक क्रियाएँ एवं स्वाध्याय",
                    points = listOf(
                        "1.1 प्रतिक्रमण : प्रतिदिन राई एवं देवासीय प्रतिक्रमण अनिवार्य रूप से करेंगे।",
                        "1.2 पोषध व्रत : चौदस एवं संवत्सरी पर पोषध अवश्य करेंगे तथा अन्य आराधकों को भी प्रेरित करेंगे।",
                        "1.3 वांचन / प्रवचन मर्यादा : वांचन में केवल अष्टाह्निका व्याख्यान एवं कल्पसूत्रजी पर ही बोलेंगे। प्रवचन सामायिक लेकर ही करेंगे।",
                        "1.4 समूह क्रिया : सभी धार्मिक क्रियाएँ एवं कार्य अपने साथी (सह-आराधक) के साथ ही करेंगे।"
                    )
                )

                RuleSectionItem(
                    title = "2. संयम, तप एवं आहार मर्यादा",
                    points = listOf(
                        "2.1 तपस्या : प्रतिदिन कम से कम एकासना अवश्य करेंगे। स्वास्थ्य कारण होने पर ही बियासना अपवाद स्वरूप मान्य होगा।",
                        "2.2 आहार संयम : आहार में विशेष सावधानी रखेंगे। अभक्ष्य, द्विदल, सूखा मेवा, अचार, सचित्त/लीलोत्री, मैदा, कच्चा नमक आदि का त्याग रहेगा।",
                        "2.3 जल शुद्धि : बिना छाना पानी उपयोग नहीं करेंगे। स्नान करते समय शावर का उपयोग नहीं करेंगे।"
                    )
                )

                RuleSectionItem(
                    title = "3. वेशभूषा, प्रसाधन एवं त्याग",
                    points = listOf(
                        "3.1 मर्यादित वेशभूषा : केवल कुर्ता-पजामा अथवा मर्यादित वस्त्र पहनेंगे। अत्यधिक टाइट कपड़े नहीं पहनेंगे।",
                        "3.2 चर्म एवं शृंगार त्याग : शेविंग नहीं करेंगे। बेल्ट, पर्स, घड़ी अथवा चमड़े की किसी वस्तु का उपयोग नहीं करेंगे।",
                        "3.3 कॉस्मेटिक निषेध : शैम्पू, क्रीम, पाउडर, डियो, परफ्यूम आदि कॉस्मेटिक पूर्णतः वर्जित रहेंगे।",
                        "3.4 पादत्राण त्याग : पर्व के दिनों में जूते-चप्पल का पूर्ण त्याग रहेगा।"
                    )
                )

                RuleSectionItem(
                    title = "4. व्यवहार, अनुशासन एवं समय मर्यादा",
                    points = listOf(
                        "4.1 विनय व्यवहार : श्रीसंघ के प्रत्येक सदस्य के साथ विनयपूर्वक एवं विवेकपूर्ण व्यवहार करेंगे।",
                        "4.2 वाहन त्याग : पर्व के दौरान किसी भी प्रकार के वाहन का उपयोग नहीं करेंगे।",
                        "4.3 डिजिटल संयम : सार्वजनिक स्थानों पर मोबाइल, फोटो, वीडियो एवं सोशल मीडिया का उपयोग पूर्णतः वर्जित रहेगा।",
                        "4.4 समय मर्यादा : रात्रिकालीन कार्यक्रम रात्रि 10:00 से 10:30 बजे तक अनिवार्य रूप से समाप्त करेंगे।"
                    )
                )

                RuleSectionItem(
                    title = "5. यात्रा, व्यवस्था एवं बहुमान नीति",
                    points = listOf(
                        "5.1 यात्रा साधन : आने-जाने हेतु केवल Train (3rd AC) का उपयोग करेंगे।",
                        "5.2 बहुमान नीति : व्यक्तिगत बहुमान में नगद राशि स्वीकार नहीं करेंगे। केवल वस्तु बहुमान स्वीकार किया जा सकेगा।",
                        "5.3 असुविधा निवारण : किसी भी असुविधा को विवेकपूर्वक सुलझाएँ या संस्था की समिति से संपर्क करें।",
                        "5.4 शिविर में उपस्थिति : संस्था द्वारा आयोजित कार्यशाला (शिविर) में उपस्थिति अनिवार्य रहेगी।"
                    )
                )

                RuleSectionItem(
                    title = "6. संस्था की उत्तरदायित्व सीमा",
                    points = listOf(
                        "6.1 स्वास्थ्य दायित्व : पर्युषण के दौरान किसी भी प्रकार की अस्वस्थता की जिम्मेदारी स्वयं आराधक की होगी।",
                        "6.2 दुर्घटना / विवाद दायित्व : आने-जाने अथवा पर्युषण के दौरान किसी भी घटना की सम्पूर्ण जिम्मेदारी स्वयं आराधक की होगी। संस्था उत्तरदायी नहीं होगी।"
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Checkboxes that scroll with the rules and appear after the last rule
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AppDeepSurface,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onRule1Change(!rule1Agreed) }
                        ) {
                            Checkbox(
                                checked = rule1Agreed,
                                onCheckedChange = onRule1Change,
                                colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                            )
                            Text(
                                text = "संस्था के बनाए गए सभी नियम का पालन करूगा, जो की मुझे स्वीकार्य हे ! *",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onRule2Change(!rule2Agreed) }
                        ) {
                            Checkbox(
                                checked = rule2Agreed,
                                onCheckedChange = onRule2Change,
                                colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                            )
                            Text(
                                text = "संस्था के प्रति संपूर्ण निष्ठा और समर्पण रखूँगा ! *",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                        }

                        if (rulesError) {
                            Text(
                                text = "⚠️ कृपया आगे बढ़ने के लिए दोनों नियमों एवं शर्तों को स्वीकार करें।",
                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.error),
                                modifier = Modifier.padding(start = 12.dp, top = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = onProceed,
            colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Proceed / आगे बढ़ें ➔", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RuleSectionItem(title: String, points: List<String>) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = AppDeepSurface,
        border = BorderStroke(0.8.dp, AppBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
            points.forEach { pt ->
                Text(
                    text = "• $pt",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextPrimary,
                        lineHeight = 18.sp
                    ),
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }
    }
}

// ----------------------------------------------------
// Step 2: Personal Details
// ----------------------------------------------------
@Composable
fun PersonalDetailsStep(
    fullName: String,
    onFullNameChange: (String) -> Unit,
    fatherName: String,
    onFatherNameChange: (String) -> Unit,
    motherName: String,
    onMotherNameChange: (String) -> Unit,
    dob: String,
    age: String,
    onOpenDatePicker: () -> Unit,
    bloodGroup: String,
    onBloodGroupChange: (String) -> Unit,
    maritalStatus: String,
    onMaritalStatusChange: (String) -> Unit,
    anniversaryDate: String,
    onOpenAnniversaryDatePicker: () -> Unit,
    education: String,
    onEducationChange: (String) -> Unit,
    workingStatus: String,
    onWorkingStatusChange: (String) -> Unit,
    otherProfession: String,
    onOtherProfessionChange: (String) -> Unit,
    workDescription: String,
    onWorkDescriptionChange: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Personal Details (व्यक्तिगत विवरण)",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold
            )
        )

        OutlinedTextField(
            value = fullName,
            onValueChange = onFullNameChange,
            label = { Text("Full Name *") },
            placeholder = { Text("Enter full name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = fatherName,
            onValueChange = onFatherNameChange,
            label = { Text("Father's Name *") },
            placeholder = { Text("Enter father's name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = motherName,
            onValueChange = onMotherNameChange,
            label = { Text("Mother's Name *") },
            placeholder = { Text("Enter mother's name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = dob,
                onValueChange = {},
                readOnly = true,
                label = { Text("Date of Birth *") },
                placeholder = { Text("dd/mmm/yyyy") },
                trailingIcon = {
                    IconButton(onClick = onOpenDatePicker) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date", tint = AppPrimaryGold)
                    }
                },
                modifier = Modifier
                    .weight(1.2f)
                    .clickable { onOpenDatePicker() }
            )

            OutlinedTextField(
                value = age,
                onValueChange = {},
                readOnly = true,
                label = { Text("Age *") },
                placeholder = { Text("Auto") },
                modifier = Modifier.weight(0.8f)
            )
        }

        // Blood Group Dropdown
        var bgExpanded by remember { mutableStateOf(false) }
        val bloodGroups = listOf("A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-")
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = bloodGroup,
                onValueChange = {},
                readOnly = true,
                label = { Text("Blood Group") },
                placeholder = { Text("Select Blood Group") },
                trailingIcon = {
                    IconButton(onClick = { bgExpanded = true }) {
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { bgExpanded = true }
            )
            DropdownMenu(
                expanded = bgExpanded,
                onDismissRequest = { bgExpanded = false }
            ) {
                bloodGroups.forEach { bg ->
                    DropdownMenuItem(
                        text = { Text(bg) },
                        onClick = {
                            onBloodGroupChange(bg)
                            bgExpanded = false
                        }
                    )
                }
            }
        }

        // Marital Status
        Text(
            text = "Marital Status *",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = maritalStatus == "Unmarried",
                    onClick = { onMaritalStatusChange("Unmarried") },
                    colors = RadioButtonDefaults.colors(selectedColor = AppPrimaryGold)
                )
                Text("Unmarried", modifier = Modifier.clickable { onMaritalStatusChange("Unmarried") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = maritalStatus == "Married",
                    onClick = { onMaritalStatusChange("Married") },
                    colors = RadioButtonDefaults.colors(selectedColor = AppPrimaryGold)
                )
                Text("Married", modifier = Modifier.clickable { onMaritalStatusChange("Married") })
            }
        }

        if (maritalStatus == "Married") {
            OutlinedTextField(
                value = anniversaryDate,
                onValueChange = {},
                readOnly = true,
                label = { Text("Date of Anniversary *") },
                placeholder = { Text("dd/mmm/yyyy") },
                trailingIcon = {
                    IconButton(onClick = onOpenAnniversaryDatePicker) {
                        Icon(Icons.Default.CalendarToday, contentDescription = "Pick Date", tint = AppPrimaryGold)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onOpenAnniversaryDatePicker() }
            )
        }

        OutlinedTextField(
            value = education,
            onValueChange = onEducationChange,
            label = { Text("Educational Qualification") },
            placeholder = { Text("e.g. B.Com, M.Tech, CA, High School") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Profession Dropdown
        var profExpanded by remember { mutableStateOf(false) }
        val professions = listOf("Business", "Job", "Student", "Others")
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = workingStatus,
                onValueChange = {},
                readOnly = true,
                label = { Text("Your Profession *") },
                placeholder = { Text("Select Profession") },
                trailingIcon = {
                    IconButton(onClick = { profExpanded = true }) {
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { profExpanded = true }
            )
            DropdownMenu(
                expanded = profExpanded,
                onDismissRequest = { profExpanded = false }
            ) {
                professions.forEach { p ->
                    DropdownMenuItem(
                        text = { Text(p) },
                        onClick = {
                            onWorkingStatusChange(p)
                            profExpanded = false
                        }
                    )
                }
            }
        }

        if (workingStatus == "Others") {
            OutlinedTextField(
                value = otherProfession,
                onValueChange = onOtherProfessionChange,
                label = { Text("Specify Other Profession *") },
                placeholder = { Text("Enter your profession name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        OutlinedTextField(
            value = workDescription,
            onValueChange = onWorkDescriptionChange,
            label = { Text("Work Description / Details") },
            placeholder = { Text("Provide details about business, job or field of study") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = onNext,
            colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
        ) {
            Text("Next: Contact Details ➔", fontWeight = FontWeight.Bold)
        }
    }
}

// ----------------------------------------------------
// Step 3: Contact Details
// ----------------------------------------------------
@Composable
fun ContactDetailsStep(
    whatsappNo: String,
    contactNo: String,
    onContactNoChange: (String) -> Unit,
    emailId: String,
    onEmailChange: (String) -> Unit,
    emergencyName: String,
    onEmergencyNameChange: (String) -> Unit,
    emergencyRelation: String,
    onEmergencyRelationChange: (String) -> Unit,
    emergencyContactNo: String,
    onEmergencyContactNoChange: (String) -> Unit,
    address: String,
    onAddressChange: (String) -> Unit,
    state: String,
    onStateChange: (String) -> Unit,
    city: String,
    onCityChange: (String) -> Unit,
    pincode: String,
    onPincodeChange: (String) -> Unit,
    onBack: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Contact Details (संपर्क विवरण)",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold
            )
        )

        OutlinedTextField(
            value = whatsappNo,
            onValueChange = {},
            readOnly = true,
            label = { Text("WhatsApp Number (Registered)") },
            leadingIcon = { Text("+91 ", fontWeight = FontWeight.Bold, color = AppPrimaryGold, modifier = Modifier.padding(start = 12.dp)) },
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = contactNo,
            onValueChange = { onContactNoChange(it.filter { c -> c.isDigit() }.take(10)) },
            label = { Text("Contact No. (Optional)") },
            placeholder = { Text("Alternative 10-digit number") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        OutlinedTextField(
            value = emailId,
            onValueChange = onEmailChange,
            label = { Text("Email ID (Optional)") },
            placeholder = { Text("e.g. name@example.com") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // Emergency Contact Card
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = AppDeepSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "🚨 Emergency Contact (आपातकालीन संपर्क)",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFCC80)
                    )
                )

                OutlinedTextField(
                    value = emergencyName,
                    onValueChange = onEmergencyNameChange,
                    label = { Text("Emergency Contact Person Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = emergencyRelation,
                    onValueChange = onEmergencyRelationChange,
                    label = { Text("Relation (e.g. Father, Brother, Spouse) *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = emergencyContactNo,
                    onValueChange = { onEmergencyContactNoChange(it.filter { c -> c.isDigit() }.take(10)) },
                    label = { Text("Emergency Mobile Number *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        OutlinedTextField(
            value = address,
            onValueChange = onAddressChange,
            label = { Text("Residential Address *") },
            placeholder = { Text("Enter full address") },
            minLines = 2,
            modifier = Modifier.fillMaxWidth()
        )

        // State Dropdown
        var stateExpanded by remember { mutableStateOf(false) }
        Box(modifier = Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = state,
                onValueChange = {},
                readOnly = true,
                label = { Text("State *") },
                trailingIcon = {
                    IconButton(onClick = { stateExpanded = true }) {
                        Icon(Icons.Default.ArrowDropDown, contentDescription = "Dropdown")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { stateExpanded = true }
            )
            DropdownMenu(
                expanded = stateExpanded,
                onDismissRequest = { stateExpanded = false }
            ) {
                ALL_INDIAN_STATES.forEach { st ->
                    DropdownMenuItem(
                        text = { Text(st) },
                        onClick = {
                            onStateChange(st)
                            stateExpanded = false
                        }
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = city,
                onValueChange = onCityChange,
                label = { Text("City *") },
                placeholder = { Text("City name") },
                singleLine = true,
                modifier = Modifier.weight(1.2f)
            )

            OutlinedTextField(
                value = pincode,
                onValueChange = { onPincodeChange(it.filter { c -> c.isDigit() }.take(6)) },
                label = { Text("Pin Code *") },
                placeholder = { Text("6-digit PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                singleLine = true,
                modifier = Modifier.weight(0.8f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text("← Back")
            }

            Button(
                onClick = onNext,
                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.5f)
                    .height(48.dp)
            ) {
                Text("Next: Religious ➔", fontWeight = FontWeight.Bold)
            }
        }
    }
}

// ----------------------------------------------------
// Step 4: Religious Details
// ----------------------------------------------------
@Composable
fun ReligiousDetailsStep(
    subMandirDohe: Boolean,
    onSubMandirDoheChange: (Boolean) -> Unit,
    subMandirChaitya: Boolean,
    onSubMandirChaityaChange: (Boolean) -> Unit,
    sub2Vanditu: Boolean,
    onSub2VandituChange: (Boolean) -> Unit,
    sub2Jagchintamani: Boolean,
    onSub2JagchintamaniChange: (Boolean) -> Unit,
    sub2Bharser: Boolean,
    onSub2BharserChange: (Boolean) -> Unit,
    sub2LaghuShanti: Boolean,
    onSub2LaghuShantiChange: (Boolean) -> Unit,
    sub2SakalaTirth: Boolean,
    onSub2SakalaTirthChange: (Boolean) -> Unit,
    sub5Saklarhat: Boolean,
    onSub5SaklarhatChange: (Boolean) -> Unit,
    sub5Snatasya: Boolean,
    onSub5SnatasyaChange: (Boolean) -> Unit,
    sub5Atichar: Boolean,
    onSub5AticharChange: (Boolean) -> Unit,
    sub5AjitShanti: Boolean,
    onSub5AjitShantiChange: (Boolean) -> Unit,
    sub5BadiShanti: Boolean,
    onSub5BadiShantiChange: (Boolean) -> Unit,
    sub5Santikaram: Boolean,
    onSub5SantikaramChange: (Boolean) -> Unit,
    otherLearnings: List<String>,
    onOtherLearningsChange: (List<String>) -> Unit,
    specPratikraman: Boolean,
    onSpecPratikramanChange: (Boolean) -> Unit,
    specVaanchan: Boolean,
    onSpecVaanchanChange: (Boolean) -> Unit,
    specBhakti: Boolean,
    onSpecBhaktiChange: (Boolean) -> Unit,
    specOther: Boolean,
    onSpecOtherChange: (Boolean) -> Unit,
    specOtherText: String,
    onSpecOtherTextChange: (String) -> Unit,
    joiningYear: String,
    onJoiningYearChange: (String) -> Unit,
    paryushanCount: String,
    onParyushanCountChange: (String) -> Unit,
    isParyushanCountLocked: Boolean,
    anotherGroup: String,
    onAnotherGroupChange: (String) -> Unit,
    postInGroup: String,
    onPostInGroupChange: (String) -> Unit,
    actNavkarshi: Boolean,
    onActNavkarshiChange: (Boolean) -> Unit,
    actPrabhuPujan: Boolean,
    onActPrabhuPujanChange: (Boolean) -> Unit,
    actRatriBhojanTyag: Boolean,
    onActRatriBhojanTyagChange: (Boolean) -> Unit,
    actTithiPalan: Boolean,
    onActTithiPalanChange: (Boolean) -> Unit,
    actNavkarPakkiMala: Boolean,
    onActNavkarPakkiMalaChange: (Boolean) -> Unit,
    actSamaiyk: Boolean,
    onActSamaiykChange: (Boolean) -> Unit,
    actPratikaman: Boolean,
    onActPratikamanChange: (Boolean) -> Unit,
    otherDailyActivities: List<String>,
    onOtherDailyActivitiesChange: (List<String>) -> Unit,
    lifetimeTapasyaList: List<String>,
    onLifetimeTapasyaListChange: (List<String>) -> Unit,
    isSubmitting: Boolean,
    onBack: () -> Unit,
    onSubmit: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(
            text = "Religious Details (धार्मिक विवरण)",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold
            )
        )

        // 1. Religious Learning Accordion
        Text("Religious Learning (धार्मिक ज्ञान / वांचन)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary))

        LearningCategoryItem(
            title = "Mandir Vidhi",
            items = listOf(
                "Asht Prakari Puja ke Dohe" to subMandirDohe,
                "Chaityawandan Vidhi" to subMandirChaitya
            ),
            onToggleItem = { idx, checked ->
                if (idx == 0) onSubMandirDoheChange(checked) else onSubMandirChaityaChange(checked)
            }
        )

        LearningCategoryItem(
            title = "2 Pratikaman",
            items = listOf(
                "Vanditu" to sub2Vanditu,
                "Jagchintamani Chaityawandan" to sub2Jagchintamani,
                "Bharser Sajjhay" to sub2Bharser,
                "Laghu Shanti" to sub2LaghuShanti,
                "Sakala Tirth" to sub2SakalaTirth
            ),
            onToggleItem = { idx, checked ->
                when (idx) {
                    0 -> onSub2VandituChange(checked)
                    1 -> onSub2JagchintamaniChange(checked)
                    2 -> onSub2BharserChange(checked)
                    3 -> onSub2LaghuShantiChange(checked)
                    4 -> onSub2SakalaTirthChange(checked)
                }
            }
        )

        LearningCategoryItem(
            title = "5 Pratikaman",
            items = listOf(
                "Saklarhat Chaityawandan" to sub5Saklarhat,
                "Snatasya Thui" to sub5Snatasya,
                "Atichar" to sub5Atichar,
                "Ajit Shanti" to sub5AjitShanti,
                "Badi Shanti" to sub5BadiShanti,
                "Santikaram" to sub5Santikaram
            ),
            onToggleItem = { idx, checked ->
                when (idx) {
                    0 -> onSub5SaklarhatChange(checked)
                    1 -> onSub5SnatasyaChange(checked)
                    2 -> onSub5AticharChange(checked)
                    3 -> onSub5AjitShantiChange(checked)
                    4 -> onSub5BadiShantiChange(checked)
                    5 -> onSub5SantikaramChange(checked)
                }
            }
        )

        // Other Religious Learnings Dynamic Inputs
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = AppDeepSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Other Religious Learnings", fontWeight = FontWeight.Bold, color = AppTextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                otherLearnings.forEachIndexed { index, text ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { newVal ->
                                val list = otherLearnings.toMutableList()
                                list[index] = newVal
                                onOtherLearningsChange(list)
                            },
                            placeholder = { Text("Enter other learning") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (otherLearnings.size > 1) {
                                val list = otherLearnings.toMutableList()
                                list.removeAt(index)
                                onOtherLearningsChange(list)
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                TextButton(onClick = {
                    onOtherLearningsChange(otherLearnings + "")
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Add Another Learning")
                }
            }
        }

        // 2. Specialities
        Text("Speciality (विशेषता) *", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = specPratikraman,
                onClick = { onSpecPratikramanChange(!specPratikraman) },
                label = { Text("Pratikraman") }
            )
            FilterChip(
                selected = specVaanchan,
                onClick = { onSpecVaanchanChange(!specVaanchan) },
                label = { Text("Vaanchan") }
            )
            FilterChip(
                selected = specBhakti,
                onClick = { onSpecBhaktiChange(!specBhakti) },
                label = { Text("Bhakti") }
            )
            FilterChip(
                selected = specOther,
                onClick = { onSpecOtherChange(!specOther) },
                label = { Text("Other") }
            )
        }

        if (specOther) {
            OutlinedTextField(
                value = specOtherText,
                onValueChange = onSpecOtherTextChange,
                label = { Text("Specify Other Speciality *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 3. Joining Year
        OutlinedTextField(
            value = joiningYear,
            onValueChange = { onJoiningYearChange(it.filter { c -> c.isDigit() }.take(4)) },
            label = { Text("In which Year you Joined Vardhman Mandal? *") },
            placeholder = { Text("e.g. 2018") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        // 4. Paryushan Count
        OutlinedTextField(
            value = paryushanCount,
            onValueChange = { onParyushanCountChange(it.filter { c -> c.isDigit() }) },
            readOnly = isParyushanCountLocked,
            label = { Text("How many times went for Paryushan Aaradhna? *") },
            placeholder = { Text("e.g. 0, 1, 2, 5") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            supportingText = {
                if (isParyushanCountLocked) {
                    Text("🔒 To update this count please contact Admin", color = AppPrimaryGold)
                }
            },
            modifier = Modifier.fillMaxWidth()
        )

        // 5 & 6. Other Group Details
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = AppDeepSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("🏛️ Other Group / Sanstha Details", fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                OutlinedTextField(
                    value = anotherGroup,
                    onValueChange = onAnotherGroupChange,
                    label = { Text("Another Religious Group (if any)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = postInGroup,
                    onValueChange = onPostInGroupChange,
                    label = { Text("Any special post in group or sanstha") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }

        // 7. Daily Routine Activities
        Text("Daily routine religious activity", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary))
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val dailyItems = listOf(
                "Navkarshi" to actNavkarshi,
                "Prabhu Pujan" to actPrabhuPujan,
                "Ratri Bhojan Tyag" to actRatriBhojanTyag,
                "Tithi Palan" to actTithiPalan,
                "Navkar Pakki Mala" to actNavkarPakkiMala,
                "Samaiyk" to actSamaiyk,
                "Pratikaman" to actPratikaman
            )
            dailyItems.forEachIndexed { idx, pair ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            when (idx) {
                                0 -> onActNavkarshiChange(!actNavkarshi)
                                1 -> onActPrabhuPujanChange(!actPrabhuPujan)
                                2 -> onActRatriBhojanTyagChange(!actRatriBhojanTyag)
                                3 -> onActTithiPalanChange(!actTithiPalan)
                                4 -> onActNavkarPakkiMalaChange(!actNavkarPakkiMala)
                                5 -> onActSamaiykChange(!actSamaiyk)
                                6 -> onActPratikamanChange(!actPratikaman)
                            }
                        }
                ) {
                    Checkbox(
                        checked = pair.second,
                        onCheckedChange = { checked ->
                            when (idx) {
                                0 -> onActNavkarshiChange(checked)
                                1 -> onActPrabhuPujanChange(checked)
                                2 -> onActRatriBhojanTyagChange(checked)
                                3 -> onActTithiPalanChange(checked)
                                4 -> onActNavkarPakkiMalaChange(checked)
                                5 -> onActSamaiykChange(checked)
                                6 -> onActPratikamanChange(checked)
                            }
                        },
                        colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                    )
                    Text(pair.first, color = AppTextPrimary)
                }
            }
        }

        // 8. Lifetime Tapasya
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = AppDeepSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("Any religious tapasya or tyag for lifetime", fontWeight = FontWeight.Bold, color = AppTextPrimary)
                Spacer(modifier = Modifier.height(6.dp))
                lifetimeTapasyaList.forEachIndexed { index, text ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = text,
                            onValueChange = { newVal ->
                                val list = lifetimeTapasyaList.toMutableList()
                                list[index] = newVal
                                onLifetimeTapasyaListChange(list)
                            },
                            placeholder = { Text("e.g. Updhaan, Ayambil, etc.") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            if (lifetimeTapasyaList.size > 1) {
                                val list = lifetimeTapasyaList.toMutableList()
                                list.removeAt(index)
                                onLifetimeTapasyaListChange(list)
                            }
                        }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                TextButton(onClick = {
                    onLifetimeTapasyaListChange(lifetimeTapasyaList + "")
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Add")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ Add Another Tapasya / Tyag")
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
            ) {
                Text("← Back")
            }

            Button(
                onClick = onSubmit,
                enabled = !isSubmitting,
                colors = ButtonDefaults.buttonColors(containerColor = AppSecondaryGreen),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.8f)
                    .height(48.dp)
            ) {
                if (isSubmitting) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Saving...")
                } else {
                    Text("Submit Registration ✔", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun LearningCategoryItem(
    title: String,
    items: List<Pair<String, Boolean>>,
    onToggleItem: (Int, Boolean) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val completedCount = items.count { it.second }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AppDeepSurface,
        border = BorderStroke(1.dp, if (completedCount > 0) AppPrimaryGold.copy(alpha = 0.6f) else AppBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = AppPrimaryGold
                    )
                    Text(title, fontWeight = FontWeight.Bold, color = AppTextPrimary)
                }

                if (completedCount == items.size && items.isNotEmpty()) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = AppSecondaryGreen.copy(alpha = 0.2f),
                        border = BorderStroke(0.6.dp, AppSecondaryGreen)
                    ) {
                        Text("✔ Complete", color = Color(0xFF81C784), fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                    }
                } else if (completedCount > 0) {
                    Text("($completedCount/${items.size})", color = AppPrimaryGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
                    items.forEachIndexed { index, pair ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onToggleItem(index, !pair.second) }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = pair.second,
                                onCheckedChange = { onToggleItem(index, it) },
                                colors = CheckboxDefaults.colors(checkedColor = AppSecondaryGreen)
                            )
                            Text(pair.first, style = MaterialTheme.typography.bodySmall, color = AppTextPrimary)
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// Custom 3-Step Date Picker (Year -> Month -> Day)
// ----------------------------------------------------
@Composable
fun CustomJainDatePickerDialog(
    title: String,
    onDateSelected: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val months = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
    var stage by remember { mutableIntStateOf(1) } // 1: Year, 2: Month, 3: Day
    var selectedYear by remember { mutableIntStateOf(Calendar.getInstance().get(Calendar.YEAR) - 20) }
    var selectedMonth by remember { mutableIntStateOf(0) }

    val currentYear = Calendar.getInstance().get(Calendar.YEAR)
    val years = (1920..currentYear).toList().reversed()

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppPrimaryGold),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(title, fontWeight = FontWeight.Bold, color = AppPrimaryGold, fontSize = 16.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = AppTextMuted)
                    }
                }

                Text(
                    text = when (stage) {
                        1 -> "Step 1: Select Year 📅"
                        2 -> "Year: $selectedYear ➔ Step 2: Select Month 📅"
                        else -> "$selectedYear ${months[selectedMonth]} ➔ Step 3: Select Day 📅"
                    },
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFFFD54F), fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                when (stage) {
                    1 -> {
                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(years.chunked(4)) { rowYears ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    rowYears.forEach { yr ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (yr == selectedYear) AppPrimaryGold else AppDeepSurface,
                                            border = BorderStroke(0.6.dp, AppBorder),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(vertical = 4.dp)
                                                .clickable {
                                                    selectedYear = yr
                                                    stage = 2
                                                }
                                        ) {
                                            Text(
                                                text = yr.toString(),
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (yr == selectedYear) Color.Black else AppTextPrimary
                                                ),
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 10.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    2 -> {
                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(months.chunked(3)) { rowMonths ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    rowMonths.forEach { m ->
                                        val mIdx = months.indexOf(m)
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (mIdx == selectedMonth) AppPrimaryGold else AppDeepSurface,
                                            border = BorderStroke(0.6.dp, AppBorder),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(vertical = 6.dp)
                                                .clickable {
                                                    selectedMonth = mIdx
                                                    stage = 3
                                                }
                                        ) {
                                            Text(
                                                text = m,
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = if (mIdx == selectedMonth) Color.Black else AppTextPrimary
                                                ),
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        val cal = Calendar.getInstance().apply {
                            set(Calendar.YEAR, selectedYear)
                            set(Calendar.MONTH, selectedMonth)
                            set(Calendar.DAY_OF_MONTH, 1)
                        }
                        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
                        val days = (1..maxDays).toList()

                        LazyColumn(modifier = Modifier.height(280.dp)) {
                            items(days.chunked(7)) { rowDays ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    rowDays.forEach { d ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = AppDeepSurface,
                                            border = BorderStroke(0.6.dp, AppBorder),
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(vertical = 4.dp)
                                                .clickable {
                                                    val formattedDay = String.format("%02d", d)
                                                    val formattedDate = "$formattedDay/${months[selectedMonth]}/$selectedYear"
                                                    onDateSelected(formattedDate)
                                                }
                                        ) {
                                            Text(
                                                text = d.toString(),
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = AppTextPrimary
                                                ),
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (stage > 1) {
                        TextButton(onClick = { stage-- }) {
                            Text("← Back Stage")
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                }
            }
        }
    }
}
