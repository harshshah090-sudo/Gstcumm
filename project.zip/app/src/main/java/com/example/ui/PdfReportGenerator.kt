package com.example.ui

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.Customer
import com.example.data.Bill
import com.example.data.Payment
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    private fun formatCurrencyPdf(amount: Double): String {
        return try {
            val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
            format.format(amount)
        } catch (e: Exception) {
            val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
            "₹" + formatter.format(amount)
        }
    }

    private fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return listOf("")
        val words = text.split("\\s+".toRegex())
        val lines = mutableListOf<String>()
        var currentLine = StringBuilder()
        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "${currentLine} $word"
            if (paint.measureText(testLine) <= maxWidth) {
                currentLine.append(if (currentLine.isEmpty()) word else " $word")
            } else {
                if (currentLine.isNotEmpty()) {
                    lines.add(currentLine.toString())
                }
                currentLine = StringBuilder(word)
            }
        }
        if (currentLine.isNotEmpty()) {
            lines.add(currentLine.toString())
        }
        return lines
    }

    fun generateAndSharePdf(
        context: Context,
        customer: Customer,
        timeline: List<LedgerItem>,
        outstandingBalance: Double
    ) {
        val pdfDocument = PdfDocument()
        
        // A4 standard sizes (595 x 842 points)
        val pageWidth = 595
        val pageHeight = 842
        
        // Setup paints
        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val boldPaint = Paint().apply {
            color = Color.BLACK
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val titlePaint = Paint().apply {
            color = Color.rgb(30, 58, 138) // deep indigo primary
            textSize = 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val headerPaint = Paint().apply {
            color = Color.WHITE
            textSize = 9f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val labelPaint = Paint().apply {
            color = Color.rgb(100, 116, 139) // Slate grey
            textSize = 8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val cardPaint = Paint().apply {
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val strokePaint = Paint().apply {
            color = Color.rgb(226, 232, 240) // soft boundary lines
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        // Timeline needs to be sorted chronologically (oldest first) to build cumulative balance accurately
        val chronologicalTimeline = timeline.sortedBy { it.date }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        // Draw Cover/Header banner
        // Background banner fill
        cardPaint.color = Color.rgb(30, 58, 138)
        canvas.drawRect(40f, 40f, 555f, 90f, cardPaint)

        // Title text in white
        headerPaint.textSize = 16f
        canvas.drawText("LEDGER ACCOUNT STATEMENT", 55f, 72f, headerPaint)
        headerPaint.textSize = 9f

        // Document Info
        val sdfDate = SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault())
        val generatedDateStr = sdfDate.format(Date())
        textPaint.color = Color.rgb(241, 245, 249)
        textPaint.textSize = 9f
        canvas.drawText("Generated: $generatedDateStr", 420f, 70f, textPaint)
        textPaint.color = Color.BLACK

        var currentY = 115f

        // Customer Details Box
        cardPaint.color = Color.rgb(248, 250, 252) // off white
        canvas.drawRoundRect(RectF(40f, currentY, 555f, currentY + 75f), 8f, 8f, cardPaint)
        canvas.drawRoundRect(RectF(40f, currentY, 555f, currentY + 75f), 8f, 8f, strokePaint)

        boldPaint.textSize = 12f
        boldPaint.color = Color.rgb(15, 23, 42)
        canvas.drawText(customer.name, 55f, currentY + 22f, boldPaint)
        boldPaint.textSize = 9f

        labelPaint.textSize = 9f
        canvas.drawText("Contact Information:", 55f, currentY + 40f, labelPaint)
        
        var contactStr = ""
        if (customer.phone.isNotEmpty()) contactStr += "Phone: ${customer.phone}"
        if (customer.email.isNotEmpty()) {
            if (contactStr.isNotEmpty()) contactStr += "  |  "
            contactStr += "Email: ${customer.email}"
        }
        if (contactStr.isEmpty()) contactStr = "No additional contact details provided."
        
        textPaint.textSize = 9f
        textPaint.color = Color.rgb(51, 65, 85)
        canvas.drawText(contactStr, 55f, currentY + 55f, textPaint)

        currentY += 95f

        // Financial KPI cards (3 side-by-side blocks)
        val cardWidth = 150f
        val gap = 12f
        
        val totalBilled = chronologicalTimeline.filterIsInstance<LedgerItem.BillEntry>().sumOf {
            val b = it.bill
            if (b.commissionRate == 0.0) {
                b.totalAmount
            } else if (b.amountGivenToCustomer == 0.0 && b.amountPaidToCompany == 0.0) {
                (b.baseAmount + b.gstAmount) + b.commissionAmount
            } else {
                b.amountGivenToCustomer + b.commissionAmount
            }
        } + chronologicalTimeline.filterIsInstance<LedgerItem.PaymentEntry>().filter { it.payment.isGivenToCustomer }.sumOf { it.payment.amount }
        val totalPaid = chronologicalTimeline.filterIsInstance<LedgerItem.PaymentEntry>().filter { !it.payment.isGivenToCustomer }.sumOf { it.payment.amount } +
                        chronologicalTimeline.filterIsInstance<LedgerItem.BillEntry>().sumOf {
                            val b = it.bill
                            if (b.commissionRate == 0.0) {
                                if (b.customerPaid) b.totalAmount else 0.0
                            } else if (b.amountGivenToCustomer == 0.0 && b.amountPaidToCompany == 0.0) {
                                b.baseAmount + b.gstAmount
                            } else {
                                b.amountPaidToCompany
                            }
                        }

        // Billed Summary Card
        cardPaint.color = Color.rgb(239, 246, 255) // light blue
        canvas.drawRoundRect(RectF(40f, currentY, 40f + cardWidth, currentY + 45f), 6f, 6f, cardPaint)
        canvas.drawRoundRect(RectF(40f, currentY, 40f + cardWidth, currentY + 45f), 6f, 6f, strokePaint)
        labelPaint.color = Color.rgb(37, 99, 235)
        canvas.drawText("TOTAL BILLED", 48f, currentY + 16f, labelPaint)
        boldPaint.color = Color.rgb(30, 58, 138)
        canvas.drawText(formatCurrencyPdf(totalBilled), 48f, currentY + 32f, boldPaint)

        // Paid Summary Card
        cardPaint.color = Color.rgb(240, 253, 244) // light green
        canvas.drawRoundRect(RectF(40f + cardWidth + gap, currentY, 40f + 2 * cardWidth + gap, currentY + 45f), 6f, 6f, cardPaint)
        canvas.drawRoundRect(RectF(40f + cardWidth + gap, currentY, 40f + 2 * cardWidth + gap, currentY + 45f), 6f, 6f, strokePaint)
        labelPaint.color = Color.rgb(22, 163, 74)
        canvas.drawText("TOTAL DEPOSITED", 40f + cardWidth + gap + 8f, currentY + 16f, labelPaint)
        boldPaint.color = Color.rgb(21, 128, 61)
        canvas.drawText(formatCurrencyPdf(totalPaid), 40f + cardWidth + gap + 8f, currentY + 32f, boldPaint)

        // Outstanding Card
        val balanceColorBg = if (outstandingBalance > 0) Color.rgb(254, 242, 242) else Color.rgb(240, 253, 244)
        val balanceColorStroke = if (outstandingBalance > 0) Color.rgb(254, 226, 226) else Color.rgb(220, 252, 231)
        val balanceColorTxt = if (outstandingBalance > 0) Color.rgb(220, 38, 38) else Color.rgb(22, 163, 74)
        
        cardPaint.color = balanceColorBg
        strokePaint.color = balanceColorStroke
        canvas.drawRoundRect(RectF(40f + 2 * cardWidth + 2 * gap, currentY, 555f, currentY + 45f), 6f, 6f, cardPaint)
        canvas.drawRoundRect(RectF(40f + 2 * cardWidth + 2 * gap, currentY, 555f, currentY + 45f), 6f, 6f, strokePaint)
        
        labelPaint.color = balanceColorTxt
        canvas.drawText("OUTSTANDING BALANCE", 40f + 2 * cardWidth + 2 * gap + 8f, currentY + 16f, labelPaint)
        boldPaint.color = balanceColorTxt
        canvas.drawText(formatCurrencyPdf(outstandingBalance), 40f + 2 * cardWidth + 2 * gap + 8f, currentY + 32f, boldPaint)

        strokePaint.color = Color.rgb(226, 232, 240) // Restore default stroke color
        labelPaint.color = Color.rgb(100, 116, 139) // Restore default label color
        boldPaint.color = Color.BLACK
        
        currentY += 70f

        // Table Header
        cardPaint.color = Color.rgb(71, 85, 105) // Slate 600
        canvas.drawRect(40f, currentY, 555f, currentY + 22f, cardPaint)

        // Date Column
        canvas.drawText("Date", 45f, currentY + 14f, headerPaint)
        // Description Column
        canvas.drawText("Particulars / Name", 115f, currentY + 14f, headerPaint)
        // GST & Comm Column
        canvas.drawText("GST & Comm %", 275f, currentY + 14f, headerPaint)
        
        // Right-aligned column headers
        headerPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Billed (+)", 430f, currentY + 14f, headerPaint)
        canvas.drawText("Paid (-)", 495f, currentY + 14f, headerPaint)
        canvas.drawText("Balance", 550f, currentY + 14f, headerPaint)
        headerPaint.textAlign = Paint.Align.LEFT

        currentY += 22f

        var runningBalance = 0.0

        for ((index, item) in chronologicalTimeline.withIndex()) {
            val formattedItemDate = sdfDate.format(Date(item.date))
            
            // Check if page boundaries reached (leave safety margin of 60pt at bottom)
            if (currentY > pageHeight - 65f) {
                // Finish current page and create a new page
                pdfDocument.finishPage(page)
                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas
                
                // Draw running page indicator top-right
                textPaint.textSize = 8f
                textPaint.color = Color.rgb(148, 163, 184)
                canvas.drawText("Page $pageNumber", 510f, 35f, textPaint)
                textPaint.color = Color.BLACK
                textPaint.textSize = 9f

                // Draw table header again for continuity
                currentY = 45f
                cardPaint.color = Color.rgb(71, 85, 105)
                canvas.drawRect(40f, currentY, 555f, currentY + 22f, cardPaint)

                canvas.drawText("Date", 45f, currentY + 14f, headerPaint)
                canvas.drawText("Particulars / Name", 115f, currentY + 14f, headerPaint)
                canvas.drawText("GST & Comm %", 275f, currentY + 14f, headerPaint)
                headerPaint.textAlign = Paint.Align.RIGHT
                canvas.drawText("Billed (+)", 430f, currentY + 14f, headerPaint)
                canvas.drawText("Paid (-)", 495f, currentY + 14f, headerPaint)
                canvas.drawText("Balance", 550f, currentY + 14f, headerPaint)
                headerPaint.textAlign = Paint.Align.LEFT

                currentY += 22f
            }

            // Alternating Row backgrounds
            if (index % 2 == 1) {
                cardPaint.color = Color.rgb(250, 250, 250)
                canvas.drawRect(40f, currentY, 555f, currentY + 30f, cardPaint)
            }
            
            // Draw baseline divider
            canvas.drawLine(40f, currentY + 30f, 555f, currentY + 30f, strokePaint)

            // Date
            textPaint.color = Color.rgb(100, 116, 139)
            canvas.drawText(formattedItemDate, 45f, currentY + 18f, textPaint)
            textPaint.color = Color.BLACK

            when (item) {
                is LedgerItem.BillEntry -> {
                    val bill = item.bill
                    val debit = if (bill.commissionRate == 0.0) {
                        bill.totalAmount
                    } else if (bill.amountGivenToCustomer == 0.0 && bill.amountPaidToCompany == 0.0) {
                        (bill.baseAmount + bill.gstAmount) + bill.commissionAmount
                    } else {
                        bill.amountGivenToCustomer + bill.commissionAmount
                    }
                    val credit = if (bill.commissionRate == 0.0) {
                        if (bill.customerPaid) bill.totalAmount else 0.0
                    } else if (bill.amountGivenToCustomer == 0.0 && bill.amountPaidToCompany == 0.0) {
                        bill.baseAmount + bill.gstAmount
                    } else {
                        bill.amountPaidToCompany
                    }
                    runningBalance += (debit - credit)

                    // Wrapping particulars name in case it's long
                    val wrappedNames = wrapText(bill.billName, boldPaint, 150f)
                    var textY = currentY + 13f
                    for (line in wrappedNames.take(2)) { // max 2 lines to fit row beautifully
                        boldPaint.color = Color.rgb(30, 41, 59)
                        canvas.drawText(line, 115f, textY, boldPaint)
                        textY += 10f
                    }
                    boldPaint.color = Color.BLACK

                    // GST / Commission breakdown
                    val gstCommStr = "GST: ${bill.gstPercentage}% | Comm: ${bill.commissionRate}%"
                    textPaint.color = Color.rgb(71, 85, 105)
                    canvas.drawText(gstCommStr, 275f, currentY + 18f, textPaint)
                    textPaint.color = Color.BLACK

                    // Billed / Paid / Running Balance alignment
                    textPaint.textAlign = Paint.Align.RIGHT
                    textPaint.color = Color.rgb(15, 23, 42)
                    canvas.drawText(formatCurrencyPdf(debit), 430f, currentY + 18f, textPaint)
                    if (credit > 0.0) {
                        canvas.drawText(formatCurrencyPdf(credit), 495f, currentY + 18f, textPaint)
                    } else {
                        canvas.drawText("-", 495f, currentY + 18f, textPaint)
                    }
                    
                    boldPaint.textAlign = Paint.Align.RIGHT
                    boldPaint.color = Color.rgb(15, 23, 42)
                    canvas.drawText(formatCurrencyPdf(runningBalance), 550f, currentY + 18f, boldPaint)
                    
                    textPaint.textAlign = Paint.Align.LEFT
                    boldPaint.textAlign = Paint.Align.LEFT
                    boldPaint.color = Color.BLACK
                }
                is LedgerItem.PaymentEntry -> {
                    val payment = item.payment
                    if (payment.isGivenToCustomer) {
                        runningBalance += payment.amount

                        // Label payment given
                        boldPaint.color = Color.rgb(185, 28, 28) // red text
                        canvas.drawText("Amount Given", 115f, currentY + 12f, boldPaint)
                        boldPaint.color = Color.BLACK

                        // Notes
                        val noteText = if (payment.note.isNotEmpty()) payment.note else "Ref Payout Entry"
                        val wrappedNotes = wrapText(noteText, textPaint, 150f)
                        var textY = currentY + 22f
                        textPaint.color = Color.rgb(100, 116, 139)
                        for (line in wrappedNotes.take(1)) {
                            canvas.drawText(line, 115f, textY, textPaint)
                        }
                        textPaint.color = Color.BLACK

                        canvas.drawText("-", 275f, currentY + 18f, textPaint)

                        textPaint.textAlign = Paint.Align.RIGHT
                        textPaint.color = Color.rgb(185, 28, 28)
                        canvas.drawText(formatCurrencyPdf(payment.amount), 430f, currentY + 18f, textPaint)

                        textPaint.color = Color.rgb(100, 116, 139)
                        canvas.drawText("-", 495f, currentY + 18f, textPaint)
                    } else {
                        runningBalance -= payment.amount

                        // Label payment received
                        boldPaint.color = Color.rgb(22, 101, 52) // Forest green text
                        canvas.drawText("Deposit Received", 115f, currentY + 12f, boldPaint)
                        boldPaint.color = Color.BLACK

                        // Notes
                        val noteText = if (payment.note.isNotEmpty()) payment.note else "Ref Deposit Entry"
                        val wrappedNotes = wrapText(noteText, textPaint, 150f)
                        var textY = currentY + 22f
                        textPaint.color = Color.rgb(100, 116, 139)
                        for (line in wrappedNotes.take(1)) {
                            canvas.drawText(line, 115f, textY, textPaint)
                        }
                        textPaint.color = Color.BLACK

                        canvas.drawText("-", 275f, currentY + 18f, textPaint)

                        textPaint.textAlign = Paint.Align.RIGHT
                        textPaint.color = Color.rgb(100, 116, 139)
                        canvas.drawText("-", 430f, currentY + 18f, textPaint)

                        textPaint.color = Color.rgb(21, 128, 61) // positive green representation for credit side
                        canvas.drawText(formatCurrencyPdf(payment.amount), 495f, currentY + 18f, textPaint)
                    }

                    boldPaint.textAlign = Paint.Align.RIGHT
                    boldPaint.color = Color.rgb(15, 23, 42)
                    canvas.drawText(formatCurrencyPdf(runningBalance), 550f, currentY + 18f, boldPaint)
                    
                    textPaint.textAlign = Paint.Align.LEFT
                    boldPaint.textAlign = Paint.Align.LEFT
                    boldPaint.color = Color.BLACK
                }
            }

            currentY += 30f
        }

        // Draw professional footer closing statement at bottom of the last page
        if (currentY > pageHeight - 50f) {
            // New page just for footer if completely stuffed
            pdfDocument.finishPage(page)
            pageNumber++
            pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
            page = pdfDocument.startPage(pageInfo)
            canvas = page.canvas
            currentY = 50f
        }

        // Horizontal footer divider line
        strokePaint.color = Color.rgb(203, 213, 225)
        canvas.drawLine(40f, pageHeight - 50f, 555f, pageHeight - 50f, strokePaint)

        // App Attribution Footer
        labelPaint.textSize = 8f
        labelPaint.color = Color.rgb(148, 163, 184)
        canvas.drawText("Statement generated via GST Bill Ledger on ${sdfDate.format(Date())}.", 45f, pageHeight - 38f, labelPaint)
        labelPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("Page $pageNumber", 550f, pageHeight - 38f, labelPaint)
        labelPaint.textAlign = Paint.Align.LEFT

        pdfDocument.finishPage(page)

        // Save file to internal cache to share easily
        val fileName = "Ledger_Statement_${customer.name.replace("\\s+".toRegex(), "_")}.pdf"
        val pdfFile = File(context.cacheDir, fileName)

        try {
            val fos = FileOutputStream(pdfFile)
            pdfDocument.writeTo(fos)
            fos.flush()
            fos.close()
            pdfDocument.close()

            // Generate content URI using FileProvider
            val fileUri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            // Build Share Intent
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, fileUri)
                putExtra(Intent.EXTRA_SUBJECT, "Ledger Account Statement: ${customer.name}")
                putExtra(Intent.EXTRA_TEXT, "Hello, please find attached the complete ledger account statement of all bills and deposits for ${customer.name}.\nOutstanding Balance: ${formatCurrencyPdf(outstandingBalance)}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            // Create selector
            val chooser = Intent.createChooser(shareIntent, "Send or Save PDF Report").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)

        } catch (e: Exception) {
            pdfDocument.close()
            e.printStackTrace()
            Toast.makeText(context, "Error creating PDF Report: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }
}
