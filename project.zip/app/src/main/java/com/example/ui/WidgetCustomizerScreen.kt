package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.widget.WidgetGlassBitmapHelper
import com.example.widget.WidgetPreferences
import com.example.widget.WidgetSunArcHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WidgetCustomizerScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val initialSettings = remember { WidgetPreferences.getSettings(context) }

    var widgetOpacity by remember { mutableIntStateOf(initialSettings.widgetOpacity) }
    var previewIsNightMode by remember { mutableStateOf(false) }

    val now = remember { Date() }
    val dayOfWeekHindi = "शुक्रवार"
    val dateMonthHindi = "19 सितम्बर 2026"

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "विजेट कस्टमाइज़ेशन",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "Liquid Glass 4×2 Widget Settings",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("widget_settings_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            widgetOpacity = WidgetPreferences.DEFAULT_OPACITY
                            WidgetPreferences.resetToDefaults(context)
                            Toast.makeText(context, "डिफ़ॉल्ट सेटिंग्स रीसेट की गई", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("widget_settings_reset_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset Defaults",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            widgetOpacity = WidgetPreferences.DEFAULT_OPACITY
                            WidgetPreferences.resetToDefaults(context)
                            Toast.makeText(context, "Settings Reset", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset")
                    }

                    Button(
                        onClick = {
                            WidgetPreferences.saveSettings(
                                context = context,
                                tithiFontSize = WidgetPreferences.DEFAULT_TITHI_FONT_SIZE,
                                timeFontSize = WidgetPreferences.DEFAULT_TIME_FONT_SIZE,
                                widgetOpacity = widgetOpacity,
                                showTimings = true
                            )
                            Toast.makeText(
                                context,
                                "Widget settings saved & applied!",
                                Toast.LENGTH_SHORT
                            ).show()
                            onNavigateBack()
                        },
                        modifier = Modifier
                            .weight(2f)
                            .testTag("save_widget_settings_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1B6B4A)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save & Apply / सेव करें", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. LIVE PREVIEW SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "LIVE WIDGET PREVIEW / लाइव प्रीव्यू",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        letterSpacing = 1.sp
                    )
                )

                // Day / Night Toggle for Preview
                FilterChip(
                    selected = previewIsNightMode,
                    onClick = { previewIsNightMode = !previewIsNightMode },
                    label = {
                        Text(if (previewIsNightMode) "🌙 Night Mode" else "☀️ Day Mode")
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = if (previewIsNightMode) Icons.Default.DarkMode else Icons.Default.WbSunny,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                )
            }

            // Simulated Wallpaper + Live Widget Replica Box (2:1 Ratio 4x2)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.radialGradient(
                            colors = if (previewIsNightMode) {
                                listOf(Color(0xFF1A2238), Color(0xFF0F1524), Color(0xFF070B14))
                            } else {
                                listOf(Color(0xFF2C3E50), Color(0xFF1A252F), Color(0xFF0E1318))
                            }
                        )
                    )
                    .padding(12.dp)
            ) {
                val glassBitmap = remember(widgetOpacity, previewIsNightMode) {
                    WidgetGlassBitmapHelper.createLiquidGlassBitmap(
                        width = 540,
                        height = 260,
                        opacityPercent = widgetOpacity,
                        cornerRadiusPx = 36f,
                        isDayMode = !previewIsNightMode
                    )
                }

                val arcBitmap = remember(previewIsNightMode) {
                    WidgetSunArcHelper.createSunArcBitmap(
                        width = 520,
                        height = 140,
                        progress = if (!previewIsNightMode) 0.37f else 0.42f,
                        isDayMode = !previewIsNightMode
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(2f)
                        .clip(RoundedCornerShape(18.dp))
                ) {
                    // Glass Background
                    Image(
                        bitmap = glassBitmap.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize()
                    )

                    // Foreground layout matching widget_tithi.xml
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Top Bar: Weekday/Date, Clock, Paksha/Tithi
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left: Weekday & Date
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = dayOfWeekHindi,
                                    color = if (previewIsNightMode) Color(0xFF94C6FF) else Color(0xFFF5CA65),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                                Text(
                                    text = dateMonthHindi,
                                    color = Color(0xD8FFFFFF),
                                    fontSize = 10.sp,
                                    maxLines = 1
                                )
                            }

                            // Center: Clock
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = "AM",
                                    color = if (previewIsNightMode) Color(0xFF80BFFF) else Color(0xFFDFB25E),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "10:47",
                                    color = Color.White,
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = 24.sp
                                )
                            }

                            // Right: Paksha & Tithi
                            Column(
                                modifier = Modifier.weight(1f),
                                horizontalAlignment = Alignment.End
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (previewIsNightMode) {
                                        Icon(
                                            painter = painterResource(id = R.drawable.ic_widget_moon),
                                            contentDescription = null,
                                            tint = Color.Unspecified,
                                            modifier = Modifier.size(13.dp).padding(end = 3.dp)
                                        )
                                    }
                                    Text(
                                        text = "भाद्रपद शुक्ल",
                                        color = if (previewIsNightMode) Color(0xFF94C6FF) else Color(0xFFF5CA65),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1
                                    )
                                }
                                Text(
                                    text = "तृतीया",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }
                        }

                        // Celestial Arc Container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                bitmap = arcBitmap.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxSize()
                            )

                            // Center Progress Tag
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.align(Alignment.BottomCenter)
                            ) {
                                Text(
                                    text = if (previewIsNightMode) "अगली सूर्योदय तक" else "दिन का प्रगति",
                                    color = Color(0xCCFFFFFF),
                                    fontSize = 9.5.sp
                                )
                                Text(
                                    text = if (previewIsNightMode) "7h 25m शेष" else "37%",
                                    color = if (previewIsNightMode) Color(0xFF94C6FF) else Color(0xFFF5CA65),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Left Sunrise Anchor
                            Row(
                                modifier = Modifier.align(Alignment.BottomStart),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_widget_sunrise),
                                    contentDescription = null,
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Column {
                                    Text(text = "06:12", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "सूर्योदय", color = Color(0xFFDFB25E), fontSize = 8.5.sp)
                                }
                            }

                            // Right Sunset Anchor
                            Row(
                                modifier = Modifier.align(Alignment.BottomEnd),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = "18:28", color = Color.White, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "सूर्यास्त", color = Color(0xFFDFB25E), fontSize = 8.5.sp)
                                }
                                Spacer(modifier = Modifier.width(3.dp))
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_widget_sunset),
                                    contentDescription = null,
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Bottom Jain Sacred Ratnatraya Aphorism
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 2.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_lotus_motif),
                                contentDescription = null,
                                tint = Color(0xFFDFB25E),
                                modifier = Modifier.size(10.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "सम्यक दर्शन  •  सम्यक ज्ञान  •  सम्यक चारित्र",
                                color = if (previewIsNightMode) Color(0xFF80BFFF) else Color(0xFFA0E0C0),
                                fontSize = 8.5.sp
                            )
                        }
                    }
                }
            }

            // TRANSPARENCY / OPACITY SLIDER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1B6B4A).copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Opacity,
                                        contentDescription = null,
                                        tint = Color(0xFF1B6B4A)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "Liquid Glass Opacity / पारदर्शिता",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = if (widgetOpacity < 45) "Ultra frosted clear glass"
                                    else if (widgetOpacity < 80) "Balanced Liquid Glass (Recommended)"
                                    else "High contrast tinted glass",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1B6B4A).copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, Color(0xFF1B6B4A).copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "$widgetOpacity%",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B6B4A),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    Slider(
                        value = widgetOpacity.toFloat(),
                        onValueChange = { widgetOpacity = it.toInt() },
                        valueRange = 20f..100f,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "20% (Ultra Clear)",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Text(
                            text = "75% (Recommended)",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Text(
                            text = "100% (Solid)",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                    }
                }
            }

            // INFO CARD ON AUTOMATIC ADAPTIVE FEATURES
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "✨ Automatic Widget Features",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "• 2:1 Horizontal ratio perfectly optimized for 4×2 home-screen widget.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• Day/Night Mode transitions automatically based on exact solar times.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• Sun Arc dynamically traces the progress of the day from Sunrise to Sunset.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "• Live digital clock updates automatically without draining battery.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
