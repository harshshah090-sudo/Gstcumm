package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.widget.WidgetPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WidgetCustomizerScreen(
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val initialSettings = remember { WidgetPreferences.getSettings(context) }

    var tithiFontSize by remember { mutableFloatStateOf(initialSettings.tithiFontSize) }
    var timeFontSize by remember { mutableFloatStateOf(initialSettings.timeFontSize) }
    var widgetOpacity by remember { mutableIntStateOf(initialSettings.widgetOpacity) }
    var showTimings by remember { mutableStateOf(initialSettings.showTimings) }

    val now = remember { Date() }
    val dayOfWeek = remember { SimpleDateFormat("EEEE", Locale.ENGLISH).format(now) }
    val dateMonth = remember { SimpleDateFormat("d MMMM", Locale.ENGLISH).format(now) }
    val yearStr = remember { SimpleDateFormat("yyyy", Locale.ENGLISH).format(now) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Widget Customization",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text(
                            text = "विजेट आकार व पारदर्शिता सेटिंग्स",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("widget_settings_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            tithiFontSize = WidgetPreferences.DEFAULT_TITHI_FONT_SIZE
                            timeFontSize = WidgetPreferences.DEFAULT_TIME_FONT_SIZE
                            widgetOpacity = WidgetPreferences.DEFAULT_OPACITY
                            showTimings = true
                            WidgetPreferences.resetToDefaults(context)
                            Toast.makeText(context, "Reset to defaults", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("widget_settings_reset_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = "Reset Defaults",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            tithiFontSize = WidgetPreferences.DEFAULT_TITHI_FONT_SIZE
                            timeFontSize = WidgetPreferences.DEFAULT_TIME_FONT_SIZE
                            widgetOpacity = WidgetPreferences.DEFAULT_OPACITY
                            showTimings = true
                            WidgetPreferences.resetToDefaults(context)
                            Toast.makeText(context, "Settings Reset", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RestartAlt,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset")
                    }

                    Button(
                        onClick = {
                            WidgetPreferences.saveSettings(
                                context = context,
                                tithiFontSize = tithiFontSize,
                                timeFontSize = timeFontSize,
                                widgetOpacity = widgetOpacity,
                                showTimings = showTimings
                            )
                            Toast.makeText(
                                context,
                                "Widget settings saved & applied!",
                                Toast.LENGTH_SHORT
                            ).show()
                            onNavigateBack()
                        },
                        modifier = Modifier
                            .weight(2f)
                            .testTag("save_widget_settings_btn"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1B6B4A)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save & Apply / सेव करें", fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // 1. LIVE PREVIEW SECTION
            Text(
                text = "LIVE WIDGET PREVIEW / लाइव प्रीव्यू",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )
            )

            // Simulated Wallpaper + Live Widget Replica Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF2C3E50),
                                Color(0xFF1A252F),
                                Color(0xFF0E1318)
                            )
                        )
                    )
                    .padding(16.dp)
            ) {
                // The Liquid Glass Widget Replica
                val alphaFloat = (widgetOpacity / 100f).coerceIn(0f, 1f)
                val baseBgColor = Color(0xFF101915).copy(alpha = alphaFloat * 0.92f)
                val rimBorderColor = Color(0xFF80DFB2).copy(alpha = 0.35f + 0.35f * alphaFloat)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(baseBgColor)
                        .border(
                            BorderStroke(1.2.dp, rimBorderColor),
                            RoundedCornerShape(18.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    // Top Sheen layer
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .clip(RoundedCornerShape(topStart = 17.dp, topEnd = 17.dp))
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color(0x30EAFFF3),
                                        Color(0x0880DFB2),
                                        Color.Transparent
                                    )
                                )
                            )
                    )

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Upper Row: 70:30 Split
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left Partition (Tithi, Samvat, Event)
                            Column(
                                modifier = Modifier.weight(0.69f),
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Text(
                                    text = "श्रावण सुदि Bij (२)",
                                    color = Color(0xFFEFFFF6),
                                    fontSize = tithiFontSize.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = "वि. सं. २०८३ (2083) • वीर सं. २५५२ (2552)",
                                    color = Color(0xFFDFB25E),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )

                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = Color(0x30282115),
                                    border = BorderStroke(0.8.dp, Color(0xB8DFB25E)),
                                    modifier = Modifier.padding(top = 2.dp)
                                ) {
                                    Text(
                                        text = "★ विशेष तिथि",
                                        color = Color(0xFFF5CA65),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }

                            // Vertical Divider
                            Box(
                                modifier = Modifier
                                    .padding(horizontal = 6.dp)
                                    .width(1.dp)
                                    .height(58.dp)
                                    .background(Color(0x3580DFB2))
                            )

                            // Right Partition (Clock & Date)
                            Column(
                                modifier = Modifier.weight(0.31f),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(1.dp)
                            ) {
                                Text(
                                    text = "AM",
                                    color = Color(0xFF8CE5AE),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "11:08",
                                    color = Color(0xFFA2EAB9),
                                    fontSize = timeFontSize.sp,
                                    fontWeight = FontWeight.Bold,
                                    lineHeight = timeFontSize.sp
                                )

                                Text(
                                    text = "───── ◆ ─────",
                                    color = Color(0x50DFB25E),
                                    fontSize = 5.sp
                                )

                                Text(
                                    text = dayOfWeek,
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = dateMonth,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = yearStr,
                                    color = Color(0xFF8CE5AE),
                                    fontSize = 9.5.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Auspicious Timings Bar
                        if (showTimings) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(1.dp)
                                    .background(Color(0x3580DFB2))
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(text = "🌅", fontSize = 11.sp)
                                    Text(
                                        text = "नवकारसी",
                                        color = Color(0xFF8CE5AE),
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = "|", color = Color(0x40FFFFFF), fontSize = 10.5.sp)
                                    Text(
                                        text = "06:52 AM",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "सूर्यास्त",
                                        color = Color(0xFFDFB25E),
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = "|", color = Color(0x40FFFFFF), fontSize = 10.5.sp)
                                    Text(
                                        text = "06:58 PM",
                                        color = Color.White,
                                        fontSize = 10.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(text = "🌇", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }

            // QUICK PRESETS
            Text(
                text = "Quick Presets / त्वरित प्रीसेट्स",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = (tithiFontSize == 30f && timeFontSize == 29f && widgetOpacity == 75),
                    onClick = {
                        tithiFontSize = 30f
                        timeFontSize = 29f
                        widgetOpacity = 75
                    },
                    label = { Text("Standard") },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = (tithiFontSize >= 36f && widgetOpacity == 80),
                    onClick = {
                        tithiFontSize = 38f
                        timeFontSize = 27f
                        widgetOpacity = 80
                    },
                    label = { Text("Large Tithi") },
                    modifier = Modifier.weight(1f)
                )

                FilterChip(
                    selected = (widgetOpacity <= 35),
                    onClick = {
                        tithiFontSize = 30f
                        timeFontSize = 29f
                        widgetOpacity = 30
                    },
                    label = { Text("Ultra Glass") },
                    modifier = Modifier.weight(1f)
                )
            }

            HorizontalDivider()

            // 2. TITHI FONT SIZE CONTROLLER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.FormatSize,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "Tithi Text Size / तिथि फ़ॉन्ट आकार",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Adjust headline scale for your screen",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                        ) {
                            Text(
                                text = "${tithiFontSize.toInt()} sp",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (tithiFontSize > WidgetPreferences.MIN_TITHI_FONT_SIZE) {
                                    tithiFontSize -= 1f
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }

                        Slider(
                            value = tithiFontSize,
                            onValueChange = { tithiFontSize = it },
                            valueRange = WidgetPreferences.MIN_TITHI_FONT_SIZE..WidgetPreferences.MAX_TITHI_FONT_SIZE,
                            steps = (WidgetPreferences.MAX_TITHI_FONT_SIZE - WidgetPreferences.MIN_TITHI_FONT_SIZE).toInt() - 1,
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                if (tithiFontSize < WidgetPreferences.MAX_TITHI_FONT_SIZE) {
                                    tithiFontSize += 1f
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }
            }

            // 3. TIME / CLOCK FONT SIZE CONTROLLER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFFDFB25E).copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Schedule,
                                        contentDescription = null,
                                        tint = Color(0xFFB5801E)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "Clock / Time Size (घड़ी फ़ॉन्ट)",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = "Digital clock font scaling",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFDFB25E).copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, Color(0xFFDFB25E).copy(alpha = 0.5f))
                        ) {
                            Text(
                                text = "${timeFontSize.toInt()} sp",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF8A5D07),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = {
                                if (timeFontSize > WidgetPreferences.MIN_TIME_FONT_SIZE) {
                                    timeFontSize -= 1f
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }

                        Slider(
                            value = timeFontSize,
                            onValueChange = { timeFontSize = it },
                            valueRange = WidgetPreferences.MIN_TIME_FONT_SIZE..WidgetPreferences.MAX_TIME_FONT_SIZE,
                            steps = (WidgetPreferences.MAX_TIME_FONT_SIZE - WidgetPreferences.MIN_TIME_FONT_SIZE).toInt() - 1,
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = {
                                if (timeFontSize < WidgetPreferences.MAX_TIME_FONT_SIZE) {
                                    timeFontSize += 1f
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, CircleShape)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }
            }

            // 4. TRANSPARENCY / OPACITY SLIDER
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color(0xFF1B6B4A).copy(alpha = 0.2f),
                                modifier = Modifier.size(36.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Opacity,
                                        contentDescription = null,
                                        tint = Color(0xFF1B6B4A)
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "Widget Transparency / पारदर्शिता",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = if (widgetOpacity < 40) "Clear glass (Wallpaper visible)"
                                    else if (widgetOpacity < 85) "Liquid frosted glass"
                                    else "Solid dark background",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF1B6B4A).copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, Color(0xFF1B6B4A).copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "$widgetOpacity%",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1B6B4A),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    }

                    Slider(
                        value = widgetOpacity.toFloat(),
                        onValueChange = { widgetOpacity = it.toInt() },
                        valueRange = 0f..100f,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "0% (Glass)",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Text(
                            text = "50%",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Text(
                            text = "100% (Solid)",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outline)
                        )
                    }
                }
            }

            // 5. TIMINGS BAR TOGGLE
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.WbSunny,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }
                        }

                        Column {
                            Text(
                                text = "Show Sunrise & Sunset Timings",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = "नवकारसी व सूर्यास्त समय पट्टी",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Switch(
                        checked = showTimings,
                        onCheckedChange = { showTimings = it }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
