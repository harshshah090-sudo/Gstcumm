package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutUsScreen(
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "हमारे बारे में",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "About Us • श्री वर्द्धमान स्वाध्याय संघ",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppSurface
                ),
                modifier = Modifier.testTag("about_us_top_bar")
            )
        },
        containerColor = AppBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 110.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero About Sangh Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(AppPrimaryGold, AppTertiaryMaroon)),
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.2f),
                                    AppDeepSurface
                                )
                            )
                        )
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "श्री वर्द्धमान स्वाध्याय संघ लोगो",
                            modifier = Modifier.size(80.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AppPrimaryGold.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "✨ विस्तृत परिचय शीघ्र आ रहा है • COMING SOON ✨",
                                color = AppPrimaryGold,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "श्री वर्द्धमान स्वाध्याय संघ",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "समस्त भारतवर्ष में पर्यूषणा महापर्व एवं निरंतर स्वाध्याय आराधना हेतु समर्पित संस्था।",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = AppTextMuted,
                                lineHeight = 20.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Sangh Objectives & Pillars
            Text(
                text = "संस्था के मुख्य स्तम्भ (Key Objectives)",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            AboutFeatureItem(
                icon = Icons.Filled.VolunteerActivism,
                title = "पर्यूषण स्वाध्यायी सेवा",
                description = "प्रत्येक श्रीसंघ तक निस्वार्थ भाव से स्वाध्यायी भाइयों को भेजकर महापर्व की विधिपूर्वक आराधना कराना।"
            )

            Spacer(modifier = Modifier.height(10.dp))

            AboutFeatureItem(
                icon = Icons.Filled.Groups,
                title = "स्वाध्यायी मंडल समन्वय",
                description = "अनुभवी एवं नवयुवक स्वाध्यायियों का विशाल नेटवर्क एवं निरंतर प्रशिक्षण कार्यक्रम।"
            )

            Spacer(modifier = Modifier.height(10.dp))

            AboutFeatureItem(
                icon = Icons.Filled.Language,
                title = "डिजिटल जैन पंचांग एवं साहित्य",
                description = "जैन तिथियों, पर्यों, कल्याणकों एवं प्रवचन सामग्री का डिजिटल माध्यम से सुलभ प्रसार।"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Jain Navkar / Quote Card
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = AppSurfaceNested,
                border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "।। परस्परोग्रहो जीवानाम् ।।\n।। ॐ अर्हम् ।।",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 22.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun AboutFeatureItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AppPrimaryGold.copy(alpha = 0.2f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        lineHeight = 16.sp
                    )
                )
            }
        }
    }
}
