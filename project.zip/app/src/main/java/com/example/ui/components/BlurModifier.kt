package com.example.ui.components

import android.graphics.BlendMode
import android.graphics.LinearGradient
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Applies a hardware-accelerated frosted blur effect to the bottom region of the Composable
 * corresponding to the height of the navigation panel.
 *
 * Content scrolling into this bottom region will be dynamically Gaussian blurred in real time,
 * creating an authentic frosted glass backdrop effect underneath translucent bars.
 */
fun Modifier.blurAtBottom(
    navBarHeightPx: Float,
    blurRadius: Float = 36f,
    transitionLengthPx: Float = 28f
): Modifier {
    if (navBarHeightPx <= 0f) return this

    return this.graphicsLayer {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val contentHeight = size.height
            if (contentHeight > navBarHeightPx) {
                try {
                    val blurEffect = RenderEffect.createBlurEffect(
                        blurRadius,
                        blurRadius,
                        Shader.TileMode.CLAMP
                    )
                    val maskYStart = (contentHeight - navBarHeightPx).coerceAtLeast(0f)
                    val maskYEnd = (maskYStart + transitionLengthPx).coerceAtMost(contentHeight)

                    // 1. Bottom Mask: 0% alpha at top, 100% alpha in bottom navigation zone
                    val bottomMaskShader = LinearGradient(
                        0f, maskYStart,
                        0f, maskYEnd,
                        intArrayOf(0x00000000, 0xFFFFFFFF.toInt()),
                        floatArrayOf(0f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    val bottomMaskEffect = RenderEffect.createShaderEffect(bottomMaskShader)
                    val blurredBottom = RenderEffect.createBlendModeEffect(
                        bottomMaskEffect,
                        blurEffect,
                        BlendMode.SRC_IN
                    )

                    // 2. Top Mask: 100% alpha in upper visible area, 0% alpha in bottom navigation zone
                    val topMaskShader = LinearGradient(
                        0f, maskYStart,
                        0f, maskYEnd,
                        intArrayOf(0xFFFFFFFF.toInt(), 0x00000000),
                        floatArrayOf(0f, 1f),
                        Shader.TileMode.CLAMP
                    )
                    val topMaskEffect = RenderEffect.createShaderEffect(topMaskShader)
                    val sharpTop = RenderEffect.createBlendModeEffect(
                        topMaskEffect,
                        RenderEffect.createOffsetEffect(0f, 0f),
                        BlendMode.SRC_IN
                    )

                    // 3. Composite: Combine crisp upper viewport with live-blurred bottom navigation backdrop
                    renderEffect = RenderEffect.createBlendModeEffect(
                        sharpTop,
                        blurredBottom,
                        BlendMode.SRC_OVER
                    ).asComposeRenderEffect()
                } catch (_: Throwable) {
                    // Fallback safely if device GPU does not support shader blend modes
                }
            }
        }
    }
}
