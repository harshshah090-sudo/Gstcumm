package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PageSize
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.TimelinePostEntity
import com.example.ui.theme.*
import com.example.utils.TimelinePhotoDisplay
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val postDateFormatter = SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH)

@Composable
fun TimelinePostCard(
    post: TimelinePostEntity,
    isAdmin: Boolean = false,
    onOpenGallery: (List<String>, Int, Map<Int, Rect>?) -> Unit,
    onDeletePost: (Long) -> Unit,
    onEditPost: ((TimelinePostEntity) -> Unit)? = null,
    onGyanPostClick: ((Long, Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val photos = remember(post.photoUris) {
        com.example.utils.TimelineImageUtils.parsePhotoUris(post.photoUris)
    }

    var isMenuExpanded by remember { mutableStateOf(false) }
    val formattedDate = remember(post.dateEpochMillis) {
        postDateFormatter.format(Date(post.dateEpochMillis))
    }

    val isGyanCard = post.isGyanShalaUpdate

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 5.dp)
            .then(
                if (isGyanCard && onGyanPostClick != null) {
                    Modifier.clickable {
                        onGyanPostClick(post.gyanCategoryId, post.gyanTopicId)
                    }
                } else Modifier
            )
            .testTag("timeline_post_card_${post.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isGyanCard) {
                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            } else {
                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            }
        ),
        border = BorderStroke(
            width = if (isGyanCard) 1.5.dp else 1.dp,
            color = if (isGyanCard) {
                AppPrimaryGold.copy(alpha = 0.65f)
            } else {
                MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
            }
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isGyanCard) 3.dp else 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(
                                if (isGyanCard) {
                                    Brush.linearGradient(
                                        listOf(AppPrimaryGold, Color(0xFFE65100))
                                    )
                                } else {
                                    Brush.linearGradient(
                                        listOf(AppPrimaryGold, AppTertiaryMaroon)
                                    )
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isGyanCard) Icons.Default.MenuBook else Icons.Default.Campaign,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = post.heading.ifBlank { if (isGyanCard) "Gyan Shala Update" else "Announcement" },
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            if (isGyanCard) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AppPrimaryGold.copy(alpha = 0.2f),
                                    border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
                                ) {
                                    Text(
                                        text = if (post.isGyanEdit) "Updated" else "New Note",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AppPrimaryGold
                                        ),
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.CalendarToday,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(11.dp)
                            )
                            Text(
                                text = formattedDate,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppTextMuted,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                if (isAdmin) {
                    Box {
                        IconButton(
                            onClick = { isMenuExpanded = true },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "Options",
                                tint = AppTextMuted,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        DropdownMenu(
                            expanded = isMenuExpanded,
                            onDismissRequest = { isMenuExpanded = false }
                        ) {
                            if (onEditPost != null) {
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            "Edit Post",
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            Icons.Default.Edit,
                                            contentDescription = "Edit Post",
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    },
                                    onClick = {
                                        isMenuExpanded = false
                                        onEditPost(post)
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        "Delete Post",
                                        color = MaterialTheme.colorScheme.error
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                },
                                onClick = {
                                    isMenuExpanded = false
                                    onDeletePost(post.id)
                                }
                            )
                        }
                    }
                }
            }

            if (post.subHeading.isNotBlank()) {
                Text(
                    text = post.subHeading,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp
                    )
                )
            }

            if (post.description.isNotBlank()) {
                Text(
                    text = post.description,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.9f),
                        fontSize = 13.5.sp,
                        lineHeight = 19.sp
                    )
                )
            }

            if (isGyanCard) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Tap to open note in Gyan Shala",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 11.5.sp
                            )
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            if (photos.isNotEmpty()) {
                key(photos) {
                    TimelinePhotoCollage(
                        photos = photos,
                        onOpenGallery = { index, boundsMap -> onOpenGallery(photos, index, boundsMap) }
                    )
                }
            }
        }
    }
}

@Composable
fun TimelinePhotoCollage(
    photos: List<String>,
    onOpenGallery: (Int, Map<Int, Rect>) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalCount = photos.size
    val displayPhotos = photos.take(5)
    val tileBoundsMap = remember { mutableMapOf<Int, Rect>() }

    fun captureBounds(index: Int): Modifier = Modifier.onGloballyPositioned { coords ->
        tileBoundsMap[index] = coords.boundsInWindow()
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color.Black.copy(alpha = 0.1f))
    ) {
        when (displayPhotos.size) {
            1 -> {
                CollageImageTile(
                    uri = displayPhotos[0],
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .then(captureBounds(0))
                        .clickable { onOpenGallery(0, tileBoundsMap.toMap()) }
                )
            }
            2 -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    CollageImageTile(
                        uri = displayPhotos[0],
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .then(captureBounds(0))
                            .clickable { onOpenGallery(0, tileBoundsMap.toMap()) }
                    )
                    CollageImageTile(
                        uri = displayPhotos[1],
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .then(captureBounds(1))
                            .clickable { onOpenGallery(1, tileBoundsMap.toMap()) }
                    )
                }
            }
            3 -> {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(190.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    CollageImageTile(
                        uri = displayPhotos[0],
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxHeight()
                            .then(captureBounds(0))
                            .clickable { onOpenGallery(0, tileBoundsMap.toMap()) }
                    )
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CollageImageTile(
                            uri = displayPhotos[1],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .then(captureBounds(1))
                                .clickable { onOpenGallery(1, tileBoundsMap.toMap()) }
                        )
                        CollageImageTile(
                            uri = displayPhotos[2],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .then(captureBounds(2))
                                .clickable { onOpenGallery(2, tileBoundsMap.toMap()) }
                        )
                    }
                }
            }
            4 -> {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CollageImageTile(
                            uri = displayPhotos[0],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(0))
                                .clickable { onOpenGallery(0, tileBoundsMap.toMap()) }
                        )
                        CollageImageTile(
                            uri = displayPhotos[1],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(1))
                                .clickable { onOpenGallery(1, tileBoundsMap.toMap()) }
                        )
                    }
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CollageImageTile(
                            uri = displayPhotos[2],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(2))
                                .clickable { onOpenGallery(2, tileBoundsMap.toMap()) }
                        )
                        CollageImageTile(
                            uri = displayPhotos[3],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(3))
                                .clickable { onOpenGallery(3, tileBoundsMap.toMap()) }
                        )
                    }
                }
            }
            else -> {
                // 5 or more photos: show 2 top and 3 bottom with the 5th having +N badge
                val extraCount = totalCount - 5
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .weight(1.2f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CollageImageTile(
                            uri = displayPhotos[0],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(0))
                                .clickable { onOpenGallery(0, tileBoundsMap.toMap()) }
                        )
                        CollageImageTile(
                            uri = displayPhotos[1],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(1))
                                .clickable { onOpenGallery(1, tileBoundsMap.toMap()) }
                        )
                    }
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        CollageImageTile(
                            uri = displayPhotos[2],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(2))
                                .clickable { onOpenGallery(2, tileBoundsMap.toMap()) }
                        )
                        CollageImageTile(
                            uri = displayPhotos[3],
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(3))
                                .clickable { onOpenGallery(3, tileBoundsMap.toMap()) }
                        )
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .then(captureBounds(4))
                                .clickable { onOpenGallery(4, tileBoundsMap.toMap()) }
                        ) {
                            CollageImageTile(
                                uri = displayPhotos[4],
                                modifier = Modifier.fillMaxSize()
                            )
                            if (extraCount > 0) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.65f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "+$extraCount",
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 20.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CollageImageTile(
    uri: String,
    modifier: Modifier = Modifier
) {
    TimelinePhotoDisplay(
        photoSource = uri,
        contentDescription = "Post photo",
        contentScale = ContentScale.Crop,
        modifier = modifier
    )
}

data class SelectedPhotoItem(
    val id: String = UUID.randomUUID().toString(),
    val uri: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateTimelinePostDialog(
    initialPost: TimelinePostEntity? = null,
    onDismiss: () -> Unit,
    onSubmit: (heading: String, subHeading: String, description: String, dateMillis: Long, photos: List<String>) -> Unit
) {
    val isEditing = initialPost != null
    var heading by remember { mutableStateOf(initialPost?.heading ?: "") }
    var subHeading by remember { mutableStateOf(initialPost?.subHeading ?: "") }
    var description by remember { mutableStateOf(initialPost?.description ?: "") }
    var selectedDateMillis by remember { mutableStateOf(initialPost?.dateEpochMillis ?: System.currentTimeMillis()) }
    var showDatePicker by remember { mutableStateOf(false) }
    var selectedPhotos by remember {
        mutableStateOf(
            com.example.utils.TimelineImageUtils.parsePhotoUris(initialPost?.photoUris).map {
                SelectedPhotoItem(id = UUID.randomUUID().toString(), uri = it)
            }
        )
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            val newItems = uris.map { uri ->
                SelectedPhotoItem(id = UUID.randomUUID().toString(), uri = uri.toString())
            }
            selectedPhotos = selectedPhotos + newItems
        }
    }

    val displayDateStr = remember(selectedDateMillis) {
        postDateFormatter.format(Date(selectedDateMillis))
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .wrapContentHeight()
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditing) Icons.Default.EditNote else Icons.Default.PostAdd,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Text(
                            text = if (isEditing) "Edit Timeline Post" else "Create Timeline Post",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Heading Field
                OutlinedTextField(
                    value = heading,
                    onValueChange = { heading = it },
                    label = { Text("Heading *") },
                    placeholder = { Text("e.g. Mahaparv Paryushan Update") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Sub-heading Field
                OutlinedTextField(
                    value = subHeading,
                    onValueChange = { subHeading = it },
                    label = { Text("Sub-heading (Optional)") },
                    placeholder = { Text("e.g. Sangh Swadhyai Arrival Details") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Description Field
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    placeholder = { Text("Write post content...") },
                    minLines = 3,
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )

                // Date Picker row
                Surface(
                    onClick = { showDatePicker = true },
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "Date: $displayDateStr",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                        Text(
                            text = "Change",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }

                // Photos Section
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Attach Photos (${selectedPhotos.size})",
                            style = MaterialTheme.typography.labelLarge.copy(
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Icon(
                                Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Select Photos", fontSize = 12.sp)
                        }
                    }

                    if (selectedPhotos.isNotEmpty()) {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(
                                items = selectedPhotos,
                                key = { item -> item.id }
                            ) { item ->
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                ) {
                                    TimelinePhotoDisplay(
                                        photoSource = item.uri,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(20.dp)
                                            .align(Alignment.TopEnd)
                                            .background(Color.Black.copy(alpha = 0.6f), CircleShape)
                                            .clickable {
                                                selectedPhotos = selectedPhotos.filter { it.id != item.id }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Remove",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Action Buttons
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel")
                    }

                    Button(
                        onClick = {
                            if (heading.isNotBlank() || description.isNotBlank()) {
                                onSubmit(
                                    heading,
                                    subHeading,
                                    description,
                                    selectedDateMillis,
                                    selectedPhotos.map { it.uri }
                                )
                            }
                        },
                        enabled = heading.isNotBlank() || description.isNotBlank(),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (isEditing) "Save Changes" else "Post")
                    }
                }
            }
        }
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = selectedDateMillis
        )
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let {
                            selectedDateMillis = it
                        }
                        showDatePicker = false
                    }
                ) {
                    Text("OK")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) {
                    Text("Cancel")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }
}

@Composable
fun FullscreenPhotoGalleryDialog(
    photos: List<String>,
    initialIndex: Int,
    sourceBounds: Map<Int, Rect>? = null,
    onDismiss: () -> Unit
) {
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current
    val safeInitialIndex = initialIndex.coerceIn(0, (photos.size - 1).coerceAtLeast(0))
    
    val pagerState = rememberPagerState(
        initialPage = safeInitialIndex,
        pageCount = { photos.size }
    )
    val thumbnailPagerState = rememberPagerState(
        initialPage = safeInitialIndex,
        pageCount = { photos.size }
    )

    // Real-time synchronization while sliding either the main photo or the thumbnail carousel
    LaunchedEffect(pagerState) {
        snapshotFlow {
            pagerState.currentPage + pagerState.currentPageOffsetFraction
        }.collect { mainPosition ->
            if (pagerState.isScrollInProgress && !thumbnailPagerState.isScrollInProgress) {
                val targetPage = mainPosition.toInt().coerceIn(0, (photos.size - 1).coerceAtLeast(0))
                val targetFraction = (mainPosition - targetPage).coerceIn(-0.5f, 0.5f)
                thumbnailPagerState.scrollToPage(targetPage, targetFraction)
            }
        }
    }

    LaunchedEffect(thumbnailPagerState) {
        snapshotFlow {
            val rawPos = thumbnailPagerState.currentPage + thumbnailPagerState.currentPageOffsetFraction
            val closestIndex = kotlin.math.round(rawPos).toInt().coerceIn(0, (photos.size - 1).coerceAtLeast(0))
            closestIndex
        }.distinctUntilChanged()
        .collect { centerIndex ->
            if (thumbnailPagerState.isScrollInProgress && !pagerState.isScrollInProgress) {
                if (pagerState.currentPage != centerIndex) {
                    pagerState.scrollToPage(centerIndex)
                }
            }
        }
    }

    // Ensure settling snaps both properly when thumbnail slide completes
    LaunchedEffect(thumbnailPagerState) {
        snapshotFlow { thumbnailPagerState.isScrollInProgress }
            .distinctUntilChanged()
            .collect { isScrolling ->
                if (!isScrolling && pagerState.currentPage != thumbnailPagerState.currentPage) {
                    pagerState.scrollToPage(thumbnailPagerState.currentPage)
                }
            }
    }

    var currentZoomScale by remember { mutableFloatStateOf(1f) }
    var showOverlays by remember { mutableStateOf(true) }

    // Spring animation specs for opening (bouncy) and dismissing (smooth non-bouncy)
    val openBouncySpringSpec = remember {
        spring<Float>(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        )
    }
    val dismissSmoothSpec = remember {
        tween<Float>(durationMillis = 280, easing = FastOutSlowInEasing)
    }

    // Hero opening expand animation (bouncy)
    val enterAnim = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        enterAnim.animateTo(1f, animationSpec = openBouncySpringSpec)
    }

    // Interactive Drag-to-Dismiss / Curved Swipe Down
    val dragOffsetX = remember { Animatable(0f) }
    val dragOffsetY = remember { Animatable(0f) }
    var isDragging by remember { mutableStateOf(false) }
    var isDismissing by remember { mutableStateOf(false) }
    val dismissAnim = remember { Animatable(0f) }

    // Dismiss start capture
    var dismissStartOffsetX by remember { mutableFloatStateOf(0f) }
    var dismissStartOffsetY by remember { mutableFloatStateOf(0f) }
    var dismissStartScale by remember { mutableFloatStateOf(1f) }

    fun triggerDismiss() {
        if (isDismissing) return
        isDismissing = true
        dismissStartOffsetX = dragOffsetX.value
        dismissStartOffsetY = dragOffsetY.value
        val dragDistY = dragOffsetY.value.coerceAtLeast(0f)
        dismissStartScale = (1f - (dragDistY / 1200f)).coerceIn(0.35f, 1f)
        coroutineScope.launch {
            dismissAnim.animateTo(1f, animationSpec = dismissSmoothSpec)
            onDismiss()
        }
    }

    Dialog(
        onDismissRequest = {
            triggerDismiss()
        },
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false
        )
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .testTag("fullscreen_photo_gallery_dialog")
        ) {
            val screenWidthPx = constraints.maxWidth.toFloat()
            val screenHeightPx = constraints.maxHeight.toFloat()

            val originRect = sourceBounds?.get(safeInitialIndex) ?: Rect(
                left = screenWidthPx * 0.25f,
                top = screenHeightPx * 0.35f,
                right = screenWidthPx * 0.75f,
                bottom = screenHeightPx * 0.65f
            )

            val currentTargetRect = sourceBounds?.get(pagerState.currentPage) ?: originRect

            // Compute backdrop alpha, scale, position, and corner radius
            val backdropAlpha: Float
            val activeTranslationX: Float
            val activeTranslationY: Float
            val activeScale: Float
            val activeCornerRadiusDp: Float

            if (isDismissing) {
                val d = dismissAnim.value.coerceIn(0f, 1f)
                backdropAlpha = ((1f - (dismissStartOffsetY.coerceAtLeast(0f) / (screenHeightPx * 0.65f))).coerceIn(0f, 1f) * (1f - d)).coerceIn(0f, 1f)
                
                val targetCenterX = currentTargetRect.center.x
                val targetCenterY = currentTargetRect.center.y
                val screenCenterX = screenWidthPx / 2f
                val screenCenterY = screenHeightPx / 2f
                
                val targetOffsetX = targetCenterX - screenCenterX
                val targetOffsetY = targetCenterY - screenCenterY
                val targetScale = (currentTargetRect.width / screenWidthPx.coerceAtLeast(1f)).coerceIn(0.15f, 1f)

                activeTranslationX = dismissStartOffsetX + (targetOffsetX - dismissStartOffsetX) * d
                activeTranslationY = dismissStartOffsetY + (targetOffsetY - dismissStartOffsetY) * d
                activeScale = dismissStartScale + (targetScale - dismissStartScale) * d
                activeCornerRadiusDp = 12f * d
            } else if (enterAnim.value < 0.999f) {
                val e = enterAnim.value
                backdropAlpha = e.coerceIn(0f, 1f)

                val originCenterX = originRect.center.x
                val originCenterY = originRect.center.y
                val screenCenterX = screenWidthPx / 2f
                val screenCenterY = screenHeightPx / 2f

                val startOffsetX = originCenterX - screenCenterX
                val startOffsetY = originCenterY - screenCenterY
                val startScale = (originRect.width / screenWidthPx.coerceAtLeast(1f)).coerceIn(0.15f, 1f)

                activeTranslationX = startOffsetX * (1f - e)
                activeTranslationY = startOffsetY * (1f - e)
                activeScale = startScale + (1f - startScale) * e
                activeCornerRadiusDp = 12f * (1f - e).coerceIn(0f, 1f)
            } else {
                val dragY = dragOffsetY.value.coerceAtLeast(0f)
                val dragFraction = (dragY / screenHeightPx).coerceIn(0f, 1f)
                backdropAlpha = (1f - (dragFraction * 1.6f)).coerceIn(0f, 1f)
                activeTranslationX = dragOffsetX.value
                activeTranslationY = dragOffsetY.value
                activeScale = (1f - (dragFraction * 0.55f)).coerceIn(0.35f, 1f)
                activeCornerRadiusDp = (dragFraction * 28f).coerceIn(0f, 16f)
            }

            // Dark Backdrop with dynamic opacity
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        alpha = backdropAlpha
                    }
                    .background(Color.Black)
            )

            // Animated / Interactive Photo Container
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        translationX = activeTranslationX
                        translationY = activeTranslationY
                        scaleX = activeScale
                        scaleY = activeScale
                        clip = activeCornerRadiusDp > 0.5f
                        shape = RoundedCornerShape(activeCornerRadiusDp.dp)
                    }
            ) {
                // Horizontal Pager for multiple photos
                if (photos.isNotEmpty()) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize(),
                        userScrollEnabled = currentZoomScale <= 1.05f && !isDragging
                    ) { page ->
                        val photoUri = photos.getOrNull(page) ?: ""
                        val isCurrentPage = pagerState.currentPage == page

                        ZoomablePhotoView(
                            photoUri = photoUri,
                            isCurrentPage = isCurrentPage,
                            onScaleChanged = { scale ->
                                if (isCurrentPage) {
                                    currentZoomScale = scale
                                }
                            },
                            onTap = {
                                showOverlays = !showOverlays
                            },
                            onDragStart = {
                                isDragging = true
                            },
                            onDragDelta = { delta ->
                                coroutineScope.launch {
                                    dragOffsetX.snapTo(dragOffsetX.value + delta.x)
                                    dragOffsetY.snapTo(dragOffsetY.value + delta.y)
                                }
                            },
                            onDragEnd = {
                                val currentY = dragOffsetY.value
                                val dismissThreshold = with(density) { 130.dp.toPx() }
                                if (currentY > dismissThreshold) {
                                    triggerDismiss()
                                } else {
                                    // Snap back with bouncy spring physics
                                    coroutineScope.launch {
                                        launch {
                                            dragOffsetX.animateTo(0f, animationSpec = openBouncySpringSpec)
                                        }
                                        launch {
                                            dragOffsetY.animateTo(0f, animationSpec = openBouncySpringSpec)
                                        }
                                        isDragging = false
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // UI Overlays: Top Counter & Bottom Thumbnail Strip (Fade when dragging down or during dismissal)
            val overlaysAlpha = if (isDismissing || enterAnim.value < 0.9f) {
                0f
            } else {
                val dragY = dragOffsetY.value.coerceAtLeast(0f)
                (1f - (dragY / 150f)).coerceIn(0f, 1f)
            }

            if (overlaysAlpha > 0.01f) {
                // Top Overlay Bar (Animated visibility)
                AnimatedVisibility(
                    visible = showOverlays,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .graphicsLayer { alpha = overlaysAlpha }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Black.copy(alpha = 0.85f),
                                        Color.Black.copy(alpha = 0.5f),
                                        Color.Transparent
                                    )
                                )
                            )
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Close button
                        IconButton(
                            onClick = { triggerDismiss() },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        if (photos.size > 1) {
                            // Photo Counter / Index
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Black.copy(alpha = 0.6f),
                                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                            ) {
                                Text(
                                    text = "${pagerState.currentPage + 1} / ${photos.size}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.5.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.size(36.dp))
                        }

                        // Placeholder spacer for symmetry
                        Spacer(modifier = Modifier.size(36.dp))
                    }
                }

                // Bottom Center-Locked Synchronized Thumbnail Strip (Animated visibility)
                AnimatedVisibility(
                    visible = showOverlays && photos.size > 1,
                    enter = fadeIn(),
                    exit = fadeOut(),
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .graphicsLayer { alpha = overlaysAlpha }
                ) {
                    val thumbnailSize = 58.dp
                    val spacing = 12.dp

                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        Color.Transparent,
                                        Color.Black.copy(alpha = 0.5f),
                                        Color.Black.copy(alpha = 0.88f)
                                    )
                                )
                            )
                            .navigationBarsPadding()
                            .padding(bottom = 40.dp) // Moved 5mm upwards
                            .padding(top = 12.dp)
                            .testTag("gallery_thumbnail_carousel")
                    ) {
                        val horizontalPadding = maxOf(0.dp, (maxWidth - thumbnailSize) / 2)
                        HorizontalPager(
                            state = thumbnailPagerState,
                            pageSize = PageSize.Fixed(thumbnailSize),
                            pageSpacing = spacing,
                            contentPadding = PaddingValues(horizontal = horizontalPadding),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(thumbnailSize + 8.dp)
                        ) { page ->
                            val photoUri = photos.getOrNull(page) ?: ""
                            val currentScrubCenter = remember {
                                derivedStateOf {
                                    val raw = thumbnailPagerState.currentPage + thumbnailPagerState.currentPageOffsetFraction
                                    kotlin.math.round(raw).toInt().coerceIn(0, (photos.size - 1).coerceAtLeast(0))
                                }
                            }
                            val isSelected = page == currentScrubCenter.value

                            Box(
                                modifier = Modifier.fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(if (isSelected) thumbnailSize else thumbnailSize - 8.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .border(
                                            width = if (isSelected) 2.5.dp else 1.dp,
                                            color = if (isSelected) AppPrimaryGold else Color.White.copy(alpha = 0.35f),
                                            shape = RoundedCornerShape(10.dp)
                                        )
                                        .graphicsLayer {
                                            alpha = if (isSelected) 1.0f else 0.55f
                                        }
                                        .clickable {
                                            coroutineScope.launch {
                                                thumbnailPagerState.animateScrollToPage(page)
                                                pagerState.animateScrollToPage(page)
                                            }
                                        }
                                ) {
                                    TimelinePhotoDisplay(
                                        photoSource = photoUri,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ZoomablePhotoView(
    photoUri: String,
    isCurrentPage: Boolean,
    onScaleChanged: (Float) -> Unit,
    onTap: () -> Unit,
    onDragStart: () -> Unit = {},
    onDragDelta: (Offset) -> Unit = {},
    onDragEnd: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var scale by remember(photoUri) { mutableFloatStateOf(1f) }
    var offsetX by remember(photoUri) { mutableFloatStateOf(0f) }
    var offsetY by remember(photoUri) { mutableFloatStateOf(0f) }

    // Reset zoom when switching away from this page
    LaunchedEffect(isCurrentPage) {
        if (!isCurrentPage) {
            scale = 1f
            offsetX = 0f
            offsetY = 0f
            onScaleChanged(1f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .pointerInput(photoUri) {
                detectTapGestures(
                    onDoubleTap = { tapOffset ->
                        if (scale > 1.2f) {
                            scale = 1f
                            offsetX = 0f
                            offsetY = 0f
                        } else {
                            scale = 2.5f
                            val centerX = size.width / 2f
                            val centerY = size.height / 2f
                            val maxOffsetX = (size.width * 1.5f) / 2f
                            val maxOffsetY = (size.height * 1.5f) / 2f
                            offsetX = ((centerX - tapOffset.x) * 1.5f).coerceIn(-maxOffsetX, maxOffsetX)
                            offsetY = ((centerY - tapOffset.y) * 1.5f).coerceIn(-maxOffsetY, maxOffsetY)
                        }
                        onScaleChanged(scale)
                    },
                    onTap = {
                        onTap()
                    }
                )
            }
            .pointerInput(photoUri) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var isTransforming = false
                    var isVerticalDrag = false
                    var totalPan = Offset.Zero

                    do {
                        val event = awaitPointerEvent()
                        val downPointers = event.changes.filter { it.pressed }

                        if (downPointers.size >= 2) {
                            // Multi-touch pinch-to-zoom
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val newScale = (scale * zoom).coerceIn(1.0f, 5.0f)
                            scale = newScale
                            onScaleChanged(newScale)

                            if (newScale > 1f) {
                                val maxOffsetX = (size.width * (newScale - 1f)) / 2f
                                val maxOffsetY = (size.height * (newScale - 1f)) / 2f
                                offsetX = (offsetX + pan.x).coerceIn(-maxOffsetX, maxOffsetX)
                                offsetY = (offsetY + pan.y).coerceIn(-maxOffsetY, maxOffsetY)
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                            event.changes.forEach { it.consume() }
                            isTransforming = true
                        } else if (downPointers.size == 1 && !isTransforming) {
                            val change = downPointers[0]
                            val dragDelta = change.positionChange()

                            if (scale > 1.05f) {
                                // Pan around when photo is zoomed
                                val maxOffsetX = (size.width * (scale - 1f)) / 2f
                                val maxOffsetY = (size.height * (scale - 1f)) / 2f
                                offsetX = (offsetX + dragDelta.x).coerceIn(-maxOffsetX, maxOffsetX)
                                offsetY = (offsetY + dragDelta.y).coerceIn(-maxOffsetY, maxOffsetY)
                                change.consume()
                            } else {
                                // Scale is 1.0f (Normal scale)
                                totalPan += dragDelta

                                if (!isVerticalDrag) {
                                    val absX = kotlin.math.abs(totalPan.x)
                                    val absY = totalPan.y // Downwards only

                                    // Intercept only when motion is decisively downward pull
                                    if (absY > 24f && absY > absX * 1.8f) {
                                        isVerticalDrag = true
                                        onDragStart()
                                    }
                                }

                                if (isVerticalDrag) {
                                    change.consume()
                                    onDragDelta(dragDelta)
                                }
                                // If horizontal motion (left-to-right or right-to-left), we do NOT consume the event!
                                // HorizontalPager receives it to slide-animate smoothly between photos!
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    if (isVerticalDrag) {
                        onDragEnd()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                    translationY = offsetY
                },
            contentAlignment = Alignment.Center
        ) {
            TimelinePhotoDisplay(
                photoSource = photoUri,
                contentDescription = "Zoomable photo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}
