package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch

// Theme colors matching ProfileScreen
private val ProfileDarkBg = AppBackground
private val ProfileDarkSurface = AppSurface
private val ProfileDarkSurface2 = Color(0xFF212D27)
private val ProfileDarkBorder = Color(0xFF2A3830)
private val ProfileGold = Color(0xFFE3B24E)
private val ProfileGoldDeep = Color(0xFFC79730)
private val ProfileCream = Color(0xFFEDE7DA)
private val ProfileMuted = Color(0xFF8FA096)
private val ProfileMaroon = Color(0xFFB4425A)
private val ProfileGreen = Color(0xFF3FAE7E)
private val ProfileTeal = Color(0xFF2FB5C4)

@Composable
fun SwadhyaiDetailPopup(
    swadhyai: SwadhyaiFormEntity,
    isAdmin: Boolean,
    isTargetAdmin: Boolean,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    sourceBounds: Rect? = null
) {
    val context = LocalContext.current
    val density = LocalDensity.current

    // Parse details
    val fullName = swadhyai.fullName.ifBlank { "Swadhyai Details" }
    val fatherName = swadhyai.fatherName
    val motherName = swadhyai.motherName
    val dob = swadhyai.dob
    val age = if (swadhyai.age > 0) swadhyai.age.toString() else ""
    val bloodGroup = swadhyai.bloodGroup
    val maritalStatus = swadhyai.maritalStatus.ifBlank { "Married" }
    val anniversaryDate = swadhyai.anniversaryDate
    val education = swadhyai.education
    val profession = swadhyai.workingStatus
    val workDescription = swadhyai.workDescription

    val contactNo = swadhyai.contactNo
    val whatsappNo = swadhyai.whatsappNo
    val emailId = swadhyai.email
    val emergencyName = swadhyai.emergencyContactName
    val emergencyRelation = swadhyai.emergencyContactRelation
    val emergencyContactNo = swadhyai.emergencyContactNo
    val address = swadhyai.address
    val city = swadhyai.city
    val state = swadhyai.state
    val pincode = swadhyai.pincode
    val nativePlace = swadhyai.nativePlace

    // Religious Learnings parsing
    val learnings = swadhyai.religiousLearnings
    val subMandirDohe = learnings.contains("Asht Prakari Puja ke Dohe")
    val subMandirChaitya = learnings.contains("Chaityawandan Vidhi")
    val sub2Vanditu = learnings.contains("Vanditu")
    val sub2Jagchintamani = learnings.contains("Jagchintamani")
    val sub2Bharser = learnings.contains("Bharser")
    val sub2LaghuShanti = learnings.contains("Laghu Shanti")
    val sub2SakalaTirth = learnings.contains("Sakala Tirth")
    val sub5Saklarhat = learnings.contains("Saklarhat")
    val sub5Snatasya = learnings.contains("Snatasya")
    val sub5Atichar = learnings.contains("Atichar")
    val sub5AjitShanti = learnings.contains("Ajit Shanti")
    val sub5BadiShanti = learnings.contains("Badi Shanti")
    val sub5Santikaram = learnings.contains("Santikaram")

    val standardKeywords = listOf(
        "Asht Prakari", "Chaityawandan Vidhi", "Vanditu", "Jagchintamani", "Bharser",
        "Laghu Shanti", "Sakala Tirth", "Saklarhat", "Snatasya", "Atichar", "Ajit Shanti",
        "Badi Shanti", "Santikaram"
    )
    val otherLearningsList = learnings.lines()
        .map { it.trim() }
        .filter { line ->
            line.isNotBlank() && (
                line.startsWith("Other:") || line.startsWith("✔") || line.startsWith("-") || line.startsWith("•") ||
                standardKeywords.none { line.contains(it, ignoreCase = true) }
            )
        }
        .map { it.removePrefix("Other:").removePrefix("✔").removePrefix("-").removePrefix("•").trim() }
        .filter { it.isNotBlank() }

    // Specialities
    val specs = swadhyai.specialities.split(",").map { it.trim() }
    val specPratikraman = specs.any { it.equals("Pratikraman", true) }
    val specVaanchan = specs.any { it.equals("Vaanchan", true) || it.equals("Vaachna", true) }
    val specBhakti = specs.any { it.equals("Bhakti", true) }
    val specOther = specs.firstOrNull { it.startsWith("Other: ") }?.removePrefix("Other: ") ?: ""

    // Mandal details
    val joiningYear = if (swadhyai.joiningYear > 0) swadhyai.joiningYear.toString() else ""
    val paryushanCount = if (swadhyai.paryushanCount > 0) swadhyai.paryushanCount.toString() else "0"
    val anotherGroup = swadhyai.anotherGroup
    val postInGroup = swadhyai.postInGroup

    // Daily Activities
    val acts = swadhyai.dailyRoutineActivities.split(",").map { it.trim() }
    val actNavkarshi = acts.any { it.equals("Navkarshi", true) }
    val actPrabhuPujan = acts.any { it.equals("Prabhu Pujan", true) }
    val actRatriBhojanTyag = acts.any { it.equals("Ratri Bhojan Tyag", true) }
    val actTithiPalan = acts.any { it.equals("Tithi Palan", true) }
    val actNavkarPakkiMala = acts.any { it.equals("Navkar Pakki Mala", true) }
    val actSamaiyk = acts.any { it.equals("Samaiyk", true) }
    val actPratikaman = acts.any { it.equals("Pratikaman", true) }
    val otherDailyActivities = acts.filter { it.startsWith("Other: ") }.map { it.removePrefix("Other: ") }

    // Tapasya
    val lifetimeTapasyaList = swadhyai.lifetimeTapasya.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }

    // Active specialities list
    val activeSpecs = mutableListOf<String>()
    if (specPratikraman) activeSpecs.add("Pratikraman")
    if (specVaanchan) activeSpecs.add("Vaanchan")
    if (specBhakti) activeSpecs.add("Bhakti")
    if (specOther.isNotBlank()) activeSpecs.add(specOther)

    // Dynamic stats counts
    val currentYear = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR)
    val displayYearsCount = try {
        val jYear = joiningYear.toIntOrNull()
        if (jYear != null && jYear in 1900..currentYear) {
            (currentYear - jYear).coerceAtLeast(1)
        } else 0
    } catch (_: Exception) { 0 }

    val displaySpecialitiesCount = activeSpecs.size
    val displayLearningsCount = run {
        var count = 0
        if (subMandirDohe) count++
        if (subMandirChaitya) count++
        if (sub2Vanditu) count++
        if (sub2Jagchintamani) count++
        if (sub2Bharser) count++
        if (sub2LaghuShanti) count++
        if (sub2SakalaTirth) count++
        if (sub5Saklarhat) count++
        if (sub5Snatasya) count++
        if (sub5Atichar) count++
        if (sub5AjitShanti) count++
        if (sub5BadiShanti) count++
        if (sub5Santikaram) count++
        count += otherLearningsList.size
        count
    }

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 4 })
    val selectedTab = pagerState.currentPage
    val scrollState = rememberScrollState()

    // Subtitle Line
    val subtitleLine = remember(age, city, state) {
        val parts = mutableListOf<String>()
        if (age.isNotBlank()) parts.add("$age yrs")
        val loc = listOf(city, state).filter { it.isNotBlank() }.joinToString(", ")
        if (loc.isNotBlank()) parts.add(loc)
        if (isTargetAdmin) parts.add("Admin")
        if (parts.isNotEmpty()) parts.joinToString(" • ") else "Swadhyai Member"
    }

    val userInitials = remember(fullName) {
        val parts = fullName.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }
        when {
            parts.isEmpty() -> "SM"
            parts.size == 1 -> parts[0].take(2).uppercase()
            else -> "${parts[0].first().uppercaseChar()}${parts[1].first().uppercaseChar()}"
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val animProgress = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        animProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 340, easing = FastOutSlowInEasing)
        )
    }

    fun triggerDismiss() {
        if (animProgress.isRunning && animProgress.targetValue == 0f) return
        coroutineScope.launch {
            animProgress.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 260, easing = FastOutSlowInEasing)
            )
            onDismiss()
        }
    }

    fun triggerEdit() {
        coroutineScope.launch {
            animProgress.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 200, easing = FastOutLinearInEasing)
            )
            onEdit()
        }
    }

    BackHandler {
        triggerDismiss()
    }

    Dialog(
        onDismissRequest = { triggerDismiss() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val scrimAlpha = (0.65f * animProgress.value).coerceIn(0f, 0.65f)

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = scrimAlpha))
                .clickable { triggerDismiss() },
            contentAlignment = Alignment.Center
        ) {
            val popupWidth = (maxWidth - 20.dp).coerceAtMost(560.dp)
            val popupHeight = (maxHeight - 36.dp).coerceAtMost(800.dp)

            val totalWidthPx = with(density) { maxWidth.toPx() }
            val totalHeightPx = with(density) { maxHeight.toPx() }
            val popupWidthPx = with(density) { popupWidth.toPx() }
            val popupHeightPx = with(density) { popupHeight.toPx() }

            val cardLeftPx = (totalWidthPx - popupWidthPx) / 2f
            val cardTopPx = (totalHeightPx - popupHeightPx) / 2f

            val origin = if (sourceBounds != null && popupWidthPx > 0f && popupHeightPx > 0f) {
                val pivotX = (sourceBounds.center.x - cardLeftPx) / popupWidthPx
                val pivotY = (sourceBounds.center.y - cardTopPx) / popupHeightPx
                TransformOrigin(pivotX, pivotY)
            } else {
                TransformOrigin(0.5f, 0.28f)
            }

            val initialScale = if (sourceBounds != null && popupWidthPx > 0f) {
                (sourceBounds.width / popupWidthPx).coerceIn(0.06f, 0.35f)
            } else {
                0.55f
            }

            val containerScale = lerp(initialScale, 1f, animProgress.value)
            val containerAlpha = animProgress.value.coerceIn(0f, 1f)
            val containerCornerRadius = (44.dp * (1f - animProgress.value) + 22.dp * animProgress.value)

            // Borderless container with only a glowing strip
            Box(
                modifier = Modifier
                    .width(popupWidth)
                    .height(popupHeight)
                    .graphicsLayer {
                        scaleX = containerScale
                        scaleY = containerScale
                        alpha = containerAlpha
                        transformOrigin = origin
                    }
                    .clip(RoundedCornerShape(containerCornerRadius))
                    .background(ProfileDarkBg)
                    .clickable(enabled = false) {}
            ) {
                // Background Watermark Logo
                Image(
                    painter = painterResource(id = R.drawable.header_logo),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    alpha = 0.08f,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .fillMaxSize(0.70f)
                )

                // Layout Dimensions for Collapsing Navigation Header
                val headerBarHeight = 64.dp
                val topHeroAvatarSize = 74.dp
                val pinnedAvatarSize = 40.dp

                val topSpacerHeight = 220.dp
                val statBoxesHeight = 54.dp
                val tabHeaderHeight = 44.dp
                val combinedStickyHeight = statBoxesHeight + 10.dp + tabHeaderHeight + 14.dp
                val dynamicScrollPadding = topSpacerHeight + combinedStickyHeight + 12.dp

                val collapseHeroTravelDp = topSpacerHeight - headerBarHeight
                val collapseHeroTravelPx = with(density) { collapseHeroTravelDp.toPx().coerceAtLeast(1f) }

                val collapseFraction by remember {
                    derivedStateOf {
                        (scrollState.value.toFloat() / collapseHeroTravelPx).coerceIn(0f, 1f)
                    }
                }

                // Helper linear interpolation
                fun lerpDp(start: Dp, stop: Dp, fraction: Float): Dp = start + (stop - start) * fraction
                fun lerpSp(start: Float, stop: Float, fraction: Float): TextUnit = (start + (stop - start) * fraction).sp

                // Avatar coordinates & dimensions:
                // Expanded: Center-X, Y = 16.dp, Size = 74.dp
                // Collapsed: Left-X = 14.dp, Y = 12.dp, Size = 40.dp
                val avatarStartX = (popupWidth - topHeroAvatarSize) / 2
                val avatarEndX = 14.dp
                val avatarStartY = 16.dp
                val avatarEndY = 12.dp

                val currentAvatarSize = lerpDp(topHeroAvatarSize, pinnedAvatarSize, collapseFraction)
                val currentAvatarX = lerpDp(avatarStartX, avatarEndX, collapseFraction)
                val currentAvatarY = lerpDp(avatarStartY, avatarEndY, collapseFraction)
                val currentInitialsFont = lerpSp(24f, 14f, collapseFraction)
                val currentBadgeSize = lerpDp(22.dp, 13.dp, collapseFraction)
                val currentBadgeFont = lerpSp(12f, 7.5f, collapseFraction)

                // Text coordinates & dimensions (Name & Subtitle):
                // Expanded: Center-X, Y = 16.dp + 74.dp + 8.dp = 98.dp
                // Collapsed: Left-X = 62.dp, Y = 13.dp
                var textBlockWidthDp by remember { mutableStateOf(0.dp) }
                val effectiveTextWidth = if (textBlockWidthDp > 0.dp) textBlockWidthDp else 160.dp
                val textStartX = ((popupWidth - effectiveTextWidth) / 2).coerceAtLeast(14.dp)
                val textEndX = 62.dp
                val textStartY = 16.dp + topHeroAvatarSize + 8.dp
                val textEndY = 13.dp

                val currentTextX = lerpDp(textStartX, textEndX, collapseFraction)
                val currentTextY = lerpDp(textStartY, textEndY, collapseFraction)
                val textScale = 1.0f - (0.18f * collapseFraction)

                // Subtitle Color lerp
                val subtitleColor = lerp(
                    ProfileGold,
                    ProfileMuted,
                    collapseFraction
                )

                // -------------------------------------------------------------
                // 1. SCROLLABLE TAB CONTENT LAYER
                // -------------------------------------------------------------
                val minScrollableHeight = popupHeight + collapseHeroTravelDp
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = minScrollableHeight)
                    ) {
                        Spacer(modifier = Modifier.height(dynamicScrollPadding))

                        // Tab Content Cards (Liquid Glass)
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp)
                        ) {
                        HorizontalPager(
                            state = pagerState,
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.Top
                        ) { page ->
                            when (page) {
                            0 -> {
                                // ---------------- PERSONAL TAB ----------------
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // 1. Basic Bio Glass Card
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGold.copy(alpha = 0.45f),
                                                    ProfileGold.copy(alpha = 0.15f),
                                                    ProfileGold.copy(alpha = 0.35f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x752C1E0A), Color(0x4816120B))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                        ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Personal & Family Details",
                                                bulletColor = ProfileGold,
                                                titleColor = ProfileGold
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                InfoGridItem(
                                                    label = "FULL NAME",
                                                    value = fullName,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                InfoGridItem(
                                                    label = "AGE",
                                                    value = if (age.isNotBlank()) "$age Years" else "—",
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))

                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                InfoGridItem(
                                                    label = "FATHER'S NAME",
                                                    value = fatherName.ifBlank { "—" },
                                                    modifier = Modifier.weight(1f)
                                                )
                                                InfoGridItem(
                                                    label = "MOTHER'S NAME",
                                                    value = motherName.ifBlank { "—" },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))

                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                InfoGridItem(
                                                    label = "DATE OF BIRTH",
                                                    value = dob.ifBlank { "—" },
                                                    modifier = Modifier.weight(1f)
                                                )
                                                InfoGridItem(
                                                    label = "BLOOD GROUP",
                                                    value = bloodGroup.ifBlank { "—" },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }

                                            Spacer(modifier = Modifier.height(10.dp))

                                            Row(modifier = Modifier.fillMaxWidth()) {
                                                InfoGridItem(
                                                    label = "MARITAL STATUS",
                                                    value = maritalStatus,
                                                    modifier = Modifier.weight(1f)
                                                )
                                                if (maritalStatus.equals("Married", true) && anniversaryDate.isNotBlank()) {
                                                    InfoGridItem(
                                                        label = "ANNIVERSARY",
                                                        value = anniversaryDate,
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                } else {
                                                    InfoGridItem(
                                                        label = "NATIVE PLACE",
                                                        value = nativePlace.ifBlank { "—" },
                                                        modifier = Modifier.weight(1f)
                                                    )
                                                }
                                            }
                                        }
                                    }

                                    // 2. Education Glass Card (Liquid Glass Teal)
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileTeal.copy(alpha = 0.45f),
                                                    ProfileTeal.copy(alpha = 0.18f),
                                                    ProfileTeal.copy(alpha = 0.35f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x700E262A), Color(0x450A1518))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Education / Qualification",
                                                bulletColor = ProfileTeal,
                                                titleColor = ProfileTeal
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            InfoGridItem(
                                                label = "QUALIFICATION",
                                                value = education.ifBlank { "—" },
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }

                                    // 3. Profession & Work Details Glass Card (Liquid Glass Gold)
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGold.copy(alpha = 0.45f),
                                                    ProfileGold.copy(alpha = 0.18f),
                                                    ProfileGold.copy(alpha = 0.35f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x752C1E0A), Color(0x4816120B))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Profession & Work Details",
                                                bulletColor = ProfileGold,
                                                titleColor = ProfileGold
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            InfoGridItem(
                                                label = "PROFESSION",
                                                value = profession.ifBlank { "—" },
                                                modifier = Modifier.fillMaxWidth()
                                            )

                                            if (workDescription.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(12.dp))
                                                InfoGridItem(
                                                    label = "WORK DETAILS / DESCRIPTION",
                                                    value = workDescription,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            1 -> {
                                // ---------------- RELIGIOUS TAB ----------------
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // 1. Learnings Glass Card (Emerald)
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGreen.copy(alpha = 0.50f),
                                                    ProfileGreen.copy(alpha = 0.18f),
                                                    ProfileGreen.copy(alpha = 0.40f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x700F261B), Color(0x450B1410))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Religious Learnings",
                                                bulletColor = ProfileGreen,
                                                titleColor = ProfileGreen
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            // Mandir Vidhi sub-category
                                            val mandirItems = mutableListOf<String>()
                                            if (subMandirDohe) mandirItems.add("Asht Prakari Puja ke Dohe")
                                            if (subMandirChaitya) mandirItems.add("Chaityawandan Vidhi")

                                            if (mandirItems.isNotEmpty()) {
                                                LearningSectionItem(
                                                    title = "Mandir Vidhi & Puja",
                                                    countStr = "${mandirItems.size}/2",
                                                    subItems = mandirItems.joinToString(" • ")
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                            }

                                            // 2 Pratikraman Sutra
                                            val sutra2Items = mutableListOf<String>()
                                            if (sub2Vanditu) sutra2Items.add("Vanditu")
                                            if (sub2Jagchintamani) sutra2Items.add("Jagchintamani")
                                            if (sub2Bharser) sutra2Items.add("Bharser")
                                            if (sub2LaghuShanti) sutra2Items.add("Laghu Shanti")
                                            if (sub2SakalaTirth) sutra2Items.add("Sakala Tirth")

                                            if (sutra2Items.isNotEmpty()) {
                                                LearningSectionItem(
                                                    title = "2 Pratikraman Sutra",
                                                    countStr = "${sutra2Items.size}/5",
                                                    subItems = sutra2Items.joinToString(" • ")
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                            }

                                            // 5 Pratikraman Sutra
                                            val sutra5Items = mutableListOf<String>()
                                            if (sub5Saklarhat) sutra5Items.add("Saklarhat")
                                            if (sub5Snatasya) sutra5Items.add("Snatasya")
                                            if (sub5Atichar) sutra5Items.add("Atichar")
                                            if (sub5AjitShanti) sutra5Items.add("Ajit Shanti")
                                            if (sub5BadiShanti) sutra5Items.add("Badi Shanti")
                                            if (sub5Santikaram) sutra5Items.add("Santikaram")

                                            if (sutra5Items.isNotEmpty()) {
                                                LearningSectionItem(
                                                    title = "5 Pratikraman Sutra & Stuti",
                                                    countStr = "${sutra5Items.size}/6",
                                                    subItems = sutra5Items.joinToString(" • ")
                                                )
                                                Spacer(modifier = Modifier.height(10.dp))
                                            }

                                            if (otherLearningsList.isNotEmpty()) {
                                                LearningSectionItem(
                                                    title = "Other Adhyayan / Learnings",
                                                    countStr = "${otherLearningsList.size}",
                                                    subItems = otherLearningsList.joinToString(" • ")
                                                )
                                            }

                                            if (mandirItems.isEmpty() && sutra2Items.isEmpty() && sutra5Items.isEmpty() && otherLearningsList.isEmpty()) {
                                                Text(
                                                    text = "No religious learnings specified",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = 13.sp,
                                                        color = ProfileMuted
                                                    )
                                                )
                                            }
                                        }
                                    }

                                    // 2. Daily Routine Activities (Liquid Glass Gold)
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGold.copy(alpha = 0.45f),
                                                    ProfileGold.copy(alpha = 0.18f),
                                                    ProfileGold.copy(alpha = 0.35f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x752C1E0A), Color(0x4816120B))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Daily Routine Activities",
                                                bulletColor = ProfileGold,
                                                titleColor = ProfileGold
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            val activeDaily = mutableListOf<String>()
                                            if (actNavkarshi) activeDaily.add("Navkarshi")
                                            if (actPrabhuPujan) activeDaily.add("Prabhu Pujan")
                                            if (actRatriBhojanTyag) activeDaily.add("Ratri Bhojan Tyag")
                                            if (actTithiPalan) activeDaily.add("Tithi Palan")
                                            if (actNavkarPakkiMala) activeDaily.add("Navkar Pakki Mala")
                                            if (actSamaiyk) activeDaily.add("Samaiyk")
                                            if (actPratikaman) activeDaily.add("Pratikaman")
                                            activeDaily.addAll(otherDailyActivities.filter { it.isNotBlank() })

                                            if (activeDaily.isNotEmpty()) {
                                                @OptIn(ExperimentalLayoutApi::class)
                                                FlowRow(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    activeDaily.forEach { actName ->
                                                        ChipPill(
                                                            text = actName,
                                                            textColor = ProfileGold,
                                                            borderColor = Color(0x60D4AF37)
                                                        )
                                                    }
                                                }
                                            } else {
                                                Text(
                                                    text = "None specified",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = 13.sp,
                                                        color = ProfileMuted
                                                    )
                                                )
                                            }
                                        }
                                    }

                                    // 3. Lifetime Tapasya & Tyag (Liquid Glass Maroon)
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileMaroon.copy(alpha = 0.55f),
                                                    ProfileMaroon.copy(alpha = 0.18f),
                                                    ProfileMaroon.copy(alpha = 0.40f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x65301018), Color(0x4016080C))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Lifetime Tapasya & Tyag",
                                                bulletColor = ProfileMaroon,
                                                titleColor = Color(0xFFFFB4AB)
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            if (lifetimeTapasyaList.isNotEmpty()) {
                                                @OptIn(ExperimentalLayoutApi::class)
                                                FlowRow(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    lifetimeTapasyaList.forEach { tap ->
                                                        ChipPill(
                                                            text = tap,
                                                            textColor = Color(0xFFFFB4AB),
                                                            borderColor = Color(0x80B4425A)
                                                        )
                                                    }
                                                }
                                            } else {
                                                Text(
                                                    text = "None specified",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = 13.sp,
                                                        color = ProfileMuted
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            2 -> {
                                // ---------------- MANDAL TAB ----------------
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // 1. Mandal Journey Card
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGold.copy(alpha = 0.50f),
                                                    ProfileGold.copy(alpha = 0.20f),
                                                    ProfileGold.copy(alpha = 0.40f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x752C1E0A), Color(0x4816120B))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Mandal Journey & Service",
                                                bulletColor = ProfileGold,
                                                titleColor = ProfileGold
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            MandalInfoRow(
                                                label = "Year Joined Vardhman Mandal",
                                                value = joiningYear.ifBlank { "—" }
                                            )
                                            MandalInfoRow(
                                                label = "Paryushan Aaradhna Attended",
                                                value = if (paryushanCount.isNotBlank()) "$paryushanCount times" else "0 times"
                                            )
                                            if (swadhyai.paryushanHistoryLog.isNotBlank()) {
                                                MandalInfoRow(
                                                    label = "Allotted Sangh History",
                                                    value = swadhyai.paryushanHistoryLog
                                                )
                                            }
                                            if (anotherGroup.isNotBlank()) {
                                                MandalInfoRow(
                                                    label = "Other Religious Groups",
                                                    value = anotherGroup
                                                )
                                            }
                                            if (postInGroup.isNotBlank()) {
                                                MandalInfoRow(
                                                    label = "Special Post / Position",
                                                    value = postInGroup
                                                )
                                            }
                                            if (swadhyai.paryushanWillingness.isNotBlank()) {
                                                MandalInfoRow(
                                                    label = "Paryushan Willingness",
                                                    value = swadhyai.paryushanWillingness
                                                )
                                            }
                                            if (swadhyai.remarks.isNotBlank()) {
                                                MandalInfoRow(
                                                    label = "Remarks / Notes",
                                                    value = swadhyai.remarks,
                                                    isLast = true
                                                )
                                            }
                                        }
                                    }

                                    // 2. Specialities & Seva
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGold.copy(alpha = 0.45f),
                                                    ProfileGold.copy(alpha = 0.18f),
                                                    ProfileGold.copy(alpha = 0.35f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x752C1E0A), Color(0x4816120B))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Mandal Specialities & Seva",
                                                bulletColor = ProfileGold,
                                                titleColor = ProfileGold
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            if (activeSpecs.isNotEmpty()) {
                                                @OptIn(ExperimentalLayoutApi::class)
                                                FlowRow(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    activeSpecs.forEach { specName ->
                                                        ChipPill(
                                                            text = specName,
                                                            textColor = ProfileGold,
                                                            borderColor = Color(0x60D4AF37)
                                                        )
                                                    }
                                                }
                                            } else {
                                                Text(
                                                    text = "None specified",
                                                    style = MaterialTheme.typography.bodyMedium.copy(
                                                        fontSize = 13.sp,
                                                        color = ProfileMuted
                                                    )
                                                )
                                            }
                                        }
                                    }

                                    // 3. Status & Code of Conduct
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileGreen.copy(alpha = 0.50f),
                                                    ProfileGreen.copy(alpha = 0.20f),
                                                    ProfileGreen.copy(alpha = 0.40f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x700F261B), Color(0x450B1410))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Mandal Status & Guidelines",
                                                bulletColor = ProfileGreen,
                                                titleColor = ProfileGreen
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            MandalInfoRow(
                                                label = "Membership Role",
                                                value = if (isTargetAdmin) "Admin Swadhyai" else "Active Swadhyai",
                                                valueColor = ProfileGreen
                                            )
                                            MandalInfoRow(
                                                label = "Mandal Code of Conduct",
                                                value = if (swadhyai.acceptedRules) "Accepted & Verified" else "Accepted",
                                                isLast = true
                                            )
                                        }
                                    }
                                }
                            }

                            3 -> {
                                // ---------------- CONTACT TAB ----------------
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            Brush.linearGradient(
                                                listOf(
                                                    ProfileTeal.copy(alpha = 0.50f),
                                                    ProfileTeal.copy(alpha = 0.20f),
                                                    ProfileTeal.copy(alpha = 0.40f)
                                                )
                                            )
                                        ),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(
                                                Brush.linearGradient(
                                                    listOf(Color(0x700E262A), Color(0x450A1518))
                                                ),
                                                RoundedCornerShape(18.dp)
                                            )
                                    ) {
                                        Column(modifier = Modifier.padding(16.dp)) {
                                            CardHeaderRow(
                                                title = "Contact & Address",
                                                bulletColor = ProfileTeal,
                                                titleColor = ProfileTeal
                                            )
                                            Spacer(modifier = Modifier.height(12.dp))

                                            val whatsappDisplay = if (whatsappNo.isNotBlank()) "+91 $whatsappNo" else "Not specified"
                                            ContactInfoRow(
                                                icon = "📱",
                                                label = "WHATSAPP",
                                                value = whatsappDisplay
                                            )

                                            HorizontalDivider(
                                                color = ProfileDarkBorder.copy(alpha = 0.5f),
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )

                                            ContactInfoRow(
                                                icon = "☎️",
                                                label = "ALTERNATE CONTACT",
                                                value = contactNo.ifBlank { "Not specified" }
                                            )

                                            HorizontalDivider(
                                                color = ProfileDarkBorder.copy(alpha = 0.5f),
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )

                                            ContactInfoRow(
                                                icon = "✉️",
                                                label = "EMAIL",
                                                value = emailId.ifBlank { "Not specified" }
                                            )

                                            HorizontalDivider(
                                                color = ProfileDarkBorder.copy(alpha = 0.5f),
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )

                                            val fullAddr = listOf(address, city, state).filter { it.isNotBlank() }.joinToString(", ").let {
                                                if (pincode.isNotBlank()) "$it — $pincode" else it
                                            }.ifBlank { "Not specified" }
                                            ContactInfoRow(
                                                icon = "📍",
                                                label = "ADDRESS",
                                                value = fullAddr
                                            )

                                            if (emergencyName.isNotBlank() || emergencyContactNo.isNotBlank()) {
                                                Spacer(modifier = Modifier.height(12.dp))

                                                // Emergency Box
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = Color(0x25B4425A),
                                                    border = BorderStroke(1.dp, Color(0x60B4425A)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(10.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                    ) {
                                                        Text(text = "🚨", fontSize = 14.sp)
                                                        val emName = emergencyName.ifBlank { "Emergency Contact" }
                                                        val emRel = emergencyRelation.ifBlank { "" }
                                                        val emNo = emergencyContactNo.ifBlank { "" }
                                                        val emergencyStr = if (emRel.isNotBlank() && emNo.isNotBlank()) {
                                                            "Emergency: $emName ($emRel) — $emNo"
                                                        } else if (emNo.isNotBlank()) {
                                                            "Emergency: $emName — $emNo"
                                                        } else {
                                                            "Emergency: $emName"
                                                        }
                                                        Text(
                                                            text = emergencyStr,
                                                            style = MaterialTheme.typography.bodySmall.copy(
                                                                color = Color(0xFFFFB4AB),
                                                                fontSize = 12.sp
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        }
                    }

                    // Clean natural bottom padding inside scroll container
                    Spacer(modifier = Modifier.height(18.dp))
                }
                }

                // -------------------------------------------------------------
                // 2. STICKY / PINNED PANE (4 STAT BOXES + TAB SELECTOR ROW)
                // -------------------------------------------------------------
                val initialStickyPaneY = topSpacerHeight
                val currentScrollDp = with(density) { scrollState.value.toDp() }
                val currentStickyPaneY = (initialStickyPaneY - currentScrollDp).coerceAtLeast(headerBarHeight)
                val isPanePinned = currentStickyPaneY <= headerBarHeight

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .offset(y = currentStickyPaneY)
                        .background(
                            if (isPanePinned) ProfileDarkBg.copy(alpha = 0.98f) else Color.Transparent
                        )
                        .padding(horizontal = 14.dp, vertical = if (isPanePinned) 6.dp else 0.dp)
                ) {
                    // ---- 4 STAT BOXES ----
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(statBoxesHeight),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        PopupStatBox(
                            num = paryushanCount.ifBlank { "0" },
                            lbl = "PARYUSHAN",
                            modifier = Modifier.weight(1f)
                        )
                        PopupStatBox(
                            num = displayYearsCount.toString(),
                            lbl = "YRS IN\nMANDAL",
                            modifier = Modifier.weight(1f)
                        )
                        PopupStatBox(
                            num = displaySpecialitiesCount.toString(),
                            lbl = "SPECIALITIES",
                            modifier = Modifier.weight(1.05f)
                        )
                        PopupStatBox(
                            num = displayLearningsCount.toString(),
                            lbl = "LEARNINGS",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // ---- TAB SELECTOR ROW (Liquid Glass Pill Bar) ----
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = Color.Transparent,
                        border = BorderStroke(
                            1.dp,
                            Brush.linearGradient(
                                listOf(
                                    ProfileGold.copy(alpha = if (isPanePinned) 0.60f else 0.40f),
                                    ProfileGold.copy(alpha = 0.15f),
                                    ProfileGold.copy(alpha = if (isPanePinned) 0.50f else 0.30f)
                                )
                            )
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        if (isPanePinned) ProfileDarkSurface.copy(alpha = 0.95f) else ProfileDarkSurface.copy(alpha = 0.55f),
                                        if (isPanePinned) ProfileDarkBg.copy(alpha = 0.98f) else ProfileDarkBg.copy(alpha = 0.40f)
                                    )
                                ),
                                RoundedCornerShape(22.dp)
                            )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(3.dp),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            PopupTabPillButton(
                                text = "Personal",
                                selected = selectedTab == 0,
                                onClick = {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(0)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            PopupTabPillButton(
                                text = "Religious",
                                selected = selectedTab == 1,
                                onClick = {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(1)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            PopupTabPillButton(
                                text = "Mandal",
                                selected = selectedTab == 2,
                                onClick = {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(2)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                            PopupTabPillButton(
                                text = "Contact",
                                selected = selectedTab == 3,
                                onClick = {
                                    coroutineScope.launch {
                                        pagerState.animateScrollToPage(3)
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // -------------------------------------------------------------
                // 3. PINNED HEADER BACKGROUND
                // -------------------------------------------------------------
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(headerBarHeight)
                        .background(
                            ProfileDarkSurface.copy(
                                alpha = (0.6f + (collapseFraction * 0.38f)).coerceIn(0.6f, 0.98f)
                            )
                        )
                )

                // -------------------------------------------------------------
                // 4. SLIDING AVATAR (Glide & scale from center hero -> top bar pinned avatar spot)
                // -------------------------------------------------------------
                Box(
                    modifier = Modifier
                        .offset(x = currentAvatarX, y = currentAvatarY)
                        .size(currentAvatarSize)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(ProfileGold, ProfileGoldDeep, ProfileGold)
                            )
                        )
                        .padding(if (collapseFraction > 0.6f) 1.5.dp else 2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0x38262012), ProfileDarkSurface2)
                                )
                            )
                            .border(if (collapseFraction > 0.6f) 1.dp else 2.dp, ProfileDarkBg, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userInitials,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = currentInitialsFont,
                                color = ProfileGold
                            )
                        )
                    }

                    // Admin badge (if admin)
                    if (isTargetAdmin) {
                        Surface(
                            shape = CircleShape,
                            color = ProfileGold,
                            border = BorderStroke(if (collapseFraction > 0.6f) 1.dp else 2.dp, ProfileDarkBg),
                            modifier = Modifier
                                .size(currentBadgeSize)
                                .align(Alignment.BottomEnd)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "★",
                                    color = Color(0xFF08130F),
                                    fontSize = currentBadgeFont,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }

                // -------------------------------------------------------------
                // 5. SLIDING NAME & SUBTITLE (Glide & scale from below hero avatar -> top bar title spot)
                // -------------------------------------------------------------
                Column(
                    modifier = Modifier
                        .offset(x = currentTextX, y = currentTextY)
                        .widthIn(max = popupWidth - 120.dp)
                        .onSizeChanged { size ->
                            if (size.width > 0 && (textBlockWidthDp == 0.dp || collapseFraction == 0f)) {
                                textBlockWidthDp = with(density) { size.width.toDp() }
                            }
                        }
                        .graphicsLayer {
                            scaleX = textScale
                            scaleY = textScale
                            transformOrigin = TransformOrigin(0f, 0f)
                        },
                    horizontalAlignment = if (collapseFraction < 0.5f) Alignment.CenterHorizontally else Alignment.Start
                ) {
                    Text(
                        text = fullName,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = 19.sp,
                            color = ProfileCream,
                            letterSpacing = 0.2.sp
                        ),
                        textAlign = if (collapseFraction < 0.5f) TextAlign.Center else TextAlign.Start,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = subtitleLine,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = subtitleColor,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 15.sp
                        ),
                        textAlign = if (collapseFraction < 0.5f) TextAlign.Center else TextAlign.Start,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // -------------------------------------------------------------
                // 6. HEADER ACTION ICONS ON RIGHT (Edit & Close)
                // -------------------------------------------------------------
                Row(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 6.dp, top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isAdmin) {
                        IconButton(
                            onClick = { triggerEdit() },
                            modifier = Modifier.size(40.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Swadhyai",
                                tint = ProfileGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    IconButton(
                        onClick = { triggerDismiss() },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = ProfileCream,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                // -------------------------------------------------------------
                // 7. TOP GLOWING STRIP (Liquid Gold/Emerald Neon Horizon Glow)
                // -------------------------------------------------------------
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.TopCenter)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    ProfileGold.copy(alpha = 0.4f),
                                    ProfileGold,
                                    ProfileGreen,
                                    ProfileGold,
                                    ProfileGold.copy(alpha = 0.4f),
                                    Color.Transparent
                                )
                            )
                        )
                )
            }
        }
    }
}

// -------------------------------------------------------------
// Helper UI Components
// -------------------------------------------------------------
@Composable
private fun PopupStatBox(
    num: String,
    lbl: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent,
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    ProfileGold.copy(alpha = 0.40f),
                    ProfileGold.copy(alpha = 0.12f),
                    ProfileGold.copy(alpha = 0.30f)
                )
            )
        ),
        modifier = modifier
            .fillMaxHeight()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0x552C1E0A), Color(0x3516120B))
                ),
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 2.dp, vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = num,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    color = ProfileGold
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = lbl,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.3.sp,
                    lineHeight = 10.sp
                ),
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun PopupTabPillButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .then(
                if (selected) {
                    Modifier.background(
                        Brush.horizontalGradient(
                            listOf(ProfileGoldDeep, ProfileGold)
                        )
                    )
                } else {
                    Modifier.background(Color.Transparent)
                }
            )
            .clickable { onClick() }
            .padding(vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Bold,
                fontSize = 12.sp,
                color = if (selected) Color(0xFF1A1305) else ProfileMuted
            )
        )
    }
}

@Composable
private fun CardHeaderRow(
    title: String,
    bulletColor: Color,
    titleColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(bulletColor)
        )
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp,
                letterSpacing = 1.sp,
                color = titleColor
            )
        )
    }
}

@Composable
private fun InfoGridItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 9.5.sp,
                color = ProfileMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = ProfileCream
            )
        )
    }
}

@Composable
private fun LearningSectionItem(
    title: String,
    countStr: String,
    subItems: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = ProfileCream
                )
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = ProfileGreen,
                contentColor = Color(0xFF08130F)
            ) {
                Text(
                    text = countStr,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subItems,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 11.5.sp,
                color = ProfileMuted,
                lineHeight = 16.sp
            )
        )
    }
}

@Composable
private fun ChipPill(
    text: String,
    textColor: Color,
    borderColor: Color
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0x08FFFFFF),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 11.5.sp,
                color = textColor
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun MandalInfoRow(
    label: String,
    value: String,
    valueColor: Color = ProfileCream,
    isLast: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 9.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = ProfileMuted
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = valueColor
                ),
                textAlign = TextAlign.End
            )
        }
        if (!isLast) {
            HorizontalDivider(
                color = ProfileDarkBorder.copy(alpha = 0.6f),
                thickness = 0.6.dp
            )
        }
    }
}

@Composable
private fun ContactInfoRow(
    icon: String,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0x0AFFFFFF),
            border = BorderStroke(1.dp, ProfileDarkBorder),
            modifier = Modifier.size(32.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = icon, fontSize = 13.sp)
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.4.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileCream
                )
            )
        }
    }
}
