package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ParyushanFormEntity
import com.example.ui.components.ActivityAttendanceGridSelector
import com.example.ui.components.CheckboxOptionList
import com.example.ui.components.QuestionHeader
import com.example.ui.components.RadioOptionGroup

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun EditFormScreen(
    formId: Long,
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formState by viewModel.getFormFlow(formId).collectAsStateWithLifecycle(initialValue = null)

    var isInitialized by remember { mutableStateOf(false) }

    var sanghName by remember { mutableStateOf("") }
    var sanghAddress by remember { mutableStateOf("") }
    var cityName by remember { mutableStateOf("") }
    var contact1 by remember { mutableStateOf("") }
    var contact2 by remember { mutableStateOf("") }
    var mulnayakBhagwan by remember { mutableStateOf("") }
    var totalFamilies by remember { mutableStateOf("") }
    var hasOtherSangh by remember { mutableStateOf("नहीं") }
    var gacchList by remember { mutableStateOf("") }
    var pratikramanTradition by remember { mutableStateOf("") }
    var hasMusicianGroup by remember { mutableStateOf("नहीं") }
    var callsOutsideMusician by remember { mutableStateOf("नहीं") }
    var hasPanchPratikramanPerson by remember { mutableStateOf("नहीं") }
    var hasToiletFacility by remember { mutableStateOf("नहीं") }
    var aradhanaSamagriList by remember { mutableStateOf("") }
    var countRaiPratikraman by remember { mutableStateOf("") }
    var countDevasiPratikraman by remember { mutableStateOf("") }
    var countPravachan by remember { mutableStateOf("") }
    var countSandhyaBhakti by remember { mutableStateOf("") }
    var mainTrustees by remember { mutableStateOf("") }
    var agreedToTerms by remember { mutableStateOf(true) }

    LaunchedEffect(formState) {
        val form = formState
        if (form != null && !isInitialized) {
            sanghName = form.sanghName
            sanghAddress = form.sanghAddress
            cityName = form.cityName
            contact1 = form.contact1
            contact2 = form.contact2
            mulnayakBhagwan = form.mulnayakBhagwan
            totalFamilies = form.totalFamilies
            hasOtherSangh = form.hasOtherSangh.ifBlank { "नहीं" }
            gacchList = form.gacchList
            pratikramanTradition = form.pratikramanTradition
            hasMusicianGroup = form.hasMusicianGroup.ifBlank { "नहीं" }
            callsOutsideMusician = form.callsOutsideMusician.ifBlank { "नहीं" }
            hasPanchPratikramanPerson = form.hasPanchPratikramanPerson.ifBlank { "नहीं" }
            hasToiletFacility = form.hasToiletFacility.ifBlank { "नहीं" }
            aradhanaSamagriList = form.aradhanaSamagriList
            countRaiPratikraman = form.countRaiPratikraman
            countDevasiPratikraman = form.countDevasiPratikraman
            countPravachan = form.countPravachan
            countSandhyaBhakti = form.countSandhyaBhakti
            mainTrustees = form.mainTrustees
            agreedToTerms = form.agreedToTerms
            isInitialized = true
        }
    }

    fun saveFormChanges() {
        val currentForm = formState ?: return
        if (sanghName.isBlank()) {
            Toast.makeText(context, "कृपया श्रीसंघ का नाम दर्ज करें", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedForm = currentForm.copy(
            sanghName = sanghName.trim(),
            sanghAddress = sanghAddress.trim(),
            cityName = cityName.trim(),
            contact1 = contact1.trim(),
            contact2 = contact2.trim(),
            mulnayakBhagwan = mulnayakBhagwan.trim(),
            totalFamilies = totalFamilies.trim(),
            hasOtherSangh = hasOtherSangh,
            gacchList = gacchList.trim(),
            pratikramanTradition = pratikramanTradition.trim(),
            hasMusicianGroup = hasMusicianGroup,
            callsOutsideMusician = callsOutsideMusician,
            hasPanchPratikramanPerson = hasPanchPratikramanPerson,
            hasToiletFacility = hasToiletFacility,
            aradhanaSamagriList = aradhanaSamagriList.trim(),
            countRaiPratikraman = countRaiPratikraman.trim(),
            countDevasiPratikraman = countDevasiPratikraman.trim(),
            countPravachan = countPravachan.trim(),
            countSandhyaBhakti = countSandhyaBhakti.trim(),
            mainTrustees = mainTrustees.trim(),
            agreedToTerms = agreedToTerms
        )

        viewModel.updateForm(updatedForm) {
            Toast.makeText(context, "फॉर्म सफलतापूर्वक अपडेट किया गया", Toast.LENGTH_SHORT).show()
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("फॉर्म संपादन करें", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "पीछे जाएँ")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { saveFormChanges() },
                        modifier = Modifier.testTag("save_edit_top_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "सहेजें", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { saveFormChanges() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("save_edit_bottom_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("बदलाव सहेजें (Save)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        val form = formState
        if (form == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val scrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "नीचे दिए गए फ़ील्ड एवं विकल्पों से जानकारी बदलें और 'बदलाव सहेजें' बटन पर क्लिक करें।",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onPrimaryContainer),
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    // Q1: Sangh Name
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१", title = "श्री संघ का नाम")
                            OutlinedTextField(
                                value = sanghName,
                                onValueChange = { sanghName = it },
                                label = { Text("श्रीसंघ का नाम") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_sangh_name")
                            )
                        }
                    }

                    // Q2: Address
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "२", title = "श्री संघ का पूरा पता")
                            OutlinedTextField(
                                value = sanghAddress,
                                onValueChange = { sanghAddress = it },
                                label = { Text("पूरा पता") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("edit_sangh_address")
                            )
                        }
                    }

                    // Q3: City Name
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "३", title = "आपके शहर/गांव का नाम")
                            OutlinedTextField(
                                value = cityName,
                                onValueChange = { cityName = it },
                                label = { Text("शहर / गांव") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_city_name")
                            )
                        }
                    }

                    // Q4: Contact Person 1
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "४", title = "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद (१)")
                            OutlinedTextField(
                                value = contact1,
                                onValueChange = { contact1 = it },
                                label = { Text("नाम एवं पद") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_contact1")
                            )
                        }
                    }

                    // Q5: Contact Person 2 (WhatsApp)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "५", title = "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका WhatsApp न.")
                            OutlinedTextField(
                                value = contact2,
                                onValueChange = { contact2 = it },
                                label = { Text("WhatsApp नंबर") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_contact2")
                            )
                        }
                    }

                    // Q6: Mulnayak Bhagwan
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "६", title = "आपके संघ में मुलनायक भगवान कौन से हैं?")
                            OutlinedTextField(
                                value = mulnayakBhagwan,
                                onValueChange = { mulnayakBhagwan = it },
                                label = { Text("मुलनायक भगवान") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_mulnayak")
                            )
                        }
                    }

                    // Q7: Total Families
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "७", title = "आपके संघ में कितने परिवार है?")
                            OutlinedTextField(
                                value = totalFamilies,
                                onValueChange = { totalFamilies = it },
                                label = { Text("परिवारों की संख्या") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_families")
                            )
                        }
                    }

                    // Q8: Other Sangh
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "८", title = "क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasOtherSangh.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasOtherSangh = it }
                            )
                        }
                    }

                    // Q9: Gacch List (Checkbox options + Text Input)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "९", title = "आपके संघ में कौन-कौन से गच्छ हैं?")
                            val commonGacchs = listOf("तपागच्छ", "खरतरगच्छ", "अंचल गच्छ", "त्रिस्तुतिक गच्छ", "स्थानकवासी", "अन्य")
                            val selectedGacchs = commonGacchs.filter { option ->
                                gacchList.split(",").map { it.trim() }.any { it.equals(option, ignoreCase = true) }
                            }

                            Text(
                                text = "विकल्प चुनें (Checkboxes):",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            CheckboxOptionList(
                                allOptions = commonGacchs,
                                selectedList = selectedGacchs,
                                onToggle = { option ->
                                    val currentItems = gacchList.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.equals(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    gacchList = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = gacchList,
                                onValueChange = { gacchList = it },
                                label = { Text("गच्छ (उदा: तपागच्छ, खरतरगच्छ)") },
                                singleLine = false,
                                maxLines = 3,
                                modifier = Modifier.fillMaxWidth().testTag("edit_gacch")
                            )
                        }
                    }

                    // Q10: Pratikraman Tradition (Checkbox options + Text Input)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१०", title = "आपके संघ में कौनसा प्रतिकमण किया जाता है?")
                            val commonTraditions = listOf("वीतराग मार्ग", "तपागच्छ", "त्रिस्तुतिक गच्छ", "खरतरगच्छ", "पाक्षिक प्रतिकमण", "स्थानकवासी", "अन्य")
                            val selectedTraditions = commonTraditions.filter { option ->
                                pratikramanTradition.split(",").map { it.trim() }.any { it.equals(option, ignoreCase = true) }
                            }

                            Text(
                                text = "विकल्प चुनें (Checkboxes):",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            CheckboxOptionList(
                                allOptions = commonTraditions,
                                selectedList = selectedTraditions,
                                onToggle = { option ->
                                    val currentItems = pratikramanTradition.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.equals(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    pratikramanTradition = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = pratikramanTradition,
                                onValueChange = { pratikramanTradition = it },
                                label = { Text("प्रतिकमण परंपरा") },
                                singleLine = false,
                                maxLines = 3,
                                modifier = Modifier.fillMaxWidth().testTag("edit_tradition")
                            )
                        }
                    }

                    // Q11: Musician Group
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "११", title = "आपके श्रीसंघ में कोई संगीतकार/मंडल हैं?")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasMusicianGroup.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasMusicianGroup = it }
                            )
                        }
                    }

                    // Q12: Outside Musician
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१२", title = "क्या आप बाहर से संगीतकार बुलाते हों?")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (callsOutsideMusician.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { callsOutsideMusician = it }
                            )
                        }
                    }

                    // Q13: Panch Pratikraman Person
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१३", title = "पंच प्रतिकमण जानकार व्यक्ति हाजिर है?")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasPanchPratikramanPerson.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasPanchPratikramanPerson = it }
                            )
                        }
                    }

                    // Q14: Toilet Facility
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१४", title = "मातृ-ठल्ले (Toilet) की व्यवस्था हैं?")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasToiletFacility.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasToiletFacility = it }
                            )
                        }
                    }

                    // Q15: Aradhana Samagri List (Checkbox options + Text Input)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१५", title = "आराधना सामग्री सूची")
                            val commonSamagri = listOf("पट - चित्र", "देव-पूजा सामग्री", "प्रतिकमण पोथी", "नवकार गाथा पोथी", "चामर / पंखा", "अन्य")
                            val selectedSamagri = commonSamagri.filter { option ->
                                aradhanaSamagriList.split(",").map { it.trim() }.any { it.equals(option, ignoreCase = true) }
                            }

                            Text(
                                text = "सामग्री विकल्प चुनें (Checkboxes):",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            CheckboxOptionList(
                                allOptions = commonSamagri,
                                selectedList = selectedSamagri,
                                onToggle = { option ->
                                    val currentItems = aradhanaSamagriList.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.equals(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    aradhanaSamagriList = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            OutlinedTextField(
                                value = aradhanaSamagriList,
                                onValueChange = { aradhanaSamagriList = it },
                                label = { Text("सामग्री की सूची") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("edit_samagri")
                            )
                        }
                    }

                    // Q16: Attendance Counts (Grid Selector + Numeric Inputs)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            QuestionHeader(number = "१६", title = "पर्यूषण दौरान प्रवृत्तियों में हाजिर व्यक्तियों की संख्या")

                            ActivityAttendanceGridSelector(
                                activityName = "राई प्रतिकमण हाजिरी",
                                selectedCount = countRaiPratikraman,
                                onSelectCount = { countRaiPratikraman = it }
                            )
                            OutlinedTextField(
                                value = countRaiPratikraman,
                                onValueChange = { countRaiPratikraman = it },
                                label = { Text("राई प्रतिकमण (संख्या / विवरण)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_rai")
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "देवसी प्रतिकमण हाजिरी",
                                selectedCount = countDevasiPratikraman,
                                onSelectCount = { countDevasiPratikraman = it }
                            )
                            OutlinedTextField(
                                value = countDevasiPratikraman,
                                onValueChange = { countDevasiPratikraman = it },
                                label = { Text("देवसी प्रतिकमण (संख्या / विवरण)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_devasi")
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "प्रवचन हाजिरी",
                                selectedCount = countPravachan,
                                onSelectCount = { countPravachan = it }
                            )
                            OutlinedTextField(
                                value = countPravachan,
                                onValueChange = { countPravachan = it },
                                label = { Text("प्रवचन (संख्या / विवरण)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_pravachan")
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "संध्या भक्ति हाजिरी",
                                selectedCount = countSandhyaBhakti,
                                onSelectCount = { countSandhyaBhakti = it }
                            )
                            OutlinedTextField(
                                value = countSandhyaBhakti,
                                onValueChange = { countSandhyaBhakti = it },
                                label = { Text("संध्या भक्ति (संख्या / विवरण)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_bhakti")
                            )
                        }
                    }

                    // Q17: Main Trustees
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१७", title = "श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर")
                            OutlinedTextField(
                                value = mainTrustees,
                                onValueChange = { mainTrustees = it },
                                label = { Text("ट्रस्टी नाम और मोबाइल नंबर") },
                                minLines = 2,
                                maxLines = 5,
                                modifier = Modifier.fillMaxWidth().testTag("edit_trustees")
                            )
                        }
                    }

                    // Q18: Agreement
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१८", title = "सर्व अग्रणियों की सम्मति एवं नियम स्वीकृति")
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                Checkbox(
                                    checked = agreedToTerms,
                                    onCheckedChange = { agreedToTerms = it },
                                    modifier = Modifier.testTag("edit_terms_checkbox")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "समस्त अग्रणियों की सर्वसम्मति एवं नियम स्वीकृत हैं",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
