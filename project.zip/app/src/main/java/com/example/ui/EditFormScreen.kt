package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ParyushanFormEntity
import com.example.ui.components.ActivityAttendanceGridSelector
import com.example.ui.components.CheckboxOptionList
import com.example.ui.components.QuestionHeader
import com.example.ui.components.RadioOptionGroup
import com.example.ui.components.StateDropdownSelector

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditFormScreen(
    formId: Long,
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formState by viewModel.getFormFlow(formId).collectAsStateWithLifecycle(initialValue = null)

    var isInitialized by remember { mutableStateOf(false) }

    var sanghName by remember { mutableStateOf("") }
    var sanghAddress by remember { mutableStateOf("") }
    var cityName by remember { mutableStateOf("") }
    var stateName by remember { mutableStateOf("") }
    var contact1 by remember { mutableStateOf("") }
    var contact2 by remember { mutableStateOf("") }
    var mulnayakBhagwan by remember { mutableStateOf("") }
    var totalFamilies by remember { mutableStateOf("") }
    var hasOtherSangh by remember { mutableStateOf("नहीं") }
    var gacchList by remember { mutableStateOf("") }
    var pratikramanTradition by remember { mutableStateOf("") }
    var hasMusicianGroup by remember { mutableStateOf("नहीं") }
    var callsOutsideMusician by remember { mutableStateOf("नहीं") }
    var hasPanchPratikramanPerson by remember { mutableStateOf("नहीं") }
    var hasToiletFacility by remember { mutableStateOf("नहीं") }
    var aradhanaSamagriList by remember { mutableStateOf("") }
    var countRaiPratikraman by remember { mutableStateOf("") }
    var countDevasiPratikraman by remember { mutableStateOf("") }
    var countPravachan by remember { mutableStateOf("") }
    var countSandhyaBhakti by remember { mutableStateOf("") }
    var mainTrustees by remember { mutableStateOf("") }
    var agreedToTerms by remember { mutableStateOf(true) }
    var ruleConsent1 by remember { mutableStateOf(true) }
    var ruleConsent2 by remember { mutableStateOf(true) }

    LaunchedEffect(formState) {
        val form = formState
        if (form != null && !isInitialized) {
            sanghName = form.sanghName
            sanghAddress = form.sanghAddress
            cityName = form.cityName
            stateName = form.stateName
            contact1 = form.contact1
            contact2 = form.contact2
            mulnayakBhagwan = form.mulnayakBhagwan
            totalFamilies = form.totalFamilies
            hasOtherSangh = form.hasOtherSangh.ifBlank { "नहीं" }
            gacchList = form.gacchList
            pratikramanTradition = form.pratikramanTradition
            hasMusicianGroup = form.hasMusicianGroup.ifBlank { "नहीं" }
            callsOutsideMusician = form.callsOutsideMusician.ifBlank { "नहीं" }
            hasPanchPratikramanPerson = form.hasPanchPratikramanPerson.ifBlank { "नहीं" }
            hasToiletFacility = form.hasToiletFacility.ifBlank { "नहीं" }
            aradhanaSamagriList = form.aradhanaSamagriList
            countRaiPratikraman = form.countRaiPratikraman
            countDevasiPratikraman = form.countDevasiPratikraman
            countPravachan = form.countPravachan
            countSandhyaBhakti = form.countSandhyaBhakti
            mainTrustees = form.mainTrustees
            agreedToTerms = form.agreedToTerms
            ruleConsent1 = form.agreedToTerms
            ruleConsent2 = form.agreedToTerms
            isInitialized = true
        }
    }

    fun saveFormChanges() {
        val currentForm = formState ?: return
        if (sanghName.isBlank()) {
            Toast.makeText(context, "कृपया श्रीसंघ का नाम दर्ज करें", Toast.LENGTH_SHORT).show()
            return
        }

        if (!ruleConsent1 || !ruleConsent2) {
            Toast.makeText(context, "प्रश्न १८: सम्मति के दोनों चेकबॉक्स स्वीकार करना आवश्यक है", Toast.LENGTH_SHORT).show()
            return
        }

        val updatedForm = currentForm.copy(
            sanghName = sanghName.trim(),
            sanghAddress = sanghAddress.trim(),
            cityName = cityName.trim(),
            stateName = stateName.trim(),
            contact1 = contact1.trim(),
            contact2 = contact2.trim(),
            mulnayakBhagwan = mulnayakBhagwan.trim(),
            totalFamilies = totalFamilies.trim(),
            hasOtherSangh = hasOtherSangh,
            gacchList = gacchList.trim(),
            pratikramanTradition = pratikramanTradition.trim(),
            hasMusicianGroup = hasMusicianGroup,
            callsOutsideMusician = callsOutsideMusician,
            hasPanchPratikramanPerson = hasPanchPratikramanPerson,
            hasToiletFacility = hasToiletFacility,
            aradhanaSamagriList = aradhanaSamagriList.trim(),
            countRaiPratikraman = countRaiPratikraman.trim(),
            countDevasiPratikraman = countDevasiPratikraman.trim(),
            countPravachan = countPravachan.trim(),
            countSandhyaBhakti = countSandhyaBhakti.trim(),
            mainTrustees = mainTrustees.trim(),
            agreedToTerms = ruleConsent1 && ruleConsent2
        )

        viewModel.updateForm(updatedForm) {
            Toast.makeText(context, "फॉर्म सफलतापूर्वक अपडेट किया गया", Toast.LENGTH_SHORT).show()
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("फॉर्म संपादन करें", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "पीछे जाएँ")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { saveFormChanges() },
                        modifier = Modifier.testTag("save_edit_top_btn")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "सहेजें", tint = MaterialTheme.colorScheme.primary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Button(
                        onClick = { saveFormChanges() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("save_edit_bottom_btn"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("बदलाव सहेजें (Save)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        val form = formState
        if (form == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val scrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "वेबसाइट फॉर्म के अनुसार सभी १८ प्रश्नों में बदलाव करके 'बदलाव सहेजें' बटन दबाएं।",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onPrimaryContainer),
                            modifier = Modifier.padding(12.dp)
                        )
                    }

                    // Q1: Sangh Name
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१", title = "श्री संघ का नाम *")
                            OutlinedTextField(
                                value = sanghName,
                                onValueChange = { sanghName = it },
                                label = { Text("श्री संघ का नाम दर्ज करें") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_sangh_name")
                            )
                        }
                    }

                    // Q2: Address
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "२", title = "श्री संघ का पूरा पता *")
                            OutlinedTextField(
                                value = sanghAddress,
                                onValueChange = { sanghAddress = it },
                                label = { Text("श्री संघ का पूरा पता दर्ज करें") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("edit_sangh_address")
                            )
                        }
                    }

                    // Q3: City Name
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "३", title = "आपके शहर/गांव का नाम *")
                            OutlinedTextField(
                                value = cityName,
                                onValueChange = { cityName = it },
                                label = { Text("शहर / गांव का नाम दर्ज करें") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_city_name")
                            )
                        }
                    }

                    // Q3.1: State Selection
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "३.१", title = "राज्य चुनें (Select State) *")
                            StateDropdownSelector(
                                selectedState = stateName,
                                onStateSelected = { stateName = it },
                                modifier = Modifier.testTag("edit_state_dropdown")
                            )
                        }
                    }

                    // Q4: Contact Person 1
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "४", title = "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद (१) *")
                            OutlinedTextField(
                                value = contact1,
                                onValueChange = { contact1 = it },
                                label = { Text("नाम एवं पद दर्ज करें") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_contact1")
                            )
                        }
                    }

                    // Q5: Contact Person 2 (WhatsApp Number)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "५", title = "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका WhatsApp न. *")
                            OutlinedTextField(
                                value = contact2,
                                onValueChange = { contact2 = it },
                                label = { Text("10 अंकीय WhatsApp नंबर दर्ज करें") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_contact2")
                            )
                        }
                    }

                    // Q6: Mulnayak Bhagwan
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "६", title = "आपके संघ में मुलनायक भगवान कौन से हें? *")
                            OutlinedTextField(
                                value = mulnayakBhagwan,
                                onValueChange = { mulnayakBhagwan = it },
                                label = { Text("जैसे: श्री आदिनाथ भगवान") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_mulnayak")
                            )
                        }
                    }

                    // Q7: Total Families
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "७", title = "आपके संघ में कितने परिवार है? *")
                            OutlinedTextField(
                                value = totalFamilies,
                                onValueChange = { totalFamilies = it },
                                label = { Text("परिवारों की संख्या दर्ज करें") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth().testTag("edit_families")
                            )
                        }
                    }

                    // Q8: Other Sangh Present
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "८", title = "क्या आपके गांव/कॉलोनी में कोई अन्य संघ है? *")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasOtherSangh.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasOtherSangh = it }
                            )
                        }
                    }

                    // Q9: Gacch List (Exact HTML options: तपागच्छ, खतरगच्छ, अचलगच्छ, स्थानक, अन्य)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "९", title = "आपके संघ में कौन-कौन से गच्छ हैं? (कम से कम एक चुनें) *")
                            val webGacchOptions = listOf("तपागच्छ", "खतरगच्छ", "अचलगच्छ", "स्थानक", "अन्य")
                            val selectedGacchs = webGacchOptions.filter { option ->
                                gacchList.split(",").map { it.trim() }.any { it.startsWith(option, ignoreCase = true) }
                            }

                            CheckboxOptionList(
                                allOptions = webGacchOptions,
                                selectedList = selectedGacchs,
                                onToggle = { option ->
                                    val currentItems = gacchList.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.startsWith(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    gacchList = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = gacchList,
                                onValueChange = { gacchList = it },
                                label = { Text("गच्छ सूची / अन्य विवरण") },
                                singleLine = false,
                                maxLines = 3,
                                modifier = Modifier.fillMaxWidth().testTag("edit_gacch")
                            )
                        }
                    }

                    // Q10: Pratikraman Tradition (Exact HTML options: तपागच्छ, खतरगच्छ, अचलगच्छ, स्थानक)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१०", title = "आपके संघ में कौनसी परंपरा से प्रतिकमण किया जाता हैं? (कम से कम एक चुनें) *")
                            val webTraditionOptions = listOf("तपागच्छ", "खतरगच्छ", "अचलगच्छ", "स्थानक")
                            val selectedTraditions = webTraditionOptions.filter { option ->
                                pratikramanTradition.split(",").map { it.trim() }.any { it.equals(option, ignoreCase = true) }
                            }

                            CheckboxOptionList(
                                allOptions = webTraditionOptions,
                                selectedList = selectedTraditions,
                                onToggle = { option ->
                                    val currentItems = pratikramanTradition.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.equals(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    pratikramanTradition = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pratikramanTradition,
                                onValueChange = { pratikramanTradition = it },
                                label = { Text("प्रतिकमण परंपरा विवरण") },
                                singleLine = false,
                                maxLines = 3,
                                modifier = Modifier.fillMaxWidth().testTag("edit_tradition")
                            )
                        }
                    }

                    // Q11: Musician Group
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "११", title = "आपके श्रीसंघ में कोई संगीतकार/मंडल हैं? *")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasMusicianGroup.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasMusicianGroup = it }
                            )
                        }
                    }

                    // Q12: Call Outside Musician
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१२", title = "क्या आप बाहर से संगीतकार बुलाते हों? *")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (callsOutsideMusician.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { callsOutsideMusician = it }
                            )
                        }
                    }

                    // Q13: Panch Pratikraman Person
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१३", title = "आपके श्रीसंघ में ऐसा कोई व्यक्ति है जिसको पंच प्रतिकमण आता हो और वह पर्यूषण पर्व में हाजिर हो? *")
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasPanchPratikramanPerson.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasPanchPratikramanPerson = it }
                            )
                        }
                    }

                    // Q14: Toilet Facility
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१४", title = "क्या आपके श्रीसंघ मैं मातृ-ठल्ले (Toilet) की व्यवस्था हैं? *")
                            Text(
                                text = "(पौषध की क्रिया करने के लिए मात्रू-ठल्ले की व्यवस्था होना आवश्यक है)",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.primary),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            RadioOptionGroup(
                                options = listOf("हाँ", "नहीं"),
                                selectedOption = if (hasToiletFacility.trim() == "हाँ") "हाँ" else "नहीं",
                                onOptionSelected = { hasToiletFacility = it }
                            )
                        }
                    }

                    // Q15: Available Aradhana Material (Exact HTML options)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१५", title = "आपके श्रीसंघ में यह आराधना सामग्री होने पर ✔️ लगाइए (कम से कम एक चुनें) *")
                            val webSamagriOptions = listOf(
                                "आचार्य भगवान (स्थापना जी पुरुषों के लिए)",
                                "आचार्य भगवान (स्थापना जी महिलाओं के लिए)",
                                "कल्पसूत्र",
                                "बारसासूत्र",
                                "पौषध सामग्री (दण्डासन, सुपडी, मातृ-ठल्ले की कुंडी)"
                            )
                            val selectedSamagris = webSamagriOptions.filter { option ->
                                aradhanaSamagriList.split(",").map { it.trim() }.any { it.equals(option, ignoreCase = true) }
                            }

                            CheckboxOptionList(
                                allOptions = webSamagriOptions,
                                selectedList = selectedSamagris,
                                onToggle = { option ->
                                    val currentItems = aradhanaSamagriList.split(",").map { it.trim() }.filter { it.isNotBlank() }.toMutableList()
                                    val existingIndex = currentItems.indexOfFirst { it.equals(option, ignoreCase = true) }
                                    if (existingIndex >= 0) {
                                        currentItems.removeAt(existingIndex)
                                    } else {
                                        currentItems.add(option)
                                    }
                                    aradhanaSamagriList = currentItems.joinToString(", ")
                                }
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = aradhanaSamagriList,
                                onValueChange = { aradhanaSamagriList = it },
                                label = { Text("सामग्री सूची / विवरण") },
                                minLines = 2,
                                maxLines = 4,
                                modifier = Modifier.fillMaxWidth().testTag("edit_samagri")
                            )
                        }
                    }

                    // Q16: Activity Attendance Counts (Exact HTML options: 1-10, 11-25, 26-50, 50-100+)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            QuestionHeader(number = "१६", title = "पर्यूषण दौरान श्री संघ की प्रवृत्तियों में हाजिर व्यक्तियों की संख्या? *")

                            ActivityAttendanceGridSelector(
                                activityName = "• राई प्रतिक्रमण *",
                                selectedCount = countRaiPratikraman,
                                onSelectCount = { countRaiPratikraman = it }
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "• देवसी प्रतिक्रमण *",
                                selectedCount = countDevasiPratikraman,
                                onSelectCount = { countDevasiPratikraman = it }
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "• प्रवचन *",
                                selectedCount = countPravachan,
                                onSelectCount = { countPravachan = it }
                            )

                            ActivityAttendanceGridSelector(
                                activityName = "• संध्या भक्ति *",
                                selectedCount = countSandhyaBhakti,
                                onSelectCount = { countSandhyaBhakti = it }
                            )
                        }
                    }

                    // Q17: Main 3 Trustees
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१७", title = "श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर *")
                            OutlinedTextField(
                                value = mainTrustees,
                                onValueChange = { mainTrustees = it },
                                label = { Text("१. नाम एवं मोबाइल नंबर\n२. नाम एवं मोबाइल नंबर\n३. नाम एवं मोबाइल नंबर") },
                                minLines = 3,
                                maxLines = 5,
                                modifier = Modifier.fillMaxWidth().testTag("edit_trustees")
                            )
                        }
                    }

                    // Q18: Consent Checkboxes (Exact HTML Statements)
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            QuestionHeader(number = "१८", title = "सर्व अग्रणियों की सम्मति *")

                            Row(
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { ruleConsent1 = !ruleConsent1 }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = ruleConsent1,
                                    onCheckedChange = { ruleConsent1 = it },
                                    modifier = Modifier.testTag("edit_consent1_checkbox")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "आपके श्रीसंघ के तमाम अग्रणी की सर्वसम्मति से ही आप स्वाध्याई भाइयों को आराधना करवाने के लिए बुला रहे हैं।",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(
                                verticalAlignment = Alignment.Top,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { ruleConsent2 = !ruleConsent2 }
                                    .padding(vertical = 4.dp)
                            ) {
                                Checkbox(
                                    checked = ruleConsent2,
                                    onCheckedChange = { ruleConsent2 = it },
                                    modifier = Modifier.testTag("edit_consent2_checkbox")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "निर्धारित किए हुए सारे नियम समस्त अग्रणियों को स्वीकार है।",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
