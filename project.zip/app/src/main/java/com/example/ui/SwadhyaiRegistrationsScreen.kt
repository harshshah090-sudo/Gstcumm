package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.SwadhyaiFormEntity
import com.example.data.toShareableText

import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

data class SwadhyaiFilterField(
    val key: String,
    val label: String,
    val getValue: (SwadhyaiFormEntity) -> String
)

val swadhyaiFilterFields = listOf(
    SwadhyaiFilterField("fatherName", "Father's Name") { it.fatherName },
    SwadhyaiFilterField("motherName", "Mother's Name") { it.motherName },
    SwadhyaiFilterField("gender", "Gender") { it.gender },
    SwadhyaiFilterField("dob", "Date of Birth") { it.dob },
    SwadhyaiFilterField("bloodGroup", "Blood Group") { it.bloodGroup },
    SwadhyaiFilterField("maritalStatus", "Marital Status") { if (it.anniversaryDate.isNotBlank()) "${it.maritalStatus} (${it.anniversaryDate})" else it.maritalStatus },
    SwadhyaiFilterField("email", "Email ID") { it.email },
    SwadhyaiFilterField("whatsappNo", "WhatsApp No.") { it.whatsappNo },
    SwadhyaiFilterField("contactNo", "Contact No.") { it.contactNo },
    SwadhyaiFilterField("emergencyContact", "Emergency Contact") { listOf(it.emergencyContactName, it.emergencyContactRelation, it.emergencyContactNo).filter { str -> str.isNotBlank() }.joinToString(" - ") },
    SwadhyaiFilterField("address", "Address") { if (it.pincode.isNotBlank()) "${it.address} - ${it.pincode}" else it.address },
    SwadhyaiFilterField("nativePlace", "Native Place") { it.nativePlace },
    SwadhyaiFilterField("education", "Education") { it.education },
    SwadhyaiFilterField("workingStatus", "Profession") { if (it.workDescription.isNotBlank()) "${it.workingStatus} (${it.workDescription})" else it.workingStatus },
    SwadhyaiFilterField("joiningYear", "Joining Year") { if (it.joiningYear > 0) "${it.joiningYear}" else "" },
    SwadhyaiFilterField("specialities", "Specialities") { it.specialities },
    SwadhyaiFilterField("religiousLearnings", "Religious Learnings") { it.religiousLearnings },
    SwadhyaiFilterField("dailyRoutineActivities", "Daily Routine Activities") { it.dailyRoutineActivities },
    SwadhyaiFilterField("lifetimeTapasya", "Lifetime Tapasya") { it.lifetimeTapasya },
    SwadhyaiFilterField("anotherGroup", "Another Group / Post") { if (it.postInGroup.isNotBlank()) "${it.anotherGroup} (${it.postInGroup})" else it.anotherGroup },
    SwadhyaiFilterField("paryushanCount", "Paryushan Count") { if (it.paryushanCount > 0) "${it.paryushanCount} times" else "" },
    SwadhyaiFilterField("paryushanWillingness", "Paryushan Service") { it.paryushanWillingness },
    SwadhyaiFilterField("remarks", "Remarks") { it.remarks }
)

@Composable
private fun SwadhyaiBadgeNumber(number: String) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
        )
    }
}

@Composable
private fun SectionHeaderBadge(title: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SwadhyaiQuestionAnswerCard(
    number: String,
    questionText: String,
    answerText: String,
    placeholderText: String = "Not specified",
    isHighlight: Boolean = false
) {
    val trimmed = answerText.trim()
    val isAnswered = trimmed.isNotBlank() && trimmed != "0"
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SwadhyaiBadgeNumber(number)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = questionText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Spacer(modifier = Modifier.height(2.dp))

            if (isAnswered) {
                Text(
                    text = trimmed,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            } else {
                Text(
                    text = placeholderText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiRegistrationsScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onOpenWebForm: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val swadhyaiForms by viewModel.filteredSwadhyaiForms.collectAsStateWithLifecycle()
    val searchQuery by viewModel.swadhyaiSearchQuery.collectAsStateWithLifecycle()

    var selectedSwadhyai by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }
    var swadhyaiToDelete by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }

    var showFilterDialog by remember { mutableStateOf(false) }
    var selectedFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var tempFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }

    val isFilterOrSearchActive = selectedFilterKeys.isNotEmpty() || searchQuery.isNotEmpty()

    fun handleBackPress() {
        if (isFilterOrSearchActive) {
            selectedFilterKeys = emptySet()
            viewModel.swadhyaiSearchQuery.value = ""
        } else {
            onNavigateBack()
        }
    }

    BackHandler(enabled = isFilterOrSearchActive) {
        handleBackPress()
    }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    fun shareOnWhatsApp() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, viewModel.getSwadhyaiFormShareInviteText())
            type = "text/plain"
            setPackage("com.whatsapp")
        }
        try {
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            val chooserIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, viewModel.getSwadhyaiFormShareInviteText())
            }
            context.startActivity(Intent.createChooser(chooserIntent, "Share Swadhyai Registration Link"))
        }
    }

    if (swadhyaiToDelete != null) {
        val target = swadhyaiToDelete!!
        AlertDialog(
            onDismissRequest = { swadhyaiToDelete = null },
            title = { Text("Delete Swadhyai Registration") },
            text = { Text("Are you sure you want to delete registration of \"${target.fullName}\"?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteSwadhyaiForm(target.id)
                        Toast.makeText(context, "Registration deleted", Toast.LENGTH_SHORT).show()
                        swadhyaiToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { swadhyaiToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Filter Questions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    TextButton(onClick = { tempFilterKeys = if (tempFilterKeys.size == swadhyaiFilterFields.size) emptySet() else swadhyaiFilterFields.map { it.key }.toSet() }) {
                        Text(if (tempFilterKeys.size == swadhyaiFilterFields.size) "Clear All" else "Select All", fontSize = 12.sp)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Select questions to display on registration cards:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    swadhyaiFilterFields.forEach { field ->
                        val isChecked = tempFilterKeys.contains(field.key)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    tempFilterKeys = if (isChecked) {
                                        tempFilterKeys - field.key
                                    } else {
                                        tempFilterKeys + field.key
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    tempFilterKeys = if (it == true) {
                                        tempFilterKeys + field.key
                                    } else {
                                        tempFilterKeys - field.key
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = field.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedFilterKeys = tempFilterKeys
                        showFilterDialog = false
                    }
                ) {
                    Text("Apply Filter")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFilterDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (selectedSwadhyai != null) {
        val s = selectedSwadhyai!!
        Dialog(
            onDismissRequest = { selectedSwadhyai = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.92f)
                    .padding(4.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = s.fullName.ifBlank { "Swadhyai Details" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val cityStateText = formatCityAndState(s.city, s.state)
                            if (cityStateText.isNotBlank()) {
                                Text(
                                    text = "City: $cityStateText",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(onClick = { selectedSwadhyai = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                    // Questions & Answers scrollable list
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Step 1: Rules & Regulations
                        SectionHeaderBadge("Step 1: Rules & Regulations")
                        SwadhyaiQuestionAnswerCard("1", "Rules & Regulations Accepted", if (s.acceptedRules) "Yes (Agreed to all rules)" else "Yes")
                        SwadhyaiQuestionAnswerCard("2", "WhatsApp Number", s.whatsappNo)

                        // Step 2: Personal Details
                        SectionHeaderBadge("Step 2: Personal Details")
                        SwadhyaiQuestionAnswerCard("3", "1. Full Name", s.fullName, isHighlight = true)
                        SwadhyaiQuestionAnswerCard("4", "2. Father's Name", s.fatherName)
                        SwadhyaiQuestionAnswerCard("5", "3. Mother's Name", s.motherName)
                        SwadhyaiQuestionAnswerCard("6", "4. Date of Birth", s.dob)
                        SwadhyaiQuestionAnswerCard("7", "5. Age", if (s.age > 0) "${s.age} yrs" else "")
                        SwadhyaiQuestionAnswerCard("8", "6. Blood Group", s.bloodGroup)
                        SwadhyaiQuestionAnswerCard("9", "7. Marital Status", s.maritalStatus)
                        SwadhyaiQuestionAnswerCard("10", "8. Date of Anniversary", s.anniversaryDate, placeholderText = "Not Applicable")
                        SwadhyaiQuestionAnswerCard("11", "9. Educational Qualification", s.education)
                        SwadhyaiQuestionAnswerCard("12", "10. Your Profession", s.workingStatus)
                        SwadhyaiQuestionAnswerCard("13", "11. Work Description / Details", s.workDescription)

                        // Step 3: Contact Details
                        SectionHeaderBadge("Step 3: Contact Details")
                        SwadhyaiQuestionAnswerCard("14", "12. Registered WhatsApp Number", s.whatsappNo)
                        SwadhyaiQuestionAnswerCard("15", "13. Contact No. (Optional)", s.contactNo)
                        SwadhyaiQuestionAnswerCard("16", "14. Email ID", s.email)
                        SwadhyaiQuestionAnswerCard("17", "15. Emergency Contact Name", s.emergencyContactName)
                        SwadhyaiQuestionAnswerCard("18", "16. Emergency Contact Relation", s.emergencyContactRelation)
                        SwadhyaiQuestionAnswerCard("19", "17. Emergency Contact Mobile Number", s.emergencyContactNo)
                        SwadhyaiQuestionAnswerCard("20", "18. Full Address", s.address)
                        SwadhyaiQuestionAnswerCard("21", "19. State", s.state)
                        SwadhyaiQuestionAnswerCard("22", "20. City", formatCityAndState(s.city, s.state))
                        SwadhyaiQuestionAnswerCard("23", "21. Pin Code", s.pincode)
                        if (s.nativePlace.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("24", "Native Place", s.nativePlace)
                        }

                        // Step 4: Religious Details
                        SectionHeaderBadge("Step 4: Religious Details")
                        SwadhyaiQuestionAnswerCard("25", "22. Religious Learning", s.religiousLearnings)
                        SwadhyaiQuestionAnswerCard("26", "23. Speciality", s.specialities)
                        SwadhyaiQuestionAnswerCard("27", "24. In which Year you Joined the Vardhman Mandal?", if (s.joiningYear > 0) "${s.joiningYear}" else "")
                        SwadhyaiQuestionAnswerCard("28", "25. How many times you went for Paryushan Aaradhna from Vardhman Mandal?", if (s.paryushanCount > 0) "${s.paryushanCount} times" else "0")
                        SwadhyaiQuestionAnswerCard("29", "26. Another Religious Group (if any)", s.anotherGroup, placeholderText = "None")
                        SwadhyaiQuestionAnswerCard("30", "27. Any special post in any kind of group or sanstha!", s.postInGroup, placeholderText = "None")
                        SwadhyaiQuestionAnswerCard("31", "28. Daily routine religious activity", s.dailyRoutineActivities)
                        SwadhyaiQuestionAnswerCard("32", "29. Any religious tapasya or tyag you did for lifetime", s.lifetimeTapasya)

                        if (s.paryushanWillingness.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("33", "Paryushan Service Willingness", s.paryushanWillingness)
                        }
                        if (s.remarks.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("34", "Remarks / Additional Notes", s.remarks)
                        }

                        SectionHeaderBadge("Registration Metadata")
                        val regDateStr = if (s.createdAt > 0) java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(s.createdAt)) else ""
                        SwadhyaiQuestionAnswerCard("35", "Registration Date & Time", regDateStr)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Bottom Buttons Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { selectedSwadhyai = null }) {
                            Text("Close")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, s.toShareableText())
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Swadhyai Details"))
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Details")
                        }
                    }
                }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Swadhyai Registrations",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Details of Registered Swadhyai Bhai",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { handleBackPress() },
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Go Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 3.dp,
                        shadowElevation = 1.dp,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            AnimatedContent(
                                targetState = swadhyaiForms.size,
                                label = "swadhyai_count_anim"
                            ) { count ->
                                Text(
                                    text = "$count",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { shareOnWhatsApp() },
                shape = CircleShape,
                containerColor = Color(0xFF25D366),
                contentColor = Color.White,
                modifier = Modifier.testTag("share_swadhyai_whatsapp_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share Link",
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Search & Filter Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val searchInteractionSource = remember { MutableInteractionSource() }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.swadhyaiSearchQuery.value = it },
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("swadhyai_search_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        singleLine = true,
                        interactionSource = searchInteractionSource,
                        decorationBox = @Composable { innerTextField ->
                            OutlinedTextFieldDefaults.DecorationBox(
                                value = searchQuery,
                                innerTextField = innerTextField,
                                enabled = true,
                                singleLine = true,
                                visualTransformation = VisualTransformation.None,
                                interactionSource = searchInteractionSource,
                                placeholder = { Text("Search Name and Cities", fontSize = 13.sp) },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { viewModel.swadhyaiSearchQuery.value = "" },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                container = {
                                    OutlinedTextFieldDefaults.ContainerBox(
                                        enabled = true,
                                        isError = false,
                                        interactionSource = searchInteractionSource,
                                        colors = OutlinedTextFieldDefaults.colors(),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            )
                        }
                    )

                    Surface(
                        onClick = {
                            tempFilterKeys = selectedFilterKeys
                            showFilterDialog = true
                        },
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("swadhyai_filter_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter",
                                modifier = Modifier.size(18.dp),
                                tint = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Filter (${selectedFilterKeys.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 3. Registration List or Empty State
            if (swadhyaiForms.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "No registrations found" else "No matching results",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            } else {
                items(
                    items = swadhyaiForms,
                    key = { it.id }
                ) { item ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SwadhyaiItemCard(
                            swadhyai = item,
                            selectedFilterKeys = selectedFilterKeys,
                            onClick = { selectedSwadhyai = item },
                            onDeleteClick = { swadhyaiToDelete = item }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SwadhyaiItemCard(
    swadhyai: SwadhyaiFormEntity,
    selectedFilterKeys: Set<String>,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cityText = remember(swadhyai.city, swadhyai.state) {
        formatCityAndState(swadhyai.city, swadhyai.state)
    }

    fun openMapForCity() {
        if (cityText.isBlank()) return
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(cityText)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(cityText)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("swadhyai_card_${swadhyai.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive City / State GPS Tag
                if (cityText.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { openMapForCity() }
                            .testTag("swadhyai_city_tag_${swadhyai.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Maps",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = cityText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Details",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Name - Age
            val displayName = swadhyai.fullName.ifBlank { "Swadhyai Registrant" }
            val ageText = if (swadhyai.age > 0) " - ${swadhyai.age} yrs" else ""
            Text(
                text = "$displayName$ageText",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Dynamic filter fields selected by user
            val activeFilterItems = remember(selectedFilterKeys, swadhyai) {
                selectedFilterKeys.mapNotNull { key ->
                    val field = swadhyaiFilterFields.find { it.key == key }
                    if (field != null) {
                        val valStr = field.getValue(swadhyai)
                        if (valStr.isNotBlank()) field.label to valStr else null
                    } else null
                }
            }

            if (activeFilterItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                if (activeFilterItems.size == 1) {
                    val (label, value) = activeFilterItems.first()
                    Text(
                        text = "$label: $value",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                } else {
                    val leftItems = activeFilterItems.filterIndexed { index, _ -> index % 2 == 0 }
                    val rightItems = activeFilterItems.filterIndexed { index, _ -> index % 2 != 0 }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            leftItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 2.dp),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            rightItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
