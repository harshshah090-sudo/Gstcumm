package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.SwadhyaiFormEntity
import com.example.data.toShareableText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiRegistrationsScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onOpenWebForm: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val swadhyaiForms by viewModel.filteredSwadhyaiForms.collectAsStateWithLifecycle()
    val searchQuery by viewModel.swadhyaiSearchQuery.collectAsStateWithLifecycle()

    var selectedSwadhyai by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }
    var swadhyaiToDelete by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    if (swadhyaiToDelete != null) {
        val target = swadhyaiToDelete!!
        AlertDialog(
            onDismissRequest = { swadhyaiToDelete = null },
            title = { Text("स्वाध्यायी पंजीकरण हटाएं") },
            text = { Text("क्या आप \"${target.fullName}\" का पंजीकरण हटाना चाहते हैं?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteSwadhyaiForm(target.id)
                        Toast.makeText(context, "पंजीकरण हटा दिया गया है", Toast.LENGTH_SHORT).show()
                        swadhyaiToDelete = null
                    }
                ) {
                    Text("हटाएं", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { swadhyaiToDelete = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    if (selectedSwadhyai != null) {
        val s = selectedSwadhyai!!
        AlertDialog(
            onDismissRequest = { selectedSwadhyai = null },
            title = {
                Column {
                    Text(
                        text = s.fullName,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    if (s.city.isNotBlank()) {
                        Text(
                            text = "${s.city}${if (s.state.isNotBlank()) ", ${s.state}" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            text = {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    item {
                        DetailInfoRow("पिता का नाम", s.fatherName)
                        DetailInfoRow("माता का नाम", s.motherName)
                        DetailInfoRow("आयु / जन्मतिथि", "${if (s.age > 0) "${s.age} वर्ष" else ""} ${if (s.dob.isNotBlank()) "(${s.dob})" else ""}".trim())
                        DetailInfoRow("वैवाहिक स्थिति", "${s.maritalStatus} ${if (s.anniversaryDate.isNotBlank()) "(${s.anniversaryDate})" else ""}")
                        DetailInfoRow("रक्त समूह", s.bloodGroup)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        DetailInfoRow("WhatsApp नंबर", s.whatsappNo)
                        DetailInfoRow("संपर्क नंबर", s.contactNo)
                        DetailInfoRow("आपातकालीन नंबर", s.emergencyContactNo)
                        DetailInfoRow("पता", "${s.address} ${if (s.pincode.isNotBlank()) "(${s.pincode})" else ""}")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        DetailInfoRow("शिक्षा / योग्यता", s.education)
                        DetailInfoRow("व्यवसाय / कार्य", "${s.workingStatus} ${if (s.workDescription.isNotBlank()) "(${s.workDescription})" else ""}")
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        DetailInfoRow("मंडल जुड़ने का वर्ष", if (s.joiningYear > 0) "${s.joiningYear}" else "")
                        DetailInfoRow("विशेषता", s.specialities)
                        DetailInfoRow("धार्मिक ज्ञान", s.religiousLearnings)
                        DetailInfoRow("अन्य संघ / पद", "${s.anotherGroup} ${if (s.postInGroup.isNotBlank()) "(${s.postInGroup})" else ""}")
                        DetailInfoRow("पर्यूषण आराधना संख्या", if (s.paryushanCount > 0) "${s.paryushanCount} बार" else "")
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, s.toShareableText())
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "विवरण शेयर करें"))
                    }
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("शेयर करें")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedSwadhyai = null }) {
                    Text("बंद करें")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "स्वाध्यायी पंजीकरण अर्जियाँ",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "पंजीकृत स्वाध्यायी भाइयों का विवरण",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    IconButton(
                        onClick = {
                            viewModel.refreshCloudData()
                            Toast.makeText(context, "डेटा रिफ्रेश हो रहा है...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("refresh_swadhyai_forms_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "रिफ्रेश करें",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = {
                            val shareIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, viewModel.getSwadhyaiFormShareInviteText())
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "फॉर्म लिंक शेयर करें"))
                        },
                        modifier = Modifier.testTag("share_swadhyai_link_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = "फॉर्म लिंक शेयर करें",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                    IconButton(
                        onClick = onOpenWebForm,
                        modifier = Modifier.testTag("add_swadhyai_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "नया स्वाध्यायी पंजीकरण फॉर्म भरें",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onOpenWebForm,
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSecondary,
                modifier = Modifier.testTag("open_swadhyai_web_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.PersonAdd,
                    contentDescription = "नया पंजीकरण फॉर्म खोलें"
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Hero Banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.secondaryContainer,
                                    MaterialTheme.colorScheme.primaryContainer
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "श्री वर्द्धमान स्वाध्याय संघ",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = MaterialTheme.colorScheme.secondary
                            ) {
                                Text(
                                    text = "${swadhyaiForms.size} स्वाध्यायी",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    ),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "स्वाध्यायी भाइयों के पंजीकरण एवं धार्मिक आराधना का एकीकृत पोर्टल।",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.85f)
                            )
                        )
                    }
                }
            }

            // 2. Search Filter
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.swadhyaiSearchQuery.value = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                        .testTag("swadhyai_search_input"),
                    placeholder = { Text("नाम, शहर या फ़ोन नंबर खोजें...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "खोजें") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.swadhyaiSearchQuery.value = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "साफ करें")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
            }

            // 3. Section Header
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "प्राप्त स्वामी पंजीकरण (${swadhyaiForms.size})",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                    Text(
                        text = "टैप करके विवरण देखें",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
            }

            // 4. Registration List or Empty State
            if (swadhyaiForms.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "अभी तक कोई स्वाध्यायी पंजीकरण जमा नहीं हुआ है" else "कोई परिणाम नहीं मिला",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "नया स्वाध्यायी फॉर्म भरने के लिए ऊपर + बटन पर क्लिक करें या नीचे शेयर बटन से लिंक भेजें।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onOpenWebForm,
                                shape = RoundedCornerShape(20.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("वेब फॉर्म खोलें")
                            }
                        }
                    }
                }
            } else {
                items(
                    items = swadhyaiForms,
                    key = { it.id }
                ) { item ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SwadhyaiItemCard(
                            swadhyai = item,
                            onClick = { selectedSwadhyai = item },
                            onDeleteClick = { swadhyaiToDelete = item }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DetailInfoRow(label: String, value: String) {
    if (value.isNotBlank()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                ),
                modifier = Modifier.weight(1f)
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.weight(1.3f)
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwadhyaiItemCard(
    swadhyai: SwadhyaiFormEntity,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cityText = remember(swadhyai.city, swadhyai.state) {
        val baseCity = convertHindiToEnglishCity(swadhyai.city)
        if (swadhyai.state.isNotBlank() && !baseCity.contains(swadhyai.state, ignoreCase = true)) {
            "$baseCity, ${swadhyai.state}"
        } else {
            baseCity
        }
    }

    fun openMapForCity() {
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(cityText)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(cityText)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    fun makeCall(phone: String) {
        if (phone.isBlank()) return
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "कॉल करने में असमर्थ", Toast.LENGTH_SHORT).show()
        }
    }

    fun openWhatsApp(phone: String) {
        if (phone.isBlank()) return
        val cleanPhone = phone.replace(Regex("[^0-9]"), "")
        val formatted = if (cleanPhone.length == 10) "91$cleanPhone" else cleanPhone
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$formatted"))
        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "WhatsApp खोलने में असमर्थ", Toast.LENGTH_SHORT).show()
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag("swadhyai_card_${swadhyai.id}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive GPS Tag for City
                if (swadhyai.city.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { openMapForCity() }
                            .testTag("swadhyai_city_tag_${swadhyai.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Maps",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = cityText,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onDeleteClick,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteOutline,
                            contentDescription = "हटाएं",
                            tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "विवरण देखें",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Swadhyai Name & Father Name
            Text(
                text = swadhyai.fullName.ifBlank { "स्वाध्यायी भाई" },
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            if (swadhyai.fatherName.isNotBlank()) {
                Text(
                    text = "आत्मज: ${swadhyai.fatherName}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Quick Info Tags
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (swadhyai.age > 0) {
                    AssistChip(
                        onClick = {},
                        label = { Text("${swadhyai.age} वर्ष") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }
                if (swadhyai.workingStatus.isNotBlank()) {
                    AssistChip(
                        onClick = {},
                        label = { Text(swadhyai.workingStatus) },
                        leadingIcon = { Icon(Icons.Default.Work, contentDescription = null, modifier = Modifier.size(14.dp)) }
                    )
                }
            }

            // Quick Contact Buttons Row
            val primaryPhone = swadhyai.whatsappNo.ifBlank { swadhyai.contactNo }
            if (primaryPhone.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📱 $primaryPhone",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { openWhatsApp(primaryPhone) },
                            modifier = Modifier
                                .size(36.dp)
                                .background(Color(0xFF25D366), CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Chat,
                                contentDescription = "WhatsApp",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { makeCall(primaryPhone) },
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Call",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
