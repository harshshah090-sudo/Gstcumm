package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.data.toShareableText

import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

data class SwadhyaiFilterField(
    val key: String,
    val label: String,
    val getValue: (SwadhyaiFormEntity) -> String
)

val swadhyaiFilterFields = listOf(
    SwadhyaiFilterField("fatherName", "Father's Name") { it.fatherName },
    SwadhyaiFilterField("motherName", "Mother's Name") { it.motherName },
    SwadhyaiFilterField("gender", "Gender") { it.gender },
    SwadhyaiFilterField("dob", "Date of Birth") { it.dob },
    SwadhyaiFilterField("bloodGroup", "Blood Group") { it.bloodGroup },
    SwadhyaiFilterField("maritalStatus", "Marital Status") { if (it.anniversaryDate.isNotBlank()) "${it.maritalStatus} (${it.anniversaryDate})" else it.maritalStatus },
    SwadhyaiFilterField("email", "Email ID") { it.email },
    SwadhyaiFilterField("whatsappNo", "WhatsApp No.") { it.whatsappNo },
    SwadhyaiFilterField("contactNo", "Contact No.") { it.contactNo },
    SwadhyaiFilterField("emergencyContact", "Emergency Contact") { listOf(it.emergencyContactName, it.emergencyContactRelation, it.emergencyContactNo).filter { str -> str.isNotBlank() }.joinToString(" - ") },
    SwadhyaiFilterField("address", "Address") { if (it.pincode.isNotBlank()) "${it.address} - ${it.pincode}" else it.address },
    SwadhyaiFilterField("nativePlace", "Native Place") { it.nativePlace },
    SwadhyaiFilterField("education", "Education") { it.education },
    SwadhyaiFilterField("workingStatus", "Profession") { if (it.workDescription.isNotBlank()) "${it.workingStatus} (${it.workDescription})" else it.workingStatus },
    SwadhyaiFilterField("joiningYear", "Joining Year") { if (it.joiningYear > 0) "${it.joiningYear}" else "" },
    SwadhyaiFilterField("specialities", "Specialities") { it.specialities },
    SwadhyaiFilterField("religiousLearnings", "Religious Learnings") { it.religiousLearnings },
    SwadhyaiFilterField("dailyRoutineActivities", "Daily Routine Activities") { it.dailyRoutineActivities },
    SwadhyaiFilterField("lifetimeTapasya", "Lifetime Tapasya") { it.lifetimeTapasya },
    SwadhyaiFilterField("anotherGroup", "Another Group / Post") { if (it.postInGroup.isNotBlank()) "${it.anotherGroup} (${it.postInGroup})" else it.anotherGroup },
    SwadhyaiFilterField("paryushanCount", "Paryushan Count") { if (it.paryushanCount > 0) "${it.paryushanCount} times" else "" },
    SwadhyaiFilterField("paryushanWillingness", "Paryushan Service") { it.paryushanWillingness },
    SwadhyaiFilterField("remarks", "Remarks") { it.remarks }
)

@Composable
private fun SwadhyaiBadgeNumber(number: String) {
    Surface(
        shape = RoundedCornerShape(4.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 1.dp)
        )
    }
}

@Composable
private fun SectionHeaderBadge(title: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.secondaryContainer,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium.copy(
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSecondaryContainer
            ),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
private fun SwadhyaiQuestionAnswerCard(
    number: String,
    questionText: String,
    answerText: String,
    placeholderText: String = "Not specified",
    isHighlight: Boolean = false
) {
    val trimmed = answerText.trim()
    val isAnswered = trimmed.isNotBlank() && trimmed != "0"
    Card(
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = questionText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Spacer(modifier = Modifier.height(2.dp))

            if (isAnswered) {
                Text(
                    text = trimmed,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            } else {
                Text(
                    text = placeholderText,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Normal,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SwadhyaiRegistrationsScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onOpenWebForm: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val swadhyaiForms by viewModel.filteredSwadhyaiForms.collectAsStateWithLifecycle()
    val searchQuery by viewModel.swadhyaiSearchQuery.collectAsStateWithLifecycle()

    val haptic = LocalHapticFeedback.current
    var selectedSwadhyai by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }
    var editingSwadhyai by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }
    var swadhyaiToDelete by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }
    var selectedSwadhyaiForActions by remember { mutableStateOf<SwadhyaiFormEntity?>(null) }

    var showFilterDialog by remember { mutableStateOf(false) }
    var selectedFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var tempFilterKeys by remember { mutableStateOf<Set<String>>(emptySet()) }

    val isFilterOrSearchActive = selectedFilterKeys.isNotEmpty() || searchQuery.isNotEmpty()

    fun handleBackPress() {
        if (isFilterOrSearchActive) {
            selectedFilterKeys = emptySet()
            viewModel.swadhyaiSearchQuery.value = ""
        } else {
            onNavigateBack()
        }
    }

    BackHandler(enabled = isFilterOrSearchActive) {
        handleBackPress()
    }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    fun shareOnWhatsApp() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, viewModel.getSwadhyaiFormShareInviteText())
            type = "text/plain"
            setPackage("com.whatsapp")
        }
        try {
            context.startActivity(shareIntent)
        } catch (e: Exception) {
            val chooserIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, viewModel.getSwadhyaiFormShareInviteText())
            }
            context.startActivity(Intent.createChooser(chooserIntent, "Share Swadhyai Registration Link"))
        }
    }

    if (selectedSwadhyaiForActions != null) {
        val targetSwadhyai = selectedSwadhyaiForActions!!
        SwadhyaiActionDialog(
            swadhyai = targetSwadhyai,
            selectedFilterKeys = selectedFilterKeys,
            onDismiss = { selectedSwadhyaiForActions = null },
            onEditSwadhyai = {
                selectedSwadhyaiForActions = null
                editingSwadhyai = targetSwadhyai
            },
            onDeleteSwadhyai = {
                selectedSwadhyaiForActions = null
                swadhyaiToDelete = targetSwadhyai
            }
        )
    }

    if (editingSwadhyai != null) {
        val targetToEdit = editingSwadhyai!!
        EditSwadhyaiDialog(
            swadhyai = targetToEdit,
            onDismiss = { editingSwadhyai = null },
            onSave = { updated ->
                viewModel.updateSwadhyaiForm(updated) {
                    Toast.makeText(context, "Swadhyai details updated successfully", Toast.LENGTH_SHORT).show()
                }
                editingSwadhyai = null
                if (selectedSwadhyai?.id == updated.id) {
                    selectedSwadhyai = updated
                }
            }
        )
    }

    if (swadhyaiToDelete != null) {
        val target = swadhyaiToDelete!!
        AlertDialog(
            onDismissRequest = { swadhyaiToDelete = null },
            title = { Text("Move to Recycle Bin") },
            text = { Text("Are you sure you want to move the registration for \"${target.fullName}\" to Recycle Bin?\n\nIt can be restored anytime or will be automatically deleted after 60 days.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteSwadhyaiForm(target.id)
                        Toast.makeText(context, "Moved to Recycle Bin (auto-deletes in 60 days)", Toast.LENGTH_SHORT).show()
                        swadhyaiToDelete = null
                        if (selectedSwadhyai?.id == target.id) {
                            selectedSwadhyai = null
                        }
                    }
                ) {
                    Text("Move to Recycle Bin", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { swadhyaiToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showFilterDialog) {
        AlertDialog(
            onDismissRequest = { showFilterDialog = false },
            title = {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Filter Questions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    TextButton(onClick = { tempFilterKeys = if (tempFilterKeys.size == swadhyaiFilterFields.size) emptySet() else swadhyaiFilterFields.map { it.key }.toSet() }) {
                        Text(if (tempFilterKeys.size == swadhyaiFilterFields.size) "Clear All" else "Select All", fontSize = 12.sp)
                    }
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 380.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Select questions to display on registration cards:",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    swadhyaiFilterFields.forEach { field ->
                        val isChecked = tempFilterKeys.contains(field.key)
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    tempFilterKeys = if (isChecked) {
                                        tempFilterKeys - field.key
                                    } else {
                                        tempFilterKeys + field.key
                                    }
                                }
                                .padding(vertical = 4.dp)
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = {
                                    tempFilterKeys = if (it == true) {
                                        tempFilterKeys + field.key
                                    } else {
                                        tempFilterKeys - field.key
                                    }
                                }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = field.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        selectedFilterKeys = tempFilterKeys
                        showFilterDialog = false
                    }
                ) {
                    Text("Apply Filter")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFilterDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (selectedSwadhyai != null) {
        val s = selectedSwadhyai!!
        Dialog(
            onDismissRequest = { selectedSwadhyai = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.96f)
                    .fillMaxHeight(0.92f)
                    .padding(4.dp),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    // Subtle transparent background watermark image
                    Image(
                        painter = painterResource(id = R.drawable.header_logo),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        alpha = 0.18f,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .fillMaxSize(0.65f)
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                    // Header Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = s.fullName.ifBlank { "Swadhyai Details" },
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            val cityStateText = formatCityAndState(s.city, s.state)
                            if (cityStateText.isNotBlank()) {
                                Text(
                                    text = "City: $cityStateText",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        IconButton(onClick = { selectedSwadhyai = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 2.dp))

                    // Questions & Answers scrollable list
                    Column(
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Step 1: Rules & Regulations
                        SectionHeaderBadge("Step 1: Rules & Regulations")
                        SwadhyaiQuestionAnswerCard("1", "Rules & Regulations Accepted", if (s.acceptedRules) "Yes (Agreed to all rules)" else "Yes")
                        SwadhyaiQuestionAnswerCard("2", "WhatsApp Number", s.whatsappNo)

                        // Step 2: Personal Details
                        SectionHeaderBadge("Step 2: Personal Details")
                        SwadhyaiQuestionAnswerCard("3", "1. Full Name", s.fullName, isHighlight = true)
                        SwadhyaiQuestionAnswerCard("4", "2. Father's Name", s.fatherName)
                        SwadhyaiQuestionAnswerCard("5", "3. Mother's Name", s.motherName)
                        SwadhyaiQuestionAnswerCard("6", "4. Date of Birth", s.dob)
                        SwadhyaiQuestionAnswerCard("7", "5. Age", if (s.age > 0) "${s.age} yrs" else "")
                        SwadhyaiQuestionAnswerCard("8", "6. Blood Group", s.bloodGroup)
                        SwadhyaiQuestionAnswerCard("9", "7. Marital Status", s.maritalStatus)
                        SwadhyaiQuestionAnswerCard("10", "8. Date of Anniversary", s.anniversaryDate, placeholderText = "Not Applicable")
                        SwadhyaiQuestionAnswerCard("11", "9. Educational Qualification", s.education)
                        SwadhyaiQuestionAnswerCard("12", "10. Your Profession", s.workingStatus)
                        SwadhyaiQuestionAnswerCard("13", "11. Work Description / Details", s.workDescription)

                        // Step 3: Contact Details
                        SectionHeaderBadge("Step 3: Contact Details")
                        SwadhyaiQuestionAnswerCard("14", "12. Registered WhatsApp Number", s.whatsappNo)
                        SwadhyaiQuestionAnswerCard("15", "13. Contact No. (Optional)", s.contactNo)
                        SwadhyaiQuestionAnswerCard("16", "14. Email ID", s.email)
                        SwadhyaiQuestionAnswerCard("17", "15. Emergency Contact Name", s.emergencyContactName)
                        SwadhyaiQuestionAnswerCard("18", "16. Emergency Contact Relation", s.emergencyContactRelation)
                        SwadhyaiQuestionAnswerCard("19", "17. Emergency Contact Mobile Number", s.emergencyContactNo)
                        SwadhyaiQuestionAnswerCard("20", "18. Full Address", s.address)
                        SwadhyaiQuestionAnswerCard("21", "19. State", s.state)
                        SwadhyaiQuestionAnswerCard("22", "20. City", formatCityAndState(s.city, s.state))
                        SwadhyaiQuestionAnswerCard("23", "21. Pin Code", s.pincode)
                        if (s.nativePlace.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("24", "Native Place", s.nativePlace)
                        }

                        // Step 4: Religious Details
                        SectionHeaderBadge("Step 4: Religious Details")
                        SwadhyaiQuestionAnswerCard("25", "22. Religious Learning", s.religiousLearnings)
                        SwadhyaiQuestionAnswerCard("26", "23. Speciality", s.specialities)
                        SwadhyaiQuestionAnswerCard("27", "24. In which Year you Joined the Vardhman Mandal?", if (s.joiningYear > 0) "${s.joiningYear}" else "")
                        SwadhyaiQuestionAnswerCard("28", "25. How many times you went for Paryushan Aaradhna from Vardhman Mandal?", if (s.paryushanCount > 0) "${s.paryushanCount} times" else "0")
                        if (s.paryushanHistoryLog.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("28A", "Allotted Sangh History (पर्यूषण आराधना संघ सूची)", s.paryushanHistoryLog)
                        }
                        SwadhyaiQuestionAnswerCard("29", "26. Another Religious Group (if any)", s.anotherGroup, placeholderText = "None")
                        SwadhyaiQuestionAnswerCard("30", "27. Any special post in any kind of group or sanstha!", s.postInGroup, placeholderText = "None")
                        SwadhyaiQuestionAnswerCard("31", "28. Daily routine religious activity", s.dailyRoutineActivities)
                        SwadhyaiQuestionAnswerCard("32", "29. Any religious tapasya or tyag you did for lifetime", s.lifetimeTapasya)

                        if (s.paryushanWillingness.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("33", "Paryushan Service Willingness", s.paryushanWillingness)
                        }
                        if (s.remarks.isNotBlank()) {
                            SwadhyaiQuestionAnswerCard("34", "Remarks / Additional Notes", s.remarks)
                        }

                        SectionHeaderBadge("Registration Metadata")
                        val regDateStr = if (s.createdAt > 0) java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(s.createdAt)) else ""
                        SwadhyaiQuestionAnswerCard("35", "Registration Date & Time", regDateStr)
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Bottom Buttons Bar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { selectedSwadhyai = null }) {
                            Text("Close")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = {
                                editingSwadhyai = s
                            }
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Edit Details")
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, s.toShareableText())
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "Share Swadhyai Details"))
                            }
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share Details")
                        }
                    }
                }
            }
        }
    }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "स्वाध्यायी पंजीकरण",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "Swadhyai Registrations • विवरण सूची",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        tonalElevation = 3.dp,
                        shadowElevation = 1.dp,
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            AnimatedContent(
                                targetState = swadhyaiForms.size,
                                label = "swadhyai_count_anim"
                            ) { count ->
                                Text(
                                    text = "$count",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 14.sp
                                    )
                                )
                            }
                        }
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { shareOnWhatsApp() },
                shape = CircleShape,
                containerColor = Color(0xFF25D366),
                contentColor = Color.White,
                modifier = Modifier
                    .padding(bottom = 72.dp)
                    .testTag("share_swadhyai_whatsapp_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share Link",
                    modifier = Modifier.size(24.dp)
                )
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Search & Filter Bar
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val searchInteractionSource = remember { MutableInteractionSource() }
                    BasicTextField(
                        value = searchQuery,
                        onValueChange = { viewModel.swadhyaiSearchQuery.value = it },
                        modifier = Modifier
                            .weight(1f)
                            .height(42.dp)
                            .testTag("swadhyai_search_input"),
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            fontSize = 13.5.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        singleLine = true,
                        interactionSource = searchInteractionSource,
                        decorationBox = @Composable { innerTextField ->
                            OutlinedTextFieldDefaults.DecorationBox(
                                value = searchQuery,
                                innerTextField = innerTextField,
                                enabled = true,
                                singleLine = true,
                                visualTransformation = VisualTransformation.None,
                                interactionSource = searchInteractionSource,
                                placeholder = {
                                    Text(
                                        text = "Search Name or City...",
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(
                                            onClick = { viewModel.swadhyaiSearchQuery.value = "" },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                        }
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                container = {
                                    OutlinedTextFieldDefaults.Container(
                                        enabled = true,
                                        isError = false,
                                        interactionSource = searchInteractionSource,
                                        colors = OutlinedTextFieldDefaults.colors(),
                                        shape = RoundedCornerShape(10.dp)
                                    )
                                }
                            )
                        }
                    )

                    Surface(
                        onClick = {
                            tempFilterKeys = selectedFilterKeys
                            showFilterDialog = true
                        },
                        modifier = Modifier
                            .height(42.dp)
                            .testTag("swadhyai_filter_button"),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(
                            width = 1.dp,
                            color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                        ),
                        color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter",
                                modifier = Modifier.size(18.dp),
                                tint = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "Filter (${selectedFilterKeys.size})",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (selectedFilterKeys.isNotEmpty()) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // 3. Registration List or Empty State
            if (swadhyaiForms.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Group,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = MaterialTheme.colorScheme.outline
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (searchQuery.isEmpty()) "No registrations found" else "No matching results",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
            } else {
                items(
                    items = swadhyaiForms,
                    key = { it.id }
                ) { item ->
                    Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                        SwadhyaiItemCard(
                            swadhyai = item,
                            selectedFilterKeys = selectedFilterKeys,
                            onClick = { selectedSwadhyai = item },
                            onEditClick = { editingSwadhyai = item },
                            onDeleteClick = { swadhyaiToDelete = item },
                            onLongClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                selectedSwadhyaiForActions = item
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwadhyaiItemCard(
    swadhyai: SwadhyaiFormEntity,
    selectedFilterKeys: Set<String>,
    onClick: () -> Unit,
    onEditClick: () -> Unit = {},
    onDeleteClick: () -> Unit = {},
    onLongClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val cityText = remember(swadhyai.city, swadhyai.state) {
        formatCityAndState(swadhyai.city, swadhyai.state)
    }

    fun openMapForCity() {
        if (cityText.isBlank()) return
        val uri = Uri.parse("geo:0,0?q=${Uri.encode(cityText)}")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        try {
            context.startActivity(mapIntent)
        } catch (e: Exception) {
            val webUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(cityText)}")
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri))
        }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .testTag("swadhyai_card_${swadhyai.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Interactive City / State GPS Tag
                if (cityText.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { openMapForCity() }
                            .testTag("swadhyai_city_tag_${swadhyai.id}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Maps",
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = cityText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "View Details",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Name - Age
            val displayName = swadhyai.fullName.ifBlank { "Swadhyai Registrant" }
            val ageText = if (swadhyai.age > 0) " - ${swadhyai.age} yrs" else ""
            Text(
                text = "$displayName$ageText",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            // Dynamic filter fields selected by user
            val activeFilterItems = remember(selectedFilterKeys, swadhyai) {
                selectedFilterKeys.mapNotNull { key ->
                    val field = swadhyaiFilterFields.find { it.key == key }
                    if (field != null) {
                        val valStr = field.getValue(swadhyai)
                        if (valStr.isNotBlank()) field.label to valStr else null
                    } else null
                }
            }

            if (activeFilterItems.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                if (activeFilterItems.size == 1) {
                    val (label, value) = activeFilterItems.first()
                    Text(
                        text = "$label: $value",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                } else {
                    val leftItems = activeFilterItems.filterIndexed { index, _ -> index % 2 == 0 }
                    val rightItems = activeFilterItems.filterIndexed { index, _ -> index % 2 != 0 }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(IntrinsicSize.Min),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            leftItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }

                        VerticalDivider(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(vertical = 2.dp),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.outlineVariant
                        )

                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            rightItems.forEach { (label, value) ->
                                Text(
                                    text = "$label: $value",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditSwadhyaiDialog(
    swadhyai: SwadhyaiFormEntity,
    onDismiss: () -> Unit,
    onSave: (SwadhyaiFormEntity) -> Unit
) {
    var fullName by remember { mutableStateOf(swadhyai.fullName) }
    var fatherName by remember { mutableStateOf(swadhyai.fatherName) }
    var motherName by remember { mutableStateOf(swadhyai.motherName) }
    var dob by remember { mutableStateOf(swadhyai.dob) }
    var ageStr by remember { mutableStateOf(if (swadhyai.age > 0) swadhyai.age.toString() else "") }
    var bloodGroup by remember { mutableStateOf(swadhyai.bloodGroup) }
    var maritalStatus by remember { mutableStateOf(swadhyai.maritalStatus) }
    var anniversaryDate by remember { mutableStateOf(swadhyai.anniversaryDate) }
    var whatsappNo by remember { mutableStateOf(swadhyai.whatsappNo) }
    var contactNo by remember { mutableStateOf(swadhyai.contactNo) }
    var email by remember { mutableStateOf(swadhyai.email) }
    var emergencyContactName by remember { mutableStateOf(swadhyai.emergencyContactName) }
    var emergencyContactRelation by remember { mutableStateOf(swadhyai.emergencyContactRelation) }
    var emergencyContactNo by remember { mutableStateOf(swadhyai.emergencyContactNo) }
    var address by remember { mutableStateOf(swadhyai.address) }
    var city by remember { mutableStateOf(swadhyai.city) }
    var state by remember { mutableStateOf(swadhyai.state) }
    var pincode by remember { mutableStateOf(swadhyai.pincode) }
    var nativePlace by remember { mutableStateOf(swadhyai.nativePlace) }
    var education by remember { mutableStateOf(swadhyai.education) }
    var workingStatus by remember { mutableStateOf(swadhyai.workingStatus) }
    var workDescription by remember { mutableStateOf(swadhyai.workDescription) }
    var joiningYearStr by remember { mutableStateOf(if (swadhyai.joiningYear > 0) swadhyai.joiningYear.toString() else "") }
    var specialities by remember { mutableStateOf(swadhyai.specialities) }
    var religiousLearnings by remember { mutableStateOf(swadhyai.religiousLearnings) }
    var anotherGroup by remember { mutableStateOf(swadhyai.anotherGroup) }
    var postInGroup by remember { mutableStateOf(swadhyai.postInGroup) }
    var paryushanCountStr by remember { mutableStateOf(if (swadhyai.paryushanCount > 0) swadhyai.paryushanCount.toString() else "0") }
    var dailyRoutineActivities by remember { mutableStateOf(swadhyai.dailyRoutineActivities) }
    var lifetimeTapasya by remember { mutableStateOf(swadhyai.lifetimeTapasya) }
    var paryushanWillingness by remember { mutableStateOf(swadhyai.paryushanWillingness) }
    var remarks by remember { mutableStateOf(swadhyai.remarks) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Edit Swadhyai Registration",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    SectionHeaderBadge("Step 1: Contact & Verification")
                    OutlinedTextField(
                        value = whatsappNo,
                        onValueChange = { whatsappNo = it },
                        label = { Text("WhatsApp Number") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    SectionHeaderBadge("Step 2: Personal Details")
                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("Father's Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("Mother's Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = dob,
                            onValueChange = { dob = it },
                            label = { Text("Date of Birth") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = ageStr,
                            onValueChange = { ageStr = it.filter { c -> c.isDigit() } },
                            label = { Text("Age") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = bloodGroup,
                            onValueChange = { bloodGroup = it },
                            label = { Text("Blood Group") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = maritalStatus,
                            onValueChange = { maritalStatus = it },
                            label = { Text("Marital Status") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = anniversaryDate,
                        onValueChange = { anniversaryDate = it },
                        label = { Text("Date of Anniversary") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = education,
                        onValueChange = { education = it },
                        label = { Text("Education") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = workingStatus,
                        onValueChange = { workingStatus = it },
                        label = { Text("Profession / Working Status") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = workDescription,
                        onValueChange = { workDescription = it },
                        label = { Text("Work Description / Details") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    SectionHeaderBadge("Step 3: Contact & Address")
                    OutlinedTextField(
                        value = contactNo,
                        onValueChange = { contactNo = it },
                        label = { Text("Contact No. (Alt)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email ID") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = emergencyContactName,
                        onValueChange = { emergencyContactName = it },
                        label = { Text("Emergency Contact Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = emergencyContactRelation,
                            onValueChange = { emergencyContactRelation = it },
                            label = { Text("Relation") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = emergencyContactNo,
                            onValueChange = { emergencyContactNo = it },
                            label = { Text("Emergency Mobile No.") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Address") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("City") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = state,
                            onValueChange = { state = it },
                            label = { Text("State") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = pincode,
                            onValueChange = { pincode = it },
                            label = { Text("Pin Code") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = nativePlace,
                            onValueChange = { nativePlace = it },
                            label = { Text("Native Place") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    SectionHeaderBadge("Step 4: Religious Details")
                    OutlinedTextField(
                        value = religiousLearnings,
                        onValueChange = { religiousLearnings = it },
                        label = { Text("Religious Learning") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = specialities,
                        onValueChange = { specialities = it },
                        label = { Text("Speciality") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = joiningYearStr,
                            onValueChange = { joiningYearStr = it.filter { c -> c.isDigit() } },
                            label = { Text("Joining Year") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = paryushanCountStr,
                            onValueChange = { paryushanCountStr = it.filter { c -> c.isDigit() } },
                            label = { Text("Paryushan Count") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                    OutlinedTextField(
                        value = anotherGroup,
                        onValueChange = { anotherGroup = it },
                        label = { Text("Another Religious Group") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = postInGroup,
                        onValueChange = { postInGroup = it },
                        label = { Text("Post in Group / Sanstha") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = dailyRoutineActivities,
                        onValueChange = { dailyRoutineActivities = it },
                        label = { Text("Daily Routine Religious Activity") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = lifetimeTapasya,
                        onValueChange = { lifetimeTapasya = it },
                        label = { Text("Lifetime Tapasya / Tyag") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = remarks,
                        onValueChange = { remarks = it },
                        label = { Text("Remarks / Notes") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val updated = swadhyai.copy(
                                fullName = fullName.trim(),
                                fatherName = fatherName.trim(),
                                motherName = motherName.trim(),
                                dob = dob.trim(),
                                age = ageStr.toIntOrNull() ?: 0,
                                bloodGroup = bloodGroup.trim(),
                                maritalStatus = maritalStatus.trim(),
                                anniversaryDate = anniversaryDate.trim(),
                                whatsappNo = whatsappNo.trim(),
                                contactNo = contactNo.trim(),
                                email = email.trim(),
                                emergencyContactName = emergencyContactName.trim(),
                                emergencyContactRelation = emergencyContactRelation.trim(),
                                emergencyContactNo = emergencyContactNo.trim(),
                                address = address.trim(),
                                city = city.trim(),
                                state = state.trim(),
                                pincode = pincode.trim(),
                                nativePlace = nativePlace.trim(),
                                education = education.trim(),
                                workingStatus = workingStatus.trim(),
                                workDescription = workDescription.trim(),
                                joiningYear = joiningYearStr.toIntOrNull() ?: 0,
                                specialities = specialities.trim(),
                                religiousLearnings = religiousLearnings.trim(),
                                anotherGroup = anotherGroup.trim(),
                                postInGroup = postInGroup.trim(),
                                paryushanCount = paryushanCountStr.toIntOrNull() ?: 0,
                                dailyRoutineActivities = dailyRoutineActivities.trim(),
                                lifetimeTapasya = lifetimeTapasya.trim(),
                                paryushanWillingness = paryushanWillingness.trim(),
                                remarks = remarks.trim()
                            )
                            onSave(updated)
                        }
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Save Changes")
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SwadhyaiActionDialog(
    swadhyai: SwadhyaiFormEntity,
    selectedFilterKeys: Set<String>,
    onDismiss: () -> Unit,
    onEditSwadhyai: () -> Unit,
    onDeleteSwadhyai: () -> Unit
) {
    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }

    val offsetY by animateFloatAsState(
        targetValue = if (animateIn) 0f else 220f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetY"
    )

    val offsetX by animateFloatAsState(
        targetValue = if (animateIn) 0f else -75f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetX"
    )

    val animRotation by animateFloatAsState(
        targetValue = if (animateIn) 0f else -5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardRotation"
    )

    val animScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardScale"
    )

    val animAlpha by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0f,
        animationSpec = spring(
            stiffness = Spring.StiffnessHigh
        ),
        label = "cardAlpha"
    )

    val optionsScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "optionsScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .graphicsLayer {
                        translationX = offsetX * density
                        translationY = offsetY * density
                        rotationZ = animRotation
                        scaleX = animScale
                        scaleY = animScale
                        this.alpha = animAlpha
                    }
                    .clickable(enabled = false) {},
                horizontalAlignment = Alignment.End
            ) {
                // Centered Preview Card
                SwadhyaiItemCard(
                    swadhyai = swadhyai,
                    selectedFilterKeys = selectedFilterKeys,
                    onClick = {},
                    onEditClick = {},
                    onDeleteClick = {},
                    onLongClick = {}
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Options Container
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .width(220.dp)
                        .graphicsLayer {
                            scaleX = optionsScale
                            scaleY = optionsScale
                            transformOrigin = TransformOrigin(1f, 0f)
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Option 1: Edit Details
                        Surface(
                            onClick = onEditSwadhyai,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "1. Edit Details",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        // Option 2: Delete Registration
                        Surface(
                            onClick = onDeleteSwadhyai,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "2. Delete Registration",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
