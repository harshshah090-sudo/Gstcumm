package com.example.ui

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class VisualSuggestion(
    val visualType: String, // "EMOJI" or "ICON"
    val visualValue: String, // emoji character or icon name
    val label: String,
    val suggestedColorHex: String
)

object GyanAiSuggester {
    private const val TAG = "GyanAiSuggester"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    // Pre-curated spiritual Jain & devotional default visuals
    val allStandardVisuals = listOf(
        VisualSuggestion("EMOJI", "🕉️", "Om / Mantra", "#FF9933"),
        VisualSuggestion("EMOJI", "🪷", "Lotus / Purity", "#E91E63"),
        VisualSuggestion("EMOJI", "📖", "Agam / Book", "#C1861F"),
        VisualSuggestion("EMOJI", "📜", "Scripture / Stotra", "#8D6E63"),
        VisualSuggestion("EMOJI", "🪔", "Deep / Aarti", "#FFB300"),
        VisualSuggestion("EMOJI", "🧘", "Dhyan / Samayik", "#2E7D32"),
        VisualSuggestion("EMOJI", "🙏", "Namaskar / Bhakti", "#F57C00"),
        VisualSuggestion("EMOJI", "🌟", "Sanskar / Star", "#9C27B0"),
        VisualSuggestion("EMOJI", "🕊️", "Ahimsa / Peace", "#00838F"),
        VisualSuggestion("EMOJI", "🏛️", "Derasar / Temple", "#6D4C41"),
        VisualSuggestion("EMOJI", "🔔", "Ghanta / Puja", "#D4AF37"),
        VisualSuggestion("EMOJI", "💡", "Tattva / Wisdom", "#1976D2"),
        VisualSuggestion("EMOJI", "💎", "Ratnatraya / Jewel", "#00ACC1"),
        VisualSuggestion("EMOJI", "🚩", "Dhwaja / Flag", "#E53935"),
        VisualSuggestion("EMOJI", "🎶", "Bhakti / Stavan", "#7B1FA2"),
        VisualSuggestion("EMOJI", "🕯️", "Jyot / Light", "#FFA000"),
        VisualSuggestion("EMOJI", "🌿", "Jeev Daya / Nature", "#388E3C"),
        VisualSuggestion("EMOJI", "👑", "Tirthankar / King", "#C1861F"),
        VisualSuggestion("EMOJI", "🌾", "Daan / Seva", "#689F38"),
        VisualSuggestion("EMOJI", "✨", "Pavitra / Divine", "#FFD700")
    )

    /**
     * Fast local contextual matching based on keywords in Hindi or English
     */
    fun getLocalSuggestions(query: String): List<VisualSuggestion> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return allStandardVisuals.take(6)

        val results = mutableListOf<VisualSuggestion>()

        // 1. Mantra / Navkar
        if (q.contains("mantra") || q.contains("मंत्र") || q.contains("नवकार") || q.contains("namokar") || q.contains("om") || q.contains("ॐ")) {
            results.add(VisualSuggestion("EMOJI", "🕉️", "Navkar / Mantra", "#FF9933"))
            results.add(VisualSuggestion("EMOJI", "🪷", "Kamal", "#E91E63"))
            results.add(VisualSuggestion("EMOJI", "🙏", "Pranam", "#F57C00"))
            results.add(VisualSuggestion("EMOJI", "✨", "Mahamantra", "#FFD700"))
        }

        // 2. Agam / Shastra / Sahitya / Grantha / Study
        if (q.contains("agam") || q.contains("आगम") || q.contains("साहित्य") || q.contains("शास्त्र") || q.contains("study") || q.contains("book") || q.contains("ग्रंथ") || q.contains("पुस्तक") || q.contains("gyan") || q.contains("ज्ञान")) {
            results.add(VisualSuggestion("EMOJI", "📖", "Agam / Book", "#C1861F"))
            results.add(VisualSuggestion("EMOJI", "📜", "Scripture", "#8D6E63"))
            results.add(VisualSuggestion("EMOJI", "💡", "Gyan", "#1976D2"))
            results.add(VisualSuggestion("EMOJI", "📝", "Swadhyay", "#2E7D32"))
        }

        // 3. Stotra / Bhaktamar / Paath
        if (q.contains("stotra") || q.contains("स्तोत्र") || q.contains("भक्तामर") || q.contains("bhaktamar") || q.contains("stavan") || q.contains("स्तवन") || q.contains("पाठ") || q.contains("chhand")) {
            results.add(VisualSuggestion("EMOJI", "📜", "Stotra", "#8D6E63"))
            results.add(VisualSuggestion("EMOJI", "🎶", "Stavan", "#7B1FA2"))
            results.add(VisualSuggestion("EMOJI", "🪔", "Aarti", "#FFB300"))
            results.add(VisualSuggestion("EMOJI", "👑", "Bhagwan", "#C1861F"))
        }

        // 4. Samayik / Pratikraman / Dhyan / Tap
        if (q.contains("samayik") || q.contains("सामयिक") || q.contains("प्रतिक्रमण") || q.contains("pratikraman") || q.contains("dhyan") || q.contains("ध्यान") || q.contains("tap") || q.contains("तप") || q.contains("updhan") || q.contains("उपधान")) {
            results.add(VisualSuggestion("EMOJI", "🧘", "Dhyan / Tap", "#2E7D32"))
            results.add(VisualSuggestion("EMOJI", "🕊️", "Ahimsa / Shanti", "#00838F"))
            results.add(VisualSuggestion("EMOJI", "🙏", "Pratikraman", "#F57C00"))
            results.add(VisualSuggestion("EMOJI", "🪷", "Purity", "#E91E63"))
        }

        // 5. Aarti / Puja / Deep / Bhakti
        if (q.contains("aarti") || q.contains("आरती") || q.contains("puja") || q.contains("पूजा") || q.contains("deep") || q.contains("दीपक") || q.contains("bhakti") || q.contains("भक्ति") || q.contains("geet") || q.contains("गीत")) {
            results.add(VisualSuggestion("EMOJI", "🪔", "Deepak / Aarti", "#FFB300"))
            results.add(VisualSuggestion("EMOJI", "🔔", "Ghanta / Puja", "#D4AF37"))
            results.add(VisualSuggestion("EMOJI", "🎶", "Bhakti Sangeet", "#7B1FA2"))
            results.add(VisualSuggestion("EMOJI", "🕯️", "Jyot", "#FFA000"))
        }

        // 6. Sanskar / Bal / Pathshala / Yuva / Kids
        if (q.contains("bal") || q.contains("बाल") || q.contains("sanskar") || q.contains("संस्कार") || q.contains("pathshala") || q.contains("पाठशाला") || q.contains("kids") || q.contains("yuva") || q.contains("युवा") || q.contains("story") || q.contains("कहानी") || q.contains("कथा")) {
            results.add(VisualSuggestion("EMOJI", "🌟", "Bal Sanskar", "#9C27B0"))
            results.add(VisualSuggestion("EMOJI", "👦", "Vidyarthi", "#1976D2"))
            results.add(VisualSuggestion("EMOJI", "✨", "Sanskar", "#FFD700"))
            results.add(VisualSuggestion("EMOJI", "📖", "Katha / Story", "#C1861F"))
        }

        // 7. Tirth / Mandir / Yatra / History
        if (q.contains("tirth") || q.contains("तीर्थ") || q.contains("mandir") || q.contains("मंदिर") || q.contains("derasar") || q.contains("देरासर") || q.contains("yatra") || q.contains("यात्रा") || q.contains("history") || q.contains("इतिहास")) {
            results.add(VisualSuggestion("EMOJI", "🏛️", "Derasar / Tirth", "#6D4C41"))
            results.add(VisualSuggestion("EMOJI", "🚩", "Dhwaja", "#E53935"))
            results.add(VisualSuggestion("EMOJI", "🏔️", "Parvat / Shatrunjay", "#00838F"))
            results.add(VisualSuggestion("EMOJI", "🔔", "Ghanti", "#D4AF37"))
        }

        // Fill up with standard visuals if fewer than 4 results
        for (item in allStandardVisuals) {
            if (results.none { it.visualValue == item.visualValue }) {
                results.add(item)
            }
            if (results.size >= 8) break
        }

        return results
    }

    /**
     * Calls Gemini 3.5 Flash AI to generate smart contextually matching emojis and theme colors
     */
    suspend fun getAiSuggestedVisuals(categoryTitle: String): List<VisualSuggestion> = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getLocalSuggestions(categoryTitle)
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val prompt = """
                You are an expert in Jain religion, spiritual literature, and iconography.
                The user is creating a learning category titled: "$categoryTitle".
                Suggest 5 highly relevant single emojis or visual symbols for this category, along with a short label and a spiritual hex color (e.g. gold, saffron, green, maroon, amber, royal blue, teal).
                
                Respond ONLY in valid JSON format as an array of objects:
                [
                  {"emoji": "📖", "label": "Agam", "color": "#C1861F"},
                  {"emoji": "🕉️", "label": "Mantra", "#FF9933"}
                ]
            """.trimIndent()

            val requestBodyJson = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        })
                    })
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(requestBodyJson.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.w(TAG, "Gemini API error code: ${response.code}")
                return@withContext getLocalSuggestions(categoryTitle)
            }

            val responseBody = response.body?.string() ?: return@withContext getLocalSuggestions(categoryTitle)
            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            val candidate = candidates?.optJSONObject(0)
            val content = candidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val rawText = parts?.optJSONObject(0)?.optString("text") ?: ""

            // Extract JSON array from Markdown code blocks if present
            val cleanedJson = if (rawText.contains("[")) {
                val start = rawText.indexOf("[")
                val end = rawText.lastIndexOf("]")
                if (start != -1 && end != -1 && end > start) {
                    rawText.substring(start, end + 1)
                } else rawText
            } else rawText

            val jsonArray = JSONArray(cleanedJson)
            val aiResults = mutableListOf<VisualSuggestion>()

            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.optJSONObject(i) ?: continue
                val emoji = obj.optString("emoji", "📖").trim()
                val label = obj.optString("label", categoryTitle).trim()
                var color = obj.optString("color", "#C1861F").trim()
                if (!color.startsWith("#")) color = "#$color"

                if (emoji.isNotEmpty()) {
                    aiResults.add(VisualSuggestion("EMOJI", emoji, label, color))
                }
            }

            if (aiResults.isNotEmpty()) {
                aiResults
            } else {
                getLocalSuggestions(categoryTitle)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to get AI suggestions", e)
            getLocalSuggestions(categoryTitle)
        }
    }
}
