package com.example.ui

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.PanchangEventEntity
import com.example.ui.theme.*
import com.example.utils.PanchangNotificationHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PanchangNotificationSettingsTab(
    allEvents: List<PanchangEventEntity>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var hasPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasPermission = isGranted
        if (isGranted) {
            Toast.makeText(context, "Notification permission granted!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Permission denied. Device notifications won't appear.", Toast.LENGTH_LONG).show()
        }
    }

    var masterEnabled by remember { mutableStateOf(PanchangNotificationHelper.isMasterEnabled(context)) }
    var kalyanakEnabled by remember { mutableStateOf(PanchangNotificationHelper.isKalyanakEnabled(context)) }
    var parvaEnabled by remember { mutableStateOf(PanchangNotificationHelper.isParvaEnabled(context)) }
    var tithiEnabled by remember { mutableStateOf(PanchangNotificationHelper.isImportantTithiEnabled(context)) }
    var selectedTimings by remember { mutableStateOf(PanchangNotificationHelper.getReminderTimings(context)) }

    fun toggleTiming(timingKey: String) {
        val current = selectedTimings.toMutableSet()
        if (current.contains(timingKey)) {
            current.remove(timingKey)
        } else {
            current.add(timingKey)
        }
        selectedTimings = current
        PanchangNotificationHelper.setReminderTimings(context, current)
        PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
    }

    val upcomingEvents = remember(allEvents) {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = sdf.format(Date())
        allEvents
            .filter { it.dateString >= todayStr && (it.kalyanaks.isNotBlank() || it.parvasAndEvents.isNotBlank() || it.isImportantTithi) }
            .sortedBy { it.dateString }
            .take(15)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Card 1: Master Enable / Permission Status
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(AppPrimaryGold.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (masterEnabled) Icons.Default.NotificationsActive else Icons.Default.NotificationsOff,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Event Reminders",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = AppTextPrimary
                                    )
                                )
                                Text(
                                    text = if (masterEnabled) "Device notifications active" else "Notifications turned off",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = if (masterEnabled) AppSecondaryGreen else AppTextMuted
                                    )
                                )
                            }
                        }

                        Switch(
                            checked = masterEnabled,
                            onCheckedChange = { newValue ->
                                masterEnabled = newValue
                                PanchangNotificationHelper.setMasterEnabled(context, newValue)
                                PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
                                if (newValue && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPermission) {
                                    permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = AppPrimaryGold,
                                checkedTrackColor = AppTertiaryMaroon
                            )
                        )
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPermission) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = Color(0xFFD32F2F).copy(alpha = 0.12f),
                            border = BorderStroke(1.dp, Color(0xFFD32F2F).copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = Color(0xFFFF5252),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Notification permission needed for popup alerts.",
                                        fontSize = 11.5.sp,
                                        color = AppTextPrimary
                                    )
                                }
                                Button(
                                    onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Text("Grant", fontSize = 11.sp, color = Color.White)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Test Notification Button
                    OutlinedButton(
                        onClick = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPermission) {
                                permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                PanchangNotificationHelper.sendTestNotification(context)
                                Toast.makeText(context, "Test notification triggered!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, AppPrimaryGold)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Send Test Device Notification",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Card 2: Notification Event Categories
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Event Categories to Notify",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    NotificationCategoryToggleRow(
                        title = "Tirthankar Kalyanaks",
                        subtitle = "Chyavan, Janma, Diksha, Kevaljnana & Moksha",
                        icon = Icons.Default.Star,
                        iconTint = Color(0xFFFFB300),
                        checked = kalyanakEnabled,
                        onCheckedChange = {
                            kalyanakEnabled = it
                            PanchangNotificationHelper.setKalyanakEnabled(context, it)
                            PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
                        }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = AppDeepSurface)

                    NotificationCategoryToggleRow(
                        title = "Special Parvas & Festivals",
                        subtitle = "Paryushan, Mahavir Jayanti, Oli, Fasts",
                        icon = Icons.Default.Flag,
                        iconTint = Color(0xFFCE93D8),
                        checked = parvaEnabled,
                        onCheckedChange = {
                            parvaEnabled = it
                            PanchangNotificationHelper.setParvaEnabled(context, it)
                            PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
                        }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = AppDeepSurface)

                    NotificationCategoryToggleRow(
                        title = "Important Tithis",
                        subtitle = "Aatham (8th), Chaudas (14th), Agiyaras, Poonam",
                        icon = Icons.Default.Bookmark,
                        iconTint = AppSecondaryGreen,
                        checked = tithiEnabled,
                        onCheckedChange = {
                            tithiEnabled = it
                            PanchangNotificationHelper.setImportantTithiEnabled(context, it)
                            PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
                        }
                    )
                }
            }
        }

        // Card 3: Reminder Timing Options
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "When to Send Notification (Select Multiple)",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    TimingOptionCheckboxRow(
                        title = "1 Day Before (at 8:00 PM)",
                        subtitle = "Best for preparing for fasts, Pachkhan & rituals",
                        checked = selectedTimings.contains("1_DAY_BEFORE_8PM"),
                        onCheckedChange = { toggleTiming("1_DAY_BEFORE_8PM") }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TimingOptionCheckboxRow(
                        title = "1 Day Before (at 7:00 AM)",
                        subtitle = "Morning reminder 1 day prior to the event",
                        checked = selectedTimings.contains("1_DAY_BEFORE_7AM"),
                        onCheckedChange = { toggleTiming("1_DAY_BEFORE_7AM") }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TimingOptionCheckboxRow(
                        title = "Same Day Morning (at 6:00 AM)",
                        subtitle = "Early morning alert on the day of the event",
                        checked = selectedTimings.contains("SAME_DAY_6AM"),
                        onCheckedChange = { toggleTiming("SAME_DAY_6AM") }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    TimingOptionCheckboxRow(
                        title = "Same Day Morning (at 8:00 AM)",
                        subtitle = "Morning alert on the day of Kalyanak or festival",
                        checked = selectedTimings.contains("SAME_DAY_8AM"),
                        onCheckedChange = { toggleTiming("SAME_DAY_8AM") }
                    )
                }
            }
        }

        // Card 4: Schedule Action Button
        item {
            Button(
                onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !hasPermission) {
                        permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        val count = PanchangNotificationHelper.scheduleNotificationsForEvents(context, allEvents)
                        Toast.makeText(context, "Successfully scheduled $count event reminders on device! 🔔", Toast.LENGTH_LONG).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon)
            ) {
                Icon(
                    imageVector = Icons.Default.Alarm,
                    contentDescription = null,
                    tint = AppPrimaryGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Schedule All Reminders On Device",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
            }
        }

        // Section 5: Upcoming Scheduled Events
        item {
            Text(
                text = "Upcoming Event Alerts (${upcomingEvents.size})",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary
                ),
                modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
            )
        }

        items(upcomingEvents) { event ->
            ScheduledEventCard(event = event)
        }
    }
}

@Composable
fun NotificationCategoryToggleRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = iconTint,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        fontSize = 11.sp
                    )
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = AppPrimaryGold,
                checkedTrackColor = AppTertiaryMaroon
            )
        )
    }
}

@Composable
fun TimingOptionCheckboxRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (checked) AppTertiaryMaroon.copy(alpha = 0.25f) else AppDeepSurface,
        border = BorderStroke(1.dp, if (checked) AppPrimaryGold else Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCheckedChange() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = checked,
                onCheckedChange = { onCheckedChange() },
                colors = CheckboxDefaults.colors(
                    checkedColor = AppPrimaryGold,
                    checkmarkColor = Color.Black,
                    uncheckedColor = AppTextMuted
                )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (checked) AppPrimaryGold else AppTextPrimary
                    )
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        fontSize = 11.sp
                    )
                )
            }
        }
    }
}

@Composable
fun ScheduledEventCard(event: PanchangEventEntity) {
    val formattedDateText = remember(event.dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(event.dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale.getDefault())
            outSdf.format(date)
        } catch (e: Exception) {
            event.dateString
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = BorderStroke(1.dp, AppDeepSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = formattedDateText,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                if (event.kalyanaks.isNotBlank()) {
                    Text(
                        text = "✨ ${event.kalyanaks}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                } else if (event.parvasAndEvents.isNotBlank()) {
                    Text(
                        text = "🚩 ${event.parvasAndEvents}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppTextPrimary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                } else {
                    Text(
                        text = "📌 Tithi: ${event.tithi}",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppSecondaryGreen)
                    )
                }
            }

            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AppTertiaryMaroon,
                border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = null,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Active 🔔",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    )
                }
            }
        }
    }
}
