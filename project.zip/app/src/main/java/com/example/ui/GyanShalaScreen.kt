package com.example.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GyanShalaScreen(
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "ज्ञान शाला",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "Gyan Shala • स्वाध्याय एवं संस्कार",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppSurface
                ),
                modifier = Modifier.testTag("gyan_shala_top_bar")
            )
        },
        containerColor = AppBackground
    ) { paddingValues ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 110.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Hero Coming Soon Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        1.dp,
                        Brush.linearGradient(listOf(AppPrimaryGold, AppSecondaryGreen)),
                        RoundedCornerShape(20.dp)
                    )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AppSecondaryGreen.copy(alpha = 0.25f),
                                    AppDeepSurface
                                )
                            )
                        )
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            shape = CircleShape,
                            color = AppPrimaryGold.copy(alpha = 0.2f),
                            modifier = Modifier.size(72.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.AutoStories,
                                    contentDescription = "Gyan Shala",
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(38.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = AppPrimaryGold.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "✨ शीघ्र आ रहा है • COMING SOON ✨",
                                color = AppPrimaryGold,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = "श्री वर्द्धमान ज्ञान शाला",
                            style = MaterialTheme.typography.headlineSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "तत्वज्ञान, सूत्र कंठस्थीकरण, जैन आगम अध्ययन एवं दैनिक स्वाध्याय की आधुनिक डिजिटल पाठशाला।",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = AppTextMuted,
                                lineHeight = 20.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Planned Features Title
            Text(
                text = "आगामी विशेषताएँ (Upcoming Features)",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            GyanShalaFeatureItem(
                icon = Icons.Filled.MenuBook,
                title = "दैनिक स्वाध्याय एवं पाठ",
                description = "पर्यूषण एवं वर्षभर के लिए स्वाध्याय सामग्री, तत्वज्ञान एवं सूत्र व्याख्या।"
            )

            Spacer(modifier = Modifier.height(10.dp))

            GyanShalaFeatureItem(
                icon = Icons.Filled.RecordVoiceOver,
                title = "ऑडीओ सूत्र संग्रह",
                description = "शुद्ध उच्चारण के साथ सूत्र वाचन, प्रतिक्रमण एवं आवश्यक पाठ के ऑडीओ ट्रैक।"
            )

            Spacer(modifier = Modifier.height(10.dp))

            GyanShalaFeatureItem(
                icon = Icons.Filled.Quiz,
                title = "जैन प्रश्नोत्तरी एवं क्विज़",
                description = "ज्ञान वृद्धि हेतु रोचक दैनिक जैन क्विज़ एवं स्वाध्याय प्रश्न-उत्तर मंच।"
            )

            Spacer(modifier = Modifier.height(10.dp))

            GyanShalaFeatureItem(
                icon = Icons.Filled.School,
                title = "युवा एवं बाल संस्कार शाला",
                description = "नवीन पीढ़ी के लिए सरल, प्रामाणिक और रोचक जैन जीवनशैली शिक्षण।"
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Mangal Shloka Banner
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = AppSurfaceNested,
                border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "।। ज्ञान समान न आन कछु सुख को कारन जग में।\nदौलत राम विचारिके यह सीख धरौ मन में।।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppSuccessPaleGreen,
                            fontWeight = FontWeight.Medium,
                            lineHeight = 18.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(72.dp))
        }
    }
}

@Composable
private fun GyanShalaFeatureItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = AppSecondaryGreen.copy(alpha = 0.25f),
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = AppSuccessPaleGreen,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        lineHeight = 16.sp
                    )
                )
            }
        }
    }
}
