package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.R
import com.example.data.GyanCategoryEntity
import com.example.data.GyanTopicEntity
import com.example.ui.theme.*

// Helper function to safely parse hex colors
fun parseHexColor(hex: String, fallback: Color = AppPrimaryGold): Color {
    return try {
        val clean = hex.removePrefix("#")
        val colorInt = when (clean.length) {
            6 -> 0xFF000000.toInt() or clean.toLong(16).toInt()
            8 -> clean.toLong(16).toInt()
            else -> fallback.value.toInt()
        }
        Color(colorInt)
    } catch (e: Exception) {
        fallback
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GyanShalaScreen(
    modifier: Modifier = Modifier,
    viewModel: GyanViewModel = viewModel()
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val allTopics by viewModel.allTopics.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val topics by viewModel.topicsForSelectedCategory.collectAsStateWithLifecycle()
    val highlightedTopicId by viewModel.highlightedTopicId.collectAsStateWithLifecycle()
    val isAiLoading by viewModel.isAiLoading.collectAsStateWithLifecycle()
    val liveSuggestions by viewModel.liveSuggestions.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var showAddTopicDialog by remember { mutableStateOf(false) }

    // Long press and action dialog states for CATEGORIES
    var selectedCategoryForActions by remember { mutableStateOf<GyanCategoryEntity?>(null) }
    var editingCategory by remember { mutableStateOf<GyanCategoryEntity?>(null) }
    var categoryToDelete by remember { mutableStateOf<GyanCategoryEntity?>(null) }

    // Long press and action dialog states for TOPICS/NOTES
    var selectedTopicForActions by remember { mutableStateOf<GyanTopicEntity?>(null) }
    var editingTopic by remember { mutableStateOf<GyanTopicEntity?>(null) }
    var topicToDelete by remember { mutableStateOf<GyanTopicEntity?>(null) }

    // Intercept back button when inside a category view
    BackHandler(enabled = selectedCategory != null) {
        viewModel.selectCategory(null)
    }

    AnimatedContent(
        targetState = selectedCategory,
        transitionSpec = {
            if (targetState != null) {
                (slideInHorizontally { width -> width } + fadeIn()).togetherWith(
                    slideOutHorizontally { width -> -width } + fadeOut()
                )
            } else {
                (slideInHorizontally { width -> -width } + fadeIn()).togetherWith(
                    slideOutHorizontally { width -> width } + fadeOut()
                )
            }
        },
        label = "gyan_shala_navigation"
    ) { currentCategory ->
        if (currentCategory == null) {
            // MAIN 3-COLUMN GRID VIEW
            GyanShalaCategoryGridView(
                categories = categories,
                allTopics = allTopics,
                onCategoryClick = { category ->
                    viewModel.selectCategory(category)
                },
                onCategoryLongClick = { category ->
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    selectedCategoryForActions = category
                },
                onAddClick = {
                    viewModel.onCategoryNameChanged("")
                    showCreateDialog = true
                },
                modifier = modifier
            )
        } else {
            // CATEGORY DETAIL SUB-WINDOW (Delete option removed from header)
            GyanCategoryDetailWindow(
                category = currentCategory,
                topics = topics,
                highlightedTopicId = highlightedTopicId,
                onBack = {
                    viewModel.clearHighlightedTopic()
                    viewModel.selectCategory(null)
                },
                onAddTopicClick = { showAddTopicDialog = true },
                onTopicLongClick = { topic ->
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    selectedTopicForActions = topic
                },
                modifier = modifier
            )
        }
    }

    // LONG PRESS ACTIONS DIALOG FOR CATEGORY (With bouncy spring animation)
    if (selectedCategoryForActions != null) {
        val targetCategory = selectedCategoryForActions!!
        GyanCategoryActionDialog(
            category = targetCategory,
            onDismiss = { selectedCategoryForActions = null },
            onEditCategory = {
                selectedCategoryForActions = null
                editingCategory = targetCategory
            },
            onDeleteCategory = {
                selectedCategoryForActions = null
                categoryToDelete = targetCategory
            }
        )
    }

    // LONG PRESS ACTIONS DIALOG FOR TOPIC / NOTE (With bouncy spring animation)
    if (selectedTopicForActions != null) {
        val targetTopic = selectedTopicForActions!!
        GyanNoteActionDialog(
            topic = targetTopic,
            onDismiss = { selectedTopicForActions = null },
            onEditNote = {
                selectedTopicForActions = null
                editingTopic = targetTopic
            },
            onDeleteNote = {
                selectedTopicForActions = null
                topicToDelete = targetTopic
            }
        )
    }

    // POPUP DIALOG: Edit Category Name, Photo, and Details
    if (editingCategory != null) {
        val targetToEdit = editingCategory!!
        EditGyanCategoryDialog(
            category = targetToEdit,
            liveSuggestions = liveSuggestions,
            isAiLoading = isAiLoading,
            onNameChange = { query -> viewModel.onCategoryNameChanged(query) },
            onTriggerAi = { query -> viewModel.triggerAiSuggestions(query) },
            onDismiss = { editingCategory = null },
            onSave = { updated ->
                viewModel.updateCategory(updated)
                Toast.makeText(context, "Category updated successfully", Toast.LENGTH_SHORT).show()
                editingCategory = null
            }
        )
    }

    // POPUP DIALOG: Delete Category Confirmation
    if (categoryToDelete != null) {
        val target = categoryToDelete!!
        AlertDialog(
            onDismissRequest = { categoryToDelete = null },
            title = { Text("Delete Category", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to delete '${target.name}' and all its lessons?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteCategory(target)
                        Toast.makeText(context, "'${target.name}' category deleted", Toast.LENGTH_SHORT).show()
                        categoryToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { categoryToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // POPUP DIALOG: Delete Note Confirmation
    if (topicToDelete != null) {
        val target = topicToDelete!!
        AlertDialog(
            onDismissRequest = { topicToDelete = null },
            title = { Text("Delete Note", fontWeight = FontWeight.Bold) },
            text = {
                val displayName = if (target.title.isNotBlank()) "'${target.title}'" else "this note"
                Text("Are you sure you want to delete $displayName?")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteTopic(target)
                        Toast.makeText(context, "Note deleted", Toast.LENGTH_SHORT).show()
                        topicToDelete = null
                    }
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { topicToDelete = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // POPUP DIALOG: Edit Topic / Note
    if (editingTopic != null) {
        val target = editingTopic!!
        EditTopicDialog(
            topic = target,
            categoryName = selectedCategory?.name ?: "",
            onDismiss = { editingTopic = null },
            onConfirm = { updatedTopic ->
                viewModel.updateTopic(updatedTopic)
                Toast.makeText(context, "Note updated successfully", Toast.LENGTH_SHORT).show()
                editingTopic = null
            }
        )
    }

    // POPUP DIALOG: Create Category with AI Suggestions & Gallery Photo Upload
    if (showCreateDialog) {
        CreateGyanCategoryDialog(
            liveSuggestions = liveSuggestions,
            isAiLoading = isAiLoading,
            onNameChange = { query -> viewModel.onCategoryNameChanged(query) },
            onTriggerAi = { query -> viewModel.triggerAiSuggestions(query) },
            onDismiss = { showCreateDialog = false },
            onConfirm = { name, visualType, visualValue, colorHex, desc ->
                viewModel.addCategory(name, visualType, visualValue, colorHex, desc)
                showCreateDialog = false
            }
        )
    }

    // POPUP DIALOG: Add Topic/Lesson in Selected Category
    if (showAddTopicDialog && selectedCategory != null) {
        AddTopicDialog(
            categoryName = selectedCategory!!.name,
            onDismiss = { showAddTopicDialog = false },
            onConfirm = { title, content, subtext, textAlignment, displayStyle ->
                viewModel.addTopic(
                    title = title,
                    content = content,
                    subtext = subtext,
                    textAlignment = textAlignment,
                    displayStyle = displayStyle
                )
                showAddTopicDialog = false
            }
        )
    }
}

/**
 * 3-Column Grid View for Gyan Shala Categories
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GyanShalaCategoryGridView(
    categories: List<GyanCategoryEntity>,
    allTopics: List<GyanTopicEntity> = emptyList(),
    onCategoryClick: (GyanCategoryEntity) -> Unit,
    onCategoryLongClick: (GyanCategoryEntity) -> Unit,
    onAddClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "Gyan Shala Logo",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "Gyan Shala",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "Learning & Wisdom Hub",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppSurface
                ),
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = AppSecondaryGreen.copy(alpha = 0.25f),
                        border = BorderStroke(1.dp, AppSecondaryGreen.copy(alpha = 0.5f)),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Category,
                                contentDescription = null,
                                tint = AppSuccessPaleGreen,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${categories.size} Categories",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppSuccessPaleGreen
                                )
                            )
                        }
                    }
                },
                modifier = Modifier.testTag("gyan_shala_top_bar")
            )
        },
        containerColor = AppBackground
    ) { paddingValues ->
        LazyColumn(
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(AppBackground),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Section Label
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Learning Categories",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold,
                            fontSize = 15.sp
                        )
                    )
                    Text(
                        text = "Press & hold for options",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppTextMuted
                        )
                    )
                }
            }

            // 3-COLUMN GRID OF CIRCULAR CATEGORIES & THE "+" CIRCLE
            item {
                val totalItemsCount = categories.size + 1
                val totalRows = (totalItemsCount + 2) / 3

                Column(
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    for (rowIndex in 0 until totalRows) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            for (colIndex in 0 until 3) {
                                val itemIndex = rowIndex * 3 + colIndex
                                if (itemIndex < categories.size) {
                                    val cat = categories[itemIndex]
                                    val catTopics = allTopics.filter { it.categoryId == cat.id }
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.TopCenter
                                    ) {
                                        CircularCategoryItem(
                                            category = cat,
                                            topics = catTopics,
                                            onClick = { onCategoryClick(cat) },
                                            onLongClick = { onCategoryLongClick(cat) }
                                        )
                                    }
                                } else if (itemIndex == categories.size) {
                                    Box(
                                        modifier = Modifier.weight(1f),
                                        contentAlignment = Alignment.TopCenter
                                    ) {
                                        CircularAddCategoryItem(
                                            onClick = onAddClick
                                        )
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Wisdom Quote
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AppSurfaceNested,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "“ज्ञान वह सर्वोच्च प्रकाश है जो अज्ञान रूपी अंधेरे को दूर करता है और आत्मा को प्रकाशित करता है।”",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppSuccessPaleGreen,
                                fontWeight = FontWeight.Medium,
                                lineHeight = 18.sp,
                                textAlign = TextAlign.Center
                            )
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual Circular Category Item with Image / Emoji Support & combinedClickable
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CircularCategoryItem(
    category: GyanCategoryEntity,
    topics: List<GyanTopicEntity> = emptyList(),
    onClick: () -> Unit,
    onLongClick: () -> Unit = {}
) {
    val context = LocalContext.current
    val gyanSeenSignal by com.example.utils.GyanSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
    val isUnread = remember(category, topics, gyanSeenSignal) {
        com.example.utils.GyanSeenTracker.isCategoryUnreadOrUpdated(context, category, topics)
    }
    val categoryColor = parseHexColor(category.colorHex, AppPrimaryGold)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(105.dp)
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = {
                    com.example.utils.GyanSeenTracker.markCategorySeen(context, category.id)
                    onClick()
                },
                onLongClick = onLongClick
            )
            .testTag("gyan_category_${category.id}")
            .padding(vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier.size(76.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = CircleShape,
                color = categoryColor.copy(alpha = 0.16f),
                border = BorderStroke(2.dp, categoryColor.copy(alpha = 0.85f)),
                shadowElevation = 3.dp,
                modifier = Modifier.fillMaxSize()
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                listOf(
                                    categoryColor.copy(alpha = 0.35f),
                                    AppSurface
                                )
                            )
                        )
                ) {
                    GyanVisualDisplay(
                        visualType = category.visualType,
                        visualValue = category.visualValue,
                        emojiFontSize = 32.sp
                    )
                }
            }

            if (isUnread) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-2).dp, y = 2.dp)
                        .size(11.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE53935))
                        .border(1.5.dp, Color.White, CircleShape)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = category.name,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.SemiBold,
                color = AppTextPrimary,
                fontSize = 13.sp,
                lineHeight = 16.sp
            ),
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * Circular Add Button ("+" Circle) in the 3-column Grid
 */
@Composable
private fun CircularAddCategoryItem(
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .width(105.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = ripple(bounded = false, radius = 48.dp),
                onClick = onClick
            )
            .testTag("add_gyan_category_button")
            .padding(vertical = 4.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = AppPrimaryGold.copy(alpha = 0.12f),
            border = BorderStroke(2.dp, Brush.linearGradient(listOf(AppPrimaryGold, AppSuccessPaleGreen))),
            shadowElevation = 4.dp,
            modifier = Modifier.size(76.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(
                                AppPrimaryGold.copy(alpha = 0.25f),
                                AppSurfaceNested
                            )
                        )
                    )
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add New Category",
                    tint = AppPrimaryGold,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "+ New Category",
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold,
                fontSize = 13.sp,
                lineHeight = 16.sp
            ),
            textAlign = TextAlign.Center,
            maxLines = 2,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/**
 * LONG-PRESS ACTION DIALOG for Categories with Bouncy Spring Animations
 */
@Composable
private fun GyanCategoryActionDialog(
    category: GyanCategoryEntity,
    onDismiss: () -> Unit,
    onEditCategory: () -> Unit,
    onDeleteCategory: () -> Unit
) {
    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }

    val density = LocalDensity.current.density
    val categoryColor = parseHexColor(category.colorHex, AppPrimaryGold)

    val offsetY by animateFloatAsState(
        targetValue = if (animateIn) 0f else -300f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetY"
    )

    val offsetX by animateFloatAsState(
        targetValue = if (animateIn) 0f else -75f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetX"
    )

    val animRotation by animateFloatAsState(
        targetValue = if (animateIn) 0f else -5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardRotation"
    )

    val animScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardScale"
    )

    val animAlpha by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0f,
        animationSpec = spring(
            stiffness = Spring.StiffnessHigh
        ),
        label = "cardAlpha"
    )

    val optionsScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "optionsScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .graphicsLayer {
                        translationX = offsetX * density
                        translationY = offsetY * density
                        rotationZ = animRotation
                        scaleX = animScale
                        scaleY = animScale
                        this.alpha = animAlpha
                    }
                    .clickable(enabled = false) {},
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    border = BorderStroke(1.5.dp, categoryColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.fillMaxWidth(0.85f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        categoryColor.copy(alpha = 0.25f),
                                        AppDeepSurface
                                    )
                                )
                            )
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = categoryColor.copy(alpha = 0.25f),
                            border = BorderStroke(2.dp, categoryColor),
                            modifier = Modifier.size(72.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                GyanVisualDisplay(
                                    visualType = category.visualType,
                                    visualValue = category.visualValue,
                                    emojiFontSize = 34.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = category.name,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary,
                                fontSize = 17.sp
                            ),
                            textAlign = TextAlign.Center
                        )

                        if (category.description.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = category.description,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AppTextMuted
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 14.dp,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier
                        .fillMaxWidth(0.85f)
                        .graphicsLayer {
                            scaleX = optionsScale
                            scaleY = optionsScale
                            transformOrigin = TransformOrigin(0.5f, 0f)
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = onEditCategory,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "1. Edit Category",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontSize = 14.sp
                                        )
                                    )
                                    Text(
                                        text = "Change name, photo, symbol & theme color",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                                            fontSize = 11.5.sp
                                        )
                                    )
                                }
                            }
                        }

                        Surface(
                            onClick = onDeleteCategory,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "2. Delete Category",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            fontSize = 14.sp
                                        )
                                    )
                                    Text(
                                        text = "This category and all its lessons will be removed",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.75f),
                                            fontSize = 11.5.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * LONG-PRESS ACTION DIALOG for Topics / Notes with Bouncy Spring Animations
 */
@Composable
private fun GyanNoteActionDialog(
    topic: GyanTopicEntity,
    onDismiss: () -> Unit,
    onEditNote: () -> Unit,
    onDeleteNote: () -> Unit
) {
    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }

    val density = LocalDensity.current.density

    val offsetY by animateFloatAsState(
        targetValue = if (animateIn) 0f else -300f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "noteOffsetY"
    )

    val offsetX by animateFloatAsState(
        targetValue = if (animateIn) 0f else -75f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "noteOffsetX"
    )

    val animRotation by animateFloatAsState(
        targetValue = if (animateIn) 0f else -5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "noteRotation"
    )

    val animScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "noteScale"
    )

    val animAlpha by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0f,
        animationSpec = spring(
            stiffness = Spring.StiffnessHigh
        ),
        label = "noteAlpha"
    )

    val optionsScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "noteOptionsScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .graphicsLayer {
                        translationX = offsetX * density
                        translationY = offsetY * density
                        rotationZ = animRotation
                        scaleX = animScale
                        scaleY = animScale
                        this.alpha = animAlpha
                    }
                    .clickable(enabled = false) {},
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    border = BorderStroke(1.5.dp, AppPrimaryGold.copy(alpha = 0.8f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                    modifier = Modifier.fillMaxWidth(0.88f)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(18.dp)
                    ) {
                        if (topic.title.isNotBlank()) {
                            Text(
                                text = topic.title,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                            if (topic.subtext.isNotBlank()) {
                                Text(
                                    text = topic.subtext,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Medium
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        Text(
                            text = topic.content,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = AppTextMuted,
                                lineHeight = 20.sp
                            ),
                            maxLines = 4,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 14.dp,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier
                        .fillMaxWidth(0.88f)
                        .graphicsLayer {
                            scaleX = optionsScale
                            scaleY = optionsScale
                            transformOrigin = TransformOrigin(0.5f, 0f)
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            onClick = onEditNote,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "1. Edit Note",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontSize = 14.sp
                                        )
                                    )
                                    Text(
                                        text = "Modify content, alignment, and display style",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                                            fontSize = 11.5.sp
                                        )
                                    )
                                }
                            }
                        }

                        Surface(
                            onClick = onDeleteNote,
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "2. Delete Note",
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            fontSize = 14.sp
                                        )
                                    )
                                    Text(
                                        text = "Permanently remove this note from category",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.75f),
                                            fontSize = 11.5.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * EDIT CATEGORY DIALOG
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditGyanCategoryDialog(
    category: GyanCategoryEntity,
    liveSuggestions: List<VisualSuggestion>,
    isAiLoading: Boolean,
    onNameChange: (String) -> Unit,
    onTriggerAi: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: (GyanCategoryEntity) -> Unit
) {
    val context = LocalContext.current
    var categoryName by remember { mutableStateOf(category.name) }
    var categoryDescription by remember { mutableStateOf(category.description) }

    val colorOptions = listOf(
        "#C1861F", // Primary Gold
        "#FF9933", // Saffron / Kesariya
        "#2E7D32", // Green
        "#8A2E3F", // Maroon
        "#1976D2", // Royal Blue
        "#9C27B0", // Purple
        "#00838F", // Teal
        "#8D6E63"  // Ochre / Brown
    )
    var selectedColorHex by remember { mutableStateOf(category.colorHex.ifBlank { colorOptions[0] }) }
    var selectedVisualType by remember { mutableStateOf(category.visualType.ifBlank { "EMOJI" }) }
    var selectedVisualValue by remember { mutableStateOf(category.visualValue.ifBlank { "📖" }) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val base64 = GyanImageUtils.processImageUriToBase64(context, uri, 280)
            if (base64 != null) {
                selectedVisualType = "IMAGE_BASE64"
                selectedVisualValue = base64
                Toast.makeText(context, "Photo selected!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Unable to load photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = AppPrimaryGold.copy(alpha = 0.2f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = null,
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Edit Category",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = "Update Category Name, Photo & Details",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted
                            )
                        )
                    }
                }

                HorizontalDivider(color = AppBorder)

                OutlinedTextField(
                    value = categoryName,
                    onValueChange = {
                        categoryName = it
                        onNameChange(it)
                    },
                    label = { Text("Category Name") },
                    placeholder = { Text("e.g. Navkar Mantra, Bhaktamar, Tattvagyan...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = AppPrimaryGold.copy(alpha = 0.08f)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Gallery",
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Choose Photo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (categoryName.isNotBlank()) {
                                onTriggerAi(categoryName)
                            } else {
                                Toast.makeText(context, "Please enter category name first", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppSecondaryGreen.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = AppSecondaryGreen.copy(alpha = 0.08f)
                        ),
                        enabled = !isAiLoading,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isAiLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = AppSuccessPaleGreen
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AI Searching...", fontSize = 11.5.sp, color = AppSuccessPaleGreen)
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AppSuccessPaleGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("✨ AI Symbols", fontSize = 12.sp, color = AppSuccessPaleGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Symbols row
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Or Pick a Symbol:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppTextMuted
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        liveSuggestions.take(5).forEach { suggestion ->
                            val isSelected = selectedVisualType != "IMAGE_BASE64" && selectedVisualValue == suggestion.visualValue
                            val chipColor = parseHexColor(suggestion.suggestedColorHex, AppPrimaryGold)

                            Surface(
                                shape = CircleShape,
                                color = if (isSelected) chipColor.copy(alpha = 0.35f) else AppSurfaceNested,
                                border = BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) chipColor else AppBorder
                                ),
                                shadowElevation = if (isSelected) 4.dp else 1.dp,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clickable {
                                        selectedVisualType = "EMOJI"
                                        selectedVisualValue = suggestion.visualValue
                                        selectedColorHex = suggestion.suggestedColorHex
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = suggestion.visualValue,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Color Swatches
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Theme Color",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        colorOptions.forEach { hex ->
                            val color = parseHexColor(hex)
                            val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                            Surface(
                                shape = CircleShape,
                                color = color,
                                border = if (isSelected) BorderStroke(2.5.dp, Color.White) else null,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clickable { selectedColorHex = hex }
                            ) {
                                if (isSelected) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = categoryDescription,
                    onValueChange = { categoryDescription = it },
                    label = { Text("Short Description (Optional)") },
                    placeholder = { Text("e.g. Verses, meaning and spiritual commentary") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Live Preview
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AppSurfaceNested,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val previewColor = parseHexColor(selectedColorHex, AppPrimaryGold)
                        Surface(
                            shape = CircleShape,
                            color = previewColor.copy(alpha = 0.2f),
                            border = BorderStroke(2.dp, previewColor),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                GyanVisualDisplay(
                                    visualType = selectedVisualType,
                                    visualValue = selectedVisualValue,
                                    emojiFontSize = 24.sp
                                )
                            }
                        }
                        Column {
                            Text(
                                text = categoryName.ifBlank { "Category Name" },
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                            Text(
                                text = if (selectedVisualType == "IMAGE_BASE64") "Custom photo is set" else "Preview as displayed in grid",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (selectedVisualType == "IMAGE_BASE64") AppPrimaryGold else AppTextMuted
                                )
                            )
                        }
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = AppTextPrimary)
                    }

                    Button(
                        onClick = {
                            if (categoryName.isBlank()) {
                                Toast.makeText(context, "Please enter category name", Toast.LENGTH_SHORT).show()
                            } else {
                                onSave(
                                    category.copy(
                                        name = categoryName.trim(),
                                        visualType = selectedVisualType,
                                        visualValue = selectedVisualValue,
                                        colorHex = selectedColorHex,
                                        description = categoryDescription.trim()
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = parseHexColor(selectedColorHex, AppPrimaryGold),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * Dedicated Sub-Window for Selected Category (Delete option removed from header)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GyanCategoryDetailWindow(
    category: GyanCategoryEntity,
    topics: List<GyanTopicEntity>,
    highlightedTopicId: Long? = null,
    onBack: () -> Unit,
    onAddTopicClick: () -> Unit,
    onTopicLongClick: (GyanTopicEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    val categoryColor = parseHexColor(category.colorHex, AppPrimaryGold)
    val listState = rememberLazyListState()

    val context = LocalContext.current

    // Automatically mark all notes in this category as viewed when the category is opened/viewed
    LaunchedEffect(category.id, topics) {
        if (topics.isNotEmpty()) {
            com.example.utils.GyanSeenTracker.markCategorySeen(context, category.id, topics)
        } else {
            com.example.utils.GyanSeenTracker.markCategorySeen(context, category.id)
        }
    }

    LaunchedEffect(highlightedTopicId, topics) {
        if (highlightedTopicId != null && topics.isNotEmpty()) {
            val targetIndex = topics.indexOfFirst { it.id == highlightedTopicId }
            if (targetIndex >= 0) {
                // index + 1 accounts for the Hero banner item at index 0
                listState.animateScrollToItem(targetIndex + 1)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = categoryColor.copy(alpha = 0.2f),
                            border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.7f)),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                GyanVisualDisplay(
                                    visualType = category.visualType,
                                    visualValue = category.visualValue,
                                    emojiFontSize = 20.sp
                                )
                            }
                        }

                        Column {
                            Text(
                                text = category.name,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "Gyan Shala • Study Lessons",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("gyan_category_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppSurface
                ),
                modifier = Modifier.testTag("gyan_category_detail_top_bar")
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddTopicClick,
                containerColor = categoryColor,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 72.dp)
                    .testTag("add_topic_fab")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add Lesson / Note",
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        containerColor = AppBackground
    ) { paddingValues ->
        LazyColumn(
            state = listState,
            modifier = modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(AppBackground),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 120.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Category Hero Banner
            item {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = AppSurface),
                    border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        categoryColor.copy(alpha = 0.22f),
                                        AppDeepSurface
                                    )
                                )
                            )
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = categoryColor.copy(alpha = 0.25f),
                            border = BorderStroke(2.dp, categoryColor),
                            modifier = Modifier.size(68.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                GyanVisualDisplay(
                                    visualType = category.visualType,
                                    visualValue = category.visualValue,
                                    emojiFontSize = 32.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = category.name,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            ),
                            textAlign = TextAlign.Center
                        )

                        if (category.description.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = category.description,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = AppTextMuted
                                ),
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = categoryColor.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, categoryColor.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "${topics.size} Lessons / Notes • Press & hold note to edit/delete",
                                color = categoryColor,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Topics / Lessons Section
            if (topics.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppSurface),
                        border = BorderStroke(1.dp, AppBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = null,
                                tint = AppTextMuted,
                                modifier = Modifier.size(40.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "No notes or lessons added yet",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap the '+' button below to add your first study note, verse, or lesson.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AppTextMuted,
                                    textAlign = TextAlign.Center
                                )
                            )
                        }
                    }
                }
            } else {
                items(topics, key = { it.id }) { topic ->
                    val isHighlighted = (topic.id == highlightedTopicId)
                    GyanTopicCard(
                        topic = topic,
                        accentColor = categoryColor,
                        isHighlighted = isHighlighted,
                        onLongClick = { onTopicLongClick(topic) }
                    )
                }
            }
        }
    }
}

/**
 * Topic / Lesson Card in Category Detail View
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun GyanTopicCard(
    topic: GyanTopicEntity,
    accentColor: Color,
    isHighlighted: Boolean = false,
    onLongClick: () -> Unit
) {
    val context = LocalContext.current
    val gyanSeenSignal by com.example.utils.GyanSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
    val isTopicUnread = remember(topic, gyanSeenSignal) {
        com.example.utils.GyanSeenTracker.isTopicUnreadOrUpdated(context, topic)
    }

    LaunchedEffect(isHighlighted) {
        if (isHighlighted) {
            com.example.utils.GyanSeenTracker.markTopicSeen(context, topic.id)
        }
    }

    var expanded by remember(isHighlighted) { mutableStateOf(isHighlighted) }

    val resolvedAlignment = when (topic.textAlignment.uppercase()) {
        "CENTER" -> TextAlign.Center
        "RIGHT" -> TextAlign.End
        else -> TextAlign.Start
    }

    val horizontalAlign = when (topic.textAlignment.uppercase()) {
        "CENTER" -> Alignment.CenterHorizontally
        "RIGHT" -> Alignment.End
        else -> Alignment.Start
    }

    val isBoxStyle = !topic.displayStyle.equals("PLAIN", ignoreCase = true)

    if (isBoxStyle) {
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isHighlighted) accentColor.copy(alpha = 0.12f) else AppSurface
            ),
            border = BorderStroke(
                width = if (isHighlighted) 2.dp else 1.dp,
                color = if (isHighlighted) accentColor else AppBorder.copy(alpha = 0.85f)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .combinedClickable(
                    onClick = {
                        com.example.utils.GyanSeenTracker.markTopicSeen(context, topic.id)
                        expanded = !expanded
                    },
                    onLongClick = onLongClick
                )
                .testTag("gyan_topic_card_${topic.id}")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = horizontalAlign
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (topic.title.isNotBlank()) {
                        Text(
                            text = topic.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            ),
                            textAlign = resolvedAlignment,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }

                    if (isTopicUnread) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .size(9.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFE53935))
                                .border(1.dp, Color.White, CircleShape)
                        )
                    }
                }

                if (topic.subtext.isNotBlank()) {
                    if (topic.title.isNotBlank()) Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = topic.subtext,
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = accentColor,
                            fontWeight = FontWeight.Medium
                        ),
                        textAlign = resolvedAlignment,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                if (topic.title.isNotBlank() || topic.subtext.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Text(
                    text = topic.content,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AppTextPrimary.copy(alpha = 0.92f),
                        lineHeight = 22.sp
                    ),
                    textAlign = resolvedAlignment,
                    maxLines = if (expanded) Int.MAX_VALUE else 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )

                if (topic.content.length > 90) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (expanded) "Show Less ▲" else "Read More ▼",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = accentColor,
                            fontWeight = FontWeight.Bold
                        ),
                        textAlign = resolvedAlignment
                    )
                }
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .combinedClickable(
                    onClick = {
                        com.example.utils.GyanSeenTracker.markTopicSeen(context, topic.id)
                        expanded = !expanded
                    },
                    onLongClick = onLongClick
                )
                .padding(vertical = 10.dp, horizontal = 6.dp)
                .testTag("gyan_topic_plain_${topic.id}"),
            horizontalAlignment = horizontalAlign
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                if (topic.title.isNotBlank()) {
                    Text(
                        text = topic.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        ),
                        textAlign = resolvedAlignment,
                        modifier = Modifier.weight(1f, fill = false)
                    )
                } else {
                    Spacer(modifier = Modifier.weight(1f))
                }

                if (isTopicUnread) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE53935))
                            .border(1.dp, Color.White, CircleShape)
                    )
                }
            }

            if (topic.subtext.isNotBlank()) {
                if (topic.title.isNotBlank()) Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = topic.subtext,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = accentColor,
                        fontWeight = FontWeight.Medium
                    ),
                    textAlign = resolvedAlignment,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (topic.title.isNotBlank() || topic.subtext.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
            }

            Text(
                text = topic.content,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = AppTextPrimary,
                    lineHeight = 23.sp
                ),
                textAlign = resolvedAlignment,
                maxLines = if (expanded) Int.MAX_VALUE else 4,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            if (topic.content.length > 90) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (expanded) "Show Less ▲" else "Read More ▼",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = accentColor,
                        fontWeight = FontWeight.Bold
                    ),
                    textAlign = resolvedAlignment
                )
            }

            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(color = AppBorder.copy(alpha = 0.5f))
        }
    }
}

/**
 * POPUP DIALOG: Create Category with AI Visual Suggestions & Photo Picker
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateGyanCategoryDialog(
    liveSuggestions: List<VisualSuggestion>,
    isAiLoading: Boolean,
    onNameChange: (String) -> Unit,
    onTriggerAi: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: (name: String, visualType: String, visualValue: String, colorHex: String, description: String) -> Unit
) {
    val context = LocalContext.current
    var categoryName by remember { mutableStateOf("") }
    var categoryDescription by remember { mutableStateOf("") }

    val colorOptions = listOf(
        "#C1861F", // Primary Gold
        "#FF9933", // Saffron / Kesariya
        "#2E7D32", // Green
        "#8A2E3F", // Maroon
        "#1976D2", // Royal Blue
        "#9C27B0", // Purple
        "#00838F", // Teal
        "#8D6E63"  // Ochre / Brown
    )
    var selectedColorHex by remember { mutableStateOf(colorOptions[0]) }
    var selectedVisualType by remember { mutableStateOf("EMOJI") }
    var selectedVisualValue by remember { mutableStateOf("📖") }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val base64 = GyanImageUtils.processImageUriToBase64(context, uri, 280)
            if (base64 != null) {
                selectedVisualType = "IMAGE_BASE64"
                selectedVisualValue = base64
                Toast.makeText(context, "Photo selected!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Unable to load photo", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LaunchedEffect(liveSuggestions) {
        if (selectedVisualType != "IMAGE_BASE64") {
            if (liveSuggestions.isNotEmpty() && (selectedVisualValue == "📖" || liveSuggestions.none { it.visualValue == selectedVisualValue })) {
                selectedVisualValue = liveSuggestions.first().visualValue
                selectedColorHex = liveSuggestions.first().suggestedColorHex
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = AppPrimaryGold.copy(alpha = 0.2f),
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.AutoStories,
                                contentDescription = null,
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Create New Category",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = "Create Learning Category • Photo / AI",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted
                            )
                        )
                    }
                }

                HorizontalDivider(color = AppBorder)

                OutlinedTextField(
                    value = categoryName,
                    onValueChange = {
                        categoryName = it
                        onNameChange(it)
                    },
                    label = { Text("Category Name") },
                    placeholder = { Text("e.g. Navkar Mantra, Bhaktamar, Tattvagyan...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("category_name_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = AppPrimaryGold.copy(alpha = 0.08f)
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = "Gallery",
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Choose Photo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            if (categoryName.isNotBlank()) {
                                onTriggerAi(categoryName)
                            } else {
                                Toast.makeText(context, "Please enter category name first", Toast.LENGTH_SHORT).show()
                            }
                        },
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppSecondaryGreen.copy(alpha = 0.7f)),
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = AppSecondaryGreen.copy(alpha = 0.08f)
                        ),
                        enabled = !isAiLoading,
                        modifier = Modifier.weight(1f)
                    ) {
                        if (isAiLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                strokeWidth = 2.dp,
                                color = AppSuccessPaleGreen
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("AI Searching...", fontSize = 11.5.sp, color = AppSuccessPaleGreen)
                        } else {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = AppSuccessPaleGreen,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("✨ AI Symbols", fontSize = 12.sp, color = AppSuccessPaleGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // AI Suggested Symbols
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Or Pick a Symbol:",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppTextMuted
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        liveSuggestions.take(5).forEach { suggestion ->
                            val isSelected = selectedVisualType != "IMAGE_BASE64" && selectedVisualValue == suggestion.visualValue
                            val chipColor = parseHexColor(suggestion.suggestedColorHex, AppPrimaryGold)

                            Surface(
                                shape = CircleShape,
                                color = if (isSelected) chipColor.copy(alpha = 0.35f) else AppSurfaceNested,
                                border = BorderStroke(
                                    if (isSelected) 2.dp else 1.dp,
                                    if (isSelected) chipColor else AppBorder
                                ),
                                shadowElevation = if (isSelected) 4.dp else 1.dp,
                                modifier = Modifier
                                    .size(46.dp)
                                    .clickable {
                                        selectedVisualType = "EMOJI"
                                        selectedVisualValue = suggestion.visualValue
                                        selectedColorHex = suggestion.suggestedColorHex
                                    }
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = suggestion.visualValue,
                                        fontSize = 22.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Color Selection
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Theme Color",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        colorOptions.forEach { hex ->
                            val color = parseHexColor(hex)
                            val isSelected = selectedColorHex.equals(hex, ignoreCase = true)
                            Surface(
                                shape = CircleShape,
                                color = color,
                                border = if (isSelected) BorderStroke(2.5.dp, Color.White) else null,
                                modifier = Modifier
                                    .size(28.dp)
                                    .clickable { selectedColorHex = hex }
                            ) {
                                if (isSelected) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = categoryDescription,
                    onValueChange = { categoryDescription = it },
                    label = { Text("Short Description (Optional)") },
                    placeholder = { Text("e.g. Verses, meaning and spiritual commentary") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Live Preview
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = AppSurfaceNested,
                    border = BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val previewColor = parseHexColor(selectedColorHex, AppPrimaryGold)
                        Surface(
                            shape = CircleShape,
                            color = previewColor.copy(alpha = 0.2f),
                            border = BorderStroke(2.dp, previewColor),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                GyanVisualDisplay(
                                    visualType = selectedVisualType,
                                    visualValue = selectedVisualValue,
                                    emojiFontSize = 24.sp
                                )
                            }
                        }
                        Column {
                            Text(
                                text = categoryName.ifBlank { "Category Name" },
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppTextPrimary
                                )
                            )
                            Text(
                                text = if (selectedVisualType == "IMAGE_BASE64") "Custom photo is set" else "Preview as displayed in grid",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (selectedVisualType == "IMAGE_BASE64") AppPrimaryGold else AppTextMuted
                                )
                            )
                        }
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = AppTextPrimary)
                    }

                    Button(
                        onClick = {
                            if (categoryName.isBlank()) {
                                Toast.makeText(context, "Please enter category name", Toast.LENGTH_SHORT).show()
                            } else {
                                onConfirm(
                                    categoryName.trim(),
                                    selectedVisualType,
                                    selectedVisualValue,
                                    selectedColorHex,
                                    categoryDescription.trim()
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = parseHexColor(selectedColorHex, AppPrimaryGold),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("create_category_confirm_button")
                    ) {
                        Text("Create", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * POPUP DIALOG: Add Note/Lesson
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTopicDialog(
    categoryName: String,
    onDismiss: () -> Unit,
    onConfirm: (title: String, content: String, subtext: String, textAlignment: String, displayStyle: String) -> Unit
) {
    val context = LocalContext.current
    var topicTitle by remember { mutableStateOf("") }
    var topicSubtext by remember { mutableStateOf("") }
    var topicContent by remember { mutableStateOf("") }
    var textAlignment by remember { mutableStateOf("LEFT") }
    var displayStyle by remember { mutableStateOf("BOX") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Add New Lesson / Note",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
                Text(
                    text = "Category: $categoryName",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppPrimaryGold,
                        fontWeight = FontWeight.Bold
                    )
                )

                HorizontalDivider(color = AppBorder)

                OutlinedTextField(
                    value = topicTitle,
                    onValueChange = { topicTitle = it },
                    label = { Text("Lesson Title (Optional)") },
                    placeholder = { Text("e.g. First Verse, Chapter 1, Core Meaning...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topicSubtext,
                    onValueChange = { topicSubtext = it },
                    label = { Text("Subtext / Chapter (Optional)") },
                    placeholder = { Text("e.g. Chapter 1, Original Sutra...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topicContent,
                    onValueChange = { topicContent = it },
                    label = { Text("Note / Lesson Content *") },
                    placeholder = { Text("Write verses, meanings, or study notes here...") },
                    minLines = 3,
                    maxLines = 6,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Text Alignment Selector
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Text Alignment",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("LEFT", Icons.Default.FormatAlignLeft, "Left"),
                            Triple("CENTER", Icons.Default.FormatAlignCenter, "Center"),
                            Triple("RIGHT", Icons.Default.FormatAlignRight, "Right")
                        ).forEach { (alignKey, icon, label) ->
                            val isSelected = textAlignment == alignKey
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AppPrimaryGold.copy(alpha = 0.25f) else AppSurfaceNested,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AppPrimaryGold else AppBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { textAlignment = alignKey }
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (isSelected) AppPrimaryGold else AppTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) AppPrimaryGold else AppTextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                // Display Style Selector
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Display Style",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("BOX", Icons.Default.CheckBoxOutlineBlank, "Inside Box"),
                            Triple("PLAIN", Icons.Default.FormatPaint, "Plain Background")
                        ).forEach { (styleKey, icon, label) ->
                            val isSelected = displayStyle == styleKey
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AppSecondaryGreen.copy(alpha = 0.25f) else AppSurfaceNested,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AppSecondaryGreen else AppBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { displayStyle = styleKey }
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (isSelected) AppSuccessPaleGreen else AppTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) AppSuccessPaleGreen else AppTextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = AppTextPrimary)
                    }

                    Button(
                        onClick = {
                            if (topicContent.isBlank()) {
                                Toast.makeText(context, "Please enter the note content", Toast.LENGTH_SHORT).show()
                            } else {
                                onConfirm(
                                    topicTitle.trim(),
                                    topicContent.trim(),
                                    topicSubtext.trim(),
                                    textAlignment,
                                    displayStyle
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AppPrimaryGold,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

/**
 * POPUP DIALOG: Edit Topic / Note
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditTopicDialog(
    topic: GyanTopicEntity,
    categoryName: String,
    onDismiss: () -> Unit,
    onConfirm: (GyanTopicEntity) -> Unit
) {
    val context = LocalContext.current
    var topicTitle by remember { mutableStateOf(topic.title) }
    var topicSubtext by remember { mutableStateOf(topic.subtext) }
    var topicContent by remember { mutableStateOf(topic.content) }
    var textAlignment by remember { mutableStateOf(topic.textAlignment.ifBlank { "LEFT" }) }
    var displayStyle by remember { mutableStateOf(topic.displayStyle.ifBlank { "BOX" }) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = AppSurface,
            border = BorderStroke(1.dp, AppBorder),
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .padding(vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Edit Lesson / Note",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
                if (categoryName.isNotBlank()) {
                    Text(
                        text = "Category: $categoryName",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                HorizontalDivider(color = AppBorder)

                OutlinedTextField(
                    value = topicTitle,
                    onValueChange = { topicTitle = it },
                    label = { Text("Lesson Title (Optional)") },
                    placeholder = { Text("e.g. First Verse, Chapter 1, Core Meaning...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topicSubtext,
                    onValueChange = { topicSubtext = it },
                    label = { Text("Subtext / Chapter (Optional)") },
                    placeholder = { Text("e.g. Chapter 1, Original Sutra...") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = topicContent,
                    onValueChange = { topicContent = it },
                    label = { Text("Note / Lesson Content *") },
                    placeholder = { Text("Write verses, meanings, or study notes here...") },
                    minLines = 3,
                    maxLines = 6,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        unfocusedBorderColor = AppBorder,
                        focusedLabelColor = AppPrimaryGold
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                // Text Alignment Selector
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Text Alignment",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("LEFT", Icons.Default.FormatAlignLeft, "Left"),
                            Triple("CENTER", Icons.Default.FormatAlignCenter, "Center"),
                            Triple("RIGHT", Icons.Default.FormatAlignRight, "Right")
                        ).forEach { (alignKey, icon, label) ->
                            val isSelected = textAlignment.equals(alignKey, ignoreCase = true)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AppPrimaryGold.copy(alpha = 0.25f) else AppSurfaceNested,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AppPrimaryGold else AppBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { textAlignment = alignKey }
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (isSelected) AppPrimaryGold else AppTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) AppPrimaryGold else AppTextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                // Display Style Selector
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Display Style",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            Triple("BOX", Icons.Default.CheckBoxOutlineBlank, "Inside Box"),
                            Triple("PLAIN", Icons.Default.FormatPaint, "Plain Background")
                        ).forEach { (styleKey, icon, label) ->
                            val isSelected = displayStyle.equals(styleKey, ignoreCase = true)
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (isSelected) AppSecondaryGreen.copy(alpha = 0.25f) else AppSurfaceNested,
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) AppSecondaryGreen else AppBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { displayStyle = styleKey }
                            ) {
                                Row(
                                    modifier = Modifier.padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = label,
                                        tint = if (isSelected) AppSuccessPaleGreen else AppTextMuted,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = label,
                                        fontSize = 12.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) AppSuccessPaleGreen else AppTextMuted
                                    )
                                }
                            }
                        }
                    }
                }

                // Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = AppTextPrimary)
                    }

                    Button(
                        onClick = {
                            if (topicContent.isBlank()) {
                                Toast.makeText(context, "Please enter the note content", Toast.LENGTH_SHORT).show()
                            } else {
                                onConfirm(
                                    topic.copy(
                                        title = topicTitle.trim(),
                                        content = topicContent.trim(),
                                        subtext = topicSubtext.trim(),
                                        textAlignment = textAlignment,
                                        displayStyle = displayStyle
                                    )
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AppPrimaryGold,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
