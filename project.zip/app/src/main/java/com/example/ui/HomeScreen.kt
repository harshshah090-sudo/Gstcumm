package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.UserSessionManager
import com.example.ui.components.CreateTimelinePostDialog
import com.example.ui.components.DualSlantedHomeBanners
import com.example.ui.components.FullscreenPhotoGalleryDialog
import com.example.ui.components.SlantedLeftCardShape
import com.example.ui.components.SlantedRightCardShape
import com.example.ui.components.TimelinePostCard
import com.example.ui.theme.*

private fun formatCurrencyIndian(amount: Double): String {
    val formatter = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("en", "IN"))
    formatter.maximumFractionDigits = 0
    return formatter.format(amount).replace("\u00A0", "").replace("₹ ", "₹").trim()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FormViewModel,
    onNavigateToNewForm: () -> Unit,
    onNavigateToSanghRegistrations: () -> Unit,
    onNavigateToSwadhyaiRegistrations: () -> Unit,
    onNavigateToSanghAllotted: () -> Unit,
    onNavigateToFund: () -> Unit,
    onNavigateToPanchang: () -> Unit,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToNotifications: () -> Unit = onNavigateToPanchang,
    onNavigateToRegistrationHistory: () -> Unit = {},
    onNavigateToGyanShala: ((Long, Long) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val forms by viewModel.filteredForms.collectAsStateWithLifecycle()
    val swadhyaiForms by viewModel.filteredSwadhyaiForms.collectAsStateWithLifecycle()
    val allAllotments by viewModel.allAllotments.collectAsStateWithLifecycle()
    val totalBankFund by viewModel.totalBankFund.collectAsStateWithLifecycle()
    val totalCashFund by viewModel.totalCashFund.collectAsStateWithLifecycle()
    val totalFund by viewModel.totalFund.collectAsStateWithLifecycle()
    val allPanchangEvents by viewModel.allPanchangEvents.collectAsStateWithLifecycle()
    val allRegistrationHistories by viewModel.allRegistrationHistories.collectAsStateWithLifecycle()
    val session by UserSessionManager.sessionState.collectAsStateWithLifecycle()

    var isRegistrationsAndFundsExpanded by remember { mutableStateOf(false) }
    var isAllotmentAndHistoryExpanded by remember { mutableStateOf(false) }

    val rawTimelinePosts by viewModel.allTimelinePosts.collectAsStateWithLifecycle()
    val gyanSeenSignal by com.example.utils.GyanSeenTracker.seenUpdateSignal.collectAsStateWithLifecycle()
    
    // Filter out past Gyan Shala changes made before app installation, and already viewed updates
    val allTimelinePosts = remember(rawTimelinePosts, gyanSeenSignal) {
        rawTimelinePosts.filter { post ->
            com.example.utils.GyanSeenTracker.shouldShowTimelinePost(context, post)
        }
    }
    var showCreatePostDialog by remember { mutableStateOf(false) }
    var editingPost by remember { mutableStateOf<com.example.data.TimelinePostEntity?>(null) }
    var galleryPhotos by remember { mutableStateOf<List<String>?>(null) }
    var galleryInitialIndex by remember { mutableIntStateOf(0) }
    var gallerySourceBounds by remember { mutableStateOf<Map<Int, Rect>?>(null) }

    val formattedTotalFund = remember(totalFund) {
        formatCurrencyIndian(totalFund)
    }
    val formattedBankFund = remember(totalBankFund) {
        formatCurrencyIndian(totalBankFund)
    }
    val formattedCashFund = remember(totalCashFund) {
        formatCurrencyIndian(totalCashFund)
    }

    val notifDb = remember { com.example.data.AppDatabase.getDatabase(context) }
    val installBaseline = remember { com.example.utils.AppInstallTracker.getInstallBaselineTimestamp(context) }
    val unseenNotifCount by notifDb.appNotificationDao().getUnseenCountAfterBaselineFlow(installBaseline).collectAsStateWithLifecycle(initialValue = 0)

    val (allottedSanghCount, allottedSwadhyaiCount) = remember(allAllotments, swadhyaiForms) {
        val swadhyaiMap = swadhyaiForms.associateBy { it.id }
        val active = allAllotments.mapNotNull { allotment ->
            val parsedIds = allotment.swadhyaiIds.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .filter { swadhyaiMap.containsKey(it) }
            if (parsedIds.isEmpty()) null else parsedIds
        }
        val sanghCount = active.size
        val swadhyaiCount = active.sumOf { it.size }
        Pair(sanghCount, swadhyaiCount)
    }

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    var lastBackPressTime by remember { mutableLongStateOf(0L) }
    BackHandler {
        val currentTime = System.currentTimeMillis()
        if (currentTime - lastBackPressTime < 2000L) {
            (context as? android.app.Activity)?.finish()
        } else {
            lastBackPressTime = currentTime
            Toast.makeText(context, "Press back again to exit / बाहर निकलने के लिए दोबारा बैक दबाएं", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(48.dp)
                        )
                        Column {
                            Text(
                                text = "श्री वर्द्धमान स्वाध्याय संघ",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontSize = 18.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "।। जिन आज्ञा परमो धर्मः ।।",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp
                                )
                            )
                        }
                    }
                },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            actions = {
                IconButton(
                    onClick = onNavigateToNotifications,
                    modifier = Modifier.testTag("top_notifications_button")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notifications / सूचनाएं",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        if (unseenNotifCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(9.dp)
                                    .align(Alignment.TopEnd)
                                    .offset(x = 1.dp, y = (-1).dp)
                                    .background(Color(0xFFE53935), CircleShape)
                                    .border(1.2.dp, MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                            )
                        }
                    }
                }
            }
        )
    },
    floatingActionButton = {
        if (session.isAdmin) {
            FloatingActionButton(
                onClick = { showCreatePostDialog = true },
                shape = CircleShape,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .padding(bottom = 60.dp, end = 4.dp)
                    .size(56.dp)
                    .testTag("fab_create_timeline_post")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Create Timeline Post",
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    },
    modifier = modifier
) { innerPadding ->
    LazyColumn(
        contentPadding = PaddingValues(bottom = 120.dp, top = 6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Greeting Banner below header
        item {
            val greetingName = if (session.firstName.isNotBlank()) session.firstName else "Swadhyai"
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pranam $greetingName..!",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground,
                        fontSize = 20.sp,
                        letterSpacing = 0.2.sp
                    ),
                    modifier = Modifier.testTag("text_pranam_admin")
                )
            }
        }

        // 1. Dual Slanted Interlocking Banners: Paryushan Countdown + Today's Tithi & Special Event
        item {
            DualSlantedHomeBanners(
                allEvents = allPanchangEvents,
                onOpenPanchang = onNavigateToPanchang
            )
        }

        // 2. Collapsible Header & Banners: Registrations & Funds (Visible only for Admin)
        if (session.isAdmin) {
            item {
                val arrowRotation by animateFloatAsState(
                    targetValue = if (isRegistrationsAndFundsExpanded) 180f else 0f,
                    animationSpec = tween(durationMillis = 300),
                    label = "arrow_rotation"
                )

                Surface(
                    onClick = { isRegistrationsAndFundsExpanded = !isRegistrationsAndFundsExpanded },
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 0.dp)
                        .testTag("toggle_registrations_funds_header")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 0.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Registrations & Funds",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.15.sp
                                )
                            )
                        }

                        IconButton(
                            onClick = { isRegistrationsAndFundsExpanded = !isRegistrationsAndFundsExpanded },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("toggle_registrations_funds_arrow")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isRegistrationsAndFundsExpanded) "Hide Registrations & Funds" else "Show Registrations & Funds",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(24.dp)
                                    .rotate(arrowRotation)
                            )
                        }
                    }
                }
            }

            // 3. Dual Slanted Interlocking Banners: Sangh Registrations & Funds with animated down rising & uprising
            item {
                AnimatedVisibility(
                    visible = isRegistrationsAndFundsExpanded,
                    enter = fadeIn(animationSpec = tween(350)) +
                            expandVertically(
                                expandFrom = Alignment.Top,
                                animationSpec = tween(350)
                            ) +
                            slideInVertically(
                                initialOffsetY = { -it / 2 },
                                animationSpec = tween(350)
                            ),
                    exit = fadeOut(animationSpec = tween(300)) +
                            shrinkVertically(
                                shrinkTowards = Alignment.Top,
                                animationSpec = tween(300)
                            ) +
                            slideOutVertically(
                                targetOffsetY = { -it / 2 },
                                animationSpec = tween(300)
                            )
                ) {
                    DualSlantedSanghFundBanners(
                        sanghCount = forms.size,
                        allottedSanghCount = allottedSanghCount,
                        allottedSwadhyaiCount = allottedSwadhyaiCount,
                        totalFundFormatted = formattedTotalFund,
                        bankFundFormatted = formattedBankFund,
                        cashFundFormatted = formattedCashFund,
                        onOpenSanghRegistrations = onNavigateToSanghRegistrations,
                        onOpenFunds = onNavigateToFund,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        } else {
            // 2. Collapsible Header & Banners: Allotment & History (Visible for Regular User)
            item {
                val arrowRotation by animateFloatAsState(
                    targetValue = if (isAllotmentAndHistoryExpanded) 180f else 0f,
                    animationSpec = tween(durationMillis = 300),
                    label = "allotment_history_arrow_rotation"
                )

                Surface(
                    onClick = { isAllotmentAndHistoryExpanded = !isAllotmentAndHistoryExpanded },
                    shape = RoundedCornerShape(10.dp),
                    color = Color.Transparent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 0.dp)
                        .testTag("toggle_allotment_history_header")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 0.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "Allotment & History",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    fontSize = 15.sp,
                                    letterSpacing = 0.15.sp
                                )
                            )
                        }

                        IconButton(
                            onClick = { isAllotmentAndHistoryExpanded = !isAllotmentAndHistoryExpanded },
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("toggle_allotment_history_arrow")
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isAllotmentAndHistoryExpanded) "Hide Allotment & History" else "Show Allotment & History",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .size(24.dp)
                                    .rotate(arrowRotation)
                            )
                        }
                    }
                }
            }

            // 3. Dual Slanted Interlocking Banners: Allotments & Registration History
            item {
                AnimatedVisibility(
                    visible = isAllotmentAndHistoryExpanded,
                    enter = fadeIn(animationSpec = tween(350)) +
                            expandVertically(
                                expandFrom = Alignment.Top,
                                animationSpec = tween(350)
                            ) +
                            slideInVertically(
                                initialOffsetY = { -it / 2 },
                                animationSpec = tween(350)
                            ),
                    exit = fadeOut(animationSpec = tween(300)) +
                            shrinkVertically(
                                shrinkTowards = Alignment.Top,
                                animationSpec = tween(300)
                            ) +
                            slideOutVertically(
                                targetOffsetY = { -it / 2 },
                                animationSpec = tween(300)
                            )
                ) {
                    DualSlantedAllotmentHistoryBanners(
                        allottedSanghCount = allottedSanghCount,
                        allottedSwadhyaiCount = allottedSwadhyaiCount,
                        historyCount = allRegistrationHistories.size,
                        onOpenAllotments = onNavigateToSanghAllotted,
                        onOpenRegistrationHistory = onNavigateToRegistrationHistory,
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // 4. Timeline Section Title (if any posts or clean divider)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Timeline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Timeline & Updates",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                )
            }
        }

        // 5. Timeline Feed Posts (Latest on top, scrollable)
        if (allTimelinePosts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Campaign,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = "No timeline updates yet",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = AppTextMuted
                            )
                        )
                        Text(
                            text = "Tap the + button to share an update or announcement",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted.copy(alpha = 0.8f)
                            ),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(
                items = allTimelinePosts,
                key = { post -> "${post.id}_${post.photoUris.hashCode()}_${post.dateEpochMillis}_${post.heading.hashCode()}_${post.subHeading.hashCode()}_${post.description.hashCode()}" }
            ) { post ->
                key(post.id, post.photoUris, post.heading, post.description, post.dateEpochMillis) {
                    TimelinePostCard(
                        post = post,
                        isAdmin = session.isAdmin,
                        onOpenGallery = { photos, startIdx, boundsMap ->
                            galleryPhotos = photos
                            galleryInitialIndex = startIdx
                            gallerySourceBounds = boundsMap
                        },
                        onEditPost = { postToEdit ->
                            editingPost = postToEdit
                        },
                        onDeletePost = { postId ->
                            viewModel.deleteTimelinePost(postId)
                        },
                        onGyanPostClick = { categoryId, topicId ->
                            // 1. Mark as viewed immediately so the card dismisses from the local timeline feed
                            com.example.utils.GyanSeenTracker.markTopicSeen(context, topicId, post.dateEpochMillis)
                            com.example.utils.GyanNotificationHelper.markGyanTopicAsViewed(
                                context = context,
                                categoryId = categoryId,
                                topicId = topicId,
                                editTimestamp = post.dateEpochMillis
                            )
                            // 2. Clear any lingering system notification for this topic
                            com.example.utils.GyanNotificationHelper.dismissTopicNotification(
                                context = context,
                                topicId = topicId
                            )
                            // 3. Navigate straight to Gyan Shala category and highlight note
                            onNavigateToGyanShala?.invoke(categoryId, topicId)
                        }
                    )
                }
            }
        }
    }

    if (showCreatePostDialog) {
        CreateTimelinePostDialog(
            onDismiss = { showCreatePostDialog = false },
            onSubmit = { heading, subHeading, description, dateMillis, photos ->
                viewModel.addTimelinePost(
                    heading = heading,
                    subHeading = subHeading,
                    description = description,
                    dateMillis = dateMillis,
                    photoUris = photos
                )
                showCreatePostDialog = false
            }
        )
    }

    editingPost?.let { targetPost ->
        key(targetPost.id) {
            CreateTimelinePostDialog(
                initialPost = targetPost,
                onDismiss = { editingPost = null },
                onSubmit = { heading, subHeading, description, dateMillis, photos ->
                    viewModel.updateTimelinePost(
                        post = targetPost,
                        heading = heading,
                        subHeading = subHeading,
                        description = description,
                        dateMillis = dateMillis,
                        photoUris = photos
                    )
                    editingPost = null
                }
            )
        }
    }

    galleryPhotos?.let { photos ->
        FullscreenPhotoGalleryDialog(
            photos = photos,
            initialIndex = galleryInitialIndex,
            sourceBounds = gallerySourceBounds,
            onDismiss = {
                galleryPhotos = null
                gallerySourceBounds = null
            }
        )
    }
}
}

/**
 * Dual Slanted Home Banners for Sangh Registrations & Total Funds
 * Matches the shape, theme, glowing borders, and geometry of Paryushan Countdown & Tithi Banners.
 */
@Composable
fun DualSlantedSanghFundBanners(
    sanghCount: Int,
    allottedSanghCount: Int,
    allottedSwadhyaiCount: Int,
    totalFundFormatted: String,
    bankFundFormatted: String,
    cashFundFormatted: String,
    onOpenSanghRegistrations: () -> Unit,
    onOpenFunds: () -> Unit,
    modifier: Modifier = Modifier
) {
    val leftShape = remember { SlantedLeftCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }
    val rightShape = remember { SlantedRightCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .height(112.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 1. LEFT CARD: SANGH REGISTRATIONS (1f weight)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(leftShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF2C0B18),
                            Color(0xFF1C060F),
                            Color(0xFF100308)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFF06292).copy(alpha = 0.85f),
                            Color(0xFFAD1457).copy(alpha = 0.5f),
                            Color(0xFF4A0826).copy(alpha = 0.3f)
                        )
                    ),
                    shape = leftShape
                )
                .clickable { onOpenSanghRegistrations() }
                .padding(start = 12.dp, top = 7.dp, bottom = 7.dp, end = 14.dp)
                .testTag("card_sangh_registrations"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF06292).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Description,
                            contentDescription = null,
                            tint = Color(0xFFF48FB1),
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = "Sangh Registrations",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8BBD0),
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Center Count Display
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "$sanghCount",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFF80AB),
                            fontSize = 23.sp,
                            lineHeight = 24.sp
                        )
                    )
                    Column(modifier = Modifier.padding(bottom = 1.dp)) {
                        Text(
                            text = "REGISTERED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF48FB1),
                                fontSize = 8.5.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Shree Sangh",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted,
                                fontSize = 9.sp
                            )
                        )
                    }
                }

                // Bottom: Allotted Sangh and Swadhyai counts
                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = Color(0xFF4A0E27).copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFFF06292).copy(alpha = 0.35f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "Allotted: $allottedSanghCount",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFD1DC),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "•",
                            color = Color(0xFFF06292).copy(alpha = 0.7f),
                            fontSize = 8.sp
                        )
                        Text(
                            text = "$allottedSwadhyaiCount Swadhyai",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFE4EC),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // 2. RIGHT CARD: FUNDS (1f weight)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(rightShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF042129),
                            Color(0xFF02161C),
                            Color(0xFF010B0E)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF26C6DA).copy(alpha = 0.85f),
                            Color(0xFF00838F).copy(alpha = 0.5f),
                            Color(0xFF00363A).copy(alpha = 0.3f)
                        )
                    ),
                    shape = rightShape
                )
                .clickable { onOpenFunds() }
                .padding(start = 18.dp, top = 7.dp, bottom = 7.dp, end = 10.dp)
                .testTag("card_fund"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge shifted slightly rightwards to avoid slanted boundary
                Row(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF26C6DA).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.VolunteerActivism,
                            contentDescription = null,
                            tint = Color(0xFF4DD0E1),
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = "Funds",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB2EBF2),
                            fontSize = 11.sp
                        )
                    )
                }

                // Center Total Fund Display
                Row(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val fundFontSize = when {
                        totalFundFormatted.length <= 6 -> 20.sp
                        totalFundFormatted.length <= 9 -> 16.5.sp
                        else -> 14.sp
                    }
                    Text(
                        text = totalFundFormatted,
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFE0F7FA),
                            fontSize = fundFontSize,
                            lineHeight = (fundFontSize.value + 1).sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Column(modifier = Modifier.padding(bottom = 1.dp)) {
                        Text(
                            text = "TOTAL",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF80DEEA),
                                fontSize = 8.5.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                    }
                }

                // Bottom Bank & Cash in Hand Pill
                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = Color(0xFF0A3944).copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFF26C6DA).copy(alpha = 0.35f)),
                    modifier = Modifier.padding(start = 5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "Bank: $bankFundFormatted",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFB2EBF2),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "•",
                            color = Color(0xFF26C6DA).copy(alpha = 0.7f),
                            fontSize = 8.sp
                        )
                        Text(
                            text = "Cash: $cashFundFormatted",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE0F7FA),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

/**
 * Dual Slanted Home Banners for Allotments & Registration History (for Regular Users)
 * Matches the geometry, glowing borders, and visual polish of the admin banners.
 */
@Composable
fun DualSlantedAllotmentHistoryBanners(
    allottedSanghCount: Int,
    allottedSwadhyaiCount: Int,
    historyCount: Int,
    onOpenAllotments: () -> Unit,
    onOpenRegistrationHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val leftShape = remember { SlantedLeftCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }
    val rightShape = remember { SlantedRightCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .height(112.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 1. LEFT CARD: ALLOTMENTS (1f weight) - Matching Admin Left Card (Magenta / Pink theme)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(leftShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF2C0B18),
                            Color(0xFF1C060F),
                            Color(0xFF100308)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFF06292).copy(alpha = 0.85f),
                            Color(0xFFAD1457).copy(alpha = 0.5f),
                            Color(0xFF4A0826).copy(alpha = 0.3f)
                        )
                    ),
                    shape = leftShape
                )
                .clickable { onOpenAllotments() }
                .padding(start = 12.dp, top = 7.dp, bottom = 7.dp, end = 14.dp)
                .testTag("card_allotments"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFF06292).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AssignmentTurnedIn,
                            contentDescription = null,
                            tint = Color(0xFFF48FB1),
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = "Allotments",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFF8BBD0),
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Center Count Display
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "$allottedSanghCount",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFF80AB),
                            fontSize = 23.sp,
                            lineHeight = 24.sp
                        )
                    )
                    Column(modifier = Modifier.padding(bottom = 1.dp)) {
                        Text(
                            text = "ALLOTTED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFF48FB1),
                                fontSize = 8.5.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = "Shree Sangh",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted,
                                fontSize = 9.sp
                            )
                        )
                    }
                }

                // Bottom: Allotted Sangh and Swadhyai counts
                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = Color(0xFF4A0E27).copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFFF06292).copy(alpha = 0.35f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "Allotted: $allottedSanghCount",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFD1DC),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = "•",
                            color = Color(0xFFF06292).copy(alpha = 0.7f),
                            fontSize = 8.sp
                        )
                        Text(
                            text = "$allottedSwadhyaiCount Swadhyai",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFE4EC),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }

        // 2. RIGHT CARD: REGISTRATION HISTORY (1f weight) - Matching Admin Right Card (Cyan / Teal theme)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(rightShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF042129),
                            Color(0xFF02161C),
                            Color(0xFF010B0E)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF26C6DA).copy(alpha = 0.85f),
                            Color(0xFF00838F).copy(alpha = 0.5f),
                            Color(0xFF00363A).copy(alpha = 0.3f)
                        )
                    ),
                    shape = rightShape
                )
                .clickable { onOpenRegistrationHistory() }
                .padding(start = 18.dp, top = 7.dp, bottom = 7.dp, end = 10.dp)
                .testTag("card_registration_history"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge
                Row(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF26C6DA).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HistoryEdu,
                            contentDescription = null,
                            tint = Color(0xFF4DD0E1),
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = "Registration History",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB2EBF2),
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Center Count / Year Display
                Row(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = if (historyCount > 0) "$historyCount" else "0",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFE0F7FA),
                            fontSize = 23.sp,
                            lineHeight = 24.sp
                        )
                    )
                    Column(modifier = Modifier.padding(bottom = 1.dp)) {
                        Text(
                            text = "ARCHIVED",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF80DEEA),
                                fontSize = 8.5.sp,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Text(
                            text = if (historyCount == 1) "Past Year" else "Past Years",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppTextMuted,
                                fontSize = 9.sp
                            )
                        )
                    }
                }

                // Bottom badge
                Surface(
                    shape = RoundedCornerShape(5.dp),
                    color = Color(0xFF0A3944).copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFF26C6DA).copy(alpha = 0.35f)),
                    modifier = Modifier.padding(start = 5.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = if (historyCount > 0) "$historyCount Years Records" else "View Past Records",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFB2EBF2),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}
