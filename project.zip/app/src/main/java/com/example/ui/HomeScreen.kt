package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.ui.components.ParyushanCalendarSection
import com.example.ui.components.TodayTithiAndEventCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: FormViewModel,
    onNavigateToNewForm: () -> Unit,
    onNavigateToSanghRegistrations: () -> Unit,
    onNavigateToSwadhyaiRegistrations: () -> Unit,
    onNavigateToSanghAllotted: () -> Unit,
    onNavigateToFund: () -> Unit,
    onNavigateToPanchang: () -> Unit,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val forms by viewModel.filteredForms.collectAsStateWithLifecycle()
    val swadhyaiForms by viewModel.filteredSwadhyaiForms.collectAsStateWithLifecycle()
    val allAllotments by viewModel.allAllotments.collectAsStateWithLifecycle()
    val totalFund by viewModel.totalFund.collectAsStateWithLifecycle()
    val allPanchangEvents by viewModel.allPanchangEvents.collectAsStateWithLifecycle()

    val formattedTotalFund = remember(totalFund) {
        val formatter = java.text.NumberFormat.getCurrencyInstance(java.util.Locale("en", "IN"))
        formatter.maximumFractionDigits = 0
        formatter.format(totalFund).replace("\u00A0", "").replace("₹ ", "₹").trim()
    }

    val allottedCount = remember(allAllotments, swadhyaiForms) {
        val swadhyaiMap = swadhyaiForms.associateBy { it.id }
        allAllotments.count { allotment ->
            allotment.swadhyaiIds.split(",")
                .mapNotNull { it.trim().toLongOrNull() }
                .any { swadhyaiMap.containsKey(it) }
        }
    }
    val isDark = true

    val sanghGradient = if (isDark) listOf(AppTertiaryMaroon, AppTertiaryMaroonDeep)
    else listOf(LightTertiaryMaroon, LightTertiaryMaroonDeep)

    val swadhyaiGradient = if (isDark) listOf(AppSecondaryGreen, AppSecondaryGreenDeep)
    else listOf(LightSecondaryGreen, LightSecondaryGreenDeep)

    val allottedGradient = if (isDark) listOf(AppPrimaryGold, AppPrimaryGoldDeep)
    else listOf(LightPrimaryGold, LightPrimaryGoldDeep)

    val fundsGradient = if (isDark) listOf(AppQuaternaryTeal, AppQuaternaryTealDeep)
    else listOf(LightQuaternaryTeal, LightQuaternaryTealDeep)

    LaunchedEffect(Unit) {
        viewModel.refreshCloudData()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "श्री वर्द्धमान स्वाध्याय संघ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "।। जिन आज्ञा परमो धर्मः ।।",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                actions = {
                    IconButton(
                        onClick = onNavigateToSettings,
                        modifier = Modifier.testTag("top_settings_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings / सेटिंग्स",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(bottom = 110.dp, top = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. Paryushan Countdown Card (Compact)
            item {
                ParyushanCalendarSection(
                    allEvents = allPanchangEvents,
                    onOpenPanchang = onNavigateToPanchang
                )
            }

            // 1b. Today's Tithi and Kalyanak/Event Card (Compact)
            item {
                TodayTithiAndEventCard(
                    allEvents = allPanchangEvents,
                    onOpenPanchang = onNavigateToPanchang
                )
            }

            // 2. 4 Rounded Corner Blocks (3:4 aspect ratio)
            // Grid Row 1: Sangh Registrations & Swadhyai Registrations
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    HomeCategory34Card(
                        titleEnglish = "Sangh Registrations",
                        countText = "${forms.size}",
                        icon = Icons.Default.Description,
                        gradientColors = sanghGradient,
                        onClick = onNavigateToSanghRegistrations,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_sangh_registrations")
                    )

                    HomeCategory34Card(
                        titleEnglish = "Swadhyai Registrations",
                        countText = "${swadhyaiForms.size}",
                        icon = Icons.Default.GroupAdd,
                        gradientColors = swadhyaiGradient,
                        onClick = onNavigateToSwadhyaiRegistrations,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_swadhyai_registrations")
                    )
                }
            }

            // Grid Row 2: Sangh Allotted & Fund
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    HomeCategory34Card(
                        titleEnglish = "Sangh Allotted",
                        countText = "$allottedCount",
                        icon = Icons.Default.AssignmentTurnedIn,
                        gradientColors = allottedGradient,
                        onClick = onNavigateToSanghAllotted,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_sangh_allotted")
                    )

                    HomeCategory34Card(
                        titleEnglish = "Funds",
                        countText = formattedTotalFund,
                        icon = Icons.Default.VolunteerActivism,
                        gradientColors = fundsGradient,
                        onClick = onNavigateToFund,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("card_fund")
                    )
                }
            }
        }
    }
}

/**
 * Custom Clean 3:4 Aspect Ratio Category Block
 */
@Composable
fun HomeCategory34Card(
    titleEnglish: String,
    countText: String,
    icon: ImageVector,
    gradientColors: List<Color>,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .aspectRatio(3f / 4f)
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .border(
                width = 1.dp,
                color = MaterialTheme.colorScheme.outline,
                shape = RoundedCornerShape(20.dp)
            ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(colors = gradientColors))
                .padding(horizontal = 10.dp, vertical = 12.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 1. Card logo on top left corner
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color.White.copy(alpha = 0.22f),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                }

                // 2. Counting in center with bigger text & glowing glass effect
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    val dynamicFontSize = when {
                        countText.length <= 3 -> 44.sp
                        countText.length <= 5 -> 34.sp
                        countText.length <= 8 -> 29.sp   // 5-digit currency e.g. ₹52,900
                        countText.length <= 10 -> 24.sp  // 6-digit currency e.g. ₹1,52,900
                        countText.length <= 12 -> 20.sp  // 7-digit currency e.g. ₹15,52,900
                        else -> 17.sp
                    }
                    val letterSpacing = if (countText.length > 6) (-0.3).sp else 0.sp
                    val horizontalPadding = when {
                        countText.length > 10 -> 6.dp
                        countText.length > 7 -> 8.dp
                        else -> 12.dp
                    }
                    val verticalPadding = if (countText.length > 8) 4.dp else 6.dp

                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White.copy(alpha = 0.16f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            Color.White.copy(alpha = 0.35f)
                        ),
                        modifier = Modifier.padding(vertical = 2.dp)
                    ) {
                        Text(
                            text = countText,
                            style = androidx.compose.ui.text.TextStyle(
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = dynamicFontSize,
                                letterSpacing = letterSpacing,
                                brush = Brush.linearGradient(
                                    colors = listOf(
                                        Color.White,
                                        Color(0xFFFFF59D)
                                    )
                                ),
                                shadow = androidx.compose.ui.graphics.Shadow(
                                    color = Color.Black.copy(alpha = 0.35f),
                                    offset = androidx.compose.ui.geometry.Offset(2f, 4f),
                                    blurRadius = 8f
                                )
                            ),
                            textAlign = TextAlign.Center,
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = horizontalPadding, vertical = verticalPadding)
                        )
                    }
                }

                // 3. Card text in English at bottom - center aligned in one line
                Text(
                    text = titleEnglish,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 13.sp,
                        letterSpacing = 0.2.sp
                    ),
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
