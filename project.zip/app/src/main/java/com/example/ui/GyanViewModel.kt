package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.GyanCategoryEntity
import com.example.data.GyanTopicEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GyanViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "GyanViewModel"
    private val gyanDao = AppDatabase.getDatabase(application).gyanDao()
    private val firestore = try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }

    private var categoryFirestoreListener: ListenerRegistration? = null
    private var topicFirestoreListener: ListenerRegistration? = null

    val categories: StateFlow<List<GyanCategoryEntity>> = gyanDao.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTopics: StateFlow<List<GyanTopicEntity>> = gyanDao.getAllTopics()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedCategory = MutableStateFlow<GyanCategoryEntity?>(null)
    val highlightedTopicId = MutableStateFlow<Long?>(null)

    fun navigateToCategoryAndTopic(categoryId: Long, topicId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            val cat = gyanDao.getCategoryById(categoryId)
            if (cat != null) {
                selectedCategory.value = cat
                if (topicId > 0) {
                    highlightedTopicId.value = topicId
                }
            }
        }
    }

    fun clearHighlightedTopic() {
        highlightedTopicId.value = null
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    val topicsForSelectedCategory: StateFlow<List<GyanTopicEntity>> = selectedCategory
        .flatMapLatest { cat ->
            if (cat != null) {
                gyanDao.getTopicsForCategory(cat.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isAiLoading = MutableStateFlow(false)
    val liveSuggestions = MutableStateFlow<List<VisualSuggestion>>(GyanAiSuggester.allStandardVisuals.take(6))

    init {
        seedInitialCategoriesIfEmpty()
        startFirestoreSync()
    }

    private fun seedInitialCategoriesIfEmpty() {
        viewModelScope.launch(Dispatchers.IO) {
            val count = gyanDao.getCategoryCount()
            if (count == 0) {
                val defaultCategories = listOf(
                    GyanCategoryEntity(
                        name = "Navkar Mahamantra",
                        visualType = "EMOJI",
                        visualValue = "🕉️",
                        colorHex = "#FF9933",
                        description = "Meaning and significance of Shri Navkar Mahamantra",
                        orderIndex = 1,
                        createdAt = 0L,
                        updatedAt = 0L
                    ),
                    GyanCategoryEntity(
                        name = "Agam & Literature",
                        visualType = "EMOJI",
                        visualValue = "📖",
                        colorHex = "#C1861F",
                        description = "Jain Agams, Sutras and spiritual scriptures",
                        orderIndex = 2,
                        createdAt = 0L,
                        updatedAt = 0L
                    ),
                    GyanCategoryEntity(
                        name = "Samayik & Pratikraman",
                        visualType = "EMOJI",
                        visualValue = "🧘",
                        colorHex = "#2E7D32",
                        description = "Meditation practices, sutras and daily rituals",
                        orderIndex = 3,
                        createdAt = 0L,
                        updatedAt = 0L
                    ),
                    GyanCategoryEntity(
                        name = "Jain Tattvagyan",
                        visualType = "EMOJI",
                        visualValue = "💡",
                        colorHex = "#1976D2",
                        description = "Nine Tattvas, Six Dravyas and Karma theory",
                        orderIndex = 4,
                        createdAt = 0L,
                        updatedAt = 0L
                    ),
                    GyanCategoryEntity(
                        name = "Bhaktamar Stotra",
                        visualType = "EMOJI",
                        visualValue = "📜",
                        colorHex = "#8D6E63",
                        description = "Shri Bhaktamar Stotra verses and spiritual meanings",
                        orderIndex = 5,
                        createdAt = 0L,
                        updatedAt = 0L
                    ),
                    GyanCategoryEntity(
                        name = "Moral Values",
                        visualType = "EMOJI",
                        visualValue = "🌟",
                        colorHex = "#9C27B0",
                        description = "Inspiring stories and spiritual sanskar",
                        orderIndex = 6,
                        createdAt = 0L,
                        updatedAt = 0L
                    )
                )
                gyanDao.insertCategories(defaultCategories)

                // Add starter topics for Navkar Mantra
                val navkar = gyanDao.getAllCategories().first().firstOrNull { it.name.contains("Navkar") }
                val starterTopics = if (navkar != null) {
                    val topics = listOf(
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Arihantanam",
                            content = "I bow to the Arihantas, the liberated souls who have attained omniscience and conquered inner passions.",
                            subtext = "First Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX",
                            createdAt = 0L,
                            updatedAt = 0L
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Siddhanam",
                            content = "I bow to the Siddhas, the fully liberated souls residing in the state of eternal bliss and purity.",
                            subtext = "Second Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX",
                            createdAt = 0L,
                            updatedAt = 0L
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Aayariyanam",
                            content = "I bow to the Acharyas, the spiritual guides and leaders who maintain monastic discipline.",
                            subtext = "Third Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX",
                            createdAt = 0L,
                            updatedAt = 0L
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Uvajjhayanam",
                            content = "I bow to the Upadhyayas, the revered spiritual preceptors and teachers of sacred wisdom.",
                            subtext = "Fourth Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX",
                            createdAt = 0L,
                            updatedAt = 0L
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Loe Savva Sahunam",
                            content = "I bow to all Sadhus and Sadhvis across the universe who steadfastly observe the five great vows.",
                            subtext = "Fifth Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX",
                            createdAt = 0L,
                            updatedAt = 0L
                        )
                    )
                    gyanDao.insertTopics(topics)
                    topics
                } else {
                    emptyList()
                }

                // Immediately mark all default starter items as seen so a fresh install never shows red dots
                com.example.utils.GyanSeenTracker.markAllExistingAsSeen(getApplication(), defaultCategories, starterTopics)
            }
        }
    }

    private fun getLongField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String): Long? {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Number -> return v.toLong()
                    is com.google.firebase.Timestamp -> return v.toDate().time
                    is String -> {
                        val parsed = v.trim().toLongOrNull()
                        if (parsed != null) return parsed
                    }
                    is Boolean -> return if (v) 1L else 0L
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun getBooleanField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String, default: Boolean = false): Boolean {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Boolean -> return v
                    is Number -> return v.toLong() != 0L
                    is String -> {
                        val lower = v.trim().lowercase()
                        if (lower == "true" || lower == "1" || lower == "yes") return true
                        if (lower == "false" || lower == "0" || lower == "no") return false
                    }
                }
            } catch (_: Exception) {}
        }
        return default
    }

    private fun getStringField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            try {
                val value = doc.get(key)
                if (value != null) {
                    if (value is List<*>) {
                        val joined = value.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
                        if (joined.isNotBlank()) return joined
                    }
                    val str = value.toString().trim()
                    if (str.isNotBlank() && str != "[]" && str != "null" && str != "{}") return str
                }
            } catch (_: Exception) {}
        }
        return ""
    }

    private fun startFirestoreSync() {
        val fs = firestore ?: return
        try {
            // Realtime Sync for Gyan Categories
            categoryFirestoreListener = fs.collection("gyan_categories")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore category sync error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        viewModelScope.launch(Dispatchers.IO) {
                            val cloudCategories = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val id = getLongField(doc, "id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val name = getStringField(doc, "name")
                                    val visualType = getStringField(doc, "visualType").ifBlank { "EMOJI" }
                                    val visualValue = getStringField(doc, "visualValue").ifBlank { "📖" }
                                    val colorHex = getStringField(doc, "colorHex").ifBlank { "#C1861F" }
                                    val description = getStringField(doc, "description")
                                    val orderIndex = (getLongField(doc, "orderIndex") ?: 0L).toInt()
                                    val isDeleted = getBooleanField(doc, "isDeleted")
                                    val createdAt = getLongField(doc, "createdAt", "created_at") ?: 0L
                                    val updatedAt = getLongField(doc, "updatedAt", "updated_at") ?: 0L

                                    if (isDeleted) {
                                        gyanDao.deleteCategoryById(id)
                                        null
                                    } else {
                                        GyanCategoryEntity(
                                            id = id,
                                            name = name,
                                            visualType = visualType,
                                            visualValue = visualValue,
                                            colorHex = colorHex,
                                            description = description,
                                            orderIndex = orderIndex,
                                            createdAt = createdAt,
                                            updatedAt = updatedAt
                                        )
                                    }
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (cloudCategories.isNotEmpty()) {
                                gyanDao.insertCategories(cloudCategories)
                                com.example.utils.GyanSeenTracker.checkAndMarkInitialInstallSeen(getApplication(), cloudCategories)
                            }
                        }
                    }
                }

            // Realtime Sync for Topics
            topicFirestoreListener = fs.collection("gyan_topics")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore topic sync error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        viewModelScope.launch(Dispatchers.IO) {
                            for (dc in snapshot.documentChanges) {
                                if (dc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED ||
                                    dc.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED) {
                                    val doc = dc.document
                                    val isDeleted = getBooleanField(doc, "isDeleted")
                                    if (!isDeleted) {
                                        val id = getLongField(doc, "id") ?: doc.id.toLongOrNull() ?: continue
                                        val categoryId = getLongField(doc, "categoryId") ?: 0L
                                        val title = getStringField(doc, "title")
                                        val content = getStringField(doc, "content")
                                        val updatedAt = getLongField(doc, "updatedAt", "updated_at") ?: 0L
                                        val isEdit = dc.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED || updatedAt > 0L
                                        val versionTime = if (updatedAt > 0L) updatedAt else (getLongField(doc, "createdAt", "created_at") ?: 0L)

                                        val docAuthorInstallId = doc.getString("authorInstallId") ?: ""
                                        val docAuthorPhone = doc.getString("authorPhone") ?: ""
                                        val currentInstallId = com.example.utils.AppInstallTracker.getInstallationId(getApplication())
                                        val currentPhone = com.example.data.UserSessionManager.sessionState.value.phone.trim()

                                        val isMyAction = (docAuthorInstallId.isNotBlank() && docAuthorInstallId == currentInstallId) ||
                                                         (docAuthorPhone.isNotBlank() && currentPhone.isNotBlank() && docAuthorPhone == currentPhone) ||
                                                         com.example.utils.GyanSeenTracker.isTopicAuthoredLocally(getApplication(), id, versionTime)

                                        if (isMyAction) {
                                            // The user who creates or edits the note must not receive any device or inside-app notification
                                            com.example.utils.GyanSeenTracker.markTopicSeen(getApplication(), id, maxOf(versionTime, System.currentTimeMillis() + 300_000L))
                                            continue
                                        }

                                        val seenTs = com.example.utils.GyanSeenTracker.getTopicSeenTimestamp(getApplication(), id)
                                        val baseline = com.example.utils.AppInstallTracker.getInstallBaselineTimestamp(getApplication())
                                        val isUnread = versionTime > 0L && versionTime > baseline && versionTime > seenTs
                                        if (isUnread) {
                                            val catName = gyanDao.getCategoryById(categoryId)?.name ?: "Gyan Shala"
                                            com.example.utils.AppNotificationHelper.notifyGyanNote(
                                                context = getApplication(),
                                                categoryId = categoryId,
                                                topicId = id,
                                                categoryName = catName,
                                                topicTitle = title,
                                                contentSnippet = content.take(120),
                                                isEdit = isEdit,
                                                eventTimestamp = versionTime,
                                                authorInstallId = docAuthorInstallId,
                                                authorPhone = docAuthorPhone
                                            )
                                        }
                                    }
                                }
                            }

                            val cloudTopics = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val id = getLongField(doc, "id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val categoryId = getLongField(doc, "categoryId") ?: return@mapNotNull null
                                    val title = getStringField(doc, "title")
                                    val content = getStringField(doc, "content")
                                    val subtext = getStringField(doc, "subtext")
                                    val textAlignment = getStringField(doc, "textAlignment").ifBlank { "LEFT" }
                                    val displayStyle = getStringField(doc, "displayStyle").ifBlank { "BOX" }
                                    val isDeleted = getBooleanField(doc, "isDeleted")
                                    val createdAt = getLongField(doc, "createdAt", "created_at") ?: 0L
                                    val updatedAt = getLongField(doc, "updatedAt", "updated_at") ?: 0L

                                    if (isDeleted) {
                                        gyanDao.deleteTopicById(id)
                                        null
                                    } else {
                                        GyanTopicEntity(
                                            id = id,
                                            categoryId = categoryId,
                                            title = title,
                                            content = content,
                                            subtext = subtext,
                                            textAlignment = textAlignment,
                                            displayStyle = displayStyle,
                                            createdAt = createdAt,
                                            updatedAt = updatedAt
                                        )
                                    }
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (cloudTopics.isNotEmpty()) {
                                gyanDao.insertTopics(cloudTopics)
                                val currentCats = gyanDao.getAllCategories().first()
                                com.example.utils.GyanSeenTracker.checkAndMarkInitialInstallSeen(getApplication(), currentCats, cloudTopics)
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start Firestore sync for Gyan Shala", e)
        }
    }

    private fun syncCategoryToFirestore(category: GyanCategoryEntity, isDeleted: Boolean = false) {
        val fs = firestore ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val docRef = fs.collection("gyan_categories").document(category.id.toString())
                val data = hashMapOf(
                    "id" to category.id,
                    "name" to category.name,
                    "visualType" to category.visualType,
                    "visualValue" to category.visualValue,
                    "colorHex" to category.colorHex,
                    "description" to category.description,
                    "orderIndex" to category.orderIndex,
                    "isDeleted" to isDeleted,
                    "createdAt" to category.createdAt,
                    "updatedAt" to (if (category.updatedAt > 0L) category.updatedAt else 0L)
                )
                docRef.set(data, SetOptions.merge())
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upload category to Firestore: ${e.message}")
            }
        }
    }

    private fun syncTopicToFirestore(
        topic: GyanTopicEntity,
        isDeleted: Boolean = false,
        broadcastToTimeline: Boolean = false,
        isEdit: Boolean = false,
        categoryName: String = ""
    ) {
        val fs = firestore ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val myInstallId = com.example.utils.AppInstallTracker.getInstallationId(getApplication())
                val myPhone = com.example.data.UserSessionManager.sessionState.value.phone.trim()

                val docRef = fs.collection("gyan_topics").document(topic.id.toString())
                val data = hashMapOf(
                    "id" to topic.id,
                    "categoryId" to topic.categoryId,
                    "title" to topic.title,
                    "content" to topic.content,
                    "subtext" to topic.subtext,
                    "textAlignment" to topic.textAlignment,
                    "displayStyle" to topic.displayStyle,
                    "isDeleted" to isDeleted,
                    "createdAt" to topic.createdAt,
                    "updatedAt" to (if (topic.updatedAt > 0L) topic.updatedAt else 0L),
                    "authorInstallId" to myInstallId,
                    "authorPhone" to myPhone
                )
                docRef.set(data, SetOptions.merge())

                // Broadcast activity update to Firestore Timeline collection if requested
                if (broadcastToTimeline && !isDeleted) {
                    val catName = if (categoryName.isNotBlank()) categoryName else {
                        gyanDao.getCategoryById(topic.categoryId)?.name ?: "Gyan Shala"
                    }
                    val now = System.currentTimeMillis()
                    val heading = if (isEdit) "Gyan Shala Note Updated" else "New Note in Gyan Shala"
                    val subHeading = "$catName • ${topic.title.ifBlank { "Study Lesson" }}"
                    val description = if (topic.subtext.isNotBlank()) {
                        "${topic.subtext}\n${topic.content.take(150)}"
                    } else {
                        topic.content.take(180)
                    }
                    val timelineDocId = "gyan_${topic.id}_${if (isEdit) "edit_$now" else "new"}"
                    val timelineData = hashMapOf(
                        "id" to now,
                        "heading" to heading,
                        "subHeading" to subHeading,
                        "description" to description,
                        "dateEpochMillis" to now,
                        "photoUris" to "",
                        "isDeleted" to false,
                        "createdAtEpochMillis" to now,
                        "isGyanShalaUpdate" to true,
                        "gyanCategoryId" to topic.categoryId,
                        "gyanTopicId" to topic.id,
                        "gyanCategoryName" to catName,
                        "gyanTopicTitle" to topic.title,
                        "isGyanEdit" to isEdit,
                        "authorInstallId" to myInstallId,
                        "authorPhone" to myPhone
                    )
                    fs.collection("timeline_posts").document(timelineDocId).set(timelineData, SetOptions.merge())
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upload topic to Firestore: ${e.message}")
            }
        }
    }

    fun onCategoryNameChanged(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            liveSuggestions.value = GyanAiSuggester.allStandardVisuals.take(6)
            return
        }
        val local = GyanAiSuggester.getLocalSuggestions(trimmed)
        liveSuggestions.value = local
    }

    fun triggerAiSuggestions(categoryName: String) {
        if (categoryName.isBlank()) return
        viewModelScope.launch {
            isAiLoading.value = true
            try {
                val aiSuggestions = GyanAiSuggester.getAiSuggestedVisuals(categoryName)
                liveSuggestions.value = aiSuggestions
            } finally {
                isAiLoading.value = false
            }
        }
    }

    fun addCategory(
        name: String,
        visualType: String = "EMOJI",
        visualValue: String = "📖",
        colorHex: String = "#C1861F",
        description: String = ""
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = gyanDao.getCategoryCount()
            val now = System.currentTimeMillis()
            val newCat = GyanCategoryEntity(
                name = name.trim(),
                visualType = visualType,
                visualValue = visualValue,
                colorHex = colorHex,
                description = description.trim(),
                orderIndex = count + 1,
                createdAt = now,
                updatedAt = 0L
            )
            val generatedId = gyanDao.insertCategory(newCat)
            val savedCategory = newCat.copy(id = generatedId)
            com.example.utils.GyanSeenTracker.markCategorySeen(getApplication(), generatedId)
            syncCategoryToFirestore(savedCategory)
        }
    }

    fun updateCategory(category: GyanCategoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val updated = category.copy(updatedAt = now)
            gyanDao.updateCategory(updated)
            if (selectedCategory.value?.id == updated.id) {
                selectedCategory.value = updated
            }
            com.example.utils.GyanSeenTracker.markCategorySeen(getApplication(), updated.id)
            syncCategoryToFirestore(updated)
        }
    }

    fun deleteCategory(category: GyanCategoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.deleteCategory(category)
            if (selectedCategory.value?.id == category.id) {
                selectedCategory.value = null
            }
            syncCategoryToFirestore(category, isDeleted = true)
        }
    }

    fun selectCategory(category: GyanCategoryEntity?) {
        selectedCategory.value = category
    }

    fun addTopic(
        title: String,
        content: String,
        subtext: String = "",
        textAlignment: String = "LEFT",
        displayStyle: String = "BOX"
    ) {
        val cat = selectedCategory.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val topic = GyanTopicEntity(
                categoryId = cat.id,
                title = title.trim(),
                content = content.trim(),
                subtext = subtext.trim(),
                textAlignment = textAlignment,
                displayStyle = displayStyle,
                createdAt = now,
                updatedAt = 0L
            )
            val id = gyanDao.insertTopic(topic)
            val savedTopic = topic.copy(id = id)
            // Mark as authored and seen by the creator on this device so creator never gets notified
            com.example.utils.GyanSeenTracker.markTopicAuthored(getApplication(), id, now)
            syncTopicToFirestore(
                topic = savedTopic,
                broadcastToTimeline = true,
                isEdit = false,
                categoryName = cat.name
            )
        }
    }

    fun updateTopic(topic: GyanTopicEntity) {
        val catName = selectedCategory.value?.name ?: ""
        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val updatedTopic = topic.copy(updatedAt = now)
            gyanDao.updateTopic(updatedTopic)
            // Mark as authored and seen by the editor on this device so editor never gets notified
            com.example.utils.GyanSeenTracker.markTopicAuthored(getApplication(), updatedTopic.id, now)
            syncTopicToFirestore(
                topic = updatedTopic,
                broadcastToTimeline = true,
                isEdit = true,
                categoryName = catName
            )
        }
    }

    fun deleteTopic(topic: GyanTopicEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.deleteTopic(topic)
            syncTopicToFirestore(topic, isDeleted = true)
        }
    }

    override fun onCleared() {
        super.onCleared()
        categoryFirestoreListener?.remove()
        topicFirestoreListener?.remove()
    }
}
