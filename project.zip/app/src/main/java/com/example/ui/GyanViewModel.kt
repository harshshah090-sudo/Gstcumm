package com.example.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.GyanCategoryEntity
import com.example.data.GyanTopicEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GyanViewModel(application: Application) : AndroidViewModel(application) {
    private val TAG = "GyanViewModel"
    private val gyanDao = AppDatabase.getDatabase(application).gyanDao()
    private val firestore = try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }

    private var categoryFirestoreListener: ListenerRegistration? = null
    private var topicFirestoreListener: ListenerRegistration? = null

    val categories: StateFlow<List<GyanCategoryEntity>> = gyanDao.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selectedCategory = MutableStateFlow<GyanCategoryEntity?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val topicsForSelectedCategory: StateFlow<List<GyanTopicEntity>> = selectedCategory
        .flatMapLatest { cat ->
            if (cat != null) {
                gyanDao.getTopicsForCategory(cat.id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isAiLoading = MutableStateFlow(false)
    val liveSuggestions = MutableStateFlow<List<VisualSuggestion>>(GyanAiSuggester.allStandardVisuals.take(6))

    init {
        seedInitialCategoriesIfEmpty()
        startFirestoreSync()
    }

    private fun seedInitialCategoriesIfEmpty() {
        viewModelScope.launch(Dispatchers.IO) {
            val count = gyanDao.getCategoryCount()
            if (count == 0) {
                val defaultCategories = listOf(
                    GyanCategoryEntity(
                        name = "Navkar Mahamantra",
                        visualType = "EMOJI",
                        visualValue = "🕉️",
                        colorHex = "#FF9933",
                        description = "Meaning and significance of Shri Navkar Mahamantra",
                        orderIndex = 1
                    ),
                    GyanCategoryEntity(
                        name = "Agam & Literature",
                        visualType = "EMOJI",
                        visualValue = "📖",
                        colorHex = "#C1861F",
                        description = "Jain Agams, Sutras and spiritual scriptures",
                        orderIndex = 2
                    ),
                    GyanCategoryEntity(
                        name = "Samayik & Pratikraman",
                        visualType = "EMOJI",
                        visualValue = "🧘",
                        colorHex = "#2E7D32",
                        description = "Meditation practices, sutras and daily rituals",
                        orderIndex = 3
                    ),
                    GyanCategoryEntity(
                        name = "Jain Tattvagyan",
                        visualType = "EMOJI",
                        visualValue = "💡",
                        colorHex = "#1976D2",
                        description = "Nine Tattvas, Six Dravyas and Karma theory",
                        orderIndex = 4
                    ),
                    GyanCategoryEntity(
                        name = "Bhaktamar Stotra",
                        visualType = "EMOJI",
                        visualValue = "📜",
                        colorHex = "#8D6E63",
                        description = "Shri Bhaktamar Stotra verses and spiritual meanings",
                        orderIndex = 5
                    ),
                    GyanCategoryEntity(
                        name = "Moral Values",
                        visualType = "EMOJI",
                        visualValue = "🌟",
                        colorHex = "#9C27B0",
                        description = "Inspiring stories and spiritual sanskar",
                        orderIndex = 6
                    )
                )
                gyanDao.insertCategories(defaultCategories)

                // Add starter topics for Navkar Mantra
                val navkar = gyanDao.getAllCategories().first().firstOrNull { it.name.contains("Navkar") }
                if (navkar != null) {
                    val starterTopics = listOf(
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Arihantanam",
                            content = "I bow to the Arihantas, the liberated souls who have attained omniscience and conquered inner passions.",
                            subtext = "First Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX"
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Siddhanam",
                            content = "I bow to the Siddhas, the fully liberated souls residing in the state of eternal bliss and purity.",
                            subtext = "Second Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX"
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Aayariyanam",
                            content = "I bow to the Acharyas, the spiritual guides and leaders who maintain monastic discipline.",
                            subtext = "Third Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX"
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Uvajjhayanam",
                            content = "I bow to the Upadhyayas, the revered spiritual preceptors and teachers of sacred wisdom.",
                            subtext = "Fourth Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX"
                        ),
                        GyanTopicEntity(
                            categoryId = navkar.id,
                            title = "Namo Loe Savva Sahunam",
                            content = "I bow to all Sadhus and Sadhvis across the universe who steadfastly observe the five great vows.",
                            subtext = "Fifth Verse",
                            textAlignment = "CENTER",
                            displayStyle = "BOX"
                        )
                    )
                    gyanDao.insertTopics(starterTopics)
                }
            }
        }
    }

    private fun startFirestoreSync() {
        val fs = firestore ?: return
        try {
            // Realtime Sync for Gyan Categories
            categoryFirestoreListener = fs.collection("gyan_categories")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore category sync error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        viewModelScope.launch(Dispatchers.IO) {
                            val cloudCategories = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val id = doc.getLong("id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val name = doc.getString("name") ?: ""
                                    val visualType = doc.getString("visualType") ?: "EMOJI"
                                    val visualValue = doc.getString("visualValue") ?: "📖"
                                    val colorHex = doc.getString("colorHex") ?: "#C1861F"
                                    val description = doc.getString("description") ?: ""
                                    val orderIndex = (doc.getLong("orderIndex") ?: 0L).toInt()
                                    val isDeleted = doc.getBoolean("isDeleted") ?: false

                                    if (isDeleted) {
                                        gyanDao.deleteCategoryById(id)
                                        null
                                    } else {
                                        GyanCategoryEntity(
                                            id = id,
                                            name = name,
                                            visualType = visualType,
                                            visualValue = visualValue,
                                            colorHex = colorHex,
                                            description = description,
                                            orderIndex = orderIndex
                                        )
                                    }
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (cloudCategories.isNotEmpty()) {
                                gyanDao.insertCategories(cloudCategories)
                            }
                        }
                    }
                }

            // Realtime Sync for Topics
            topicFirestoreListener = fs.collection("gyan_topics")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Firestore topic sync error: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && !snapshot.isEmpty) {
                        viewModelScope.launch(Dispatchers.IO) {
                            val cloudTopics = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val id = doc.getLong("id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val categoryId = doc.getLong("categoryId") ?: return@mapNotNull null
                                    val title = doc.getString("title") ?: ""
                                    val content = doc.getString("content") ?: ""
                                    val subtext = doc.getString("subtext") ?: ""
                                    val textAlignment = doc.getString("textAlignment") ?: "LEFT"
                                    val displayStyle = doc.getString("displayStyle") ?: "BOX"
                                    val isDeleted = doc.getBoolean("isDeleted") ?: false

                                    if (isDeleted) {
                                        gyanDao.deleteTopicById(id)
                                        null
                                    } else {
                                        GyanTopicEntity(
                                            id = id,
                                            categoryId = categoryId,
                                            title = title,
                                            content = content,
                                            subtext = subtext,
                                            textAlignment = textAlignment,
                                            displayStyle = displayStyle
                                        )
                                    }
                                } catch (e: Exception) {
                                    null
                                }
                            }
                            if (cloudTopics.isNotEmpty()) {
                                gyanDao.insertTopics(cloudTopics)
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start Firestore sync for Gyan Shala", e)
        }
    }

    private fun syncCategoryToFirestore(category: GyanCategoryEntity, isDeleted: Boolean = false) {
        val fs = firestore ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val docRef = fs.collection("gyan_categories").document(category.id.toString())
                val data = hashMapOf(
                    "id" to category.id,
                    "name" to category.name,
                    "visualType" to category.visualType,
                    "visualValue" to category.visualValue,
                    "colorHex" to category.colorHex,
                    "description" to category.description,
                    "orderIndex" to category.orderIndex,
                    "isDeleted" to isDeleted,
                    "updatedAt" to System.currentTimeMillis()
                )
                docRef.set(data, SetOptions.merge())
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upload category to Firestore: ${e.message}")
            }
        }
    }

    private fun syncTopicToFirestore(topic: GyanTopicEntity, isDeleted: Boolean = false) {
        val fs = firestore ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val docRef = fs.collection("gyan_topics").document(topic.id.toString())
                val data = hashMapOf(
                    "id" to topic.id,
                    "categoryId" to topic.categoryId,
                    "title" to topic.title,
                    "content" to topic.content,
                    "subtext" to topic.subtext,
                    "textAlignment" to topic.textAlignment,
                    "displayStyle" to topic.displayStyle,
                    "isDeleted" to isDeleted,
                    "updatedAt" to System.currentTimeMillis()
                )
                docRef.set(data, SetOptions.merge())
            } catch (e: Exception) {
                Log.e(TAG, "Failed to upload topic to Firestore: ${e.message}")
            }
        }
    }

    fun onCategoryNameChanged(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            liveSuggestions.value = GyanAiSuggester.allStandardVisuals.take(6)
            return
        }
        val local = GyanAiSuggester.getLocalSuggestions(trimmed)
        liveSuggestions.value = local
    }

    fun triggerAiSuggestions(categoryName: String) {
        if (categoryName.isBlank()) return
        viewModelScope.launch {
            isAiLoading.value = true
            try {
                val aiSuggestions = GyanAiSuggester.getAiSuggestedVisuals(categoryName)
                liveSuggestions.value = aiSuggestions
            } finally {
                isAiLoading.value = false
            }
        }
    }

    fun addCategory(
        name: String,
        visualType: String = "EMOJI",
        visualValue: String = "📖",
        colorHex: String = "#C1861F",
        description: String = ""
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            val count = gyanDao.getCategoryCount()
            val newCat = GyanCategoryEntity(
                name = name.trim(),
                visualType = visualType,
                visualValue = visualValue,
                colorHex = colorHex,
                description = description.trim(),
                orderIndex = count + 1
            )
            val generatedId = gyanDao.insertCategory(newCat)
            val savedCategory = newCat.copy(id = generatedId)
            syncCategoryToFirestore(savedCategory)
        }
    }

    fun updateCategory(category: GyanCategoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.updateCategory(category)
            if (selectedCategory.value?.id == category.id) {
                selectedCategory.value = category
            }
            syncCategoryToFirestore(category)
        }
    }

    fun deleteCategory(category: GyanCategoryEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.deleteCategory(category)
            if (selectedCategory.value?.id == category.id) {
                selectedCategory.value = null
            }
            syncCategoryToFirestore(category, isDeleted = true)
        }
    }

    fun selectCategory(category: GyanCategoryEntity?) {
        selectedCategory.value = category
    }

    fun addTopic(
        title: String,
        content: String,
        subtext: String = "",
        textAlignment: String = "LEFT",
        displayStyle: String = "BOX"
    ) {
        val cat = selectedCategory.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val topic = GyanTopicEntity(
                categoryId = cat.id,
                title = title.trim(),
                content = content.trim(),
                subtext = subtext.trim(),
                textAlignment = textAlignment,
                displayStyle = displayStyle
            )
            val id = gyanDao.insertTopic(topic)
            val savedTopic = topic.copy(id = id)
            syncTopicToFirestore(savedTopic)
        }
    }

    fun updateTopic(topic: GyanTopicEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.updateTopic(topic)
            syncTopicToFirestore(topic)
        }
    }

    fun deleteTopic(topic: GyanTopicEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            gyanDao.deleteTopic(topic)
            syncTopicToFirestore(topic, isDeleted = true)
        }
    }

    override fun onCleared() {
        super.onCleared()
        categoryFirestoreListener?.remove()
        topicFirestoreListener?.remove()
    }
}
