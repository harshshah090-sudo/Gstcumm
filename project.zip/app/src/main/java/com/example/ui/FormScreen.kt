package com.example.ui

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    onFormSubmitted: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    var showThankYouDialog by remember { mutableStateOf(false) }
    var submittedFormId by remember { mutableStateOf<Long?>(null) }

    // 18 State Variables - All initially UNSELECTED / EMPTY
    var q1SanghName by remember { mutableStateOf("") }
    var q2SanghAddress by remember { mutableStateOf("") }
    var q3CityName by remember { mutableStateOf("") }
    var q4Contact1 by remember { mutableStateOf("") }
    var q5Contact2 by remember { mutableStateOf("") }
    var q6MulnayakBhagwan by remember { mutableStateOf("") }
    var q7TotalFamilies by remember { mutableStateOf("") }
    var q8HasOtherSangh by remember { mutableStateOf("") }

    val gacchOptions = listOf("तपागच्छ", "खतरगच्छ", "अचलगच्छ", "स्थानक", "अन्य")
    var q9GacchList by remember { mutableStateOf(listOf<String>()) }
    var q9GacchOtherText by remember { mutableStateOf("") }

    val pratikramanOptions = listOf("तपागच्छ", "खतरगच्छ", "अचलगच्छ", "स्थानक")
    var q10PratikramanTradition by remember { mutableStateOf(listOf<String>()) }

    var q11HasMusicianGroup by remember { mutableStateOf("") }
    var q12CallsOutsideMusician by remember { mutableStateOf("") }
    var q13HasPanchPratikramanPerson by remember { mutableStateOf("") }
    var q14HasToiletFacility by remember { mutableStateOf("") }

    val samagriOptions = listOf(
        "आचार्य भगवान (स्थापना जी महिलाओं के लिए )",
        "आचार्य भगवान (स्थापना जी पुरुषों के लिए )",
        "कल्पसूत्र",
        "बारसासूत्र"
    )
    var q15SamagriList by remember { mutableStateOf(listOf<String>()) }

    var q16RaiCount by remember { mutableStateOf("") }
    var q16DevasiCount by remember { mutableStateOf("") }
    var q16PravachanCount by remember { mutableStateOf("") }
    var q16SandhyaCount by remember { mutableStateOf("") }

    var q17MainTrustees by remember { mutableStateOf("") }
    var q18AgreedToRule1 by remember { mutableStateOf(false) }
    var q18AgreedToRule2 by remember { mutableStateOf(false) }

    fun fillSampleData() {
        q1SanghName = "श्री चिंतामणि पार्श्वनाथ जैन संघ"
        q2SanghAddress = "जैन चौक, मुख्य मार्ग, रेलवे स्टेशन के निकट"
        q3CityName = "सूरत (गुजरात)"
        q4Contact1 = "महेशभाई शाह (अध्यक्ष) - 9825123456"
        q5Contact2 = "अमितकुमार दोशी (सचिव) - 9898123456"
        q6MulnayakBhagwan = "श्री चिंतामणि पार्श्वनाथ भगवान"
        q7TotalFamilies = "85"
        q8HasOtherSangh = "हाँ"
        q9GacchList = listOf("तपागच्छ")
        q9GacchOtherText = ""
        q10PratikramanTradition = listOf("तपागच्छ")
        q11HasMusicianGroup = "हाँ"
        q12CallsOutsideMusician = "नहीं"
        q13HasPanchPratikramanPerson = "हाँ"
        q14HasToiletFacility = "हाँ"
        q15SamagriList = listOf(
            "आचार्य भगवान (स्थापना जी महिलाओं के लिए )",
            "आचार्य भगवान (स्थापना जी पुरुषों के लिए )",
            "कल्पसूत्र",
            "बारसासूत्र"
        )
        q16RaiCount = "51-100 या अधिक"
        q16DevasiCount = "51-100 या अधिक"
        q16PravachanCount = "51-100 या अधिक"
        q16SandhyaCount = "51-100 या अधिक"
        q17MainTrustees = "१. शांतिलाल संघवी (9825001122)\n२. हंसमुखलाल मेहता (9426003344)\n३. भरतकुमार शाह (9898005566)"
        q18AgreedToRule1 = true
        q18AgreedToRule2 = true
        Toast.makeText(context, "नमूना डेटा भर दिया गया है!", Toast.LENGTH_SHORT).show()
    }

    if (showThankYouDialog) {
        AlertDialog(
            onDismissRequest = { },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF2E7D32),
                    modifier = Modifier.size(52.dp)
                )
            },
            title = {
                Text(
                    text = "जय जिनेन्द्र!",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    color = MaterialTheme.colorScheme.primary
                )
            },
            text = {
                Text(
                    text = "✅ आपका फॉर्म सफलतापूर्वक दर्ज कर लिया गया है!\n\nश्री वर्धमान स्वाध्यायी मंडल में आवेदन करने हेतु आपका हार्दिक धन्यवाद। पर्वाधिराज पर्यूषण महापर्व की आपकी आराधना मंगलमयी हो।",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        lineHeight = 22.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showThankYouDialog = false
                        submittedFormId?.let { id ->
                            onFormSubmitted(id)
                        } ?: onNavigateBack()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("आवेदन विवरण देखें", fontWeight = FontWeight.Bold)
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("पर्यूषण आराधना फॉर्म", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "पीछे जाएँ")
                    }
                },
                actions = {
                    TextButton(
                        onClick = { fillSampleData() },
                        modifier = Modifier.testTag("fill_sample_data_btn")
                    ) {
                        Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("नमूना भरें", fontWeight = FontWeight.Bold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            // Validation for EVERY single question
                            if (q1SanghName.isBlank()) {
                                Toast.makeText(context, "कृपया १. श्री संघ का नाम भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q2SanghAddress.isBlank()) {
                                Toast.makeText(context, "कृपया २. श्री संघ का पूरा पता भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q3CityName.isBlank()) {
                                Toast.makeText(context, "कृपया ३. आपके शहर / गांव का नाम भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q4Contact1.isBlank()) {
                                Toast.makeText(context, "कृपया ४. स्वाध्याई संपर्क (१) की जानकारी भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q5Contact2.isBlank()) {
                                Toast.makeText(context, "कृपया ५. स्वाध्याई संपर्क (२) की जानकारी भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q6MulnayakBhagwan.isBlank()) {
                                Toast.makeText(context, "कृपया ६. मुलनायक भगवान का नाम भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q7TotalFamilies.isBlank()) {
                                Toast.makeText(context, "कृपया ७. कुल परिवार संख्या भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q8HasOtherSangh.isBlank()) {
                                Toast.makeText(context, "कृपया ८. अन्य संघ के विषय में चुनें (हाँ/नहीं)", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q9GacchList.isEmpty()) {
                                Toast.makeText(context, "कृपया ९. गच्छ का चयन करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q9GacchList.contains("अन्य") && q9GacchOtherText.isBlank()) {
                                Toast.makeText(context, "कृपया ९. 'अन्य' गच्छ का नाम दर्ज करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q10PratikramanTradition.isEmpty()) {
                                Toast.makeText(context, "कृपया १०. प्रतिकमण परंपरा का चयन करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q11HasMusicianGroup.isBlank()) {
                                Toast.makeText(context, "कृपया ११. संगीतकार/मंडल के विषय में चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q12CallsOutsideMusician.isBlank()) {
                                Toast.makeText(context, "कृपया १२. बाहर से संगीतकार बुलाने के विषय में चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q13HasPanchPratikramanPerson.isBlank()) {
                                Toast.makeText(context, "कृपया १३. पंच प्रतिकमण जानने वाले व्यक्ति के विषय में चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q14HasToiletFacility.isBlank()) {
                                Toast.makeText(context, "कृपया १४. मात्रू-ठल्ले (Toilet) व्यवस्था के विषय में चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q15SamagriList.isEmpty()) {
                                Toast.makeText(context, "कृपया १५. उपलब्ध आराधना सामग्री पर टिक करें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q16RaiCount.isBlank()) {
                                Toast.makeText(context, "कृपया १६. राई प्रतिकमण उपस्थिति संख्या चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q16DevasiCount.isBlank()) {
                                Toast.makeText(context, "कृपया १६. देवसी प्रतिकमण उपस्थिति संख्या चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q16PravachanCount.isBlank()) {
                                Toast.makeText(context, "कृपया १६. प्रवचन उपस्थिति संख्या चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q16SandhyaCount.isBlank()) {
                                Toast.makeText(context, "कृपया १६. संध्या भक्ति उपस्थिति संख्या चुनें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (q17MainTrustees.isBlank()) {
                                Toast.makeText(context, "कृपया १७. मुख्य तीन अग्रणी/ट्रस्टी की जानकारी भरें", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (!q18AgreedToRule1 || !q18AgreedToRule2) {
                                Toast.makeText(context, "कृपया १८. नियम एवं शर्तों के दोनों चेकबॉक्स (✔️) स्वीकार करें", Toast.LENGTH_LONG).show()
                                return@Button
                            }

                            val finalGacchListStr = q9GacchList.map {
                                if (it == "अन्य" && q9GacchOtherText.isNotBlank()) "अन्य (${q9GacchOtherText.trim()})" else it
                            }.joinToString(", ")

                            val newForm = ParyushanFormEntity(
                                sanghName = q1SanghName.trim(),
                                sanghAddress = q2SanghAddress.trim(),
                                cityName = q3CityName.trim(),
                                contact1 = q4Contact1.trim(),
                                contact2 = q5Contact2.trim(),
                                mulnayakBhagwan = q6MulnayakBhagwan.trim(),
                                totalFamilies = q7TotalFamilies.trim(),
                                hasOtherSangh = q8HasOtherSangh,
                                gacchList = finalGacchListStr,
                                pratikramanTradition = q10PratikramanTradition.joinToString(", "),
                                hasMusicianGroup = q11HasMusicianGroup,
                                callsOutsideMusician = q12CallsOutsideMusician,
                                hasPanchPratikramanPerson = q13HasPanchPratikramanPerson,
                                hasToiletFacility = q14HasToiletFacility,
                                aradhanaSamagriList = q15SamagriList.joinToString(", "),
                                countRaiPratikraman = q16RaiCount,
                                countDevasiPratikraman = q16DevasiCount,
                                countPravachan = q16PravachanCount,
                                countSandhyaBhakti = q16SandhyaCount,
                                mainTrustees = q17MainTrustees.trim(),
                                agreedToTerms = true
                            )

                            viewModel.insertForm(newForm) { newId ->
                                submittedFormId = newId
                                showThankYouDialog = true
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("submit_form_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Icon(Icons.Default.Send, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("फॉर्म सबमिट करें", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Subtle transparent background watermark image
            Image(
                painter = painterResource(id = R.drawable.ic_group_logo),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                alpha = 0.18f,
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .aspectRatio(1f)
                    .align(Alignment.Center)
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "पर्वाधीराज पर्यूषण आराधना",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "पर्यूषणा महापर्व में आराधना करने और करवाने हेतु यह फॉर्म सही जानकारियों के साथ भर देवे।",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.9f)
                        )
                    )
                }
            }

            Text(
                text = "समस्त प्रश्नों के उत्तर ध्यानपूर्वक अंकित करें:",
                style = MaterialTheme.typography.labelLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )

            // Q1: श्री संघ का नाम
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१", "श्री संघ का नाम", true)
                    OutlinedTextField(
                        value = q1SanghName,
                        onValueChange = { q1SanghName = it },
                        placeholder = { Text("उदा. श्री श्वेतांबर जैन संघ") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q1_sangh_name"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q2: श्री संघ का पूरा पता
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("२", "श्री संघ का पूरा पता", true)
                    OutlinedTextField(
                        value = q2SanghAddress,
                        onValueChange = { q2SanghAddress = it },
                        placeholder = { Text("देरासर/उपाश्रय गली, लैंडमार्क, क्षेत्र") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q2_sangh_address"),
                        minLines = 2,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q3: आपके शहर/गांव का नाम
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("३", "आपके शहर / गांव का नाम", true)
                    OutlinedTextField(
                        value = q3CityName,
                        onValueChange = { q3CityName = it },
                        placeholder = { Text("उदा. अहमदाबाद, पाली, मुंबई") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q3_city_name"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q4: स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद और मोबाइल नंबर (१)
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("४", "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद और मोबाइल नंबर (१)", true)
                    OutlinedTextField(
                        value = q4Contact1,
                        onValueChange = { q4Contact1 = it },
                        placeholder = { Text("नाम, पद (उदा. अध्यक्ष), मोबाइल नंबर") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q4_contact1"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q5: स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद और मोबाइल नंबर (२)
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("५", "स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद और मोबाइल नंबर (२)", true)
                    OutlinedTextField(
                        value = q5Contact2,
                        onValueChange = { q5Contact2 = it },
                        placeholder = { Text("नाम, पद (उदा. मंत्री), मोबाइल नंबर") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q5_contact2"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q6: आपके संघ में मुलनायक भगवान कौन से हें?
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("६", "आपके संघ में मुलनायक भगवान कौन से हें?", true)
                    OutlinedTextField(
                        value = q6MulnayakBhagwan,
                        onValueChange = { q6MulnayakBhagwan = it },
                        placeholder = { Text("उदा. श्री शंखेश्वर पार्श्वनाथ भगवान / श्री आदिनाथ प्रभु") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q6_mulnayak_bhagwan"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q7: आपके संघ में कितने परिवार हैं
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("७", "आपके संघ में कितने परिवार हैं", true)
                    OutlinedTextField(
                        value = q7TotalFamilies,
                        onValueChange = { q7TotalFamilies = it },
                        placeholder = { Text("उदा. ५० / १००") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q7_total_families"),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q8: क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("८", "क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?", true)
                    RadioOptionGroup(
                        options = listOf("हाँ", "नहीं"),
                        selectedOption = q8HasOtherSangh,
                        onOptionSelected = { q8HasOtherSangh = it }
                    )
                }
            }

            // Q9: आपके संघ में कौन-कौन से गच्छ हैं (with 'अन्य' input textfield)
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("९", "आपके संघ में कौन-कौन से गच्छ हैं", true)
                    CheckboxOptionList(
                        allOptions = gacchOptions,
                        selectedList = q9GacchList,
                        onToggle = { item ->
                            q9GacchList = if (q9GacchList.contains(item)) {
                                q9GacchList - item
                            } else {
                                q9GacchList + item
                            }
                        }
                    )
                    if (q9GacchList.contains("अन्य")) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = q9GacchOtherText,
                            onValueChange = { q9GacchOtherText = it },
                            placeholder = { Text("अन्य गच्छ का नाम दर्ज करें...") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("q9_gacch_other_text"),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }

            // Q10: आपके संघ में कौनसी परंपरा से प्रतिकमण किया जाता है
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१०", "आपके संघ में कौनसी परंपरा से प्रतिकमण किया जाता है", true)
                    CheckboxOptionList(
                        allOptions = pratikramanOptions,
                        selectedList = q10PratikramanTradition,
                        onToggle = { item ->
                            q10PratikramanTradition = if (q10PratikramanTradition.contains(item)) {
                                q10PratikramanTradition - item
                            } else {
                                q10PratikramanTradition + item
                            }
                        }
                    )
                }
            }

            // Q11: आपके श्रीसंघ में कोई संगीतकार / मंडल है
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("११", "आपके श्रीसंघ में कोई संगीतकार / मंडल है", true)
                    RadioOptionGroup(
                        options = listOf("हाँ", "नहीं"),
                        selectedOption = q11HasMusicianGroup,
                        onOptionSelected = { q11HasMusicianGroup = it }
                    )
                }
            }

            // Q12: क्या आप बाहर से संगीतकार बुलाते हो
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१२", "क्या आप बाहर से संगीतकार बुलाते हो", true)
                    RadioOptionGroup(
                        options = listOf("हाँ", "नहीं"),
                        selectedOption = q12CallsOutsideMusician,
                        onOptionSelected = { q12CallsOutsideMusician = it }
                    )
                }
            }

            // Q13: आपके श्रीसंघ मैं ऐसा कोई व्यक्ति है जिसको पंच प्रतिकमण आता हो और वह पर्यूषण पर्व में हाजिर हो?
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१३", "आपके श्रीसंघ मैं ऐसा कोई व्यक्ति है जिसको पंच प्रतिकमण आता हो और वह पर्यूषण पर्व में हाजिर हो?", true)
                    RadioOptionGroup(
                        options = listOf("हाँ", "नहीं"),
                        selectedOption = q13HasPanchPratikramanPerson,
                        onOptionSelected = { q13HasPanchPratikramanPerson = it }
                    )
                }
            }

            // Q14: क्या आपके श्रीसंघ मैं पौषध उपयुक्त मात्रू-ठल्ले (Toilet) की व्यवस्था है?
            // Subtext: (पौषध की क्रिया करने के लिए पौषध मै उपयुक्त मात्रू-ठल्ले की व्यवस्था होना आवश्यक है)
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१४", "क्या आपके श्रीसंघ मैं पौषध उपयुक्त मात्रू-ठल्ले (Toilet) की व्यवस्था है?", true)
                    Text(
                        text = "(पौषध की क्रिया करने के लिए पौषध मै उपयुक्त मात्रू-ठल्ले की व्यवस्था होना आवश्यक है)",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    RadioOptionGroup(
                        options = listOf("हाँ", "नहीं"),
                        selectedOption = q14HasToiletFacility,
                        onOptionSelected = { q14HasToiletFacility = it }
                    )
                }
            }

            // Q15: आपके श्रीसंघ में यह आराधना सामग्री होने पर ✔️ लगाइए
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१५", "आपके श्रीसंघ में यह आराधना सामग्री होने पर ✔️ लगाइए", true)
                    CheckboxOptionList(
                        allOptions = samagriOptions,
                        selectedList = q15SamagriList,
                        onToggle = { item ->
                            q15SamagriList = if (q15SamagriList.contains(item)) {
                                q15SamagriList - item
                            } else {
                                q15SamagriList + item
                            }
                        }
                    )
                }
            }

            // Q16: पर्यूषण दौरान श्री संघ की प्रवृत्तियों में हाजिर व्यक्तियों की संख्या
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१६", "पर्यूषण दौरान श्री संघ की प्रवृत्तियों में हाजिर व्यक्तियों की संख्या", true)

                    ActivityAttendanceGridSelector(
                        activityName = "१. राई प्रतिकमण",
                        selectedCount = q16RaiCount,
                        onSelectCount = { q16RaiCount = it }
                    )
                    ActivityAttendanceGridSelector(
                        activityName = "२. देवसी प्रतिकमण",
                        selectedCount = q16DevasiCount,
                        onSelectCount = { q16DevasiCount = it }
                    )
                    ActivityAttendanceGridSelector(
                        activityName = "३. प्रवचन",
                        selectedCount = q16PravachanCount,
                        onSelectCount = { q16PravachanCount = it }
                    )
                    ActivityAttendanceGridSelector(
                        activityName = "४. संध्या भक्ति",
                        selectedCount = q16SandhyaCount,
                        onSelectCount = { q16SandhyaCount = it }
                    )
                }
            }

            // Q17: श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर
            Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(14.dp)) {
                    QuestionHeader("१७", "श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर", true)
                    OutlinedTextField(
                        value = q17MainTrustees,
                        onValueChange = { q17MainTrustees = it },
                        placeholder = { Text("१. नाम व मोबाइल नंबर\n२. नाम व मोबाइल नंबर\n३. नाम व मोबाइल नंबर") },
                        minLines = 3,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("q17_main_trustees"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }

            // Q18: नियम एवं सर्व अग्रणियों की सम्मति (Both checkboxes MANDATORY)
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    QuestionHeader("१८", "नियम एवं शर्तें", true)

                    Text(
                        text = "श्री वर्धमान स्वाध्यायी संघ पिछले कई वर्षों से ऐसे युवाओं के समूह को भेजता है जो जिनशासन की सेवा में लगे हुए हैं। ये युवा, संघों के अनुरोध पर, पर्युषण की उत्तम आराधना के लिए भेजे जाते हैं, ताकि आपके जैसे संघों में पर्वाधिराज का यह पावन पर्व और भी शुभ, आनंदमय और पुण्यदायक बन सके।",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            lineHeight = 20.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = ": नियम :",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                ),
                                modifier = Modifier.padding(bottom = 8.dp)
                            )

                            val rules = listOf(
                                "1. पर्युषण पर्व के दौरान होने वाली सभी प्रवृतियों (कल्पसूत्र वांचन, प्रतिक्रमण, पौषध, पूजन, भक्ति भावना इत्यादि कार्यक्रम) मै श्री संघ सदस्यों की ज़्यादा से ज़्यादा उपस्थिति रहे।",
                                "2. पयुर्षण पर्व के दौरान स्वामीवात्सल्य एवम पारणा इत्यादि के अंतर्गत बर्फ, द्विदल, अभक्ष्य इत्यादि वस्तुओं का उपयोग नहीं होगा।",
                                "3. पयुर्षण महापर्व के दौरान अभक्ष्य एवम अयोग्य वस्तुओं की प्रभावनाओं का उपयोग ना करे ।(बिस्किट, चॉकलेट, इत्यादि )",
                                "4. किसी भी प्रकार की अशास्त्रीय और अयोग्य पद्धति एवम क्रिया के सामने हमारी संस्था के युवान अरुचि बताए तो वह पद्धति या क्रिया अमल मैं नहीं रखी जाएगी ।",
                                "5. श्रावक और श्राविकाओं का प्रतिकमन साथ मैं नहीं होगा।\n   (अगर श्राविकाओं को प्रतीकमण विधि नहीं आती है तो श्रावक और श्राविकाओं के मध्य एक दूसरे पर दृष्टि ना पड़े ऐसा पर्दा रख कर, सिर्फ़ श्रावकों द्वारा बोले गय सूत्रो से प्रतीकमण सम्पूर्ण किया जाएगा)",
                                "6. पूजा, भक्ति-भावना इत्यादि अन्य प्रसंगों में जहाँ पुरुषो की मुख्यता होगी, वहाँ श्राविका बहेनें नृत्य नहीं कर सकेंगी।",
                                "7. आपके संघ मैं संस्था के द्वारा आने वाले स्वाध्याइ भाइयो के रहने, आने -जाने, भोजन इत्यादि की व्यस्था श्री संघ के द्वारा की जाएगी।",
                                "8. पर्युषण महा पर्व की आराधना करवाने आये हुए हमारे स्वाध्याय भाइयो को कुछ भी नगद राशि और कीमती भेट नहीं देना है।\n   (श्री संघ की शक्ति अनुसार वस्तु बहुमान स्वीकार्य है)",
                                "9. स्वाध्याइ मंडल के विकास के लिये आपको योग्य लगे उतनी राशि बहुमान स्वरूप \"श्री वर्धमान स्वाध्याय मंडल\" को बिना किसी बंधन के भेज सकते है।",
                                "10. स्वाध्याइ भाइयो को उनके क्षेत्र से आपके क्षेत्र तक आने और जाने का किराया आपके संघ को वहन करना होगा।"
                            )

                            rules.forEach { rule ->
                                Text(
                                    text = rule,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        lineHeight = 18.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    ),
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "इन सारे नियमो का चुस्त रुप से पालन होना चाहीये ।",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Mandatory Checkbox 1
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { q18AgreedToRule1 = !q18AgreedToRule1 }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = q18AgreedToRule1,
                            onCheckedChange = { q18AgreedToRule1 = it },
                            colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "आपके श्रीसंघ के तमाम अग्रणी की सर्वसम्मति से ही आप स्वाध्याई भाइयों को आराधना करवाने के लिए बुला रहे हैं",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (q18AgreedToRule1) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Mandatory Checkbox 2
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { q18AgreedToRule2 = !q18AgreedToRule2 }
                            .padding(vertical = 4.dp)
                    ) {
                        Checkbox(
                            checked = q18AgreedToRule2,
                            onCheckedChange = { q18AgreedToRule2 = it },
                            colors = CheckboxDefaults.colors(checkedColor = MaterialTheme.colorScheme.primary)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "निर्धारित किए हुए सारे नियम समस्त अग्रणियों को स्वीकार है।",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (q18AgreedToRule2) FontWeight.Bold else FontWeight.Normal,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}
}
