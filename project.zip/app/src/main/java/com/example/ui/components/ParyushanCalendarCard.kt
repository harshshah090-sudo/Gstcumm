package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JainGacch
import com.example.data.ParyushanCalendarRepository
import com.example.data.ParyushanCountdownState
import com.example.data.ParyushanPhase
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun ParyushanCalendarSection(
    onClickOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var isExpanded by remember { mutableStateOf(false) }

    // Live Ticker coroutine updating every second
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMs = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val activeState = remember(currentTimeMs) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.TAPAGACCH, currentTimeMs)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AppPrimaryGoldDeep,
                        AppBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("paryushan_calendar_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .animateContentSize()
        ) {
            // Header Row with Expand/Collapse toggle
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AppPrimaryGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "पर्वाधिराज पर्यूषण महापर्व",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = if (activeState.phase == ParyushanPhase.SAMVATSARI_ACTIVE)
                                "संवत्सरी - मिच्छामि दुक्कडम्"
                            else
                                "${activeState.daysRemaining} दिन ${activeState.hoursRemaining} घंटे शेष • ${activeState.phase.titleHindi}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }

                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "कम करें" else "और देखें",
                        tint = AppPrimaryGold
                    )
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))

                    SingleGacchFullTimerCard(state = activeState)

                    Spacer(modifier = Modifier.height(8.dp))

                    // Dates Summary Row
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AppDeepSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            DatePill(
                                label = "प्रथम दिवस",
                                date = activeState.startDateFormatted,
                                isHighlighted = activeState.phase == ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
                            )
                            DatePill(
                                label = "जन्म वांचन",
                                date = activeState.janmVanchanDateFormatted,
                                isHighlighted = activeState.phase == ParyushanPhase.MAHAVIR_JANM_VANCHAN
                            )
                            DatePill(
                                label = "संवत्सरी",
                                date = activeState.samvatsariDateFormatted,
                                isHighlighted = activeState.phase == ParyushanPhase.SAMVATSARI || activeState.phase == ParyushanPhase.SAMVATSARI_ACTIVE
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SingleGacchFullTimerCard(state: ParyushanCountdownState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AppDeepSurface, // Deep surface #141A17
                        AppSurfaceNested // Surface (nested) #212D27
                    )
                )
            )
            .border(1.dp, AppBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Phase Title Header
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = AppPrimaryGold.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.currentDayNumber > 0) {
                    Text(
                        text = "पर्यूषण दिवस ${state.currentDayNumber} सक्रिय • ",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Text(
                    text = state.phase.titleHindi,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (state.phase.subtitleHindi.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = state.phase.subtitleHindi,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AppPrimaryGold,
                    fontSize = 11.5.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))
        } else {
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (state.phase == ParyushanPhase.SAMVATSARI_ACTIVE) {
            // Samvatsari Celebration Banner
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "🙏 उत्तमा क्षमा - मिच्छामि दुक्कडम् 🙏",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "समस्त जीवराशी से मन, वचन, काया से क्षमा याचना करते हैं।",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AppTextPrimary
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            // Live 4-Block Countdown Timer
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                TimeUnitBlock(value = state.daysRemaining, label = "दिन", isHighlight = true)
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.hoursRemaining, label = "घंटे")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.minutesRemaining, label = "मिनट")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.secondsRemaining, label = "सेकंड")
            }
        }
    }
}

@Composable
private fun SingleGacchCompactTimerCard(
    state: ParyushanCountdownState,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AppSurfaceNested,
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = state.gacch.displayNameHindi,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = state.phase.titleHindi,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextPrimary,
                    fontSize = 10.sp
                ),
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactDigitBox(value = state.daysRemaining, label = "d", isHighlight = true)
                CompactDigitBox(value = state.hoursRemaining, label = "h")
                CompactDigitBox(value = state.minutesRemaining, label = "m")
                CompactDigitBox(value = state.secondsRemaining, label = "s")
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "प्रारंभ: ${state.startDateFormatted}",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppPrimaryGold,
                    fontSize = 9.5.sp
                )
            )
        }
    }
}

@Composable
private fun TimeUnitBlock(
    value: Long,
    label: String,
    isHighlight: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(58.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isHighlight) AppTertiaryMaroon else AppSurfaceNested // Tertiary accent maroon for first digit, surface nested for rest
                )
                .border(
                    width = 1.dp,
                    color = if (isHighlight) AppPrimaryGold else AppBorder,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format("%02d", value),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary,
                    fontSize = 22.sp
                )
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun CompactDigitBox(value: Long, label: String, isHighlight: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isHighlight) AppTertiaryMaroon else AppSurfaceNested,
        border = if (isHighlight) androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold) else androidx.compose.foundation.BorderStroke(1.dp, AppBorder)
    ) {
        Text(
            text = "${String.format("%02d", value)}$label",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = AppTextPrimary,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun TodayTithiCard(
    onClickOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }
    var selectedCity by remember { mutableStateOf(com.example.data.JainCityManager.getSelectedCity(context)) }
    var showCityDialog by remember { mutableStateOf(false) }

    val cal = remember { java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Asia/Kolkata")) }
    val yr = cal.get(java.util.Calendar.YEAR)
    val mo = cal.get(java.util.Calendar.MONTH) + 1
    val dy = cal.get(java.util.Calendar.DAY_OF_MONTH)

    val panchang = remember(yr, mo, dy, selectedCity) {
        com.example.data.JainPanchangRepository.getDayPanchang(yr, mo, dy, selectedCity)
    }

    if (showCityDialog) {
        CitySelectionDialog(
            currentCity = selectedCity,
            onCitySelected = { newCity ->
                selectedCity = newCity
                com.example.data.JainCityManager.setSelectedCity(context, newCity)
            },
            onDismissRequest = { showCityDialog = false }
        )
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AppPrimaryGold,
                        AppBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("today_tithi_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .animateContentSize()
        ) {
            // Header Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { isExpanded = !isExpanded }
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AppPrimaryGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "आज की जैन तिथि",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = "$dy/$mo/$yr • ${panchang.tithiName}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (panchang.paksha == "सुद") Color(0xFF1B5E20) else Color(0xFF4A148C),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, Color.White.copy(alpha = 0.5f))
                    ) {
                        Text(
                            text = if (panchang.paksha == "सुद") "सुदि" else "वदि",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    IconButton(
                        onClick = { isExpanded = !isExpanded },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isExpanded) "कम करें" else "और देखें",
                            tint = AppPrimaryGold
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))

                    // Location / City Selector Strip
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AppPrimaryGold.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(0.8.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCityDialog = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "स्थान: ${panchang.cityName}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    )
                                )
                            }
                            Text(
                                text = "शहर बदलें ▾",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppPrimaryGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.5.sp
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Main Tithi Highlight Banner
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = AppDeepSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = panchang.tithiName,
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = AppPrimaryGold,
                                    fontSize = 20.sp
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${panchang.masNameHindi} ${if (panchang.paksha == "सुद") "सुदि (शुक्ल पक्ष)" else "वदि (कृष्ण पक्ष)"}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = AppTextMuted,
                                    fontSize = 12.sp
                                )
                            )

                            Spacer(modifier = Modifier.height(10.dp))
                            HorizontalDivider(color = AppBorder.copy(alpha = 0.4f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                DetailPill(label = "विक्रम संवत", value = "सं. ${panchang.vikramSamvat}")
                                DetailPill(label = "वीर नि. संवत", value = "वीर ${panchang.vikramSamvat + 470}")
                                DetailPill(label = "मास (महीना)", value = panchang.masNameHindi)
                                DetailPill(label = "पक्ष", value = if (panchang.paksha == "सुद") "सुदि" else "वदि")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Timings Grid (4 Timings: Sunrise, Sunset, Navkarsi, Chauvihar)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AppSurfaceNested,
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, AppBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("सूर्योदय", fontSize = 9.5.sp, color = AppTextMuted)
                                Text(panchang.sunriseTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AppSurfaceNested,
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, AppBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("सूर्यास्त", fontSize = 9.5.sp, color = AppTextMuted)
                                Text(panchang.sunsetTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AppSurfaceNested,
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, AppBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("नवकारसी", fontSize = 9.5.sp, color = AppTextMuted)
                                Text(panchang.navkarsiTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AppSurfaceNested,
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, AppBorder),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(
                                modifier = Modifier.padding(6.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("चौविहार", fontSize = 9.5.sp, color = AppTextMuted)
                                Text(panchang.chauviharTime, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold)
                            }
                        }
                    }

                    if (panchang.events.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AppTertiaryMaroon.copy(alpha = 0.25f),
                            border = androidx.compose.foundation.BorderStroke(0.8.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Star,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "विशेष: " + panchang.events.joinToString(" | ") { it.titleHindi },
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = AppTextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.5.sp
                                    ),
                                    maxLines = 1
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Action Footer
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = AppPrimaryGold.copy(alpha = 0.12f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onClickOpenPanchang?.invoke() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "👉 विस्तृत जैन पंचांग एवं कैलेंडर खोलें",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppPrimaryGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp
                                )
                            )
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = null,
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailPill(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontSize = 10.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = AppPrimaryGold,
                fontSize = 11.5.sp
            )
        )
    }
}

@Composable
private fun DatePill(
    label: String,
    date: String,
    isHighlighted: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isHighlighted) AppPrimaryGold else AppTextMuted,
                fontSize = 10.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isHighlighted) AppTertiaryMaroon else AppSurfaceNested
        ) {
            Text(
                text = date,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
