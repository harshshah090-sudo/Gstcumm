package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JainGacch
import com.example.data.PanchangEventEntity
import com.example.data.ParyushanCalendarRepository
import com.example.data.ParyushanCountdownState
import com.example.data.ParyushanPhase
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ParyushanCalendarSection(
    onOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Live Ticker coroutine updating every second
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var isExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMs = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val activeState = remember(currentTimeMs) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.TAPAGACCH, currentTimeMs)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AppPrimaryGoldDeep,
                        AppBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("paryushan_calendar_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize()
                .clickable { isExpanded = !isExpanded }
                .padding(12.dp)
        ) {
            // Top Header: Title + Compact Countdown + Expand Down Arrow Icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AppPrimaryGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "पर्वाधिराज पर्यूषण महापर्व",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary,
                                fontSize = 14.5.sp
                            )
                        )
                        Text(
                            text = "${activeState.daysRemaining}d ${activeState.hoursRemaining}h ${activeState.minutesRemaining}m • ${activeState.startDateFormatted}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }

                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(12.dp))

                SingleGacchFullTimerCard(state = activeState)

                Spacer(modifier = Modifier.height(10.dp))

                // Dates Summary Row
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DatePill(
                            label = "प्रथम दिवस",
                            date = activeState.startDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
                        )
                        DatePill(
                            label = "जन्म वांचन",
                            date = activeState.janmVanchanDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.MAHAVIR_JANM_VANCHAN
                        )
                        DatePill(
                            label = "संवत्सरी",
                            date = activeState.samvatsariDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.SAMVATSARI || activeState.phase == ParyushanPhase.SAMVATSARI_ACTIVE
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TodayTithiAndEventCard(
    allEvents: List<PanchangEventEntity>,
    onOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    val todayFormattedEnglish = remember {
        SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
    }

    val todayEvent = remember(allEvents, todayDateString) {
        allEvents.find { it.dateString == todayDateString }
    }

    val displayTithi = remember(todayEvent) {
        if (!todayEvent?.tithi.isNullOrBlank()) todayEvent!!.tithi else "श्रावण वद अमावास्या"
    }

    val displayKalyanak = remember(todayEvent) {
        todayEvent?.kalyanaks?.ifBlank { null }
    }

    val displayParva = remember(todayEvent) {
        todayEvent?.parvasAndEvents?.ifBlank { null }
    }

    val samvatInfo = remember(todayDateString) {
        val parts = todayDateString.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val month = parts.getOrNull(1)?.toIntOrNull() ?: 8
        val vs = if (month >= 11) year + 57 + 1 else year + 57
        val vns = if (month >= 11) year + 526 + 1 else year + 526

        fun toDevanagari(num: Int): String {
            val digits = charArrayOf('०', '१', '२', '३', '४', '५', '६', '७', '८', '९')
            return num.toString().map { digits[it - '0'] }.joinToString("")
        }

        Pair("वि. सं. ${toDevanagari(vs)} ($vs)", "वीर सं. ${toDevanagari(vns)} ($vns)")
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AppSecondaryGreen,
                        AppBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onOpenPanchang?.invoke() }
            .testTag("today_tithi_event_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Main Top Row: Calendar Icon + Tithi + Date + Chevron Right Arrow
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(AppSecondaryGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = AppSecondaryGreen,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = displayTithi,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppPrimaryGold,
                                fontSize = 16.sp
                            )
                        )
                        Text(
                            text = todayFormattedEnglish,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppTextPrimary,
                                fontSize = 12.sp
                            )
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Open Panchang",
                    tint = AppTextMuted,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Samvat Row: Vikram Samvat & Veer Nirvana Samvat
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(AppDeepSurface, shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = samvatInfo.first,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp
                    )
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        fontSize = 11.5.sp
                    )
                )
                Text(
                    text = samvatInfo.second,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppSecondaryGreen,
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp
                    )
                )
            }

            // Show Kalyanak if present (empty if none)
            if (displayKalyanak != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF2E220D),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFB300).copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "✨ कल्याणक: $displayKalyanak",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFFFFB300),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Show Special Event/Parva if present (empty if none)
            if (displayParva != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF2B1D38),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCE93D8).copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "🚩 पर्व/उत्सव: $displayParva",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFFCE93D8),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Sunrise/Navkarsi/Sunset timings row if available
            if (!todayEvent?.sunriseTime.isNullOrBlank() || !todayEvent?.sunsetTime.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!todayEvent?.sunriseTime.isNullOrBlank()) {
                        Text("☀️ सूर्योदय: ${todayEvent.sunriseTime}", fontSize = 11.sp, color = AppTextPrimary)
                    }
                    if (!todayEvent?.navkarsiTime.isNullOrBlank()) {
                        Text("🌅 नवकारशी: ${todayEvent.navkarsiTime}", fontSize = 11.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                    }
                    if (!todayEvent?.sunsetTime.isNullOrBlank()) {
                        Text("🌇 सूर्यास्त: ${todayEvent.sunsetTime}", fontSize = 11.sp, color = AppTextPrimary)
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRowItem(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = AppTextMuted,
                fontSize = 11.5.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = valueColor,
                fontSize = 12.sp,
                textAlign = TextAlign.End
            ),
            modifier = Modifier.widthIn(max = 220.dp)
        )
    }
}

@Composable
private fun SingleGacchFullTimerCard(state: ParyushanCountdownState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AppDeepSurface, // Deep surface #141A17
                        AppSurfaceNested // Surface (nested) #212D27
                    )
                )
            )
            .border(1.dp, AppBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Phase Title Header
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = AppPrimaryGold.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.currentDayNumber > 0) {
                    Text(
                        text = "पर्यूषण दिवस ${state.currentDayNumber} सक्रिय • ",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Text(
                    text = state.phase.titleHindi,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (state.phase.subtitleHindi.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = state.phase.subtitleHindi,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AppPrimaryGold,
                    fontSize = 11.5.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))
        } else {
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (state.phase == ParyushanPhase.SAMVATSARI_ACTIVE) {
            // Samvatsari Celebration Banner
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "🙏 उत्तमा क्षमा - मिच्छामि दुक्कडम् 🙏",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "समस्त जीवराशी से मन, वचन, काया से क्षमा याचना करते हैं।",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AppTextPrimary
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            // Live 4-Block Countdown Timer
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                TimeUnitBlock(value = state.daysRemaining, label = "दिन", isHighlight = true)
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.hoursRemaining, label = "घंटे")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.minutesRemaining, label = "मिनट")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.secondsRemaining, label = "सेकंड")
            }
        }
    }
}

@Composable
private fun SingleGacchCompactTimerCard(
    state: ParyushanCountdownState,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AppSurfaceNested,
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = state.gacch.displayNameHindi,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = state.phase.titleHindi,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextPrimary,
                    fontSize = 10.sp
                ),
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactDigitBox(value = state.daysRemaining, label = "d", isHighlight = true)
                CompactDigitBox(value = state.hoursRemaining, label = "h")
                CompactDigitBox(value = state.minutesRemaining, label = "m")
                CompactDigitBox(value = state.secondsRemaining, label = "s")
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "प्रारंभ: ${state.startDateFormatted}",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppPrimaryGold,
                    fontSize = 9.5.sp
                )
            )
        }
    }
}

@Composable
private fun TimeUnitBlock(
    value: Long,
    label: String,
    isHighlight: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(58.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isHighlight) AppTertiaryMaroon else AppSurfaceNested // Tertiary accent maroon for first digit, surface nested for rest
                )
                .border(
                    width = 1.dp,
                    color = if (isHighlight) AppPrimaryGold else AppBorder,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format("%02d", value),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary,
                    fontSize = 22.sp
                )
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun CompactDigitBox(value: Long, label: String, isHighlight: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isHighlight) AppTertiaryMaroon else AppSurfaceNested,
        border = if (isHighlight) androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold) else androidx.compose.foundation.BorderStroke(1.dp, AppBorder)
    ) {
        Text(
            text = "${String.format("%02d", value)}$label",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = AppTextPrimary,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun DatePill(
    label: String,
    date: String,
    isHighlighted: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isHighlighted) AppPrimaryGold else AppTextMuted,
                fontSize = 10.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isHighlighted) AppTertiaryMaroon else AppSurfaceNested
        ) {
            Text(
                text = date,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
