package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JainGacch
import com.example.data.PanchangEventEntity
import com.example.data.ParyushanCalendarRepository
import com.example.data.ParyushanCountdownState
import com.example.data.ParyushanPhase
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.min

/**
 * Creates a rounded polygon path given vertices in clockwise order and a corner radius.
 */
fun createRoundedPolygonPath(vertices: List<Offset>, radius: Float): Path {
    val path = Path()
    val n = vertices.size
    if (n < 3) return path

    for (i in 0 until n) {
        val curr = vertices[i]
        val prev = vertices[(i - 1 + n) % n]
        val next = vertices[(i + 1) % n]

        val dPrevX = prev.x - curr.x
        val dPrevY = prev.y - curr.y
        val lenPrev = hypot(dPrevX, dPrevY)

        val dNextX = next.x - curr.x
        val dNextY = next.y - curr.y
        val lenNext = hypot(dNextX, dNextY)

        if (lenPrev < 0.001f || lenNext < 0.001f) continue

        val maxR = min(radius, min(lenPrev, lenNext) / 2.5f)

        val pStartX = curr.x + (dPrevX / lenPrev) * maxR
        val pStartY = curr.y + (dPrevY / lenPrev) * maxR

        val pEndX = curr.x + (dNextX / lenNext) * maxR
        val pEndY = curr.y + (dNextY / lenNext) * maxR

        if (i == 0) {
            path.moveTo(pStartX, pStartY)
        } else {
            path.lineTo(pStartX, pStartY)
        }
        path.quadraticTo(curr.x, curr.y, pEndX, pEndY)
    }
    path.close()
    return path
}

/**
 * Custom Slanted Card Shape (Left side: Top-Right extends, Right side slants down-left)
 * with rounded corners.
 */
class SlantedLeftCardShape(
    private val slantOffsetDp: Float = 26f,
    private val cornerRadiusDp: Float = 14f
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val slantOffsetPx = with(density) { slantOffsetDp.dp.toPx() }
        val radiusPx = with(density) { cornerRadiusDp.dp.toPx() }
        val w = size.width
        val h = size.height

        val vertices = listOf(
            Offset(0f, 0f),
            Offset(w, 0f),
            Offset(w - slantOffsetPx, h),
            Offset(0f, h)
        )
        return Outline.Generic(createRoundedPolygonPath(vertices, radiusPx))
    }
}

/**
 * Custom Slanted Card Shape (Right side: Left side slants down-left parallel to Left Card)
 * with rounded corners.
 */
class SlantedRightCardShape(
    private val slantOffsetDp: Float = 26f,
    private val cornerRadiusDp: Float = 14f
) : Shape {
    override fun createOutline(
        size: Size,
        layoutDirection: LayoutDirection,
        density: Density
    ): Outline {
        val slantOffsetPx = with(density) { slantOffsetDp.dp.toPx() }
        val radiusPx = with(density) { cornerRadiusDp.dp.toPx() }
        val w = size.width
        val h = size.height

        val vertices = listOf(
            Offset(slantOffsetPx, 0f),
            Offset(w, 0f),
            Offset(w, h),
            Offset(0f, h)
        )
        return Outline.Generic(createRoundedPolygonPath(vertices, radiusPx))
    }
}

/**
 * Dual Slanted Home Banners (Paryushan Countdown + Today's Tithi & Special Event)
 * Placed side-by-side with interlocking diagonal curved geometry as sketched.
 */
@Composable
fun DualSlantedHomeBanners(
    allEvents: List<PanchangEventEntity> = emptyList(),
    onOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMs = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val activeState = remember(currentTimeMs, allEvents) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.TAPAGACCH, currentTimeMs, allEvents)
    }

    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    val todayEvent = remember(allEvents, todayDateString) {
        allEvents.find { it.dateString == todayDateString }
    }

    val displayTithi = remember(todayEvent) {
        if (!todayEvent?.tithi.isNullOrBlank()) todayEvent!!.tithi else "श्रावण वद बारस"
    }

    val specialEventText = remember(todayEvent) {
        when {
            !todayEvent?.parvasAndEvents.isNullOrBlank() -> todayEvent!!.parvasAndEvents
            !todayEvent?.kalyanaks.isNullOrBlank() -> todayEvent!!.kalyanaks
            else -> null
        }
    }

    val leftShape = remember { SlantedLeftCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }
    val rightShape = remember { SlantedRightCardShape(slantOffsetDp = 18f, cornerRadiusDp = 12f) }

    val (tithiPrefix, tithiMain) = remember(displayTithi) {
        var clean = displayTithi
            .replace(Regex("\\s*\\([^)]*\\)"), "") // Remove bracketed numbers like (७), (7), (२), etc.
            .replace(Regex("[0-9०-९()]"), "")      // Remove any standalone numbers or brackets
            .trim()

        val romanToHindi = listOf(
            "Ekam" to "एकम", "Bij" to "बीज", "Teej" to "तीज", "Choth" to "चौथ",
            "Pancham" to "पंचमी", "Chhath" to "छठ", "Satam" to "सातम", "Aatham" to "आठम",
            "Atham" to "आठम", "Nom" to "नोम", "Dasham" to "दशम", "Agiyaras" to "ग्यारस",
            "Gyaras" to "ग्यारस", "Baras" to "बारस", "Terash" to "तेरस", "Teras" to "तेरस",
            "Chaudas" to "चौदस", "Poonam" to "पूनम", "Purnima" to "पूर्णिमा",
            "Amavasya" to "अमावस्या", "Amavas" to "अमावस्या"
        )
        for ((roman, hindi) in romanToHindi) {
            clean = clean.replace(Regex("(?i)\\b$roman\\b"), hindi)
        }

        clean = clean
            .replace("सुदि", "सुदी")
            .replace("वदि", "वदी")
            .replace(Regex("\\s+"), " ")
            .trim()

        val parts = clean.split(" ").filter { it.isNotBlank() }
        if (parts.size >= 3) {
            val prefix = parts.subList(0, parts.size - 1).joinToString(" ")
            val main = parts.last()
            Pair(prefix, main)
        } else if (parts.size == 2) {
            Pair(parts[0], parts[1])
        } else {
            Pair("", clean)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 2.dp)
            .height(106.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        // 1. LEFT CARD: PARYUSHAN COUNTDOWN (1f weight)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(leftShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF2A1C0A),
                            Color(0xFF1B1207),
                            Color(0xFF100B04)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFFFFD54F).copy(alpha = 0.85f),
                            Color(0xFFC1861F).copy(alpha = 0.5f),
                            Color(0xFF422C0A).copy(alpha = 0.3f)
                        )
                    ),
                    shape = leftShape
                )
                .clickable { onOpenPanchang?.invoke() }
                .padding(start = 12.dp, top = 7.dp, bottom = 7.dp, end = 14.dp)
                .testTag("paryushan_slanted_countdown_card"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(AppPrimaryGold.copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                    Text(
                        text = "पर्यूषण महापर्व",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFE082),
                            fontSize = 11.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Center Content: Active Day Details vs Completed vs Hero Countdown
                if (activeState.phase == ParyushanPhase.PARYUSHAN_ACTIVE) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 1.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = activeState.activeDayMainText,
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFFFD54F),
                                fontSize = 21.sp,
                                lineHeight = 22.sp
                            ),
                            maxLines = 1
                        )
                        Text(
                            text = activeState.activeDaySubText,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFE082),
                                fontSize = 10.5.sp,
                                lineHeight = 13.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Bottom Active Day Pill
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = Color(0xFF3E280C).copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFFFFD54F).copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = "दिवस ${activeState.currentDayNumber} सक्रिय • पावन पर्व",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFECB3),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else if (activeState.phase == ParyushanPhase.PARYUSHAN_COMPLETED) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "पर्यूषण पर्व समाप्त 🙏🏻",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD54F),
                                fontSize = 13.sp,
                                lineHeight = 16.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "मिच्छामि दुक्कडम्",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFE082),
                                fontWeight = FontWeight.Medium,
                                fontSize = 10.sp
                            ),
                            maxLines = 1
                        )
                    }

                    // Bottom Completed Pill
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = Color(0xFF3E280C).copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFFFFD54F).copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = "पर्व संपन्न • उत्तम क्षमा",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFECB3),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 8.5.sp
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                } else {
                    // Center Hero Countdown
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "${activeState.daysRemaining}",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.Black,
                                color = Color(0xFFFFD54F),
                                fontSize = 23.sp,
                                lineHeight = 24.sp
                            )
                        )
                        Column(modifier = Modifier.padding(bottom = 1.dp)) {
                            Text(
                                text = "DAYS LEFT",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFFCA28),
                                    fontSize = 8.5.sp,
                                    letterSpacing = 0.5.sp
                                )
                            )
                            Text(
                                text = "${activeState.hoursRemaining}h ${activeState.minutesRemaining}m",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppTextMuted,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }

                    // Bottom Start Date Pill
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = Color(0xFF3E280C).copy(alpha = 0.75f),
                        border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFFFFD54F).copy(alpha = 0.35f))
                    ) {
                        Text(
                            text = "प्रारंभ: ${activeState.startDateFormatted}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFFFECB3),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 9.sp
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }

        // 2. RIGHT CARD: TODAY'S TITHI & SPECIAL EVENT (1f weight)
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .clip(rightShape)
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF09261C),
                            Color(0xFF061A13),
                            Color(0xFF030E0A)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0xFF48CA97).copy(alpha = 0.85f),
                            Color(0xFF1E6B4F).copy(alpha = 0.5f),
                            Color(0xFF0A3324).copy(alpha = 0.3f)
                        )
                    ),
                    shape = rightShape
                )
                .clickable { onOpenPanchang?.invoke() }
                .padding(start = 18.dp, top = 7.dp, bottom = 7.dp, end = 10.dp)
                .testTag("tithi_slanted_card"),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header badge shifted slightly rightwards to avoid slanted boundary
                Row(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF48CA97).copy(alpha = 0.22f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = Color(0xFF48CA97),
                            modifier = Modifier.size(10.dp)
                        )
                    }
                    Text(
                        text = "आज की तिथि",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFA7F3D0),
                            fontSize = 11.sp
                        )
                    )
                }

                // Center Tithi Display (Prefix in regular size, Tithi day in bigger bold font)
                Column(
                    modifier = Modifier.padding(start = 5.dp),
                    verticalArrangement = Arrangement.spacedBy(0.5.dp)
                ) {
                    if (tithiPrefix.isNotBlank()) {
                        Text(
                            text = tithiPrefix,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFFA7F3D0),
                                fontSize = 11.sp,
                                lineHeight = 12.sp
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Text(
                        text = tithiMain,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Black,
                            color = Color(0xFFFFFFFF),
                            fontSize = 16.5.sp,
                            lineHeight = 18.sp
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Bottom: Special Event / Festival only
                if (!specialEventText.isNullOrBlank()) {
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = Color(0xFF0F3B2C),
                        border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFF48CA97).copy(alpha = 0.45f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Star,
                                contentDescription = null,
                                tint = Color(0xFFFFD54F),
                                modifier = Modifier.size(9.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = specialEventText,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFFFE082),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                } else {
                    Surface(
                        shape = RoundedCornerShape(5.dp),
                        color = Color(0xFF0A2B20).copy(alpha = 0.65f),
                        border = androidx.compose.foundation.BorderStroke(0.7.dp, Color(0xFF48CA97).copy(alpha = 0.25f))
                    ) {
                        Text(
                            text = "विशेष पर्व: कोई नहीं",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFF81C784),
                                fontWeight = FontWeight.Normal,
                                fontSize = 9.sp
                            ),
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.5.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ParyushanCalendarSection(
    allEvents: List<PanchangEventEntity> = emptyList(),
    onOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Live Ticker coroutine updating every second
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var isExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            currentTimeMs = System.currentTimeMillis()
            delay(1000L)
        }
    }

    val activeState = remember(currentTimeMs, allEvents) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.TAPAGACCH, currentTimeMs, allEvents)
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(16.dp))
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        AppPrimaryGoldDeep,
                        AppBorder
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
            .testTag("paryushan_calendar_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize()
                .clickable { isExpanded = !isExpanded }
                .padding(12.dp)
        ) {
            // Top Header: Title + Compact Countdown + Expand Down Arrow Icon
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(AppPrimaryGold.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "पर्वाधिराज पर्यूषण महापर्व",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary,
                                fontSize = 14.5.sp
                            )
                        )
                        Text(
                            text = when (activeState.phase) {
                                ParyushanPhase.PARYUSHAN_ACTIVE ->
                                    "${activeState.activeDayMainText}: ${activeState.activeDaySubText}"
                                ParyushanPhase.PARYUSHAN_COMPLETED ->
                                    "पर्यूषण पर्व समाप्त 🙏🏻"
                                else ->
                                    "${activeState.daysRemaining}d ${activeState.hoursRemaining}h ${activeState.minutesRemaining}m • ${activeState.startDateFormatted}"
                            },
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }

                IconButton(
                    onClick = { isExpanded = !isExpanded },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(12.dp))

                SingleGacchFullTimerCard(state = activeState)

                Spacer(modifier = Modifier.height(10.dp))

                // Dates Summary Row
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        DatePill(
                            label = "प्रथम दिवस",
                            date = activeState.startDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
                        )
                        DatePill(
                            label = "जन्म वांचन",
                            date = activeState.janmVanchanDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.MAHAVIR_JANM_VANCHAN
                        )
                        DatePill(
                            label = "संवत्सरी",
                            date = activeState.samvatsariDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.SAMVATSARI || activeState.phase == ParyushanPhase.SAMVATSARI_ACTIVE
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TodayTithiAndEventCard(
    allEvents: List<PanchangEventEntity>,
    onOpenPanchang: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    val todayFormattedEnglish = remember {
        SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
    }

    val todayEvent = remember(allEvents, todayDateString) {
        allEvents.find { it.dateString == todayDateString }
    }

    val displayTithi = remember(todayEvent) {
        if (!todayEvent?.tithi.isNullOrBlank()) todayEvent!!.tithi else "श्रावण वद अमावास्या"
    }

    val displayKalyanak = remember(todayEvent) {
        todayEvent?.kalyanaks?.ifBlank { null }
    }

    val displayParva = remember(todayEvent) {
        todayEvent?.parvasAndEvents?.ifBlank { null }
    }

    val samvatInfo = remember(todayDateString) {
        val parts = todayDateString.split("-")
        val year = parts.getOrNull(0)?.toIntOrNull() ?: 2026
        val month = parts.getOrNull(1)?.toIntOrNull() ?: 8
        val vs = if (month >= 11) year + 57 + 1 else year + 57
        val vns = if (month >= 11) year + 526 + 1 else year + 526

        fun toDevanagari(num: Int): String {
            val digits = charArrayOf('०', '१', '२', '३', '४', '५', '६', '७', '८', '९')
            return num.toString().map { digits[it - '0'] }.joinToString("")
        }

        Pair("वि. सं. ${toDevanagari(vs)} ($vs)", "वीर सं. ${toDevanagari(vns)} ($vns)")
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF0F2F24),
                        Color(0xFF091612),
                        Color(0xFF050707)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF5FD6A8).copy(alpha = 0.5f),
                        Color(0xFF1F7A72).copy(alpha = 0.3f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .clickable { onOpenPanchang?.invoke() }
            .testTag("today_tithi_event_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.Transparent
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(15.dp)
        ) {
            // Main Top Row: Calendar Icon + Tithi + Date + Chevron Right Arrow
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0F2F24))
                            .border(1.dp, Color(0xFF5FD6A8).copy(alpha = 0.4f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = null,
                            tint = Color(0xFF5FD6A8),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = displayTithi,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEAFFF2),
                                fontSize = 17.sp
                            )
                        )
                        Text(
                            text = todayFormattedEnglish,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFFA9D9C2),
                                fontSize = 12.sp
                            )
                        )
                    }
                }

                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Open Panchang",
                    tint = Color(0xFF5FD6A8),
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Samvat Row: Vikram Samvat & Veer Nirvana Samvat (Onyx & Jade styling)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF091812))
                    .border(1.dp, Color(0xFF5FD6A8).copy(alpha = 0.25f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = samvatInfo.first,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF8FC9AC),
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.5.sp
                    )
                )
                Text(
                    text = "•",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF5FD6A8).copy(alpha = 0.5f),
                        fontSize = 11.5.sp
                    )
                )
                Text(
                    text = samvatInfo.second,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color(0xFF5FD6A8),
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.5.sp
                    )
                )
            }

            // Show Kalyanak if present (empty if none)
            if (displayKalyanak != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF14291F),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5FD6A8).copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "✨ कल्याणक: $displayKalyanak",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFF7EFFC9),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Show Special Event/Parva if present (empty if none)
            if (displayParva != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF262013),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD4A24C).copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "🚩 पर्व/उत्सव: $displayParva",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFFFFD573),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            // Sunrise/Navkarsi/Sunset timings row if available
            if (!todayEvent?.sunriseTime.isNullOrBlank() || !todayEvent?.sunsetTime.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!todayEvent?.sunriseTime.isNullOrBlank()) {
                        Text("☀️ सूर्योदय: ${todayEvent.sunriseTime}", fontSize = 11.sp, color = Color(0xFFA9D9C2))
                    }
                    if (!todayEvent?.navkarsiTime.isNullOrBlank()) {
                        Text("🌅 नवकारशी: ${todayEvent.navkarsiTime}", fontSize = 11.sp, color = Color(0xFF5FD6A8), fontWeight = FontWeight.Bold)
                    }
                    if (!todayEvent?.sunsetTime.isNullOrBlank()) {
                        Text("🌇 सूर्यास्त: ${todayEvent.sunsetTime}", fontSize = 11.sp, color = Color(0xFFA9D9C2))
                    }
                }
            }
        }
    }
}

@Composable
private fun DetailRowItem(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = AppTextMuted,
                fontSize = 11.5.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.Bold,
                color = valueColor,
                fontSize = 12.sp,
                textAlign = TextAlign.End
            ),
            modifier = Modifier.widthIn(max = 220.dp)
        )
    }
}

@Composable
private fun SingleGacchFullTimerCard(state: ParyushanCountdownState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        AppDeepSurface, // Deep surface #141A17
                        AppSurfaceNested // Surface (nested) #212D27
                    )
                )
            )
            .border(1.dp, AppBorder, RoundedCornerShape(16.dp))
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Phase Title Header
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = AppPrimaryGold.copy(alpha = 0.15f),
            border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.currentDayNumber > 0) {
                    Text(
                        text = "पर्यूषण दिवस ${state.currentDayNumber} सक्रिय • ",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Text(
                    text = state.phase.titleHindi,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppTextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        if (state.phase.subtitleHindi.isNotBlank()) {
            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = state.phase.subtitleHindi,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = AppPrimaryGold,
                    fontSize = 11.5.sp
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))
        } else {
            Spacer(modifier = Modifier.height(6.dp))
        }

        if (state.phase == ParyushanPhase.PARYUSHAN_ACTIVE) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp)
            ) {
                Text(
                    text = state.activeDayMainText,
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFFD54F),
                        fontSize = 24.sp
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = state.activeDaySubText,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFE082),
                        fontSize = 16.sp
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(14.dp))
                // Live 4-Block Countdown Timer to next sunrise
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TimeUnitBlock(value = state.daysRemaining, label = "दिन", isHighlight = true)
                    Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TimeUnitBlock(value = state.hoursRemaining, label = "घंटे")
                    Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TimeUnitBlock(value = state.minutesRemaining, label = "मिनट")
                    Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    TimeUnitBlock(value = state.secondsRemaining, label = "सेकंड")
                }
            }
        } else if (state.phase == ParyushanPhase.PARYUSHAN_COMPLETED) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp)
            ) {
                Text(
                    text = "पर्यूषण पर्व समाप्त 🙏🏻",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD54F),
                        fontSize = 21.sp
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "🙏 उत्तम क्षमा - मिच्छामि दुक्कडम् 🙏",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AppTextPrimary,
                        fontWeight = FontWeight.SemiBold
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else if (state.phase == ParyushanPhase.SAMVATSARI_ACTIVE) {
            // Samvatsari Celebration Banner
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "🙏 उत्तमा क्षमा - मिच्छामि दुक्कडम् 🙏",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "समस्त जीवराशी से मन, वचन, काया से क्षमा याचना करते हैं।",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = AppTextPrimary
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            // Live 4-Block Countdown Timer
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                TimeUnitBlock(value = state.daysRemaining, label = "दिन", isHighlight = true)
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.hoursRemaining, label = "घंटे")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.minutesRemaining, label = "मिनट")
                Text(":", color = AppPrimaryGold, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.secondsRemaining, label = "सेकंड")
            }
        }
    }
}

@Composable
private fun SingleGacchCompactTimerCard(
    state: ParyushanCountdownState,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = AppSurfaceNested,
        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = state.gacch.displayNameHindi,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (state.phase == ParyushanPhase.PARYUSHAN_ACTIVE) {
                Text(
                    text = state.activeDayMainText,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD54F)
                    ),
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = state.activeDaySubText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFFFE082),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CompactDigitBox(value = state.daysRemaining, label = "d", isHighlight = true)
                    CompactDigitBox(value = state.hoursRemaining, label = "h")
                    CompactDigitBox(value = state.minutesRemaining, label = "m")
                    CompactDigitBox(value = state.secondsRemaining, label = "s")
                }
            } else if (state.phase == ParyushanPhase.PARYUSHAN_COMPLETED) {
                Text(
                    text = "पर्यूषण पर्व समाप्त 🙏🏻",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD54F),
                        fontSize = 11.5.sp
                    ),
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "मिच्छामि दुक्कडम्",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFFFE082),
                        fontSize = 9.5.sp
                    ),
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
            } else {
                Text(
                    text = state.phase.titleHindi,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppTextPrimary,
                        fontSize = 10.sp
                    ),
                    maxLines = 1,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CompactDigitBox(value = state.daysRemaining, label = "d", isHighlight = true)
                    CompactDigitBox(value = state.hoursRemaining, label = "h")
                    CompactDigitBox(value = state.minutesRemaining, label = "m")
                    CompactDigitBox(value = state.secondsRemaining, label = "s")
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "प्रारंभ: ${state.startDateFormatted}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = AppPrimaryGold,
                        fontSize = 9.5.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun TimeUnitBlock(
    value: Long,
    label: String,
    isHighlight: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(58.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isHighlight) AppTertiaryMaroon else AppSurfaceNested // Tertiary accent maroon for first digit, surface nested for rest
                )
                .border(
                    width = 1.dp,
                    color = if (isHighlight) AppPrimaryGold else AppBorder,
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format("%02d", value),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary,
                    fontSize = 22.sp
                )
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = AppTextMuted,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun CompactDigitBox(value: Long, label: String, isHighlight: Boolean = false) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isHighlight) AppTertiaryMaroon else AppSurfaceNested,
        border = if (isHighlight) androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold) else androidx.compose.foundation.BorderStroke(1.dp, AppBorder)
    ) {
        Text(
            text = "${String.format("%02d", value)}$label",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = AppTextPrimary,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun DatePill(
    label: String,
    date: String,
    isHighlighted: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isHighlighted) AppPrimaryGold else AppTextMuted,
                fontSize = 10.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isHighlighted) AppTertiaryMaroon else AppSurfaceNested
        ) {
            Text(
                text = date,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
