package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.JainGacch
import com.example.data.ParyushanCalendarRepository
import com.example.data.ParyushanCountdownState
import com.example.data.ParyushanPhase
import kotlinx.coroutines.delay

@Composable
fun ParyushanCalendarSection(
    modifier: Modifier = Modifier
) {
    var selectedGacch by remember { mutableStateOf(JainGacch.TAPAGACCH) }
    var showDualMode by remember { mutableStateOf(false) }
    var isItineraryExpanded by remember { mutableStateOf(false) }
    
    // Test mode state for easy testing
    var simulatedTimeOffsetMs by remember { mutableLongStateOf(0L) }
    var activeTestPhaseLabel by remember { mutableStateOf("वास्तविक समय (Live)") }

    // Live Ticker coroutine updating every second
    var currentTimeMs by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(simulatedTimeOffsetMs) {
        while (true) {
            currentTimeMs = System.currentTimeMillis() + simulatedTimeOffsetMs
            delay(1000L)
        }
    }

    val tapagacchState = remember(currentTimeMs) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.TAPAGACCH, currentTimeMs)
    }

    val kharatargacchState = remember(currentTimeMs) {
        ParyushanCalendarRepository.getCountdownState(JainGacch.KHARATARGACCH, currentTimeMs)
    }

    val activeState = if (selectedGacch == JainGacch.TAPAGACCH) tapagacchState else kharatargacchState

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(RoundedCornerShape(20.dp))
            .border(
                width = 1.5.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFFD4A24C),
                        Color(0xFF8C2020)
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .testTag("paryushan_calendar_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF181210) // Deep warm dark Jain canvas
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .animateContentSize()
        ) {
            // Top Header: Title & Year
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFD4A24C).copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Timer,
                            contentDescription = null,
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "पर्वाधिराज पर्यूषण महापर्व",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFE0B2)
                            )
                        )
                        Text(
                            text = "श्वेताम्बर जैन पंचांग एवं काउंटडाउन (${activeState.year})",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFD4A24C)
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFF8C2020)
                ) {
                    Text(
                        text = "२०२६",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Two Gacch Notice Banner if dates differ in current year
            if (activeState.isTwoGacchDifferentThisYear) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color(0xFF332008),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD4A24C).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = Color(0xFFFFD700),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "विशेष सूचना: इस वर्ष तपागच्छ एवं खरतरगच्छ की पर्यूषण तिथियों में अंतर है। नीचे दोनों तिथियां उपलब्ध हैं।",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFFFFE0B2),
                                fontSize = 11.5.sp
                            )
                        )
                    }
                }
            }

            // Gacch Selector Tabs + Both Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF261D1A))
                    .padding(3.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                FilterChip(
                    selected = !showDualMode && selectedGacch == JainGacch.TAPAGACCH,
                    onClick = {
                        showDualMode = false
                        selectedGacch = JainGacch.TAPAGACCH
                    },
                    label = {
                        Text(
                            text = "तपागच्छ",
                            fontSize = 12.sp,
                            fontWeight = if (!showDualMode && selectedGacch == JainGacch.TAPAGACCH) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD4A24C),
                        selectedLabelColor = Color.Black,
                        containerColor = Color.Transparent,
                        labelColor = Color(0xFFD4A24C)
                    ),
                    modifier = Modifier.weight(1f).testTag("tab_tapagacch")
                )

                FilterChip(
                    selected = !showDualMode && selectedGacch == JainGacch.KHARATARGACCH,
                    onClick = {
                        showDualMode = false
                        selectedGacch = JainGacch.KHARATARGACCH
                    },
                    label = {
                        Text(
                            text = "खरतरगच्छ",
                            fontSize = 12.sp,
                            fontWeight = if (!showDualMode && selectedGacch == JainGacch.KHARATARGACCH) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFFD4A24C),
                        selectedLabelColor = Color.Black,
                        containerColor = Color.Transparent,
                        labelColor = Color(0xFFD4A24C)
                    ),
                    modifier = Modifier.weight(1f).testTag("tab_kharatargacch")
                )

                FilterChip(
                    selected = showDualMode,
                    onClick = { showDualMode = true },
                    label = {
                        Text(
                            text = "दोनों गच्छ",
                            fontSize = 12.sp,
                            fontWeight = if (showDualMode) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Color(0xFF8C2020),
                        selectedLabelColor = Color.White,
                        containerColor = Color.Transparent,
                        labelColor = Color(0xFFE0E0E0)
                    ),
                    modifier = Modifier.weight(1f).testTag("tab_both_gacch")
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (showDualMode) {
                // Dual Side-By-Side Comparison Display
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "दोनों गच्छ पर्यूषण काउंटडाउन तुलना:",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SingleGacchCompactTimerCard(
                            state = tapagacchState,
                            modifier = Modifier.weight(1f)
                        )
                        SingleGacchCompactTimerCard(
                            state = kharatargacchState,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            } else {
                // Single Active Gacch Detailed Timer
                SingleGacchFullTimerCard(state = activeState)
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Dates Summary Row
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF231B18),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "📌 ${activeState.gacch.displayNameHindi} पर्यूषण मुख्य तिथियाँ (${activeState.year}):",
                        style = MaterialTheme.typography.labelMedium.copy(
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        DatePill(
                            label = "डे १ (प्रारंभ)",
                            date = activeState.startDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
                        )
                        DatePill(
                            label = "डे ५ (जन्म वांचन)",
                            date = activeState.janmVanchanDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.MAHAVIR_JANM_VANCHAN
                        )
                        DatePill(
                            label = "डे ८ (संवत्सरी)",
                            date = activeState.samvatsariDateFormatted,
                            isHighlighted = activeState.phase == ParyushanPhase.SAMVATSARI || activeState.phase == ParyushanPhase.SAMVATSARI_ACTIVE
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Expandable 8-Day Schedule Accordion Button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { isItineraryExpanded = !isItineraryExpanded }
                    .background(Color(0xFF2A201C))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CalendarMonth,
                        contentDescription = null,
                        tint = Color(0xFFD4A24C),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "८ दिवसीय पर्यूषण कार्यक्रम एवं कर्तव्य देखें",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFE0B2)
                        )
                    )
                }
                Icon(
                    imageVector = if (isItineraryExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = Color(0xFFD4A24C)
                )
            }

            // Expandable Schedule Content
            AnimatedVisibility(
                visible = isItineraryExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    activeState.itinerary.forEach { item ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (item.isHighlighted) Color(0xFF381616) else Color(0xFF221A17),
                            border = if (item.dayNumber == activeState.currentDayNumber)
                                androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFFD700))
                            else null,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (item.isHighlighted) Color(0xFF8C2020) else Color(0xFF4A3830)
                                ) {
                                    Text(
                                        text = "${item.dayNumber}",
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        ),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text = item.titleHindi,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = if (item.isHighlighted) Color(0xFFFFD700) else Color(0xFFFFE0B2)
                                            )
                                        )
                                        Text(
                                            text = item.dateString,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = Color(0xFFD4A24C)
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = item.descriptionHindi,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = Color(0xFFCCCCCC),
                                            fontSize = 11.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Time Travel Simulator Control for Easy Verification
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF221B18))
                    .padding(8.dp)
            ) {
                Text(
                    text = "⚙️ परीक्षण टाइमर सिम्युलेटर ($activeTestPhaseLabel):",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFB0BEC5),
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Button(
                        onClick = {
                            simulatedTimeOffsetMs = 0L
                            activeTestPhaseLabel = "वास्तविक समय (Live)"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF37474F)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).testTag("sim_live_time_btn")
                    ) {
                        Text("लाइव", fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            // Target 2 hours before Day 1
                            val target = activeState.targetTimeMillis - activeState.startDateFormatted.let { activeState.targetTimeMillis }
                            simulatedTimeOffsetMs = (activeState.startDateFormatted.let {
                                val cal = java.util.Calendar.getInstance()
                                cal.set(activeState.year, 7, 8, 4, 0) // Aug 8 04:00 AM
                                cal.timeInMillis - System.currentTimeMillis()
                            })
                            activeTestPhaseLabel = "डे १ प्रारंभ पूर्व"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3830)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).testTag("sim_day1_btn")
                    ) {
                        Text("डे १", fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            // Target Day 1 - Janm Vanchan countdown
                            simulatedTimeOffsetMs = (activeState.startDateFormatted.let {
                                val cal = java.util.Calendar.getInstance()
                                cal.set(activeState.year, 7, 10, 10, 0) // Aug 10
                                cal.timeInMillis - System.currentTimeMillis()
                            })
                            activeTestPhaseLabel = "जन्म वांचन काउंटडाउन"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A3830)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).testTag("sim_janm_vanchan_btn")
                    ) {
                        Text("जन्म वांचन", fontSize = 10.sp)
                    }

                    Button(
                        onClick = {
                            // Target Samvatsari countdown
                            simulatedTimeOffsetMs = (activeState.startDateFormatted.let {
                                val cal = java.util.Calendar.getInstance()
                                cal.set(activeState.year, 7, 13, 10, 0) // Aug 13
                                cal.timeInMillis - System.currentTimeMillis()
                            })
                            activeTestPhaseLabel = "संवत्सरी काउंटडाउन"
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF8C2020)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                        modifier = Modifier.weight(1f).testTag("sim_samvatsari_btn")
                    ) {
                        Text("संवत्सरी", fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun SingleGacchFullTimerCard(state: ParyushanCountdownState) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF2A1C16),
                        Color(0xFF1E1410)
                    )
                )
            )
            .padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Phase Title Header
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color(0xFFD4A24C).copy(alpha = 0.2f),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD4A24C).copy(alpha = 0.6f))
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (state.currentDayNumber > 0) {
                    Text(
                        text = "पर्यूषण दिवस ${state.currentDayNumber} सक्रिय • ",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFFFD700),
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
                Text(
                    text = state.phase.titleHindi,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = Color(0xFFFFE0B2),
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = state.phase.subtitleHindi,
            style = MaterialTheme.typography.bodySmall.copy(
                color = Color(0xFFD4A24C),
                fontSize = 11.5.sp
            ),
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        if (state.phase == ParyushanPhase.SAMVATSARI_ACTIVE) {
            // Samvatsari Celebration Banner
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
            ) {
                Text(
                    text = "🙏 उत्तमा क्षमा - मिच्छामि दुक्कडम् 🙏",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    ),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "समस्त जीवराशी से मन, वचन, काया से क्षमा याचना करते हैं।",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = Color(0xFFFFE0B2)
                    ),
                    textAlign = TextAlign.Center
                )
            }
        } else {
            // Live 4-Block Countdown Timer
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                TimeUnitBlock(value = state.daysRemaining, label = "दिन")
                Text(":", color = Color(0xFFD4A24C), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.hoursRemaining, label = "घंटे")
                Text(":", color = Color(0xFFD4A24C), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.minutesRemaining, label = "मिनट")
                Text(":", color = Color(0xFFD4A24C), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                TimeUnitBlock(value = state.secondsRemaining, label = "सेकंड", isHighlight = true)
            }
        }
    }
}

@Composable
private fun SingleGacchCompactTimerCard(
    state: ParyushanCountdownState,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF261D1A),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFD4A24C).copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = state.gacch.displayNameHindi,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFFFD700)
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = state.phase.titleHindi,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFFFFE0B2),
                    fontSize = 10.sp
                ),
                maxLines = 1,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                CompactDigitBox(value = state.daysRemaining, label = "d")
                CompactDigitBox(value = state.hoursRemaining, label = "h")
                CompactDigitBox(value = state.minutesRemaining, label = "m")
                CompactDigitBox(value = state.secondsRemaining, label = "s")
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "प्रारंभ: ${state.startDateFormatted}",
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color(0xFFD4A24C),
                    fontSize = 9.5.sp
                )
            )
        }
    }
}

@Composable
private fun TimeUnitBlock(
    value: Long,
    label: String,
    isHighlight: Boolean = false
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .width(58.dp)
                .height(52.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (isHighlight) Color(0xFF8C2020) else Color(0xFF382822)
                )
                .border(
                    width = 1.dp,
                    color = if (isHighlight) Color(0xFFFFD700) else Color(0xFF5A443A),
                    shape = RoundedCornerShape(10.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = String.format("%02d", value),
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 22.sp
                )
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = Color(0xFFD4A24C),
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )
        )
    }
}

@Composable
private fun CompactDigitBox(value: Long, label: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = Color(0xFF382822)
    ) {
        Text(
            text = "${String.format("%02d", value)}$label",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 10.sp
            ),
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun DatePill(
    label: String,
    date: String,
    isHighlighted: Boolean
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                color = if (isHighlighted) Color(0xFFFFD700) else Color(0xFFB0BEC5),
                fontSize = 10.sp,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = if (isHighlighted) Color(0xFF8C2020) else Color(0xFF2E231F)
        ) {
            Text(
                text = date,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.5.sp
                ),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
