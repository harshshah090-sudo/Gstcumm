package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.data.toShareableText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    formId: Long,
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formState by viewModel.getFormFlow(formId).collectAsStateWithLifecycle(initialValue = null)

    fun shareFormAsText(form: ParyushanFormEntity) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, form.toShareableText())
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(shareIntent, "व्हाट्सएप / संदेश पर शेयर करें"))
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = formState?.sanghName ?: "श्रीसंघ विवरण",
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "पीछे जाएँ")
                    }
                },
                actions = {
                    formState?.let { form ->
                        IconButton(
                            onClick = { shareFormAsText(form) },
                            modifier = Modifier.testTag("top_share_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "शेयर करें", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            )
        },
        bottomBar = {
            formState?.let { form ->
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = { shareFormAsText(form) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("bottom_share_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("व्हाट्सएप / मैसेज पर टेक्स्ट शेयर करें", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        val form = formState
        if (form == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val scrollState = rememberScrollState()

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Subtle transparent background watermark image
                Image(
                    painter = painterResource(id = R.drawable.ic_group_logo),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    alpha = 0.18f,
                    modifier = Modifier
                        .fillMaxWidth(0.90f)
                        .aspectRatio(1f)
                        .align(Alignment.Center)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Top Banner
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "पर्वाधीराज पर्यूषण आराधना विवरण",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                )
                                Text(
                                    text = "शहर: ${form.cityName}${if (form.stateName.isNotBlank()) " (${form.stateName})" else ""}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                    )
                                )
                            }
                            IconButton(
                                onClick = { shareFormAsText(form) },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(Icons.Default.Share, contentDescription = "शेयर करें")
                            }
                        }
                    }

                    Text(
                        text = "फॉर्म के समस्त प्रश्नों के उत्तर:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    )

                    // Render all Question Cards matching exact webpage questions
                    AnswerDetailCard("१", "१. श्री संघ का नाम", form.sanghName, isHighlight = true)
                    AnswerDetailCard("२", "२. श्री संघ का पूरा पता", form.sanghAddress, isHighlight = true)
                    val cityAndStateDisplay = if (form.stateName.isNotBlank() && !form.cityName.contains(form.stateName, ignoreCase = true)) {
                        "${form.cityName}, ${form.stateName}"
                    } else {
                        form.cityName
                    }
                    AnswerDetailCard("३", "३. आपके शहर/गांव का नाम", cityAndStateDisplay)
                    AnswerDetailCard("४", "४. स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका नाम, पद (१)", form.contact1)
                    AnswerDetailCard("५", "५. स्वाध्याई भाई जिसके साथ संपर्क में रहेंगे उनका WhatsApp न.", form.contact2)
                    AnswerDetailCard("६", "६. आपके संघ में मुलनायक भगवान कौन से हें?", form.mulnayakBhagwan)
                    AnswerDetailCard("७", "७. आपके संघ में कितने परिवार है?", form.totalFamilies)
                    AnswerDetailCard("८", "८. क्या आपके गांव/कॉलोनी में कोई अन्य संघ है?", form.hasOtherSangh)
                    AnswerDetailCard("९", "९. आपके संघ में कौन-कौन से गच्छ हैं?", form.gacchList, isCheckboxList = true)
                    AnswerDetailCard("१०", "१०. आपके संघ में कौनसी परंपरा से प्रतिकमण किया जाता हैं?", form.pratikramanTradition, isCheckboxList = true)
                    AnswerDetailCard("११", "११. आपके श्रीसंघ में कोई संगीतकार/मंडल हैं?", form.hasMusicianGroup)
                    AnswerDetailCard("१२", "१२. क्या आप बाहर से संगीतकार बुलाते हों?", form.callsOutsideMusician)
                    AnswerDetailCard("१३", "१३. आपके श्रीसंघ में ऐसा कोई व्यक्ति है जिसको पंच प्रतिकमण आता हो और वह पर्यूषण पर्व में हाजिर हो?", form.hasPanchPratikramanPerson)
                    AnswerDetailCard("१४", "१४. क्या आपके श्रीसंघ मैं मातृ-ठल्ले (Toilet) की व्यवस्था हैं?", form.hasToiletFacility)
                    AnswerDetailCard("१५", "१५. आपके श्रीसंघ में यह आराधना सामग्री होने पर ✔️ लगाइए", form.aradhanaSamagriList, isCheckboxList = true)

                    // Q16 Attendance Details
                    Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                BadgeNumber("१६")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "१६. पर्यूषण दौरान श्री संघ की प्रवृत्तियों में हाजिर व्यक्तियों की संख्या:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            AttendanceRow("• राई प्रतिकमण", form.countRaiPratikraman)
                            AttendanceRow("• देवसी प्रतिकमण", form.countDevasiPratikraman)
                            AttendanceRow("• प्रवचन", form.countPravachan)
                            AttendanceRow("• संध्या भक्ति", form.countSandhyaBhakti)
                        }
                    }

                    AnswerDetailCard("१७", "१७. श्रीसंघ के मुख्य तीन अग्रणी / ट्रस्टी के नाम और मोबाइल नंबर", form.mainTrustees)

                    // Q18 Agreement
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            BadgeNumber("१८")
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "१८. सर्व अग्रणियों की सम्मति एवं नियम स्वीकृति:",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (form.agreedToTerms) "✔️ समस्त अग्रणियों की सर्वसम्मति एवं नियम स्वीकृत हैं।" else "❌ सम्मति प्राप्त नहीं",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (form.agreedToTerms) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}

@Composable
private fun BadgeNumber(number: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun AnswerDetailCard(
    number: String,
    title: String,
    answer: String,
    isHighlight: Boolean = false,
    isCheckboxList: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                BadgeNumber(number)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            val trimmed = answer.trim()
            if (isCheckboxList) {
                val commaNotInParensRegex = Regex(",(?![^()]*\\))")
                val items = trimmed.split(commaNotInParensRegex)
                    .map { it.trim() }
                    .filter { it.isNotBlank() && it != "null" }

                if (items.isEmpty() || trimmed == "कोई नहीं" || trimmed == "निर्दिष्ट नहीं") {
                    Text(
                        text = if (trimmed.isBlank()) "कोई नहीं" else trimmed,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                } else {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        items.forEach { item ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "✔️",
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                            }
                        }
                    }
                }
            } else if (trimmed.contains("\n")) {
                val lines = trimmed.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                Column(
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(start = 4.dp)
                ) {
                    lines.forEach { line ->
                        Text(
                            text = line,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            } else {
                Text(
                    text = if (trimmed.isBlank()) "निर्दिष्ट नहीं" else trimmed,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    ),
                    modifier = Modifier.padding(start = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun AttendanceRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.secondaryContainer
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}
