package com.example.ui

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ParyushanFormEntity
import com.example.data.toShareableText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(
    formId: Long,
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val formState by viewModel.getFormFlow(formId).collectAsStateWithLifecycle(initialValue = null)
    var showDeleteConfirmDialog by remember { mutableStateOf(false) }

    fun shareFormAsText(form: ParyushanFormEntity) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, form.toShareableText())
            type = "text/plain"
        }
        context.startActivity(Intent.createChooser(shareIntent, "व्हाट्सएप / संदेश पर शेयर करें"))
    }

    if (showDeleteConfirmDialog && formState != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = false },
            title = { Text("फॉर्म हटाएं") },
            text = { Text("क्या आप इस श्रीसंघ का फॉर्म हटाना चाहते हैं?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        showDeleteConfirmDialog = false
                        viewModel.deleteForm(formId)
                        Toast.makeText(context, "फॉर्म हटा दिया गया", Toast.LENGTH_SHORT).show()
                        onNavigateBack()
                    }
                ) {
                    Text("हटाएं", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = false }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = formState?.sanghName ?: "श्रीसंघ विवरण",
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "पीछे जाएँ")
                    }
                },
                actions = {
                    formState?.let { form ->
                        IconButton(
                            onClick = { shareFormAsText(form) },
                            modifier = Modifier.testTag("top_share_button")
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "शेयर करें", tint = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { showDeleteConfirmDialog = true }) {
                            Icon(Icons.Default.Delete, contentDescription = "हटाएं", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                )
            )
        },
        bottomBar = {
            formState?.let { form ->
                Surface(
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    color = MaterialTheme.colorScheme.surface
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = { shareFormAsText(form) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("bottom_share_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("व्हाट्सएप / मैसेज पर टेक्स्ट शेयर करें", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        val form = formState
        if (form == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            val scrollState = rememberScrollState()

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .verticalScroll(scrollState)
                    .background(MaterialTheme.colorScheme.background)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Top Action Banner
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "पर्वाधीराज पर्यूषण आराधना विवरण",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                            Text(
                                text = "शहर: ${form.cityName}",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            )
                        }
                        IconButton(
                            onClick = { shareFormAsText(form) },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                contentColor = MaterialTheme.colorScheme.onPrimary
                            )
                        ) {
                            Icon(Icons.Default.Share, contentDescription = "शेयर करें")
                        }
                    }
                }

                Text(
                    text = "फॉर्म के समस्त १८ प्रश्नों के उत्तर:",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                )

                // Render all 18 Question Cards
                AnswerDetailCard("१", "श्री संघ का नाम", form.sanghName, isHighlight = true)
                AnswerDetailCard("२", "श्री संघ का पूरा पता", form.sanghAddress, isHighlight = true)
                AnswerDetailCard("३", "आपके शहर / गांव का नाम", form.cityName)
                AnswerDetailCard("४", "स्वाध्याई भाई संपर्क सूत्र (१)", form.contact1)
                AnswerDetailCard("५", "स्वाध्याई भाई संपर्क सूत्र (२)", form.contact2)
                AnswerDetailCard("६", "मुलनायक भगवान", form.mulnayakBhagwan)
                AnswerDetailCard("७", "संघ में परिवार संख्या", form.totalFamilies)
                AnswerDetailCard("८", "अन्य संघ उपस्थित है", form.hasOtherSangh)
                AnswerDetailCard("९", "संघ में गच्छ", form.gacchList.ifBlank { "निर्दिष्ट नहीं" })
                AnswerDetailCard("१०", "प्रतिकमण परंपरा", form.pratikramanTradition.ifBlank { "निर्दिष्ट नहीं" })
                AnswerDetailCard("११", "संगीतकार / मंडल उपस्थित है", form.hasMusicianGroup)
                AnswerDetailCard("१२", "बाहर से संगीतकार बुलाते हैं", form.callsOutsideMusician)
                AnswerDetailCard("१३", "पंच प्रतिकमण जानकार व्यक्ति", form.hasPanchPratikramanPerson)
                AnswerDetailCard("१४", "मात्रू-ठल्ले (Toilet) व्यवस्था", form.hasToiletFacility)
                AnswerDetailCard("१५", "आराधना सामग्री उपलब्ध", form.aradhanaSamagriList.ifBlank { "कोई नहीं" })

                // Q16 Grid Attendance Detail
                Card(shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BadgeNumber("१६")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "प्रवृत्तियों में उपस्थित व्यक्तियों की संख्या:",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        AttendanceRow("राई प्रतिकमण", form.countRaiPratikraman)
                        AttendanceRow("देवसी प्रतिकमण", form.countDevasiPratikraman)
                        AttendanceRow("प्रवचन", form.countPravachan)
                        AttendanceRow("संध्या भक्ति", form.countSandhyaBhakti)
                    }
                }

                AnswerDetailCard("१७", "मुख्य ३ अग्रणी / ट्रस्टी", form.mainTrustees)

                // Q18 Agreement
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        BadgeNumber("१८")
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "सर्व अग्रणियों की सम्मति:",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (form.agreedToTerms) "✔️ समस्त अग्रणियों की सर्वसम्मति एवं नियम स्वीकृत हैं।" else "❌ सम्मति प्राप्त नहीं",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (form.agreedToTerms) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(30.dp))
            }
        }
    }
}

@Composable
private fun BadgeNumber(number: String) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = number,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun AnswerDetailCard(
    number: String,
    title: String,
    answer: String,
    isHighlight: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                BadgeNumber(number)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = answer,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            )
        }
    }
}

@Composable
private fun AttendanceRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, style = MaterialTheme.typography.bodyMedium)
        Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.secondaryContainer
        ) {
            Text(
                text = value,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSecondaryContainer
                ),
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}
