package com.example.ui

import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import com.example.utils.PanchangScannerService
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.PanchangEventEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class CalendarViewMode {
    GRID, LIST
}

enum class PanchangFilter {
    ALL, TITHI, KALYANAK, PARVA
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalPanchangScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allEvents by viewModel.allPanchangEvents.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanningPanchang.collectAsStateWithLifecycle()
    val scanError by viewModel.scanPanchangError.collectAsStateWithLifecycle()
    val extractedDraft by viewModel.extractedPanchangDraft.collectAsStateWithLifecycle()

    var selectedCalendar by remember { mutableStateOf(Calendar.getInstance()) }
    var viewMode by remember { mutableStateOf(CalendarViewMode.GRID) }
    var selectedFilter by remember { mutableStateOf(PanchangFilter.ALL) }

    var selectedDayEvent by remember { mutableStateOf<PanchangEventEntity?>(null) }
    var selectedDayDateString by remember { mutableStateOf<String?>(null) }
    var showScanBottomSheet by remember { mutableStateOf(false) }
    var showApiKeyDialog by remember { mutableStateOf(false) }
    var currentSelectedImageUri by remember { mutableStateOf<Uri?>(null) }

    // Image Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            currentSelectedImageUri = it
            showScanBottomSheet = true
            viewModel.scanPanchangImage(context, it)
        }
    }

    val currentYearMonthStr = remember(selectedCalendar.timeInMillis) {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        sdf.format(selectedCalendar.time)
    }

    val displayMonthYearTitle = remember(selectedCalendar.timeInMillis) {
        val sdfEng = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
        val sdfHindi = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN"))
        "${sdfHindi.format(selectedCalendar.time)} (${sdfEng.format(selectedCalendar.time)})"
    }

    // Filtered events for the month
    val monthEvents = remember(allEvents, currentYearMonthStr) {
        allEvents.filter { it.dateString.startsWith(currentYearMonthStr) }
            .associateBy { it.dateString }
    }

    val kalyanakCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.kalyanaks.isNotBlank() }
    }

    val tithiCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.isImportantTithi || it.tithi.isNotBlank() }
    }

    val parvaCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.parvasAndEvents.isNotBlank() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "डिजिटल पंचांग एवं तिथि कैलेंडर",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "Zero Storage Privacy • AI Panchang Extraction",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontSize = 11.sp
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showApiKeyDialog = true },
                        modifier = Modifier.testTag("configure_api_key_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Key,
                            contentDescription = "API Key Settings",
                            tint = AppPrimaryGold
                        )
                    }
                    Button(
                        onClick = { showScanBottomSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("scan_panchang_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "📁 Upload JSON / Scan",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Month Header Controls Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AppSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    // Row 1: Month Chevrons & Title
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val cal = selectedCalendar.clone() as Calendar
                                cal.add(Calendar.MONTH, -1)
                                selectedCalendar = cal
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = "Previous Month",
                                tint = AppPrimaryGold
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = displayMonthYearTitle,
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.ExtraBold,
                                    color = AppTextPrimary
                                ),
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = AppDeepSurface,
                                modifier = Modifier.clickable {
                                    selectedCalendar = Calendar.getInstance()
                                }
                            ) {
                                Text(
                                    text = "आज (Today)",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = AppPrimaryGold,
                                        fontSize = 10.sp
                                    ),
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = {
                                val cal = selectedCalendar.clone() as Calendar
                                cal.add(Calendar.MONTH, 1)
                                selectedCalendar = cal
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Next Month",
                                tint = AppPrimaryGold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 2: Stats Banner
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        MonthStatPill(
                            label = "कल्याणक",
                            count = "$kalyanakCountInMonth",
                            color = AppPrimaryGold
                        )
                        MonthStatPill(
                            label = "विशेष तिथियां",
                            count = "$tithiCountInMonth",
                            color = AppSecondaryGreen
                        )
                        MonthStatPill(
                            label = "पर्व & उत्सव",
                            count = "$parvaCountInMonth",
                            color = Color(0xFFBA68C8)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Row 3: View Mode & Filter Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // View mode toggle
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(AppDeepSurface)
                                .padding(2.dp)
                        ) {
                            IconButton(
                                onClick = { viewMode = CalendarViewMode.GRID },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (viewMode == CalendarViewMode.GRID) AppTertiaryMaroon else Color.Transparent)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CalendarViewMonth,
                                    contentDescription = "Grid View",
                                    tint = if (viewMode == CalendarViewMode.GRID) AppPrimaryGold else AppTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = { viewMode = CalendarViewMode.LIST },
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (viewMode == CalendarViewMode.LIST) AppTertiaryMaroon else Color.Transparent)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FormatListBulleted,
                                    contentDescription = "List View",
                                    tint = if (viewMode == CalendarViewMode.LIST) AppPrimaryGold else AppTextMuted,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Filter Chips
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            FilterChipCompact(
                                label = "सभी",
                                isSelected = selectedFilter == PanchangFilter.ALL,
                                onClick = { selectedFilter = PanchangFilter.ALL }
                            )
                            FilterChipCompact(
                                label = "तिथियां",
                                isSelected = selectedFilter == PanchangFilter.TITHI,
                                onClick = { selectedFilter = PanchangFilter.TITHI }
                            )
                            FilterChipCompact(
                                label = "कल्याणक",
                                isSelected = selectedFilter == PanchangFilter.KALYANAK,
                                onClick = { selectedFilter = PanchangFilter.KALYANAK }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Main Calendar View
            if (viewMode == CalendarViewMode.GRID) {
                PanchangGridCalendar(
                    selectedCalendar = selectedCalendar,
                    eventsMap = monthEvents,
                    filter = selectedFilter,
                    onDayClick = { dateStr, event ->
                        selectedDayDateString = dateStr
                        selectedDayEvent = event
                    }
                )
            } else {
                PanchangListCalendar(
                    selectedCalendar = selectedCalendar,
                    eventsMap = monthEvents,
                    filter = selectedFilter,
                    onDayClick = { dateStr, event ->
                        selectedDayDateString = dateStr
                        selectedDayEvent = event
                    }
                )
            }
        }
    }

    // Day Detail Bottom Sheet / Dialog
    selectedDayDateString?.let { dateStr ->
        DayDetailDialog(
            dateString = dateStr,
            event = selectedDayEvent,
            onDismiss = {
                selectedDayDateString = null
                selectedDayEvent = null
            },
            onSaveNotes = { updatedEvent ->
                viewModel.addOrUpdatePanchangEvent(updatedEvent)
                selectedDayDateString = null
                selectedDayEvent = null
                Toast.makeText(context, "Panchang details updated", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Api Key Config Dialog
    if (showApiKeyDialog) {
        var keyInput by remember {
            mutableStateOf(PanchangScannerService.getSavedCustomApiKey(context))
        }
        AlertDialog(
            onDismissRequest = { showApiKeyDialog = false },
            title = {
                Text(
                    text = "🔑 Gemini API Key Configuration",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
            },
            text = {
                Column {
                    Text(
                        text = "Paste your free Gemini API key to enable live AI vision photo scanning of Panchang pages.",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = keyInput,
                        onValueChange = { keyInput = it },
                        label = { Text("Gemini API Key") },
                        placeholder = { Text("AIzaSy...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "You can get a free key at aistudio.google.com",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppPrimaryGold,
                            fontSize = 11.sp
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        PanchangScannerService.saveCustomApiKey(context, keyInput)
                        showApiKeyDialog = false
                        Toast.makeText(context, "API Key saved successfully!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold)
                ) {
                    Text("Save Key", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showApiKeyDialog = false }) {
                    Text("Cancel", color = AppTextMuted)
                }
            },
            containerColor = AppSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    // Scan Panchang Dialog / Bottom Sheet
    if (showScanBottomSheet || isScanning || extractedDraft.isNotEmpty() || scanError != null) {
        PanchangExtractionSheet(
            isScanning = isScanning,
            imageUri = currentSelectedImageUri,
            errorMsg = scanError,
            extractedEvents = extractedDraft,
            onDismiss = {
                showScanBottomSheet = false
                viewModel.clearPanchangDraft()
            },
            onConfirmImport = { selectedEvents ->
                viewModel.saveExtractedDraftPanchangEvents(selectedEvents)
                showScanBottomSheet = false
                Toast.makeText(context, "Successfully imported ${selectedEvents.size} Panchang events!", Toast.LENGTH_LONG).show()
            },
            onRetryScan = {
                photoPickerLauncher.launch("image/*")
            },
            onRetryWithKey = { apiKey ->
                currentSelectedImageUri?.let { uri ->
                    viewModel.scanPanchangImage(context, uri, apiKey, allowDemoFallback = false)
                }
            },
            onDemoMode = {
                currentSelectedImageUri?.let { uri ->
                    viewModel.scanPanchangImage(context, uri, customApiKey = null, allowDemoFallback = true)
                }
            },
            onPasteJson = { jsonText ->
                viewModel.processPastedPanchangJson(jsonText)
            }
        )
    }
}

@Composable
fun PanchangGridCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    onDayClick: (String, PanchangEventEntity?) -> Unit
) {
    val daysOfWeek = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")

    val calendarMatrix = remember(selectedCalendar.timeInMillis) {
        val cal = selectedCalendar.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0-based for Sun
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        val yearMonthSdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val yearMonth = yearMonthSdf.format(cal.time)

        val list = mutableListOf<CalendarGridCellData?>()
        // Add padding empty cells for preceding days
        for (i in 0 until firstDayOfWeek) {
            list.add(null)
        }
        // Add days of month
        for (day in 1..daysInMonth) {
            val dayFormatted = String.format("%02d", day)
            val fullDateStr = "$yearMonth-$dayFormatted"
            list.add(CalendarGridCellData(dayNumber = day, dateString = fullDateStr))
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        // Week Days Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            daysOfWeek.forEach { dayName ->
                Text(
                    text = dayName,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (dayName == "रवि") AppPrimaryGold else AppTextMuted
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Grid Cells
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(calendarMatrix) { cell ->
                if (cell == null) {
                    Spacer(modifier = Modifier.aspectRatio(0.85f))
                } else {
                    val event = eventsMap[cell.dateString]
                    val isPassFilter = remember(event, filter) {
                        when (filter) {
                            PanchangFilter.ALL -> true
                            PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                            PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                            PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
                        }
                    }

                    PanchangGridCell(
                        dayNumber = cell.dayNumber,
                        event = event,
                        isHighlightFilter = isPassFilter,
                        onClick = { onDayClick(cell.dateString, event) }
                    )
                }
            }
        }
    }
}

data class CalendarGridCellData(
    val dayNumber: Int,
    val dateString: String
)

@Composable
fun PanchangGridCell(
    dayNumber: Int,
    event: PanchangEventEntity?,
    isHighlightFilter: Boolean,
    onClick: () -> Unit
) {
    val todayDateStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
    val isToday = event?.dateString == todayDateStr

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true
    val isImportantTithi = event?.isImportantTithi == true

    Card(
        modifier = Modifier
            .aspectRatio(0.82f)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isToday) 1.8.dp else 1.dp,
                color = when {
                    isToday -> AppPrimaryGold
                    hasKalyanak -> AppPrimaryGold.copy(alpha = 0.6f)
                    isImportantTithi -> AppSecondaryGreen.copy(alpha = 0.6f)
                    else -> AppBorder
                },
                shape = RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isToday -> AppSurfaceNested
                hasKalyanak -> AppDeepSurface
                else -> AppSurface
            }
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Day Number + Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$dayNumber",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (isToday || hasKalyanak) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isToday) AppPrimaryGold else AppTextPrimary,
                        fontSize = 14.sp
                    )
                )

                if (hasKalyanak) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Kalyanak",
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(12.dp)
                    )
                } else if (hasParva) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFBA68C8))
                    )
                }
            }

            // Tithi / Event Tag Badge
            if (event != null && event.tithi.isNotBlank()) {
                val shortTithi = remember(event.tithi) {
                    event.tithi
                        .replace("Vaisakha", "")
                        .replace("Bhadrapad", "")
                        .replace("Chaitra", "")
                        .replace("Karthik", "")
                        .trim()
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = when {
                        isImportantTithi -> AppTertiaryMaroon
                        hasKalyanak -> AppPrimaryGold.copy(alpha = 0.2f)
                        else -> AppDeepSurface
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = shortTithi,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isImportantTithi) AppPrimaryGold else AppTextPrimary
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(1.dp))
            }
        }
    }
}

@Composable
fun PanchangListCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    onDayClick: (String, PanchangEventEntity?) -> Unit
) {
    val yearMonthSdf = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()) }
    val currentYearMonth = yearMonthSdf.format(selectedCalendar.time)
    val daysInMonth = selectedCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

    val dateList = remember(selectedCalendar.timeInMillis) {
        (1..daysInMonth).map { day ->
            val formattedDay = String.format("%02d", day)
            "$currentYearMonth-$formattedDay"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(dateList) { dateStr ->
            val event = eventsMap[dateStr]
            val isPassFilter = when (filter) {
                PanchangFilter.ALL -> true
                PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
            }

            if (isPassFilter) {
                PanchangListRowCard(
                    dateString = dateStr,
                    event = event,
                    onClick = { onDayClick(dateStr, event) }
                )
            }
        }
    }
}

@Composable
fun PanchangListRowCard(
    dateString: String,
    event: PanchangEventEntity?,
    onClick: () -> Unit
) {
    val formattedDateText = remember(dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMM, EEEE", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            dateString
        }
    }

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(
                1.dp,
                if (hasKalyanak) AppPrimaryGold.copy(alpha = 0.5f) else AppBorder,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Date Badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (hasKalyanak) AppTertiaryMaroon else AppDeepSurface,
                modifier = Modifier.width(90.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary,
                            fontSize = 11.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                if (event != null && event.tithi.isNotBlank()) {
                    Text(
                        text = "तिथि: ${event.tithi}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (event.isImportantTithi) AppPrimaryGold else AppTextPrimary
                        )
                    )
                } else {
                    Text(
                        text = "कोई विशेष तिथि दर्ज नहीं",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )
                }

                if (hasKalyanak) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "✨ ${event?.kalyanaks}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                if (hasParva) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "🚩 ${event?.parvasAndEvents}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFCE93D8)
                        )
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppTextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun DayDetailDialog(
    dateString: String,
    event: PanchangEventEntity?,
    onDismiss: () -> Unit,
    onSaveNotes: (PanchangEventEntity) -> Unit
) {
    var tithiInput by remember { mutableStateOf(event?.tithi ?: "") }
    var kalyanakInput by remember { mutableStateOf(event?.kalyanaks ?: "") }
    var parvaInput by remember { mutableStateOf(event?.parvasAndEvents ?: "") }
    var notesInput by remember { mutableStateOf(event?.notes ?: "") }
    var isImportant by remember { mutableStateOf(event?.isImportantTithi ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "तिथि विवरण ($dateString)",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = tithiInput,
                    onValueChange = { tithiInput = it },
                    label = { Text("जैन तिथि (Tithi)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isImportant,
                        onCheckedChange = { isImportant = it },
                        colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                    )
                    Text("विशेष तिथि (Agiyaras, Chaudas, Poonam, Amas, etc.)", style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = kalyanakInput,
                    onValueChange = { kalyanakInput = it },
                    label = { Text("तीर्थंकर कल्याणक (Kalyanak)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = parvaInput,
                    onValueChange = { parvaInput = it },
                    label = { Text("पर्व / त्यौहार (Parva / Event)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("अन्य विवरण एवं नोट्स (Notes)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = event?.copy(
                        tithi = tithiInput,
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput,
                        parvasAndEvents = parvaInput,
                        notes = notesInput
                    ) ?: PanchangEventEntity(
                        dateString = dateString,
                        tithi = tithiInput,
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput,
                        parvasAndEvents = parvaInput,
                        notes = notesInput
                    )
                    onSaveNotes(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold)
            ) {
                Text("सुरक्षित करें (Save)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें (Cancel)", color = AppTextMuted)
            }
        },
        containerColor = AppSurface,
        shape = RoundedCornerShape(18.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanchangExtractionSheet(
    isScanning: Boolean,
    imageUri: Uri?,
    errorMsg: String?,
    extractedEvents: List<PanchangEventEntity>,
    onDismiss: () -> Unit,
    onConfirmImport: (List<PanchangEventEntity>) -> Unit,
    onRetryScan: () -> Unit,
    onRetryWithKey: (String) -> Unit,
    onDemoMode: () -> Unit,
    onPasteJson: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedItemIds by remember(extractedEvents) {
        mutableStateOf(extractedEvents.mapIndexed { index, _ -> index }.toSet())
    }
    var userApiKeyInput by remember {
        mutableStateOf(PanchangScannerService.getSavedCustomApiKey(context))
    }
    var pastedJsonInput by remember { mutableStateOf("") }

    val jsonFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { fileUri: Uri? ->
        fileUri?.let { uri ->
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val jsonContent = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (jsonContent.isNotBlank()) {
                    onPasteJson(jsonContent)
                } else {
                    Toast.makeText(context, "Selected JSON file is empty", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to read JSON file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = AppSurface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Privacy Banner Guarantee
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = AppDeepSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, AppSecondaryGreen.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Zero Storage Privacy",
                        tint = AppSecondaryGreen,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Zero Storage Privacy: Photos are analyzed in RAM only and never saved on your device or cloud.",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppSecondaryGreen,
                            fontSize = 11.5.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (isScanning) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = AppPrimaryGold)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Analyzing Panchang Photo with Gemini Vision AI...",
                        style = MaterialTheme.typography.titleSmall.copy(
                            color = AppPrimaryGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Extracting dates, Jain Tithis, Tirthankar Kalyanaks & Pachkhan timings",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )
                }
            } else if (errorMsg != null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Extraction Failed",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (errorMsg == "NO_API_KEY_CONFIGURED" || errorMsg.contains("Gemini API key", ignoreCase = true))
                            "Gemini API key is required to perform live AI Vision OCR on photos."
                        else errorMsg,
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // API KEY PASTE CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Paste Gemini API Key Here",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedTextField(
                                value = userApiKeyInput,
                                onValueChange = { userApiKeyInput = it },
                                label = { Text("Gemini API Key") },
                                placeholder = { Text("Paste key starting with AIzaSy...") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_key_input_field"),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { onRetryWithKey(userApiKeyInput) },
                                enabled = userApiKeyInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("save_key_and_extract_button")
                            ) {
                                Text("Save Key & Scan Photo Now", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // DEMO MODE OPTION
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "Don't have an API key right now?",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Test the scanner immediately with pre-loaded demo Panchang data.",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = onDemoMode,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("try_demo_scanner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Try Demo Panchang Scanner Mode", color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // PASTE JSON FROM OTHER AI PLATFORM CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Paste AI Result (ChatGPT / Gemini / Claude)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Uploaded image to ChatGPT or Gemini web? Paste the generated JSON output below to import into your calendar instantly:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = pastedJsonInput,
                                onValueChange = { pastedJsonInput = it },
                                label = { Text("Paste JSON Array") },
                                placeholder = { Text("[{\"dateString\": \"2026-08-15\", ...}]") },
                                maxLines = 6,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("pasted_json_input_field"),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    if (pastedJsonInput.isNotBlank()) {
                                        onPasteJson(pastedJsonInput)
                                    }
                                },
                                enabled = pastedJsonInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("import_pasted_json_button")
                            ) {
                                Text("Import Pasted JSON Data", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    TextButton(onClick = onRetryScan) {
                        Icon(
                            imageVector = Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = AppTextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Choose Another Photo", color = AppTextMuted)
                    }
                }
            } else if (extractedEvents.isNotEmpty()) {
                Text(
                    text = "Extracted ${extractedEvents.size} Panchang Entries",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(extractedEvents.size) { index ->
                        val item = extractedEvents[index]
                        val isChecked = selectedItemIds.contains(index)

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedItemIds = if (checked) {
                                            selectedItemIds + index
                                        } else {
                                            selectedItemIds - index
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.dateString} • ${item.tithi}",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppTextPrimary
                                        )
                                    )
                                    if (item.kalyanaks.isNotBlank()) {
                                        Text(
                                            text = "⭐ ${item.kalyanaks}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppPrimaryGold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val selectedList = extractedEvents.filterIndexed { index, _ -> selectedItemIds.contains(index) }
                        onConfirmImport(selectedList)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Import ${selectedItemIds.size} Events into Digital Calendar",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                // INITIAL / DEFAULT IMPORT OPTIONS VIEW
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📋 AI & Panchang Data Import Options",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Choose how you want to add Jain Tithis & events to your calendar:",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // OPTION 1: UPLOAD JSON FILE FROM STORAGE
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, AppPrimaryGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Option 1: Upload JSON File (.json)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Select a JSON file saved from ChatGPT or downloaded on your device storage to extract all Panchang details into your calendar:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { jsonFileLauncher.launch("*/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upload_json_file_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("📁 Select & Upload JSON File", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // OPTION 2: PASTE JSON TEXT
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Option 2: Paste JSON Text",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Or paste JSON response text directly from ChatGPT / Gemini below:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = pastedJsonInput,
                                onValueChange = { pastedJsonInput = it },
                                label = { Text("Paste JSON Array") },
                                placeholder = { Text("[{\"dateString\": \"2026-08-15\", \"tithi\": \"Sud Teej\"}, ...]") },
                                maxLines = 4,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_pasted_json_input"),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    if (pastedJsonInput.isNotBlank()) {
                                        onPasteJson(pastedJsonInput)
                                    }
                                },
                                enabled = pastedJsonInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_import_pasted_json_button")
                            ) {
                                Text("Import Pasted JSON Text", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // OPTION 3: LOAD 2026 PRE-LOADED DATA (110+ DATES)
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppSecondaryGreen.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = AppSecondaryGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Option 3: Load Full 2026 Calendar (110+ Days)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppSecondaryGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Instantly load all 110+ Jain Panchang dates & Tithis from July 2026 through November 2026 provided in your file.",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = onDemoMode,
                                colors = ButtonDefaults.buttonColors(containerColor = AppSecondaryGreen),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_try_demo_scanner_button")
                            ) {
                                Text("Load All 110+ Events into Calendar", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // OPTION 4: SCAN PHOTO
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Option 4: Scan Printed Photo with AI",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppTextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Select a printed Panchang calendar photo from phone gallery.",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = onRetryScan,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("choose_photo_and_scan_button")
                            ) {
                                Text("Select Photo & Scan", color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthStatPill(
    label: String,
    count: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = count,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextMuted,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
fun FilterChipCompact(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) AppTertiaryMaroon else AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) AppPrimaryGold else AppBorder
        ),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) AppPrimaryGold else AppTextMuted,
                fontSize = 10.5.sp
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
