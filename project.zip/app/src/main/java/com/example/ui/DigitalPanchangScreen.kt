package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.BorderStroke
import com.example.utils.PanchangScannerService
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.OutlinedFlag
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.PanchangEventEntity
import com.example.data.CityLocation
import com.example.data.CityPreferences
import com.example.data.JainKalyanakRepository
import com.example.data.TirthankarDisplayKalyanak
import com.example.ui.components.CitySelectionDialog
import com.example.utils.SolarTimingCalculator
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class CalendarViewMode {
    GRID, LIST
}

enum class PanchangFilter {
    ALL, TITHI, KALYANAK, PARVA
}

enum class PanchangTab {
    CALENDAR, KALYANAK, EVENTS, NOTIFICATIONS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalPanchangScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val rawAllEvents by viewModel.allPanchangEvents.collectAsStateWithLifecycle()
    val allEvents = remember(rawAllEvents) {
        rawAllEvents
            .filter { it.dateString.isNotBlank() }
            .associateBy { it.dateString.trim() }
            .values
            .toList()
    }
    val isScanning by viewModel.isScanningPanchang.collectAsStateWithLifecycle()
    val scanError by viewModel.scanPanchangError.collectAsStateWithLifecycle()
    val extractedDraft by viewModel.extractedPanchangDraft.collectAsStateWithLifecycle()

    var selectedCalendar by remember { mutableStateOf(Calendar.getInstance()) }
    var viewMode by remember { mutableStateOf(CalendarViewMode.GRID) }
    var selectedFilter by remember { mutableStateOf(PanchangFilter.ALL) }
    var activeTab by remember { mutableStateOf(PanchangTab.CALENDAR) }

    val hiddenCalendarEventNames by viewModel.hiddenCalendarEventNames.collectAsStateWithLifecycle()
    val hiddenRepoEventNames by viewModel.hiddenRepoEventNames.collectAsStateWithLifecycle()

    fun isCandidateEvent(event: PanchangEventEntity): Boolean {
        return event.parvasAndEvents.isNotBlank() || event.isImportantTithi
    }

    val allDistinctEventNames = remember(allEvents) {
        val candidateEvents = allEvents.filter { isCandidateEvent(it) }
        candidateEvents.flatMap { getEventFilterNames(it) }.distinct().sorted()
    }

    var showEventFilterDialog by remember { mutableStateOf(false) }

    val todayDateString = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    var selectedDayDateString by remember { mutableStateOf<String?>(todayDateString) }
    var showEditDialogForDate by remember { mutableStateOf<String?>(null) }
    var showScanBottomSheet by remember { mutableStateOf(false) }

    val currentYearMonthStr = remember(selectedCalendar.timeInMillis) {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        sdf.format(selectedCalendar.time)
    }

    val displayMonthYearTitle = remember(selectedCalendar.timeInMillis) {
        val sdfEng = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
        val sdfHindi = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN"))
        "${sdfHindi.format(selectedCalendar.time)} (${sdfEng.format(selectedCalendar.time)})"
    }

    // Filtered events for the month (respecting global hidden calendar events preferences)
    val monthEvents = remember(allEvents, currentYearMonthStr, hiddenCalendarEventNames) {
        val rawEvents = allEvents.filter { it.dateString.startsWith(currentYearMonthStr) }
            .associateBy { it.dateString }

        if (hiddenCalendarEventNames.isEmpty()) {
            rawEvents
        } else {
            rawEvents.mapValues { (_, event) ->
                if (isEventVisible(event, hiddenCalendarEventNames)) {
                    event
                } else {
                    event.copy(
                        parvasAndEvents = "",
                        isImportantTithi = false
                    )
                }
            }
        }
    }

    val selectedDayEvent = remember(allEvents, selectedDayDateString, hiddenCalendarEventNames) {
        if (selectedDayDateString == null) null
        else {
            val raw = allEvents.find { it.dateString == selectedDayDateString }
            if (raw == null || hiddenCalendarEventNames.isEmpty()) {
                raw
            } else {
                if (isEventVisible(raw, hiddenCalendarEventNames)) raw else raw.copy(parvasAndEvents = "", isImportantTithi = false)
            }
        }
    }

    val kalyanakCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.kalyanaks.isNotBlank() }
    }

    val tithiCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.isImportantTithi || it.tithi.isNotBlank() }
    }

    val parvaCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.parvasAndEvents.isNotBlank() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Jain Panchang",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontSize = 18.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "।। तिथि, कल्याणक एवं पर्व निर्णय ।।",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 12.sp
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("panchang_back_calendar_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Back to previous screen",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                actions = {
                    if (activeTab == PanchangTab.CALENDAR) {
                        IconButton(
                            onClick = {
                                showEditDialogForDate = selectedDayDateString ?: todayDateString
                            },
                            modifier = Modifier.testTag("edit_panchang_event_top_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edit Panchang Event",
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        IconButton(
                            onClick = { showScanBottomSheet = true },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("scan_panchang_photo_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FileUpload,
                                contentDescription = "Upload JSON",
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    } else if (activeTab == PanchangTab.EVENTS) {
                        IconButton(
                            onClick = { showEventFilterDialog = true },
                            modifier = Modifier
                                .padding(end = 8.dp)
                                .testTag("events_top_bar_filter_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.FilterList,
                                contentDescription = "Filter Events",
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            PanchangBottomNavigationBar(
                activeTab = activeTab,
                onTabSelected = { activeTab = it }
            )
        },
        modifier = modifier
    ) { innerPadding ->
        val navigatePreviousMonth = {
            val cal = selectedCalendar.clone() as Calendar
            cal.add(Calendar.MONTH, -1)
            selectedCalendar = cal
            val ym = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.time)
            selectedDayDateString = if (todayDateString.startsWith(ym)) todayDateString else "$ym-01"
        }

        val navigateNextMonth = {
            val cal = selectedCalendar.clone() as Calendar
            cal.add(Calendar.MONTH, 1)
            selectedCalendar = cal
            val ym = SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.time)
            selectedDayDateString = if (todayDateString.startsWith(ym)) todayDateString else "$ym-01"
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (activeTab) {
                PanchangTab.CALENDAR -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 8.dp)
                    ) {
                        // Top summary card matching Home screen theme (visible only on Panchang/Calendar tab)
                        TodayPanchangHeaderCard(
                            allEvents = allEvents,
                            selectedCalendar = selectedCalendar,
                            selectedDayDateString = selectedDayDateString,
                            onPreviousMonth = navigatePreviousMonth,
                            onNextMonth = navigateNextMonth
                        )

                        // Main Calendar View (Non-scrolling inside grid, shows all dates on screen, swipe left/right to change month)
                        PanchangGridCalendar(
                            selectedCalendar = selectedCalendar,
                            eventsMap = monthEvents,
                            filter = selectedFilter,
                            selectedDateString = selectedDayDateString,
                            onDayClick = { dateStr, _ ->
                                selectedDayDateString = dateStr
                            },
                            onPreviousMonth = navigatePreviousMonth,
                            onNextMonth = navigateNextMonth,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Centered Kalyanak and Event details in a stylish card in the space between calendar and bottom navigation panel
                        val activeDayDateRaw = selectedDayDateString ?: todayDateString
                        val currentTithi = formatTithiWithoutNumbers(selectedDayEvent?.tithi ?: "", activeDayDateRaw)
                        val currentKalyanak = selectedDayEvent?.kalyanaks?.trim()?.let { formatTithiInHindi(it) } ?: ""
                        val currentEvent = selectedDayEvent?.parvasAndEvents?.trim()?.let { formatTithiInHindi(it) } ?: ""
                        val hasDetails = currentKalyanak.isNotBlank() || currentEvent.isNotBlank()
                        val formattedDateDisplay = remember(activeDayDateRaw) {
                            try {
                                val parsed = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(activeDayDateRaw)
                                if (parsed != null) {
                                    SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(parsed)
                                } else {
                                    activeDayDateRaw
                                }
                            } catch (_: Exception) {
                                activeDayDateRaw
                            }
                        }

                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 4.dp)
                                    .testTag("selected_day_kalyanak_events_card"),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (currentKalyanak.isNotBlank()) AppPrimaryGold.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                ),
                                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                            ) {
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = formattedDateDisplay,
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = AppPrimaryGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            )
                                        )
                                        if (currentTithi.isNotBlank()) {
                                            Text(
                                                text = currentTithi,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = AppPrimaryGold,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp
                                                ),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    if (currentKalyanak.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = currentKalyanak,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFFFFE082),
                                                fontSize = 20.sp,
                                                letterSpacing = 0.5.sp,
                                                shadow = androidx.compose.ui.graphics.Shadow(
                                                    color = Color(0xFFFFC107),
                                                    blurRadius = 24f
                                                )
                                            ),
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )
                                    }

                                    if (currentKalyanak.isNotBlank() && currentEvent.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                    }

                                    if (currentEvent.isNotBlank()) {
                                        Text(
                                            text = currentEvent,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 16.sp,
                                                lineHeight = 22.sp
                                            ),
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(horizontal = 4.dp)
                                        )
                                    }

                                    if (!hasDetails) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = "इस दिन कोई विशेष कल्याणक या पर्व नहीं है (विवरण जोड़ने हेतु टैप करें)",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppTextMuted,
                                                fontSize = 12.sp
                                            ),
                                            textAlign = TextAlign.Center,
                                            modifier = Modifier.padding(vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                PanchangTab.KALYANAK -> {
                    val visibleEventsForKalyanak = remember(allEvents) {
                        allEvents.filter { it.kalyanaks.isNotBlank() }
                    }
                    KalyanaksTabContent(
                        allEvents = visibleEventsForKalyanak,
                        onEditEvent = { event ->
                            showEditDialogForDate = event.dateString
                        },
                        onSelectDateInCalendar = { event ->
                            try {
                                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                                val date = sdf.parse(event.dateString)
                                if (date != null) {
                                    val cal = Calendar.getInstance()
                                    cal.time = date
                                    selectedCalendar = cal
                                }
                            } catch (_: Exception) {}
                            selectedDayDateString = event.dateString
                            activeTab = PanchangTab.CALENDAR
                        }
                    )
                }

                PanchangTab.EVENTS -> {
                    EventsTabContent(
                        allEvents = allEvents,
                        hiddenCalendarEventNames = hiddenCalendarEventNames,
                        hiddenRepoEventNames = hiddenRepoEventNames,
                        allDistinctEventNames = allDistinctEventNames,
                        onOpenFilterDialog = { showEventFilterDialog = true },
                        onResetFilter = { viewModel.updateEventVisibility(emptySet(), emptySet()) },
                        onEditEvent = { event ->
                            showEditDialogForDate = event.dateString
                        },
                        onSelectDateInCalendar = { event ->
                            try {
                                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                                val date = sdf.parse(event.dateString)
                                if (date != null) {
                                    val cal = Calendar.getInstance()
                                    cal.time = date
                                    selectedCalendar = cal
                                }
                            } catch (_: Exception) {}
                            selectedDayDateString = event.dateString
                            activeTab = PanchangTab.CALENDAR
                        }
                    )
                }

                PanchangTab.NOTIFICATIONS -> {
                    PanchangNotificationSettingsTab(
                        allEvents = allEvents
                    )
                }
            }
        }
    }

    // Event Filter Dialog
    if (showEventFilterDialog) {
        EventFilterDialog(
            allDistinctEventNames = allDistinctEventNames,
            hiddenCalendarEventNames = hiddenCalendarEventNames,
            hiddenRepoEventNames = hiddenRepoEventNames,
            allEvents = allEvents,
            onDismiss = { showEventFilterDialog = false },
            onApply = { newHiddenCal, newHiddenRepo ->
                viewModel.updateEventVisibility(newHiddenCal, newHiddenRepo)
            }
        )
    }

    // Day Edit Dialog when triggered from "Edit" button or card
    showEditDialogForDate?.let { dateStr ->
        val targetEvent = remember(dateStr, allEvents) {
            allEvents.find { it.dateString == dateStr }
        }
        DayDetailDialog(
            dateString = dateStr,
            event = targetEvent,
            onDismiss = {
                showEditDialogForDate = null
            },
            onSaveNotes = { updatedEvent ->
                viewModel.addOrUpdatePanchangEvent(updatedEvent)
                showEditDialogForDate = null
                Toast.makeText(context, "Panchang details updated", Toast.LENGTH_SHORT).show()
            },
            onDelete = { eventToDelete ->
                if (eventToDelete.id != 0L) {
                    viewModel.deletePanchangEvent(eventToDelete.id)
                }
                viewModel.deletePanchangEventByDate(eventToDelete.dateString)
                showEditDialogForDate = null
                Toast.makeText(context, "Event removed successfully", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Upload JSON Panchang Dialog / Bottom Sheet
    if (showScanBottomSheet || extractedDraft.isNotEmpty()) {
        PanchangExtractionSheet(
            extractedEvents = extractedDraft,
            onDismiss = {
                showScanBottomSheet = false
                viewModel.clearPanchangDraft()
            },
            onConfirmImport = { selectedEvents ->
                viewModel.saveExtractedDraftPanchangEvents(selectedEvents)
                showScanBottomSheet = false
                Toast.makeText(context, "Successfully imported ${selectedEvents.size} Panchang events!", Toast.LENGTH_LONG).show()
            },
            onPasteJson = { jsonText ->
                viewModel.processPastedPanchangJson(jsonText)
            }
        )
    }
}

@Composable
fun PanchangGridCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    selectedDateString: String? = null,
    onDayClick: (String, PanchangEventEntity?) -> Unit,
    onPreviousMonth: () -> Unit = {},
    onNextMonth: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    // English short form starting with Sunday
    val daysOfWeek = listOf("SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT")

    var totalDragX by remember { mutableFloatStateOf(0f) }

    val yearMonthKey = remember(selectedCalendar.timeInMillis) {
        selectedCalendar.get(Calendar.YEAR) * 12 + selectedCalendar.get(Calendar.MONTH)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .pointerInput(selectedCalendar.timeInMillis) {
                detectHorizontalDragGestures(
                    onDragStart = { totalDragX = 0f },
                    onDragEnd = {
                        if (totalDragX > 50f) {
                            // Swiped Left-to-Right -> Previous Month
                            onPreviousMonth()
                        } else if (totalDragX < -50f) {
                            // Swiped Right-to-Left -> Next Month
                            onNextMonth()
                        }
                        totalDragX = 0f
                    },
                    onDragCancel = { totalDragX = 0f },
                    onHorizontalDrag = { _, dragAmount ->
                        totalDragX += dragAmount
                    }
                )
            }
            .padding(horizontal = 2.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Week Days Header (SUN, MON, TUE, WED, THU, FRI, SAT)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            daysOfWeek.forEach { dayName ->
                Text(
                    text = dayName,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (dayName == "SUN") Color(0xFFFFB300) else Color(0xFFCCCCCC),
                        fontSize = 11.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // All Weeks Rendered with smooth slide animation on month change
        AnimatedContent(
            targetState = yearMonthKey,
            transitionSpec = {
                if (targetState > initialState) {
                    (slideInHorizontally(animationSpec = tween(280)) { width -> width } +
                            fadeIn(animationSpec = tween(280)))
                        .togetherWith(
                            slideOutHorizontally(animationSpec = tween(280)) { width -> -width } +
                                    fadeOut(animationSpec = tween(280))
                        )
                } else {
                    (slideInHorizontally(animationSpec = tween(280)) { width -> -width } +
                            fadeIn(animationSpec = tween(280)))
                        .togetherWith(
                            slideOutHorizontally(animationSpec = tween(280)) { width -> width } +
                                    fadeOut(animationSpec = tween(280))
                        )
                }
            },
            label = "MonthGridSlideAnimation",
            modifier = Modifier.fillMaxWidth()
        ) { monthKey ->
            val cal = remember(monthKey) {
                val c = Calendar.getInstance()
                c.set(Calendar.YEAR, monthKey / 12)
                c.set(Calendar.MONTH, monthKey % 12)
                c.set(Calendar.DAY_OF_MONTH, 1)
                c
            }
            val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1
            val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

            val yearMonthSdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
            val yearMonth = yearMonthSdf.format(cal.time)

            val list = mutableListOf<CalendarGridCellData?>()
            for (i in 0 until firstDayOfWeek) {
                list.add(null)
            }
            for (day in 1..daysInMonth) {
                val dayFormatted = String.format(Locale.US, "%02d", day)
                val fullDateStr = "$yearMonth-$dayFormatted"
                list.add(CalendarGridCellData(dayNumber = day, dateString = fullDateStr))
            }
            while (list.size % 7 != 0) {
                list.add(null)
            }
            val monthWeekRows = list.chunked(7)

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                monthWeekRows.forEach { week ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        week.forEach { cell ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(52.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                if (cell != null) {
                                    val event = eventsMap[cell.dateString]
                                    val isPassFilter = remember(event, filter) {
                                        when (filter) {
                                            PanchangFilter.ALL -> true
                                            PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                                            PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                                            PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
                                        }
                                    }

                                    val isSelectedCell = cell.dateString == selectedDateString

                                    PanchangGridCell(
                                        dayNumber = cell.dayNumber,
                                        event = event,
                                        isHighlightFilter = isPassFilter,
                                        isSelected = isSelectedCell,
                                        onClick = { onDayClick(cell.dateString, event) }
                                    )
                                } else {
                                    Spacer(modifier = Modifier.fillMaxSize())
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CalendarLegendChip(label: String, color: Color, bg: Color) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

data class CalendarGridCellData(
    val dayNumber: Int,
    val dateString: String
)

data class EventColorScheme(
    val borderColor: Color,
    val containerColor: Color,
    val badgeBgColor: Color,
    val badgeTextColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector?,
    val iconTint: Color
)

fun getEventColorScheme(
    event: PanchangEventEntity?,
    isToday: Boolean,
    isSelected: Boolean
): EventColorScheme {
    if (isSelected) {
        return EventColorScheme(
            borderColor = AppPrimaryGold,
            containerColor = Color(0xFF4A121A),
            badgeBgColor = AppPrimaryGold,
            badgeTextColor = Color.Black,
            icon = null,
            iconTint = AppPrimaryGold
        )
    }

    if (event == null) {
        return EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
    }

    val tithiLower = event.tithi.lowercase()

    return when {
        // 1. Tirthankar Kalyanaks -> Saffron Gold
        event.kalyanaks.isNotBlank() -> EventColorScheme(
            borderColor = Color(0xFFFFB300),
            containerColor = Color(0xFF2E220D),
            badgeBgColor = Color(0xFFFFB300),
            badgeTextColor = Color(0xFF2E220D),
            icon = Icons.Default.Star,
            iconTint = Color(0xFFFFD54F)
        )
        // 2. Parvas / Major Festivals -> Royal Purple
        event.parvasAndEvents.isNotBlank() -> EventColorScheme(
            borderColor = Color(0xFFCE93D8),
            containerColor = Color(0xFF2B1D38),
            badgeBgColor = Color(0xFFAB47BC),
            badgeTextColor = Color.White,
            icon = Icons.Default.Flag,
            iconTint = Color(0xFFCE93D8)
        )
        // 3. Aatham (8th Tithi) -> Emerald Green
        tithiLower.contains("8") || tithiLower.contains("८") || tithiLower.contains("आठम") || tithiLower.contains("अष्टमी") || tithiLower.contains("aatham") || tithiLower.contains("ashtami") -> EventColorScheme(
            borderColor = Color(0xFF81C784),
            containerColor = Color(0xFF1B3322),
            badgeBgColor = Color(0xFF2E7D32),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFF81C784)
        )
        // 4. Chaudas (14th Tithi) -> Crimson Red
        tithiLower.contains("14") || tithiLower.contains("१४") || tithiLower.contains("चौदस") || tithiLower.contains("चतुर्दशी") || tithiLower.contains("chaudas") || tithiLower.contains("chaturdashi") -> EventColorScheme(
            borderColor = Color(0xFFE57373),
            containerColor = Color(0xFF381C21),
            badgeBgColor = Color(0xFFC62828),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFFE57373)
        )
        // 5. Agiyaras / Ekadashi (11th Tithi) -> Teal / Cyan
        tithiLower.contains("11") || tithiLower.contains("११") || tithiLower.contains("अग्यारस") || tithiLower.contains("एकादशी") || tithiLower.contains("agiyaras") || tithiLower.contains("ekadashi") -> EventColorScheme(
            borderColor = Color(0xFF4DB6AC),
            containerColor = Color(0xFF1B3335),
            badgeBgColor = Color(0xFF00695C),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFF4DB6AC)
        )
        // 6. Poonam / Amavasya -> Night Indigo / Blue
        tithiLower.contains("पूणम") || tithiLower.contains("पूर्णिमा") || tithiLower.contains("अमावस्या") || tithiLower.contains("अमास") || tithiLower.contains("poonam") || tithiLower.contains("amavasya") -> EventColorScheme(
            borderColor = Color(0xFF7986CB),
            containerColor = Color(0xFF1C2138),
            badgeBgColor = Color(0xFF283593),
            badgeTextColor = Color.White,
            icon = Icons.Default.Brightness7,
            iconTint = Color(0xFF7986CB)
        )
        // 7. Important Tithis -> Coral Saffron
        event.isImportantTithi -> EventColorScheme(
            borderColor = Color(0xFFFF8A65),
            containerColor = Color(0xFF38241C),
            badgeBgColor = Color(0xFFD84315),
            badgeTextColor = Color.White,
            icon = Icons.Default.Bookmark,
            iconTint = Color(0xFFFF8A65)
        )
        // 8. Regular Day with Tithi info
        event.tithi.isNotBlank() -> EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
        else -> EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
    }
}

fun extractHindiTithiNumber(tithiStr: String): String {
    if (tithiStr.isBlank()) return ""
    val trimmed = tithiStr.trim()

    // Check if there are English digits in the string
    val digitMatch = Regex("""\d+""").find(trimmed)
    if (digitMatch != null) {
        return digitMatch.value.toHindiDigits()
    }
    // Check if there are Hindi digits in the string
    val hindiDigitMatch = Regex("""[०-९]+""").find(trimmed)
    if (hindiDigitMatch != null) {
        return hindiDigitMatch.value
    }

    val lower = trimmed.lowercase()
    return when {
        lower.contains("ekam") || lower.contains("pratipada") || lower.contains("padwa") || lower.contains("एकम") || lower.contains("प्रतिपदा") || lower.contains("पड़वा") -> "१"
        lower.contains("bij") || lower.contains("beej") || lower.contains("dwitiya") || lower.contains("बीज") || lower.contains("द्वितीया") -> "२"
        lower.contains("teej") || lower.contains("tritiya") || lower.contains("तीज") || lower.contains("तृतीया") -> "३"
        lower.contains("choth") || lower.contains("chaturthi") || lower.contains("चौथ") || lower.contains("चतुर्थी") -> "४"
        lower.contains("pancham") || lower.contains("panchami") || lower.contains("पंचमी") || lower.contains("पंचम") -> "५"
        lower.contains("chhath") || lower.contains("chhat") || lower.contains("shashthi") || lower.contains("छठ") || lower.contains("षष्ठी") -> "६"
        lower.contains("satam") || lower.contains("saptami") || lower.contains("सातम") || lower.contains("सप्तमी") -> "७"
        lower.contains("aatham") || lower.contains("atham") || lower.contains("ashtami") || lower.contains("आठम") || lower.contains("अष्टमी") -> "८"
        lower.contains("nom") || lower.contains("navam") || lower.contains("navami") || lower.contains("नवमी") || lower.contains("नोम") -> "९"
        lower.contains("dasham") || lower.contains("dashami") || lower.contains("दशम") || lower.contains("दशमी") -> "१०"
        lower.contains("agiyaras") || lower.contains("gyaras") || lower.contains("ekadashi") || lower.contains("अग्यारस") || lower.contains("ग्यारस") || lower.contains("एकादशी") -> "११"
        lower.contains("baras") || lower.contains("dwadashi") || lower.contains("बारस") || lower.contains("द्वादशी") -> "१२"
        lower.contains("terash") || lower.contains("teras") || lower.contains("trayodashi") || lower.contains("तेरस") || lower.contains("त्रयोदशी") -> "१३"
        lower.contains("chaudas") || lower.contains("chaturdashi") || lower.contains("चौदस") || lower.contains("चतुर्दशी") -> "१४"
        lower.contains("poonam") || lower.contains("purnima") || lower.contains("पूर्णिमा") || lower.contains("पूनम") -> "१५"
        lower.contains("amavasya") || lower.contains("amavas") || lower.contains("अमावस्या") || lower.contains("अमास") || lower.contains("अमावस") -> "१५"
        else -> ""
    }
}

fun isSpecialGreenTithi(tithiStr: String): Boolean {
    if (tithiStr.isBlank()) return false
    val lower = tithiStr.trim().lowercase()
    val hindiNum = extractHindiTithiNumber(tithiStr)

    val isPancham = hindiNum == "५" ||
            lower.contains("pancham") || lower.contains("panchami") || lower.contains("pacham") ||
            lower.contains("पंचमी") || lower.contains("पंचम") || lower.contains("पाचम")

    val isAatham = hindiNum == "८" ||
            lower.contains("aatham") || lower.contains("atham") || lower.contains("ashtami") ||
            lower.contains("आठम") || lower.contains("अष्टमी")

    val isChaudas = hindiNum == "१४" ||
            lower.contains("chaudas") || lower.contains("chaturdashi") ||
            lower.contains("चौदस") || lower.contains("चतुर्दशी")

    if (isAatham || isChaudas) {
        return true
    }

    if (isPancham) {
        val isSudi = lower.contains("sudi") || lower.contains("sud") || lower.contains("shukla") ||
                lower.contains("सुदि") || lower.contains("सुदी") || lower.contains("शुक्ल")
        val isVadi = lower.contains("vadi") || lower.contains("vad") || lower.contains("krishna") ||
                lower.contains("वदि") || lower.contains("वदी") || lower.contains("कृष्ण")

        return isSudi && !isVadi
    }

    return false
}

@Composable
fun PanchangGridCell(
    dayNumber: Int,
    event: PanchangEventEntity?,
    isHighlightFilter: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    val todayDateStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
    val isToday = event?.dateString == todayDateStr

    val isGreenTithi = remember(event?.tithi) {
        event != null && isSpecialGreenTithi(event.tithi)
    }

    val hasKalyanak = remember(event?.kalyanaks) {
        event != null && event.kalyanaks.isNotBlank()
    }

    val hasEvent = remember(event?.parvasAndEvents) {
        event != null && event.parvasAndEvents.isNotBlank()
    }

    val hindiTithiNumber = remember(event?.tithi) {
        if (event != null && event.tithi.isNotBlank()) {
            extractHindiTithiNumber(event.tithi)
        } else {
            ""
        }
    }

    val containerBgColor = when {
        isSelected -> Color(0xFF2E2413)
        isGreenTithi -> Color(0xFF09261C) // Deep Emerald theme from HomeScreen Tithi Card
        isToday -> AppSurfaceNested
        else -> AppSurface
    }

    val cellBorderColor = when {
        isSelected -> AppPrimaryGold
        isGreenTithi -> Color(0xFF48CA97) // Vibrant Emerald Green border from HomeScreen Tithi Card
        isToday -> AppPrimaryGold
        else -> AppBorder
    }

    val primaryTextColor = when {
        isGreenTithi -> Color(0xFFA7F3D0) // Mint Emerald text from HomeScreen Tithi Card
        isSelected || isToday -> AppPrimaryGold
        else -> AppTextPrimary
    }

    val cornerDateColor = when {
        isGreenTithi -> Color(0xFF48CA97) // Emerald Green corner date from HomeScreen Tithi Card
        isSelected || isToday -> AppPrimaryGold
        else -> AppTextMuted
    }

    Card(
        modifier = Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 2.dp else if (isToday) 1.5.dp else 0.8.dp,
                color = cellBorderColor,
                shape = RoundedCornerShape(8.dp)
            ),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = containerBgColor
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(3.dp)
        ) {
            // Gregorian Date in the top corner of the block
            Text(
                text = "$dayNumber",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = if (isToday || isSelected || isGreenTithi) FontWeight.Bold else FontWeight.Medium,
                    color = cornerDateColor,
                    fontSize = 10.5.sp
                ),
                modifier = Modifier.align(Alignment.TopStart)
            )

            // Small glowing yellow star on top right corner if date contains Kalyanak
            if (hasKalyanak) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 0.5.dp, end = 0.5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Soft glowing aura
                    Box(
                        modifier = Modifier
                            .size(13.dp)
                            .background(
                                brush = Brush.radialGradient(
                                    colors = listOf(
                                        Color(0xFFFFEA00).copy(alpha = 0.65f),
                                        Color(0xFFFFD600).copy(alpha = 0.25f),
                                        Color.Transparent
                                    )
                                ),
                                shape = CircleShape
                            )
                    )
                    // Core yellow star icon
                    Icon(
                        imageVector = Icons.Filled.Star,
                        contentDescription = "Kalyanak Star",
                        tint = Color(0xFFFFD700),
                        modifier = Modifier.size(10.dp)
                    )
                }
            }

            // Hindi Tithi Number in the center of the block
            if (hindiTithiNumber.isNotBlank()) {
                Text(
                    text = hindiTithiNumber,
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = primaryTextColor,
                        fontSize = 17.5.sp
                    ),
                    modifier = Modifier.align(Alignment.Center),
                    textAlign = TextAlign.Center
                )
            }

            // Small red dot on bottom right side for events/parvas
            if (hasEvent) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(bottom = 1.5.dp, end = 1.5.dp)
                        .size(5.5.dp)
                        .background(
                            color = Color(0xFFEF4444),
                            shape = CircleShape
                        )
                )
            }
        }
    }
}

@Composable
fun MonthKalyanakAndEventsCard(
    selectedCalendar: Calendar,
    monthEvents: Map<String, PanchangEventEntity>,
    selectedDateString: String?,
    onEventClick: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val monthTitle = remember(selectedCalendar.timeInMillis) {
        SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(selectedCalendar.time)
    }

    val specialMonthEvents = remember(monthEvents) {
        monthEvents.values
            .filter { it.kalyanaks.isNotBlank() || it.parvasAndEvents.isNotBlank() }
            .sortedBy { it.dateString }
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("month_kalyanak_events_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = BorderStroke(1.dp, AppBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            // Month name centered at the top of the card
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = monthTitle,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold,
                            fontSize = 16.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "कल्याणक एवं विशेष पर्व",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = AppTextMuted,
                            fontSize = 11.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            HorizontalDivider(
                color = AppBorder.copy(alpha = 0.6f),
                thickness = 0.8.dp
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (specialMonthEvents.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "इस माह में कोई विशेष कल्याणक या पर्व नहीं है।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = AppTextMuted,
                            fontSize = 12.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    specialMonthEvents.forEach { event ->
                        val isSelected = event.dateString == selectedDateString
                        val dateFormatted = remember(event.dateString) {
                            try {
                                val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(event.dateString)
                                if (d != null) {
                                    SimpleDateFormat("dd MMM (EEE)", Locale.ENGLISH).format(d)
                                } else event.dateString
                            } catch (_: Exception) {
                                event.dateString
                            }
                        }
                        val tithiFormatted = remember(event.tithi) {
                            if (event.tithi.isNotBlank()) formatTithiInHindi(event.tithi) else ""
                        }
                        val kalyanakFormatted = remember(event.kalyanaks) {
                            if (event.kalyanaks.isNotBlank()) formatTithiInHindi(event.kalyanaks) else ""
                        }
                        val eventFormatted = remember(event.parvasAndEvents) {
                            if (event.parvasAndEvents.isNotBlank()) formatTithiInHindi(event.parvasAndEvents) else ""
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onEventClick(event.dateString) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) Color(0xFF2E2413) else AppSurfaceNested,
                            border = BorderStroke(
                                width = if (isSelected) 1.5.dp else 0.8.dp,
                                color = if (isSelected) AppPrimaryGold else AppBorder.copy(alpha = 0.5f)
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Date Badge
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (isSelected) AppPrimaryGold else AppDeepSurface,
                                    border = BorderStroke(0.8.dp, if (isSelected) AppPrimaryGold else AppBorder)
                                ) {
                                    Text(
                                        text = dateFormatted,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = if (isSelected) Color.Black else AppTextPrimary,
                                            fontSize = 11.sp
                                        ),
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
                                        textAlign = TextAlign.Center
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                // Details: Tithi + Kalyanak + Special Event
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(2.dp)
                                ) {
                                    // Tithi name
                                    if (tithiFormatted.isNotBlank()) {
                                        Text(
                                            text = tithiFormatted,
                                            style = MaterialTheme.typography.labelMedium.copy(
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (isSelected) AppPrimaryGold else AppTextPrimary,
                                                fontSize = 12.sp
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    // Kalyanak Name (with yellow star)
                                    if (kalyanakFormatted.isNotBlank()) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Star,
                                                contentDescription = null,
                                                tint = Color(0xFFFFD700),
                                                modifier = Modifier.size(13.dp)
                                            )
                                            Text(
                                                text = kalyanakFormatted,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFFFD700),
                                                    fontSize = 11.5.sp
                                                ),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }

                                    // Special Event Name (with red dot)
                                    if (eventFormatted.isNotBlank()) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .background(Color(0xFFEF4444), CircleShape)
                                            )
                                            Text(
                                                text = eventFormatted,
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontWeight = FontWeight.Medium,
                                                    color = Color(0xFFCE93D8),
                                                    fontSize = 11.5.sp
                                                ),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PanchangListCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    onDayClick: (String, PanchangEventEntity?) -> Unit
) {
    val yearMonthSdf = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()) }
    val currentYearMonth = yearMonthSdf.format(selectedCalendar.time)
    val daysInMonth = selectedCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

    val dateList = remember(selectedCalendar.timeInMillis) {
        (1..daysInMonth).map { day ->
            val formattedDay = String.format("%02d", day)
            "$currentYearMonth-$formattedDay"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(dateList) { dateStr ->
            val event = eventsMap[dateStr]
            val isPassFilter = when (filter) {
                PanchangFilter.ALL -> true
                PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
            }

            if (isPassFilter) {
                PanchangListRowCard(
                    dateString = dateStr,
                    event = event,
                    onClick = { onDayClick(dateStr, event) }
                )
            }
        }
    }
}

@Composable
fun PanchangListRowCard(
    dateString: String,
    event: PanchangEventEntity?,
    onClick: () -> Unit
) {
    val formattedDateText = remember(dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMM, EEEE", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            dateString
        }
    }

    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val isToday = dateString == todayDateStr
    val scheme = remember(event, isToday) { getEventColorScheme(event, isToday = isToday, isSelected = false) }

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(
                1.2.dp,
                scheme.borderColor,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = scheme.containerColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Date Badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = scheme.badgeBgColor,
                modifier = Modifier.width(90.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = scheme.badgeTextColor,
                            fontSize = 11.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                if (event != null && event.tithi.isNotBlank()) {
                    Text(
                        text = "तिथि: ${event.tithi}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (event.isImportantTithi || hasKalyanak) scheme.borderColor else AppTextPrimary
                        )
                    )
                } else {
                    Text(
                        text = "कोई विशेष तिथि दर्ज नहीं",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )
                }

                if (hasKalyanak) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "✨ ${event?.kalyanaks}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                if (hasParva) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "🚩 ${event?.parvasAndEvents}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFCE93D8)
                        )
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppTextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun DayDetailDialog(
    dateString: String,
    event: PanchangEventEntity?,
    onDismiss: () -> Unit,
    onSaveNotes: (PanchangEventEntity) -> Unit,
    onDelete: ((PanchangEventEntity) -> Unit)? = null
) {
    val defaultCalculatedTithi = remember(event, dateString) {
        if (!event?.tithi.isNullOrBlank()) {
            val cleaned = formatTithiWithoutNumbers(event!!.tithi, dateString)
            if (cleaned.isNotBlank()) cleaned else event.tithi
        } else {
            formatTithiWithoutNumbers("", dateString)
        }
    }
    var tithiInput by remember(event, defaultCalculatedTithi) {
        mutableStateOf(if (!event?.tithi.isNullOrBlank()) event!!.tithi else defaultCalculatedTithi)
    }
    var kalyanakInput by remember(event) { mutableStateOf(event?.kalyanaks ?: "") }
    var parvaInput by remember(event) { mutableStateOf(event?.parvasAndEvents ?: "") }
    var notesInput by remember(event) { mutableStateOf(event?.notes ?: "") }
    var isImportant by remember(event) { mutableStateOf(event?.isImportantTithi ?: false) }
    var navkarsiInput by remember(event) { mutableStateOf(event?.navkarsiTime ?: "") }
    var sunsetInput by remember(event) { mutableStateOf(event?.sunsetTime ?: "") }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    val formattedDateHeader = remember(dateString) {
        try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateString)
            if (d != null) {
                SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN")).format(d)
            } else dateString
        } catch (_: Exception) {
            dateString
        }
    }

    if (showDeleteConfirm && event != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = {
                Text(
                    text = "इवेंट हटाएं (Delete Event)",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFEF5350)
                )
            },
            text = {
                Text(
                    text = "क्या आप इस दिन ($dateString) के पंचांग विवरण एवं कल्याणक को हटाना चाहते हैं?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirm = false
                        onDelete?.invoke(event)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F))
                ) {
                    Text("हटाएं (Delete)", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("रद्द करें", color = AppTextMuted)
                }
            },
            containerColor = AppSurface,
            shape = RoundedCornerShape(16.dp)
        )
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "पंचांग विवरण बदलें (Edit Event)",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold,
                            fontSize = 17.sp
                        )
                    )
                    Text(
                        text = "$formattedDateHeader • $dateString",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = AppTextMuted,
                            fontSize = 11.sp
                        )
                    )
                }
                if (event != null && onDelete != null) {
                    IconButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete event",
                            tint = Color(0xFFEF5350),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Tithi input
                OutlinedTextField(
                    value = tithiInput,
                    onValueChange = { tithiInput = it },
                    label = { Text("जैन तिथि (जैसे: भाद्रपद सुदि २ / Bij)") },
                    placeholder = { Text("उदा. भाद्रपद सुदि पंचमी") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AppPrimaryGold,
                        focusedLabelColor = AppPrimaryGold
                    )
                )

                // Important Tithi Checkbox
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    border = BorderStroke(0.6.dp, if (isImportant) AppPrimaryGold else AppBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isImportant = !isImportant }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isImportant,
                            onCheckedChange = { isImportant = it },
                            colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = "⭐ विशेष तिथि (Important Tithi)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isImportant) AppPrimaryGold else AppTextPrimary
                                )
                            )
                            Text(
                                text = "एकादशी, चौदस, पूनम, अमावस, पंचमी, अष्टमी आदि",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppTextMuted,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                }

                // Kalyanak input
                OutlinedTextField(
                    value = kalyanakInput,
                    onValueChange = { kalyanakInput = it },
                    label = { Text("तीर्थंकर कल्याणक (Kalyanak)") },
                    placeholder = { Text("उदा. श्री वासुपूज्य स्वामी निर्वाण कल्याणक") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFD700), modifier = Modifier.size(18.dp))
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFFFD700),
                        focusedLabelColor = Color(0xFFFFD700)
                    )
                )

                // Parva / Event input
                OutlinedTextField(
                    value = parvaInput,
                    onValueChange = { parvaInput = it },
                    label = { Text("पर्व / त्यौहार / विशेष नियम (Parva / Event)") },
                    placeholder = { Text("उदा. पर्युषण महापर्व प्रारंभ, रोहिणी तप") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    leadingIcon = {
                        Icon(Icons.Default.Flag, contentDescription = null, tint = Color(0xFFCE93D8), modifier = Modifier.size(18.dp))
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFFBA68C8),
                        focusedLabelColor = Color(0xFFBA68C8)
                    )
                )

                // Timings overrides (Navkarsi / Sunset)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = navkarsiInput,
                        onValueChange = { navkarsiInput = it },
                        label = { Text("नवकारशी") },
                        placeholder = { Text("06:48 AM") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = sunsetInput,
                        onValueChange = { sunsetInput = it },
                        label = { Text("सूर्यास्त") },
                        placeholder = { Text("07:02 PM") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }

                // Notes input
                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("अन्य निर्देश एवं नोट्स (Special Notes)") },
                    placeholder = { Text("उदा. क्षय तिथि, आयंबिल, उपवास...") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = event?.copy(
                        tithi = tithiInput.trim(),
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput.trim(),
                        parvasAndEvents = parvaInput.trim(),
                        navkarsiTime = navkarsiInput.trim(),
                        sunsetTime = sunsetInput.trim(),
                        notes = notesInput.trim()
                    ) ?: PanchangEventEntity(
                        dateString = dateString,
                        tithi = tithiInput.trim(),
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput.trim(),
                        parvasAndEvents = parvaInput.trim(),
                        navkarsiTime = navkarsiInput.trim(),
                        sunsetTime = sunsetInput.trim(),
                        notes = notesInput.trim()
                    )
                    onSaveNotes(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Save,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("सुरक्षित करें (Save)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें (Cancel)", color = AppTextMuted)
            }
        },
        containerColor = AppSurface,
        shape = RoundedCornerShape(18.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanchangExtractionSheet(
    extractedEvents: List<PanchangEventEntity>,
    onDismiss: () -> Unit,
    onConfirmImport: (List<PanchangEventEntity>) -> Unit,
    onPasteJson: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedItemIds by remember(extractedEvents) {
        mutableStateOf(extractedEvents.mapIndexed { index, _ -> index }.toSet())
    }
    var pastedJsonInput by remember { mutableStateOf("") }

    val jsonFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { fileUri: Uri? ->
        fileUri?.let { uri ->
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val jsonContent = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (jsonContent.isNotBlank()) {
                    onPasteJson(jsonContent)
                } else {
                    Toast.makeText(context, "Selected JSON file is empty", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to read JSON file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = AppSurface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (extractedEvents.isNotEmpty()) {
                Text(
                    text = "Extracted ${extractedEvents.size} Panchang Entries",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(extractedEvents.size) { index ->
                        val item = extractedEvents[index]
                        val isChecked = selectedItemIds.contains(index)

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedItemIds = if (checked) {
                                            selectedItemIds + index
                                        } else {
                                            selectedItemIds - index
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.dateString} • ${item.tithi}",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppTextPrimary
                                        )
                                    )
                                    if (item.kalyanaks.isNotBlank()) {
                                        Text(
                                            text = "⭐ ${item.kalyanaks}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppPrimaryGold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val selectedList = extractedEvents.filterIndexed { index, _ -> selectedItemIds.contains(index) }
                        onConfirmImport(selectedList)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Import ${selectedItemIds.size} Events into Digital Calendar",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📁 Upload Panchang JSON File",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select or paste a Panchang JSON file to import events into your calendar:",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // UPLOAD JSON FILE CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, AppPrimaryGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Upload JSON File (.json)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Select a Panchang JSON file from your device storage:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { jsonFileLauncher.launch("*/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upload_json_file_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("📁 Select & Upload JSON File", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // PASTE JSON TEXT CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Or Paste JSON Text",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Paste Panchang JSON array text directly below:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = pastedJsonInput,
                                onValueChange = { pastedJsonInput = it },
                                label = { Text("Paste JSON Array") },
                                placeholder = { Text("[{\"dateString\": \"2026-08-15\", \"tithi\": \"Sud Teej\"}, ...]") },
                                maxLines = 5,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_pasted_json_input"),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    if (pastedJsonInput.isNotBlank()) {
                                        onPasteJson(pastedJsonInput)
                                    }
                                },
                                enabled = pastedJsonInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_import_pasted_json_button")
                            ) {
                                Text("Import Pasted JSON Text", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthStatPill(
    label: String,
    count: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = count,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextMuted,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
fun FilterChipCompact(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) AppTertiaryMaroon else AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) AppPrimaryGold else AppBorder
        ),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) AppPrimaryGold else AppTextMuted,
                fontSize = 10.5.sp
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SelectedDateDetailBelowCalendarCard(
    dateString: String,
    event: PanchangEventEntity?
) {
    val formattedDateText = remember(dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
            val engSdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
            "${outSdf.format(date)} / ${engSdf.format(date)}"
        } catch (e: Exception) {
            dateString
        }
    }

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true
    val isImportantTithi = event?.isImportantTithi == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (hasKalyanak) AppPrimaryGold else AppTertiaryMaroon.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Selected Date Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = AppPrimaryGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Date Details",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Formatted Date
            Text(
                text = formattedDateText,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = AppTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Tithi Info Row
            val formattedTithi = if (event != null && event.tithi.isNotBlank()) {
                val cleaned = formatTithiInPureHindi(event.tithi, dateString)
                if (cleaned.isNotBlank()) cleaned else formatTithiWithoutNumbers(event.tithi, dateString).ifBlank { event.tithi }
            } else ""

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isImportantTithi) AppTertiaryMaroon else AppDeepSurface
                ) {
                    Text(
                        text = if (formattedTithi.isNotBlank()) "तिथि: $formattedTithi" else "तिथि: सामान्य दिन",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isImportantTithi) AppPrimaryGold else AppTextPrimary
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                if (isImportantTithi) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AppSecondaryGreen.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "⭐ विशेष तिथि (Agiyaras/Chaudas/Poonam)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppSecondaryGreen,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Kalyanaks Box
            if (hasKalyanak) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "कल्याणक (Kalyanak)",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppPrimaryGold,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = event?.kalyanaks ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }

            // Parva Box
            if (hasParva) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFCE93D8).copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Celebration,
                            contentDescription = null,
                            tint = Color(0xFFCE93D8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "पर्व / त्यौहार / विशेष नियम",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFCE93D8),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = event?.parvasAndEvents ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timings Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("नवकारशी", style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted, fontSize = 9.sp))
                            Text(
                                text = event?.navkarsiTime?.takeIf { it.isNotBlank() } ?: "07:15 AM",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("सूर्योदय", style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted, fontSize = 9.sp))
                            Text(
                                text = event?.sunriseTime?.takeIf { it.isNotBlank() } ?: "06:15 AM",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NightsStay,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("चौविहार", style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted, fontSize = 9.sp))
                            Text(
                                text = event?.sunsetTime?.takeIf { it.isNotBlank() } ?: "06:45 PM",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
                            )
                        }
                    }
                }
            }
        }
    }
}

data class TirthankaraDefinition(
    val number: Int,
    val name: String,
    val hindiSymbol: String,
    val aliases: List<String>
)

val ALL_24_TIRTHANKARAS = listOf(
    TirthankaraDefinition(1, "Rishabhdev Bhagwan", "बैल", listOf("ऋषभदेव", "ऋषभ नाथ", "ऋषभनाथ", "ऋषभ", "आदिनाथ", "ऋषभनाथ स्वामी", "आदीश्वर", "rishabhdev", "adinath", "rushabh", "rishabh")),
    TirthankaraDefinition(2, "Ajitnath Bhagwan", "हाथी", listOf("अजितनाथ", "अजीतनाथ", "अजित स्वामी", "अजित प्रभु", "अजितनाथ स्वामी", "अजीतनाथ स्वामी", "ajitnath", "ajit swami")),
    TirthankaraDefinition(3, "Sambhavnath Bhagwan", "घोड़ा", listOf("सम्भवनाथ", "संभवनाथ", "सम्भव स्वामी", "संभव स्वामी", "सम्भवनाथ स्वामी", "संभवनाथ स्वामी", "sambhavnath")),
    TirthankaraDefinition(4, "Abhinandannath Bhagwan", "बन्दर", listOf("अभिनन्दननाथ", "अभिनंदननाथ", "अभिनन्दन स्वामी", "अभिनंदन स्वामी", "अभिनन्दननाथ स्वामी", "अभिनंदननाथ स्वामी", "abhinandan", "abhinandannath")),
    TirthankaraDefinition(5, "Sumatinath Bhagwan", "चकवा", listOf("सुमतिनाथ", "सुमति स्वामी", "सुमतिनाथ स्वामी", "sumatinath")),
    TirthankaraDefinition(6, "Padmaprabha Bhagwan", "लाल कमल", listOf("पद्मप्रभ", "पद्मप्रभु", "पदमप्रभ", "पद्मप्रभ स्वामी", "पद्मप्रभु स्वामी", "padmaprabha", "padmaprabhu")),
    TirthankaraDefinition(7, "Suparshvanath Bhagwan", "स्वस्तिक", listOf("सुपार्श्वनाथ", "सुपार्श्व स्वामी", "सुपार्श्वनाथ स्वामी", "suparshvanath", "suparshva", "suparshwa")),
    TirthankaraDefinition(8, "Chandraprabha Bhagwan", "चन्द्रमा", listOf("चन्द्रप्रभ", "चंद्रप्रभ", "चन्द्रप्रभु", "चंद्रप्रभु", "chandraprabha", "chandraprabhu")),
    TirthankaraDefinition(9, "Suvidhinath Bhagwan", "मगर", listOf("सुविधिनाथ", "सुविधि", "पुष्पदन्त", "पुष्पदंत", "suvidhinath", "pushpadanta", "pushpadant")),
    TirthankaraDefinition(10, "Shitalnath Bhagwan", "श्रीवत्स / कल्पवृक्ष", listOf("शीतलनाथ", "शीतल", "shitalnath", "shital")),
    TirthankaraDefinition(11, "Shreyansnath Bhagwan", "गैंडा", listOf("श्रेयांसनाथ", "श्रेयान्सनाथ", "श्रेयांस", "श्रेयान्स", "shreyansnath", "shreyans")),
    TirthankaraDefinition(12, "Vasupujya Bhagwan", "भैंसा", listOf("वासुपूज्य", "वासुपूज्य स्वामी", "वासुपूज्या", "vasupujya")),
    TirthankaraDefinition(13, "Vimalnath Bhagwan", "शूकर (वराह)", listOf("विमलनाथ", "विमल", "vimalnath", "vimal")),
    TirthankaraDefinition(14, "Anantnath Bhagwan", "सेही (बाज़)", listOf("अनन्तनाथ", "अनंतनाथ", "अनन्त", "अनंत", "anantnath", "anant")),
    TirthankaraDefinition(15, "Dharmanath Bhagwan", "वज्रदण्ड", listOf("धर्मनाथ", "धर्म", "dharmanath", "dharma")),
    TirthankaraDefinition(16, "Shantinath Bhagwan", "हिरण", listOf("शान्तिनाथ", "शांतिनाथ", "शान्ति", "शांति", "shantinath", "shanti")),
    TirthankaraDefinition(17, "Kunthunath Bhagwan", "बकरा", listOf("कुन्थुनाथ", "कुंथुनाथ", "कुन्थु", "कुंथु", "kunthunath", "kunthu")),
    TirthankaraDefinition(18, "Aranath Bhagwan", "मछली (नन्द्यावर्त)", listOf("अरहनाथ", "अरनाथ", "अर", "aranath", "arahnath")),
    TirthankaraDefinition(19, "Mallinath Bhagwan", "कलश", listOf("मल्लिनाथ", "मल्लीनाथ", "मल्लि", "मल्ली", "mallinath", "malli")),
    TirthankaraDefinition(20, "Munisuvratnath Bhagwan", "कछुआ", listOf("मुनिसुव्रतनाथ", "मुनिसुव्रत", "मुनिसुव्रत स्वामी", "munisuvratnath", "munisuvrat")),
    TirthankaraDefinition(21, "Naminath Bhagwan", "नीलकमल", listOf("नमिनाथ", "नमीनाथ", "नमि", "naminath")),
    TirthankaraDefinition(22, "Neminath Bhagwan", "शंख", listOf("नेमिनाथ", "अरिष्टनेमि", "नेमि", "neminath", "arishtanemi")),
    TirthankaraDefinition(23, "Parshvanath Bhagwan", "सर्प", listOf("पार्श्वनाथ", "पारसनाथ", "पार्श्व", "पारस", "parshvanath", "parasnath", "parshva")),
    TirthankaraDefinition(24, "Mahavira Swami Bhagwan", "सिंह", listOf("महावीर", "वर्धमान", "सन्मति", "महावीर स्वामी", "महावीर प्रभु", "वीर प्रभु", "mahavira", "mahavir", "vardhaman"))
)

enum class KalyanakCategory(val order: Int, val hindiName: String, val rawHindiName: String, val englishLabel: String, val searchKeywords: List<String>) {
    CHYAVAN(1, "1. च्यवन कल्याणक", "च्यवन कल्याणक", "Chyavan Kalyanak", listOf("च्यवन", "गर्भ", "गर्भावतरण", "chyavan", "garbha")),
    JANMA(2, "2. जन्म कल्याणक", "जन्म कल्याणक", "Janma Kalyanak", listOf("जन्म", "प्राकट्य", "janma", "birth")),
    DIKSHA(3, "3. दीक्षा कल्याणक", "दीक्षा कल्याणक", "Diksha Kalyanak", listOf("दीक्षा", "तप", "वैराग्य", "diksha", "tap")),
    KEVALGYAN(4, "4. केवलज्ञान कल्याणक", "केवलज्ञान कल्याणक", "Kevalgyan Kalyanak", listOf("केवलज्ञान", "ज्ञान", "केवल", "kevalgyan", "kevalgnyan", "gnyan")),
    NIRVANA(5, "5. निर्वाण कल्याणक", "निर्वाण कल्याणक", "Nirvana Kalyanak", listOf("निर्वाण", "मोक्ष", "nirvan", "nirvana", "moksh", "moksha"))
}

@Composable
fun KalyanaksTabContent(
    allEvents: List<PanchangEventEntity>,
    onEditEvent: (PanchangEventEntity) -> Unit = {},
    onSelectDateInCalendar: (PanchangEventEntity) -> Unit
) {
    // Requirement: All 24 Tirthankara cards collapsed by default
    var expandedTirthankaraIds by remember { mutableStateOf(setOf<Int>()) }

    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    // Resolve ONLY Tirthankaras and Kalyanaks that are PRESENT in the active calendar
    val tirthankarGroups = remember(allEvents) {
        JainKalyanakRepository.resolvePresentInCalendarTirthankarKalyanaks(allEvents)
    }

    // All Kalyanaks that are present in the calendar
    val calendarKalyanaks = remember(tirthankarGroups) {
        tirthankarGroups.flatMap { it.second }.filter { it.isPresentInCalendar && it.eventDateString != null }
    }

    // Find the next upcoming Kalyanak
    val upcomingKalyanak = remember(calendarKalyanaks, todayDateString) {
        calendarKalyanaks
            .filter { (it.eventDateString ?: "") >= todayDateString }
            .minByOrNull { it.eventDateString ?: "" }
            ?: calendarKalyanaks.minByOrNull { it.eventDateString ?: "" }
    }

    // Calculate days remaining
    val daysRemaining = remember(upcomingKalyanak?.eventDateString, todayDateString) {
        if (upcomingKalyanak?.eventDateString == null) ""
        else {
            try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val eventDate = sdf.parse(upcomingKalyanak.eventDateString)
                val today = sdf.parse(todayDateString)
                if (eventDate != null && today != null) {
                    val diff = ((eventDate.time - today.time) / (1000 * 60 * 60 * 24)).toInt()
                    when {
                        diff == 0 -> "आज (Today)"
                        diff == 1 -> "कल (Tomorrow)"
                        diff > 1 -> "$diff दिन शेष"
                        else -> "आगामी"
                    }
                } else ""
            } catch (_: Exception) { "" }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp)
    ) {
        // 8. Upcoming Kalyanak Card at Top matching exact height, layout and style of TodayPanchangHeaderCard
        if (upcomingKalyanak != null) {
            SharedHeaderCardContainer(
                testTag = "upcoming_kalyanak_header_card",
                bgDrawableResId = com.example.R.drawable.bg_upcoming_kalyanak
            ) {
                // Top Row: Title + Date on left, Tithi & Status badge on right
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Upcoming Kalyanak",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = AppTextPrimary,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = upcomingKalyanak.formattedDateText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.5.sp
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = upcomingKalyanak.traditionalTithi
                                .replace(Regex("\\s*\\([^)]*\\)"), "")
                                .replace("(", "")
                                .replace(")", "")
                                .trim()
                                .ifBlank { "—" },
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFF7BE495),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFB300).copy(alpha = 0.12f),
                            border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFFFB300).copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = if (daysRemaining.isNotBlank()) daysRemaining else "Upcoming",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFFFE082),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                            )
                        }
                    }
                }

                // Centerpiece: Radial gold glow box with Tirthankara & Kalyanak Name in single row matching Today's Panchang centerpiece height exactly
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    AppPrimaryGold.copy(alpha = 0.25f),
                                    AppPrimaryGold.copy(alpha = 0.08f),
                                    Color.Transparent
                                )
                            )
                        )
                        .border(
                            0.75.dp,
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    AppPrimaryGold.copy(alpha = 0.6f),
                                    Color.Transparent
                                )
                            ),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(vertical = 4.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 40.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "❖",
                            color = AppPrimaryGold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(start = 8.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = JainKalyanakRepository.cleanKalyanakTitle(upcomingKalyanak.customTitle, upcomingKalyanak.category.rawHindiName),
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFFFE082),
                                    fontSize = 22.sp,
                                    letterSpacing = 0.6.sp,
                                    shadow = androidx.compose.ui.graphics.Shadow(
                                        color = AppPrimaryGold.copy(alpha = 0.85f),
                                        blurRadius = 16f
                                    )
                                ),
                                maxLines = 1
                            )
                        }

                        Text(
                            text = "❖",
                            color = AppPrimaryGold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }

                // Bottom Badges: Tirthankara Name Card & Tithi Card (equal dimensions & styling)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(androidx.compose.foundation.layout.IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Tirthankara Name directly without serial number
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF1E261E),
                        border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFF81C784).copy(alpha = 0.35f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = upcomingKalyanak.tirthankar.name,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFA5D6A7),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Tithi Card directly without "तिथि" label
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF231E17),
                        border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFFFB300).copy(alpha = 0.35f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = upcomingKalyanak.traditionalTithi
                                    .replace(Regex("\\s*\\([^)]*\\)"), "")
                                    .replace("(", "")
                                    .replace(")", "")
                                    .trim()
                                    .ifBlank { upcomingKalyanak.formattedDateText },
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFFFE082),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (tirthankarGroups.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.EventBusy,
                        contentDescription = null,
                        tint = AppTextMuted,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No Kalyanak dates available",
                        style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 110.dp)
            ) {
                items(tirthankarGroups, key = { it.first.number }) { (tirthankar, kalyanaks) ->
                    val isExpanded = expandedTirthankaraIds.contains(tirthankar.number)
                    val rotationAngle by animateFloatAsState(
                        targetValue = if (isExpanded) 180f else 0f,
                        label = "dropdown_arrow"
                    )

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                expandedTirthankaraIds = if (isExpanded) {
                                    expandedTirthankaraIds - tirthankar.number
                                } else {
                                    expandedTirthankaraIds + tirthankar.number
                                }
                            }
                            .testTag("tirthankar_kalyanak_card_${tirthankar.number}"),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isExpanded) AppSurface.copy(alpha = 0.95f) else AppSurface
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isExpanded) AppPrimaryGold else AppPrimaryGold.copy(alpha = 0.35f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            // Header Row: Number + Name in English + Symbol in Hindi + Dropdown Arrow
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // Golden Circular Number Badge
                                    Surface(
                                        shape = CircleShape,
                                        color = AppTertiaryMaroon,
                                        border = BorderStroke(1.dp, AppPrimaryGold),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${tirthankar.number}",
                                                style = MaterialTheme.typography.labelMedium.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = AppPrimaryGold,
                                                    fontSize = 13.sp
                                                )
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = "${tirthankar.number}. ${tirthankar.name}",
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = AppPrimaryGold,
                                                fontSize = 15.sp
                                            ),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        // 6. Symbol name in Hindi: लांछन : [हिन्दी नाम]
                                        Text(
                                            text = "लांछन : ${tirthankar.hindiSymbol}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppTextMuted,
                                                fontWeight = FontWeight.Medium,
                                                fontSize = 12.sp
                                            )
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        expandedTirthankaraIds = if (isExpanded) {
                                            expandedTirthankaraIds - tirthankar.number
                                        } else {
                                            expandedTirthankaraIds + tirthankar.number
                                        }
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.KeyboardArrowDown,
                                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                                        tint = AppPrimaryGold,
                                        modifier = Modifier.rotate(rotationAngle)
                                    )
                                }
                            }

                            // 9. Drop-down kalyanak list in a 3-column row layout
                            AnimatedVisibility(
                                visible = isExpanded,
                                enter = expandVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + fadeIn(),
                                exit = shrinkVertically(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) + fadeOut()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 10.dp)
                                ) {
                                    HorizontalDivider(
                                        color = AppPrimaryGold.copy(alpha = 0.25f),
                                        thickness = 1.dp,
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )

                                    // 3-Column Kalyanak Rows (All 5 Kalyanak dates for each Tirthankara)
                                    kalyanaks.forEachIndexed { index, item ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(
                                                    if (index % 2 == 1) AppDeepSurface.copy(alpha = 0.5f) else Color.Transparent,
                                                    shape = RoundedCornerShape(6.dp)
                                                )
                                                .then(
                                                    if (item.isPresentInCalendar && item.event != null) {
                                                        Modifier.clickable { onSelectDateInCalendar(item.event) }
                                                    } else Modifier
                                                )
                                                .padding(horizontal = 4.dp, vertical = 7.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            // Left Column: Kalyanak name from calendar (without Tirthankar name prefix)
                                            Text(
                                                text = JainKalyanakRepository.cleanKalyanakTitle(item.customTitle, item.category.rawHindiName),
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = AppTextPrimary,
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 12.sp
                                                ),
                                                modifier = Modifier.weight(1.3f)
                                            )

                                            // Center Column: Traditional Tithi
                                            Text(
                                                text = item.traditionalTithi
                                                    .replace(Regex("\\s*\\([^)]*\\)"), "")
                                                    .replace("(", "")
                                                    .replace(")", "")
                                                    .trim()
                                                    .ifBlank { "—" },
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    color = AppSecondaryGreen,
                                                    fontWeight = FontWeight.Medium,
                                                    fontSize = 11.5.sp
                                                ),
                                                textAlign = TextAlign.Center,
                                                modifier = Modifier.weight(1.1f)
                                            )

                                            // Right Column: Date (Linked to Calendar if present)
                                            Box(
                                                modifier = Modifier.weight(0.9f),
                                                contentAlignment = Alignment.CenterEnd
                                            ) {
                                                if (item.isPresentInCalendar && item.event != null) {
                                                    Surface(
                                                        shape = RoundedCornerShape(6.dp),
                                                        color = AppPrimaryGold.copy(alpha = 0.15f),
                                                        border = BorderStroke(0.6.dp, AppPrimaryGold.copy(alpha = 0.45f))
                                                    ) {
                                                        Text(
                                                            text = item.formattedDateText,
                                                            style = MaterialTheme.typography.bodySmall.copy(
                                                                color = Color(0xFFFFE082),
                                                                fontWeight = FontWeight.Bold,
                                                                fontSize = 11.sp
                                                            ),
                                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                } else {
                                                    Text(
                                                        text = item.formattedDateText,
                                                        style = MaterialTheme.typography.bodySmall.copy(
                                                            color = AppTextMuted.copy(alpha = 0.7f),
                                                            fontWeight = FontWeight.Medium,
                                                            fontSize = 11.5.sp
                                                        ),
                                                        textAlign = TextAlign.End
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

fun cleanTithiName(rawTithi: String): String {
    if (rawTithi.isBlank()) return ""
    val monthsRegex = Regex(
        "(?i)\\b(श्रावण|भाद्रपद|भादरवो|आसोज|आसो|कार्तिक|मार्गशीर्ष|पौष|माघ|फाल्गुण|फागुन|चैत्र|वैशाख|ज्येष्ठ|अषाढ़|आषाढ़|Shravan|Bhadrapad|Aasoj|Kartik|Margsirsha|Paush|Magh|Falgun|Chaitra|Vaishakh|Jeshtha|Ashadh)\\b"
    )
    val pakshaRegex = Regex(
        "(?i)\\b(वदि|सुदि|वद|सुद|कृष्ण|शुक्ल|Vad|Sud|vadi|sudi)\\b"
    )
    val numberInBracketsRegex = Regex("\\([0-9०-९\\s]+\\)")

    val cleaned = rawTithi
        .replace(monthsRegex, "")
        .replace(pakshaRegex, "")
        .replace(numberInBracketsRegex, "")
        .replace(Regex("^[\\s,.-]+|[\\s,.-]+$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    return cleaned.ifBlank { rawTithi.trim() }
}

fun getEventFilterNames(event: PanchangEventEntity): List<String> {
    val list = mutableListOf<String>()
    if (event.parvasAndEvents.isNotBlank()) {
        event.parvasAndEvents.split(",", "/", "\n", "|", "॥").map { it.trim() }.filter { it.isNotBlank() }.forEach {
            list.add(it)
        }
    }
    if (event.isImportantTithi && event.parvasAndEvents.isBlank()) {
        val tithiClean = cleanTithiName(event.tithi)
        val name = if (tithiClean.isNotBlank()) "विशेष तिथि: $tithiClean" else "विशेष तिथि"
        list.add(name)
    }
    return list.distinct()
}

fun isEventVisible(event: PanchangEventEntity, hiddenEventNames: Set<String>): Boolean {
    if (hiddenEventNames.isEmpty()) return true

    val eventNames = getEventFilterNames(event)
    if (eventNames.isEmpty()) {
        // If event has no parvas or special tithi, it's not subject to event filter hiding
        return true
    }

    // Visible if and only if at least one of its event names is NOT hidden
    return eventNames.any { it !in hiddenEventNames }
}

@Composable
fun EventFilterDialog(
    allDistinctEventNames: List<String>,
    hiddenCalendarEventNames: Set<String>,
    hiddenRepoEventNames: Set<String>,
    allEvents: List<PanchangEventEntity>,
    onDismiss: () -> Unit,
    onApply: (hiddenCalendar: Set<String>, hiddenRepo: Set<String>) -> Unit
) {
    var calendarSelected by remember(hiddenCalendarEventNames, allDistinctEventNames) {
        mutableStateOf(allDistinctEventNames.filter { it !in hiddenCalendarEventNames }.toSet())
    }
    var repoSelected by remember(hiddenRepoEventNames, hiddenCalendarEventNames, allDistinctEventNames) {
        mutableStateOf(allDistinctEventNames.filter { it !in hiddenCalendarEventNames && it !in hiddenRepoEventNames }.toSet())
    }

    val eventNameCounts = remember(allEvents, allDistinctEventNames) {
        allDistinctEventNames.associateWith { name ->
            allEvents.count { ev ->
                getEventFilterNames(ev).contains(name)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "Event Filters",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = "कैलेंडर एवं इवेंट्स दृश्यता",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppPrimaryGold,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "प्रत्येक इवेंट के लिए चयन करें। कैलेंडर से हटाने पर इवेंट्स सूची से भी स्वतः हट जाएगा।",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted, fontSize = 11.5.sp)
                )
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(
                        onClick = {
                            calendarSelected = allDistinctEventNames.toSet()
                            repoSelected = allDistinctEventNames.toSet()
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Select All", fontSize = 12.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                    }
                    TextButton(
                        onClick = {
                            calendarSelected = emptySet()
                            repoSelected = emptySet()
                        },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Clear All", fontSize = 12.sp, color = AppTextMuted, fontWeight = FontWeight.Medium)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Table Column Headers
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    color = AppDeepSurface.copy(alpha = 0.8f),
                    border = BorderStroke(0.6.dp, AppBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Event / पर्व",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AppPrimaryGold,
                                fontSize = 11.5.sp
                            ),
                            modifier = Modifier.weight(1f)
                        )

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(54.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "कैलेंडर",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.5.sp,
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.width(54.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Flag,
                                contentDescription = null,
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = "इवेंट्स",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 9.5.sp,
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                if (allDistinctEventNames.isEmpty()) {
                    Text(
                        text = "No event names found",
                        style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted),
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 300.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(allDistinctEventNames, key = { it }) { eventName ->
                            val isCalChecked = eventName in calendarSelected
                            val isRepoChecked = isCalChecked && (eventName in repoSelected)
                            val isRepoEnabled = isCalChecked
                            val count = eventNameCounts[eventName] ?: 0

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isCalChecked) AppSurface else AppSurface.copy(alpha = 0.4f),
                                border = BorderStroke(
                                    0.5.dp,
                                    if (isCalChecked) AppBorder else AppBorder.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = eventName,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = if (isCalChecked) AppTextPrimary else AppTextMuted,
                                                fontWeight = if (isCalChecked) FontWeight.SemiBold else FontWeight.Normal,
                                                fontSize = 12.5.sp
                                            ),
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "$count dates",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = AppPrimaryGold.copy(alpha = 0.7f),
                                                fontSize = 10.sp
                                            )
                                        )
                                    }

                                    // Checkbox 1: Calendar
                                    Box(
                                        modifier = Modifier.width(54.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Checkbox(
                                            checked = isCalChecked,
                                            onCheckedChange = { checked ->
                                                if (checked) {
                                                    calendarSelected = calendarSelected + eventName
                                                    repoSelected = repoSelected + eventName
                                                } else {
                                                    calendarSelected = calendarSelected - eventName
                                                    repoSelected = repoSelected - eventName
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = AppPrimaryGold,
                                                uncheckedColor = AppTextMuted
                                            ),
                                            modifier = Modifier.testTag("filter_cal_cb_$eventName")
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(4.dp))

                                    // Checkbox 2: Events Repository (auto unchecked and disabled if Calendar is unchecked)
                                    Box(
                                        modifier = Modifier.width(54.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Checkbox(
                                            checked = isRepoChecked,
                                            enabled = isRepoEnabled,
                                            onCheckedChange = { checked ->
                                                if (isRepoEnabled) {
                                                    repoSelected = if (checked) repoSelected + eventName else repoSelected - eventName
                                                }
                                            },
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = AppPrimaryGold,
                                                uncheckedColor = AppTextMuted,
                                                disabledCheckedColor = AppTextMuted.copy(alpha = 0.3f),
                                                disabledUncheckedColor = AppTextMuted.copy(alpha = 0.15f)
                                            ),
                                            modifier = Modifier.testTag("filter_repo_cb_$eventName")
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val newHiddenCalendar = allDistinctEventNames.toSet() - calendarSelected
                    val newHiddenRepo = allDistinctEventNames.toSet() - repoSelected
                    onApply(newHiddenCalendar, newHiddenRepo)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon),
                modifier = Modifier.testTag("apply_event_filter_button")
            ) {
                Text("Apply Filter", color = AppPrimaryGold, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AppTextMuted)
            }
        },
        containerColor = AppDeepSurface,
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun EventsTabContent(
    allEvents: List<PanchangEventEntity>,
    hiddenCalendarEventNames: Set<String>,
    hiddenRepoEventNames: Set<String>,
    allDistinctEventNames: List<String>,
    onOpenFilterDialog: () -> Unit,
    onResetFilter: () -> Unit,
    onEditEvent: (PanchangEventEntity) -> Unit = {},
    onSelectDateInCalendar: (PanchangEventEntity) -> Unit
) {
    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    val isFilterActive = remember(hiddenCalendarEventNames, hiddenRepoEventNames) {
        hiddenCalendarEventNames.isNotEmpty() || hiddenRepoEventNames.isNotEmpty()
    }

    val parvaEvents = remember(allEvents, hiddenCalendarEventNames, hiddenRepoEventNames) {
        val candidateEvents = allEvents.filter {
            it.parvasAndEvents.isNotBlank() || it.isImportantTithi
        }
        candidateEvents
            .filter { isEventVisible(it, hiddenCalendarEventNames) && isEventVisible(it, hiddenRepoEventNames) }
            .sortedBy { it.dateString }
    }

    // Find the next upcoming Event from the visible repository events
    val upcomingEvent = remember(parvaEvents, todayDateString) {
        parvaEvents
            .filter { it.dateString >= todayDateString }
            .minByOrNull { it.dateString }
            ?: parvaEvents.minByOrNull { it.dateString }
    }

    // Calculate days remaining for upcoming event
    val daysRemaining = remember(upcomingEvent?.dateString, todayDateString) {
        if (upcomingEvent?.dateString == null) ""
        else {
            try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val eventDate = sdf.parse(upcomingEvent.dateString)
                val today = sdf.parse(todayDateString)
                if (eventDate != null && today != null) {
                    val diff = ((eventDate.time - today.time) / (1000 * 60 * 60 * 24)).toInt()
                    when {
                        diff == 0 -> "आज (Today)"
                        diff == 1 -> "कल (Tomorrow)"
                        diff > 1 -> "$diff दिन शेष"
                        else -> "आगामी"
                    }
                } else ""
            } catch (_: Exception) { "" }
        }
    }

    val formattedUpcomingDateText = remember(upcomingEvent?.dateString) {
        if (upcomingEvent?.dateString == null) ""
        else {
            try {
                val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val date = inSdf.parse(upcomingEvent.dateString) ?: Date()
                val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
                outSdf.format(date)
            } catch (_: Exception) {
                upcomingEvent.dateString
            }
        }
    }

    val upcomingEventTitle = remember(upcomingEvent) {
        if (upcomingEvent == null) ""
        else {
            val raw = upcomingEvent.parvasAndEvents.trim()
            if (raw.isNotBlank()) formatTithiInHindi(raw)
            else if (upcomingEvent.isImportantTithi) "विशेष तिथि"
            else "पर्व / त्यौहार"
        }
    }

    val upcomingEventTithi = remember(upcomingEvent) {
        if (upcomingEvent == null) ""
        else {
            formatTithiInPureHindi(upcomingEvent.tithi, upcomingEvent.dateString)
                .ifBlank {
                    formatTithiWithoutNumbers(upcomingEvent.tithi, upcomingEvent.dateString)
                }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp)
    ) {
        // Upcoming Event Card at Top matching exact height, layout and style of Upcoming Kalyanak Card
        if (upcomingEvent != null) {
            SharedHeaderCardContainer(
                testTag = "upcoming_event_header_card",
                bgDrawableResId = com.example.R.drawable.bg_upcoming_kalyanak
            ) {
                // Top Row: Title + Date on left, Tithi & Status badge on right
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Upcoming Event",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = AppTextPrimary,
                                fontSize = 14.sp
                            )
                        )
                        Text(
                            text = formattedUpcomingDateText,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppPrimaryGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 10.5.sp
                            )
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = upcomingEventTithi.ifBlank { "—" },
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFF7BE495),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFFFB300).copy(alpha = 0.12f),
                            border = BorderStroke(0.6.dp, Color(0xFFFFB300).copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = if (daysRemaining.isNotBlank()) daysRemaining else "Upcoming",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFFFE082),
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp)
                            )
                        }
                    }
                }

                // Centerpiece: Radial gold glow box with Event Title in single row matching Upcoming Kalyanak centerpiece height exactly
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.radialGradient(
                                colors = listOf(
                                    AppPrimaryGold.copy(alpha = 0.25f),
                                    AppPrimaryGold.copy(alpha = 0.08f),
                                    Color.Transparent
                                )
                            )
                        )
                        .border(
                            0.75.dp,
                            Brush.horizontalGradient(
                                listOf(
                                    Color.Transparent,
                                    AppPrimaryGold.copy(alpha = 0.6f),
                                    Color.Transparent
                                )
                            ),
                            RoundedCornerShape(12.dp)
                        )
                        .padding(vertical = 4.dp, horizontal = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 40.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "❖",
                            color = AppPrimaryGold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(start = 8.dp)
                        )

                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .weight(1f, fill = false)
                                .padding(horizontal = 4.dp)
                        ) {
                            Text(
                                text = upcomingEventTitle,
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = Color(0xFFFFE082),
                                    fontSize = 22.sp,
                                    letterSpacing = 0.6.sp,
                                    shadow = androidx.compose.ui.graphics.Shadow(
                                        color = AppPrimaryGold.copy(alpha = 0.85f),
                                        blurRadius = 16f
                                    )
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Text(
                            text = "❖",
                            color = AppPrimaryGold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(end = 8.dp)
                        )
                    }
                }

                // Bottom Badges: Event Category / Status & Tithi Details (matching Kalyanak card bottom badges)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(androidx.compose.foundation.layout.IntrinsicSize.Min),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Badge: Festival / Event label
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF1E261E),
                        border = BorderStroke(0.6.dp, Color(0xFF81C784).copy(alpha = 0.35f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = if (upcomingEvent.isImportantTithi) "विशेष तिथि (Special Tithi)" else "जैन पर्व / उत्सव",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFA5D6A7),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Right Badge: Tithi Card directly
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(),
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFF231E17),
                        border = BorderStroke(0.6.dp, Color(0xFFFFB300).copy(alpha = 0.35f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp, vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = upcomingEventTithi.ifBlank { formattedUpcomingDateText },
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color(0xFFFFE082),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                ),
                                textAlign = TextAlign.Center,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        if (parvaEvents.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No events match current filter preferences.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )
                    if (isFilterActive) {
                        Spacer(modifier = Modifier.height(10.dp))
                        TextButton(onClick = onResetFilter) {
                            Text("Reset Event Filters", color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 110.dp)
            ) {
                items(parvaEvents) { event ->
                    EventCardItem(
                        event = event,
                        onEditEvent = { onEditEvent(event) },
                        onViewInCalendar = { onSelectDateInCalendar(event) }
                    )
                }
            }
        }
    }
}

@Composable
fun EventCardItem(
    event: PanchangEventEntity,
    onEditEvent: () -> Unit = {},
    onViewInCalendar: () -> Unit
) {
    val formattedDateText = remember(event.dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(event.dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            event.dateString
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Flag,
                        contentDescription = null,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalIconButton(
                        onClick = onEditEvent,
                        modifier = Modifier.size(30.dp),
                        colors = IconButtonDefaults.filledTonalIconButtonColors(
                            containerColor = AppPrimaryGold.copy(alpha = 0.15f),
                            contentColor = AppPrimaryGold
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit Event",
                            modifier = Modifier.size(15.dp)
                        )
                    }

                    Button(
                        onClick = onViewInCalendar,
                        colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.height(30.dp)
                    ) {
                        Text("📅 कैलेंडर", fontSize = 11.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            val pureHindiTithi = remember(event.tithi, event.dateString) {
                formatTithiInPureHindi(event.tithi, event.dateString).ifBlank { event.tithi }
            }

            if (event.parvasAndEvents.isNotBlank()) {
                Text(
                    text = "🚩 ${event.parvasAndEvents}",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
            } else {
                Text(
                    text = "⭐ विशेष तिथि: $pureHindiTithi",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppSecondaryGreen
                    )
                )
            }

            if (event.tithi.isNotBlank() && event.parvasAndEvents.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "तिथि: $pureHindiTithi",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppSecondaryGreen, fontWeight = FontWeight.Medium)
                )
            }
        }
    }
}

fun String.toHindiDigits(): String {
    val englishToHindi = mapOf(
        '0' to '०',
        '1' to '१',
        '2' to '२',
        '3' to '३',
        '4' to '४',
        '5' to '५',
        '6' to '६',
        '7' to '७',
        '8' to '८',
        '9' to '९'
    )
    return this.map { englishToHindi[it] ?: it }.joinToString("")
}

fun formatTithiWithoutNumbers(rawTithi: String, dateString: String? = null): String {
    val trimmed = rawTithi.trim()
    if (trimmed.isEmpty()) return ""

    // 1. Detect / extract Month
    val lower = trimmed.lowercase()
    val monthMap = listOf(
        listOf("shravana", "shravan", "sarvan", "श्रावण", "सावन") to "श्रावण",
        listOf("bhadrapada", "bhadrapad", "bhadarvo", "bhadva", "भाद्रपद", "भादरवो", "भादवा") to "भाद्रपद",
        listOf("ashwin", "aasoj", "aso", "asvin", "आश्विन", "आसोज", "आसो") to "आश्विन",
        listOf("kartika", "kartik", "kartak", "कार्तिक", "कारतक", "कातिक") to "कार्तिक",
        listOf("margashirsha", "margsirsha", "magshar", "magsar", "मार्गशीर्ष", "मगसर", "अगहन") to "मार्गशीर्ष",
        listOf("pausha", "paush", "posh", "पौष", "पोष", "पूस") to "पौष",
        listOf("magha", "magh", "maha", "माघ", "महा", "माह") to "माघ",
        listOf("phalguna", "phalgun", "falgun", "fagan", "फाल्गुन", "फागण", "फागुन") to "फाल्गुन",
        listOf("chaitra", "chait", "chaitar", "चैत्र", "चैत", "चेतर") to "चैत्र",
        listOf("vaishakha", "vaishakh", "vaisakh", "vaishak", "वैशाख", "बैसाख") to "वैशाख",
        listOf("jyeshtha", "jeshtha", "jeth", "ज्येष्ठ", "जेठ") to "ज्येष्ठ",
        listOf("ashadha", "ashadh", "asadh", "aashad", "आषाढ़", "असाढ़", "आषाढ") to "आषाढ़"
    )

    var detectedMonth: String? = null
    for ((keywords, monthName) in monthMap) {
        if (keywords.any { lower.contains(it) }) {
            detectedMonth = monthName
            break
        }
    }

    if (detectedMonth == null && !dateString.isNullOrBlank()) {
        detectedMonth = try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateString)
            if (date != null) {
                val cal = Calendar.getInstance().apply { time = date }
                when (cal.get(Calendar.MONTH)) {
                    0 -> "पौष"
                    1 -> "माघ"
                    2 -> "फाल्गुन"
                    3 -> "चैत्र"
                    4 -> "वैशाख"
                    5 -> "ज्येष्ठ"
                    6 -> "आषाढ़"
                    7 -> "श्रावण"
                    8 -> "भाद्रपद"
                    9 -> "आश्विन"
                    10 -> "कार्तिक"
                    11 -> "मार्गशीर्ष"
                    else -> "श्रावण"
                }
            } else "श्रावण"
        } catch (_: Exception) {
            "श्रावण"
        }
    }
    if (detectedMonth == null) detectedMonth = "श्रावण"

    // 2. Detect Paksha (सुदी or वदी)
    val isVadi = listOf("vadi", "vad", "वदी", "वदि", "वद", "krishna", "कृष्ण", "बदी", "बदि", "बद", "badi", "bad", "andhari", "अंधारी").any {
        lower.contains(it)
    }
    val detectedPaksha = if (isVadi) "वदी" else "सुदी"

    // 3. Extract Tithi Number / Word accurately
    var numericTithi: Int? = null

    // Check English digits (ignoring full years like 2024, 2025, 2026, 2027)
    val englishDigitMatches = Regex("""\d+""").findAll(trimmed).map { it.value }.toList()
    for (m in englishDigitMatches) {
        val num = m.toIntOrNull()
        if (num != null && num in 1..30 && num != 2024 && num != 2025 && num != 2026 && num != 2027) {
            numericTithi = num
            break
        }
    }

    // Check Hindi digits if not found
    if (numericTithi == null) {
        val hindiDigitMatches = Regex("""[०-९]+""").findAll(trimmed).map { it.value }.toList()
        for (m in hindiDigitMatches) {
            val engStr = m.map {
                when (it) {
                    '०' -> '0'; '१' -> '1'; '२' -> '2'; '३' -> '3'; '४' -> '4'
                    '५' -> '5'; '६' -> '6'; '७' -> '7'; '८' -> '8'; '९' -> '9'
                    else -> it
                }
            }.joinToString("")
            val num = engStr.toIntOrNull()
            if (num != null && num in 1..30 && num != 2024 && num != 2025 && num != 2026 && num != 2027) {
                numericTithi = num
                break
            }
        }
    }

    var detectedTithi: String? = null
    if (numericTithi != null) {
        detectedTithi = when (numericTithi) {
            1 -> "एकम"
            2 -> "बीज"
            3 -> "तीज"
            4 -> "चौथ"
            5 -> "पंचमी"
            6 -> "छठ"
            7 -> "सातम"
            8 -> "आठम"
            9 -> "नवमी"
            10 -> "दशमी"
            11 -> "ग्यारस"
            12 -> "बारस"
            13 -> "तेरस"
            14 -> "चौदस"
            15 -> if (isVadi) "अमावस्या" else "पूनम"
            30 -> "अमावस्या"
            else -> "एकम"
        }
    }

    // If no numeric digits, match textual names in Hindi / Gujarati / English
    if (detectedTithi == null) {
        detectedTithi = when {
            lower.contains("amavasya") || lower.contains("amavas") || lower.contains("amas") || lower.contains("अमावस्या") || lower.contains("अमास") || lower.contains("अमावस") -> "अमावस्या"
            lower.contains("poonam") || lower.contains("purnima") || lower.contains("punam") || lower.contains("पूर्णिमा") || lower.contains("पूनम") || lower.contains("पूणम") -> if (isVadi) "अमावस्या" else "पूनम"
            lower.contains("chaudas") || lower.contains("chaturdashi") || lower.contains("chaudash") || lower.contains("चौदस") || lower.contains("चतुर्दशी") || lower.contains("चौदश") -> "चौदस"
            lower.contains("terash") || lower.contains("teras") || lower.contains("trayodashi") || lower.contains("तेरस") || lower.contains("त्रयोदशी") || lower.contains("तेराश") -> "तेरस"
            lower.contains("baras") || lower.contains("dwadashi") || lower.contains("बारस") || lower.contains("द्वादशी") -> "बारस"
            lower.contains("agiyaras") || lower.contains("gyaras") || lower.contains("ekadashi") || lower.contains("agyaras") || lower.contains("ग्यारस") || lower.contains("अग्यारस") || lower.contains("एकादशी") -> "ग्यारस"
            lower.contains("dasham") || lower.contains("dashami") || lower.contains("दशम") || lower.contains("दशमी") -> "दशमी"
            lower.contains("navam") || lower.contains("navami") || lower.contains("nom") || lower.contains("नवमी") || lower.contains("नोम") || lower.contains("नवं") -> "नवमी"
            lower.contains("aatham") || lower.contains("atham") || lower.contains("ashtami") || lower.contains("आठम") || lower.contains("अष्टमी") -> "आठम"
            lower.contains("satam") || lower.contains("saptami") || lower.contains("saatam") || lower.contains("सातम") || lower.contains("सप्तमी") -> "सातम"
            lower.contains("chhath") || lower.contains("chhat") || lower.contains("shashthi") || lower.contains("shasthi") || lower.contains("छठ") || lower.contains("षष्ठी") || lower.contains("छट") -> "छठ"
            lower.contains("pancham") || lower.contains("panchami") || lower.contains("pacham") || lower.contains("पंचम") || lower.contains("पंचमी") || lower.contains("पाचम") -> "पंचमी"
            lower.contains("choth") || lower.contains("chaturthi") || lower.contains("चौथ") || lower.contains("चतुर्थी") -> "चौथ"
            lower.contains("teej") || lower.contains("tritiya") || lower.contains("तीज") || lower.contains("तृतीया") -> "तीज"
            lower.contains("bij") || lower.contains("beej") || lower.contains("dwitiya") || lower.contains("dooj") || lower.contains("बीज") || lower.contains("द्वितीया") || lower.contains("दूज") -> "बीज"
            lower.contains("ekam") || lower.contains("pratipada") || lower.contains("padwa") || lower.contains("एकम") || lower.contains("प्रतिपदा") || lower.contains("पड़वा") -> "एकम"
            else -> ""
        }
    }

    if (detectedTithi.isBlank()) {
        return ""
    }

    return "$detectedMonth $detectedPaksha $detectedTithi"
}

fun formatTithiInPureHindi(rawTithi: String, dateString: String? = null): String {
    val trimmed = rawTithi.trim()
    if (trimmed.isEmpty()) return ""

    // 1. Remove all parentheses and bracketed contents, e.g. (१२), (12), (३०)
    var text = trimmed.replace(Regex("\\s*\\([^)]*\\)"), "")
        .replace("(", "")
        .replace(")", "")
        .replace("[", "")
        .replace("]", "")
        .trim()

    // 2. Map English / Romanized tithi and paksha words to pure Hindi
    val wordReplacements = listOf(
        Regex("(?i)\\bEkam\\b") to "एकम",
        Regex("(?i)\\bPratipada\\b") to "पड़वा",
        Regex("(?i)\\bPadwa\\b") to "पड़वा",
        Regex("(?i)\\bBij\\b") to "बीज",
        Regex("(?i)\\bBeej\\b") to "बीज",
        Regex("(?i)\\bDooj\\b") to "दूज",
        Regex("(?i)\\bDwitiya\\b") to "बीज",
        Regex("(?i)\\bTrij\\b") to "तीज",
        Regex("(?i)\\bTeej\\b") to "तीज",
        Regex("(?i)\\bTritiya\\b") to "तीज",
        Regex("(?i)\\bChoth\\b") to "चौथ",
        Regex("(?i)\\bChaturthi\\b") to "चौथ",
        Regex("(?i)\\bPancham\\b") to "पंचम",
        Regex("(?i)\\bPanchami\\b") to "पंचमी",
        Regex("(?i)\\bPacham\\b") to "पंचम",
        Regex("(?i)\\bChhath\\b") to "छठ",
        Regex("(?i)\\bChhat\\b") to "छठ",
        Regex("(?i)\\bShashthi\\b") to "छठ",
        Regex("(?i)\\bShasthi\\b") to "छठ",
        Regex("(?i)\\bSaatam\\b") to "सातम",
        Regex("(?i)\\bSatam\\b") to "सातम",
        Regex("(?i)\\bSaptami\\b") to "सातम",
        Regex("(?i)\\bAatham\\b") to "आठम",
        Regex("(?i)\\bAtham\\b") to "आठम",
        Regex("(?i)\\bAshtami\\b") to "आठम",
        Regex("(?i)\\bNaom\\b") to "नवमी",
        Regex("(?i)\\bNom\\b") to "नवमी",
        Regex("(?i)\\bNavam\\b") to "नवमी",
        Regex("(?i)\\bNavami\\b") to "नवमी",
        Regex("(?i)\\bDasam\\b") to "दशम",
        Regex("(?i)\\bDasham\\b") to "दशम",
        Regex("(?i)\\bDashami\\b") to "दशमी",
        Regex("(?i)\\bAgiyaras\\b") to "ग्यारस",
        Regex("(?i)\\bGyaras\\b") to "ग्यारस",
        Regex("(?i)\\bAgyaras\\b") to "ग्यारस",
        Regex("(?i)\\bEkadashi\\b") to "एकादशी",
        Regex("(?i)\\bBaras\\b") to "बारस",
        Regex("(?i)\\bDwadashi\\b") to "द्वादशी",
        Regex("(?i)\\bTeras\\b") to "तेरस",
        Regex("(?i)\\bTerash\\b") to "तेरस",
        Regex("(?i)\\bTrayodashi\\b") to "तेरस",
        Regex("(?i)\\bChaudas\\b") to "चौदस",
        Regex("(?i)\\bChaturdashi\\b") to "चौदस",
        Regex("(?i)\\bChaudash\\b") to "चौदस",
        Regex("(?i)\\bPoonam\\b") to "पूनम",
        Regex("(?i)\\bPurnima\\b") to "पूर्णिमा",
        Regex("(?i)\\bPunam\\b") to "पूनम",
        Regex("(?i)\\bAmavasya\\b") to "अमावस्या",
        Regex("(?i)\\bAmavas\\b") to "अमावस्या",
        Regex("(?i)\\bAmas\\b") to "अमावस्या",
        Regex("(?i)\\bSudi\\b") to "सुदि",
        Regex("(?i)\\bSud\\b") to "सुद",
        Regex("(?i)\\bVadi\\b") to "वदि",
        Regex("(?i)\\bVad\\b") to "वद",
        Regex("(?i)\\bShukla\\b") to "शुक्ल",
        Regex("(?i)\\bKrishna\\b") to "कृष्ण",
        Regex("(?i)\\bShravana\\b") to "श्रावण",
        Regex("(?i)\\bShravan\\b") to "श्रावण",
        Regex("(?i)\\bSarvan\\b") to "श्रावण",
        Regex("(?i)\\bBhadrapada\\b") to "भाद्रपद",
        Regex("(?i)\\bBhadrapad\\b") to "भाद्रपद",
        Regex("(?i)\\bBhadarvo\\b") to "भाद्रपद",
        Regex("(?i)\\bBhadva\\b") to "भाद्रपद",
        Regex("(?i)\\bAshwin\\b") to "आश्विन",
        Regex("(?i)\\bAasoj\\b") to "आश्विन",
        Regex("(?i)\\bAso\\b") to "आश्विन",
        Regex("(?i)\\bKartika\\b") to "कार्तिक",
        Regex("(?i)\\bKartik\\b") to "कार्तिक",
        Regex("(?i)\\bKartak\\b") to "कार्तिक",
        Regex("(?i)\\bMargashirsha\\b") to "मार्गशीर्ष",
        Regex("(?i)\\bMagsar\\b") to "मार्गशीर्ष",
        Regex("(?i)\\bPausha\\b") to "पौष",
        Regex("(?i)\\bPaush\\b") to "पौष",
        Regex("(?i)\\bPosh\\b") to "पौष",
        Regex("(?i)\\bMagha\\b") to "माघ",
        Regex("(?i)\\bMagh\\b") to "माघ",
        Regex("(?i)\\bMaha\\b") to "माघ",
        Regex("(?i)\\bPhalguna\\b") to "फाल्गुन",
        Regex("(?i)\\bPhalgun\\b") to "फाल्गुन",
        Regex("(?i)\\bFalgun\\b") to "फाल्गुन",
        Regex("(?i)\\bFagan\\b") to "फाल्गुन",
        Regex("(?i)\\bChaitra\\b") to "चैत्र",
        Regex("(?i)\\bChait\\b") to "चैत्र",
        Regex("(?i)\\bChaitar\\b") to "चैत्र",
        Regex("(?i)\\bVaishakha\\b") to "वैशाख",
        Regex("(?i)\\bVaishakh\\b") to "वैशाख",
        Regex("(?i)\\bJyeshtha\\b") to "ज्येष्ठ",
        Regex("(?i)\\bJeth\\b") to "ज्येष्ठ",
        Regex("(?i)\\bAshadha\\b") to "आषाढ़",
        Regex("(?i)\\bAshadh\\b") to "आषाढ़",
        Regex("(?i)\\bAashad\\b") to "आषाढ़"
    )

    for ((regex, replacement) in wordReplacements) {
        text = text.replace(regex, replacement)
    }

    // 3. Remove standalone numbers remaining (like 12 or १२) if any
    text = text.replace(Regex("""\b\d+\b"""), "")
        .replace(Regex("""[०-९]+"""), "")
        .replace(Regex("""\s+"""), " ")
        .trim()

    // 4. Fallback check if text became too short or lost tithi name
    if (text.isBlank() || text.split(" ").size < 2) {
        val fallback = formatTithiWithoutNumbers(trimmed, dateString)
        if (fallback.isNotBlank()) {
            return fallback
        }
    }

    return text
}

fun formatTithiInHindi(rawTithi: String): String {
    var clean = rawTithi
    val romanToHindi = listOf(
        "Ekam" to "एकम", "Bij" to "बीज", "Teej" to "तीज", "Choth" to "चौथ",
        "Pancham" to "पंचमी", "Panchami" to "पंचमी", "Chhath" to "छठ", "Satam" to "सातम", "Aatham" to "आठम",
        "Atham" to "आठम", "Nom" to "नवमी", "Navami" to "नवमी", "Navam" to "नवमी", "Dasham" to "दशम", "Dashami" to "दशमी",
        "Agiyaras" to "ग्यारस", "Gyaras" to "ग्यारस", "Ekadashi" to "एकादशी",
        "Baras" to "बारस", "Dwadashi" to "द्वादशी", "Terash" to "तेरस", "Teras" to "तेरस", "Trayodashi" to "त्रयोदशी",
        "Chaudas" to "चौदस", "Chaturdashi" to "चतुर्दशी", "Poonam" to "पूनम", "Purnima" to "पूर्णिमा",
        "Amavasya" to "अमावस्या", "Amavas" to "अमावस्या",
        "Sudi" to "सुदी", "Sud" to "सुदी", "Vadi" to "वदी", "Vad" to "वदी", "Shukla" to "शुक्ल", "Krishna" to "कृष्ण"
    )
    for ((roman, hindi) in romanToHindi) {
        clean = clean.replace(Regex("(?i)\\b$roman\\b"), hindi)
    }

    clean = clean
        .replace("सुदि", "सुदी")
        .replace("वदि", "वदी")
        .toHindiDigits()

    return clean
}

@Composable
fun TodayPanchangHeaderCard(
    allEvents: List<PanchangEventEntity>,
    selectedCalendar: Calendar,
    selectedDayDateString: String? = null,
    onPreviousMonth: () -> Unit,
    onNextMonth: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val selectedCity by CityPreferences.selectedCityFlow.collectAsStateWithLifecycle()
    var showCityDialog by remember { mutableStateOf(false) }

    if (showCityDialog) {
        CitySelectionDialog(
            selectedCity = selectedCity,
            onCitySelected = { newCity ->
                CityPreferences.saveSelectedCity(context, newCity)
                Toast.makeText(
                    context,
                    "City updated to ${newCity.hindiName} (${newCity.name})",
                    Toast.LENGTH_SHORT
                ).show()
            },
            onDismiss = { showCityDialog = false }
        )
    }

    val currentYearMonthStr = remember(selectedCalendar.timeInMillis) {
        SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(selectedCalendar.time)
    }

    val todayDateString = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }

    val activeDateString = remember(selectedCalendar.timeInMillis, selectedDayDateString) {
        if (selectedDayDateString != null && selectedDayDateString.startsWith(currentYearMonthStr)) {
            selectedDayDateString
        } else if (todayDateString.startsWith(currentYearMonthStr)) {
            todayDateString
        } else {
            "$currentYearMonthStr-01"
        }
    }

    val activeCal = remember(activeDateString, selectedCalendar.timeInMillis) {
        val cal = selectedCalendar.clone() as Calendar
        try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(activeDateString)
            if (date != null) cal.time = date
        } catch (_: Exception) {}
        cal
    }

    var solarTimings by remember(activeDateString, selectedCity.id) {
        mutableStateOf(SolarTimingCalculator.calculateLocalSolarTimings(activeCal, selectedCity))
    }

    LaunchedEffect(activeDateString, selectedCity.id) {
        val live = SolarTimingCalculator.getLiveSolarTimings(activeCal, selectedCity)
        solarTimings = live
    }

    val displayMonthEnglish = remember(selectedCalendar.timeInMillis) {
        SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(selectedCalendar.time)
    }

    val activeEnglishDate = remember(activeDateString) {
        try {
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(activeDateString)
            if (date != null) {
                SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(date)
            } else {
                SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
            }
        } catch (e: Exception) {
            SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
        }
    }

    val activeEvent = remember(allEvents, activeDateString) {
        allEvents.find { it.dateString == activeDateString }
    }

    // Dynamic Vikram Samvat & Veer Nirwan Samvat based on month & year
    val calYear = selectedCalendar.get(Calendar.YEAR)
    val calMonth = selectedCalendar.get(Calendar.MONTH) + 1 // 1..12
    val vsNum = if (calMonth >= 11) calYear + 57 + 1 else calYear + 57
    val vnsNum = if (calMonth >= 11) calYear + 526 + 1 else calYear + 526
    val vikramSamvat = vsNum.toString().toHindiDigits()
    val veerNirwan = vnsNum.toString().toHindiDigits()

    val tithiText = remember(activeEvent?.tithi, activeDateString) {
        formatTithiWithoutNumbers(activeEvent?.tithi ?: "", activeDateString)
    }

    val kalyanak = activeEvent?.kalyanaks?.trim()?.let { formatTithiInHindi(it) } ?: ""
    val specialEvent = activeEvent?.parvasAndEvents?.trim()?.let { formatTithiInHindi(it) } ?: ""

    val navkarshiTime = solarTimings.navkarshi
    val suryastTime = solarTimings.sunset

    var headerDragX by remember { mutableFloatStateOf(0f) }

    SharedHeaderCardContainer(
        modifier = modifier
            .pointerInput(selectedCalendar.timeInMillis) {
                detectHorizontalDragGestures(
                    onDragStart = { headerDragX = 0f },
                    onDragEnd = {
                        if (headerDragX > 60f) {
                            onPreviousMonth()
                        } else if (headerDragX < -60f) {
                            onNextMonth()
                        }
                        headerDragX = 0f
                    },
                    onDragCancel = { headerDragX = 0f },
                    onHorizontalDrag = { _, dragAmount ->
                        headerDragX += dragAmount
                    }
                )
            },
        testTag = "today_panchang_header_card"
    ) {
        // Top Row: Month & Year (English) + Today's date on left, Samvats & City badge on right
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = displayMonthEnglish,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = AppTextPrimary,
                        fontSize = 14.sp
                    )
                )
                Text(
                    text = activeEnglishDate,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppPrimaryGold,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.5.sp
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "वि.सं. $vikramSamvat • वीर $veerNirwan",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                )
                Spacer(modifier = Modifier.height(2.dp))
                // Clickable City Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFB300).copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFFFB300).copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { showCityDialog = true }
                        .testTag("city_badge_panchang_header")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.5.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "City",
                            tint = Color(0xFFFFB300),
                            modifier = Modifier.size(11.dp)
                        )
                        Text(
                            text = "${selectedCity.hindiName} ▾",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color(0xFFFFE082),
                                fontSize = 10.5.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Centerpiece: Left Arrow, Bigger Center-aligned Glowing Tithi, Right Arrow
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            AppPrimaryGold.copy(alpha = 0.22f),
                            AppPrimaryGold.copy(alpha = 0.06f),
                            Color.Transparent
                        )
                    )
                )
                .border(
                    0.75.dp,
                    Brush.horizontalGradient(
                        listOf(
                            Color.Transparent,
                            AppPrimaryGold.copy(alpha = 0.55f),
                            Color.Transparent
                        )
                    ),
                    RoundedCornerShape(12.dp)
                )
                .padding(vertical = 2.dp, horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(34.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onPreviousMonth,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("panchang_prev_month_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronLeft,
                        contentDescription = "Previous Month",
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Text(
                    text = tithiText,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFFE082),
                        fontSize = 20.sp,
                        letterSpacing = 0.5.sp,
                        shadow = androidx.compose.ui.graphics.Shadow(
                            color = AppPrimaryGold.copy(alpha = 0.85f),
                            blurRadius = 16f
                        )
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .padding(horizontal = 4.dp)
                )

                IconButton(
                    onClick = onNextMonth,
                    modifier = Modifier
                        .size(34.dp)
                        .testTag("panchang_next_month_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = "Next Month",
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // Bottom Timing Badges: Navkarshi & Suryast
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Navkarshi Badge
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF1E261E),
                border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFF81C784).copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = Color(0xFFFFD54F),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "नवकारशी",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppTextMuted,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                    Text(
                        text = navkarshiTime,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFA5D6A7),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }

            // Suryast Badge
            Surface(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFF261D1A),
                border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFFF8A65).copy(alpha = 0.35f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.NightsStay,
                            contentDescription = null,
                            tint = Color(0xFFFF8A65),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "सूर्यास्त",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = AppTextMuted,
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                    Text(
                        text = suryastTime,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFFFAB91),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }
            }
        }
    }
}

data class PanchangBottomNavItem(
    val tab: PanchangTab,
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val testTag: String
)

val panchangNavItems = listOf(
    PanchangBottomNavItem(
        tab = PanchangTab.CALENDAR,
        title = "Calendar",
        selectedIcon = Icons.Filled.CalendarMonth,
        unselectedIcon = Icons.Outlined.CalendarMonth,
        testTag = "panchang_nav_item_calendar"
    ),
    PanchangBottomNavItem(
        tab = PanchangTab.KALYANAK,
        title = "Kalyanak",
        selectedIcon = Icons.Filled.Star,
        unselectedIcon = Icons.Outlined.StarBorder,
        testTag = "panchang_nav_item_kalyanak"
    ),
    PanchangBottomNavItem(
        tab = PanchangTab.EVENTS,
        title = "Events",
        selectedIcon = Icons.Filled.Flag,
        unselectedIcon = Icons.Outlined.OutlinedFlag,
        testTag = "panchang_nav_item_events"
    ),
    PanchangBottomNavItem(
        tab = PanchangTab.NOTIFICATIONS,
        title = "Notifications",
        selectedIcon = Icons.Filled.Notifications,
        unselectedIcon = Icons.Outlined.NotificationsNone,
        testTag = "panchang_nav_item_notifications"
    )
)

@Composable
fun PanchangBottomNavigationBar(
    activeTab: PanchangTab,
    onTabSelected: (PanchangTab) -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedIndex = panchangNavItems.indexOfFirst { it.tab == activeTab }.let {
        if (it >= 0) it else 0
    }

    // Spring physics bouncy animation
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "panchang_sliding_bouncy_pill"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("panchang_bottom_navigation_bar")
    ) {
        // --- 1. iOS Liquid Glass Translucent Frosted Base Layer ---
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            AppBackground.copy(alpha = 0.68f),
                            AppBackground.copy(alpha = 0.80f),
                            AppDeepSurface.copy(alpha = 0.88f)
                        )
                    )
                )
        )

        // --- 2. Frosted Glass Diffusion, Specular Sheen & Light Scattering ---
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.White.copy(alpha = 0.04f),
                            Color.Transparent,
                            Color(0x25000000)
                        )
                    )
                )
        )

        // --- 3. Crisp Foreground Content (Icons, Bouncy Sliding Pill & Typography) ---
        Column(modifier = Modifier.fillMaxWidth()) {
            // iOS Liquid Glass Top Specular Hairline Border (1px crisp edge)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.18f),
                                Color.White.copy(alpha = 0.45f),
                                AppPrimaryGold.copy(alpha = 0.80f),
                                Color.White.copy(alpha = 0.45f),
                                Color.White.copy(alpha = 0.18f)
                            )
                        )
                    )
            )

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(top = 4.dp, bottom = 4.dp, start = 6.dp, end = 6.dp)
            ) {
                val totalTabs = panchangNavItems.size
                val tabWidth = maxWidth / totalTabs
                val pillWidth = 52.dp
                val pillHeight = 26.dp

                // Sliding Gold Active Pill with Bouncy Physics
                Box(
                    modifier = Modifier
                        .offset(
                            x = tabWidth * (animatedIndex + 0.5f) - (pillWidth / 2),
                            y = 2.dp
                        )
                        .size(pillWidth, pillHeight)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.32f),
                                    AppPrimaryGold.copy(alpha = 0.20f)
                                )
                            )
                        )
                        .border(
                            0.75.dp,
                            Brush.linearGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.70f),
                                    AppPrimaryGold.copy(alpha = 0.35f)
                                )
                            ),
                            CircleShape
                        )
                )

                // Interactive Tab Columns (Icons & Text)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    panchangNavItems.forEachIndexed { index, item ->
                        val isSelected = index == selectedIndex

                        val iconTint by animateColorAsState(
                            targetValue = if (isSelected) {
                                AppPrimaryGold
                            } else {
                                AppTextMuted
                            },
                            label = "icon_tint_anim"
                        )

                        val labelColor by animateColorAsState(
                            targetValue = if (isSelected) {
                                AppTextPrimary
                            } else {
                                AppTextMuted
                            },
                            label = "label_color_anim"
                        )

                        val iconScale by animateFloatAsState(
                            targetValue = if (isSelected) 1.08f else 1.0f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessLow
                            ),
                            label = "icon_scale_anim"
                        )

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = {
                                        if (activeTab != item.tab) {
                                            onTabSelected(item.tab)
                                        }
                                    }
                                )
                                .testTag(item.testTag)
                                .padding(vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Icon Container (transparent so the sliding pill displays seamlessly behind)
                            Box(
                                modifier = Modifier
                                    .width(pillWidth)
                                    .height(pillHeight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title,
                                    tint = iconTint,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .scale(iconScale)
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = labelColor
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

