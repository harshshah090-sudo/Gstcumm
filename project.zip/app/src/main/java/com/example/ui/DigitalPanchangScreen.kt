package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.BorderStroke
import com.example.utils.PanchangScannerService
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.PanchangEventEntity
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class CalendarViewMode {
    GRID, LIST
}

enum class PanchangFilter {
    ALL, TITHI, KALYANAK, PARVA
}

enum class PanchangTab {
    CALENDAR, KALYANAK, EVENTS, NOTIFICATIONS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DigitalPanchangScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val allEvents by viewModel.allPanchangEvents.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanningPanchang.collectAsStateWithLifecycle()
    val scanError by viewModel.scanPanchangError.collectAsStateWithLifecycle()
    val extractedDraft by viewModel.extractedPanchangDraft.collectAsStateWithLifecycle()

    var selectedCalendar by remember { mutableStateOf(Calendar.getInstance()) }
    var viewMode by remember { mutableStateOf(CalendarViewMode.GRID) }
    var selectedFilter by remember { mutableStateOf(PanchangFilter.ALL) }
    var activeTab by remember { mutableStateOf(PanchangTab.CALENDAR) }

    val hiddenEventNames by viewModel.hiddenEventNames.collectAsStateWithLifecycle()

    fun isCandidateEvent(event: PanchangEventEntity): Boolean {
        return event.parvasAndEvents.isNotBlank() || event.isImportantTithi || event.kalyanaks.isNotBlank()
    }

    val allDistinctEventNames = remember(allEvents) {
        val candidateEvents = allEvents.filter { isCandidateEvent(it) }
        candidateEvents.flatMap { getEventFilterNames(it) }.distinct().sorted()
    }

    var showEventFilterDialog by remember { mutableStateOf(false) }

    val todayDateString = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    var selectedDayDateString by remember { mutableStateOf<String?>(todayDateString) }
    var showEditDialogForDate by remember { mutableStateOf<String?>(null) }
    var showScanBottomSheet by remember { mutableStateOf(false) }

    val currentYearMonthStr = remember(selectedCalendar.timeInMillis) {
        val sdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        sdf.format(selectedCalendar.time)
    }

    val displayMonthYearTitle = remember(selectedCalendar.timeInMillis) {
        val sdfEng = SimpleDateFormat("MMMM yyyy", Locale.ENGLISH)
        val sdfHindi = SimpleDateFormat("MMMM yyyy", Locale("hi", "IN"))
        "${sdfHindi.format(selectedCalendar.time)} (${sdfEng.format(selectedCalendar.time)})"
    }

    // Filtered events for the month (respecting global hidden events preferences)
    val monthEvents = remember(allEvents, currentYearMonthStr, hiddenEventNames) {
        val rawEvents = allEvents.filter { it.dateString.startsWith(currentYearMonthStr) }
            .associateBy { it.dateString }

        if (hiddenEventNames.isEmpty()) {
            rawEvents
        } else {
            rawEvents.mapValues { (_, event) ->
                if (isEventVisible(event, hiddenEventNames)) {
                    event
                } else {
                    event.copy(
                        parvasAndEvents = "",
                        isImportantTithi = false,
                        kalyanaks = ""
                    )
                }
            }
        }
    }

    val selectedDayEvent = remember(allEvents, selectedDayDateString, hiddenEventNames) {
        if (selectedDayDateString == null) null
        else {
            val raw = allEvents.find { it.dateString == selectedDayDateString }
            if (raw == null || hiddenEventNames.isEmpty()) {
                raw
            } else {
                if (isEventVisible(raw, hiddenEventNames)) raw else raw.copy(parvasAndEvents = "", isImportantTithi = false, kalyanaks = "")
            }
        }
    }

    val kalyanakCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.kalyanaks.isNotBlank() }
    }

    val tithiCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.isImportantTithi || it.tithi.isNotBlank() }
    }

    val parvaCountInMonth = remember(monthEvents) {
        monthEvents.values.count { it.parvasAndEvents.isNotBlank() }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Jain Panchang",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showScanBottomSheet = true },
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("scan_panchang_photo_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = "Upload JSON",
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Top Tabs Bar
            TabRow(
                selectedTabIndex = activeTab.ordinal,
                containerColor = AppSurface,
                contentColor = AppPrimaryGold,
                indicator = { tabPositions ->
                    if (activeTab.ordinal < tabPositions.size) {
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[activeTab.ordinal]),
                            height = 3.dp,
                            color = AppPrimaryGold
                        )
                    }
                }
            ) {
                Tab(
                    selected = activeTab == PanchangTab.CALENDAR,
                    onClick = { activeTab = PanchangTab.CALENDAR },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Calendar", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    },
                    selectedContentColor = AppPrimaryGold,
                    unselectedContentColor = AppTextMuted
                )

                Tab(
                    selected = activeTab == PanchangTab.KALYANAK,
                    onClick = { activeTab = PanchangTab.KALYANAK },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Kalyanak (${allEvents.count { it.kalyanaks.isNotBlank() }})",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    },
                    selectedContentColor = AppPrimaryGold,
                    unselectedContentColor = AppTextMuted
                )

                Tab(
                    selected = activeTab == PanchangTab.EVENTS,
                    onClick = { activeTab = PanchangTab.EVENTS },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Flag, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            val activeEventCount = remember(allEvents, hiddenEventNames) {
                                val candidateEvents = allEvents.filter { isCandidateEvent(it) }
                                if (hiddenEventNames.isEmpty()) {
                                    candidateEvents.size
                                } else {
                                    candidateEvents.count { isEventVisible(it, hiddenEventNames) }
                                }
                            }
                            Text(
                                "Events ($activeEventCount)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    },
                    selectedContentColor = Color(0xFFCE93D8),
                    unselectedContentColor = AppTextMuted
                )

                Tab(
                    selected = activeTab == PanchangTab.NOTIFICATIONS,
                    onClick = { activeTab = PanchangTab.NOTIFICATIONS },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Notifications, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Notifications",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    },
                    selectedContentColor = AppPrimaryGold,
                    unselectedContentColor = AppTextMuted
                )
            }

            when (activeTab) {
                PanchangTab.CALENDAR -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Month Header Controls Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 6.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = AppSurface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                // Row 1: Month Chevrons & Today's Date in English
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            val cal = selectedCalendar.clone() as Calendar
                                            cal.add(Calendar.MONTH, -1)
                                            selectedCalendar = cal
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ChevronLeft,
                                            contentDescription = "Previous Month",
                                            tint = AppPrimaryGold
                                        )
                                    }

                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        val displayMonthEnglish = remember(selectedCalendar.timeInMillis) {
                                            SimpleDateFormat("MMMM yyyy", Locale.ENGLISH).format(selectedCalendar.time)
                                        }
                                        Text(
                                            text = displayMonthEnglish,
                                            style = MaterialTheme.typography.titleMedium.copy(
                                                fontWeight = FontWeight.ExtraBold,
                                                color = AppTextPrimary,
                                                fontSize = 16.sp
                                            ),
                                            textAlign = TextAlign.Center
                                        )

                                        val todayEnglishDate = remember {
                                            SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
                                        }
                                        Text(
                                            text = todayEnglishDate,
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppPrimaryGold,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp
                                            ),
                                            textAlign = TextAlign.Center
                                        )
                                    }

                                    IconButton(
                                        onClick = {
                                            val cal = selectedCalendar.clone() as Calendar
                                            cal.add(Calendar.MONTH, 1)
                                            selectedCalendar = cal
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ChevronRight,
                                            contentDescription = "Next Month",
                                            tint = AppPrimaryGold
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Row 2: Kalyanak Count & Event Count Only
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFF2E220D),
                                        border = BorderStroke(1.dp, Color(0xFFFFB300).copy(alpha = 0.6f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = null,
                                                tint = Color(0xFFFFB300),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Kalyanak Count: $kalyanakCountInMonth",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFFFB300),
                                                    fontSize = 12.sp
                                                )
                                            )
                                        }
                                    }

                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = Color(0xFF2B1D38),
                                        border = BorderStroke(1.dp, Color(0xFFCE93D8).copy(alpha = 0.6f))
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Flag,
                                                contentDescription = null,
                                                tint = Color(0xFFCE93D8),
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "Event Count: $parvaCountInMonth",
                                                style = MaterialTheme.typography.bodySmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFFCE93D8),
                                                    fontSize = 12.sp
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        // Main Calendar View Box
                        Box(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                            if (viewMode == CalendarViewMode.GRID) {
                                PanchangGridCalendar(
                                    selectedCalendar = selectedCalendar,
                                    eventsMap = monthEvents,
                                    filter = selectedFilter,
                                    selectedDateString = selectedDayDateString,
                                    onDayClick = { dateStr, _ ->
                                        selectedDayDateString = dateStr
                                    }
                                )
                            } else {
                                PanchangListCalendar(
                                    selectedCalendar = selectedCalendar,
                                    eventsMap = monthEvents,
                                    filter = selectedFilter,
                                    onDayClick = { dateStr, _ ->
                                        selectedDayDateString = dateStr
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Selected Date Details Card Below Calendar
                        selectedDayDateString?.let { dateStr ->
                            SelectedDateDetailBelowCalendarCard(
                                dateString = dateStr,
                                event = selectedDayEvent
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }

                PanchangTab.KALYANAK -> {
                    KalyanaksTabContent(
                        allEvents = allEvents,
                        onSelectDateInCalendar = { event ->
                            try {
                                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                                val date = sdf.parse(event.dateString)
                                if (date != null) {
                                    val cal = Calendar.getInstance()
                                    cal.time = date
                                    selectedCalendar = cal
                                }
                            } catch (_: Exception) {}
                            selectedDayDateString = event.dateString
                            activeTab = PanchangTab.CALENDAR
                        }
                    )
                }

                PanchangTab.EVENTS -> {
                    EventsTabContent(
                        allEvents = allEvents,
                        hiddenEventNames = hiddenEventNames,
                        allDistinctEventNames = allDistinctEventNames,
                        onOpenFilterDialog = { showEventFilterDialog = true },
                        onResetFilter = { viewModel.updateHiddenEventNames(emptySet()) },
                        onSelectDateInCalendar = { event ->
                            try {
                                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                                val date = sdf.parse(event.dateString)
                                if (date != null) {
                                    val cal = Calendar.getInstance()
                                    cal.time = date
                                    selectedCalendar = cal
                                }
                            } catch (_: Exception) {}
                            selectedDayDateString = event.dateString
                            activeTab = PanchangTab.CALENDAR
                        }
                    )
                }

                PanchangTab.NOTIFICATIONS -> {
                    PanchangNotificationSettingsTab(
                        allEvents = allEvents
                    )
                }
            }
        }
    }

    // Event Filter Dialog
    if (showEventFilterDialog) {
        EventFilterDialog(
            allDistinctEventNames = allDistinctEventNames,
            hiddenEventNames = hiddenEventNames,
            allEvents = allEvents,
            onDismiss = { showEventFilterDialog = false },
            onApply = { newlySelected ->
                val newHiddenSet = allDistinctEventNames.toSet() - newlySelected
                viewModel.updateHiddenEventNames(newHiddenSet)
            }
        )
    }

    // Day Edit Dialog when triggered from "Edit" button below calendar
    showEditDialogForDate?.let { dateStr ->
        DayDetailDialog(
            dateString = dateStr,
            event = selectedDayEvent,
            onDismiss = {
                showEditDialogForDate = null
            },
            onSaveNotes = { updatedEvent ->
                viewModel.addOrUpdatePanchangEvent(updatedEvent)
                showEditDialogForDate = null
                Toast.makeText(context, "Panchang details updated", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // Upload JSON Panchang Dialog / Bottom Sheet
    if (showScanBottomSheet || extractedDraft.isNotEmpty()) {
        PanchangExtractionSheet(
            extractedEvents = extractedDraft,
            onDismiss = {
                showScanBottomSheet = false
                viewModel.clearPanchangDraft()
            },
            onConfirmImport = { selectedEvents ->
                viewModel.saveExtractedDraftPanchangEvents(selectedEvents)
                showScanBottomSheet = false
                Toast.makeText(context, "Successfully imported ${selectedEvents.size} Panchang events!", Toast.LENGTH_LONG).show()
            },
            onPasteJson = { jsonText ->
                viewModel.processPastedPanchangJson(jsonText)
            }
        )
    }
}

@Composable
fun PanchangGridCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    selectedDateString: String? = null,
    onDayClick: (String, PanchangEventEntity?) -> Unit
) {
    val daysOfWeek = listOf("रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि")

    val calendarMatrix = remember(selectedCalendar.timeInMillis) {
        val cal = selectedCalendar.clone() as Calendar
        cal.set(Calendar.DAY_OF_MONTH, 1)
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK) - 1 // 0-based for Sun
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)

        val yearMonthSdf = SimpleDateFormat("yyyy-MM", Locale.getDefault())
        val yearMonth = yearMonthSdf.format(cal.time)

        val list = mutableListOf<CalendarGridCellData?>()
        // Add padding empty cells for preceding days
        for (i in 0 until firstDayOfWeek) {
            list.add(null)
        }
        // Add days of month
        for (day in 1..daysInMonth) {
            val dayFormatted = String.format("%02d", day)
            val fullDateStr = "$yearMonth-$dayFormatted"
            list.add(CalendarGridCellData(dayNumber = day, dateString = fullDateStr))
        }
        list
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp)
    ) {
        // Legend Bar for Event Color Schemes
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 4.dp, horizontal = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CalendarLegendChip(label = "Kalyanak", color = Color(0xFFFFB300), bg = Color(0xFF2E220D))
            CalendarLegendChip(label = "Parva", color = Color(0xFFAB47BC), bg = Color(0xFF2B1D38))
            CalendarLegendChip(label = "Aatham (8)", color = Color(0xFF81C784), bg = Color(0xFF1B3322))
            CalendarLegendChip(label = "Chaudas (14)", color = Color(0xFFE57373), bg = Color(0xFF381C21))
            CalendarLegendChip(label = "Agiyaras (11)", color = Color(0xFF4DB6AC), bg = Color(0xFF1B3335))
            CalendarLegendChip(label = "Poonam/Amavasya", color = Color(0xFF7986CB), bg = Color(0xFF1C2138))
            CalendarLegendChip(label = "Important Tithi", color = Color(0xFFFF8A65), bg = Color(0xFF38241C))
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Week Days Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            daysOfWeek.forEach { dayName ->
                Text(
                    text = dayName,
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (dayName == "रवि") AppPrimaryGold else AppTextMuted
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Grid Cells
        LazyVerticalGrid(
            columns = GridCells.Fixed(7),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(calendarMatrix) { cell ->
                if (cell == null) {
                    Spacer(modifier = Modifier.aspectRatio(0.85f))
                } else {
                    val event = eventsMap[cell.dateString]
                    val isPassFilter = remember(event, filter) {
                        when (filter) {
                            PanchangFilter.ALL -> true
                            PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                            PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                            PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
                        }
                    }

                    val isSelectedCell = cell.dateString == selectedDateString

                    PanchangGridCell(
                        dayNumber = cell.dayNumber,
                        event = event,
                        isHighlightFilter = isPassFilter,
                        isSelected = isSelectedCell,
                        onClick = { onDayClick(cell.dateString, event) }
                    )
                }
            }
        }
    }
}

@Composable
fun CalendarLegendChip(label: String, color: Color, bg: Color) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = bg,
        border = BorderStroke(1.dp, color.copy(alpha = 0.6f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = color
            )
        }
    }
}

data class CalendarGridCellData(
    val dayNumber: Int,
    val dateString: String
)

data class EventColorScheme(
    val borderColor: Color,
    val containerColor: Color,
    val badgeBgColor: Color,
    val badgeTextColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector?,
    val iconTint: Color
)

fun getEventColorScheme(
    event: PanchangEventEntity?,
    isToday: Boolean,
    isSelected: Boolean
): EventColorScheme {
    if (isSelected) {
        return EventColorScheme(
            borderColor = AppPrimaryGold,
            containerColor = Color(0xFF4A121A),
            badgeBgColor = AppPrimaryGold,
            badgeTextColor = Color.Black,
            icon = null,
            iconTint = AppPrimaryGold
        )
    }

    if (event == null) {
        return EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
    }

    val tithiLower = event.tithi.lowercase()

    return when {
        // 1. Tirthankar Kalyanaks -> Saffron Gold
        event.kalyanaks.isNotBlank() -> EventColorScheme(
            borderColor = Color(0xFFFFB300),
            containerColor = Color(0xFF2E220D),
            badgeBgColor = Color(0xFFFFB300),
            badgeTextColor = Color(0xFF2E220D),
            icon = Icons.Default.Star,
            iconTint = Color(0xFFFFD54F)
        )
        // 2. Parvas / Major Festivals -> Royal Purple
        event.parvasAndEvents.isNotBlank() -> EventColorScheme(
            borderColor = Color(0xFFCE93D8),
            containerColor = Color(0xFF2B1D38),
            badgeBgColor = Color(0xFFAB47BC),
            badgeTextColor = Color.White,
            icon = Icons.Default.Flag,
            iconTint = Color(0xFFCE93D8)
        )
        // 3. Aatham (8th Tithi) -> Emerald Green
        tithiLower.contains("8") || tithiLower.contains("८") || tithiLower.contains("आठम") || tithiLower.contains("अष्टमी") || tithiLower.contains("aatham") || tithiLower.contains("ashtami") -> EventColorScheme(
            borderColor = Color(0xFF81C784),
            containerColor = Color(0xFF1B3322),
            badgeBgColor = Color(0xFF2E7D32),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFF81C784)
        )
        // 4. Chaudas (14th Tithi) -> Crimson Red
        tithiLower.contains("14") || tithiLower.contains("१४") || tithiLower.contains("चौदस") || tithiLower.contains("चतुर्दशी") || tithiLower.contains("chaudas") || tithiLower.contains("chaturdashi") -> EventColorScheme(
            borderColor = Color(0xFFE57373),
            containerColor = Color(0xFF381C21),
            badgeBgColor = Color(0xFFC62828),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFFE57373)
        )
        // 5. Agiyaras / Ekadashi (11th Tithi) -> Teal / Cyan
        tithiLower.contains("11") || tithiLower.contains("११") || tithiLower.contains("अग्यारस") || tithiLower.contains("एकादशी") || tithiLower.contains("agiyaras") || tithiLower.contains("ekadashi") -> EventColorScheme(
            borderColor = Color(0xFF4DB6AC),
            containerColor = Color(0xFF1B3335),
            badgeBgColor = Color(0xFF00695C),
            badgeTextColor = Color.White,
            icon = Icons.Default.Circle,
            iconTint = Color(0xFF4DB6AC)
        )
        // 6. Poonam / Amavasya -> Night Indigo / Blue
        tithiLower.contains("पूणम") || tithiLower.contains("पूर्णिमा") || tithiLower.contains("अमावस्या") || tithiLower.contains("अमास") || tithiLower.contains("poonam") || tithiLower.contains("amavasya") -> EventColorScheme(
            borderColor = Color(0xFF7986CB),
            containerColor = Color(0xFF1C2138),
            badgeBgColor = Color(0xFF283593),
            badgeTextColor = Color.White,
            icon = Icons.Default.Brightness7,
            iconTint = Color(0xFF7986CB)
        )
        // 7. Important Tithis -> Coral Saffron
        event.isImportantTithi -> EventColorScheme(
            borderColor = Color(0xFFFF8A65),
            containerColor = Color(0xFF38241C),
            badgeBgColor = Color(0xFFD84315),
            badgeTextColor = Color.White,
            icon = Icons.Default.Bookmark,
            iconTint = Color(0xFFFF8A65)
        )
        // 8. Regular Day with Tithi info
        event.tithi.isNotBlank() -> EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
        else -> EventColorScheme(
            borderColor = if (isToday) AppPrimaryGold else AppBorder,
            containerColor = if (isToday) AppSurfaceNested else AppSurface,
            badgeBgColor = AppDeepSurface,
            badgeTextColor = AppTextPrimary,
            icon = null,
            iconTint = AppTextMuted
        )
    }
}

@Composable
fun PanchangGridCell(
    dayNumber: Int,
    event: PanchangEventEntity?,
    isHighlightFilter: Boolean,
    isSelected: Boolean = false,
    onClick: () -> Unit
) {
    val todayDateStr = remember {
        SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    }
    val isToday = event?.dateString == todayDateStr

    val scheme = remember(event, isToday, isSelected) {
        getEventColorScheme(event, isToday, isSelected)
    }

    Card(
        modifier = Modifier
            .aspectRatio(0.82f)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .border(
                width = if (isSelected) 2.5.dp else if (isToday) 1.8.dp else 1.2.dp,
                color = scheme.borderColor,
                shape = RoundedCornerShape(12.dp)
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = scheme.containerColor
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Day Number + Indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$dayNumber",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = if (isToday || scheme.icon != null) FontWeight.Bold else FontWeight.SemiBold,
                        color = if (isToday) AppPrimaryGold else AppTextPrimary,
                        fontSize = 14.sp
                    )
                )

                if (scheme.icon != null) {
                    Icon(
                        imageVector = scheme.icon,
                        contentDescription = null,
                        tint = scheme.iconTint,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }

            // Tithi / Event Tag Badge
            if (event != null && event.tithi.isNotBlank()) {
                val shortTithi = remember(event.tithi) {
                    event.tithi
                        .replace("Vaisakha", "")
                        .replace("Bhadrapad", "")
                        .replace("Chaitra", "")
                        .replace("Karthik", "")
                        .trim()
                }
                Surface(
                    shape = RoundedCornerShape(4.dp),
                    color = scheme.badgeBgColor,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = shortTithi,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = scheme.badgeTextColor
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 1.5.dp)
                    )
                }
            } else {
                Spacer(modifier = Modifier.height(1.dp))
            }
        }
    }
}

@Composable
fun PanchangListCalendar(
    selectedCalendar: Calendar,
    eventsMap: Map<String, PanchangEventEntity>,
    filter: PanchangFilter,
    onDayClick: (String, PanchangEventEntity?) -> Unit
) {
    val yearMonthSdf = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()) }
    val currentYearMonth = yearMonthSdf.format(selectedCalendar.time)
    val daysInMonth = selectedCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)

    val dateList = remember(selectedCalendar.timeInMillis) {
        (1..daysInMonth).map { day ->
            val formattedDay = String.format("%02d", day)
            "$currentYearMonth-$formattedDay"
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        items(dateList) { dateStr ->
            val event = eventsMap[dateStr]
            val isPassFilter = when (filter) {
                PanchangFilter.ALL -> true
                PanchangFilter.TITHI -> event != null && (event.isImportantTithi || event.tithi.isNotBlank())
                PanchangFilter.KALYANAK -> event != null && event.kalyanaks.isNotBlank()
                PanchangFilter.PARVA -> event != null && event.parvasAndEvents.isNotBlank()
            }

            if (isPassFilter) {
                PanchangListRowCard(
                    dateString = dateStr,
                    event = event,
                    onClick = { onDayClick(dateStr, event) }
                )
            }
        }
    }
}

@Composable
fun PanchangListRowCard(
    dateString: String,
    event: PanchangEventEntity?,
    onClick: () -> Unit
) {
    val formattedDateText = remember(dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMM, EEEE", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            dateString
        }
    }

    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val isToday = dateString == todayDateStr
    val scheme = remember(event, isToday) { getEventColorScheme(event, isToday = isToday, isSelected = false) }

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .border(
                1.2.dp,
                scheme.borderColor,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = scheme.containerColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Date Badge
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = scheme.badgeBgColor,
                modifier = Modifier.width(90.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = scheme.badgeTextColor,
                            fontSize = 11.sp
                        ),
                        textAlign = TextAlign.Center
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Details
            Column(modifier = Modifier.weight(1f)) {
                if (event != null && event.tithi.isNotBlank()) {
                    Text(
                        text = "तिथि: ${event.tithi}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (event.isImportantTithi || hasKalyanak) scheme.borderColor else AppTextPrimary
                        )
                    )
                } else {
                    Text(
                        text = "कोई विशेष तिथि दर्ज नहीं",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )
                }

                if (hasKalyanak) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "✨ ${event?.kalyanaks}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFFFD54F),
                            fontWeight = FontWeight.Medium
                        )
                    )
                }

                if (hasParva) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "🚩 ${event?.parvasAndEvents}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = Color(0xFFCE93D8)
                        )
                    )
                }
            }

            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = null,
                tint = AppTextMuted,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

@Composable
fun DayDetailDialog(
    dateString: String,
    event: PanchangEventEntity?,
    onDismiss: () -> Unit,
    onSaveNotes: (PanchangEventEntity) -> Unit
) {
    var tithiInput by remember { mutableStateOf(event?.tithi ?: "") }
    var kalyanakInput by remember { mutableStateOf(event?.kalyanaks ?: "") }
    var parvaInput by remember { mutableStateOf(event?.parvasAndEvents ?: "") }
    var notesInput by remember { mutableStateOf(event?.notes ?: "") }
    var isImportant by remember { mutableStateOf(event?.isImportantTithi ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "तिथि विवरण ($dateString)",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppPrimaryGold
                )
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = tithiInput,
                    onValueChange = { tithiInput = it },
                    label = { Text("जैन तिथि (Tithi)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isImportant,
                        onCheckedChange = { isImportant = it },
                        colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                    )
                    Text("विशेष तिथि (Agiyaras, Chaudas, Poonam, Amas, etc.)", style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = kalyanakInput,
                    onValueChange = { kalyanakInput = it },
                    label = { Text("तीर्थंकर कल्याणक (Kalyanak)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = parvaInput,
                    onValueChange = { parvaInput = it },
                    label = { Text("पर्व / त्यौहार (Parva / Event)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = notesInput,
                    onValueChange = { notesInput = it },
                    label = { Text("अन्य विवरण एवं नोट्स (Notes)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = event?.copy(
                        tithi = tithiInput,
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput,
                        parvasAndEvents = parvaInput,
                        notes = notesInput
                    ) ?: PanchangEventEntity(
                        dateString = dateString,
                        tithi = tithiInput,
                        isImportantTithi = isImportant,
                        kalyanaks = kalyanakInput,
                        parvasAndEvents = parvaInput,
                        notes = notesInput
                    )
                    onSaveNotes(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold)
            ) {
                Text("सुरक्षित करें (Save)", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें (Cancel)", color = AppTextMuted)
            }
        },
        containerColor = AppSurface,
        shape = RoundedCornerShape(18.dp)
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PanchangExtractionSheet(
    extractedEvents: List<PanchangEventEntity>,
    onDismiss: () -> Unit,
    onConfirmImport: (List<PanchangEventEntity>) -> Unit,
    onPasteJson: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedItemIds by remember(extractedEvents) {
        mutableStateOf(extractedEvents.mapIndexed { index, _ -> index }.toSet())
    }
    var pastedJsonInput by remember { mutableStateOf("") }

    val jsonFileLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { fileUri: Uri? ->
        fileUri?.let { uri ->
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val jsonContent = inputStream?.bufferedReader()?.use { it.readText() } ?: ""
                if (jsonContent.isNotBlank()) {
                    onPasteJson(jsonContent)
                } else {
                    Toast.makeText(context, "Selected JSON file is empty", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to read JSON file: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = AppSurface,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (extractedEvents.isNotEmpty()) {
                Text(
                    text = "Extracted ${extractedEvents.size} Panchang Entries",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
                Spacer(modifier = Modifier.height(10.dp))

                LazyColumn(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .heightIn(max = 300.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(extractedEvents.size) { index ->
                        val item = extractedEvents[index]
                        val isChecked = selectedItemIds.contains(index)

                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { checked ->
                                        selectedItemIds = if (checked) {
                                            selectedItemIds + index
                                        } else {
                                            selectedItemIds - index
                                        }
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = AppPrimaryGold)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${item.dateString} • ${item.tithi}",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = AppTextPrimary
                                        )
                                    )
                                    if (item.kalyanaks.isNotBlank()) {
                                        Text(
                                            text = "⭐ ${item.kalyanaks}",
                                            style = MaterialTheme.typography.bodySmall.copy(
                                                color = AppPrimaryGold,
                                                fontSize = 11.sp
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val selectedList = extractedEvents.filterIndexed { index, _ -> selectedItemIds.contains(index) }
                        onConfirmImport(selectedList)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Import ${selectedItemIds.size} Events into Digital Calendar",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "📁 Upload Panchang JSON File",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Select or paste a Panchang JSON file to import events into your calendar:",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted),
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // UPLOAD JSON FILE CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, AppPrimaryGold),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FileUpload,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Upload JSON File (.json)",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Select a Panchang JSON file from your device storage:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { jsonFileLauncher.launch("*/*") },
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("upload_json_file_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FolderOpen,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("📁 Select & Upload JSON File", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // PASTE JSON TEXT CARD
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.ContentPaste,
                                    contentDescription = null,
                                    tint = AppPrimaryGold,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Or Paste JSON Text",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        color = AppPrimaryGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Paste Panchang JSON array text directly below:",
                                style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = pastedJsonInput,
                                onValueChange = { pastedJsonInput = it },
                                label = { Text("Paste JSON Array") },
                                placeholder = { Text("[{\"dateString\": \"2026-08-15\", \"tithi\": \"Sud Teej\"}, ...]") },
                                maxLines = 5,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_pasted_json_input"),
                                shape = RoundedCornerShape(10.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = {
                                    if (pastedJsonInput.isNotBlank()) {
                                        onPasteJson(pastedJsonInput)
                                    }
                                },
                                enabled = pastedJsonInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("initial_import_pasted_json_button")
                            ) {
                                Text("Import Pasted JSON Text", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MonthStatPill(
    label: String,
    count: String,
    color: Color
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = count,
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    color = AppTextMuted,
                    fontSize = 11.sp
                )
            )
        }
    }
}

@Composable
fun FilterChipCompact(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (isSelected) AppTertiaryMaroon else AppDeepSurface,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) AppPrimaryGold else AppBorder
        ),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) AppPrimaryGold else AppTextMuted,
                fontSize = 10.5.sp
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun SelectedDateDetailBelowCalendarCard(
    dateString: String,
    event: PanchangEventEntity?
) {
    val formattedDateText = remember(dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
            val engSdf = SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH)
            "${outSdf.format(date)} / ${engSdf.format(date)}"
        } catch (e: Exception) {
            dateString
        }
    }

    val hasKalyanak = event?.kalyanaks?.isNotBlank() == true
    val hasParva = event?.parvasAndEvents?.isNotBlank() == true
    val isImportantTithi = event?.isImportantTithi == true

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (hasKalyanak) AppPrimaryGold else AppTertiaryMaroon.copy(alpha = 0.5f)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Selected Date Title
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Start,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.CalendarToday,
                    contentDescription = null,
                    tint = AppPrimaryGold,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Date Details",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppPrimaryGold
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Formatted Date
            Text(
                text = formattedDateText,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.ExtraBold,
                    color = AppTextPrimary
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Tithi Info Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isImportantTithi) AppTertiaryMaroon else AppDeepSurface
                ) {
                    Text(
                        text = if (event != null && event.tithi.isNotBlank()) "तिथि: ${event.tithi}" else "तिथि: सामान्य दिन",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = if (isImportantTithi) AppPrimaryGold else AppTextPrimary
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }

                if (isImportantTithi) {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = AppSecondaryGreen.copy(alpha = 0.2f)
                    ) {
                        Text(
                            text = "⭐ विशेष तिथि (Agiyaras/Chaudas/Poonam)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = AppSecondaryGreen,
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Kalyanaks Box
            if (hasKalyanak) {
                Spacer(modifier = Modifier.height(10.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "तीर्थंकर कल्याणक",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppPrimaryGold,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = event?.kalyanaks ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }

            // Parvas & Events Box
            if (hasParva) {
                Spacer(modifier = Modifier.height(8.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = AppDeepSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBA68C8).copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Default.Flag,
                            contentDescription = null,
                            tint = Color(0xFFBA68C8),
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "पर्व / त्यौहार / विशेष नियम",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFCE93D8),
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Text(
                                text = event?.parvasAndEvents ?: "",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = AppTextPrimary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Timings Grid (Navkarsi / Sunset)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = AppPrimaryGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("नवकारसी समय", style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted, fontSize = 9.sp))
                            Text(
                                text = event?.navkarsiTime?.ifBlank { "06:48 AM" } ?: "06:48 AM",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
                            )
                        }
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.weight(1f)
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.NightsStay,
                            contentDescription = null,
                            tint = Color(0xFFFF8A65),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text("सूर्यास्त (चौविहार)", style = MaterialTheme.typography.labelSmall.copy(color = AppTextMuted, fontSize = 9.sp))
                            Text(
                                text = event?.sunsetTime?.ifBlank { "07:02 PM" } ?: "07:02 PM",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AppTextPrimary)
                            )
                        }
                    }
                }
            }

            // Notes Section
            if (event?.notes?.isNotBlank() == true) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = AppDeepSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        Text("📝 विशेष निर्देश / नोट्स:", style = MaterialTheme.typography.labelSmall.copy(color = AppPrimaryGold, fontWeight = FontWeight.Bold))
                        Text(event.notes, style = MaterialTheme.typography.bodySmall.copy(color = AppTextPrimary))
                    }
                }
            }
        }
    }
}

@Composable
fun KalyanaksTabContent(
    allEvents: List<PanchangEventEntity>,
    onSelectDateInCalendar: (PanchangEventEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val kalyanakEvents = remember(allEvents) {
        allEvents.filter { it.kalyanaks.isNotBlank() }
            .sortedBy { it.dateString }
    }

    val filteredList = remember(kalyanakEvents, searchQuery) {
        if (searchQuery.isBlank()) kalyanakEvents
        else kalyanakEvents.filter {
            it.kalyanaks.contains(searchQuery, ignoreCase = true) ||
            it.tithi.contains(searchQuery, ignoreCase = true) ||
            it.dateString.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("तीर्थंकर या कल्याणक खोजें (जैसे: महावीर, पार्श्वनाथ)") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = AppPrimaryGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = AppTextMuted)
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("kalyanak_search_input"),
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = AppSurface,
                unfocusedContainerColor = AppSurface
            )
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "कुल कल्याणक: ${filteredList.size} तिथियां",
            style = MaterialTheme.typography.labelSmall.copy(color = AppPrimaryGold, fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("कोई कल्याणक प्राप्त नहीं हुआ", style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted))
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredList) { event ->
                    KalyanakCardItem(
                        event = event,
                        onViewInCalendar = { onSelectDateInCalendar(event) }
                    )
                }
            }
        }
    }
}

@Composable
fun KalyanakCardItem(
    event: PanchangEventEntity,
    onViewInCalendar: () -> Unit
) {
    val formattedDateText = remember(event.dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(event.dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            event.dateString
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, AppPrimaryGold.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = null,
                        tint = AppPrimaryGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppPrimaryGold
                        )
                    )
                }

                Button(
                    onClick = onViewInCalendar,
                    colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("📅 कैलेंडर में देखें", fontSize = 11.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "✨ ${event.kalyanaks}",
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Bold,
                    color = AppTextPrimary
                )
            )

            if (event.tithi.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "तिथि: ${event.tithi}",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppSecondaryGreen, fontWeight = FontWeight.Medium)
                )
            }

            if (event.parvasAndEvents.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "🚩 ${event.parvasAndEvents}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFCE93D8))
                )
            }
        }
    }
}

fun cleanTithiName(rawTithi: String): String {
    if (rawTithi.isBlank()) return ""
    val monthsRegex = Regex(
        "(?i)\\b(श्रावण|भाद्रपद|भादरवो|आसोज|आसो|कार्तिक|मार्गशीर्ष|पौष|माघ|फाल्गुण|फागुन|चैत्र|वैशाख|ज्येष्ठ|अषाढ़|आषाढ़|Shravan|Bhadrapad|Aasoj|Kartik|Margsirsha|Paush|Magh|Falgun|Chaitra|Vaishakh|Jeshtha|Ashadh)\\b"
    )
    val pakshaRegex = Regex(
        "(?i)\\b(वदि|सुदि|वद|सुद|कृष्ण|शुक्ल|Vad|Sud|vadi|sudi)\\b"
    )
    val numberInBracketsRegex = Regex("\\([0-9०-९\\s]+\\)")

    val cleaned = rawTithi
        .replace(monthsRegex, "")
        .replace(pakshaRegex, "")
        .replace(numberInBracketsRegex, "")
        .replace(Regex("^[\\s,.-]+|[\\s,.-]+$"), "")
        .replace(Regex("\\s+"), " ")
        .trim()

    return cleaned.ifBlank { rawTithi.trim() }
}

fun getParvaAndKalyanakFilterNames(event: PanchangEventEntity): List<String> {
    val list = mutableListOf<String>()
    if (event.parvasAndEvents.isNotBlank()) {
        event.parvasAndEvents.split(",", "/", "\n", "|", "॥").map { it.trim() }.filter { it.isNotBlank() }.forEach {
            list.add(it)
        }
    }
    if (event.kalyanaks.isNotBlank()) {
        event.kalyanaks.split(",", "/", "\n", "|", "॥").map { it.trim() }.filter { it.isNotBlank() }.forEach {
            list.add(it)
        }
    }
    return list.distinct()
}

fun isEventVisible(event: PanchangEventEntity, hiddenEventNames: Set<String>): Boolean {
    if (hiddenEventNames.isEmpty()) return true

    val parvaAndKalyanakNames = getParvaAndKalyanakFilterNames(event)
    val tithiName = cleanTithiName(event.tithi)

    // If there are specific parva or kalyanak events occurring on this day
    if (parvaAndKalyanakNames.isNotEmpty()) {
        // Shown if ANY of the event/parva/kalyanak names on this day are NOT hidden
        return parvaAndKalyanakNames.any { it !in hiddenEventNames }
    }

    // If no parva/kalyanak, check if tithi name itself is removed
    return tithiName.isBlank() || tithiName !in hiddenEventNames
}

fun getEventFilterNames(event: PanchangEventEntity): List<String> {
    val list = mutableListOf<String>()
    if (event.parvasAndEvents.isNotBlank()) {
        event.parvasAndEvents.split(",", "/", "\n", "|", "॥").map { it.trim() }.filter { it.isNotBlank() }.forEach {
            list.add(it)
        }
    }
    if (event.tithi.isNotBlank()) {
        val cleaned = cleanTithiName(event.tithi)
        if (cleaned.isNotBlank()) {
            list.add(cleaned)
        }
    }
    if (event.kalyanaks.isNotBlank()) {
        event.kalyanaks.split(",", "/", "\n", "|", "॥").map { it.trim() }.filter { it.isNotBlank() }.forEach {
            list.add(it)
        }
    }
    return list.distinct()
}

@Composable
fun EventFilterDialog(
    allDistinctEventNames: List<String>,
    hiddenEventNames: Set<String>,
    allEvents: List<PanchangEventEntity>,
    onDismiss: () -> Unit,
    onApply: (Set<String>) -> Unit
) {
    var tempSelected by remember(hiddenEventNames, allDistinctEventNames) {
        mutableStateOf(allDistinctEventNames.filter { it !in hiddenEventNames }.toSet())
    }
    var filterQuery by remember { mutableStateOf("") }

    val eventNameCounts = remember(allEvents, allDistinctEventNames) {
        allDistinctEventNames.associateWith { name ->
            allEvents.count { ev ->
                getEventFilterNames(ev).contains(name)
            }
        }
    }

    val displayList = remember(allDistinctEventNames, filterQuery) {
        if (filterQuery.isBlank()) allDistinctEventNames
        else allDistinctEventNames.filter { it.contains(filterQuery, ignoreCase = true) }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FilterList,
                        contentDescription = null,
                        tint = Color(0xFFCE93D8)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Manage Event Preferences",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = AppTextPrimary
                        )
                    )
                }
                Text(
                    text = "${tempSelected.size}/${allDistinctEventNames.size}",
                    style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFCE93D8), fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Checked events are visible. Unchecking an event permanently removes it from the Calendar and Events tab across all devices.",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                )
                Spacer(modifier = Modifier.height(10.dp))

                if (allDistinctEventNames.size > 5) {
                    OutlinedTextField(
                        value = filterQuery,
                        onValueChange = { filterQuery = it },
                        placeholder = { Text("Search event name...") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(
                        onClick = { tempSelected = allDistinctEventNames.toSet() },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Select All", fontSize = 12.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                    }
                    TextButton(
                        onClick = { tempSelected = emptySet() },
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text("Clear All", fontSize = 12.sp, color = AppTextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                if (displayList.isEmpty()) {
                    Text(
                        text = "No event names found",
                        style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted),
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp)
                    ) {
                        items(displayList) { eventName ->
                            val isChecked = eventName in tempSelected
                            val count = eventNameCounts[eventName] ?: 0
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        tempSelected = if (isChecked) {
                                            tempSelected - eventName
                                        } else {
                                            tempSelected + eventName
                                        }
                                    }
                                    .padding(vertical = 4.dp, horizontal = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Checkbox(
                                        checked = isChecked,
                                        onCheckedChange = { checked ->
                                            tempSelected = if (checked == true) {
                                                tempSelected + eventName
                                            } else {
                                                tempSelected - eventName
                                            }
                                        },
                                        colors = CheckboxDefaults.colors(
                                            checkedColor = Color(0xFFBA68C8)
                                        )
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = eventName,
                                        style = MaterialTheme.typography.bodyMedium.copy(
                                            color = AppTextPrimary,
                                            fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal
                                        )
                                    )
                                }
                                Text(
                                    text = "($count dates)",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = AppTextMuted,
                                        fontSize = 11.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onApply(tempSelected)
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFBA68C8))
            ) {
                Text("Save & Sync to Server", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = AppTextMuted)
            }
        },
        containerColor = AppSurface,
        shape = RoundedCornerShape(18.dp)
    )
}

@Composable
fun EventsTabContent(
    allEvents: List<PanchangEventEntity>,
    hiddenEventNames: Set<String>,
    allDistinctEventNames: List<String>,
    onOpenFilterDialog: () -> Unit,
    onResetFilter: () -> Unit,
    onSelectDateInCalendar: (PanchangEventEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }

    val activeSelectedCount = remember(hiddenEventNames, allDistinctEventNames) {
        allDistinctEventNames.count { it !in hiddenEventNames }
    }

    val isFilterActive = remember(hiddenEventNames) {
        hiddenEventNames.isNotEmpty()
    }

    val parvaEvents = remember(allEvents, hiddenEventNames) {
        val candidateEvents = allEvents.filter {
            it.parvasAndEvents.isNotBlank() || it.isImportantTithi || it.kalyanaks.isNotBlank()
        }
        if (hiddenEventNames.isEmpty()) {
            candidateEvents.sortedBy { it.dateString }
        } else {
            candidateEvents.filter { isEventVisible(it, hiddenEventNames) }.sortedBy { it.dateString }
        }
    }

    val filteredList = remember(parvaEvents, searchQuery) {
        if (searchQuery.isBlank()) parvaEvents
        else parvaEvents.filter {
            it.parvasAndEvents.contains(searchQuery, ignoreCase = true) ||
            it.tithi.contains(searchQuery, ignoreCase = true) ||
            it.dateString.contains(searchQuery, ignoreCase = true) ||
            it.kalyanaks.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search events...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color(0xFFBA68C8)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = AppTextMuted)
                        }
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("events_search_input"),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = AppSurface,
                    unfocusedContainerColor = AppSurface
                )
            )

            Button(
                onClick = onOpenFilterDialog,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isFilterActive) Color(0xFFBA68C8) else AppTertiaryMaroon
                ),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 12.dp),
                modifier = Modifier.testTag("open_event_filter_button")
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = "Manage Events",
                    tint = if (isFilterActive) Color.White else AppPrimaryGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isFilterActive) "Manage ($activeSelectedCount/${allDistinctEventNames.size})" else "Manage Events",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = if (isFilterActive) Color.White else AppPrimaryGold
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (isFilterActive) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = Color(0xFFBA68C8).copy(alpha = 0.15f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBA68C8).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Hidden Events: ${hiddenEventNames.size} of ${allDistinctEventNames.size} events hidden",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFCE93D8), fontSize = 11.5.sp)
                    )
                    TextButton(
                        onClick = onResetFilter,
                        contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                    ) {
                        Text("Unhide All", color = AppPrimaryGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
        }

        Text(
            text = "Total Events: ${filteredList.size}",
            style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFFCE93D8), fontWeight = FontWeight.Bold)
        )

        Spacer(modifier = Modifier.height(6.dp))

        if (filteredList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No events match current filter or search query.", style = MaterialTheme.typography.bodyMedium.copy(color = AppTextMuted))
                    if (isFilterActive) {
                        Spacer(modifier = Modifier.height(8.dp))
                        TextButton(onClick = onResetFilter) {
                            Text("Reset Event Filter", color = AppPrimaryGold)
                        }
                    }
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(filteredList) { event ->
                    EventCardItem(
                        event = event,
                        onViewInCalendar = { onSelectDateInCalendar(event) }
                    )
                }
            }
        }
    }
}

@Composable
fun EventCardItem(
    event: PanchangEventEntity,
    onViewInCalendar: () -> Unit
) {
    val formattedDateText = remember(event.dateString) {
        try {
            val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = inSdf.parse(event.dateString) ?: Date()
            val outSdf = SimpleDateFormat("dd MMMM yyyy (EEEE)", Locale("hi", "IN"))
            outSdf.format(date)
        } catch (e: Exception) {
            event.dateString
        }
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AppSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFBA68C8).copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Flag,
                        contentDescription = null,
                        tint = Color(0xFFBA68C8),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = formattedDateText,
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFCE93D8)
                        )
                    )
                }

                Button(
                    onClick = onViewInCalendar,
                    colors = ButtonDefaults.buttonColors(containerColor = AppTertiaryMaroon),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Text("📅 कैलेंडर में देखें", fontSize = 11.sp, color = AppPrimaryGold, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            if (event.parvasAndEvents.isNotBlank()) {
                Text(
                    text = "🚩 ${event.parvasAndEvents}",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppTextPrimary
                    )
                )
            } else {
                Text(
                    text = "⭐ विशेष तिथि: ${event.tithi}",
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = AppSecondaryGreen
                    )
                )
            }

            if (event.tithi.isNotBlank() && event.parvasAndEvents.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "तिथि: ${event.tithi}",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppSecondaryGreen, fontWeight = FontWeight.Medium)
                )
            }

            if (event.kalyanaks.isNotBlank()) {
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "✨ ${event.kalyanaks}",
                    style = MaterialTheme.typography.bodySmall.copy(color = AppPrimaryGold)
                )
            }
        }
    }
}
