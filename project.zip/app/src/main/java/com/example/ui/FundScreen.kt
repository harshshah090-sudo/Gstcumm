package com.example.ui

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FundTransactionEntity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FundScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val totalBankFund by viewModel.totalBankFund.collectAsStateWithLifecycle()
    val totalCashFund by viewModel.totalCashFund.collectAsStateWithLifecycle()
    val totalFund by viewModel.totalFund.collectAsStateWithLifecycle()
    val personCashBalances by viewModel.personCashBalances.collectAsStateWithLifecycle()
    val allPersons by viewModel.allFundPersons.collectAsStateWithLifecycle()
    val transactions by viewModel.allFundTransactions.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var activeTransactionType by remember { mutableStateOf("INCOMING") } // "INCOMING" or "EXPENDITURE"
    var editingTransaction by remember { mutableStateOf<FundTransactionEntity?>(null) }
    var transactionToDelete by remember { mutableStateOf<FundTransactionEntity?>(null) }

    var selectedFilterTab by remember { mutableStateOf("All") }

    val currencyFormatter = remember {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.maximumFractionDigits = 0
        format
    }

    val availablePersons = remember(allPersons, personCashBalances) {
        (allPersons.map { it.name } + personCashBalances.keys).filter { it.isNotBlank() }.distinct()
    }

    val filteredTransactions = remember(transactions, selectedFilterTab) {
        when {
            selectedFilterTab.equals("All", ignoreCase = true) -> transactions
            selectedFilterTab.equals("Bank", ignoreCase = true) -> transactions.filter { it.mode == "BANK" }
            else -> transactions.filter { it.mode == "CASH" && it.personName.equals(selectedFilterTab, ignoreCase = true) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Manage Funds",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold
                        )
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("fund_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Incoming Button (Green)
                    Button(
                        onClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही ट्रांसजेक्शन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                activeTransactionType = "INCOMING"
                                showAddDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2E7D32),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isOnline,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("incoming_fund_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Incoming",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    // Expenditure Button (Red)
                    Button(
                        onClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही ट्रांसजेक्शन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                activeTransactionType = "EXPENDITURE"
                                showAddDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC62828),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isOnline,
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("expenditure_fund_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RemoveCircle,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Expenditure",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 16.dp,
                bottom = innerPadding.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (!isOnline) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Offline Warning",
                                modifier = Modifier.size(32.dp),
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "केवल ऑनलाइन मोड (Online Connection Required)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "सभी डिवाइसों में रीयल-टाइम डेटा सिंक बनाए रखने के लिए फ़ंड विंडो केवल ऑनलाइन होने पर ही कार्य करती है। कनेक्ट होने पर डेटा स्वतः सिंक हो जाएगा।",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }
            // Summary Card displaying Total Fund, Bank, Cash in Hand (with per person breakdown)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Total Fund",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = currencyFormatter.format(totalFund),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (totalFund >= 0) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.error,
                                fontSize = 26.sp
                            )
                        )

                        HorizontalDivider(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Bank Column
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalance,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Bank",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 13.sp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currencyFormatter.format(totalBankFund),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 15.sp
                                        )
                                    )
                                }

                                VerticalDivider(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .padding(horizontal = 10.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                )

                                // Cash in Hand Column
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Payments,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.tertiary
                                        )
                                        Text(
                                            text = "Cash in Hand",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 13.sp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currencyFormatter.format(totalCashFund),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 15.sp
                                        )
                                    )
                                }
                            }
                        }

                        // Per Person Cash Breakdown (Horizontal Scrollable Chips)
                        if (personCashBalances.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Cash Holdings by Person",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    )
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    personCashBalances.forEach { (personName, balance) ->
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(
                                                    horizontal = 10.dp,
                                                    vertical = 6.dp
                                                ),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = MaterialTheme.colorScheme.primaryContainer,
                                                    modifier = Modifier.size(20.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = personName.take(1).uppercase(),
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                                            )
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = personName,
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                )
                                                Text(
                                                    text = currencyFormatter.format(balance),
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (balance >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Transaction History Section Header & Filter Tabs
            item {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Transaction History",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Small tabs for filtering: All, Bank, and Person Names
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val filterOptions = remember(availablePersons) {
                            listOf("All", "Bank") + availablePersons
                        }

                        filterOptions.forEach { filterName ->
                            val isSelected = selectedFilterTab.equals(filterName, ignoreCase = true)
                            FilterChip(
                                selected = isSelected,
                                onClick = { selectedFilterTab = filterName },
                                label = {
                                    Text(
                                        text = filterName,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 12.sp
                                        )
                                    )
                                },
                                modifier = Modifier.height(32.dp)
                            )
                        }
                    }
                }
            }

            if (filteredTransactions.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (transactions.isEmpty()) "No transactions recorded yet" else "No transactions for '$selectedFilterTab'",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap 'Incoming' or 'Expenditure' below to record a transaction.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(
                    items = filteredTransactions,
                    key = { it.id }
                ) { transaction ->
                    FundTransactionItemCard(
                        transaction = transaction,
                        currencyFormatter = currencyFormatter,
                        isOnline = isOnline,
                        onTransactionClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही सम्पादन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                editingTransaction = transaction
                            }
                        },
                        onDeleteClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही डिलीट संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                transactionToDelete = transaction
                            }
                        }
                    )
                }
            }
        }
    }

    // Add or Edit Transaction Dialog
    if (showAddDialog || editingTransaction != null) {
        AddOrEditTransactionDialog(
            type = editingTransaction?.type ?: activeTransactionType,
            editingTransaction = editingTransaction,
            availablePersons = availablePersons,
            personCashBalances = personCashBalances,
            totalBankFund = totalBankFund,
            onAddPerson = { newPersonName ->
                viewModel.addFundPerson(newPersonName)
            },
            onDeletePerson = { personNameToDelete ->
                viewModel.deleteFundPerson(personNameToDelete)
            },
            onDismiss = {
                showAddDialog = false
                editingTransaction = null
            },
            onConfirm = { mode, personName, dateMillis, amount, description ->
                if (editingTransaction != null) {
                    val updated = editingTransaction!!.copy(
                        type = editingTransaction!!.type,
                        mode = mode,
                        amount = amount,
                        description = description,
                        personName = if (mode == "CASH") personName else "",
                        date = dateMillis
                    )
                    viewModel.updateFundTransaction(updated)
                    editingTransaction = null
                    Toast.makeText(context, "Transaction updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.addFundTransaction(
                        type = activeTransactionType,
                        mode = mode,
                        amount = amount,
                        description = description,
                        personName = personName,
                        date = dateMillis
                    )
                    showAddDialog = false
                    Toast.makeText(context, "$activeTransactionType recorded successfully", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Delete Transaction Confirmation Dialog (Centered)
    if (transactionToDelete != null) {
        Dialog(
            onDismissRequest = { transactionToDelete = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 440.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "Delete Transaction",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Are you sure you want to delete this transaction entry? This will adjust your total funds accordingly.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { transactionToDelete = null }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    transactionToDelete?.let { viewModel.deleteFundTransaction(it) }
                                    transactionToDelete = null
                                    Toast.makeText(context, "Transaction deleted", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Delete", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FundTransactionItemCard(
    transaction: FundTransactionEntity,
    currencyFormatter: NumberFormat,
    isOnline: Boolean,
    onTransactionClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isIncoming = transaction.type == "INCOMING"
    val isBank = transaction.mode == "BANK"
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onTransactionClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (isIncoming) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    modifier = Modifier.size(42.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = if (isIncoming) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                            contentDescription = null,
                            tint = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Column {
                    Text(
                        text = transaction.description.ifEmpty { if (isIncoming) "Incoming Funds" else "Expenditure" },
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer
                        ) {
                            Text(
                                text = if (isBank) "Bank" else "Cash: ${transaction.personName.ifEmpty { "Cash" }}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        Text(
                            text = dateFormatter.format(Date(transaction.date)),
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "${if (isIncoming) "+" else "-"} ${currencyFormatter.format(transaction.amount)}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.ExtraBold,
                        color = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                )

                IconButton(
                    onClick = onDeleteClick,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteOutline,
                        contentDescription = "Delete",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AddOrEditTransactionDialog(
    type: String, // "INCOMING" or "EXPENDITURE"
    editingTransaction: FundTransactionEntity? = null,
    availablePersons: List<String>,
    personCashBalances: Map<String, Double>,
    totalBankFund: Double,
    onAddPerson: (String) -> Unit,
    onDeletePerson: (String) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: (mode: String, personName: String, dateMillis: Long, amount: Double, description: String) -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableStateOf(editingTransaction?.mode ?: "CASH") } // "CASH" by default
    var selectedPersonName by remember { mutableStateOf(editingTransaction?.personName ?: "") }
    var amountText by remember {
        mutableStateOf(
            editingTransaction?.amount?.let {
                if (it % 1 == 0.0) it.toLong().toString() else it.toString()
            } ?: ""
        )
    }
    var descriptionText by remember { mutableStateOf(editingTransaction?.description ?: "") }
    var errorMessage by remember { mutableStateOf("") }

    var selectedDateMillis by remember { mutableStateOf(editingTransaction?.date ?: System.currentTimeMillis()) }
    var showAddPersonDialog by remember { mutableStateOf(false) }
    var personToDeleteConfirm by remember { mutableStateOf<String?>(null) }

    val isIncoming = type == "INCOMING"
    val isEditing = editingTransaction != null
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val currencyFormatter = remember {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.maximumFractionDigits = 0
        format
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .widthIn(max = 480.dp)
                    .fillMaxWidth(0.95f)
                    .wrapContentHeight()
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Title Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isIncoming) Icons.Default.AddCircle else Icons.Default.RemoveCircle,
                            contentDescription = null,
                            tint = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        Text(
                            text = if (isEditing) {
                                if (isIncoming) "Edit Incoming Fund" else "Edit Expenditure"
                            } else {
                                if (isIncoming) "Add Incoming Fund" else "Add Expenditure"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // Mode Selection (Bank vs Cash in Hand)
                    Column {
                        Text(
                            text = "Fund Source / Destination Mode",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedMode == "BANK",
                                onClick = {
                                    selectedMode = "BANK"
                                    errorMessage = ""
                                },
                                label = { Text("Bank") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )

                            FilterChip(
                                selected = selectedMode == "CASH",
                                onClick = {
                                    selectedMode = "CASH"
                                    errorMessage = ""
                                },
                                label = { Text("Cash in Hand") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // If Cash in Hand: Person Selection with Long-Press to Delete
                    if (selectedMode == "CASH") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Select Person",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedPersonName.isEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                    )
                                )

                                IconButton(
                                    onClick = { showAddPersonDialog = true },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = "Add Person",
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            if (availablePersons.isEmpty()) {
                                Text(
                                    text = "No person added yet. Click '+' above to add.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            } else {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    availablePersons.forEach { personName ->
                                        val isSelected = selectedPersonName.equals(personName, ignoreCase = true)
                                        val personBalance = personCashBalances[personName] ?: 0.0

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                            ),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .combinedClickable(
                                                    onClick = {
                                                        selectedPersonName = personName
                                                        errorMessage = ""
                                                    },
                                                    onLongClick = {
                                                        if (abs(personBalance) > 0.001) {
                                                            Toast.makeText(
                                                                context,
                                                                "Cannot delete $personName. Cash balance must be ₹0 (Current balance: ${currencyFormatter.format(personBalance)})",
                                                                Toast.LENGTH_LONG
                                                            ).show()
                                                        } else {
                                                            personToDeleteConfirm = personName
                                                        }
                                                    }
                                                )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "$personName (${currencyFormatter.format(personBalance)})",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 12.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Date Selection Field (Today by Default)
                    Column {
                        Text(
                            text = "Date",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                                    DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val selectedCal = Calendar.getInstance().apply {
                                                set(Calendar.YEAR, year)
                                                set(Calendar.MONTH, month)
                                                set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                            }
                                            selectedDateMillis = selectedCal.timeInMillis
                                        },
                                        cal.get(Calendar.YEAR),
                                        cal.get(Calendar.MONTH),
                                        cal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = dateFormatter.format(Date(selectedDateMillis)),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = "Select Date",
                                    modifier = Modifier.size(18.dp),
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Amount Field
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = {
                            amountText = it.filter { char -> char.isDigit() || char == '.' }
                            errorMessage = ""
                        },
                        label = { Text("Amount (₹) *") },
                        placeholder = { Text("e.g. 5000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = errorMessage.contains("amount", ignoreCase = true) || errorMessage.contains("exceed", ignoreCase = true),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("fund_amount_input")
                    )

                    // Notes / Details Field (Mandatory)
                    OutlinedTextField(
                        value = descriptionText,
                        onValueChange = {
                            descriptionText = it
                            errorMessage = ""
                        },
                        label = { Text("Notes / Details (Mandatory) *") },
                        placeholder = { Text("e.g. Contribution for Paryushan event") },
                        maxLines = 2,
                        isError = errorMessage.contains("Notes", ignoreCase = true),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorMessage.isNotEmpty()) {
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Dialog Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val amount = amountText.toDoubleOrNull()
                                if (amount == null || amount <= 0) {
                                    errorMessage = "Please enter a valid amount greater than 0"
                                    return@Button
                                }

                                if (descriptionText.trim().isEmpty()) {
                                    errorMessage = "Please enter Notes / Details"
                                    return@Button
                                }

                                if (selectedMode == "CASH") {
                                    if (selectedPersonName.isBlank()) {
                                        errorMessage = "Please select a person for Cash in Hand"
                                        return@Button
                                    }

                                    // Expenditure limit check for Cash in Hand
                                    if (!isIncoming) {
                                        val currentPersonCash = personCashBalances[selectedPersonName] ?: 0.0
                                        val previousContrib = if (editingTransaction != null && editingTransaction.mode == "CASH" && editingTransaction.personName.equals(selectedPersonName, ignoreCase = true) && editingTransaction.type == "EXPENDITURE") {
                                            editingTransaction.amount
                                        } else 0.0
                                        val availableCash = currentPersonCash + previousContrib
                                        if (amount > availableCash) {
                                            errorMessage = "Expenditure (${currencyFormatter.format(amount)}) cannot exceed available cash for $selectedPersonName (${currencyFormatter.format(availableCash)})"
                                            return@Button
                                        }
                                    }
                                } else if (selectedMode == "BANK" && !isIncoming) {
                                    // Expenditure limit check for Bank
                                    val previousBankContrib = if (editingTransaction != null && editingTransaction.mode == "BANK" && editingTransaction.type == "EXPENDITURE") {
                                        editingTransaction.amount
                                    } else 0.0
                                    val availableBank = totalBankFund + previousBankContrib
                                    if (amount > availableBank) {
                                        errorMessage = "Expenditure (${currencyFormatter.format(amount)}) cannot exceed available bank balance (${currencyFormatter.format(availableBank)})"
                                        return@Button
                                    }
                                }

                                onConfirm(
                                    selectedMode,
                                    if (selectedMode == "CASH") selectedPersonName else "",
                                    selectedDateMillis,
                                    amount,
                                    descriptionText.trim()
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828)
                            )
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Add Person Dialog (Centered)
    if (showAddPersonDialog) {
        var newPersonInput by remember { mutableStateOf("") }
        var personError by remember { mutableStateOf("") }

        Dialog(
            onDismissRequest = { showAddPersonDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 400.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Add Person",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = newPersonInput,
                            onValueChange = {
                                newPersonInput = it
                                personError = ""
                            },
                            label = { Text("Person Name *") },
                            placeholder = { Text("e.g. Rahul Shah") },
                            singleLine = true,
                            isError = personError.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (personError.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = personError,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showAddPersonDialog = false }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val name = newPersonInput.trim()
                                    if (name.isEmpty()) {
                                        personError = "Person name cannot be empty"
                                    } else {
                                        onAddPerson(name)
                                        selectedPersonName = name
                                        showAddPersonDialog = false
                                        Toast.makeText(context, "$name added", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Text("OK", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Person Confirmation Dialog (Centered)
    if (personToDeleteConfirm != null) {
        Dialog(
            onDismissRequest = { personToDeleteConfirm = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 400.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Delete Person",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Are you sure you want to delete '$personToDeleteConfirm' from the cash persons list?",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { personToDeleteConfirm = null }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val target = personToDeleteConfirm!!
                                    onDeletePerson(target)
                                    if (selectedPersonName.equals(target, ignoreCase = true)) {
                                        selectedPersonName = ""
                                    }
                                    Toast.makeText(context, "$target deleted", Toast.LENGTH_SHORT).show()
                                    personToDeleteConfirm = null
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Delete", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}
