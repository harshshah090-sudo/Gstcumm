package com.example.ui

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.*
import kotlinx.coroutines.delay
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FundTransactionEntity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FundScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    val totalBankFund by viewModel.totalBankFund.collectAsStateWithLifecycle()
    val totalCashFund by viewModel.totalCashFund.collectAsStateWithLifecycle()
    val totalFund by viewModel.totalFund.collectAsStateWithLifecycle()
    val personCashBalances by viewModel.personCashBalances.collectAsStateWithLifecycle()
    val allPersons by viewModel.allFundPersons.collectAsStateWithLifecycle()
    val transactions by viewModel.allFundTransactions.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val syncStatus by viewModel.syncStatus.collectAsStateWithLifecycle()

    var showAddDialog by remember { mutableStateOf(false) }
    var showTransferDialog by remember { mutableStateOf(false) }
    var activeTransactionType by remember { mutableStateOf("INCOMING") } // "INCOMING" or "EXPENDITURE"
    var editingTransaction by remember { mutableStateOf<FundTransactionEntity?>(null) }
    var editingTransferTransaction by remember { mutableStateOf<FundTransactionEntity?>(null) }
    var transactionToDelete by remember { mutableStateOf<FundTransactionEntity?>(null) }

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 2 })
    val coroutineScope = rememberCoroutineScope()
    var selectedHistoryYear by remember { mutableStateOf<Int?>(null) }

    var selectedFilterTab by remember { mutableStateOf("All") }
    var historyFilterTab by remember { mutableStateOf("All") }

    fun handleBackPress(): Boolean {
        if (pagerState.currentPage == 0) {
            if (!selectedFilterTab.equals("All", ignoreCase = true)) {
                selectedFilterTab = "All"
                return true
            }
            return false
        } else {
            if (selectedHistoryYear != null) {
                if (!historyFilterTab.equals("All", ignoreCase = true)) {
                    historyFilterTab = "All"
                    return true
                }
                selectedHistoryYear = null
                return true
            } else {
                if (!historyFilterTab.equals("All", ignoreCase = true) || !selectedFilterTab.equals("All", ignoreCase = true)) {
                    historyFilterTab = "All"
                    selectedFilterTab = "All"
                    return true
                }
                coroutineScope.launch {
                    pagerState.animateScrollToPage(0)
                }
                return true
            }
        }
    }

    val isBackHandlerActive = remember(pagerState.currentPage, selectedFilterTab, historyFilterTab, selectedHistoryYear) {
        (pagerState.currentPage == 0 && !selectedFilterTab.equals("All", ignoreCase = true)) ||
        (pagerState.currentPage == 1)
    }

    BackHandler(enabled = isBackHandlerActive) {
        if (!handleBackPress()) {
            onNavigateBack()
        }
    }

    val currentYear = remember { Calendar.getInstance().get(Calendar.YEAR) }

    fun getYearFromDate(dateMillis: Long): Int {
        val cal = Calendar.getInstance()
        cal.timeInMillis = dateMillis
        return cal.get(Calendar.YEAR)
    }

    val currentYearTransactions = remember(transactions, currentYear) {
        transactions.filter { getYearFromDate(it.date) == currentYear }
    }

    val otherYearsTransactions = remember(transactions, currentYear) {
        transactions.filter { getYearFromDate(it.date) != currentYear }
    }

    val yearlyHistoryGrouped = remember(otherYearsTransactions) {
        otherYearsTransactions
            .groupBy { getYearFromDate(it.date) }
            .toSortedMap(compareByDescending { it })
    }

    val currencyFormatter = remember {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.maximumFractionDigits = 0
        format
    }

    var selectedTransactionForActions by remember { mutableStateOf<FundTransactionEntity?>(null) }

    val availablePersons = remember(allPersons, personCashBalances) {
        (allPersons.map { it.name } + personCashBalances.keys).filter { it.isNotBlank() }.distinct()
    }

    val filteredTransactions = remember(currentYearTransactions, selectedFilterTab) {
        when {
            selectedFilterTab.equals("All", ignoreCase = true) -> currentYearTransactions
            selectedFilterTab.equals("Bank", ignoreCase = true) -> currentYearTransactions.filter {
                (it.mode == "BANK" && it.type != "TRANSFER") ||
                (it.type == "TRANSFER" && (it.transferFrom.equals("Bank", ignoreCase = true) || it.transferTo.equals("Bank", ignoreCase = true)))
            }
            selectedFilterTab.equals("Incoming", ignoreCase = true) -> currentYearTransactions.filter {
                it.type == "INCOMING"
            }
            selectedFilterTab.equals("Expenditure", ignoreCase = true) -> currentYearTransactions.filter {
                it.type == "EXPENDITURE"
            }
            else -> currentYearTransactions.filter {
                (it.mode == "CASH" && it.personName.equals(selectedFilterTab, ignoreCase = true) && it.type != "TRANSFER") ||
                (it.type == "TRANSFER" && (it.transferFrom.equals(selectedFilterTab, ignoreCase = true) || it.transferTo.equals(selectedFilterTab, ignoreCase = true)))
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = Alignment.CenterStart
                    ) {
                        val rawProgress = pagerState.currentPage + pagerState.currentPageOffsetFraction
                        val scrollProgress = rawProgress.coerceIn(0f, 1f)

                        // Page 0 Title: Manage Funds
                        Text(
                            text = "Manage Funds",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            modifier = Modifier
                                .graphicsLayer {
                                    alpha = (1f - scrollProgress).coerceIn(0f, 1f)
                                    translationX = -scrollProgress * 150f
                                }
                        )

                        // Page 1 Title: Transaction History / Year XXXX Transactions
                        AnimatedContent(
                            targetState = selectedHistoryYear,
                            transitionSpec = {
                                if (targetState != null) {
                                    slideInHorizontally { w -> w / 2 } + fadeIn() togetherWith slideOutHorizontally { w -> -w / 2 } + fadeOut()
                                } else {
                                    slideInHorizontally { w -> -w / 2 } + fadeIn() togetherWith slideOutHorizontally { w -> w / 2 } + fadeOut()
                                }
                            },
                            label = "HistoryTitleTransition",
                            modifier = Modifier
                                .graphicsLayer {
                                    alpha = scrollProgress.coerceIn(0f, 1f)
                                    translationX = (1f - scrollProgress) * 150f
                                }
                        ) { historyYear ->
                            Column {
                                Text(
                                    text = if (historyYear != null) "Year $historyYear Transactions" else "Transaction History",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                                Text(
                                    text = if (historyYear != null) "01 Jan $historyYear – 31 Dec $historyYear" else "Summarized Yearly Records",
                                    style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (!handleBackPress()) {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("fund_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                actions = {
                    SyncStatusIcon(
                        syncState = syncStatus,
                        onClick = {
                            val msg = when (syncStatus) {
                                SyncState.CONNECTED -> "Real-time sync active across devices"
                                SyncState.SYNCING -> "Syncing data with cloud..."
                                SyncState.OFFLINE -> "Offline: Reconnect to sync"
                            }
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            Surface(
                tonalElevation = 8.dp,
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Incoming Button (Green)
                    Button(
                        onClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही ट्रांसजेक्शन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                activeTransactionType = "INCOMING"
                                showAddDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF2E7D32),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isOnline,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("incoming_fund_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AddCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Incoming",
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }

                    // Transfer Button (Blue, Square in shape, ONLY transfer icon, NO text)
                    Button(
                        onClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही ट्रांसजेक्शन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                showTransferDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1976D2),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isOnline,
                        contentPadding = PaddingValues(0.dp),
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("transfer_fund_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                            contentDescription = "Transfer Fund",
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    // Expenditure Button (Red)
                    Button(
                        onClick = {
                            if (!isOnline) {
                                Toast.makeText(context, "केवल ऑनलाइन होने पर ही ट्रांसजेक्शन संभव है", Toast.LENGTH_SHORT).show()
                            } else {
                                activeTransactionType = "EXPENDITURE"
                                showAddDialog = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC62828),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        enabled = isOnline,
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("expenditure_fund_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.RemoveCircle,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Expenditure",
                            maxLines = 1,
                            softWrap = false,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        )
                    }
                }
            }
        },
        modifier = modifier
    ) { innerPadding ->
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .fillMaxSize()
                .padding(top = innerPadding.calculateTopPadding())
        ) { page ->
            if (page == 0) {
                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 16.dp,
                        bottom = innerPadding.calculateBottomPadding() + 88.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                ) {
            if (!isOnline) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.errorContainer,
                            contentColor = MaterialTheme.colorScheme.onErrorContainer
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Offline Warning",
                                modifier = Modifier.size(32.dp),
                                tint = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "केवल ऑनलाइन मोड (Online Connection Required)",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "सभी डिवाइसों में रीयल-टाइम डेटा सिंक बनाए रखने के लिए फ़ंड विंडो केवल ऑनलाइन होने पर ही कार्य करती है। कनेक्ट होने पर डेटा स्वतः सिंक हो जाएगा।",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    }
                }
            }
            // Summary Card displaying Total Fund, Bank, Cash in Hand (with per person breakdown)
            item {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Total Fund",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = currencyFormatter.format(totalFund),
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = if (totalFund >= 0) MaterialTheme.colorScheme.onSurface
                                else MaterialTheme.colorScheme.error,
                                fontSize = 26.sp
                            )
                        )

                        HorizontalDivider(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                        )

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Bank Column
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AccountBalance,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "Bank",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 13.sp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currencyFormatter.format(totalBankFund),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 15.sp
                                        )
                                    )
                                }

                                VerticalDivider(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .padding(horizontal = 10.dp),
                                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                )

                                // Cash in Hand Column
                                Column(
                                    modifier = Modifier.weight(1f),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Payments,
                                            contentDescription = null,
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.tertiary
                                        )
                                        Text(
                                            text = "Cash in Hand",
                                            style = MaterialTheme.typography.titleSmall.copy(
                                                fontWeight = FontWeight.Bold,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                fontSize = 13.sp
                                            )
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = currencyFormatter.format(totalCashFund),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface,
                                            fontSize = 15.sp
                                        )
                                    )
                                }
                            }
                        }

                        // Per Person Cash Breakdown (Horizontal Scrollable Chips)
                        if (personCashBalances.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))

                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.Start
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier.padding(bottom = 6.dp, start = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Cash Holdings by Person",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontSize = 11.sp
                                        )
                                    )
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState()),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    personCashBalances.forEach { (personName, balance) ->
                                        Surface(
                                            shape = RoundedCornerShape(10.dp),
                                            color = MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(
                                                    horizontal = 10.dp,
                                                    vertical = 6.dp
                                                ),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = MaterialTheme.colorScheme.primaryContainer,
                                                    modifier = Modifier.size(20.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Text(
                                                            text = personName.take(1).uppercase(),
                                                            style = MaterialTheme.typography.labelSmall.copy(
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                color = MaterialTheme.colorScheme.onPrimaryContainer
                                                            )
                                                        )
                                                    }
                                                }
                                                Text(
                                                    text = personName,
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Medium,
                                                        color = MaterialTheme.colorScheme.onSurface
                                                    )
                                                )
                                                Text(
                                                    text = currencyFormatter.format(balance),
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = if (balance >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Transaction History Section Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.clickable {
                            coroutineScope.launch {
                                pagerState.animateScrollToPage(1)
                            }
                        }
                    ) {
                        Text(
                            text = "Transaction History",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        )
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Transaction History",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Filter Menu Button on the right side
                    var showFilterMenu by remember { mutableStateOf(false) }
                    val filterOptions = remember(availablePersons) {
                        listOf("All", "Bank", "Incoming", "Expenditure") + availablePersons
                    }

                    Box {
                        FilterChip(
                            selected = !selectedFilterTab.equals("All", ignoreCase = true),
                            onClick = { showFilterMenu = true },
                            label = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.FilterList,
                                        contentDescription = "Filter",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        text = selectedFilterTab,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 12.sp
                                        )
                                    )
                                }
                            },
                            modifier = Modifier.height(32.dp)
                        )

                        DropdownMenu(
                            expanded = showFilterMenu,
                            onDismissRequest = { showFilterMenu = false }
                        ) {
                            filterOptions.forEach { option ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            text = option,
                                            fontWeight = if (selectedFilterTab.equals(option, ignoreCase = true)) FontWeight.Bold else FontWeight.Normal,
                                            color = if (selectedFilterTab.equals(option, ignoreCase = true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                    },
                                    onClick = {
                                        selectedFilterTab = option
                                        showFilterMenu = false
                                    },
                                    leadingIcon = if (selectedFilterTab.equals(option, ignoreCase = true)) {
                                        {
                                            Icon(
                                                imageVector = Icons.Default.Check,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    } else null
                                )
                            }
                        }
                    }
                }
            }

            if (filteredTransactions.isEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.ReceiptLong,
                                contentDescription = null,
                                modifier = Modifier.size(48.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = if (transactions.isEmpty()) "No transactions recorded yet" else "No transactions for '$selectedFilterTab'",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Tap 'Incoming' or 'Expenditure' below to record a transaction.",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                ),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(
                    items = filteredTransactions,
                    key = { it.id }
                ) { transaction ->
                    FundTransactionItemCard(
                        transaction = transaction,
                        currencyFormatter = currencyFormatter,
                        isOnline = isOnline,
                        onTransactionClick = {},
                        onLongClick = {
                            selectedTransactionForActions = transaction
                        }
                    )
                }
            }
        }
    }

    // Add or Edit Transaction Dialog
    if (showAddDialog || editingTransaction != null) {
        AddOrEditTransactionDialog(
            type = editingTransaction?.type ?: activeTransactionType,
            editingTransaction = editingTransaction,
            availablePersons = availablePersons,
            personCashBalances = personCashBalances,
            totalBankFund = totalBankFund,
            onAddPerson = { newPersonName ->
                viewModel.addFundPerson(newPersonName)
            },
            onDeletePerson = { personNameToDelete ->
                viewModel.deleteFundPerson(personNameToDelete)
            },
            onDismiss = {
                showAddDialog = false
                editingTransaction = null
            },
            onValidate = { proposedTx ->
                viewModel.canSaveFundTransaction(editingTransaction, proposedTx)
            },
            onConfirm = { mode, personName, dateMillis, amount, description ->
                if (editingTransaction != null) {
                    val oldTx = editingTransaction!!
                    val changes = mutableListOf<String>()
                    val nowStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())

                    if (kotlin.math.abs(oldTx.amount - amount) > 0.001) {
                        changes.add("Amount changed from ${currencyFormatter.format(oldTx.amount)} to ${currencyFormatter.format(amount)} on $nowStr")
                    }
                    if (oldTx.description.trim() != description.trim()) {
                        val oldDesc = oldTx.description.ifEmpty { "None" }
                        val newDesc = description.ifEmpty { "None" }
                        changes.add("Notes changed from '$oldDesc' to '$newDesc' on $nowStr")
                    }
                    if (changes.isEmpty()) {
                        changes.add("Transaction details updated on $nowStr")
                    }

                    val newHistory = if (oldTx.editHistory.isBlank()) {
                        changes.joinToString("\n")
                    } else {
                        "${oldTx.editHistory}\n${changes.joinToString("\n")}"
                    }

                    val updated = oldTx.copy(
                        amount = amount,
                        description = description,
                        isEdited = true,
                        editHistory = newHistory
                    )
                    viewModel.updateFundTransaction(updated)
                    editingTransaction = null
                    Toast.makeText(context, "Transaction updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.addFundTransaction(
                        type = activeTransactionType,
                        mode = mode,
                        amount = amount,
                        description = description,
                        personName = personName,
                        date = dateMillis
                    )
                    showAddDialog = false
                    Toast.makeText(context, "$activeTransactionType recorded successfully", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Transfer Fund Dialog
    if (showTransferDialog || editingTransferTransaction != null) {
        TransferFundDialog(
            editingTransaction = editingTransferTransaction,
            availablePersons = availablePersons,
            totalBankFund = totalBankFund,
            personCashBalances = personCashBalances,
            onDismiss = {
                showTransferDialog = false
                editingTransferTransaction = null
            },
            onValidate = { proposedTx ->
                viewModel.canSaveFundTransaction(editingTransferTransaction, proposedTx)
            },
            onConfirm = { from, to, dateMillis, amount, description ->
                if (editingTransferTransaction != null) {
                    val oldTx = editingTransferTransaction!!
                    val changes = mutableListOf<String>()
                    val nowStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())

                    if (kotlin.math.abs(oldTx.amount - amount) > 0.001) {
                        changes.add("Amount changed from ${currencyFormatter.format(oldTx.amount)} to ${currencyFormatter.format(amount)} on $nowStr")
                    }
                    if (oldTx.description.trim() != description.trim()) {
                        val oldDesc = oldTx.description.ifEmpty { "None" }
                        val newDesc = description.ifEmpty { "None" }
                        changes.add("Notes changed from '$oldDesc' to '$newDesc' on $nowStr")
                    }
                    if (changes.isEmpty()) {
                        changes.add("Transaction details updated on $nowStr")
                    }

                    val newHistory = if (oldTx.editHistory.isBlank()) {
                        changes.joinToString("\n")
                    } else {
                        "${oldTx.editHistory}\n${changes.joinToString("\n")}"
                    }

                    val updated = oldTx.copy(
                        amount = amount,
                        description = description,
                        isEdited = true,
                        editHistory = newHistory
                    )
                    viewModel.updateFundTransaction(updated)
                    editingTransferTransaction = null
                    Toast.makeText(context, "Transfer updated successfully", Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.addFundTransaction(
                        type = "TRANSFER",
                        mode = if (from.equals("Bank", ignoreCase = true)) "BANK" else "CASH",
                        amount = amount,
                        description = description,
                        personName = if (!from.equals("Bank", ignoreCase = true)) from else "",
                        date = dateMillis,
                        transferFrom = from,
                        transferTo = to
                    )
                    showTransferDialog = false
                    Toast.makeText(context, "Transfer recorded successfully", Toast.LENGTH_SHORT).show()
                }
            }
        )
    }

    // Delete Transaction Confirmation Dialog (Centered)
    if (transactionToDelete != null) {
        val targetTx = transactionToDelete!!
        val (canDelete, deleteBlockReason) = remember(targetTx, transactions) {
            viewModel.canDeleteFundTransaction(targetTx)
        }

        Dialog(
            onDismissRequest = { transactionToDelete = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 440.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp)
                    ) {
                        Text(
                            text = "Delete Transaction",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Are you sure you want to move this transaction to the Recycle Bin?",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        if (!canDelete) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.errorContainer,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                    Text(
                                        text = deleteBlockReason,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onErrorContainer,
                                            fontWeight = FontWeight.Bold
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { transactionToDelete = null }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val (success, reason) = viewModel.deleteFundTransaction(targetTx)
                                    if (success) {
                                        Toast.makeText(context, "Transaction moved to Recycle Bin", Toast.LENGTH_SHORT).show()
                                        transactionToDelete = null
                                    } else {
                                        Toast.makeText(context, reason, Toast.LENGTH_LONG).show()
                                    }
                                },
                                enabled = canDelete,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Delete", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
                }
            } else {
                TransactionHistoryScreen(
                    currentYear = currentYear,
                    yearlyHistoryGrouped = yearlyHistoryGrouped,
                    selectedHistoryYear = selectedHistoryYear,
                    onSelectYear = {
                        selectedHistoryYear = it
                        historyFilterTab = "All"
                    },
                    onBackToSummaries = {
                        selectedHistoryYear = null
                        historyFilterTab = "All"
                    },
                    onDismiss = {
                        coroutineScope.launch {
                            pagerState.animateScrollToPage(0)
                        }
                    },
                    currencyFormatter = currencyFormatter,
                    isOnline = isOnline,
                    context = context,
                    onLongClickTransaction = { tx ->
                        selectedTransactionForActions = tx
                    },
                    historyFilterTab = historyFilterTab,
                    onHistoryFilterTabChange = { historyFilterTab = it }
                )
            }
        }
    }

    // Animated Long Press Action Options Dialog
    if (selectedTransactionForActions != null) {
        val targetTx = selectedTransactionForActions!!
        FundTransactionActionDialog(
            transaction = targetTx,
            currencyFormatter = currencyFormatter,
            isOnline = isOnline,
            onDismiss = { selectedTransactionForActions = null },
            onEditTransaction = {
                selectedTransactionForActions = null
                if (!isOnline) {
                    Toast.makeText(context, "केवल ऑनलाइन होने पर ही सम्पादन संभव है", Toast.LENGTH_SHORT).show()
                } else {
                    if (targetTx.type == "TRANSFER") {
                        editingTransferTransaction = targetTx
                    } else {
                        editingTransaction = targetTx
                    }
                }
            },
            onDeleteTransaction = {
                selectedTransactionForActions = null
                if (!isOnline) {
                    Toast.makeText(context, "केवल ऑनलाइन होने पर ही डिलीट संभव है", Toast.LENGTH_SHORT).show()
                } else {
                    transactionToDelete = targetTx
                }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FundTransactionItemCard(
    transaction: FundTransactionEntity,
    currencyFormatter: NumberFormat,
    isOnline: Boolean,
    onTransactionClick: () -> Unit = {},
    onLongClick: () -> Unit = {}
) {
    var isExpanded by remember { mutableStateOf(false) }
    val isTransfer = transaction.type == "TRANSFER"
    val isIncoming = transaction.type == "INCOMING"
    val isBank = transaction.mode == "BANK"
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val themeColor = when {
        isTransfer -> Color(0xFF1565C0)
        isIncoming -> Color(0xFF2E7D32)
        else -> Color(0xFFC62828)
    }

    val iconBgColor = when {
        isTransfer -> Color(0xFFE3F2FD)
        isIncoming -> Color(0xFFE8F5E9)
        else -> Color(0xFFFFEBEE)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = {
                    if (transaction.isEdited || transaction.editHistory.isNotBlank()) {
                        isExpanded = !isExpanded
                    }
                    onTransactionClick()
                },
                onLongClick = { onLongClick() }
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = iconBgColor,
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = when {
                                    isTransfer -> Icons.AutoMirrored.Filled.CompareArrows
                                    isIncoming -> Icons.Default.ArrowDownward
                                    else -> Icons.Default.ArrowUpward
                                },
                                contentDescription = null,
                                tint = themeColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = transaction.description.ifEmpty {
                                if (isTransfer) "Transfer Fund" else if (isIncoming) "Incoming Funds" else "Expenditure"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )

                        Spacer(modifier = Modifier.height(2.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (isTransfer) Color(0xFFE3F2FD) else MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    text = if (isTransfer) {
                                        "Transfer: ${transaction.transferFrom} → ${transaction.transferTo}"
                                    } else if (isBank) {
                                        "Bank"
                                    } else {
                                        "Cash: ${transaction.personName.ifEmpty { "Cash" }}"
                                    },
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isTransfer) Color(0xFF1565C0) else MaterialTheme.colorScheme.onSecondaryContainer
                                    ),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            Text(
                                text = dateFormatter.format(Date(transaction.date)),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (isTransfer) currencyFormatter.format(transaction.amount) else "${if (isIncoming) "+" else "-"} ${currencyFormatter.format(transaction.amount)}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = themeColor
                        )
                    )

                    if (transaction.isEdited || transaction.editHistory.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { isExpanded = !isExpanded }
                                .padding(2.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Edit,
                                contentDescription = "Edited",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                                modifier = Modifier.size(12.dp)
                            )
                            Icon(
                                imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                contentDescription = if (isExpanded) "Collapse History" else "Expand History",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.65f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }

            if (isExpanded) {
                Spacer(modifier = Modifier.height(10.dp))
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                Spacer(modifier = Modifier.height(8.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "Edit History Details:",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    val lines = transaction.editHistory.split("\n").filter { it.isNotBlank() }
                    if (lines.isNotEmpty()) {
                        lines.forEach { line ->
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    text = "•",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                                Text(
                                    text = line,
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    } else {
                        Text(
                            text = "This transaction was updated.",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun AddOrEditTransactionDialog(
    type: String, // "INCOMING" or "EXPENDITURE"
    editingTransaction: FundTransactionEntity? = null,
    initialDescription: String = "",
    availablePersons: List<String>,
    personCashBalances: Map<String, Double>,
    totalBankFund: Double,
    onAddPerson: (String) -> Unit,
    onDeletePerson: (String) -> Unit,
    onDismiss: () -> Unit,
    onValidate: (proposedTx: FundTransactionEntity) -> Pair<Boolean, String> = { Pair(true, "") },
    onConfirm: (mode: String, personName: String, dateMillis: Long, amount: Double, description: String) -> Unit
) {
    val context = LocalContext.current
    var selectedMode by remember { mutableStateOf(editingTransaction?.mode ?: "CASH") } // "CASH" by default
    var selectedPersonName by remember { mutableStateOf(editingTransaction?.personName ?: "") }
    val initialAmount = remember(editingTransaction) {
        editingTransaction?.amount?.let {
            if (it % 1 == 0.0) it.toLong().toString() else it.toString()
        } ?: ""
    }
    var amountTextFieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = initialAmount,
                selection = TextRange(initialAmount.length)
            )
        )
    }
    var descriptionText by remember { mutableStateOf(editingTransaction?.description ?: initialDescription) }
    var errorMessage by remember { mutableStateOf("") }

    var selectedDateMillis by remember { mutableStateOf(editingTransaction?.date ?: System.currentTimeMillis()) }
    var showAddPersonDialog by remember { mutableStateOf(false) }
    var personToDeleteConfirm by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    val isIncoming = type == "INCOMING"
    val isEditing = editingTransaction != null
    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }
    val currencyFormatter = remember {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.maximumFractionDigits = 0
        format
    }

    val amountFocusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        amountFocusRequester.requestFocus()
        amountTextFieldValue = amountTextFieldValue.copy(
            selection = TextRange(amountTextFieldValue.text.length)
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                modifier = Modifier
                    .widthIn(max = 480.dp)
                    .fillMaxWidth(0.95f)
                    .wrapContentHeight()
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Title Header
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isIncoming) Icons.Default.AddCircle else Icons.Default.RemoveCircle,
                            contentDescription = null,
                            tint = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        Text(
                            text = if (isEditing) {
                                if (isIncoming) "Edit Incoming Fund" else "Edit Expenditure"
                            } else {
                                if (isIncoming) "Add Incoming Fund" else "Add Expenditure"
                            },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // Mode Selection (Bank vs Cash in Hand)
                    Column {
                        Text(
                            text = "Fund Source / Destination Mode",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            FilterChip(
                                selected = selectedMode == "BANK",
                                enabled = !isEditing,
                                onClick = {
                                    if (!isEditing) {
                                        selectedMode = "BANK"
                                        errorMessage = ""
                                    }
                                },
                                label = { Text("Bank") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.AccountBalance,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )

                            FilterChip(
                                selected = selectedMode == "CASH",
                                enabled = !isEditing,
                                onClick = {
                                    if (!isEditing) {
                                        selectedMode = "CASH"
                                        errorMessage = ""
                                    }
                                },
                                label = { Text("Cash in Hand") },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Default.Payments,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    // If Cash in Hand: Person Selection with Long-Press to Delete
                    if (selectedMode == "CASH") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                    RoundedCornerShape(12.dp)
                                )
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Select Person",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedPersonName.isEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                                    )
                                )

                                IconButton(
                                    onClick = { if (!isEditing) showAddPersonDialog = true },
                                    enabled = !isEditing,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PersonAdd,
                                        contentDescription = "Add Person",
                                        tint = if (isEditing) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f) else MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            if (availablePersons.isEmpty()) {
                                Text(
                                    text = "No person added yet. Click '+' above to add.",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            } else {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    availablePersons.forEach { personName ->
                                        val isSelected = selectedPersonName.equals(personName, ignoreCase = true)
                                        val personBalance = personCashBalances[personName] ?: 0.0

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                            ),
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .combinedClickable(
                                                    enabled = !isEditing,
                                                    onClick = {
                                                        if (!isEditing) {
                                                            selectedPersonName = personName
                                                            errorMessage = ""
                                                        }
                                                    },
                                                    onLongClick = {
                                                        if (!isEditing) {
                                                            if (abs(personBalance) > 0.001) {
                                                                Toast.makeText(
                                                                    context,
                                                                    "Cannot delete $personName. Cash balance must be ₹0 (Current balance: ${currencyFormatter.format(personBalance)})",
                                                                    Toast.LENGTH_LONG
                                                                ).show()
                                                            } else {
                                                                personToDeleteConfirm = personName
                                                            }
                                                        }
                                                    }
                                                )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                if (isSelected) {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                Text(
                                                    text = "$personName (${currencyFormatter.format(personBalance)})",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                        fontSize = 12.sp,
                                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurface
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Date Selection Field (Today by Default)
                    Column {
                        Text(
                            text = "Date",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isEditing) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = if (isEditing) 0.3f else 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(
                                    if (!isEditing) {
                                        Modifier.clickable {
                                            val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                                            DatePickerDialog(
                                                context,
                                                { _, year, month, dayOfMonth ->
                                                    val selectedCal = Calendar.getInstance().apply {
                                                        set(Calendar.YEAR, year)
                                                        set(Calendar.MONTH, month)
                                                        set(Calendar.DAY_OF_MONTH, dayOfMonth)
                                                    }
                                                    selectedDateMillis = selectedCal.timeInMillis
                                                },
                                                cal.get(Calendar.YEAR),
                                                cal.get(Calendar.MONTH),
                                                cal.get(Calendar.DAY_OF_MONTH)
                                            ).show()
                                        }
                                    } else Modifier
                                )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = dateFormatter.format(Date(selectedDateMillis)),
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isEditing) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                Icon(
                                    imageVector = Icons.Default.CalendarToday,
                                    contentDescription = "Select Date",
                                    modifier = Modifier.size(18.dp),
                                    tint = if (isEditing) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f) else MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    // Amount Field
                    OutlinedTextField(
                        value = amountTextFieldValue,
                        onValueChange = { newValue ->
                            val filteredText = newValue.text.filter { char -> char.isDigit() || char == '.' }
                            val diff = newValue.text.length - filteredText.length
                            val newSelection = if (diff == 0) {
                                newValue.selection
                            } else {
                                TextRange(filteredText.length)
                            }
                            amountTextFieldValue = TextFieldValue(
                                text = filteredText,
                                selection = newSelection
                            )
                            errorMessage = ""
                        },
                        label = { Text("Amount (₹) *") },
                        placeholder = { Text("e.g. 5000") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        isError = errorMessage.contains("amount", ignoreCase = true) || errorMessage.contains("exceed", ignoreCase = true),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("fund_amount_input")
                            .focusRequester(amountFocusRequester)
                    )

                    // Notes / Details Field (Mandatory)
                    OutlinedTextField(
                        value = descriptionText,
                        onValueChange = {
                            descriptionText = it
                            errorMessage = ""
                        },
                        label = { Text("Notes / Details (Mandatory) *") },
                        placeholder = { Text("e.g. Contribution for Paryushan event") },
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                        maxLines = 2,
                        isError = errorMessage.contains("Notes", ignoreCase = true),
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (errorMessage.isNotEmpty()) {
                        Text(
                            text = errorMessage,
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Dialog Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            enabled = !isSubmitting,
                            onClick = {
                                if (isSubmitting) return@Button

                                val amount = amountTextFieldValue.text.toDoubleOrNull()
                                if (amount == null || amount <= 0) {
                                    errorMessage = "Please enter a valid amount greater than 0"
                                    return@Button
                                }

                                if (descriptionText.trim().isEmpty()) {
                                    errorMessage = "Please enter Notes / Details"
                                    return@Button
                                }

                                if (selectedMode == "CASH" && selectedPersonName.isBlank()) {
                                    errorMessage = "Please select a person for Cash in Hand"
                                    return@Button
                                }

                                val proposedTx = FundTransactionEntity(
                                    id = editingTransaction?.id ?: 0L,
                                    type = if (isIncoming) "INCOMING" else "EXPENDITURE",
                                    mode = selectedMode,
                                    amount = amount,
                                    description = descriptionText.trim(),
                                    personName = if (selectedMode == "CASH") selectedPersonName else "",
                                    date = selectedDateMillis,
                                    remoteId = editingTransaction?.remoteId ?: "",
                                    isEdited = editingTransaction?.isEdited ?: false,
                                    editHistory = editingTransaction?.editHistory ?: ""
                                )

                                val (allowed, reason) = onValidate(proposedTx)
                                if (!allowed) {
                                    errorMessage = reason
                                    return@Button
                                }

                                isSubmitting = true
                                onConfirm(
                                    selectedMode,
                                    if (selectedMode == "CASH") selectedPersonName else "",
                                    selectedDateMillis,
                                    amount,
                                    descriptionText.trim()
                                )
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isIncoming) Color(0xFF2E7D32) else Color(0xFFC62828)
                            )
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Add Person Dialog (Centered)
    if (showAddPersonDialog) {
        var newPersonInput by remember { mutableStateOf("") }
        var personError by remember { mutableStateOf("") }

        Dialog(
            onDismissRequest = { showAddPersonDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 400.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Add Person",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedTextField(
                            value = newPersonInput,
                            onValueChange = {
                                newPersonInput = it
                                personError = ""
                            },
                            label = { Text("Person Name *") },
                            placeholder = { Text("e.g. Rahul Shah") },
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                            singleLine = true,
                            isError = personError.isNotEmpty(),
                            modifier = Modifier.fillMaxWidth()
                        )
                        if (personError.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = personError,
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { showAddPersonDialog = false }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val name = newPersonInput.trim()
                                    if (name.isEmpty()) {
                                        personError = "Person name cannot be empty"
                                    } else {
                                        onAddPerson(name)
                                        selectedPersonName = name
                                        showAddPersonDialog = false
                                        Toast.makeText(context, "$name added", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ) {
                                Text("OK", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete Person Confirmation Dialog (Centered)
    if (personToDeleteConfirm != null) {
        Dialog(
            onDismissRequest = { personToDeleteConfirm = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .widthIn(max = 400.dp)
                        .fillMaxWidth(0.92f)
                        .wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp)
                    ) {
                        Text(
                            text = "Delete Person",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Are you sure you want to delete '$personToDeleteConfirm' from the cash persons list?",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextButton(onClick = { personToDeleteConfirm = null }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    val target = personToDeleteConfirm!!
                                    onDeletePerson(target)
                                    if (selectedPersonName.equals(target, ignoreCase = true)) {
                                        selectedPersonName = ""
                                    }
                                    Toast.makeText(context, "$target deleted", Toast.LENGTH_SHORT).show()
                                    personToDeleteConfirm = null
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.error
                                )
                            ) {
                                Text("Delete", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun TransferFundDialog(
    editingTransaction: FundTransactionEntity? = null,
    availablePersons: List<String>,
    totalBankFund: Double = 0.0,
    personCashBalances: Map<String, Double> = emptyMap(),
    onDismiss: () -> Unit,
    onValidate: (proposedTx: FundTransactionEntity) -> Pair<Boolean, String> = { Pair(true, "") },
    onConfirm: (from: String, to: String, dateMillis: Long, amount: Double, description: String) -> Unit
) {
    val context = LocalContext.current
    val currencyFormatter = remember {
        val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
        format.maximumFractionDigits = 0
        format
    }

    val allOptions = remember(availablePersons) {
        listOf("Bank") + availablePersons.filter { !it.equals("Bank", ignoreCase = true) }
    }

    var selectedFrom by remember {
        mutableStateOf(editingTransaction?.transferFrom.takeIf { !it.isNullOrBlank() } ?: "")
    }
    var selectedTo by remember {
        mutableStateOf(editingTransaction?.transferTo.takeIf { !it.isNullOrBlank() } ?: "")
    }
    val initialAmount = remember(editingTransaction) {
        editingTransaction?.amount?.let { if (it > 0) it.toLong().toString() else "" } ?: ""
    }
    var amountTextFieldValue by remember {
        mutableStateOf(
            TextFieldValue(
                text = initialAmount,
                selection = TextRange(initialAmount.length)
            )
        )
    }
    var descriptionText by remember {
        mutableStateOf(editingTransaction?.description ?: "")
    }
    var selectedDateMillis by remember {
        mutableStateOf(editingTransaction?.date ?: System.currentTimeMillis())
    }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSubmitting by remember { mutableStateOf(false) }

    val isEditing = editingTransaction != null

    val amountFocusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        amountFocusRequester.requestFocus()
        amountTextFieldValue = amountTextFieldValue.copy(
            selection = TextRange(amountTextFieldValue.text.length)
        )
    }

    val dateFormatter = remember { SimpleDateFormat("dd MMM yyyy", Locale.getDefault()) }

    val fromBalance = remember(selectedFrom, totalBankFund, personCashBalances) {
        if (selectedFrom.equals("Bank", ignoreCase = true)) {
            totalBankFund
        } else {
            personCashBalances.entries.find { it.key.equals(selectedFrom, ignoreCase = true) }?.value ?: 0.0
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFE3F2FD),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.CompareArrows,
                                contentDescription = null,
                                tint = Color(0xFF1565C0),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }
                    Text(
                        text = if (editingTransaction != null) "Edit Transfer Fund" else "Transfer Fund",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF1565C0)
                        )
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                if (errorMessage != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = errorMessage!!,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Transfer From
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transfer From *",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    if (selectedFrom.isNotBlank()) {
                        Text(
                            text = "Balance: ${currencyFormatter.format(fromBalance)}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (fromBalance < 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    allOptions.forEach { option ->
                        val isSelected = selectedFrom.equals(option, ignoreCase = true)
                        val isDisabled = selectedTo.equals(option, ignoreCase = true)
                        val optionBalance = if (option.equals("Bank", ignoreCase = true)) {
                            totalBankFund
                        } else {
                            personCashBalances.entries.find { it.key.equals(option, ignoreCase = true) }?.value ?: 0.0
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                isSelected -> MaterialTheme.colorScheme.primaryContainer
                                isDisabled || isEditing -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                else -> MaterialTheme.colorScheme.surface
                            },
                            border = BorderStroke(
                                1.dp,
                                when {
                                    isSelected -> MaterialTheme.colorScheme.primary
                                    isDisabled || isEditing -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                }
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(
                                    enabled = !isEditing && !isDisabled,
                                    onClick = {
                                        selectedFrom = option
                                        errorMessage = null
                                    }
                                )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(
                                    text = "$option (${currencyFormatter.format(optionBalance)})",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = when {
                                            isSelected -> MaterialTheme.colorScheme.onPrimaryContainer
                                            isDisabled || isEditing -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Transfer To
                val toBalance = remember(selectedTo, totalBankFund, personCashBalances) {
                    if (selectedTo.equals("Bank", ignoreCase = true)) {
                        totalBankFund
                    } else {
                        personCashBalances.entries.find { it.key.equals(selectedTo, ignoreCase = true) }?.value ?: 0.0
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Transfer To *",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    if (selectedTo.isNotBlank()) {
                        Text(
                            text = "Balance: ${currencyFormatter.format(toBalance)}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (toBalance < 0) Color(0xFFC62828) else Color(0xFF2E7D32)
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    allOptions.forEach { option ->
                        val isSelected = selectedTo.equals(option, ignoreCase = true)
                        val isDisabled = selectedFrom.equals(option, ignoreCase = true)
                        val optionBalance = if (option.equals("Bank", ignoreCase = true)) {
                            totalBankFund
                        } else {
                            personCashBalances.entries.find { it.key.equals(option, ignoreCase = true) }?.value ?: 0.0
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = when {
                                isSelected -> MaterialTheme.colorScheme.primaryContainer
                                isDisabled || isEditing -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                else -> MaterialTheme.colorScheme.surface
                            },
                            border = BorderStroke(
                                1.dp,
                                when {
                                    isSelected -> MaterialTheme.colorScheme.primary
                                    isDisabled || isEditing -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f)
                                    else -> MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                }
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable(
                                    enabled = !isEditing && !isDisabled,
                                    onClick = {
                                        selectedTo = option
                                        errorMessage = null
                                    }
                                )
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text(
                                    text = "$option (${currencyFormatter.format(optionBalance)})",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp,
                                        color = when {
                                            isSelected -> MaterialTheme.colorScheme.onPrimaryContainer
                                            isDisabled || isEditing -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                                            else -> MaterialTheme.colorScheme.onSurface
                                        }
                                    )
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date
                Text(
                    text = "Date",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                val calendar = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                val datePickerDialog = DatePickerDialog(
                    context,
                    { _, year, month, dayOfMonth ->
                        val newCal = Calendar.getInstance()
                        newCal.set(year, month, dayOfMonth)
                        selectedDateMillis = newCal.timeInMillis
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
                )

                val isEditing = editingTransaction != null
                OutlinedCard(
                    onClick = {
                        if (!isEditing) {
                            datePickerDialog.show()
                        }
                    },
                    enabled = !isEditing,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = dateFormatter.format(Date(selectedDateMillis)),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = if (isEditing) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Icon(
                            imageVector = Icons.Default.CalendarToday,
                            contentDescription = "Select Date",
                            tint = if (isEditing) Color.Gray else Color(0xFF1565C0),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Amount
                Text(
                    text = "Amount",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = amountTextFieldValue,
                    onValueChange = { newValue ->
                        val filteredText = newValue.text.filter { char -> char.isDigit() }
                        val diff = newValue.text.length - filteredText.length
                        val newSelection = if (diff == 0) {
                            newValue.selection
                        } else {
                            TextRange(filteredText.length)
                        }
                        amountTextFieldValue = TextFieldValue(
                            text = filteredText,
                            selection = newSelection
                        )
                    },
                    placeholder = { Text("0") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    prefix = { Text("₹ ", fontWeight = FontWeight.Bold) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(amountFocusRequester),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF1565C0),
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Description / Note
                Text(
                    text = "Note / Description",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedTextField(
                    value = descriptionText,
                    onValueChange = { descriptionText = it },
                    placeholder = { Text("Enter note") },
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        enabled = !isSubmitting,
                        onClick = {
                            if (isSubmitting) return@Button
                            if (selectedFrom.isBlank()) {
                                errorMessage = "Please select Transfer From"
                                return@Button
                            }
                            if (selectedTo.isBlank()) {
                                errorMessage = "Please select Transfer To"
                                return@Button
                            }
                            if (selectedFrom.equals(selectedTo, ignoreCase = true)) {
                                errorMessage = "Transfer From and Transfer To cannot be the same"
                                return@Button
                            }
                            val amount = amountTextFieldValue.text.toDoubleOrNull()
                            if (amount == null || amount <= 0) {
                                errorMessage = "Please enter a valid amount greater than 0"
                                return@Button
                            }

                            val proposedTx = FundTransactionEntity(
                                id = editingTransaction?.id ?: 0L,
                                type = "TRANSFER",
                                mode = if (selectedFrom.equals("Bank", ignoreCase = true)) "BANK" else "CASH",
                                amount = amount,
                                description = descriptionText.trim(),
                                personName = if (!selectedFrom.equals("Bank", ignoreCase = true)) selectedFrom else "",
                                date = selectedDateMillis,
                                transferFrom = selectedFrom,
                                transferTo = selectedTo,
                                remoteId = editingTransaction?.remoteId ?: "",
                                isEdited = editingTransaction?.isEdited ?: false,
                                editHistory = editingTransaction?.editHistory ?: ""
                            )

                            val (allowed, reason) = onValidate(proposedTx)
                            if (!allowed) {
                                errorMessage = reason
                                return@Button
                            }

                            isSubmitting = true
                            onConfirm(selectedFrom, selectedTo, selectedDateMillis, amount, descriptionText)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1976D2),
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text("Transfer", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TransactionHistoryScreen(
    currentYear: Int,
    yearlyHistoryGrouped: Map<Int, List<FundTransactionEntity>>,
    selectedHistoryYear: Int?,
    onSelectYear: (Int) -> Unit,
    onBackToSummaries: () -> Unit,
    onDismiss: () -> Unit,
    currencyFormatter: NumberFormat,
    isOnline: Boolean,
    context: android.content.Context,
    onLongClickTransaction: (FundTransactionEntity) -> Unit,
    historyFilterTab: String,
    onHistoryFilterTabChange: (String) -> Unit
) {

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount ->
                    if (dragAmount > 35f) { // Swipe right to dismiss or go back
                        if (selectedHistoryYear != null) {
                            onBackToSummaries()
                        } else {
                            onDismiss()
                        }
                    }
                }
            }
    ) {
        AnimatedContent(
            targetState = selectedHistoryYear,
            transitionSpec = {
                if (targetState != null) {
                    slideInHorizontally { width -> width } + fadeIn() togetherWith
                            slideOutHorizontally { width -> -width } + fadeOut()
                } else {
                    slideInHorizontally { width -> -width } + fadeIn() togetherWith
                            slideOutHorizontally { width -> width } + fadeOut()
                }
            },
            label = "HistoryYearTransition"
        ) { activeYear ->
            if (activeYear == null) {
                // Display Yearly Summarized Cards
                if (yearlyHistoryGrouped.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(28.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Folder,
                                    contentDescription = null,
                                    modifier = Modifier.size(52.dp),
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "No Past Years History Yet",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Currently in Year $currentYear. When the calendar year changes, past transactions will automatically be archived into compact summarized yearly cards here.",
                                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Tap any yearly summarized card below to view all detailed transaction cards for that year.",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            fontSize = 12.sp
                                        )
                                    )
                                }
                            }
                        }

                        items(
                            items = yearlyHistoryGrouped.keys.toList(),
                            key = { it }
                        ) { year ->
                            val yrTxList = yearlyHistoryGrouped[year] ?: emptyList()
                            YearlySummarizedCard(
                                year = year,
                                transactions = yrTxList,
                                currencyFormatter = currencyFormatter,
                                onClick = { onSelectYear(year) }
                            )
                        }
                    }
                }
            } else {
                // Display detailed transaction cards for selected history year
                val yearTxList = yearlyHistoryGrouped[activeYear] ?: emptyList()

                val availableHistoryPersons = remember(yearTxList) {
                    yearTxList.map { it.personName }.filter { it.isNotBlank() }.distinct()
                }

                val filteredHistoryTx = remember(yearTxList, historyFilterTab) {
                    when {
                        historyFilterTab.equals("All", ignoreCase = true) -> yearTxList
                        historyFilterTab.equals("Bank", ignoreCase = true) -> yearTxList.filter {
                            (it.mode == "BANK" && it.type != "TRANSFER") ||
                            (it.type == "TRANSFER" && (it.transferFrom.equals("Bank", ignoreCase = true) || it.transferTo.equals("Bank", ignoreCase = true)))
                        }
                        historyFilterTab.equals("Incoming", ignoreCase = true) -> yearTxList.filter {
                            it.type == "INCOMING"
                        }
                        historyFilterTab.equals("Expenditure", ignoreCase = true) -> yearTxList.filter {
                            it.type == "EXPENDITURE"
                        }
                        else -> yearTxList.filter {
                            (it.mode == "CASH" && it.personName.equals(historyFilterTab, ignoreCase = true) && it.type != "TRANSFER") ||
                            (it.type == "TRANSFER" && (it.transferFrom.equals(historyFilterTab, ignoreCase = true) || it.transferTo.equals(historyFilterTab, ignoreCase = true)))
                        }
                    }
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    item {
                        // Filter menu for the selected year
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Filtered By",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            )

                            var showHistoryFilterMenu by remember { mutableStateOf(false) }
                            val filterOptions = remember(availableHistoryPersons) {
                                listOf("All", "Bank", "Incoming", "Expenditure") + availableHistoryPersons
                            }

                            Box {
                                FilterChip(
                                    selected = !historyFilterTab.equals("All", ignoreCase = true),
                                    onClick = { showHistoryFilterMenu = true },
                                    label = {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.FilterList,
                                                contentDescription = "Filter",
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Text(
                                                text = historyFilterTab,
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    fontWeight = FontWeight.SemiBold,
                                                    fontSize = 12.sp
                                                )
                                            )
                                        }
                                    },
                                    modifier = Modifier.height(32.dp)
                                )

                                DropdownMenu(
                                    expanded = showHistoryFilterMenu,
                                    onDismissRequest = { showHistoryFilterMenu = false }
                                ) {
                                    filterOptions.forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Text(
                                                    text = option,
                                                    fontWeight = if (historyFilterTab.equals(option, ignoreCase = true)) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (historyFilterTab.equals(option, ignoreCase = true)) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                                )
                                            },
                                            onClick = {
                                                onHistoryFilterTabChange(option)
                                                showHistoryFilterMenu = false
                                            },
                                            leadingIcon = if (historyFilterTab.equals(option, ignoreCase = true)) {
                                                {
                                                    Icon(
                                                        imageVector = Icons.Default.Check,
                                                        contentDescription = null,
                                                        tint = MaterialTheme.colorScheme.primary,
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            } else null
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (filteredHistoryTx.isEmpty()) {
                        item {
                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 12.dp)
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(32.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ReceiptLong,
                                        contentDescription = null,
                                        modifier = Modifier.size(44.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "No transactions found for '$historyFilterTab' in year $activeYear",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    } else {
                        items(
                            items = filteredHistoryTx,
                            key = { it.id }
                        ) { transaction ->
                            FundTransactionItemCard(
                                transaction = transaction,
                                currencyFormatter = currencyFormatter,
                                isOnline = isOnline,
                                onTransactionClick = {},
                                onLongClick = { onLongClickTransaction(transaction) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun YearlySummarizedCard(
    year: Int,
    transactions: List<FundTransactionEntity>,
    currencyFormatter: NumberFormat,
    onClick: () -> Unit
) {
    val totalIncoming = remember(transactions) {
        transactions.filter { it.type == "INCOMING" }.sumOf { it.amount }
    }
    val totalExpenditure = remember(transactions) {
        transactions.filter { it.type == "EXPENDITURE" }.sumOf { it.amount }
    }
    val netFlow = totalIncoming - totalExpenditure

    val bankNet = remember(transactions) {
        val bankIncoming = transactions.filter { it.mode == "BANK" && it.type == "INCOMING" }.sumOf { it.amount }
        val bankExpenditure = transactions.filter { it.mode == "BANK" && it.type == "EXPENDITURE" }.sumOf { it.amount }
        val bankTransferIn = transactions.filter { it.type == "TRANSFER" && it.transferTo.equals("Bank", ignoreCase = true) }.sumOf { it.amount }
        val bankTransferOut = transactions.filter { it.type == "TRANSFER" && it.transferFrom.equals("Bank", ignoreCase = true) }.sumOf { it.amount }
        (bankIncoming + bankTransferIn) - (bankExpenditure + bankTransferOut)
    }

    val cashNet = remember(transactions) {
        val cashIncoming = transactions.filter { it.mode == "CASH" && it.type == "INCOMING" }.sumOf { it.amount }
        val cashExpenditure = transactions.filter { it.mode == "CASH" && it.type == "EXPENDITURE" }.sumOf { it.amount }
        val cashTransferIn = transactions.filter { it.type == "TRANSFER" && !it.transferTo.equals("Bank", ignoreCase = true) && it.transferTo.isNotBlank() }.sumOf { it.amount }
        val cashTransferOut = transactions.filter { it.type == "TRANSFER" && !it.transferFrom.equals("Bank", ignoreCase = true) && it.transferFrom.isNotBlank() }.sumOf { it.amount }
        (cashIncoming + cashTransferIn) - (cashExpenditure + cashTransferOut)
    }

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("yearly_summary_card_$year")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row: Year Title + Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CalendarToday,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Year $year Summary",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                        Text(
                            text = "01/01/$year – 31/12/$year",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = MaterialTheme.colorScheme.secondaryContainer
                ) {
                    Text(
                        text = "${transactions.size} Txns",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        ),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            HorizontalDivider(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
            )

            // 3-Column Key Financial Highlights
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Incoming
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Total Incoming",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "+${currencyFormatter.format(totalIncoming)}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32)
                        )
                    )
                }

                // Expenditure
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Total Expenditure",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "-${currencyFormatter.format(totalExpenditure)}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFC62828)
                        )
                    )
                }

                // Net Annual Flow
                Column(horizontalAlignment = Alignment.Start) {
                    Text(
                        text = "Net Flow",
                        style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = currencyFormatter.format(netFlow),
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = if (netFlow >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Mode Breakdown pill
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Bank Net: ${currencyFormatter.format(bankNet)}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    Text(
                        text = "|",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.outlineVariant)
                    )
                    Text(
                        text = "Cash Net: ${currencyFormatter.format(cashNet)}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // CTA Footer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Tap to view all transactions of $year",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun FundTransactionActionDialog(
    transaction: FundTransactionEntity,
    currencyFormatter: NumberFormat,
    isOnline: Boolean,
    onDismiss: () -> Unit,
    onEditTransaction: () -> Unit,
    onDeleteTransaction: () -> Unit
) {
    var animateIn by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        animateIn = true
    }

    val offsetY by animateFloatAsState(
        targetValue = if (animateIn) 0f else 220f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetY"
    )

    val offsetX by animateFloatAsState(
        targetValue = if (animateIn) 0f else -75f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardOffsetX"
    )

    val animRotation by animateFloatAsState(
        targetValue = if (animateIn) 0f else -5f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardRotation"
    )

    val animScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.8f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioHighBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "cardScale"
    )

    val animAlpha by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0f,
        animationSpec = spring(
            stiffness = Spring.StiffnessHigh
        ),
        label = "cardAlpha"
    )

    val optionsScale by animateFloatAsState(
        targetValue = if (animateIn) 1.0f else 0.4f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        ),
        label = "optionsScale"
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
                .clickable { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .graphicsLayer {
                        translationX = offsetX * density
                        translationY = offsetY * density
                        rotationZ = animRotation
                        scaleX = animScale
                        scaleY = animScale
                        this.alpha = animAlpha
                    }
                    .clickable(enabled = false) {},
                horizontalAlignment = Alignment.End
            ) {
                // Centered Preview Card
                FundTransactionItemCard(
                    transaction = transaction,
                    currencyFormatter = currencyFormatter,
                    isOnline = isOnline,
                    onTransactionClick = {},
                    onLongClick = {}
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Options Container anchored at right bottom of card
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 12.dp,
                    modifier = Modifier
                        .width(210.dp)
                        .graphicsLayer {
                            scaleX = optionsScale
                            scaleY = optionsScale
                            transformOrigin = TransformOrigin(1f, 0f)
                        }
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Option 1: Edit Transaction
                        Surface(
                            onClick = onEditTransaction,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Edit,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "1. Edit Transaction",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }

                        // Option 2: Delete Transaction
                        Surface(
                            onClick = onDeleteTransaction,
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "2. Delete Transaction",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onErrorContainer,
                                        fontSize = 13.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SyncStatusIcon(
    syncState: SyncState,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val (iconColor, contentDesc) = when (syncState) {
        SyncState.CONNECTED -> Pair(Color(0xFF2E7D32), "Real-time sync active")
        SyncState.SYNCING -> Pair(Color(0xFF1565C0), "Syncing")
        SyncState.OFFLINE -> Pair(Color(0xFFC62828), "Offline")
    }

    IconButton(
        onClick = onClick,
        modifier = modifier.testTag("sync_status_icon")
    ) {
        when (syncState) {
            SyncState.CONNECTED -> {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = contentDesc,
                    tint = iconColor,
                    modifier = Modifier.size(28.dp)
                )
            }
            SyncState.SYNCING -> {
                val infiniteTransition = rememberInfiniteTransition(label = "SyncSpin")
                val rotation by infiniteTransition.animateFloat(
                    initialValue = 0f,
                    targetValue = 360f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Restart
                    ),
                    label = "Rotation"
                )
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = contentDesc,
                    tint = iconColor,
                    modifier = Modifier
                        .size(28.dp)
                        .graphicsLayer { rotationZ = rotation }
                )
            }
            SyncState.OFFLINE -> {
                Icon(
                    imageVector = Icons.Default.SyncDisabled,
                    contentDescription = contentDesc,
                    tint = iconColor,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}
