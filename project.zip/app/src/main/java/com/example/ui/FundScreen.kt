package com.example.ui

import android.app.DatePickerDialog
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.FundHolderEntity
import com.example.data.FundTransactionEntity
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FundScreen(
    viewModel: FormViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val fundHolders by viewModel.allFundHolders.collectAsState()
    val fundTransactions by viewModel.allFundTransactions.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    
    // Dialog states
    var showAddTransactionDialog by remember { mutableStateOf(false) }
    var preselectedHolderId by remember { mutableLongStateOf(0L) }
    var preselectedTxType by remember { mutableStateOf("INCOME") }

    var showAddHolderDialog by remember { mutableStateOf(false) }
    var showDeleteHolderConfirm by remember { mutableStateOf<FundHolderEntity?>(null) }
    var showDeleteTxConfirm by remember { mutableStateOf<FundTransactionEntity?>(null) }

    // Ensure at least Bank Holder exists
    LaunchedEffect(fundHolders) {
        if (fundHolders.none { it.type == "BANK" }) {
            viewModel.insertFundHolder(
                FundHolderEntity(
                    name = "Primary Bank Account",
                    type = "BANK",
                    notes = "Official Sangh Bank Account"
                )
            )
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "फंड प्रबंधन (Fund Management)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Text(
                            text = "बैंक फंड्स एवं कैश प्रबंधन",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "वापस जाएं"
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.refreshCloudData() }) {
                        Icon(
                            imageVector = Icons.Default.Sync,
                            contentDescription = "रिफ्रेश करें"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    preselectedHolderId = fundHolders.firstOrNull()?.id ?: 1L
                    preselectedTxType = "INCOME"
                    showAddTransactionDialog = true
                },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("फंड / खर्च दर्ज करें", fontWeight = FontWeight.Bold) },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 12.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("📊 ओवरव्यू") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("🏦 बैंक व नकद व्यक्ति") }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("📅 मासिक रोल-अप") }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("📆 वार्षिक रोल-अप") }
                )
                Tab(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    text = { Text("📝 लेन-देन सूची") }
                )
            }

            // Tab Content
            when (selectedTab) {
                0 -> FundDashboardTab(
                    holders = fundHolders,
                    transactions = fundTransactions,
                    onAddTransaction = { holderId, txType ->
                        preselectedHolderId = holderId
                        preselectedTxType = txType
                        showAddTransactionDialog = true
                    },
                    onAddHolder = { showAddHolderDialog = true }
                )
                1 -> BankAndPersonsTab(
                    holders = fundHolders,
                    transactions = fundTransactions,
                    onAddTransaction = { holderId, txType ->
                        preselectedHolderId = holderId
                        preselectedTxType = txType
                        showAddTransactionDialog = true
                    },
                    onAddHolder = { showAddHolderDialog = true },
                    onDeleteHolder = { holder -> showDeleteHolderConfirm = holder }
                )
                2 -> MonthlyRollupTab(
                    holders = fundHolders,
                    transactions = fundTransactions
                )
                3 -> YearlyRollupTab(
                    holders = fundHolders,
                    transactions = fundTransactions
                )
                4 -> TransactionsLogTab(
                    holders = fundHolders,
                    transactions = fundTransactions,
                    onDeleteTransaction = { tx -> showDeleteTxConfirm = tx }
                )
            }
        }
    }

    // Add Transaction Dialog
    if (showAddTransactionDialog) {
        AddTransactionDialog(
            holders = fundHolders,
            initialHolderId = preselectedHolderId,
            initialTxType = preselectedTxType,
            onDismiss = { showAddTransactionDialog = false },
            onSave = { transaction ->
                viewModel.insertFundTransaction(transaction)
                showAddTransactionDialog = false
            }
        )
    }

    // Add Cash Person / Holder Dialog
    if (showAddHolderDialog) {
        AddHolderDialog(
            onDismiss = { showAddHolderDialog = false },
            onSave = { holder ->
                viewModel.insertFundHolder(holder)
                showAddHolderDialog = false
            }
        )
    }

    // Delete Holder Confirm Dialog
    showDeleteHolderConfirm?.let { holder ->
        AlertDialog(
            onDismissRequest = { showDeleteHolderConfirm = null },
            title = { Text("व्यक्ति/खाता हटाएं") },
            text = { Text("'${holder.name}' और उससे जुड़े रिकॉर्ड हटाना चाहते हैं?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteFundHolder(holder)
                        showDeleteHolderConfirm = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("हटाएं")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteHolderConfirm = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }

    // Delete Transaction Confirm Dialog
    showDeleteTxConfirm?.let { tx ->
        AlertDialog(
            onDismissRequest = { showDeleteTxConfirm = null },
            title = { Text("लेन-देन हटाएं") },
            text = { Text("क्या आप ₹${formatCurrency(tx.amount)} का लेन-देन रिकॉर्ड हटाना चाहते हैं?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteFundTransaction(tx.id)
                        showDeleteTxConfirm = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("हटाएं")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteTxConfirm = null }) {
                    Text("रद्द करें")
                }
            }
        )
    }
}

// ==========================================
// TAB 0: DASHBOARD / OVERVIEW
// ==========================================
@Composable
private fun FundDashboardTab(
    holders: List<FundHolderEntity>,
    transactions: List<FundTransactionEntity>,
    onAddTransaction: (Long, String) -> Unit,
    onAddHolder: () -> Unit
) {
    val bankHolders = holders.filter { it.type == "BANK" }
    val bankHolderIds = bankHolders.map { it.id }.toSet()
    val cashHolders = holders.filter { it.type == "CASH" }
    val cashHolderIds = cashHolders.map { it.id }.toSet()

    val bankIn = transactions.filter { it.holderId in bankHolderIds && it.type == "INCOME" }.sumOf { it.amount }
    val bankOut = transactions.filter { it.holderId in bankHolderIds && it.type == "EXPENSE" }.sumOf { it.amount }
    val bankBalance = bankIn - bankOut

    val cashIn = transactions.filter { it.holderId in cashHolderIds && it.type == "INCOME" }.sumOf { it.amount }
    val cashOut = transactions.filter { it.holderId in cashHolderIds && it.type == "EXPENSE" }.sumOf { it.amount }
    val cashBalance = cashIn - cashOut

    val totalNetFunds = bankBalance + cashBalance

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Overall Funds Summary Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = "कुल शुद्ध कोष (Total Available Net Balance)",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            )
                            Text(
                                text = "₹ ${formatCurrency(totalNetFunds)}",
                                style = MaterialTheme.typography.headlineLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            )
                        }
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .padding(12.dp)
                                    .fillMaxSize()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f))
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("बैंक बैलेंस", style = MaterialTheme.typography.labelMedium)
                            }
                            Text(
                                text = "₹ ${formatCurrency(bankBalance)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "आवक: ₹${formatCurrency(bankIn)} | जावक: ₹${formatCurrency(bankOut)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)),
                                fontSize = 11.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Money,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("कैश इन हैंड", style = MaterialTheme.typography.labelMedium)
                            }
                            Text(
                                text = "₹ ${formatCurrency(cashBalance)}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "आवक: ₹${formatCurrency(cashIn)} | जावक: ₹${formatCurrency(cashOut)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }

        // Quick Action Row Buttons
        item {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        val defaultBankId = bankHolders.firstOrNull()?.id ?: 1L
                        onAddTransaction(defaultBankId, "INCOME")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2E7D32)
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.TrendingUp, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("+ आवक दर्ज करें", style = MaterialTheme.typography.labelLarge)
                }

                Button(
                    onClick = {
                        val defaultBankId = bankHolders.firstOrNull()?.id ?: 1L
                        onAddTransaction(defaultBankId, "EXPENSE")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.TrendingDown, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("- खर्च दर्ज करें", style = MaterialTheme.typography.labelLarge)
                }
            }
        }

        // Bank Funds Component
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AccountBalance,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "बैंक फंड्स (Bank Funds)",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primaryContainer
                        ) {
                            Text(
                                text = "₹ ${formatCurrency(bankBalance)}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("कुल आवक (Incoming)", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                            Text("₹ ${formatCurrency(bankIn)}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32)))
                        }
                        Column {
                            Text("कुल जावक/खर्च (Outgoing)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            Text("₹ ${formatCurrency(bankOut)}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                val bankId = bankHolders.firstOrNull()?.id ?: 1L
                                onAddTransaction(bankId, "INCOME")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+ बैंक जमा", color = Color(0xFF2E7D32))
                        }

                        OutlinedButton(
                            onClick = {
                                val bankId = bankHolders.firstOrNull()?.id ?: 1L
                                onAddTransaction(bankId, "EXPENSE")
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("- बैंक खर्च", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }

        // Cash in Hand Component
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Money,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "कैश इन हैंड व्यक्ति (Cash Holders)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                TextButton(onClick = onAddHolder) {
                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("+ व्यक्ति जोड़ें")
                }
            }
        }

        if (cashHolders.isEmpty()) {
            item {
                OutlinedCard(
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.PersonSearch, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "अभी तक कोई नकद व्यक्ति नहीं जोड़ा गया है",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.outline)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = onAddHolder, shape = RoundedCornerShape(8.dp)) {
                            Text("+ नकद धारक व्यक्ति जोड़ें")
                        }
                    }
                }
            }
        } else {
            items(cashHolders) { holder ->
                val hIn = transactions.filter { it.holderId == holder.id && it.type == "INCOME" }.sumOf { it.amount }
                val hOut = transactions.filter { it.holderId == holder.id && it.type == "EXPENSE" }.sumOf { it.amount }
                val hBal = hIn - hOut

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.secondaryContainer,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = holder.name,
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                    if (holder.notes.isNotBlank()) {
                                        Text(
                                            text = holder.notes,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("शेष नकद", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "₹ ${formatCurrency(hBal)}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (hBal >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("आवक: ₹${formatCurrency(hIn)}", style = MaterialTheme.typography.labelMedium, color = Color(0xFF2E7D32))
                            Text("खर्च: ₹${formatCurrency(hOut)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onAddTransaction(holder.id, "INCOME") },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                            ) {
                                Text("+ नकद प्राप्त", fontSize = 12.sp, color = Color(0xFF2E7D32))
                            }

                            OutlinedButton(
                                onClick = { onAddTransaction(holder.id, "EXPENSE") },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 8.dp)
                            ) {
                                Text("- खर्च / भुगतान", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 1: BANK & CASH HOLDERS MANAGEMENT
// ==========================================
@Composable
private fun BankAndPersonsTab(
    holders: List<FundHolderEntity>,
    transactions: List<FundTransactionEntity>,
    onAddTransaction: (Long, String) -> Unit,
    onAddHolder: () -> Unit,
    onDeleteHolder: (FundHolderEntity) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "खाते एवं नकद धारक सूची",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Button(onClick = onAddHolder, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("नया व्यक्ति जोड़ें")
                }
            }
        }

        items(holders) { holder ->
            val hTxs = transactions.filter { it.holderId == holder.id }
            val hIn = hTxs.filter { it.type == "INCOME" }.sumOf { it.amount }
            val hOut = hTxs.filter { it.type == "EXPENSE" }.sumOf { it.amount }
            val hBal = hIn - hOut

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = if (holder.type == "BANK") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Icon(
                                    imageVector = if (holder.type == "BANK") Icons.Default.AccountBalance else Icons.Default.Person,
                                    contentDescription = null,
                                    tint = if (holder.type == "BANK") MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSecondaryContainer,
                                    modifier = Modifier.padding(10.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = holder.name,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (holder.type == "BANK") "बैंक खाता" else "नकद धारक",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        if (holder.type == "CASH") {
                            IconButton(onClick = { onDeleteHolder(holder) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "हटाएं", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("कुल आवक", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                            Text("₹ ${formatCurrency(hIn)}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32)))
                        }
                        Column {
                            Text("कुल खर्च", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            Text("₹ ${formatCurrency(hOut)}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("शुद्ध शेष", style = MaterialTheme.typography.bodySmall)
                            Text(
                                text = "₹ ${formatCurrency(hBal)}",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { onAddTransaction(holder.id, "INCOME") },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("+ आवक", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { onAddTransaction(holder.id, "EXPENSE") },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("- खर्च", fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 2: MONTHLY ROLL-UP FEATURE
// ==========================================
@Composable
private fun MonthlyRollupTab(
    holders: List<FundHolderEntity>,
    transactions: List<FundTransactionEntity>
) {
    val holderMap = remember(holders) { holders.associateBy { it.id } }

    // Available Year-Months in dataset or current year
    val currentYearMonth = remember { SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(Date()) }
    val allYearMonths = remember(transactions) {
        val set = transactions.mapNotNull {
            try {
                if (it.date.length >= 7) it.date.substring(0, 7) else null
            } catch (e: Exception) { null }
        }.toMutableSet()
        set.add(currentYearMonth)
        set.sortedDescending()
    }

    var selectedYearMonth by remember { mutableStateOf(if (allYearMonths.contains(currentYearMonth)) currentYearMonth else allYearMonths.firstOrNull() ?: currentYearMonth) }

    val monthlyTxs = remember(transactions, selectedYearMonth) {
        transactions.filter { it.date.startsWith(selectedYearMonth) }
    }

    val monthIn = monthlyTxs.filter { it.type == "INCOME" }.sumOf { it.amount }
    val monthOut = monthlyTxs.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val monthNet = monthIn - monthOut

    // Category breakdown
    val categoryBreakdown = remember(monthlyTxs) {
        monthlyTxs.groupBy { it.category.ifBlank { "सामान्य" } }
            .mapValues { entry ->
                val inAmt = entry.value.filter { it.type == "INCOME" }.sumOf { it.amount }
                val outAmt = entry.value.filter { it.type == "EXPENSE" }.sumOf { it.amount }
                Pair(inAmt, outAmt)
            }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Month Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "माह चुनें (Select Month for Monthly Roll-up):",
                        style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    ScrollableTabRow(
                        selectedTabIndex = allYearMonths.indexOf(selectedYearMonth).coerceAtLeast(0),
                        edgePadding = 0.dp,
                        containerColor = Color.Transparent
                    ) {
                        allYearMonths.forEach { ym ->
                            val label = formatYearMonthLabel(ym)
                            Tab(
                                selected = selectedYearMonth == ym,
                                onClick = { selectedYearMonth = ym },
                                text = { Text(label, fontWeight = if (selectedYearMonth == ym) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }
                    }
                }
            }
        }

        // Condensed Monthly Roll-up Summary Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "${formatYearMonthLabel(selectedYearMonth)} - मासिक सारांश (Monthly Roll-Up)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("कुल मासिक आवक", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32))
                            Text("₹ ${formatCurrency(monthIn)}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32)))
                        }

                        Column {
                            Text("कुल मासिक खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            Text("₹ ${formatCurrency(monthOut)}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("मासिक शुद्ध लाभ/शेष", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                text = "₹ ${formatCurrency(monthNet)}",
                                style = MaterialTheme.typography.titleLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (monthNet >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }
                }
            }
        }

        // Category breakdown card
        if (categoryBreakdown.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "कैटेगरी अनुसार वर्गीकरण (Category Summary)",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        categoryBreakdown.forEach { (cat, pair) ->
                            val (catIn, catOut) = pair
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(cat, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    if (catIn > 0) {
                                        Text("+₹${formatCurrency(catIn)}", style = MaterialTheme.typography.labelMedium, color = Color(0xFF2E7D32))
                                    }
                                    if (catOut > 0) {
                                        Text("-₹${formatCurrency(catOut)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant)
                        }
                    }
                }
            }
        }

        // Transactions list for selected month
        item {
            Text(
                text = "इस माह के लेन-देन विवरण (${monthlyTxs.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (monthlyTxs.isEmpty()) {
            item {
                Text(
                    text = "इस महीने में कोई लेन-देन दर्ज नहीं है।",
                    style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    modifier = Modifier.padding(16.dp)
                )
            }
        } else {
            items(monthlyTxs.sortedByDescending { it.date }) { tx ->
                TransactionItemRow(tx = tx, holderName = holderMap[tx.holderId]?.name ?: "अज्ञात")
            }
        }
    }
}

// ==========================================
// TAB 3: YEARLY ROLL-UP FEATURE
// ==========================================
@Composable
private fun YearlyRollupTab(
    holders: List<FundHolderEntity>,
    transactions: List<FundTransactionEntity>
) {
    val currentYear = remember { SimpleDateFormat("yyyy", Locale.getDefault()).format(Date()) }
    val allYears = remember(transactions) {
        val set = transactions.mapNotNull {
            try {
                if (it.date.length >= 4) it.date.substring(0, 4) else null
            } catch (e: Exception) { null }
        }.toMutableSet()
        set.add(currentYear)
        set.sortedDescending()
    }

    var selectedYear by remember { mutableStateOf(if (allYears.contains(currentYear)) currentYear else allYears.firstOrNull() ?: currentYear) }

    val yearlyTxs = remember(transactions, selectedYear) {
        transactions.filter { it.date.startsWith(selectedYear) }
    }

    val yearIn = yearlyTxs.filter { it.type == "INCOME" }.sumOf { it.amount }
    val yearOut = yearlyTxs.filter { it.type == "EXPENSE" }.sumOf { it.amount }
    val yearNet = yearIn - yearOut

    // Month-by-Month Roll-up for selected year (01 to 12)
    val monthNames = listOf("जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितम्बर", "अक्टूबर", "नवम्बर", "दिसम्बर")
    val monthRollupList = remember(yearlyTxs, selectedYear) {
        (1..12).map { monthNum ->
            val monthStr = String.format("%02d", monthNum)
            val ym = "$selectedYear-$monthStr"
            val mTxs = yearlyTxs.filter { it.date.startsWith(ym) }
            val mIn = mTxs.filter { it.type == "INCOME" }.sumOf { it.amount }
            val mOut = mTxs.filter { it.type == "EXPENSE" }.sumOf { it.amount }
            Triple(monthNames[monthNum - 1], mIn, mOut)
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Year Selector
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.padding(16.dp).fillMaxWidth()
                ) {
                    Text(
                        text = "वर्ष चुनें (Select Year):",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        allYears.forEach { yr ->
                            FilterChip(
                                selected = selectedYear == yr,
                                onClick = { selectedYear = yr },
                                label = { Text(yr, fontWeight = FontWeight.Bold) }
                            )
                        }
                    }
                }
            }
        }

        // Annual Total Roll-up Summary Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "वर्ष $selectedYear - वार्षिक रोल-अप सारांश (Annual Transaction Total)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("वार्षिक कुल आवक", style = MaterialTheme.typography.labelSmall, color = Color(0xFF2E7D32))
                            Text("₹ ${formatCurrency(yearIn)}", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32)))
                        }

                        Column {
                            Text("वार्षिक कुल खर्च", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                            Text("₹ ${formatCurrency(yearOut)}", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error))
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("वार्षिक शुद्ध शेष", style = MaterialTheme.typography.labelSmall)
                            Text(
                                text = "₹ ${formatCurrency(yearNet)}",
                                style = MaterialTheme.typography.headlineSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (yearNet >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                )
                            )
                        }
                    }
                }
            }
        }

        // Month by Month Rollup Breakdown
        item {
            Text(
                text = "माह-दर-माह समेकित विवरण (Month-by-Month Roll-up)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(monthRollupList) { (mName, mIn, mOut) ->
            val mNet = mIn - mOut
            val hasData = mIn > 0 || mOut > 0

            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (hasData) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = mName,
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (hasData) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                            )
                        )
                    }

                    if (hasData) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(horizontalAlignment = Alignment.End) {
                                Text("आवक: ₹${formatCurrency(mIn)}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                                Text("खर्च: ₹${formatCurrency(mOut)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("मासिक शेष", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                Text(
                                    text = "₹${formatCurrency(mNet)}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (mNet >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                )
                            }
                        }
                    } else {
                        Text("कोई लेन-देन नहीं", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                    }
                }
            }
        }
    }
}

// ==========================================
// TAB 4: TRANSACTIONS LOG & FILTERING
// ==========================================
@Composable
private fun TransactionsLogTab(
    holders: List<FundHolderEntity>,
    transactions: List<FundTransactionEntity>,
    onDeleteTransaction: (FundTransactionEntity) -> Unit
) {
    val holderMap = remember(holders) { holders.associateBy { it.id } }
    var filterType by remember { mutableStateOf("ALL") } // ALL, INCOME, EXPENSE
    var filterHolderId by remember { mutableLongStateOf(0L) } // 0 = All

    val filteredList = remember(transactions, filterType, filterHolderId) {
        transactions.filter { tx ->
            val matchType = when (filterType) {
                "INCOME" -> tx.type == "INCOME"
                "EXPENSE" -> tx.type == "EXPENSE"
                else -> true
            }
            val matchHolder = if (filterHolderId != 0L) tx.holderId == filterHolderId else true
            matchType && matchHolder
        }.sortedByDescending { it.date }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("फ़िल्टर लागू करें:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = filterType == "ALL",
                            onClick = { filterType = "ALL" },
                            label = { Text("सभी") }
                        )
                        FilterChip(
                            selected = filterType == "INCOME",
                            onClick = { filterType = "INCOME" },
                            label = { Text("केवल आवक (+)") }
                        )
                        FilterChip(
                            selected = filterType == "EXPENSE",
                            onClick = { filterType = "EXPENSE" },
                            label = { Text("केवल खर्च (-)") }
                        )
                    }
                }
            }
        }

        item {
            Text(
                text = "कुल ${filteredList.size} लेन-देन",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        if (filteredList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("कोई लेन-देन नहीं मिला।", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(filteredList) { tx ->
                TransactionItemRow(
                    tx = tx,
                    holderName = holderMap[tx.holderId]?.name ?: "अज्ञात खाता",
                    onDelete = { onDeleteTransaction(tx) }
                )
            }
        }
    }
}

// ==========================================
// ITEM ROW COMPONENT FOR TRANSACTIONS
// ==========================================
@Composable
private fun TransactionItemRow(
    tx: FundTransactionEntity,
    holderName: String,
    onDelete: (() -> Unit)? = null
) {
    val isIncome = tx.type == "INCOME"

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Surface(
                    shape = CircleShape,
                    color = if (isIncome) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = if (isIncome) Icons.AutoMirrored.Filled.TrendingUp else Icons.AutoMirrored.Filled.TrendingDown,
                        contentDescription = null,
                        tint = if (isIncome) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = holderName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (tx.category.isNotBlank()) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = tx.category,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    if (tx.notes.isNotBlank()) {
                        Text(
                            text = tx.notes,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Text(
                        text = "दिनांक: ${tx.date}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${if (isIncome) "+" else "-"} ₹${formatCurrency(tx.amount)}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (isIncome) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                    )
                )

                if (onDelete != null) {
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "हटाएं", tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
    }
}

// ==========================================
// ADD TRANSACTION DIALOG
// ==========================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddTransactionDialog(
    holders: List<FundHolderEntity>,
    initialHolderId: Long,
    initialTxType: String,
    onDismiss: () -> Unit,
    onSave: (FundTransactionEntity) -> Unit
) {
    var selectedHolderId by remember { mutableLongStateOf(initialHolderId) }
    var txType by remember { mutableStateOf(initialTxType) } // INCOME / EXPENSE
    var amountText by remember { mutableStateOf("") }
    
    val todayDateStr = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    var dateText by remember { mutableStateOf(todayDateStr) }
    
    var categoryText by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    val context = LocalContext.current
    val calendar = Calendar.getInstance()

    val categories = listOf("सहयोग/दान (Donation)", "पर्यूषण आयोजन", "सामग्री खर्च", "यात्रा/वाहन खर्च", "सामान्य खर्च", "अन्य")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (txType == "INCOME") "आवक फंड दर्ज करें (+)" else "खर्च/भुगतान दर्ज करें (-)",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Type Selector
                Row(modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = txType == "INCOME",
                        onClick = { txType = "INCOME" },
                        label = { Text("+ जमा / आवक") },
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    FilterChip(
                        selected = txType == "EXPENSE",
                        onClick = { txType = "EXPENSE" },
                        label = { Text("- खर्च / भुगतान") },
                        modifier = Modifier.weight(1f)
                    )
                }

                // Holder Selector Dropdown / Row
                Text("खाता / व्यक्ति चुनें:", style = MaterialTheme.typography.labelMedium)
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    holders.forEach { h ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (selectedHolderId == h.id) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                                .clickable { selectedHolderId = h.id }
                                .padding(horizontal = 10.dp, vertical = 8.dp)
                        ) {
                            RadioButton(
                                selected = selectedHolderId == h.id,
                                onClick = { selectedHolderId = h.id }
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${h.name} (${if (h.type == "BANK") "बैंक" else "नकद धारक"})",
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (selectedHolderId == h.id) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    }
                }

                // Amount
                OutlinedTextField(
                    value = amountText,
                    onValueChange = { amountText = it },
                    label = { Text("राशि (Amount in ₹) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Date
                OutlinedTextField(
                    value = dateText,
                    onValueChange = { dateText = it },
                    label = { Text("दिनांक (YYYY-MM-DD) *") },
                    trailingIcon = {
                        IconButton(onClick = {
                            DatePickerDialog(
                                context,
                                { _, year, month, dayOfMonth ->
                                    val formattedMonth = String.format("%02d", month + 1)
                                    val formattedDay = String.format("%02d", dayOfMonth)
                                    dateText = "$year-$formattedMonth-$formattedDay"
                                },
                                calendar.get(Calendar.YEAR),
                                calendar.get(Calendar.MONTH),
                                calendar.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }) {
                            Icon(Icons.Default.CalendarToday, contentDescription = "कैलेंडर")
                        }
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Category Quick Choice
                Text("कैटेगरी:", style = MaterialTheme.typography.labelMedium)
                FlowRowHorizontal(categories = categories, selected = categoryText, onSelect = { categoryText = it })

                // Notes
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("विवरण / टिप्पणी (Notes)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage.isNotBlank()) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountText.toDoubleOrNull()
                    if (amt == null || amt <= 0.0) {
                        errorMessage = "कृपया वैध राशि दर्ज करें।"
                        return@Button
                    }
                    if (selectedHolderId == 0L) {
                        errorMessage = "कृपया खाता / व्यक्ति का चयन करें।"
                        return@Button
                    }
                    onSave(
                        FundTransactionEntity(
                            holderId = selectedHolderId,
                            type = txType,
                            amount = amt,
                            date = dateText.ifBlank { todayDateStr },
                            timestamp = System.currentTimeMillis(),
                            notes = notesText.trim(),
                            category = categoryText.trim()
                        )
                    )
                }
            ) {
                Text("सुरक्षित करें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}

@Composable
private fun FlowRowHorizontal(
    categories: List<String>,
    selected: String,
    onSelect: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.take(3).forEach { cat ->
                FilterChip(
                    selected = selected == cat,
                    onClick = { onSelect(cat) },
                    label = { Text(cat, fontSize = 11.sp) }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            categories.drop(3).forEach { cat ->
                FilterChip(
                    selected = selected == cat,
                    onClick = { onSelect(cat) },
                    label = { Text(cat, fontSize = 11.sp) }
                )
            }
        }
    }
}

// ==========================================
// ADD HOLDER DIALOG
// ==========================================
@Composable
private fun AddHolderDialog(
    onDismiss: () -> Unit,
    onSave: (FundHolderEntity) -> Unit
) {
    var personName by remember { mutableStateOf("") }
    var notesText by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("नया नकद धारक व्यक्ति जोड़ें") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "नकद जमा रखने वाले व्यक्ति (जैसे- मंत्री जी, कोषाध्यक्ष, स्वाध्यायी कार्यकर्ता) का नाम दर्ज करें:",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = personName,
                    onValueChange = { personName = it },
                    label = { Text("व्यक्ति का नाम (Person Name) *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("पद / टिप्पणी (e.g. Treasurer / Cashier)") },
                    modifier = Modifier.fillMaxWidth()
                )

                if (errorMessage.isNotBlank()) {
                    Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (personName.isBlank()) {
                        errorMessage = "कृपया नाम दर्ज करें।"
                        return@Button
                    }
                    onSave(
                        FundHolderEntity(
                            name = personName.trim(),
                            type = "CASH",
                            notes = notesText.trim()
                        )
                    )
                }
            ) {
                Text("जोड़ें")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("रद्द करें")
            }
        }
    )
}

// Helpers
private fun formatCurrency(amount: Double): String {
    return try {
        val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
        formatter.maximumFractionDigits = 2
        formatter.format(amount)
    } catch (e: Exception) {
        String.format("%.2f", amount)
    }
}

private fun formatYearMonthLabel(ym: String): String {
    return try {
        val parts = ym.split("-")
        if (parts.size == 2) {
            val yr = parts[0]
            val mNum = parts[1].toIntOrNull() ?: 1
            val mNames = listOf("जनवरी", "फ़रवरी", "मार्च", "अप्रैल", "मई", "जून", "जुलाई", "अगस्त", "सितम्बर", "अक्टूबर", "नवम्बर", "दिसम्बर")
            "${mNames[mNum - 1]} $yr"
        } else ym
    } catch (e: Exception) {
        ym
    }
}
