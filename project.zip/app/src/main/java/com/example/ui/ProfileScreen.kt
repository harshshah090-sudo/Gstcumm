package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: FormViewModel,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToSanghRegistrations: () -> Unit = {},
    onNavigateToSwadhyaiRegistrations: () -> Unit = {},
    onNavigateToFund: () -> Unit = {},
    onNavigateToPanchang: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(40.dp)
                        )
                        Column {
                            Text(
                                text = "प्रोफ़ाइल एवं खाता",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            Text(
                                text = "Profile & Account • श्री वर्द्धमान संघ",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppSurface
                ),
                modifier = Modifier.testTag("profile_top_bar")
            )
        },
        containerColor = AppBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .padding(bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Profile Header Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = AppSurface,
                border = BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.12f),
                                    Color.Transparent
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            AppPrimaryGold.copy(alpha = 0.25f),
                                            AppPrimaryGold.copy(alpha = 0.10f)
                                        )
                                    )
                                )
                                .border(2.dp, AppPrimaryGold.copy(alpha = 0.6f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Profile Avatar",
                                tint = AppPrimaryGold,
                                modifier = Modifier.size(46.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "श्री वर्द्धमान स्वाध्यायी संघ",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 18.sp
                            )
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Surface(
                            shape = CircleShape,
                            color = AppPrimaryGold.copy(alpha = 0.15f),
                            border = BorderStroke(0.75.dp, AppPrimaryGold.copy(alpha = 0.4f))
                        ) {
                            Text(
                                text = "।। जिन आज्ञा परमो धर्मः ।।",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = AppPrimaryGold,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.5.sp
                                ),
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Quick Access Section
            Text(
                text = "त्वरित विकल्प (Quick Access)",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp
                ),
                modifier = Modifier.padding(start = 4.dp)
            )

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = AppSurface,
                border = BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    ProfileMenuRow(
                        icon = Icons.Outlined.Groups,
                        title = "स्वाध्यायी पंजीकरण (Swadhyai Registrations)",
                        subtitle = "पंजीकृत स्वाध्यायी बंधुओं की सूची एवं विवरण",
                        onClick = onNavigateToSwadhyaiRegistrations
                    )
                    HorizontalDivider(color = AppBorder.copy(alpha = 0.5f), thickness = 0.75.dp)
                    ProfileMenuRow(
                        icon = Icons.Outlined.Domain,
                        title = "संघ पंजीकरण (Sangh Registrations)",
                        subtitle = "पंजीकृत संघों की सूची व आवंटन",
                        onClick = onNavigateToSanghRegistrations
                    )
                    HorizontalDivider(color = AppBorder.copy(alpha = 0.5f), thickness = 0.75.dp)
                    ProfileMenuRow(
                        icon = Icons.Outlined.CalendarMonth,
                        title = "जैन पंचांग व तिथियां (Jain Panchang)",
                        subtitle = "डिजिटल पंचांग व महत्वपूर्ण पर्व",
                        onClick = onNavigateToPanchang
                    )
                    HorizontalDivider(color = AppBorder.copy(alpha = 0.5f), thickness = 0.75.dp)
                    ProfileMenuRow(
                        icon = Icons.Outlined.AccountBalanceWallet,
                        title = "स्वाध्यायी संघ कोष (Trust Fund)",
                        subtitle = "दान विवरण व बैंक खाता जानकारी",
                        onClick = onNavigateToFund
                    )
                }
            }

            // Settings & Preferences
            Text(
                text = "ऐप सेटिंग व प्राथमिकताएं (Preferences)",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 13.sp
                ),
                modifier = Modifier.padding(start = 4.dp)
            )

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = AppSurface,
                border = BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    ProfileMenuRow(
                        icon = Icons.Outlined.Settings,
                        title = "सेटिंग्स (Settings)",
                        subtitle = "विजेट, बैकअप, रीसायकल बिन व प्रबंधन",
                        onClick = onNavigateToSettings
                    )
                }
            }

            // App Version Info
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "वर्जन 1.0.0 • श्री वर्द्धमान स्वाध्यायी संघ, मुम्बई",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = AppTextMuted,
                        fontSize = 11.5.sp
                    )
                )
            }
        }
    }
}

@Composable
private fun ProfileMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(AppPrimaryGold.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = AppPrimaryGold,
                modifier = Modifier.size(20.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontSize = 14.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 12.sp
                )
            )
        }

        Icon(
            imageVector = Icons.Default.ChevronRight,
            contentDescription = null,
            tint = AppTextMuted,
            modifier = Modifier.size(20.dp)
        )
    }
}
