package com.example.ui

import android.util.Log
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.data.UserSessionManager
import com.example.ui.theme.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// HTML-matched Color Palette (aligned with Swadhyai Mandal Theme: AppBackground #101614, AppSurface #1B2420)
private val ProfileDarkBg = AppBackground // Color(0xFF101614)
private val ProfileDarkSurface = AppSurface // Color(0xFF1B2420)
private val ProfileDarkSurface2 = Color(0xFF212D27)
private val ProfileDarkBorder = Color(0xFF2A3830)
private val ProfileGold = Color(0xFFE3B24E)
private val ProfileGoldDeep = Color(0xFFC79730)
private val ProfileCream = Color(0xFFEDE7DA)
private val ProfileMuted = Color(0xFF8FA096)
private val ProfileMaroon = Color(0xFFB4425A)
private val ProfileGreen = Color(0xFF3FAE7E)
private val ProfileTeal = Color(0xFF2FB5C4)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: FormViewModel,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToSanghRegistrations: () -> Unit = {},
    onNavigateToSwadhyaiRegistrations: () -> Unit = {},
    onNavigateToFund: () -> Unit = {},
    onNavigateToPanchang: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val session by UserSessionManager.sessionState.collectAsStateWithLifecycle()

    val swadhyaiForms by viewModel.allSwadhyaiForms.collectAsStateWithLifecycle()

    // Find current user's profile entity
    val userProfileEntity = remember(session.phone, swadhyaiForms, session.profileData) {
        val clean = session.phone.takeLast(10)
        val fromRoom = swadhyaiForms.firstOrNull { it.whatsappNo.takeLast(10) == clean || it.contactNo.takeLast(10) == clean }
        if (fromRoom != null && session.profileData != null) {
            if (session.profileData!!.updatedAt >= fromRoom.updatedAt) session.profileData else fromRoom
        } else {
            fromRoom ?: session.profileData
        }
    }

    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 4 })
    val selectedTab = pagerState.currentPage

    // Editable profile fields
    var fullName by remember(userProfileEntity, session.fullName) {
        mutableStateOf(userProfileEntity?.fullName?.ifBlank { session.fullName } ?: session.fullName.ifBlank { "Swadhyai Member" })
    }
    var fatherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.fatherName ?: "") }
    var motherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.motherName ?: "") }
    var dob by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.dob ?: "") }
    var age by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.age ?: 0) > 0) userProfileEntity!!.age.toString() else "")
    }
    var bloodGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.bloodGroup ?: "") }
    var maritalStatus by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.maritalStatus?.ifBlank { "Married" } ?: "Married") }
    var anniversaryDate by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anniversaryDate ?: "") }
    var education by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.education ?: "") }

    var workingStatus by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: ""
        mutableStateOf(if (stat.startsWith("Other: ")) "Others" else stat)
    }
    var otherProfession by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: ""
        mutableStateOf(if (stat.startsWith("Other: ")) stat.removePrefix("Other: ") else "")
    }
    var workDescription by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.workDescription ?: "") }

    var contactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.contactNo ?: "") }
    var emailId by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.email ?: "") }
    var emergencyName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactName ?: "") }
    var emergencyRelation by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactRelation ?: "") }
    var emergencyContactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactNo ?: "") }
    var address by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.address ?: "") }
    var state by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.state ?: "") }
    var city by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.city ?: "") }
    var pincode by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.pincode ?: "") }

    // Religious
    val learnings = userProfileEntity?.religiousLearnings ?: ""
    var subMandirDohe by remember(learnings) { mutableStateOf(learnings.contains("Asht Prakari Puja ke Dohe")) }
    var subMandirChaitya by remember(learnings) { mutableStateOf(learnings.contains("Chaityawandan Vidhi")) }
    var sub2Vanditu by remember(learnings) { mutableStateOf(learnings.contains("Vanditu")) }
    var sub2Jagchintamani by remember(learnings) { mutableStateOf(learnings.contains("Jagchintamani")) }
    var sub2Bharser by remember(learnings) { mutableStateOf(learnings.contains("Bharser")) }
    var sub2LaghuShanti by remember(learnings) { mutableStateOf(learnings.contains("Laghu Shanti")) }
    var sub2SakalaTirth by remember(learnings) { mutableStateOf(learnings.contains("Sakala Tirth")) }
    var sub5Saklarhat by remember(learnings) { mutableStateOf(learnings.contains("Saklarhat")) }
    var sub5Snatasya by remember(learnings) { mutableStateOf(learnings.contains("Snatasya")) }
    var sub5Atichar by remember(learnings) { mutableStateOf(learnings.contains("Atichar")) }
    var sub5AjitShanti by remember(learnings) { mutableStateOf(learnings.contains("Ajit Shanti")) }
    var sub5BadiShanti by remember(learnings) { mutableStateOf(learnings.contains("Badi Shanti")) }
    var sub5Santikaram by remember(learnings) { mutableStateOf(learnings.contains("Santikaram")) }

    var otherLearnings by remember(learnings) {
        val standardKeywords = listOf(
            "Asht Prakari", "Chaityawandan Vidhi", "Vanditu", "Jagchintamani", "Bharser",
            "Laghu Shanti", "Sakala Tirth", "Saklarhat", "Snatasya", "Atichar", "Ajit Shanti",
            "Badi Shanti", "Santikaram"
        )
        val extra = learnings.lines()
            .map { it.trim() }
            .filter { line ->
                line.isNotBlank() && (
                    line.startsWith("Other:") || line.startsWith("✔") || line.startsWith("-") || line.startsWith("•") ||
                    standardKeywords.none { line.contains(it, ignoreCase = true) }
                )
            }
            .map { it.removePrefix("Other:").removePrefix("✔").removePrefix("-").removePrefix("•").trim() }
            .filter { it.isNotBlank() }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    val specs = (userProfileEntity?.specialities ?: "").split(",").map { it.trim() }
    var specPratikraman by remember(specs) { mutableStateOf(specs.any { it.equals("Pratikraman", true) }) }
    var specVaanchan by remember(specs) { mutableStateOf(specs.any { it.equals("Vaanchan", true) || it.equals("Vaachna", true) }) }
    var specBhakti by remember(specs) { mutableStateOf(specs.any { it.equals("Bhakti", true) }) }
    var specOther by remember(specs) { mutableStateOf(specs.any { it.startsWith("Other: ") }) }
    var specOtherText by remember(specs) { mutableStateOf(specs.firstOrNull { it.startsWith("Other: ") }?.removePrefix("Other: ") ?: "") }

    var joiningYear by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.joiningYear ?: 0) > 0) userProfileEntity!!.joiningYear.toString() else "")
    }
    var paryushanCount by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.paryushanCount ?: 0) > 0) userProfileEntity!!.paryushanCount.toString() else "0")
    }

    var anotherGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anotherGroup ?: "") }
    var postInGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.postInGroup ?: "") }

    val acts = (userProfileEntity?.dailyRoutineActivities ?: "").split(",").map { it.trim() }
    var actNavkarshi by remember(acts) { mutableStateOf(acts.any { it.equals("Navkarshi", true) }) }
    var actPrabhuPujan by remember(acts) { mutableStateOf(acts.any { it.equals("Prabhu Pujan", true) }) }
    var actRatriBhojanTyag by remember(acts) { mutableStateOf(acts.any { it.equals("Ratri Bhojan Tyag", true) }) }
    var actTithiPalan by remember(acts) { mutableStateOf(acts.any { it.equals("Tithi Palan", true) }) }
    var actNavkarPakkiMala by remember(acts) { mutableStateOf(acts.any { it.equals("Navkar Pakki Mala", true) }) }
    var actSamaiyk by remember(acts) { mutableStateOf(acts.any { it.equals("Samaiyk", true) }) }
    var actPratikaman by remember(acts) { mutableStateOf(acts.any { it.equals("Pratikaman", true) }) }
    var otherDailyActivities by remember(userProfileEntity) {
        val extra = acts.filter { it.startsWith("Other: ") }.map { it.removePrefix("Other: ") }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    var lifetimeTapasyaList by remember(userProfileEntity) {
        val raw = userProfileEntity?.lifetimeTapasya ?: ""
        val tap = raw.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
        mutableStateOf(tap)
    }

    var menuExpanded by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var datePickerTarget by remember { mutableStateOf("dob") }

    fun saveProfile() {
        val cleanPhone = session.phone.takeLast(10).ifBlank { "9876543210" }
        isSaving = true

        coroutineScope.launch {
            val specialitiesList = mutableListOf<String>()
            if (specPratikraman) specialitiesList.add("Pratikraman")
            if (specVaanchan) specialitiesList.add("Vaanchan")
            if (specBhakti) specialitiesList.add("Bhakti")
            if (specOther && specOtherText.isNotBlank()) specialitiesList.add("Other: $specOtherText")

            val religiousLearningsList = mutableListOf<String>()
            if (subMandirDohe) religiousLearningsList.add("Asht Prakari Puja ke Dohe")
            if (subMandirChaitya) religiousLearningsList.add("Chaityawandan Vidhi")
            if (sub2Vanditu) religiousLearningsList.add("Vanditu")
            if (sub2Jagchintamani) religiousLearningsList.add("Jagchintamani Chaityawandan")
            if (sub2Bharser) religiousLearningsList.add("Bharser Sajjhay")
            if (sub2LaghuShanti) religiousLearningsList.add("Laghu Shanti")
            if (sub2SakalaTirth) religiousLearningsList.add("Sakala Tirth")
            if (sub5Saklarhat) religiousLearningsList.add("Saklarhat Chaityawandan")
            if (sub5Snatasya) religiousLearningsList.add("Snatasya Thui")
            if (sub5Atichar) religiousLearningsList.add("Atichar")
            if (sub5AjitShanti) religiousLearningsList.add("Ajit Shanti")
            if (sub5BadiShanti) religiousLearningsList.add("Badi Shanti")
            if (sub5Santikaram) religiousLearningsList.add("Santikaram")
            otherLearnings.filter { it.isNotBlank() }.forEach { religiousLearningsList.add("Other: $it") }

            val dailyActivitiesList = mutableListOf<String>()
            if (actNavkarshi) dailyActivitiesList.add("Navkarshi")
            if (actPrabhuPujan) dailyActivitiesList.add("Prabhu Pujan")
            if (actRatriBhojanTyag) dailyActivitiesList.add("Ratri Bhojan Tyag")
            if (actTithiPalan) dailyActivitiesList.add("Tithi Palan")
            if (actNavkarPakkiMala) dailyActivitiesList.add("Navkar Pakki Mala")
            if (actSamaiyk) dailyActivitiesList.add("Samaiyk")
            if (actPratikaman) dailyActivitiesList.add("Pratikaman")
            otherDailyActivities.filter { it.isNotBlank() }.forEach { dailyActivitiesList.add("Other: $it") }

            val lifetimeList = lifetimeTapasyaList.filter { it.isNotBlank() }

            val pCount = paryushanCount.toIntOrNull() ?: 0
            val jYear = joiningYear.toIntOrNull() ?: 0
            val userAge = age.toIntOrNull() ?: 0

            val workVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) "Other: $otherProfession" else workingStatus

            val updatedEntity = SwadhyaiFormEntity(
                id = userProfileEntity?.id ?: 0L,
                firestoreDocId = userProfileEntity?.firestoreDocId?.ifBlank { "phone_$cleanPhone" } ?: "phone_$cleanPhone",
                fullName = fullName.trim(),
                fatherName = fatherName.trim(),
                motherName = motherName.trim(),
                gender = userProfileEntity?.gender ?: "Male",
                dob = dob.trim(),
                age = userAge,
                bloodGroup = bloodGroup.trim(),
                maritalStatus = maritalStatus,
                anniversaryDate = if (maritalStatus == "Married") anniversaryDate.trim() else "",
                email = emailId.trim(),
                whatsappNo = cleanPhone,
                contactNo = contactNo.trim(),
                emergencyContactName = emergencyName.trim(),
                emergencyContactRelation = emergencyRelation.trim(),
                emergencyContactNo = emergencyContactNo.trim(),
                address = address.trim(),
                city = city.trim(),
                pincode = pincode.trim(),
                state = state.trim(),
                education = education.trim(),
                workingStatus = workVal.trim(),
                workDescription = workDescription.trim(),
                joiningYear = jYear,
                specialities = specialitiesList.joinToString(", "),
                religiousLearnings = religiousLearningsList.joinToString("\n"),
                anotherGroup = anotherGroup.trim(),
                postInGroup = postInGroup.trim(),
                paryushanCount = pCount,
                paryushanHistoryLog = userProfileEntity?.paryushanHistoryLog ?: "",
                dailyRoutineActivities = dailyActivitiesList.joinToString(", "),
                lifetimeTapasya = lifetimeList.joinToString("\n"),
                acceptedRules = true,
                updatedAt = System.currentTimeMillis()
            )

            // 1. Immediately persist to Room database
            withContext(Dispatchers.IO) {
                try {
                    val existing = swadhyaiForms.firstOrNull { it.whatsappNo.takeLast(10) == cleanPhone || it.contactNo.takeLast(10) == cleanPhone }
                    if (updatedEntity.id > 0L) {
                        viewModel.updateSwadhyaiForm(updatedEntity)
                    } else if (existing != null) {
                        viewModel.updateSwadhyaiForm(updatedEntity.copy(id = existing.id))
                    } else {
                        viewModel.insertSwadhyaiForm(updatedEntity)
                    }
                } catch (e: Exception) {
                    Log.w("ProfileScreen", "Failed to update local room form: ${e.message}")
                }
            }

            // 2. Immediately update session state
            UserSessionManager.updateProfileData(updatedEntity)

            // 3. Save to Firestore
            withContext(Dispatchers.IO) {
                try {
                    val db = FirebaseFirestore.getInstance()
                    val map = hashMapOf(
                        "fullName" to updatedEntity.fullName,
                        "fatherName" to updatedEntity.fatherName,
                        "motherName" to updatedEntity.motherName,
                        "gender" to updatedEntity.gender,
                        "dob" to updatedEntity.dob,
                        "age" to updatedEntity.age,
                        "bloodGroup" to updatedEntity.bloodGroup,
                        "maritalStatus" to updatedEntity.maritalStatus,
                        "anniversaryDate" to updatedEntity.anniversaryDate,
                        "whatsappNo" to cleanPhone,
                        "searchPhone" to cleanPhone,
                        "contactNo" to updatedEntity.contactNo,
                        "email" to updatedEntity.email,
                        "emailId" to updatedEntity.email,
                        "emergencyContactName" to updatedEntity.emergencyContactName,
                        "emergencyContactRelation" to updatedEntity.emergencyContactRelation,
                        "emergencyContactNo" to updatedEntity.emergencyContactNo,
                        "address" to updatedEntity.address,
                        "city" to updatedEntity.city,
                        "pincode" to updatedEntity.pincode,
                        "state" to updatedEntity.state,
                        "education" to updatedEntity.education,
                        "workingStatus" to updatedEntity.workingStatus,
                        "workDescription" to updatedEntity.workDescription,
                        "joiningYear" to updatedEntity.joiningYear,
                        "specialities" to specialitiesList,
                        "religiousLearnings" to religiousLearningsList,
                        "religiousLearningsFormatted" to updatedEntity.religiousLearnings,
                        "anotherGroup" to updatedEntity.anotherGroup,
                        "postInGroup" to updatedEntity.postInGroup,
                        "paryushanCount" to updatedEntity.paryushanCount,
                        "paryushanHistoryLog" to updatedEntity.paryushanHistoryLog,
                        "dailyRoutineActivities" to dailyActivitiesList,
                        "lifetimeTapasya" to lifetimeList,
                        "acceptedRules" to true,
                        "updatedAt" to updatedEntity.updatedAt
                    )
                    db.collection("swadhyai_forms").document("phone_$cleanPhone").set(map, SetOptions.merge())
                } catch (e: Exception) {
                    Log.w("ProfileScreen", "Failed to update Firestore: ${e.message}")
                }
            }

            if (updatedEntity.id > 0L) {
                com.example.utils.SwadhyaiSeenTracker.markSwadhyaiSeen(context, updatedEntity.id)
            }
            viewModel.refreshCloudData()
            isSaving = false
            showEditDialog = false
            Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    // Dynamic stats computation
    val displaySpecialitiesCount = remember(specPratikraman, specVaanchan, specBhakti, specOther, specOtherText) {
        val count = listOfNotNull(
            if (specPratikraman) 1 else null,
            if (specVaanchan) 1 else null,
            if (specBhakti) 1 else null,
            if (specOther && specOtherText.isNotBlank()) 1 else null
        ).size
        count
    }
    val displayLearningsCount = remember(
        subMandirDohe, subMandirChaitya,
        sub2Vanditu, sub2Jagchintamani, sub2Bharser, sub2LaghuShanti, sub2SakalaTirth,
        sub5Saklarhat, sub5Snatasya, sub5Atichar, sub5AjitShanti, sub5BadiShanti, sub5Santikaram,
        otherLearnings
    ) {
        val standard = listOf(
            subMandirDohe, subMandirChaitya,
            sub2Vanditu, sub2Jagchintamani, sub2Bharser, sub2LaghuShanti, sub2SakalaTirth,
            sub5Saklarhat, sub5Snatasya, sub5Atichar, sub5AjitShanti, sub5BadiShanti, sub5Santikaram
        ).count { it }
        val others = otherLearnings.count { it.isNotBlank() }
        standard + others
    }
    val displayYearsCount = remember(joiningYear) {
        val j = joiningYear.toIntOrNull() ?: 0
        if (j in 1950..2026) 2026 - j else 0
    }

    val memberSinceStr = remember(joiningYear) {
        if (joiningYear.isNotBlank() && joiningYear != "0") "Member since $joiningYear" else "Swadhyai Sangh Member"
    }
    val subtitleLine = memberSinceStr

    // Initials computation
    val userInitials = remember(fullName) {
        val parts = fullName.trim().split(" ").filter { it.isNotBlank() }
        if (parts.size >= 2) {
            "${parts[0].first().uppercaseChar()}${parts[1].first().uppercaseChar()}"
        } else if (parts.isNotEmpty() && parts[0].isNotEmpty()) {
            parts[0].take(2).uppercase()
        } else {
            "NS"
        }
    }

    val scrollState = rememberScrollState()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            val screenWidth = maxWidth
            val screenHeight = maxHeight
            val density = LocalDensity.current

            val headerBarHeight = 64.dp
            val topSpacerHeight = 240.dp
            val statBoxesHeight = 72.dp
            val tabsBarHeight = 48.dp

            // Distance to collapse hero avatar & name into the 64dp header bar:
            val collapseHeroTravelDp = topSpacerHeight - headerBarHeight // 176.dp
            val collapseHeroTravelPx = with(density) { collapseHeroTravelDp.toPx().coerceAtLeast(1f) }

            val collapseFraction by remember {
                derivedStateOf {
                    (scrollState.value.toFloat() / collapseHeroTravelPx).coerceIn(0f, 1f)
                }
            }

            // Helper linear interpolation
            fun lerpDp(start: Dp, stop: Dp, fraction: Float): Dp = start + (stop - start) * fraction
            fun lerpSp(start: Float, stop: Float, fraction: Float): TextUnit = (start + (stop - start) * fraction).sp

            // Measured text width for exact horizontal centering in expanded state
            var textBlockWidthDp by remember { mutableStateOf(0.dp) }

            // Avatar coordinates & dimensions:
            // Expanded: Center-X, Y = 72.dp, Size = 92.dp
            // Collapsed: Left-X = 16.dp, Y = 12.dp, Size = 40.dp
            val avatarExpandedSize = 92.dp
            val avatarCollapsedSize = 40.dp
            val avatarStartX = (screenWidth - avatarExpandedSize) / 2
            val avatarEndX = 16.dp
            val avatarStartY = 72.dp
            val avatarEndY = 12.dp

            val currentAvatarSize = lerpDp(avatarExpandedSize, avatarCollapsedSize, collapseFraction)
            val currentAvatarX = lerpDp(avatarStartX, avatarEndX, collapseFraction)
            val currentAvatarY = lerpDp(avatarStartY, avatarEndY, collapseFraction)
            val currentInitialsFont = lerpSp(34f, 14f, collapseFraction)
            val currentBadgeSize = lerpDp(25.dp, 13.dp, collapseFraction)
            val currentBadgeFont = lerpSp(13f, 8f, collapseFraction)

            // Text coordinates & dimensions (Name & Subtitle):
            // Expanded: Center-X, Y = 172.dp
            // Collapsed: Left-X = 64.dp, Y = 13.dp
            val effectiveTextWidth = if (textBlockWidthDp > 0.dp) textBlockWidthDp else 160.dp
            val textStartX = ((screenWidth - effectiveTextWidth) / 2).coerceAtLeast(16.dp)
            val textEndX = 64.dp
            val textStartY = 172.dp
            val textEndY = 13.dp

            val currentTextX = lerpDp(textStartX, textEndX, collapseFraction)
            val currentTextY = lerpDp(textStartY, textEndY, collapseFraction)
            val textScale = 1.0f - (0.22f * collapseFraction)
            val subtitleColor = lerp(ProfileMuted, ProfileGold, collapseFraction)

            // Calculate the exact minimum height for the tab container so that scrolling can always travel
            // at least `collapseHeroTravelDp` (176dp) to place the avatar & name cleanly in the header,
            // without creating unbounded extra whitespace.
            // When total content height = screenHeight + collapseHeroTravelDp - bottomBarSpacing, max scroll is exactly collapseHeroTravelPx.
            val minContainerHeightForHeroCollapse = (screenHeight + collapseHeroTravelDp - (topSpacerHeight + statBoxesHeight + 10.dp + tabsBarHeight + 12.dp) - 90.dp).coerceAtLeast(0.dp)

            // 1. App logo watermark in the background
            Image(
                painter = painterResource(id = R.drawable.header_logo),
                contentDescription = null,
                modifier = Modifier
                    .size(340.dp)
                    .align(Alignment.Center)
                    .alpha(0.18f)
            )

            // 2. Main Scroll Container
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
            ) {
                // Space for Expanded Hero Avatar & Name (scrolls up and collapses into header bar)
                Spacer(modifier = Modifier.height(topSpacerHeight))

                // Spacer matching the sticky 4 Stat Blocks + Tab Selector Row + Margins
                Spacer(modifier = Modifier.height(statBoxesHeight + 10.dp + tabsBarHeight + 12.dp))

                // ---- TAB CONTENT AREA ----
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .defaultMinSize(minHeight = minContainerHeightForHeroCollapse)
                        .padding(horizontal = 18.dp)
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.Top
                    ) { targetTab ->
                        when (targetTab) {
                            0 -> {
                                // Personal Tab Panel (Liquid Glass Card)
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGold.copy(alpha = 0.45f),
                                                ProfileGold.copy(alpha = 0.18f),
                                                ProfileGold.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x752C1E0A), Color(0x4816120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp)
                                    ) {
                                        CardHeaderRow(
                                            title = "Personal Details",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // 2-column info grid
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            InfoGridItem(
                                                label = "FATHER'S NAME",
                                                value = fatherName.ifBlank { "Not specified" },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "MOTHER'S NAME",
                                                value = motherName.ifBlank { "Not specified" },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            val dobAgeDisplay = if (dob.isNotBlank() && age.isNotBlank()) {
                                                "$dob (Age $age)"
                                            } else if (dob.isNotBlank()) {
                                                dob
                                            } else if (age.isNotBlank()) {
                                                "Age $age"
                                            } else {
                                                "Not specified"
                                            }
                                            InfoGridItem(
                                                label = "DATE OF BIRTH",
                                                value = dobAgeDisplay,
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "BLOOD GROUP",
                                                value = bloodGroup.ifBlank { "Not specified" },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            InfoGridItem(
                                                label = "MARITAL STATUS",
                                                value = maritalStatus.ifBlank { "Not specified" },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "ANNIVERSARY",
                                                value = if (maritalStatus == "Married") anniversaryDate.ifBlank { "Not specified" } else "N/A",
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                    }
                                }

                                // 2. Education Card (Liquid Glass Teal)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileTeal.copy(alpha = 0.45f),
                                                ProfileTeal.copy(alpha = 0.18f),
                                                ProfileTeal.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x700E262A), Color(0x450A1518))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp)
                                    ) {
                                        CardHeaderRow(
                                            title = "Education / Qualification",
                                            bulletColor = ProfileTeal,
                                            titleColor = ProfileTeal
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        InfoGridItem(
                                            label = "QUALIFICATION",
                                            value = education.ifBlank { "Not specified" },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }

                                // 3. Profession & Work Details Card (Liquid Glass Gold)
                                val profVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) {
                                    otherProfession
                                } else if (workingStatus.isNotBlank()) {
                                    workingStatus
                                } else {
                                    "Not specified"
                                }

                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGold.copy(alpha = 0.45f),
                                                ProfileGold.copy(alpha = 0.18f),
                                                ProfileGold.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x752C1E0A), Color(0x4816120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp)
                                    ) {
                                        CardHeaderRow(
                                            title = "Profession & Work Details",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        InfoGridItem(
                                            label = "PROFESSION",
                                            value = profVal,
                                            modifier = Modifier.fillMaxWidth()
                                        )

                                        if (workDescription.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            InfoGridItem(
                                                label = "WORK DETAILS / DESCRIPTION",
                                                value = workDescription,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        1 -> {
                            // Religious Tab Panel (Liquid Glass Cards)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // 1. Religious Learning Card (Liquid Glass Emerald)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGreen.copy(alpha = 0.50f),
                                                ProfileGreen.copy(alpha = 0.20f),
                                                ProfileGreen.copy(alpha = 0.40f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x700E261D), Color(0x450B1712))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Religious Learning",
                                            bulletColor = ProfileGreen,
                                            titleColor = ProfileGreen
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Mandir Vidhi
                                        val mandirList = listOfNotNull(
                                            if (subMandirDohe) "Asht Prakari Puja ke Dohe" else null,
                                            if (subMandirChaitya) "Chaityawandan Vidhi" else null
                                        )
                                        LearningSectionItem(
                                            title = "Mandir Vidhi",
                                            countStr = "${mandirList.size}/2",
                                            subItems = mandirList.ifEmpty { listOf("None recorded") }.joinToString(" · ")
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )

                                        // 2 Pratikraman
                                        val sub2List = listOfNotNull(
                                            if (sub2Vanditu) "Vanditu" else null,
                                            if (sub2Jagchintamani) "Jagchintamani Chaityawandan" else null,
                                            if (sub2Bharser) "Bharser Sajjhay" else null,
                                            if (sub2LaghuShanti) "Laghu Shanti" else null,
                                            if (sub2SakalaTirth) "Sakala Tirth" else null
                                        )
                                        LearningSectionItem(
                                            title = "2 Pratikraman",
                                            countStr = "${sub2List.size}/5",
                                            subItems = sub2List.ifEmpty { listOf("None recorded") }.joinToString(" · ")
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )

                                        // 5 Pratikraman
                                        val sub5List = listOfNotNull(
                                            if (sub5Saklarhat) "Saklarhat Chaityawandan" else null,
                                            if (sub5AjitShanti) "Ajit Shanti" else null,
                                            if (sub5Snatasya) "Snatasya Thui" else null,
                                            if (sub5Atichar) "Atichar" else null,
                                            if (sub5BadiShanti) "Badi Shanti" else null,
                                            if (sub5Santikaram) "Santikaram" else null
                                        )
                                        LearningSectionItem(
                                            title = "5 Pratikraman",
                                            countStr = "${sub5List.size}/6",
                                            subItems = sub5List.ifEmpty { listOf("None recorded") }.joinToString(" · ")
                                        )

                                        val cleanOthers = otherLearnings.filter { it.isNotBlank() }
                                        if (cleanOthers.isNotEmpty()) {
                                            HorizontalDivider(
                                                color = ProfileDarkBorder.copy(alpha = 0.6f),
                                                modifier = Modifier.padding(vertical = 10.dp)
                                            )
                                            LearningSectionItem(
                                                title = "Other Gyan / Path",
                                                countStr = "${cleanOthers.size}",
                                                subItems = cleanOthers.joinToString(" · ")
                                            )
                                        }
                                    }
                                }

                                // 2. Daily Routine Religious Activity Card (Liquid Glass Emerald)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGreen.copy(alpha = 0.50f),
                                                ProfileGreen.copy(alpha = 0.20f),
                                                ProfileGreen.copy(alpha = 0.40f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x700E261D), Color(0x450B1712))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Daily Routine Religious Activity",
                                            bulletColor = ProfileGreen,
                                            titleColor = ProfileGreen
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val activeActs = mutableListOf<String>()
                                        if (actNavkarshi) activeActs.add("Navkarshi")
                                        if (actPrabhuPujan) activeActs.add("Prabhu Pujan")
                                        if (actSamaiyk) activeActs.add("Samaiyk")
                                        if (actTithiPalan) activeActs.add("Tithi Palan")
                                        if (actRatriBhojanTyag) activeActs.add("Ratri Bhojan Tyag")
                                        if (actNavkarPakkiMala) activeActs.add("Navkar Pakki Mala")
                                        if (actPratikaman) activeActs.add("Pratikaman")
                                        otherDailyActivities.filter { it.isNotBlank() }.forEach { activeActs.add(it) }

                                        if (activeActs.isNotEmpty()) {
                                            @OptIn(ExperimentalLayoutApi::class)
                                            FlowRow(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                activeActs.forEach { actName ->
                                                    ChipPill(
                                                        text = actName,
                                                        textColor = ProfileGreen,
                                                        borderColor = Color(0x603FAE7E)
                                                    )
                                                }
                                            }
                                        } else {
                                            Text(
                                                text = "None recorded",
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontSize = 13.sp,
                                                    color = ProfileMuted
                                                )
                                            )
                                        }
                                    }
                                }

                                // 4. Lifetime Tapasya / Tyag Card (Liquid Glass Gold)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGold.copy(alpha = 0.45f),
                                                ProfileGold.copy(alpha = 0.18f),
                                                ProfileGold.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x752C1E0A), Color(0x4816120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Lifetime Tapasya / Tyag",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val tapList = lifetimeTapasyaList.filter { it.isNotBlank() }

                                        if (tapList.isNotEmpty()) {
                                            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                                tapList.forEach { vow ->
                                                    Row(
                                                        verticalAlignment = Alignment.Top,
                                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                    ) {
                                                        Box(
                                                            modifier = Modifier
                                                                .padding(top = 6.dp)
                                                                .size(7.dp)
                                                                .clip(CircleShape)
                                                                .background(ProfileGold)
                                                        )
                                                        Text(
                                                            text = vow,
                                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                                fontSize = 13.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                color = ProfileCream
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        } else {
                                            Text(
                                                text = "None recorded",
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontSize = 13.sp,
                                                    color = ProfileMuted
                                                )
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            // Mandal Tab Panel (Liquid Glass Gold / Emerald Cards)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // 1. Mandal Association Card (Liquid Glass Gold)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGold.copy(alpha = 0.45f),
                                                ProfileGold.copy(alpha = 0.18f),
                                                ProfileGold.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x752C1E0A), Color(0x4816120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Mandal Association",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        val jYearDisplay = if (joiningYear.isNotBlank() && joiningYear != "0") joiningYear else "Not specified"
                                        val pCountDisplay = if (paryushanCount.isNotBlank() && paryushanCount != "0") "${paryushanCount} times" else "0 times"
                                        val otherGroupDisplay = anotherGroup.ifBlank { "None" }
                                        val postDisplay = postInGroup.ifBlank { "None" }

                                        MandalInfoRow(
                                            label = "Joined Vardhman Mandal",
                                            value = jYearDisplay
                                        )
                                        MandalInfoRow(
                                            label = "Paryushan Aaradhna Count",
                                            value = pCountDisplay
                                        )
                                        MandalInfoRow(
                                            label = "Other Group",
                                            value = otherGroupDisplay
                                        )
                                        MandalInfoRow(
                                            label = "Post Held",
                                            value = postDisplay,
                                            isLast = true
                                        )
                                    }
                                }

                                // 2. Specialities & Seva in Mandal Card (Liquid Glass Gold)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGold.copy(alpha = 0.45f),
                                                ProfileGold.copy(alpha = 0.18f),
                                                ProfileGold.copy(alpha = 0.35f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x752C1E0A), Color(0x4816120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Mandal Specialities & Seva",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val activeSpecs = mutableListOf<String>()
                                        if (specPratikraman) activeSpecs.add("Pratikraman")
                                        if (specVaanchan) activeSpecs.add("Vaanchan")
                                        if (specBhakti) activeSpecs.add("Bhakti")
                                        if (specOther && specOtherText.isNotBlank()) activeSpecs.add(specOtherText)

                                        if (activeSpecs.isNotEmpty()) {
                                            @OptIn(ExperimentalLayoutApi::class)
                                            FlowRow(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                                verticalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                activeSpecs.forEach { specName ->
                                                    ChipPill(
                                                        text = specName,
                                                        textColor = ProfileGold,
                                                        borderColor = Color(0x60D4AF37)
                                                    )
                                                }
                                            }
                                        } else {
                                            Text(
                                                text = "None specified",
                                                style = MaterialTheme.typography.bodyMedium.copy(
                                                    fontSize = 13.sp,
                                                    color = ProfileMuted
                                                )
                                            )
                                        }
                                    }
                                }

                                // 3. Mandal Commitment & Active Status Card (Liquid Glass Emerald)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileGreen.copy(alpha = 0.50f),
                                                ProfileGreen.copy(alpha = 0.20f),
                                                ProfileGreen.copy(alpha = 0.40f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x700F261B), Color(0x450B1410))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Mandal Status & Guidelines",
                                            bulletColor = ProfileGreen,
                                            titleColor = ProfileGreen
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        MandalInfoRow(
                                            label = "Membership Status",
                                            value = "Active Swadhyai",
                                            valueColor = ProfileGreen
                                        )
                                        MandalInfoRow(
                                            label = "Mandal Code of Conduct",
                                            value = "Accepted & Verified",
                                            isLast = true
                                        )
                                    }
                                }
                            }
                        }

                        3 -> {
                            // Contact Tab Panel (Liquid Glass Teal Card)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(
                                        1.dp,
                                        Brush.linearGradient(
                                            listOf(
                                                ProfileTeal.copy(alpha = 0.50f),
                                                ProfileTeal.copy(alpha = 0.20f),
                                                ProfileTeal.copy(alpha = 0.40f)
                                            )
                                        )
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0x700E262A), Color(0x450A1518))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Contact & Address",
                                            bulletColor = ProfileTeal,
                                            titleColor = ProfileTeal
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        val whatsappDisplay = if (session.phone.isNotBlank()) "+91 ${session.phone}" else "Not specified"
                                        ContactInfoRow(
                                            icon = "📱",
                                            label = "WHATSAPP",
                                            value = whatsappDisplay
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        ContactInfoRow(
                                            icon = "☎️",
                                            label = "ALTERNATE CONTACT",
                                            value = contactNo.ifBlank { "Not specified" }
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        ContactInfoRow(
                                            icon = "✉️",
                                            label = "EMAIL",
                                            value = emailId.ifBlank { "Not specified" }
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        val fullAddr = listOf(address, city, state).filter { it.isNotBlank() }.joinToString(", ").let {
                                            if (pincode.isNotBlank()) "$it — $pincode" else it
                                        }.ifBlank { "Not specified" }
                                        ContactInfoRow(
                                            icon = "📍",
                                            label = "ADDRESS",
                                            value = fullAddr
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // Emergency Note Box (Liquid Glass Maroon)
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = Color(0x25B4425A),
                                            border = BorderStroke(1.dp, Color(0x60B4425A)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(text = "🚨", fontSize = 14.sp)
                                                val emName = emergencyName.ifBlank { "Not specified" }
                                                val emRel = emergencyRelation.ifBlank { "" }
                                                val emNo = emergencyContactNo.ifBlank { "" }
                                                val emergencyStr = if (emRel.isNotBlank() && emNo.isNotBlank()) {
                                                    "Emergency Contact: $emName ($emRel) — $emNo"
                                                } else if (emNo.isNotBlank()) {
                                                    "Emergency Contact: $emName — $emNo"
                                                } else {
                                                    "Emergency Contact: $emName"
                                                }
                                                Text(
                                                    text = emergencyStr,
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        color = Color(0xFFFFB4AB),
                                                        fontSize = 12.sp
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom spacer to clear the floating bottom navigation bar
            Spacer(modifier = Modifier.height(100.dp))
        }

            // 3. Pinned Header & Sliding Elements Layer
            // Header bar background matching Swadhyai window header (surfaceVariant with alpha)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(headerBarHeight)
                    .background(
                        MaterialTheme.colorScheme.surfaceVariant.copy(
                            alpha = (0.5f + (collapseFraction * 0.45f)).coerceIn(0.5f, 0.95f)
                        )
                    )
            )

            // Dissolving Old Header (Mandala Logo + "Profile" + "Name - Age")
            // Starts fully visible at the top, dissolves into nothingness as soon as scrolling begins
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .offset(x = 16.dp, y = 12.dp)
                    .graphicsLayer {
                        alpha = (1f - collapseFraction * 3.5f).coerceIn(0f, 1f)
                    }
            ) {
                Image(
                    painter = painterResource(id = R.drawable.header_logo),
                    contentDescription = "स्वाध्यायी मंडल लोगो",
                    modifier = Modifier.size(40.dp)
                )
                Column {
                    Text(
                        text = "Profile",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    val nameStr = fullName.ifBlank { session.fullName.ifBlank { "Harsh Shah" } }
                    val ageStr = age.ifBlank { "32" }
                    Text(
                        text = "$nameStr - $ageStr",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    )
                }
            }

            // Pinned Three-Dots Menu Button at Top Right
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = 4.dp, top = 8.dp)
            ) {
                IconButton(
                    onClick = { menuExpanded = !menuExpanded },
                    modifier = Modifier.testTag("profile_three_dots_menu")
                ) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = "More Options",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                DropdownMenu(
                    expanded = menuExpanded,
                    onDismissRequest = { menuExpanded = false },
                    modifier = Modifier
                        .background(ProfileDarkSurface)
                        .border(BorderStroke(1.dp, ProfileDarkBorder), RoundedCornerShape(14.dp))
                ) {
                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Edit Profile",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = ProfileCream
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = "Edit Profile",
                                tint = ProfileGold,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            showEditDialog = true
                        }
                    )

                    HorizontalDivider(color = ProfileDarkBorder, thickness = 0.6.dp)

                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Settings",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = ProfileCream
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Settings,
                                contentDescription = "Settings",
                                tint = ProfileGold,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            onNavigateToSettings()
                        },
                        modifier = Modifier.testTag("profile_menu_settings_item")
                    )

                    HorizontalDivider(color = ProfileDarkBorder, thickness = 0.6.dp)

                    DropdownMenuItem(
                        text = {
                            Text(
                                text = "Log Out",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                color = ProfileMaroon
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.AutoMirrored.Outlined.Logout,
                                contentDescription = "Log Out",
                                tint = ProfileMaroon,
                                modifier = Modifier.size(20.dp)
                            )
                        },
                        onClick = {
                            menuExpanded = false
                            showLogoutConfirmDialog = true
                        }
                    )
                }
            }

            // SLIDING AVATAR (Smooth continuous glide & scale from center hero -> top bar logo spot)
            Box(
                modifier = Modifier
                    .offset(x = currentAvatarX, y = currentAvatarY)
                    .size(currentAvatarSize)
                    .clip(CircleShape)
                    .background(
                        Brush.sweepGradient(
                            listOf(ProfileGold, ProfileGoldDeep, ProfileGold)
                        )
                    )
                    .padding(if (collapseFraction > 0.6f) 1.5.dp else 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                listOf(Color(0x38262012), ProfileDarkSurface2)
                            )
                        )
                        .border(if (collapseFraction > 0.6f) 1.dp else 2.dp, ProfileDarkBg, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = userInitials,
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            fontSize = currentInitialsFont,
                            color = ProfileGold
                        )
                    )
                }
            }

            // SLIDING NAME & SUBTITLE (Smooth continuous glide & scale from below hero avatar -> top bar title spot)
            Column(
                modifier = Modifier
                    .offset(x = currentTextX, y = currentTextY)
                    .widthIn(max = screenWidth - 116.dp)
                    .onSizeChanged { size ->
                        if (size.width > 0 && (textBlockWidthDp == 0.dp || collapseFraction == 0f)) {
                            textBlockWidthDp = with(density) { size.width.toDp() }
                        }
                    }
                    .graphicsLayer {
                        scaleX = textScale
                        scaleY = textScale
                        transformOrigin = TransformOrigin(0f, 0f)
                    },
                horizontalAlignment = Alignment.Start
            ) {
                Text(
                    text = fullName.ifBlank { "Nirav Kumar Shah" },
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        color = ProfileCream,
                        letterSpacing = 0.2.sp
                    ),
                    textAlign = TextAlign.Start,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = subtitleLine,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = subtitleColor,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    ),
                    textAlign = TextAlign.Start,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // STICKY / PINNED PANE (4 STAT BOXES + TAB SELECTOR ROW)
            // Starts at topSpacerHeight (240.dp) and glides smoothly up with scroll until reaching headerBarHeight (64.dp)
            val initialStickyPaneY = topSpacerHeight // 240.dp
            val currentScrollDp = with(density) { scrollState.value.toDp() }
            val currentStickyPaneY = (initialStickyPaneY - currentScrollDp).coerceAtLeast(headerBarHeight)
            val isPanePinned = currentStickyPaneY <= headerBarHeight

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = currentStickyPaneY)
                    .background(
                        if (isPanePinned) MaterialTheme.colorScheme.background.copy(alpha = 0.98f) else Color.Transparent
                    )
                    .padding(horizontal = 18.dp, vertical = if (isPanePinned) 6.dp else 0.dp)
            ) {
                // ---- 4 STAT BOXES (Paryushan, Yrs in Mandal, Specialities, Learnings) ----
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(statBoxesHeight),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    StatBox(
                        num = paryushanCount.ifBlank { "6" },
                        lbl = "PARYUSHAN",
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        num = displayYearsCount.toString(),
                        lbl = "YRS IN\nMANDAL",
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        num = displaySpecialitiesCount.toString(),
                        lbl = "SPECIALITIES",
                        modifier = Modifier.weight(1.05f)
                    )
                    StatBox(
                        num = displayLearningsCount.toString(),
                        lbl = "LEARNINGS",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // ---- TAB SELECTOR ROW (Liquid Glass Pill Bar) ----
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.Transparent,
                    border = BorderStroke(
                        1.dp,
                        Brush.linearGradient(
                            listOf(
                                ProfileGold.copy(alpha = if (isPanePinned) 0.60f else 0.40f),
                                ProfileGold.copy(alpha = 0.15f),
                                ProfileGold.copy(alpha = if (isPanePinned) 0.50f else 0.30f)
                            )
                        )
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    if (isPanePinned) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
                                    if (isPanePinned) MaterialTheme.colorScheme.surface.copy(alpha = 0.95f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.40f)
                                )
                            ),
                            RoundedCornerShape(24.dp)
                        )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TabPillButton(
                            text = "Personal",
                            selected = selectedTab == 0,
                            onClick = { coroutineScope.launch { pagerState.animateScrollToPage(0) } },
                            modifier = Modifier.weight(1f)
                        )
                        TabPillButton(
                            text = "Religious",
                            selected = selectedTab == 1,
                            onClick = { coroutineScope.launch { pagerState.animateScrollToPage(1) } },
                            modifier = Modifier.weight(1f)
                        )
                        TabPillButton(
                            text = "Mandal",
                            selected = selectedTab == 2,
                            onClick = { coroutineScope.launch { pagerState.animateScrollToPage(2) } },
                            modifier = Modifier.weight(1f)
                        )
                        TabPillButton(
                            text = "Contact",
                            selected = selectedTab == 3,
                            onClick = { coroutineScope.launch { pagerState.animateScrollToPage(3) } },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    // Edit Profile Full Dialog
    if (showEditDialog) {
        Dialog(
            onDismissRequest = { showEditDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            var editStep by remember { mutableIntStateOf(0) }
            val editPagerState = rememberPagerState(initialPage = 0, pageCount = { 3 })

            LaunchedEffect(editStep) {
                editPagerState.animateScrollToPage(editStep)
            }
            LaunchedEffect(editPagerState.currentPage) {
                editStep = editPagerState.currentPage
            }

            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ProfileDarkBg),
                color = ProfileDarkBg
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                ) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ProfileDarkSurface)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showEditDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = ProfileCream)
                            }
                            Text(
                                text = "Edit Profile",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = ProfileCream
                                )
                            )
                        }

                        Button(
                            onClick = { saveProfile() },
                            enabled = !isSaving,
                            colors = ButtonDefaults.buttonColors(containerColor = ProfileGold),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                            } else {
                                Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Edit Tabs
                    TabRow(
                        selectedTabIndex = editStep,
                        containerColor = ProfileDarkSurface2,
                        contentColor = ProfileGold
                    ) {
                        Tab(
                            selected = editStep == 0,
                            onClick = { editStep = 0 },
                            text = { Text("Personal", fontWeight = FontWeight.Bold, color = if (editStep == 0) ProfileGold else ProfileMuted) }
                        )
                        Tab(
                            selected = editStep == 1,
                            onClick = { editStep = 1 },
                            text = { Text("Contact", fontWeight = FontWeight.Bold, color = if (editStep == 1) ProfileGold else ProfileMuted) }
                        )
                        Tab(
                            selected = editStep == 2,
                            onClick = { editStep = 2 },
                            text = { Text("Religious", fontWeight = FontWeight.Bold, color = if (editStep == 2) ProfileGold else ProfileMuted) }
                        )
                    }

                    HorizontalPager(
                        state = editPagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) { page ->
                        when (page) {
                            0 -> PersonalDetailsStep(
                                fullName = fullName,
                                onFullNameChange = { fullName = it },
                                fatherName = fatherName,
                                onFatherNameChange = { fatherName = it },
                                motherName = motherName,
                                onMotherNameChange = { motherName = it },
                                dob = dob,
                                age = age,
                                onOpenDatePicker = {
                                    datePickerTarget = "dob"
                                    showDatePickerDialog = true
                                },
                                bloodGroup = bloodGroup,
                                onBloodGroupChange = { bloodGroup = it },
                                maritalStatus = maritalStatus,
                                onMaritalStatusChange = { maritalStatus = it },
                                anniversaryDate = anniversaryDate,
                                onOpenAnniversaryDatePicker = {
                                    datePickerTarget = "anniversary"
                                    showDatePickerDialog = true
                                },
                                education = education,
                                onEducationChange = { education = it },
                                workingStatus = workingStatus,
                                onWorkingStatusChange = { workingStatus = it },
                                otherProfession = otherProfession,
                                onOtherProfessionChange = { otherProfession = it },
                                workDescription = workDescription,
                                onWorkDescriptionChange = { workDescription = it },
                                onNext = { coroutineScope.launch { editPagerState.animateScrollToPage(1) } }
                            )

                            1 -> ContactDetailsStep(
                                whatsappNo = session.phone.ifBlank { "9876543210" },
                                contactNo = contactNo,
                                onContactNoChange = { contactNo = it },
                                emailId = emailId,
                                onEmailChange = { emailId = it },
                                emergencyName = emergencyName,
                                onEmergencyNameChange = { emergencyName = it },
                                emergencyRelation = emergencyRelation,
                                onEmergencyRelationChange = { emergencyRelation = it },
                                emergencyContactNo = emergencyContactNo,
                                onEmergencyContactNoChange = { emergencyContactNo = it },
                                address = address,
                                onAddressChange = { address = it },
                                state = state,
                                onStateChange = { state = it },
                                city = city,
                                onCityChange = { city = it },
                                pincode = pincode,
                                onPincodeChange = { pincode = it },
                                onBack = { coroutineScope.launch { editPagerState.animateScrollToPage(0) } },
                                onNext = { coroutineScope.launch { editPagerState.animateScrollToPage(2) } }
                            )

                            2 -> ReligiousDetailsStep(
                                subMandirDohe = subMandirDohe,
                                onSubMandirDoheChange = { subMandirDohe = it },
                                subMandirChaitya = subMandirChaitya,
                                onSubMandirChaityaChange = { subMandirChaitya = it },
                                sub2Vanditu = sub2Vanditu,
                                onSub2VandituChange = { sub2Vanditu = it },
                                sub2Jagchintamani = sub2Jagchintamani,
                                onSub2JagchintamaniChange = { sub2Jagchintamani = it },
                                sub2Bharser = sub2Bharser,
                                onSub2BharserChange = { sub2Bharser = it },
                                sub2LaghuShanti = sub2LaghuShanti,
                                onSub2LaghuShantiChange = { sub2LaghuShanti = it },
                                sub2SakalaTirth = sub2SakalaTirth,
                                onSub2SakalaTirthChange = { sub2SakalaTirth = it },
                                sub5Saklarhat = sub5Saklarhat,
                                onSub5SaklarhatChange = { sub5Saklarhat = it },
                                sub5Snatasya = sub5Snatasya,
                                onSub5SnatasyaChange = { sub5Snatasya = it },
                                sub5Atichar = sub5Atichar,
                                onSub5AticharChange = { sub5Atichar = it },
                                sub5AjitShanti = sub5AjitShanti,
                                onSub5AjitShantiChange = { sub5AjitShanti = it },
                                sub5BadiShanti = sub5BadiShanti,
                                onSub5BadiShantiChange = { sub5BadiShanti = it },
                                sub5Santikaram = sub5Santikaram,
                                onSub5SantikaramChange = { sub5Santikaram = it },
                                otherLearnings = otherLearnings,
                                onOtherLearningsChange = { otherLearnings = it },
                                specPratikraman = specPratikraman,
                                onSpecPratikramanChange = { specPratikraman = it },
                                specVaanchan = specVaanchan,
                                onSpecVaanchanChange = { specVaanchan = it },
                                specBhakti = specBhakti,
                                onSpecBhaktiChange = { specBhakti = it },
                                specOther = specOther,
                                onSpecOtherChange = { specOther = it },
                                specOtherText = specOtherText,
                                onSpecOtherTextChange = { specOtherText = it },
                                joiningYear = joiningYear,
                                onJoiningYearChange = { joiningYear = it },
                                paryushanCount = paryushanCount,
                                onParyushanCountChange = { paryushanCount = it },
                                isParyushanCountLocked = !session.isAdmin,
                                anotherGroup = anotherGroup,
                                onAnotherGroupChange = { anotherGroup = it },
                                postInGroup = postInGroup,
                                onPostInGroupChange = { postInGroup = it },
                                actNavkarshi = actNavkarshi,
                                onActNavkarshiChange = { actNavkarshi = it },
                                actPrabhuPujan = actPrabhuPujan,
                                onActPrabhuPujanChange = { actPrabhuPujan = it },
                                actRatriBhojanTyag = actRatriBhojanTyag,
                                onActRatriBhojanTyagChange = { actRatriBhojanTyag = it },
                                actTithiPalan = actTithiPalan,
                                onActTithiPalanChange = { actTithiPalan = it },
                                actNavkarPakkiMala = actNavkarPakkiMala,
                                onActNavkarPakkiMalaChange = { actNavkarPakkiMala = it },
                                actSamaiyk = actSamaiyk,
                                onActSamaiykChange = { actSamaiyk = it },
                                actPratikaman = actPratikaman,
                                onActPratikamanChange = { actPratikaman = it },
                                otherDailyActivities = otherDailyActivities,
                                onOtherDailyActivitiesChange = { otherDailyActivities = it },
                                lifetimeTapasyaList = lifetimeTapasyaList,
                                onLifetimeTapasyaListChange = { lifetimeTapasyaList = it },
                                isSubmitting = isSaving,
                                onBack = { coroutineScope.launch { editPagerState.animateScrollToPage(1) } },
                                onSubmit = { saveProfile() }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("Log Out Confirmation", fontWeight = FontWeight.Bold, color = ProfileCream) },
            text = { Text("Are you sure you want to log out from Shree Vardhman Swadhyai Sangh?", color = ProfileMuted) },
            containerColor = ProfileDarkSurface,
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        UserSessionManager.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProfileMaroon)
                ) {
                    Text("Log Out", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("Cancel", color = ProfileCream)
                }
            }
        )
    }

    if (showDatePickerDialog) {
        CustomJainDatePickerDialog(
            title = if (datePickerTarget == "dob") "Select Date of Birth" else "Select Anniversary Date",
            onDateSelected = { dateStr ->
                if (datePickerTarget == "dob") {
                    dob = dateStr
                } else {
                    anniversaryDate = dateStr
                }
                showDatePickerDialog = false
            },
            onDismiss = { showDatePickerDialog = false }
        )
    }
}

@Composable
private fun StatBox(
    num: String,
    lbl: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color.Transparent,
        border = BorderStroke(
            1.dp,
            Brush.linearGradient(
                listOf(
                    ProfileGold.copy(alpha = 0.45f),
                    ProfileGold.copy(alpha = 0.15f),
                    ProfileGold.copy(alpha = 0.35f)
                )
            )
        ),
        modifier = modifier
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0x752A2012),
                        Color(0x4516120B)
                    )
                ),
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = num,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = ProfileGold
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = lbl,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.3.sp,
                    lineHeight = 11.sp
                ),
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun MandalInfoRow(
    label: String,
    value: String,
    valueColor: Color = ProfileCream,
    isLast: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = ProfileMuted
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = valueColor
                ),
                textAlign = TextAlign.End
            )
        }
        if (!isLast) {
            HorizontalDivider(
                color = ProfileDarkBorder.copy(alpha = 0.6f),
                thickness = 0.6.dp
            )
        }
    }
}

@Composable
private fun TabPillButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .then(
                if (selected) {
                    Modifier.background(
                        Brush.horizontalGradient(
                            listOf(ProfileGoldDeep, ProfileGold)
                        )
                    )
                } else {
                    Modifier.background(Color.Transparent)
                }
            )
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Bold,
                fontSize = 12.5.sp,
                color = if (selected) Color(0xFF1A1305) else ProfileMuted
            )
        )
    }
}

@Composable
private fun CardHeaderRow(
    title: String,
    bulletColor: Color,
    titleColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(bulletColor)
        )
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.5.sp,
                letterSpacing = 1.1.sp,
                color = titleColor
            )
        )
    }
}

@Composable
private fun InfoGridItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                color = ProfileMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = ProfileCream
            )
        )
    }
}

@Composable
private fun LearningSectionItem(
    title: String,
    countStr: String,
    subItems: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = ProfileCream
                )
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = ProfileGreen,
                contentColor = Color(0xFF08130F)
            ) {
                Text(
                    text = countStr,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = subItems,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 12.sp,
                color = ProfileMuted,
                lineHeight = 17.sp
            )
        )
    }
}

@Composable
private fun ChipPill(
    text: String,
    textColor: Color,
    borderColor: Color
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0x08FFFFFF),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                color = textColor
            ),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun ContactInfoRow(
    icon: String,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0x0AFFFFFF),
            border = BorderStroke(1.dp, ProfileDarkBorder),
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = icon, fontSize = 14.sp)
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.4.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileCream
                )
            )
        }
    }
}
