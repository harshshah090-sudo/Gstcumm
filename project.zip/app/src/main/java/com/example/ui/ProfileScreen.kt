package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.data.UserSessionManager
import com.example.ui.theme.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: FormViewModel,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToSanghRegistrations: () -> Unit = {},
    onNavigateToSwadhyaiRegistrations: () -> Unit = {},
    onNavigateToFund: () -> Unit = {},
    onNavigateToPanchang: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val session by UserSessionManager.sessionState.collectAsStateWithLifecycle()
    val hasRedDot by UserSessionManager.hasNewQuestionRedDot.collectAsStateWithLifecycle()

    val swadhyaiForms by viewModel.allSwadhyaiForms.collectAsStateWithLifecycle()

    // Find current user's profile entity
    val userProfileEntity = remember(session.phone, swadhyaiForms) {
        val clean = session.phone.takeLast(10)
        swadhyaiForms.firstOrNull { it.whatsappNo.takeLast(10) == clean } ?: session.profileData
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Personal, 1: Contact, 2: Religious
    val pagerState = rememberPagerState(initialPage = 0, pageCount = { 3 })

    LaunchedEffect(selectedTab) {
        pagerState.animateScrollToPage(selectedTab)
    }
    LaunchedEffect(pagerState.currentPage) {
        selectedTab = pagerState.currentPage
    }

    // Editable profile fields
    var fullName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.fullName ?: session.fullName) }
    var fatherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.fatherName ?: "") }
    var motherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.motherName ?: "") }
    var dob by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.dob ?: "") }
    var age by remember(userProfileEntity) { mutableStateOf(if ((userProfileEntity?.age ?: 0) > 0) userProfileEntity!!.age.toString() else "") }
    var bloodGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.bloodGroup ?: "") }
    var maritalStatus by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.maritalStatus ?: "Unmarried") }
    var anniversaryDate by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anniversaryDate ?: "") }
    var education by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.education ?: "") }
    
    var workingStatus by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: ""
        mutableStateOf(if (stat.startsWith("Other: ")) "Others" else stat)
    }
    var otherProfession by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: ""
        mutableStateOf(if (stat.startsWith("Other: ")) stat.removePrefix("Other: ") else "")
    }
    var workDescription by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.workDescription ?: "") }

    var contactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.contactNo ?: "") }
    var emailId by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.email ?: "") }
    var emergencyName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactName ?: "") }
    var emergencyRelation by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactRelation ?: "") }
    var emergencyContactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactNo ?: "") }
    var address by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.address ?: "") }
    var state by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.state?.ifBlank { "Madhya Pradesh" } ?: "Madhya Pradesh") }
    var city by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.city?.ifBlank { "Indore" } ?: "Indore") }
    var pincode by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.pincode ?: "") }

    // Religious
    val learnings = userProfileEntity?.religiousLearnings ?: ""
    var subMandirDohe by remember(learnings) { mutableStateOf(learnings.contains("Asht Prakari Puja ke Dohe")) }
    var subMandirChaitya by remember(learnings) { mutableStateOf(learnings.contains("Chaityawandan Vidhi")) }
    var sub2Vanditu by remember(learnings) { mutableStateOf(learnings.contains("Vanditu")) }
    var sub2Jagchintamani by remember(learnings) { mutableStateOf(learnings.contains("Jagchintamani")) }
    var sub2Bharser by remember(learnings) { mutableStateOf(learnings.contains("Bharser")) }
    var sub2LaghuShanti by remember(learnings) { mutableStateOf(learnings.contains("Laghu Shanti")) }
    var sub2SakalaTirth by remember(learnings) { mutableStateOf(learnings.contains("Sakala Tirth")) }
    var sub5Saklarhat by remember(learnings) { mutableStateOf(learnings.contains("Saklarhat")) }
    var sub5Snatasya by remember(learnings) { mutableStateOf(learnings.contains("Snatasya")) }
    var sub5Atichar by remember(learnings) { mutableStateOf(learnings.contains("Atichar")) }
    var sub5AjitShanti by remember(learnings) { mutableStateOf(learnings.contains("Ajit Shanti")) }
    var sub5BadiShanti by remember(learnings) { mutableStateOf(learnings.contains("Badi Shanti")) }
    var sub5Santikaram by remember(learnings) { mutableStateOf(learnings.contains("Santikaram")) }

    var otherLearnings by remember(learnings) {
        val extra = learnings.lines().filter { it.startsWith("Other:") || it.startsWith("  ✔ ") }.map { it.replace("Other:", "").replace("  ✔ ", "").trim() }.filter { it.isNotBlank() }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    val specs = (userProfileEntity?.specialities ?: "").split(",").map { it.trim() }
    var specPratikraman by remember(specs) { mutableStateOf(specs.any { it.equals("Pratikraman", true) }) }
    var specVaanchan by remember(specs) { mutableStateOf(specs.any { it.equals("Vaanchan", true) || it.equals("Vaachna", true) }) }
    var specBhakti by remember(specs) { mutableStateOf(specs.any { it.equals("Bhakti", true) }) }
    var specOther by remember(specs) { mutableStateOf(specs.any { it.startsWith("Other: ") }) }
    var specOtherText by remember(specs) { mutableStateOf(specs.firstOrNull { it.startsWith("Other: ") }?.removePrefix("Other: ") ?: "") }

    var joiningYear by remember(userProfileEntity) { mutableStateOf(if ((userProfileEntity?.joiningYear ?: 0) > 0) userProfileEntity!!.joiningYear.toString() else "") }
    var paryushanCount by remember(userProfileEntity) { mutableStateOf((userProfileEntity?.paryushanCount ?: 0).toString()) }

    var anotherGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anotherGroup ?: "") }
    var postInGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.postInGroup ?: "") }

    val acts = (userProfileEntity?.dailyRoutineActivities ?: "").split(",").map { it.trim() }
    var actNavkarshi by remember(acts) { mutableStateOf(acts.any { it.equals("Navkarshi", true) }) }
    var actPrabhuPujan by remember(acts) { mutableStateOf(acts.any { it.equals("Prabhu Pujan", true) }) }
    var actRatriBhojanTyag by remember(acts) { mutableStateOf(acts.any { it.equals("Ratri Bhojan Tyag", true) }) }
    var actTithiPalan by remember(acts) { mutableStateOf(acts.any { it.equals("Tithi Palan", true) }) }
    var actNavkarPakkiMala by remember(acts) { mutableStateOf(acts.any { it.equals("Navkar Pakki Mala", true) }) }
    var actSamaiyk by remember(acts) { mutableStateOf(acts.any { it.equals("Samaiyk", true) }) }
    var actPratikaman by remember(acts) { mutableStateOf(acts.any { it.equals("Pratikaman", true) }) }
    var otherDailyActivities by remember(userProfileEntity) {
        val extra = acts.filter { it.startsWith("Other: ") }.map { it.removePrefix("Other: ") }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    var lifetimeTapasyaList by remember(userProfileEntity) {
        val tap = (userProfileEntity?.lifetimeTapasya ?: "").split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
        mutableStateOf(if (tap.isNotEmpty()) tap else listOf(""))
    }

    var isSaving by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var datePickerTarget by remember { mutableStateOf("dob") }

    fun saveProfile() {
        val cleanPhone = session.phone.takeLast(10)
        isSaving = true

        coroutineScope.launch {
            val specialitiesList = mutableListOf<String>()
            if (specPratikraman) specialitiesList.add("Pratikraman")
            if (specVaanchan) specialitiesList.add("Vaanchan")
            if (specBhakti) specialitiesList.add("Bhakti")
            if (specOther && specOtherText.isNotBlank()) specialitiesList.add("Other: $specOtherText")

            val religiousLearningsList = mutableListOf<String>()
            if (subMandirDohe) religiousLearningsList.add("Asht Prakari Puja ke Dohe")
            if (subMandirChaitya) religiousLearningsList.add("Chaityawandan Vidhi")
            if (sub2Vanditu) religiousLearningsList.add("Vanditu")
            if (sub2Jagchintamani) religiousLearningsList.add("Jagchintamani Chaityawandan")
            if (sub2Bharser) religiousLearningsList.add("Bharser Sajjhay")
            if (sub2LaghuShanti) religiousLearningsList.add("Laghu Shanti")
            if (sub2SakalaTirth) religiousLearningsList.add("Sakala Tirth")
            if (sub5Saklarhat) religiousLearningsList.add("Saklarhat Chaityawandan")
            if (sub5Snatasya) religiousLearningsList.add("Snatasya Thui")
            if (sub5Atichar) religiousLearningsList.add("Atichar")
            if (sub5AjitShanti) religiousLearningsList.add("Ajit Shanti")
            if (sub5BadiShanti) religiousLearningsList.add("Badi Shanti")
            if (sub5Santikaram) religiousLearningsList.add("Santikaram")
            otherLearnings.filter { it.isNotBlank() }.forEach { religiousLearningsList.add("Other: $it") }

            val dailyActivitiesList = mutableListOf<String>()
            if (actNavkarshi) dailyActivitiesList.add("Navkarshi")
            if (actPrabhuPujan) dailyActivitiesList.add("Prabhu Pujan")
            if (actRatriBhojanTyag) dailyActivitiesList.add("Ratri Bhojan Tyag")
            if (actTithiPalan) dailyActivitiesList.add("Tithi Palan")
            if (actNavkarPakkiMala) dailyActivitiesList.add("Navkar Pakki Mala")
            if (actSamaiyk) dailyActivitiesList.add("Samaiyk")
            if (actPratikaman) dailyActivitiesList.add("Pratikaman")

            val lifetimeList = lifetimeTapasyaList.filter { it.isNotBlank() }

            val pCount = paryushanCount.toIntOrNull() ?: 0
            val jYear = joiningYear.toIntOrNull() ?: 0
            val userAge = age.toIntOrNull() ?: 0

            val workVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) "Other: $otherProfession" else workingStatus

            val updatedEntity = SwadhyaiFormEntity(
                id = userProfileEntity?.id ?: 0L,
                firestoreDocId = "phone_$cleanPhone",
                fullName = fullName.trim(),
                fatherName = fatherName.trim(),
                motherName = motherName.trim(),
                gender = userProfileEntity?.gender ?: "Male",
                dob = dob.trim(),
                age = userAge,
                bloodGroup = bloodGroup.trim(),
                maritalStatus = maritalStatus,
                anniversaryDate = if (maritalStatus == "Married") anniversaryDate.trim() else "",
                email = emailId.trim(),
                whatsappNo = cleanPhone,
                contactNo = contactNo.trim(),
                emergencyContactName = emergencyName.trim(),
                emergencyContactRelation = emergencyRelation.trim(),
                emergencyContactNo = emergencyContactNo.trim(),
                address = address.trim(),
                city = city.trim(),
                pincode = pincode.trim(),
                state = state.trim(),
                education = education.trim(),
                workingStatus = workVal.trim(),
                workDescription = workDescription.trim(),
                joiningYear = jYear,
                specialities = specialitiesList.joinToString(", "),
                religiousLearnings = religiousLearningsList.joinToString("\n"),
                anotherGroup = anotherGroup.trim(),
                postInGroup = postInGroup.trim(),
                paryushanCount = pCount,
                dailyRoutineActivities = dailyActivitiesList.joinToString(", "),
                lifetimeTapasya = lifetimeList.joinToString(", "),
                acceptedRules = true
            )

            withContext(Dispatchers.IO) {
                try {
                    val db = FirebaseFirestore.getInstance()
                    val map = hashMapOf(
                        "fullName" to updatedEntity.fullName,
                        "fatherName" to updatedEntity.fatherName,
                        "motherName" to updatedEntity.motherName,
                        "dob" to updatedEntity.dob,
                        "age" to updatedEntity.age,
                        "bloodGroup" to updatedEntity.bloodGroup,
                        "maritalStatus" to updatedEntity.maritalStatus,
                        "anniversaryDate" to updatedEntity.anniversaryDate,
                        "whatsappNo" to cleanPhone,
                        "contactNo" to updatedEntity.contactNo,
                        "emailId" to updatedEntity.email,
                        "emergencyContactName" to updatedEntity.emergencyContactName,
                        "emergencyContactRelation" to updatedEntity.emergencyContactRelation,
                        "emergencyContactNo" to updatedEntity.emergencyContactNo,
                        "address" to updatedEntity.address,
                        "city" to updatedEntity.city,
                        "pincode" to updatedEntity.pincode,
                        "state" to updatedEntity.state,
                        "education" to updatedEntity.education,
                        "workingStatus" to updatedEntity.workingStatus,
                        "workDescription" to updatedEntity.workDescription,
                        "joiningYear" to updatedEntity.joiningYear,
                        "specialities" to specialitiesList,
                        "religiousLearnings" to religiousLearningsList,
                        "anotherGroup" to updatedEntity.anotherGroup,
                        "postInGroup" to updatedEntity.postInGroup,
                        "dailyRoutineActivities" to dailyActivitiesList,
                        "lifetimeTapasya" to lifetimeList,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    db.collection("swadhyai_forms").document("phone_$cleanPhone").set(map, SetOptions.merge())
                } catch (_: Exception) {}
            }

            UserSessionManager.updateProfileData(updatedEntity)
            isSaving = false
            Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(40.dp)
                        )
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "My Profile / प्रोफ़ाइल",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                )
                                if (session.isAdmin) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = AppPrimaryGold.copy(alpha = 0.2f),
                                        border = BorderStroke(0.6.dp, AppPrimaryGold)
                                    ) {
                                        Text("ADMIN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = AppPrimaryGold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }
                            Text(
                                text = "WhatsApp: +91 ${session.phone}",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showLogoutConfirmDialog = true }) {
                        Icon(Icons.Default.Logout, contentDescription = "Log Out", tint = MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = AppSurface),
                modifier = Modifier.testTag("profile_top_bar")
            )
        },
        containerColor = AppBackground,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // User Greeting & Summary Header Banner
            Surface(
                color = AppDeepSurface,
                border = BorderStroke(1.dp, AppBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = if (fullName.isNotBlank()) fullName else "Swadhyai",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = AppTextPrimary
                            )
                        )
                        Text(
                            text = if (city.isNotBlank()) "$city, $state" else state,
                            style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                        )
                    }

                    Button(
                        onClick = { saveProfile() },
                        enabled = !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = AppPrimaryGold),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        if (isSaving) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White)
                        } else {
                            Icon(Icons.Default.Save, contentDescription = "Save", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Tabs for horizontal page swipe
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = AppSurface,
                contentColor = AppPrimaryGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = AppPrimaryGold
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Personal", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Contact", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("Religious", fontWeight = FontWeight.Bold)
                            if (hasRedDot) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFE53935))
                                )
                            }
                        }
                    }
                )
            }

            HorizontalPager(
                state = pagerState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) { page ->
                when (page) {
                    0 -> PersonalDetailsStep(
                        fullName = fullName,
                        onFullNameChange = { fullName = it },
                        fatherName = fatherName,
                        onFatherNameChange = { fatherName = it },
                        motherName = motherName,
                        onMotherNameChange = { motherName = it },
                        dob = dob,
                        age = age,
                        onOpenDatePicker = {
                            datePickerTarget = "dob"
                            showDatePickerDialog = true
                        },
                        bloodGroup = bloodGroup,
                        onBloodGroupChange = { bloodGroup = it },
                        maritalStatus = maritalStatus,
                        onMaritalStatusChange = { maritalStatus = it },
                        anniversaryDate = anniversaryDate,
                        onOpenAnniversaryDatePicker = {
                            datePickerTarget = "anniversary"
                            showDatePickerDialog = true
                        },
                        education = education,
                        onEducationChange = { education = it },
                        workingStatus = workingStatus,
                        onWorkingStatusChange = { workingStatus = it },
                        otherProfession = otherProfession,
                        onOtherProfessionChange = { otherProfession = it },
                        workDescription = workDescription,
                        onWorkDescriptionChange = { workDescription = it },
                        onNext = { coroutineScope.launch { pagerState.animateScrollToPage(1) } }
                    )

                    1 -> ContactDetailsStep(
                        whatsappNo = session.phone,
                        contactNo = contactNo,
                        onContactNoChange = { contactNo = it },
                        emailId = emailId,
                        onEmailChange = { emailId = it },
                        emergencyName = emergencyName,
                        onEmergencyNameChange = { emergencyName = it },
                        emergencyRelation = emergencyRelation,
                        onEmergencyRelationChange = { emergencyRelation = it },
                        emergencyContactNo = emergencyContactNo,
                        onEmergencyContactNoChange = { emergencyContactNo = it },
                        address = address,
                        onAddressChange = { address = it },
                        state = state,
                        onStateChange = { state = it },
                        city = city,
                        onCityChange = { city = it },
                        pincode = pincode,
                        onPincodeChange = { pincode = it },
                        onBack = { coroutineScope.launch { pagerState.animateScrollToPage(0) } },
                        onNext = { coroutineScope.launch { pagerState.animateScrollToPage(2) } }
                    )

                    2 -> ReligiousDetailsStep(
                        subMandirDohe = subMandirDohe,
                        onSubMandirDoheChange = { subMandirDohe = it },
                        subMandirChaitya = subMandirChaitya,
                        onSubMandirChaityaChange = { subMandirChaitya = it },
                        sub2Vanditu = sub2Vanditu,
                        onSub2VandituChange = { sub2Vanditu = it },
                        sub2Jagchintamani = sub2Jagchintamani,
                        onSub2JagchintamaniChange = { sub2Jagchintamani = it },
                        sub2Bharser = sub2Bharser,
                        onSub2BharserChange = { sub2Bharser = it },
                        sub2LaghuShanti = sub2LaghuShanti,
                        onSub2LaghuShantiChange = { sub2LaghuShanti = it },
                        sub2SakalaTirth = sub2SakalaTirth,
                        onSub2SakalaTirthChange = { sub2SakalaTirth = it },
                        sub5Saklarhat = sub5Saklarhat,
                        onSub5SaklarhatChange = { sub5Saklarhat = it },
                        sub5Snatasya = sub5Snatasya,
                        onSub5SnatasyaChange = { sub5Snatasya = it },
                        sub5Atichar = sub5Atichar,
                        onSub5AticharChange = { sub5Atichar = it },
                        sub5AjitShanti = sub5AjitShanti,
                        onSub5AjitShantiChange = { sub5AjitShanti = it },
                        sub5BadiShanti = sub5BadiShanti,
                        onSub5BadiShantiChange = { sub5BadiShanti = it },
                        sub5Santikaram = sub5Santikaram,
                        onSub5SantikaramChange = { sub5Santikaram = it },
                        otherLearnings = otherLearnings,
                        onOtherLearningsChange = { otherLearnings = it },
                        specPratikraman = specPratikraman,
                        onSpecPratikramanChange = { specPratikraman = it },
                        specVaanchan = specVaanchan,
                        onSpecVaanchanChange = { specVaanchan = it },
                        specBhakti = specBhakti,
                        onSpecBhaktiChange = { specBhakti = it },
                        specOther = specOther,
                        onSpecOtherChange = { specOther = it },
                        specOtherText = specOtherText,
                        onSpecOtherTextChange = { specOtherText = it },
                        joiningYear = joiningYear,
                        onJoiningYearChange = { joiningYear = it },
                        paryushanCount = paryushanCount,
                        onParyushanCountChange = { paryushanCount = it },
                        isParyushanCountLocked = !session.isAdmin,
                        anotherGroup = anotherGroup,
                        onAnotherGroupChange = { anotherGroup = it },
                        postInGroup = postInGroup,
                        onPostInGroupChange = { postInGroup = it },
                        actNavkarshi = actNavkarshi,
                        onActNavkarshiChange = { actNavkarshi = it },
                        actPrabhuPujan = actPrabhuPujan,
                        onActPrabhuPujanChange = { actPrabhuPujan = it },
                        actRatriBhojanTyag = actRatriBhojanTyag,
                        onActRatriBhojanTyagChange = { actRatriBhojanTyag = it },
                        actTithiPalan = actTithiPalan,
                        onActTithiPalanChange = { actTithiPalan = it },
                        actNavkarPakkiMala = actNavkarPakkiMala,
                        onActNavkarPakkiMalaChange = { actNavkarPakkiMala = it },
                        actSamaiyk = actSamaiyk,
                        onActSamaiykChange = { actSamaiyk = it },
                        actPratikaman = actPratikaman,
                        onActPratikamanChange = { actPratikaman = it },
                        otherDailyActivities = otherDailyActivities,
                        onOtherDailyActivitiesChange = { otherDailyActivities = it },
                        lifetimeTapasyaList = lifetimeTapasyaList,
                        onLifetimeTapasyaListChange = { lifetimeTapasyaList = it },
                        isSubmitting = isSaving,
                        onBack = { coroutineScope.launch { pagerState.animateScrollToPage(1) } },
                        onSubmit = { saveProfile() }
                    )
                }
            }

            // Bottom Log Out Button Bar
            Surface(
                color = AppDeepSurface,
                border = BorderStroke(1.dp, AppBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 72.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Sign out from this device",
                        style = MaterialTheme.typography.bodySmall.copy(color = AppTextMuted)
                    )

                    OutlinedButton(
                        onClick = { showLogoutConfirmDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f)),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Log Out", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("Log Out Confirmation", fontWeight = FontWeight.Bold) },
            text = { Text("Are you sure you want to log out from Shree Vardhman Swadhyai Sangh?") },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        UserSessionManager.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Log Out", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    if (showDatePickerDialog) {
        CustomJainDatePickerDialog(
            title = if (datePickerTarget == "dob") "Select Date of Birth" else "Select Anniversary Date",
            onDateSelected = { dateStr ->
                if (datePickerTarget == "dob") {
                    dob = dateStr
                } else {
                    anniversaryDate = dateStr
                }
                showDatePickerDialog = false
            },
            onDismiss = { showDatePickerDialog = false }
        )
    }
}
