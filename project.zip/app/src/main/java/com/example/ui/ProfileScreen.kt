package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.SwadhyaiFormEntity
import com.example.data.UserSessionManager
import com.example.ui.theme.*
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// HTML-matched Color Palette
private val ProfileDarkBg = Color(0xFF0B0D0B)
private val ProfileDarkSurface = Color(0xFF151815)
private val ProfileDarkSurface2 = Color(0xFF1B1F1B)
private val ProfileDarkBorder = Color(0xFF2A2E29)
private val ProfileGold = Color(0xFFE3B24E)
private val ProfileGoldDeep = Color(0xFFC79730)
private val ProfileCream = Color(0xFFF4E9CF)
private val ProfileMuted = Color(0xFF8A8E86)
private val ProfileMaroon = Color(0xFFB4425A)
private val ProfileGreen = Color(0xFF3FAE7E)
private val ProfileTeal = Color(0xFF2FB5C4)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel: FormViewModel,
    onNavigateToSettings: () -> Unit = {},
    onNavigateToSanghRegistrations: () -> Unit = {},
    onNavigateToSwadhyaiRegistrations: () -> Unit = {},
    onNavigateToFund: () -> Unit = {},
    onNavigateToPanchang: () -> Unit = {},
    onLogout: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val session by UserSessionManager.sessionState.collectAsStateWithLifecycle()

    val swadhyaiForms by viewModel.allSwadhyaiForms.collectAsStateWithLifecycle()

    // Find current user's profile entity
    val userProfileEntity = remember(session.phone, swadhyaiForms) {
        val clean = session.phone.takeLast(10)
        swadhyaiForms.firstOrNull { it.whatsappNo.takeLast(10) == clean } ?: session.profileData
    }

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Personal, 1: Religious, 2: Contact

    // Editable profile fields
    var fullName by remember(userProfileEntity, session.fullName) {
        mutableStateOf(userProfileEntity?.fullName?.ifBlank { session.fullName } ?: session.fullName.ifBlank { "Nirav Kumar Shah" })
    }
    var fatherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.fatherName ?: "Mahendra Kumar Shah") }
    var motherName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.motherName ?: "Kanta Shah") }
    var dob by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.dob ?: "14 Aug 1994") }
    var age by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.age ?: 0) > 0) userProfileEntity!!.age.toString() else "32")
    }
    var bloodGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.bloodGroup ?: "B+") }
    var maritalStatus by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.maritalStatus ?: "Married") }
    var anniversaryDate by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anniversaryDate ?: "2 Feb 2020") }
    var education by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.education ?: "B.Com, Chartered Accountant") }

    var workingStatus by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: "Business — Textile Trading (Family Business)"
        mutableStateOf(if (stat.startsWith("Other: ")) "Others" else stat)
    }
    var otherProfession by remember(userProfileEntity) {
        val stat = userProfileEntity?.workingStatus ?: ""
        mutableStateOf(if (stat.startsWith("Other: ")) stat.removePrefix("Other: ") else "")
    }
    var workDescription by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.workDescription ?: "") }

    var contactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.contactNo ?: "+91 98765 43211") }
    var emailId by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.email ?: "nirav.shah@example.com") }
    var emergencyName by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactName ?: "Mahendra Shah") }
    var emergencyRelation by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactRelation ?: "Father") }
    var emergencyContactNo by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.emergencyContactNo ?: "+91 98765 43212") }
    var address by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.address ?: "24, Snehnagar Society") }
    var state by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.state?.ifBlank { "Madhya Pradesh" } ?: "Madhya Pradesh") }
    var city by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.city?.ifBlank { "Indore" } ?: "Indore") }
    var pincode by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.pincode ?: "452001") }

    // Religious
    val learnings = userProfileEntity?.religiousLearnings ?: "Asht Prakari Puja ke Dohe\nChaityawandan Vidhi\nVanditu\nJagchintamani Chaityawandan\nBharser Sajjhay\nSaklarhat Chaityawandan\nAjit Shanti"
    var subMandirDohe by remember(learnings) { mutableStateOf(learnings.contains("Asht Prakari Puja ke Dohe")) }
    var subMandirChaitya by remember(learnings) { mutableStateOf(learnings.contains("Chaityawandan Vidhi")) }
    var sub2Vanditu by remember(learnings) { mutableStateOf(learnings.contains("Vanditu")) }
    var sub2Jagchintamani by remember(learnings) { mutableStateOf(learnings.contains("Jagchintamani")) }
    var sub2Bharser by remember(learnings) { mutableStateOf(learnings.contains("Bharser")) }
    var sub2LaghuShanti by remember(learnings) { mutableStateOf(learnings.contains("Laghu Shanti")) }
    var sub2SakalaTirth by remember(learnings) { mutableStateOf(learnings.contains("Sakala Tirth")) }
    var sub5Saklarhat by remember(learnings) { mutableStateOf(learnings.contains("Saklarhat")) }
    var sub5Snatasya by remember(learnings) { mutableStateOf(learnings.contains("Snatasya")) }
    var sub5Atichar by remember(learnings) { mutableStateOf(learnings.contains("Atichar")) }
    var sub5AjitShanti by remember(learnings) { mutableStateOf(learnings.contains("Ajit Shanti")) }
    var sub5BadiShanti by remember(learnings) { mutableStateOf(learnings.contains("Badi Shanti")) }
    var sub5Santikaram by remember(learnings) { mutableStateOf(learnings.contains("Santikaram")) }

    var otherLearnings by remember(learnings) {
        val extra = learnings.lines().filter { it.startsWith("Other:") || it.startsWith("  ✔ ") }.map { it.replace("Other:", "").replace("  ✔ ", "").trim() }.filter { it.isNotBlank() }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    val specs = (userProfileEntity?.specialities ?: "Pratikraman, Vaanchan, Bhakti").split(",").map { it.trim() }
    var specPratikraman by remember(specs) { mutableStateOf(specs.any { it.equals("Pratikraman", true) }) }
    var specVaanchan by remember(specs) { mutableStateOf(specs.any { it.equals("Vaanchan", true) || it.equals("Vaachna", true) }) }
    var specBhakti by remember(specs) { mutableStateOf(specs.any { it.equals("Bhakti", true) }) }
    var specOther by remember(specs) { mutableStateOf(specs.any { it.startsWith("Other: ") }) }
    var specOtherText by remember(specs) { mutableStateOf(specs.firstOrNull { it.startsWith("Other: ") }?.removePrefix("Other: ") ?: "") }

    var joiningYear by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.joiningYear ?: 0) > 0) userProfileEntity!!.joiningYear.toString() else "2015")
    }
    var paryushanCount by remember(userProfileEntity) {
        mutableStateOf(if ((userProfileEntity?.paryushanCount ?: 0) > 0) userProfileEntity!!.paryushanCount.toString() else "6")
    }

    var anotherGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.anotherGroup ?: "") }
    var postInGroup by remember(userProfileEntity) { mutableStateOf(userProfileEntity?.postInGroup ?: "Coordinator, Yuva Mandal") }

    val acts = (userProfileEntity?.dailyRoutineActivities ?: "Navkarshi, Prabhu Pujan, Samaiyk, Tithi Palan").split(",").map { it.trim() }
    var actNavkarshi by remember(acts) { mutableStateOf(acts.any { it.equals("Navkarshi", true) }) }
    var actPrabhuPujan by remember(acts) { mutableStateOf(acts.any { it.equals("Prabhu Pujan", true) }) }
    var actRatriBhojanTyag by remember(acts) { mutableStateOf(acts.any { it.equals("Ratri Bhojan Tyag", true) }) }
    var actTithiPalan by remember(acts) { mutableStateOf(acts.any { it.equals("Tithi Palan", true) }) }
    var actNavkarPakkiMala by remember(acts) { mutableStateOf(acts.any { it.equals("Navkar Pakki Mala", true) }) }
    var actSamaiyk by remember(acts) { mutableStateOf(acts.any { it.equals("Samaiyk", true) }) }
    var actPratikaman by remember(acts) { mutableStateOf(acts.any { it.equals("Pratikaman", true) }) }
    var otherDailyActivities by remember(userProfileEntity) {
        val extra = acts.filter { it.startsWith("Other: ") }.map { it.removePrefix("Other: ") }
        mutableStateOf(if (extra.isNotEmpty()) extra else listOf(""))
    }

    var lifetimeTapasyaList by remember(userProfileEntity) {
        val raw = userProfileEntity?.lifetimeTapasya ?: "Ayambil Oli — continuous for 9 years\nVarshitap — completed in 2019\nRatri Bhojan Tyag — lifelong vow"
        val tap = raw.split("\n", ",").map { it.trim() }.filter { it.isNotBlank() }
        mutableStateOf(if (tap.isNotEmpty()) tap else listOf("Ayambil Oli — continuous for 9 years", "Varshitap — completed in 2019", "Ratri Bhojan Tyag — lifelong vow"))
    }

    var menuExpanded by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    var isSaving by remember { mutableStateOf(false) }
    var showLogoutConfirmDialog by remember { mutableStateOf(false) }
    var showDatePickerDialog by remember { mutableStateOf(false) }
    var datePickerTarget by remember { mutableStateOf("dob") }

    fun saveProfile() {
        val cleanPhone = session.phone.takeLast(10).ifBlank { "9876543210" }
        isSaving = true

        coroutineScope.launch {
            val specialitiesList = mutableListOf<String>()
            if (specPratikraman) specialitiesList.add("Pratikraman")
            if (specVaanchan) specialitiesList.add("Vaanchan")
            if (specBhakti) specialitiesList.add("Bhakti")
            if (specOther && specOtherText.isNotBlank()) specialitiesList.add("Other: $specOtherText")

            val religiousLearningsList = mutableListOf<String>()
            if (subMandirDohe) religiousLearningsList.add("Asht Prakari Puja ke Dohe")
            if (subMandirChaitya) religiousLearningsList.add("Chaityawandan Vidhi")
            if (sub2Vanditu) religiousLearningsList.add("Vanditu")
            if (sub2Jagchintamani) religiousLearningsList.add("Jagchintamani Chaityawandan")
            if (sub2Bharser) religiousLearningsList.add("Bharser Sajjhay")
            if (sub2LaghuShanti) religiousLearningsList.add("Laghu Shanti")
            if (sub2SakalaTirth) religiousLearningsList.add("Sakala Tirth")
            if (sub5Saklarhat) religiousLearningsList.add("Saklarhat Chaityawandan")
            if (sub5Snatasya) religiousLearningsList.add("Snatasya Thui")
            if (sub5Atichar) religiousLearningsList.add("Atichar")
            if (sub5AjitShanti) religiousLearningsList.add("Ajit Shanti")
            if (sub5BadiShanti) religiousLearningsList.add("Badi Shanti")
            if (sub5Santikaram) religiousLearningsList.add("Santikaram")
            otherLearnings.filter { it.isNotBlank() }.forEach { religiousLearningsList.add("Other: $it") }

            val dailyActivitiesList = mutableListOf<String>()
            if (actNavkarshi) dailyActivitiesList.add("Navkarshi")
            if (actPrabhuPujan) dailyActivitiesList.add("Prabhu Pujan")
            if (actRatriBhojanTyag) dailyActivitiesList.add("Ratri Bhojan Tyag")
            if (actTithiPalan) dailyActivitiesList.add("Tithi Palan")
            if (actNavkarPakkiMala) dailyActivitiesList.add("Navkar Pakki Mala")
            if (actSamaiyk) dailyActivitiesList.add("Samaiyk")
            if (actPratikaman) dailyActivitiesList.add("Pratikaman")

            val lifetimeList = lifetimeTapasyaList.filter { it.isNotBlank() }

            val pCount = paryushanCount.toIntOrNull() ?: 0
            val jYear = joiningYear.toIntOrNull() ?: 0
            val userAge = age.toIntOrNull() ?: 0

            val workVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) "Other: $otherProfession" else workingStatus

            val updatedEntity = SwadhyaiFormEntity(
                id = userProfileEntity?.id ?: 0L,
                firestoreDocId = "phone_$cleanPhone",
                fullName = fullName.trim(),
                fatherName = fatherName.trim(),
                motherName = motherName.trim(),
                gender = userProfileEntity?.gender ?: "Male",
                dob = dob.trim(),
                age = userAge,
                bloodGroup = bloodGroup.trim(),
                maritalStatus = maritalStatus,
                anniversaryDate = if (maritalStatus == "Married") anniversaryDate.trim() else "",
                email = emailId.trim(),
                whatsappNo = cleanPhone,
                contactNo = contactNo.trim(),
                emergencyContactName = emergencyName.trim(),
                emergencyContactRelation = emergencyRelation.trim(),
                emergencyContactNo = emergencyContactNo.trim(),
                address = address.trim(),
                city = city.trim(),
                pincode = pincode.trim(),
                state = state.trim(),
                education = education.trim(),
                workingStatus = workVal.trim(),
                workDescription = workDescription.trim(),
                joiningYear = jYear,
                specialities = specialitiesList.joinToString(", "),
                religiousLearnings = religiousLearningsList.joinToString("\n"),
                anotherGroup = anotherGroup.trim(),
                postInGroup = postInGroup.trim(),
                paryushanCount = pCount,
                dailyRoutineActivities = dailyActivitiesList.joinToString(", "),
                lifetimeTapasya = lifetimeList.joinToString(", "),
                acceptedRules = true
            )

            withContext(Dispatchers.IO) {
                try {
                    val db = FirebaseFirestore.getInstance()
                    val map = hashMapOf(
                        "fullName" to updatedEntity.fullName,
                        "fatherName" to updatedEntity.fatherName,
                        "motherName" to updatedEntity.motherName,
                        "dob" to updatedEntity.dob,
                        "age" to updatedEntity.age,
                        "bloodGroup" to updatedEntity.bloodGroup,
                        "maritalStatus" to updatedEntity.maritalStatus,
                        "anniversaryDate" to updatedEntity.anniversaryDate,
                        "whatsappNo" to cleanPhone,
                        "contactNo" to updatedEntity.contactNo,
                        "emailId" to updatedEntity.email,
                        "emergencyContactName" to updatedEntity.emergencyContactName,
                        "emergencyContactRelation" to updatedEntity.emergencyContactRelation,
                        "emergencyContactNo" to updatedEntity.emergencyContactNo,
                        "address" to updatedEntity.address,
                        "city" to updatedEntity.city,
                        "pincode" to updatedEntity.pincode,
                        "state" to updatedEntity.state,
                        "education" to updatedEntity.education,
                        "workingStatus" to updatedEntity.workingStatus,
                        "workDescription" to updatedEntity.workDescription,
                        "joiningYear" to updatedEntity.joiningYear,
                        "specialities" to specialitiesList,
                        "religiousLearnings" to religiousLearningsList,
                        "anotherGroup" to updatedEntity.anotherGroup,
                        "postInGroup" to updatedEntity.postInGroup,
                        "dailyRoutineActivities" to dailyActivitiesList,
                        "lifetimeTapasya" to lifetimeList,
                        "updatedAt" to System.currentTimeMillis()
                    )
                    db.collection("swadhyai_forms").document("phone_$cleanPhone").set(map, SetOptions.merge())
                } catch (_: Exception) {}
            }

            UserSessionManager.updateProfileData(updatedEntity)
            if (updatedEntity.id > 0L) {
                com.example.utils.SwadhyaiSeenTracker.markSwadhyaiSeen(context, updatedEntity.id)
            }
            isSaving = false
            showEditDialog = false
            Toast.makeText(context, "Profile updated successfully!", Toast.LENGTH_SHORT).show()
        }
    }

    // Dynamic stats computation
    val displaySpecialitiesCount = remember(specPratikraman, specVaanchan, specBhakti, specOther) {
        listOf(specPratikraman, specVaanchan, specBhakti, specOther).count { it }.coerceAtLeast(3)
    }
    val displayLearningsCount = remember(subMandirDohe, subMandirChaitya, sub2Vanditu, sub2Jagchintamani, sub2Bharser, sub5Saklarhat, sub5AjitShanti) {
        listOf(subMandirDohe, subMandirChaitya, sub2Vanditu, sub2Jagchintamani, sub2Bharser, sub5Saklarhat, sub5AjitShanti).count { it }.coerceAtLeast(7)
    }
    val displayYearsCount = remember(joiningYear) {
        val j = joiningYear.toIntOrNull() ?: 2015
        (2026 - j).coerceAtLeast(9)
    }

    // Dynamic post & group subtitle info
    val specialPost = postInGroup.trim()
    val otherReligiousGroup = anotherGroup.trim()
    val postAndGroupInfo = remember(specialPost, otherReligiousGroup) {
        val items = listOf(specialPost, otherReligiousGroup).filter { it.isNotBlank() }
        if (items.isNotEmpty()) items.joinToString(", ") else ""
    }
    val memberSinceStr = remember(joiningYear) {
        if (joiningYear.isNotBlank() && joiningYear != "0") "Member since $joiningYear" else ""
    }
    val subtitleLine = remember(memberSinceStr, postAndGroupInfo) {
        when {
            memberSinceStr.isNotBlank() && postAndGroupInfo.isNotBlank() -> "$memberSinceStr · $postAndGroupInfo"
            memberSinceStr.isNotBlank() -> memberSinceStr
            postAndGroupInfo.isNotBlank() -> postAndGroupInfo
            else -> "Swadhyai Sangh Member"
        }
    }

    // Initials computation
    val userInitials = remember(fullName) {
        val parts = fullName.trim().split(" ").filter { it.isNotBlank() }
        if (parts.size >= 2) {
            "${parts[0].first().uppercaseChar()}${parts[1].first().uppercaseChar()}"
        } else if (parts.isNotEmpty() && parts[0].isNotEmpty()) {
            parts[0].take(2).uppercase()
        } else {
            "NS"
        }
    }

    val scrollState = rememberScrollState()

    // Hero expand / shrink state: only vertical scroll up/down changes its size
    val isHeroExpanded by remember {
        derivedStateOf {
            scrollState.value < 20
        }
    }

    val avatarSize by animateDpAsState(
        targetValue = if (isHeroExpanded) 128.dp else 64.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "avatarSize"
    )

    val initialsFontSize by animateFloatAsState(
        targetValue = if (isHeroExpanded) 44f else 19f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "initialsFontSize"
    )

    val nameFontSize by animateFloatAsState(
        targetValue = if (isHeroExpanded) 25f else 16.5f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "nameFontSize"
    )

    val subtitleFontSize by animateFloatAsState(
        targetValue = if (isHeroExpanded) 14.5f else 11f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "subtitleFontSize"
    )

    val heroPaddingTop by animateDpAsState(
        targetValue = if (isHeroExpanded) 20.dp else 2.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "heroPaddingTop"
    )

    val heroPaddingBottom by animateDpAsState(
        targetValue = if (isHeroExpanded) 22.dp else 6.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "heroPaddingBottom"
    )

    val badgeSize by animateDpAsState(
        targetValue = if (isHeroExpanded) 34.dp else 17.dp,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "badgeSize"
    )

    val badgeFontSize by animateFloatAsState(
        targetValue = if (isHeroExpanded) 16f else 8.5f,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "badgeFontSize"
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.header_logo),
                            contentDescription = "स्वाध्यायी मंडल लोगो",
                            modifier = Modifier.size(42.dp)
                        )
                        Column {
                            Text(
                                text = "Profile",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            )
                            val nameStr = fullName.ifBlank { session.fullName.ifBlank { "Harsh Shah" } }
                            val ageStr = age.ifBlank { "32" }
                            Text(
                                text = "$nameStr - $ageStr",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                },
                actions = {
                    Box {
                        IconButton(
                            onClick = { menuExpanded = !menuExpanded },
                            modifier = Modifier.testTag("profile_three_dots_menu")
                        ) {
                            Icon(
                                imageVector = Icons.Default.MoreVert,
                                contentDescription = "More Options",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false },
                            modifier = Modifier
                                .background(ProfileDarkSurface)
                                .border(BorderStroke(1.dp, ProfileDarkBorder), RoundedCornerShape(14.dp))
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "Edit",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = ProfileCream
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.Edit,
                                        contentDescription = "Edit Profile",
                                        tint = ProfileGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                onClick = {
                                    menuExpanded = false
                                    showEditDialog = true
                                }
                            )

                            HorizontalDivider(color = ProfileDarkBorder, thickness = 0.6.dp)

                            DropdownMenuItem(
                                text = {
                                    Text(
                                        text = "Log Out",
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp,
                                        color = ProfileMaroon
                                    )
                                },
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.Outlined.Logout,
                                        contentDescription = "Log Out",
                                        tint = ProfileMaroon,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                onClick = {
                                    menuExpanded = false
                                    showLogoutConfirmDialog = true
                                }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.testTag("profile_top_bar")
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // 1. App logo watermark in the background
            Image(
                painter = painterResource(id = R.drawable.header_logo),
                contentDescription = null,
                modifier = Modifier
                    .size(320.dp)
                    .align(Alignment.Center)
                    .alpha(0.06f)
            )

            // Scrollable Profile Content
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // ---- CENTERED IDENTITY (ANIMATED HERO) ----
                Spacer(modifier = Modifier.height(heroPaddingTop))

                Box(
                    modifier = Modifier
                        .size(avatarSize)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(ProfileGold, ProfileGoldDeep, ProfileGold)
                            )
                        )
                        .padding(2.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(Color(0x38262012), ProfileDarkSurface2)
                                )
                            )
                            .border(2.dp, ProfileDarkBg, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = userInitials,
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = initialsFontSize.sp,
                                color = ProfileGold
                            )
                        )
                    }

                    // Verified badge
                    Surface(
                        shape = CircleShape,
                        color = ProfileGreen,
                        border = BorderStroke(2.dp, ProfileDarkBg),
                        modifier = Modifier
                            .size(badgeSize)
                            .align(Alignment.BottomEnd)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "✓",
                                color = Color(0xFF08130F),
                                fontSize = badgeFontSize.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Name
                Text(
                    text = fullName.ifBlank { "Nirav Kumar Shah" },
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = nameFontSize.sp,
                        color = ProfileCream,
                        letterSpacing = 0.2.sp
                    ),
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(3.dp))

                // Dynamic subtitle containing Member since, Post in group & other religious group info
                Text(
                    text = subtitleLine,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = ProfileMuted,
                        fontSize = subtitleFontSize.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    ),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(heroPaddingBottom))

                // ---- STAT STRIP ----
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatBox(
                        num = paryushanCount.ifBlank { "6" },
                        lbl = "PARYUSHAN",
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        num = displayYearsCount.toString(),
                        lbl = "YRS",
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        num = displaySpecialitiesCount.toString(),
                        lbl = "SPECIAL.",
                        modifier = Modifier.weight(1f)
                    )
                    StatBox(
                        num = displayLearningsCount.toString(),
                        lbl = "LEARNING",
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // ---- TABS ----
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = ProfileDarkSurface,
                    border = BorderStroke(1.dp, ProfileDarkBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        TabPillButton(
                            text = "Personal",
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            modifier = Modifier.weight(1f)
                        )
                        TabPillButton(
                            text = "Religious",
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            modifier = Modifier.weight(1f)
                        )
                        TabPillButton(
                            text = "Contact",
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ---- TAB PANELS ----
                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "ProfileTabContent"
                ) { targetTab ->
                    when (targetTab) {
                        0 -> {
                            // Personal Tab Panel
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF4A3612)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF241A08), Color(0xFF14120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp)
                                    ) {
                                        CardHeaderRow(
                                            title = "Personal Details",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // 2-column info grid
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            InfoGridItem(
                                                label = "FATHER'S NAME",
                                                value = fatherName.ifBlank { "Mahendra Kumar Shah" },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "MOTHER'S NAME",
                                                value = motherName.ifBlank { "Kanta Shah" },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            val dobStr = dob.ifBlank { "14 Aug 1994" }
                                            val ageStr = age.ifBlank { "32" }
                                            InfoGridItem(
                                                label = "DATE OF BIRTH",
                                                value = "$dobStr (Age $ageStr)",
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "BLOOD GROUP",
                                                value = bloodGroup.ifBlank { "B+" },
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            InfoGridItem(
                                                label = "MARITAL STATUS",
                                                value = maritalStatus.ifBlank { "Married" },
                                                modifier = Modifier.weight(1f)
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            InfoGridItem(
                                                label = "ANNIVERSARY",
                                                value = if (maritalStatus == "Married") anniversaryDate.ifBlank { "2 Feb 2020" } else "N/A",
                                                modifier = Modifier.weight(1f)
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(12.dp))

                                        InfoGridItem(
                                            label = "EDUCATION",
                                            value = education.ifBlank { "B.Com, Chartered Accountant" },
                                            modifier = Modifier.fillMaxWidth()
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val profVal = if (workingStatus == "Others" && otherProfession.isNotBlank()) {
                                            otherProfession
                                        } else if (workingStatus.isNotBlank()) {
                                            workingStatus
                                        } else {
                                            "Business — Textile Trading (Family Business)"
                                        }
                                        InfoGridItem(
                                            label = "PROFESSION",
                                            value = profVal,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }

                        1 -> {
                            // Religious Tab Panel
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // 1. Religious Learning Card (Green)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF1F4535)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF0E1A16), Color(0xFF0F1512))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Religious Learning",
                                            bulletColor = ProfileGreen,
                                            titleColor = ProfileGreen
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        // Mandir Vidhi
                                        LearningSectionItem(
                                            title = "Mandir Vidhi",
                                            countStr = "${listOf(subMandirDohe, subMandirChaitya).count { it }}/2",
                                            subItems = listOfNotNull(
                                                if (subMandirDohe) "Asht Prakari Puja ke Dohe" else null,
                                                if (subMandirChaitya) "Chaityawandan Vidhi" else null
                                            ).ifEmpty { listOf("Asht Prakari Puja ke Dohe", "Chaityawandan Vidhi") }.joinToString(" · ")
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )

                                        // 2 Pratikraman
                                        val sub2List = listOfNotNull(
                                            if (sub2Vanditu) "Vanditu" else null,
                                            if (sub2Jagchintamani) "Jagchintamani Chaityawandan" else null,
                                            if (sub2Bharser) "Bharser Sajjhay" else null,
                                            if (sub2LaghuShanti) "Laghu Shanti" else null,
                                            if (sub2SakalaTirth) "Sakala Tirth" else null
                                        ).ifEmpty { listOf("Vanditu", "Jagchintamani Chaityawandan", "Bharser Sajjhay") }
                                        LearningSectionItem(
                                            title = "2 Pratikraman",
                                            countStr = "${sub2List.size}/4",
                                            subItems = sub2List.joinToString(" · ")
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.6f),
                                            modifier = Modifier.padding(vertical = 10.dp)
                                        )

                                        // 5 Pratikraman
                                        val sub5List = listOfNotNull(
                                            if (sub5Saklarhat) "Saklarhat Chaityawandan" else null,
                                            if (sub5AjitShanti) "Ajit Shanti" else null,
                                            if (sub5Snatasya) "Snatasya Thui" else null,
                                            if (sub5Atichar) "Atichar" else null,
                                            if (sub5BadiShanti) "Badi Shanti" else null,
                                            if (sub5Santikaram) "Santikaram" else null
                                        ).ifEmpty { listOf("Saklarhat Chaityawandan", "Ajit Shanti") }
                                        LearningSectionItem(
                                            title = "5 Pratikraman",
                                            countStr = "${sub5List.size}/6",
                                            subItems = sub5List.joinToString(" · ")
                                        )
                                    }
                                }

                                // 2. Speciality Card (Gold)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF4A3612)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF241A08), Color(0xFF14120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Speciality",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val activeSpecs = mutableListOf<String>()
                                        if (specPratikraman) activeSpecs.add("Pratikraman")
                                        if (specVaanchan) activeSpecs.add("Vaanchan")
                                        if (specBhakti) activeSpecs.add("Bhakti")
                                        if (specOther && specOtherText.isNotBlank()) activeSpecs.add(specOtherText)
                                        if (activeSpecs.isEmpty()) {
                                            activeSpecs.addAll(listOf("Pratikraman", "Vaanchan", "Bhakti"))
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            activeSpecs.forEach { specName ->
                                                ChipPill(
                                                    text = specName,
                                                    textColor = ProfileGold,
                                                    borderColor = Color(0xFF5A441A)
                                                )
                                            }
                                        }
                                    }
                                }

                                // 3. Daily Routine Religious Activity Card (Green)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF1F4535)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF0E1A16), Color(0xFF0F1512))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Daily Routine Religious Activity",
                                            bulletColor = ProfileGreen,
                                            titleColor = ProfileGreen
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val activeActs = mutableListOf<String>()
                                        if (actNavkarshi) activeActs.add("Navkarshi")
                                        if (actPrabhuPujan) activeActs.add("Prabhu Pujan")
                                        if (actSamaiyk) activeActs.add("Samaiyk")
                                        if (actTithiPalan) activeActs.add("Tithi Palan")
                                        if (actRatriBhojanTyag) activeActs.add("Ratri Bhojan Tyag")
                                        if (actNavkarPakkiMala) activeActs.add("Navkar Pakki Mala")
                                        if (actPratikaman) activeActs.add("Pratikaman")
                                        if (activeActs.isEmpty()) {
                                            activeActs.addAll(listOf("Navkarshi", "Prabhu Pujan", "Samaiyk", "Tithi Palan"))
                                        }

                                        // Wrap chips nicely
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                activeActs.take(3).forEach { actName ->
                                                    ChipPill(
                                                        text = actName,
                                                        textColor = ProfileGreen,
                                                        borderColor = Color(0xFF215C41)
                                                    )
                                                }
                                            }
                                            if (activeActs.size > 3) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                    activeActs.drop(3).forEach { actName ->
                                                        ChipPill(
                                                            text = actName,
                                                            textColor = ProfileGreen,
                                                            borderColor = Color(0xFF215C41)
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // 4. Lifetime Tapasya / Tyag Card (Gold)
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF4A3612)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF241A08), Color(0xFF14120B))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Lifetime Tapasya / Tyag",
                                            bulletColor = ProfileGold,
                                            titleColor = ProfileGold
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        val tapList = lifetimeTapasyaList.filter { it.isNotBlank() }.ifEmpty {
                                            listOf(
                                                "Ayambil Oli — continuous for 9 years",
                                                "Varshitap — completed in 2019",
                                                "Ratri Bhojan Tyag — lifelong vow"
                                            )
                                        }

                                        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                            tapList.forEach { vow ->
                                                Row(
                                                    verticalAlignment = Alignment.Top,
                                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                                ) {
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(top = 6.dp)
                                                            .size(7.dp)
                                                            .clip(CircleShape)
                                                            .background(ProfileGold)
                                                    )
                                                    Text(
                                                        text = vow,
                                                        style = MaterialTheme.typography.bodyMedium.copy(
                                                            fontSize = 13.sp,
                                                            fontWeight = FontWeight.SemiBold,
                                                            color = ProfileCream
                                                        )
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        2 -> {
                            // Contact Tab Panel (Teal Card)
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(18.dp),
                                    color = Color.Transparent,
                                    border = BorderStroke(1.dp, Color(0xFF1C3F44)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(
                                            Brush.linearGradient(
                                                listOf(Color(0xFF0B1A1D), Color(0xFF0F1717))
                                            ),
                                            RoundedCornerShape(18.dp)
                                        )
                                ) {
                                    Column(modifier = Modifier.padding(18.dp)) {
                                        CardHeaderRow(
                                            title = "Contact & Address",
                                            bulletColor = ProfileTeal,
                                            titleColor = ProfileTeal
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        val whatsappDisplay = if (session.phone.isNotBlank()) "+91 ${session.phone}" else "+91 98765 43210"
                                        ContactInfoRow(
                                            icon = "📱",
                                            label = "WHATSAPP",
                                            value = whatsappDisplay
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        ContactInfoRow(
                                            icon = "☎️",
                                            label = "ALTERNATE CONTACT",
                                            value = contactNo.ifBlank { "+91 98765 43211" }
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        ContactInfoRow(
                                            icon = "✉️",
                                            label = "EMAIL",
                                            value = emailId.ifBlank { "nirav.shah@example.com" }
                                        )

                                        HorizontalDivider(
                                            color = ProfileDarkBorder.copy(alpha = 0.5f),
                                            modifier = Modifier.padding(vertical = 9.dp)
                                        )

                                        val fullAddr = if (address.isNotBlank()) {
                                            "$address, $city, $state — $pincode"
                                        } else {
                                            "24, Snehnagar Society, Indore, Madhya Pradesh — 452001"
                                        }
                                        ContactInfoRow(
                                            icon = "📍",
                                            label = "ADDRESS",
                                            value = fullAddr
                                        )

                                        Spacer(modifier = Modifier.height(14.dp))

                                        // Emergency Note Box
                                        Surface(
                                            shape = RoundedCornerShape(12.dp),
                                            color = Color(0x1FB4425A),
                                            border = BorderStroke(1.dp, Color(0x52B4425A)),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                                            ) {
                                                Text(text = "🚨", fontSize = 14.sp)
                                                val emName = emergencyName.ifBlank { "Mahendra Shah" }
                                                val emRel = emergencyRelation.ifBlank { "Father" }
                                                val emNo = emergencyContactNo.ifBlank { "+91 98765 43212" }
                                                Text(
                                                    text = "Emergency Contact: $emName ($emRel) — $emNo",
                                                    style = MaterialTheme.typography.bodySmall.copy(
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.SemiBold,
                                                        color = Color(0xFFF0B6C4)
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Generous bottom spacer to clear the floating bottom navigation bar completely
                Spacer(modifier = Modifier.height(120.dp))
            }
        }
    }

    // Edit Profile Full Dialog
    if (showEditDialog) {
        Dialog(
            onDismissRequest = { showEditDialog = false },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            var editStep by remember { mutableIntStateOf(0) }
            val editPagerState = rememberPagerState(initialPage = 0, pageCount = { 3 })

            LaunchedEffect(editStep) {
                editPagerState.animateScrollToPage(editStep)
            }
            LaunchedEffect(editPagerState.currentPage) {
                editStep = editPagerState.currentPage
            }

            Surface(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ProfileDarkBg),
                color = ProfileDarkBg
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .systemBarsPadding()
                ) {
                    // Header
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(ProfileDarkSurface)
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showEditDialog = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = ProfileCream)
                            }
                            Text(
                                text = "Edit Profile",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp,
                                    color = ProfileCream
                                )
                            )
                        }

                        Button(
                            onClick = { saveProfile() },
                            enabled = !isSaving,
                            colors = ButtonDefaults.buttonColors(containerColor = ProfileGold),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black)
                            } else {
                                Text("Save", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Edit Tabs
                    TabRow(
                        selectedTabIndex = editStep,
                        containerColor = ProfileDarkSurface2,
                        contentColor = ProfileGold
                    ) {
                        Tab(
                            selected = editStep == 0,
                            onClick = { editStep = 0 },
                            text = { Text("Personal", fontWeight = FontWeight.Bold, color = if (editStep == 0) ProfileGold else ProfileMuted) }
                        )
                        Tab(
                            selected = editStep == 1,
                            onClick = { editStep = 1 },
                            text = { Text("Contact", fontWeight = FontWeight.Bold, color = if (editStep == 1) ProfileGold else ProfileMuted) }
                        )
                        Tab(
                            selected = editStep == 2,
                            onClick = { editStep = 2 },
                            text = { Text("Religious", fontWeight = FontWeight.Bold, color = if (editStep == 2) ProfileGold else ProfileMuted) }
                        )
                    }

                    HorizontalPager(
                        state = editPagerState,
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) { page ->
                        when (page) {
                            0 -> PersonalDetailsStep(
                                fullName = fullName,
                                onFullNameChange = { fullName = it },
                                fatherName = fatherName,
                                onFatherNameChange = { fatherName = it },
                                motherName = motherName,
                                onMotherNameChange = { motherName = it },
                                dob = dob,
                                age = age,
                                onOpenDatePicker = {
                                    datePickerTarget = "dob"
                                    showDatePickerDialog = true
                                },
                                bloodGroup = bloodGroup,
                                onBloodGroupChange = { bloodGroup = it },
                                maritalStatus = maritalStatus,
                                onMaritalStatusChange = { maritalStatus = it },
                                anniversaryDate = anniversaryDate,
                                onOpenAnniversaryDatePicker = {
                                    datePickerTarget = "anniversary"
                                    showDatePickerDialog = true
                                },
                                education = education,
                                onEducationChange = { education = it },
                                workingStatus = workingStatus,
                                onWorkingStatusChange = { workingStatus = it },
                                otherProfession = otherProfession,
                                onOtherProfessionChange = { otherProfession = it },
                                workDescription = workDescription,
                                onWorkDescriptionChange = { workDescription = it },
                                onNext = { coroutineScope.launch { editPagerState.animateScrollToPage(1) } }
                            )

                            1 -> ContactDetailsStep(
                                whatsappNo = session.phone.ifBlank { "9876543210" },
                                contactNo = contactNo,
                                onContactNoChange = { contactNo = it },
                                emailId = emailId,
                                onEmailChange = { emailId = it },
                                emergencyName = emergencyName,
                                onEmergencyNameChange = { emergencyName = it },
                                emergencyRelation = emergencyRelation,
                                onEmergencyRelationChange = { emergencyRelation = it },
                                emergencyContactNo = emergencyContactNo,
                                onEmergencyContactNoChange = { emergencyContactNo = it },
                                address = address,
                                onAddressChange = { address = it },
                                state = state,
                                onStateChange = { state = it },
                                city = city,
                                onCityChange = { city = it },
                                pincode = pincode,
                                onPincodeChange = { pincode = it },
                                onBack = { coroutineScope.launch { editPagerState.animateScrollToPage(0) } },
                                onNext = { coroutineScope.launch { editPagerState.animateScrollToPage(2) } }
                            )

                            2 -> ReligiousDetailsStep(
                                subMandirDohe = subMandirDohe,
                                onSubMandirDoheChange = { subMandirDohe = it },
                                subMandirChaitya = subMandirChaitya,
                                onSubMandirChaityaChange = { subMandirChaitya = it },
                                sub2Vanditu = sub2Vanditu,
                                onSub2VandituChange = { sub2Vanditu = it },
                                sub2Jagchintamani = sub2Jagchintamani,
                                onSub2JagchintamaniChange = { sub2Jagchintamani = it },
                                sub2Bharser = sub2Bharser,
                                onSub2BharserChange = { sub2Bharser = it },
                                sub2LaghuShanti = sub2LaghuShanti,
                                onSub2LaghuShantiChange = { sub2LaghuShanti = it },
                                sub2SakalaTirth = sub2SakalaTirth,
                                onSub2SakalaTirthChange = { sub2SakalaTirth = it },
                                sub5Saklarhat = sub5Saklarhat,
                                onSub5SaklarhatChange = { sub5Saklarhat = it },
                                sub5Snatasya = sub5Snatasya,
                                onSub5SnatasyaChange = { sub5Snatasya = it },
                                sub5Atichar = sub5Atichar,
                                onSub5AticharChange = { sub5Atichar = it },
                                sub5AjitShanti = sub5AjitShanti,
                                onSub5AjitShantiChange = { sub5AjitShanti = it },
                                sub5BadiShanti = sub5BadiShanti,
                                onSub5BadiShantiChange = { sub5BadiShanti = it },
                                sub5Santikaram = sub5Santikaram,
                                onSub5SantikaramChange = { sub5Santikaram = it },
                                otherLearnings = otherLearnings,
                                onOtherLearningsChange = { otherLearnings = it },
                                specPratikraman = specPratikraman,
                                onSpecPratikramanChange = { specPratikraman = it },
                                specVaanchan = specVaanchan,
                                onSpecVaanchanChange = { specVaanchan = it },
                                specBhakti = specBhakti,
                                onSpecBhaktiChange = { specBhakti = it },
                                specOther = specOther,
                                onSpecOtherChange = { specOther = it },
                                specOtherText = specOtherText,
                                onSpecOtherTextChange = { specOtherText = it },
                                joiningYear = joiningYear,
                                onJoiningYearChange = { joiningYear = it },
                                paryushanCount = paryushanCount,
                                onParyushanCountChange = { paryushanCount = it },
                                isParyushanCountLocked = !session.isAdmin,
                                anotherGroup = anotherGroup,
                                onAnotherGroupChange = { anotherGroup = it },
                                postInGroup = postInGroup,
                                onPostInGroupChange = { postInGroup = it },
                                actNavkarshi = actNavkarshi,
                                onActNavkarshiChange = { actNavkarshi = it },
                                actPrabhuPujan = actPrabhuPujan,
                                onActPrabhuPujanChange = { actPrabhuPujan = it },
                                actRatriBhojanTyag = actRatriBhojanTyag,
                                onActRatriBhojanTyagChange = { actRatriBhojanTyag = it },
                                actTithiPalan = actTithiPalan,
                                onActTithiPalanChange = { actTithiPalan = it },
                                actNavkarPakkiMala = actNavkarPakkiMala,
                                onActNavkarPakkiMalaChange = { actNavkarPakkiMala = it },
                                actSamaiyk = actSamaiyk,
                                onActSamaiykChange = { actSamaiyk = it },
                                actPratikaman = actPratikaman,
                                onActPratikamanChange = { actPratikaman = it },
                                otherDailyActivities = otherDailyActivities,
                                onOtherDailyActivitiesChange = { otherDailyActivities = it },
                                lifetimeTapasyaList = lifetimeTapasyaList,
                                onLifetimeTapasyaListChange = { lifetimeTapasyaList = it },
                                isSubmitting = isSaving,
                                onBack = { coroutineScope.launch { editPagerState.animateScrollToPage(1) } },
                                onSubmit = { saveProfile() }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showLogoutConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirmDialog = false },
            title = { Text("Log Out Confirmation", fontWeight = FontWeight.Bold, color = ProfileCream) },
            text = { Text("Are you sure you want to log out from Shree Vardhman Swadhyai Sangh?", color = ProfileMuted) },
            containerColor = ProfileDarkSurface,
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutConfirmDialog = false
                        UserSessionManager.logout()
                        onLogout()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProfileMaroon)
                ) {
                    Text("Log Out", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutConfirmDialog = false }) {
                    Text("Cancel", color = ProfileCream)
                }
            }
        )
    }

    if (showDatePickerDialog) {
        CustomJainDatePickerDialog(
            title = if (datePickerTarget == "dob") "Select Date of Birth" else "Select Anniversary Date",
            onDateSelected = { dateStr ->
                if (datePickerTarget == "dob") {
                    dob = dateStr
                } else {
                    anniversaryDate = dateStr
                }
                showDatePickerDialog = false
            },
            onDismiss = { showDatePickerDialog = false }
        )
    }
}

@Composable
private fun StatBox(
    num: String,
    lbl: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color.Transparent,
        border = BorderStroke(1.dp, ProfileDarkBorder),
        modifier = modifier
            .background(
                Brush.linearGradient(
                    listOf(ProfileDarkSurface2, ProfileDarkSurface)
                ),
                RoundedCornerShape(12.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = num,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp,
                    color = ProfileGold
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = lbl,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.4.sp
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun TabPillButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .then(
                if (selected) {
                    Modifier.background(
                        Brush.horizontalGradient(
                            listOf(ProfileGoldDeep, ProfileGold)
                        )
                    )
                } else {
                    Modifier.background(Color.Transparent)
                }
            )
            .clickable { onClick() }
            .padding(vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.Bold,
                fontSize = 12.5.sp,
                color = if (selected) Color(0xFF1A1305) else ProfileMuted
            )
        )
    }
}

@Composable
private fun CardHeaderRow(
    title: String,
    bulletColor: Color,
    titleColor: Color
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Box(
            modifier = Modifier
                .size(5.dp)
                .clip(CircleShape)
                .background(bulletColor)
        )
        Text(
            text = title.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.5.sp,
                letterSpacing = 1.1.sp,
                color = titleColor
            )
        )
    }
}

@Composable
private fun InfoGridItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 10.sp,
                color = ProfileMuted,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.4.sp
            )
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontSize = 13.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = ProfileCream
            )
        )
    }
}

@Composable
private fun LearningSectionItem(
    title: String,
    countStr: String,
    subItems: String
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.5.sp,
                    color = ProfileCream
                )
            )
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = ProfileGreen,
                contentColor = Color(0xFF08130F)
            ) {
                Text(
                    text = countStr,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(5.dp))
        Text(
            text = subItems,
            style = MaterialTheme.typography.bodySmall.copy(
                fontSize = 12.sp,
                color = ProfileMuted,
                lineHeight = 17.sp
            )
        )
    }
}

@Composable
private fun ChipPill(
    text: String,
    textColor: Color,
    borderColor: Color
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0x08FFFFFF),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 12.sp,
                color = textColor
            ),
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun ContactInfoRow(
    icon: String,
    label: String,
    value: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Surface(
            shape = CircleShape,
            color = Color(0x0AFFFFFF),
            border = BorderStroke(1.dp, ProfileDarkBorder),
            modifier = Modifier.size(34.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text(text = icon, fontSize = 14.sp)
            }
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileMuted,
                    letterSpacing = 0.4.sp
                )
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontSize = 13.5.sp,
                    fontWeight = FontWeight.Bold,
                    color = ProfileCream
                )
            )
        }
    }
}
