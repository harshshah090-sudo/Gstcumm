package com.example.ui.components

import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.AutoStories
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

sealed class BottomNavItem(
    val route: String,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    object Home : BottomNavItem(
        route = "home",
        title = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        testTag = "nav_item_home"
    )

    object GyanShala : BottomNavItem(
        route = "gyan_shala",
        title = "Gyan Shala",
        selectedIcon = Icons.Filled.AutoStories,
        unselectedIcon = Icons.Outlined.AutoStories,
        testTag = "nav_item_gyan_shala"
    )

    object Swadhyai : BottomNavItem(
        route = "swadhyai_registrations",
        title = "Swadhyai",
        selectedIcon = Icons.Filled.Groups,
        unselectedIcon = Icons.Outlined.Groups,
        testTag = "nav_item_swadhyai"
    )

    object Profile : BottomNavItem(
        route = "profile",
        title = "Profile",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person,
        testTag = "nav_item_profile"
    )

    object AboutUs : BottomNavItem(
        route = "about_us",
        title = "About Us",
        selectedIcon = Icons.Filled.Info,
        unselectedIcon = Icons.Outlined.Info,
        testTag = "nav_item_about_us"
    )
}

val bottomNavItems = listOf(
    BottomNavItem.Home,
    BottomNavItem.GyanShala,
    BottomNavItem.Swadhyai,
    BottomNavItem.Profile,
    BottomNavItem.AboutUs
)

@Composable
fun AppBottomNavigationBar(
    currentRoute: String?,
    onNavigateToRoute: (String) -> Unit,
    hasSwadhyaiUnread: Boolean = false,
    hasGyanShalaUnread: Boolean = false,
    hasProfileUnread: Boolean = false,
    modifier: Modifier = Modifier
) {
    val selectedIndex = bottomNavItems.indexOfFirst { it.route == currentRoute }.let {
        if (it >= 0) it else 0
    }

    // Spring animation for smooth sliding and bouncy stop
    val animatedIndex by animateFloatAsState(
        targetValue = selectedIndex.toFloat(),
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "sliding_bouncy_pill"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .testTag("main_bottom_navigation_bar")
    ) {
        // --- 1. iOS Liquid Glass Translucent Frosted Base Layer (Increased Opacity) ---
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            AppBackground.copy(alpha = 0.68f),
                            AppBackground.copy(alpha = 0.80f),
                            AppDeepSurface.copy(alpha = 0.88f)
                        )
                    )
                )
        )

        // --- 2. Frosted Glass Diffusion, Specular Sheen & Light Scattering ---
        Box(
            modifier = Modifier
                .matchParentSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color.White.copy(alpha = 0.12f),
                            Color.White.copy(alpha = 0.04f),
                            Color.Transparent,
                            Color(0x25000000)
                        )
                    )
                )
        )

        // --- 3. Crisp Foreground Content (Icons, Bouncy Sliding Pill & Typography) ---
        Column(modifier = Modifier.fillMaxWidth()) {
            // iOS Liquid Glass Top Specular Hairline Border (1px crisp edge)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(
                                Color.White.copy(alpha = 0.18f),
                                Color.White.copy(alpha = 0.45f),
                                AppPrimaryGold.copy(alpha = 0.80f),
                                Color.White.copy(alpha = 0.45f),
                                Color.White.copy(alpha = 0.18f)
                            )
                        )
                    )
            )

            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(top = 4.dp, bottom = 4.dp, start = 6.dp, end = 6.dp)
            ) {
                val totalTabs = bottomNavItems.size
                val tabWidth = maxWidth / totalTabs
                val pillWidth = 48.dp
                val pillHeight = 26.dp

                // Sliding Gold Active Pill with Bouncy Physics
                Box(
                    modifier = Modifier
                        .offset(
                            x = tabWidth * (animatedIndex + 0.5f) - (pillWidth / 2),
                            y = 2.dp
                        )
                        .size(pillWidth, pillHeight)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.32f),
                                    AppPrimaryGold.copy(alpha = 0.20f)
                                )
                            )
                        )
                        .border(
                            0.75.dp,
                            Brush.linearGradient(
                                listOf(
                                    AppPrimaryGold.copy(alpha = 0.70f),
                                    AppPrimaryGold.copy(alpha = 0.35f)
                                )
                            ),
                            CircleShape
                        )
                )

                // Interactive Tab Columns (Icons & Text)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    bottomNavItems.forEachIndexed { index, item ->
                        val isSelected = index == selectedIndex

                        val iconTint by animateColorAsState(
                            targetValue = if (isSelected) {
                                AppPrimaryGold
                            } else {
                                AppTextMuted
                            },
                            label = "icon_tint_anim"
                        )

                        val labelColor by animateColorAsState(
                            targetValue = if (isSelected) {
                                AppTextPrimary
                            } else {
                                AppTextMuted
                            },
                            label = "label_color_anim"
                        )

                        val iconScale by animateFloatAsState(
                            targetValue = if (isSelected) 1.08f else 1.0f,
                            animationSpec = spring(
                                dampingRatio = Spring.DampingRatioMediumBouncy,
                                stiffness = Spring.StiffnessLow
                            ),
                            label = "icon_scale_anim"
                        )

                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = {
                                        if (currentRoute != item.route) {
                                            onNavigateToRoute(item.route)
                                        }
                                    }
                                )
                                .testTag(item.testTag)
                                .padding(vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            // Icon Container (transparent so the sliding pill displays seamlessly behind)
                            Box(
                                modifier = Modifier
                                    .width(pillWidth)
                                    .height(pillHeight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title,
                                    tint = iconTint,
                                    modifier = Modifier
                                        .size(20.dp)
                                        .scale(iconScale)
                                )

                                if (item == BottomNavItem.Swadhyai && hasSwadhyaiUnread) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = (-10).dp, y = 2.dp)
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE53935))
                                            .border(1.dp, Color.White, CircleShape)
                                    )
                                } else if (item == BottomNavItem.GyanShala && hasGyanShalaUnread) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = (-10).dp, y = 2.dp)
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE53935))
                                            .border(1.dp, Color.White, CircleShape)
                                    )
                                } else if (item == BottomNavItem.Profile && hasProfileUnread) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = (-10).dp, y = 2.dp)
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFFE53935))
                                            .border(1.dp, Color.White, CircleShape)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = labelColor
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}
