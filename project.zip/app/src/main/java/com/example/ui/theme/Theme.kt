package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Dark Theme Palette (#101614, #1B2420, #D4A24C, #2F6B4F, #EDE7DA, #8FA096, #8FCB9E)
private val DarkColorScheme =
  darkColorScheme(
    primary = AppPrimaryAccent,            // #D4A24C Buttons, headings, tags, FAB
    onPrimary = Color(0xFF101614),         // Dark text on primary button
    primaryContainer = AppPrimaryContainer,
    onPrimaryContainer = AppOnPrimaryContainer,
    secondary = AppSecondaryAccent,        // #2F6B4F Hero gradient, borders
    onSecondary = Color.White,
    secondaryContainer = AppSecondaryContainer,
    onSecondaryContainer = AppOnSecondaryContainer,
    tertiary = AppSuccessPaleGreen,        // #8FCB9E Tag text on city chip
    onTertiary = Color(0xFF101614),
    tertiaryContainer = AppSecondaryContainer,
    onTertiaryContainer = AppSuccessPaleGreen,
    background = AppBackground,            // #101614 Background
    onBackground = AppTextPrimary,         // #EDE7DA Text primary
    surface = AppSurface,                  // #1B2420 Surface/card
    onSurface = AppTextPrimary,            // #EDE7DA Text primary
    surfaceVariant = AppSurfaceVariant,    // Cards, search bar, header logo bg
    onSurfaceVariant = AppTextMuted,       // #8FA096 Text muted
    outline = AppSecondaryAccent,          // #2F6B4F Borders
    outlineVariant = Color(0xFF26382F)
  )

// Light Theme Palette (#713600, #C05800, #38240D, #FDFBD4)
private val LightColorScheme =
  lightColorScheme(
    primary = LightAmberPrimary,            // #713600
    onPrimary = Color.White,
    primaryContainer = LightCreamContainer,
    onPrimaryContainer = LightAmberPrimary,
    secondary = LightAmberSecondary,        // #C05800
    onSecondary = Color.White,
    secondaryContainer = LightSurfaceVariant,
    onSecondaryContainer = LightBrownTextPrimary,
    tertiary = LightAmberSecondary,
    tertiaryContainer = LightSurfaceVariant,
    background = LightCreamBackground,      // #FDFBD4 Background
    surface = LightSurface,                 // #FFFEEB Surface
    surfaceVariant = LightSurfaceVariant,   // #F6F0B5 Surface Variant
    onBackground = LightBrownTextPrimary,   // #38240D Text Primary
    onSurface = LightBrownTextPrimary,       // #38240D Text Primary
    onSurfaceVariant = LightTextMutedBrown,
    outline = LightSoftBrownBorder
  )

@Composable
fun SwadhyayiMandalTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) = SwadhyayiMandalTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)


