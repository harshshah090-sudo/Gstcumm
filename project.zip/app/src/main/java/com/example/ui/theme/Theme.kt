package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

// Dark Theme Palette (#101614, #1B2420, #D4A24C, #2F6B4F, #EDE7DA, #8FA096, #8FCB9E)
private val DarkColorScheme =
  darkColorScheme(
    primary = AppPrimaryAccent,            // #D4A24C Buttons, headings, tags, FAB
    onPrimary = Color(0xFF101614),         // Dark text on primary button
    primaryContainer = AppPrimaryContainer,
    onPrimaryContainer = AppOnPrimaryContainer,
    secondary = AppSecondaryAccent,        // #2F6B4F Hero gradient, borders
    onSecondary = Color.White,
    secondaryContainer = AppSecondaryContainer,
    onSecondaryContainer = AppOnSecondaryContainer,
    tertiary = AppSuccessPaleGreen,        // #8FCB9E Tag text on city chip
    onTertiary = Color(0xFF101614),
    tertiaryContainer = AppSecondaryContainer,
    onTertiaryContainer = AppSuccessPaleGreen,
    background = AppBackground,            // #101614 Background
    onBackground = AppTextPrimary,         // #EDE7DA Text primary
    surface = AppSurface,                  // #1B2420 Surface/card
    onSurface = AppTextPrimary,            // #EDE7DA Text primary
    surfaceVariant = AppSurfaceVariant,    // Cards, search bar, header logo bg
    onSurfaceVariant = AppTextMuted,       // #8FA096 Text muted
    outline = AppSecondaryAccent,          // #2F6B4F Borders
    outlineVariant = Color(0xFF26382F)
  )

// Light Theme Palette
private val LightColorScheme =
  lightColorScheme(
    primary = LightPrimaryGold,              // #C1861F Buttons, headings, tags, active tab, FAB
    onPrimary = Color.White,
    primaryContainer = LightSurfaceNested,   // #F0EDE1
    onPrimaryContainer = LightTextPrimary,
    secondary = LightSecondaryGreen,          // #2F6B4F
    onSecondary = Color.White,
    secondaryContainer = LightSurfaceNested,
    onSecondaryContainer = LightTextPrimary,
    tertiary = LightTertiaryMaroon,          // #8A2E3F
    onTertiary = Color.White,
    tertiaryContainer = LightSurfaceNested,
    onTertiaryContainer = LightTextPrimary,
    background = LightBackground,            // #F7F5EE App base
    onBackground = LightTextPrimary,         // #241E15 Text primary
    surface = LightSurface,                  // #FFFFFF Cards, search bar, header logo bg
    onSurface = LightTextPrimary,            // #241E15 Text primary
    surfaceVariant = LightSurfaceNested,     // #F0EDE1
    onSurfaceVariant = LightTextMuted,       // #736C5C Text muted
    outline = LightBorder,                   // #E3DFCF Card borders, inactive tab borders
    outlineVariant = LightBorder
  )

@Composable
fun SwadhyayiMandalTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) = SwadhyayiMandalTheme(darkTheme = true, dynamicColor = dynamicColor, content = content)


