package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sangh_allotments")
data class AllotmentEntity(
    @PrimaryKey
    val sanghId: Long,
    val sanghName: String = "",
    val cityName: String = "",
    val stateName: String = "",
    val swadhyaiIds: String = "", // Comma-separated list of Swadhyai IDs e.g. "12,15,20"
    val updatedAt: Long = System.currentTimeMillis()
)
