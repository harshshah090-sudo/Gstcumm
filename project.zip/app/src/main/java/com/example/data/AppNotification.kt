package com.example.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "app_notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "GYAN_NOTE", "SWADHYAI_REGISTRATION"
    val title: String,
    val message: String,
    val targetId: String, // Topic ID or Swadhyai ID
    val targetExtraId: String = "", // Category ID for Gyan Note
    val timestamp: Long = System.currentTimeMillis(),
    val isSeen: Boolean = false,
    val seenTimestamp: Long? = null
)

@Dao
interface AppNotificationDao {
    @Query("SELECT * FROM app_notifications ORDER BY timestamp DESC")
    fun getAllNotificationsFlow(): Flow<List<AppNotification>>

    @Query("SELECT * FROM app_notifications WHERE isSeen = 0 ORDER BY timestamp DESC")
    fun getUnseenNotificationsFlow(): Flow<List<AppNotification>>

    @Query("SELECT * FROM app_notifications WHERE isSeen = 1 ORDER BY timestamp DESC")
    fun getSeenNotificationsFlow(): Flow<List<AppNotification>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE isSeen = 0")
    fun getUnseenCountFlow(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification): Long

    @Query("UPDATE app_notifications SET isSeen = 1, seenTimestamp = :timestamp WHERE id = :id")
    suspend fun markAsSeen(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE app_notifications SET isSeen = 1, seenTimestamp = :timestamp WHERE type = :type AND targetId = :targetId")
    suspend fun markByTargetAsSeen(type: String, targetId: String, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE app_notifications SET isSeen = 1, seenTimestamp = :timestamp WHERE isSeen = 0")
    suspend fun markAllAsSeen(timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM app_notifications WHERE isSeen = 1")
    suspend fun clearSeenNotifications()

    @Query("DELETE FROM app_notifications WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM app_notifications")
    suspend fun clearAllNotifications()
}
