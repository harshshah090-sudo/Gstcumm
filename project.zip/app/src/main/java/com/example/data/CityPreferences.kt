package com.example.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object CityPreferences {
    private const val PREFS_NAME = "jain_panchang_city_prefs"
    private const val KEY_CITY_ID = "selected_city_id"
    private const val KEY_CITY_NAME = "selected_city_name"
    private const val KEY_CITY_HINDI_NAME = "selected_city_hindi_name"
    private const val KEY_CITY_STATE = "selected_city_state"
    private const val KEY_CITY_LAT = "selected_city_lat"
    private const val KEY_CITY_LNG = "selected_city_lng"
    private const val KEY_CITY_TZ = "selected_city_tz"

    private val _selectedCityFlow = MutableStateFlow(DefaultCities.DEFAULT_CITY)
    val selectedCityFlow: StateFlow<CityLocation> = _selectedCityFlow.asStateFlow()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun init(context: Context) {
        _selectedCityFlow.value = getSelectedCity(context)
    }

    fun getSelectedCity(context: Context): CityLocation {
        val prefs = getPrefs(context)
        val cityId = prefs.getString(KEY_CITY_ID, null) ?: return DefaultCities.DEFAULT_CITY

        // Check if it matches a predefined city
        val found = DefaultCities.ALL_CITIES.find { it.id == cityId }
        if (found != null) return found

        // Otherwise load custom saved city
        val name = prefs.getString(KEY_CITY_NAME, "Ahmedabad") ?: "Ahmedabad"
        val hindiName = prefs.getString(KEY_CITY_HINDI_NAME, "अहमदाबाद") ?: "अहमदाबाद"
        val state = prefs.getString(KEY_CITY_STATE, "Gujarat, India") ?: "Gujarat, India"
        val lat = prefs.getFloat(KEY_CITY_LAT, 23.0225f).toDouble()
        val lng = prefs.getFloat(KEY_CITY_LNG, 72.5714f).toDouble()
        val tz = prefs.getString(KEY_CITY_TZ, "Asia/Kolkata") ?: "Asia/Kolkata"

        return CityLocation(
            id = cityId,
            name = name,
            hindiName = hindiName,
            stateOrCountry = state,
            latitude = lat,
            longitude = lng,
            timezoneId = tz
        )
    }

    fun saveSelectedCity(context: Context, city: CityLocation) {
        val prefs = getPrefs(context)
        prefs.edit()
            .putString(KEY_CITY_ID, city.id)
            .putString(KEY_CITY_NAME, city.name)
            .putString(KEY_CITY_HINDI_NAME, city.hindiName)
            .putString(KEY_CITY_STATE, city.stateOrCountry)
            .putFloat(KEY_CITY_LAT, city.latitude.toFloat())
            .putFloat(KEY_CITY_LNG, city.longitude.toFloat())
            .putString(KEY_CITY_TZ, city.timezoneId)
            .apply()

        _selectedCityFlow.value = city
        try {
            com.example.widget.TithiAppWidget.updateAllWidgets(context)
        } catch (_: Throwable) {}
    }
}
