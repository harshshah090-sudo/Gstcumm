package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine

class AppRepository(
    private val customerDao: CustomerDao,
    private val billDao: BillDao,
    private val paymentDao: PaymentDao
) {
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val allBills: Flow<List<Bill>> = billDao.getAllBills()
    val allPayments: Flow<List<Payment>> = paymentDao.getAllPayments()

    // Real-time combined summaries of outstanding balances per customer
    val customerSummaries: Flow<List<CustomerSummary>> = combine(
        allCustomers,
        allBills,
        allPayments
    ) { customers, bills, payments ->
        customers.map { customer ->
            val custBills = bills.filter { it.customerId == customer.id }
            val custPayments = payments.filter { it.customerId == customer.id }

            val totalBilled = (if (customer.openingBalance > 0.0) customer.openingBalance else 0.0) + custBills.sumOf { bill ->
                if (bill.commissionRate == 0.0) {
                    bill.totalAmount
                } else if (bill.amountGivenToCustomer == 0.0 && bill.amountPaidToCompany == 0.0) {
                    (bill.baseAmount + bill.gstAmount) + bill.commissionAmount
                } else {
                    bill.amountGivenToCustomer + bill.commissionAmount
                }
            } + custPayments.filter { it.isGivenToCustomer }.sumOf { it.amount }
            val totalPaid = (if (customer.openingBalance < 0.0) -customer.openingBalance else 0.0) + custBills.sumOf { bill ->
                if (bill.commissionRate == 0.0) {
                    0.0
                } else if (bill.amountGivenToCustomer == 0.0 && bill.amountPaidToCompany == 0.0) {
                    bill.baseAmount + bill.gstAmount
                } else {
                    bill.amountPaidToCompany
                }
            } + custPayments.filter { !it.isGivenToCustomer }.sumOf { it.amount }
            val outstanding = totalBilled - totalPaid

            CustomerSummary(
                customer = customer,
                totalBilled = totalBilled,
                totalPaid = totalPaid,
                outstandingBalance = outstanding,
                billCount = custBills.size,
                paymentCount = custPayments.size
            )
        }
    }

    suspend fun getCustomerById(id: Int): Customer? = customerDao.getCustomerById(id)

    suspend fun insertCustomer(customer: Customer): Long = customerDao.insertCustomer(customer)
    suspend fun updateCustomer(customer: Customer) = customerDao.updateCustomer(customer)
    suspend fun deleteCustomer(customer: Customer) = customerDao.deleteCustomer(customer)

    suspend fun insertBill(bill: Bill): Long = billDao.insertBill(bill)
    suspend fun updateBill(bill: Bill) = billDao.updateBill(bill)
    suspend fun deleteBill(bill: Bill) = billDao.deleteBill(bill)

    suspend fun insertPayment(payment: Payment): Long = paymentDao.insertPayment(payment)
    suspend fun updatePayment(payment: Payment) = paymentDao.updatePayment(payment)
    suspend fun deletePayment(payment: Payment) = paymentDao.deletePayment(payment)
}
