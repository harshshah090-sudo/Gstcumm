package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "customers",
    indices = [Index(value = ["name"], unique = true)]
)
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String = "",
    val email: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val openingBalance: Double = 0.0
)

@Entity(
    tableName = "bills",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId")]
)
data class Bill(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val billName: String, // Bill/Invoice generation name/number
    val baseAmount: Double, // Pre-tax amount
    val gstPercentage: Int, // 5, 12, or 18
    val gstAmount: Double, // calculated matching gstPercentage
    val commissionRate: Double, // percentage of baseAmount (e.g. 1.5, 2.0, 3.0)
    val commissionAmount: Double, // calculated based on commissionRate
    val totalAmount: Double, // baseAmount + gstAmount + commissionAmount
    val amountGivenToCustomer: Double = 0.0,
    val amountPaidToCompany: Double = 0.0,
    val date: Long = System.currentTimeMillis(),
    val customerPaid: Boolean = false
)

@Entity(
    tableName = "payments",
    foreignKeys = [
        ForeignKey(
            entity = Customer::class,
            parentColumns = ["id"],
            childColumns = ["customerId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("customerId")]
)
data class Payment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val amount: Double,
    val date: Long = System.currentTimeMillis(),
    val note: String = "",
    val isGivenToCustomer: Boolean = false
)

// UI support model to aggregate customer balances easily
data class CustomerSummary(
    val customer: Customer,
    val totalBilled: Double,
    val totalPaid: Double,
    val outstandingBalance: Double,
    val billCount: Int,
    val paymentCount: Int
)
