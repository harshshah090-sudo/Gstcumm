package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fund_transactions")
data class FundTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // "INCOMING" or "EXPENDITURE"
    val mode: String, // "BANK" or "CASH"
    val amount: Double,
    val title: String = "",
    val description: String = "",
    val personName: String = "",
    val date: Long = System.currentTimeMillis(),
    val remoteId: String = ""
)
