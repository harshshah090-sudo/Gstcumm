package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "timeline_posts")
data class TimelinePostEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val heading: String = "",
    val subHeading: String = "",
    val description: String = "",
    val dateEpochMillis: Long = System.currentTimeMillis(),
    val photoUris: String = "", // Comma-separated list of image URIs/paths
    val isDeleted: Boolean = false,
    val createdAtEpochMillis: Long = System.currentTimeMillis()
)
