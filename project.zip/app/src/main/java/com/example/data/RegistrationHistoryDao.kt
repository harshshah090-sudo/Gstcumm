package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RegistrationHistoryDao {
    @Query("SELECT * FROM registration_history ORDER BY year DESC")
    fun getAllHistories(): Flow<List<RegistrationHistoryEntity>>

    @Query("SELECT * FROM registration_history WHERE year = :year LIMIT 1")
    suspend fun getHistoryByYear(year: Int): RegistrationHistoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: RegistrationHistoryEntity)

    @Delete
    suspend fun deleteHistory(history: RegistrationHistoryEntity)

    @Query("DELETE FROM registration_history WHERE year = :year")
    suspend fun deleteByYear(year: Int)

    @Query("SELECT * FROM registration_history ORDER BY year DESC")
    suspend fun getAllHistoriesList(): List<RegistrationHistoryEntity>
}
