package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GyanDao {
    @Query("SELECT * FROM gyan_categories ORDER BY orderIndex ASC, id ASC")
    fun getAllCategories(): Flow<List<GyanCategoryEntity>>

    @Query("SELECT * FROM gyan_categories WHERE id = :id")
    suspend fun getCategoryById(id: Long): GyanCategoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: GyanCategoryEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<GyanCategoryEntity>)

    @Update
    suspend fun updateCategory(category: GyanCategoryEntity)

    @Delete
    suspend fun deleteCategory(category: GyanCategoryEntity)

    @Query("DELETE FROM gyan_categories WHERE id = :id")
    suspend fun deleteCategoryById(id: Long)

    @Query("SELECT COUNT(*) FROM gyan_categories")
    suspend fun getCategoryCount(): Int

    // Topics Queries
    @Query("SELECT * FROM gyan_topics WHERE categoryId = :categoryId ORDER BY id ASC")
    fun getTopicsForCategory(categoryId: Long): Flow<List<GyanTopicEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopic(topic: GyanTopicEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTopics(topics: List<GyanTopicEntity>)

    @Update
    suspend fun updateTopic(topic: GyanTopicEntity)

    @Delete
    suspend fun deleteTopic(topic: GyanTopicEntity)

    @Query("DELETE FROM gyan_topics WHERE id = :id")
    suspend fun deleteTopicById(id: Long)
}
