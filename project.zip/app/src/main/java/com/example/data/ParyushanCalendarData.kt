package com.example.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class JainGacch(val displayNameHindi: String, val displayNameEng: String) {
    TAPAGACCH("तपागच्छ", "Tapagacch"),
    KHARATARGACCH("खरतरगच्छ", "Kharatargacch")
}

enum class ParyushanPhase(val titleHindi: String, val subtitleHindi: String) {
    COUNTDOWN_TO_PARYUSHAN("पर्यूषण महापर्व प्रारंभ काउंटडाउन", "प्रथम दिवस (डे १) प्रारंभ हेतु शेष समय"),
    MAHAVIR_JANM_VANCHAN("श्री महावीर जन्म वांचन काउंटडाउन", "पावन जन्म वांचन महोत्सव (डे ५) हेतु शेष समय"),
    SAMVATSARI("संवत्सरी महापर्व काउंटडाउन", "संवत्सरी प्रतिक्रमण एवं क्षमापना (डे ८) हेतु शेष समय"),
    SAMVATSARI_ACTIVE("आज संवत्सरी महापर्व है 🙏", "उत्तम क्षमा - मिच्छामि दुक्कडम्"),
    POST_PARYUSHAN_NEXT_YEAR("अगले वर्ष का पर्यूषण पर्व", "आगामी पर्यूषण पर्व तिथि एवं काउंटडाउन")
}

data class ParyushanYearSchedule(
    val year: Int,
    val gacch: JainGacch,
    val startDateMillis: Long,          // Day 1 Start (approx 06:00 AM)
    val janmVanchanDateMillis: Long,   // Day 5 Start (approx 09:00 AM)
    val samvatsariDateMillis: Long,     // Day 8 Start (approx 06:00 AM)
    val endDateMillis: Long             // Day 8 End (approx 23:59 PM)
)

data class DayItinerary(
    val dayNumber: Int,
    val dateString: String,
    val titleHindi: String,
    val descriptionHindi: String,
    val isHighlighted: Boolean = false
)

data class ParyushanCountdownState(
    val year: Int,
    val gacch: JainGacch,
    val phase: ParyushanPhase,
    val currentDayNumber: Int, // 1 to 8 if active, 0 otherwise
    val targetTimeMillis: Long,
    val daysRemaining: Long,
    val hoursRemaining: Long,
    val minutesRemaining: Long,
    val secondsRemaining: Long,
    val startDateFormatted: String,
    val janmVanchanDateFormatted: String,
    val samvatsariDateFormatted: String,
    val isTwoGacchDifferentThisYear: Boolean = false,
    val itinerary: List<DayItinerary>
)

object ParyushanCalendarRepository {

    private fun createDateMillis(year: Int, month: Int, day: Int, hour: Int = 6, minute: Int = 0): Long {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1) // 0-based
        cal.set(Calendar.DAY_OF_MONTH, day)
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // Comprehensive multi-year Paryushan dates for Tapagacch and Kharatargacch
    val allSchedules = listOf(
        // 2025
        ParyushanYearSchedule(
            year = 2025,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2025, 8, 20, 6, 0),
            janmVanchanDateMillis = createDateMillis(2025, 8, 24, 9, 0),
            samvatsariDateMillis = createDateMillis(2025, 8, 27, 6, 0),
            endDateMillis = createDateMillis(2025, 8, 27, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2025,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2025, 8, 21, 6, 0),
            janmVanchanDateMillis = createDateMillis(2025, 8, 25, 9, 0),
            samvatsariDateMillis = createDateMillis(2025, 8, 28, 6, 0),
            endDateMillis = createDateMillis(2025, 8, 28, 23, 59)
        ),

        // 2026
        ParyushanYearSchedule(
            year = 2026,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2026, 8, 8, 6, 0),
            janmVanchanDateMillis = createDateMillis(2026, 8, 12, 9, 0),
            samvatsariDateMillis = createDateMillis(2026, 8, 15, 6, 0),
            endDateMillis = createDateMillis(2026, 8, 15, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2026,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2026, 8, 9, 6, 0),
            janmVanchanDateMillis = createDateMillis(2026, 8, 13, 9, 0),
            samvatsariDateMillis = createDateMillis(2026, 8, 16, 6, 0),
            endDateMillis = createDateMillis(2026, 8, 16, 23, 59)
        ),

        // 2027
        ParyushanYearSchedule(
            year = 2027,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2027, 8, 28, 6, 0),
            janmVanchanDateMillis = createDateMillis(2027, 9, 1, 9, 0),
            samvatsariDateMillis = createDateMillis(2027, 9, 4, 6, 0),
            endDateMillis = createDateMillis(2027, 9, 4, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2027,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2027, 8, 28, 6, 0),
            janmVanchanDateMillis = createDateMillis(2027, 9, 1, 9, 0),
            samvatsariDateMillis = createDateMillis(2027, 9, 4, 6, 0),
            endDateMillis = createDateMillis(2027, 9, 4, 23, 59)
        ),

        // 2028
        ParyushanYearSchedule(
            year = 2028,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2028, 8, 16, 6, 0),
            janmVanchanDateMillis = createDateMillis(2028, 8, 20, 9, 0),
            samvatsariDateMillis = createDateMillis(2028, 8, 23, 6, 0),
            endDateMillis = createDateMillis(2028, 8, 23, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2028,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2028, 8, 17, 6, 0),
            janmVanchanDateMillis = createDateMillis(2028, 8, 21, 9, 0),
            samvatsariDateMillis = createDateMillis(2028, 8, 24, 6, 0),
            endDateMillis = createDateMillis(2028, 8, 24, 23, 59)
        ),

        // 2029
        ParyushanYearSchedule(
            year = 2029,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2029, 8, 5, 6, 0),
            janmVanchanDateMillis = createDateMillis(2029, 8, 9, 9, 0),
            samvatsariDateMillis = createDateMillis(2029, 8, 12, 6, 0),
            endDateMillis = createDateMillis(2029, 8, 12, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2029,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2029, 8, 5, 6, 0),
            janmVanchanDateMillis = createDateMillis(2029, 8, 9, 9, 0),
            samvatsariDateMillis = createDateMillis(2029, 8, 12, 6, 0),
            endDateMillis = createDateMillis(2029, 8, 12, 23, 59)
        ),

        // 2030
        ParyushanYearSchedule(
            year = 2030,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2030, 8, 24, 6, 0),
            janmVanchanDateMillis = createDateMillis(2030, 8, 28, 9, 0),
            samvatsariDateMillis = createDateMillis(2030, 8, 31, 6, 0),
            endDateMillis = createDateMillis(2030, 8, 31, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2030,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2030, 8, 24, 6, 0),
            janmVanchanDateMillis = createDateMillis(2030, 8, 28, 9, 0),
            samvatsariDateMillis = createDateMillis(2030, 8, 31, 6, 0),
            endDateMillis = createDateMillis(2030, 8, 31, 23, 59)
        )
    )

    fun formatDate(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN"))
        sdf.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        return sdf.format(Date(millis))
    }

    fun formatDateShort(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMM", Locale("hi", "IN"))
        sdf.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        return sdf.format(Date(millis))
    }

    fun getCountdownState(
        gacch: JainGacch,
        nowMillis: Long = System.currentTimeMillis()
    ): ParyushanCountdownState {
        // Find relevant schedule
        val currentYearSchedules = allSchedules.filter { it.gacch == gacch }
        
        // Find if active or upcoming schedule for this year/next year
        var activeSchedule = currentYearSchedules.firstOrNull { schedule ->
            nowMillis <= schedule.endDateMillis
        }

        if (activeSchedule == null) {
            // Fallback to latest
            activeSchedule = currentYearSchedules.last()
        }

        val tapagacchThisYear = allSchedules.find { it.year == activeSchedule.year && it.gacch == JainGacch.TAPAGACCH }
        val kharatargacchThisYear = allSchedules.find { it.year == activeSchedule.year && it.gacch == JainGacch.KHARATARGACCH }
        val isTwoGacchDiff = tapagacchThisYear != null && kharatargacchThisYear != null &&
                (tapagacchThisYear.startDateMillis != kharatargacchThisYear.startDateMillis ||
                 tapagacchThisYear.samvatsariDateMillis != kharatargacchThisYear.samvatsariDateMillis)

        var phase: ParyushanPhase
        var targetMillis: Long
        var currentDay = 0

        if (nowMillis < activeSchedule.startDateMillis) {
            // 1. Before Paryushan starts -> Countdown to Day 1
            phase = ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
            targetMillis = activeSchedule.startDateMillis
        } else if (nowMillis >= activeSchedule.startDateMillis && nowMillis < activeSchedule.janmVanchanDateMillis) {
            // 2. Paryushan started (Day 1 - 4) -> Countdown to Mahavir Janm Vanchan (Day 5)
            phase = ParyushanPhase.MAHAVIR_JANM_VANCHAN
            targetMillis = activeSchedule.janmVanchanDateMillis
            // Calculate day (1 to 4)
            val diffMs = nowMillis - activeSchedule.startDateMillis
            val dayCalc = (diffMs / (24 * 3600 * 1000L)).toInt() + 1
            currentDay = dayCalc.coerceIn(1, 4)
        } else if (nowMillis >= activeSchedule.janmVanchanDateMillis && nowMillis < activeSchedule.samvatsariDateMillis) {
            // 3. After Janm Vanchan (Day 5 - 7) -> Countdown to Samvatsari (Day 8)
            phase = ParyushanPhase.SAMVATSARI
            targetMillis = activeSchedule.samvatsariDateMillis
            val diffMs = nowMillis - activeSchedule.startDateMillis
            val dayCalc = (diffMs / (24 * 3600 * 1000L)).toInt() + 1
            currentDay = dayCalc.coerceIn(5, 7)
        } else if (nowMillis >= activeSchedule.samvatsariDateMillis && nowMillis <= activeSchedule.endDateMillis) {
            // 4. On Samvatsari Day 8
            phase = ParyushanPhase.SAMVATSARI_ACTIVE
            targetMillis = activeSchedule.endDateMillis
            currentDay = 8
        } else {
            // 5. Post Samvatsari -> Countdown to Next Year's Paryushan
            phase = ParyushanPhase.POST_PARYUSHAN_NEXT_YEAR
            val nextSchedule = currentYearSchedules.firstOrNull { it.year > activeSchedule.year }
            targetMillis = nextSchedule?.startDateMillis ?: (activeSchedule.startDateMillis + 365 * 24 * 3600 * 1000L)
        }

        val diff = (targetMillis - nowMillis).coerceAtLeast(0L)
        val days = diff / (1000 * 60 * 60 * 24)
        val hours = (diff / (1000 * 60 * 60)) % 24
        val minutes = (diff / (1000 * 60)) % 60
        val seconds = (diff / 1000) % 60

        val itinerary = build8DayItinerary(activeSchedule)

        return ParyushanCountdownState(
            year = activeSchedule.year,
            gacch = activeSchedule.gacch,
            phase = phase,
            currentDayNumber = currentDay,
            targetTimeMillis = targetMillis,
            daysRemaining = days,
            hoursRemaining = hours,
            minutesRemaining = minutes,
            secondsRemaining = seconds,
            startDateFormatted = formatDate(activeSchedule.startDateMillis),
            janmVanchanDateFormatted = formatDate(activeSchedule.janmVanchanDateMillis),
            samvatsariDateFormatted = formatDate(activeSchedule.samvatsariDateMillis),
            isTwoGacchDifferentThisYear = isTwoGacchDiff,
            itinerary = itinerary
        )
    }

    private fun build8DayItinerary(schedule: ParyushanYearSchedule): List<DayItinerary> {
        val startMs = schedule.startDateMillis
        val dayMs = 24 * 3600 * 1000L

        val dayTitles = listOf(
            "दिवस १: खाद्य संयम एवं अमारी प्रवर्तन" to "स्वाध्याय प्रारंभ, खाद्य पदार्थों पर नियंत्रण, जीवदया का विशेष संकल्प।",
            "दिवस २: स्वाध्याय एवं साधर्मिक भक्ति" to "धार्मिक ग्रंथों का वांचन, साधर्मिक भाइयों का सम्मान एवं सेवा।",
            "दिवस ३: अट्ठाई तप प्रारंभ एवं छत्र पूजन" to "अट्ठाई तपस्वियों का आदर, जिन मंदिर में छत्र एवं मंडप पूजन।",
            "दिवस ४: श्री कल्पसूत्र पूजन एवं आगमन" to "श्री कल्पसूत्र जी का बाजे-गाजे के साथ मंगल आगमन एवं शोभायात्रा।",
            "दिवस ५: श्री महावीर स्वामी जन्म वांचन" to "प्रभु महावीर के ३६ स्वप्नों का वांचन, जन्म कल्याणक महामहोत्सव हर्षोल्लास।",
            "दिवस ६: श्री प्रभु चरित्र एवं कल्पसूत्र वांचन" to "तीर्थंकर प्रभु के दिव्य चरित्र का वांचन, वैराग्य भावना का चिंतन।",
            "दिवस ७: बरसा सूत्र एवं संवत्सरी विचार" to "संवत्सरी पूर्व संध्या चिंतन, अंतरात्मा का निरीक्षण एवं प्रतिक्रमण तैयारी।",
            "दिवस ८: महापर्व संवत्सरी - सर्व जीव क्षमापना" to "वार्षिक संवत्सरी प्रतिक्रमण, सर्व जीवों से खमतखामणा (मिच्छामि दुक्कडम्)।"
        )

        return dayTitles.mapIndexed { index, pair ->
            val curDayMs = startMs + (index * dayMs)
            DayItinerary(
                dayNumber = index + 1,
                dateString = formatDateShort(curDayMs),
                titleHindi = pair.first,
                descriptionHindi = pair.second,
                isHighlighted = (index + 1 == 5 || index + 1 == 8) // Janm Vanchan and Samvatsari
            )
        }
    }
}
