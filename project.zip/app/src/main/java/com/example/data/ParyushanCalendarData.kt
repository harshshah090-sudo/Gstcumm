package com.example.data

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

enum class JainGacch(val displayNameHindi: String, val displayNameEng: String) {
    TAPAGACCH("तपागच्छ", "Tapagacch"),
    KHARATARGACCH("खरतरगच्छ", "Kharatargacch")
}

enum class ParyushanPhase(val titleHindi: String, val subtitleHindi: String) {
    COUNTDOWN_TO_PARYUSHAN("Time Left for Paryushan", ""),
    PARYUSHAN_ACTIVE("पर्यूषण महापर्व", ""),
    PARYUSHAN_COMPLETED("पर्यूषण पर्व समाप्त 🙏🏻", "मिच्छामि दुक्कडम्"),
    MAHAVIR_JANM_VANCHAN("श्री महावीर जन्म वांचन काउंटडाउन", "पावन जन्म वांचन महोत्सव हेतु शेष समय"),
    SAMVATSARI("संवत्सरी महापर्व काउंटडाउन", "संवत्सरी प्रतिक्रमण एवं क्षमापना हेतु शेष समय"),
    SAMVATSARI_ACTIVE("आज संवत्सरी महापर्व है 🙏", "उत्तम क्षमा - मिच्छामि दुक्कडम्"),
    POST_PARYUSHAN_NEXT_YEAR("Time Left for Paryushan", "")
}

data class ParyushanDayDuty(
    val dayNumber: Int,
    val mainText: String,
    val subText: String
)

val PARYUSHAN_DAY_DUTIES = listOf(
    ParyushanDayDuty(1, "Day 1", "पर्यूषण 5 कर्तव्य"),
    ParyushanDayDuty(2, "Day 2", "वार्षिक 11 कर्तव्य"),
    ParyushanDayDuty(3, "Day 3", "पौषध आत्मा का औषध"),
    ParyushanDayDuty(4, "Day 4", "कल्पसूत्र वांचन"),
    ParyushanDayDuty(5, "Day 5", "जन्म वांचन"),
    ParyushanDayDuty(6, "Day 6", "पार्श्व, नेम एवं ऋषभ चरित्र"),
    ParyushanDayDuty(7, "Day 7", "स्थविरावली एवं समाचारी"),
    ParyushanDayDuty(8, "Day 8", "संवत्सरी एवं क्षमापना")
)

data class ParyushanYearSchedule(
    val year: Int,
    val gacch: JainGacch,
    val startDateMillis: Long,          // Day 1 Start (approx 06:00 AM)
    val janmVanchanDateMillis: Long,   // Day 5 Start (approx 09:00 AM)
    val samvatsariDateMillis: Long,     // Day 8 Start (approx 06:00 AM)
    val endDateMillis: Long             // Day 8 End (approx 23:59 PM)
)

data class DayItinerary(
    val dayNumber: Int,
    val dateString: String,
    val titleHindi: String,
    val descriptionHindi: String,
    val isHighlighted: Boolean = false
)

data class ParyushanCountdownState(
    val year: Int,
    val gacch: JainGacch,
    val phase: ParyushanPhase,
    val currentDayNumber: Int, // 1 to 8 if active, 0 otherwise
    val targetTimeMillis: Long,
    val daysRemaining: Long,
    val hoursRemaining: Long,
    val minutesRemaining: Long,
    val secondsRemaining: Long,
    val startDateFormatted: String,
    val janmVanchanDateFormatted: String,
    val samvatsariDateFormatted: String,
    val isTwoGacchDifferentThisYear: Boolean = false,
    val itinerary: List<DayItinerary>,
    val activeDayMainText: String = "",
    val activeDaySubText: String = ""
)

object ParyushanCalendarRepository {

    private fun createDateMillis(year: Int, month: Int, day: Int, hour: Int = 6, minute: Int = 0): Long {
        val cal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        cal.set(Calendar.YEAR, year)
        cal.set(Calendar.MONTH, month - 1) // 0-based
        cal.set(Calendar.DAY_OF_MONTH, day)
        cal.set(Calendar.HOUR_OF_DAY, hour)
        cal.set(Calendar.MINUTE, minute)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    // Comprehensive multi-year Paryushan dates for Tapagacch and Kharatargacch
    val allSchedules = listOf(
        // 2025
        ParyushanYearSchedule(
            year = 2025,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2025, 8, 20, 6, 0),
            janmVanchanDateMillis = createDateMillis(2025, 8, 24, 9, 0),
            samvatsariDateMillis = createDateMillis(2025, 8, 27, 6, 0),
            endDateMillis = createDateMillis(2025, 8, 27, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2025,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2025, 8, 20, 6, 0),
            janmVanchanDateMillis = createDateMillis(2025, 8, 24, 9, 0),
            samvatsariDateMillis = createDateMillis(2025, 8, 27, 6, 0),
            endDateMillis = createDateMillis(2025, 8, 27, 23, 59)
        ),

        // 2026
        ParyushanYearSchedule(
            year = 2026,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2026, 9, 8, 6, 0),
            janmVanchanDateMillis = createDateMillis(2026, 9, 12, 9, 0),
            samvatsariDateMillis = createDateMillis(2026, 9, 15, 6, 0),
            endDateMillis = createDateMillis(2026, 9, 15, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2026,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2026, 9, 8, 6, 0),
            janmVanchanDateMillis = createDateMillis(2026, 9, 12, 9, 0),
            samvatsariDateMillis = createDateMillis(2026, 9, 15, 6, 0),
            endDateMillis = createDateMillis(2026, 9, 15, 23, 59)
        ),

        // 2027
        ParyushanYearSchedule(
            year = 2027,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2027, 8, 28, 6, 0),
            janmVanchanDateMillis = createDateMillis(2027, 9, 1, 9, 0),
            samvatsariDateMillis = createDateMillis(2027, 9, 4, 6, 0),
            endDateMillis = createDateMillis(2027, 9, 4, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2027,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2027, 8, 28, 6, 0),
            janmVanchanDateMillis = createDateMillis(2027, 9, 1, 9, 0),
            samvatsariDateMillis = createDateMillis(2027, 9, 4, 6, 0),
            endDateMillis = createDateMillis(2027, 9, 4, 23, 59)
        ),

        // 2028
        ParyushanYearSchedule(
            year = 2028,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2028, 8, 16, 6, 0),
            janmVanchanDateMillis = createDateMillis(2028, 8, 20, 9, 0),
            samvatsariDateMillis = createDateMillis(2028, 8, 23, 6, 0),
            endDateMillis = createDateMillis(2028, 8, 23, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2028,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2028, 8, 17, 6, 0),
            janmVanchanDateMillis = createDateMillis(2028, 8, 21, 9, 0),
            samvatsariDateMillis = createDateMillis(2028, 8, 24, 6, 0),
            endDateMillis = createDateMillis(2028, 8, 24, 23, 59)
        ),

        // 2029
        ParyushanYearSchedule(
            year = 2029,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2029, 8, 5, 6, 0),
            janmVanchanDateMillis = createDateMillis(2029, 8, 9, 9, 0),
            samvatsariDateMillis = createDateMillis(2029, 8, 12, 6, 0),
            endDateMillis = createDateMillis(2029, 8, 12, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2029,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2029, 8, 5, 6, 0),
            janmVanchanDateMillis = createDateMillis(2029, 8, 9, 9, 0),
            samvatsariDateMillis = createDateMillis(2029, 8, 12, 6, 0),
            endDateMillis = createDateMillis(2029, 8, 12, 23, 59)
        ),

        // 2030
        ParyushanYearSchedule(
            year = 2030,
            gacch = JainGacch.TAPAGACCH,
            startDateMillis = createDateMillis(2030, 8, 24, 6, 0),
            janmVanchanDateMillis = createDateMillis(2030, 8, 28, 9, 0),
            samvatsariDateMillis = createDateMillis(2030, 8, 31, 6, 0),
            endDateMillis = createDateMillis(2030, 8, 31, 23, 59)
        ),
        ParyushanYearSchedule(
            year = 2030,
            gacch = JainGacch.KHARATARGACCH,
            startDateMillis = createDateMillis(2030, 8, 24, 6, 0),
            janmVanchanDateMillis = createDateMillis(2030, 8, 28, 9, 0),
            samvatsariDateMillis = createDateMillis(2030, 8, 31, 6, 0),
            endDateMillis = createDateMillis(2030, 8, 31, 23, 59)
        )
    )

    fun formatDate(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMMM yyyy", Locale("hi", "IN"))
        sdf.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        return sdf.format(Date(millis))
    }

    fun formatDateShort(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMM", Locale("hi", "IN"))
        sdf.timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        return sdf.format(Date(millis))
    }

    fun getPanchangParyushanSchedule(
        panchangEvents: List<PanchangEventEntity>,
        year: Int,
        gacch: JainGacch
    ): ParyushanYearSchedule? {
        if (panchangEvents.isEmpty()) return null
        val yearEvents = panchangEvents.filter { it.dateString.startsWith("$year-") }
        if (yearEvents.isEmpty()) return null

        val startEvent = yearEvents.find {
            (it.parvasAndEvents.contains("पर्युषण", ignoreCase = true) || it.parvasAndEvents.contains("पर्यूषण", ignoreCase = true)) &&
            (it.parvasAndEvents.contains("प्रारंभ", ignoreCase = true) || it.parvasAndEvents.contains("शुरू", ignoreCase = true) || it.parvasAndEvents.contains("पहला", ignoreCase = true))
        } ?: yearEvents.find {
            it.parvasAndEvents.contains("पर्युषण", ignoreCase = true) || it.parvasAndEvents.contains("पर्यूषण", ignoreCase = true)
        }

        val janmEvent = yearEvents.find {
            it.parvasAndEvents.contains("जन्म वांचन", ignoreCase = true) || it.parvasAndEvents.contains("जन्मवांचन", ignoreCase = true)
        }

        val samvatsariEvent = yearEvents.find {
            it.parvasAndEvents.contains("संवत्सरी", ignoreCase = true)
        }

        if (startEvent == null && samvatsariEvent == null) return null

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).apply {
            timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        }

        val startCal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        val samvatsariCal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))
        val janmCal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata"))

        var hasStart = false
        var hasSamvatsari = false

        if (startEvent != null) {
            val d = sdf.parse(startEvent.dateString)
            if (d != null) {
                startCal.time = d
                startCal.set(Calendar.HOUR_OF_DAY, 6)
                startCal.set(Calendar.MINUTE, 0)
                startCal.set(Calendar.SECOND, 0)
                startCal.set(Calendar.MILLISECOND, 0)
                hasStart = true
            }
        }

        if (samvatsariEvent != null) {
            val d = sdf.parse(samvatsariEvent.dateString)
            if (d != null) {
                samvatsariCal.time = d
                samvatsariCal.set(Calendar.HOUR_OF_DAY, 6)
                samvatsariCal.set(Calendar.MINUTE, 0)
                samvatsariCal.set(Calendar.SECOND, 0)
                samvatsariCal.set(Calendar.MILLISECOND, 0)
                hasSamvatsari = true
            }
        }

        if (hasStart && !hasSamvatsari) {
            samvatsariCal.timeInMillis = startCal.timeInMillis + (7L * 24 * 3600 * 1000L)
        } else if (!hasStart && hasSamvatsari) {
            startCal.timeInMillis = samvatsariCal.timeInMillis - (7L * 24 * 3600 * 1000L)
        }

        if (janmEvent != null) {
            val d = sdf.parse(janmEvent.dateString)
            if (d != null) {
                janmCal.time = d
                janmCal.set(Calendar.HOUR_OF_DAY, 9)
                janmCal.set(Calendar.MINUTE, 0)
                janmCal.set(Calendar.SECOND, 0)
                janmCal.set(Calendar.MILLISECOND, 0)
            }
        } else {
            janmCal.timeInMillis = startCal.timeInMillis + (4L * 24 * 3600 * 1000L)
            janmCal.set(Calendar.HOUR_OF_DAY, 9)
            janmCal.set(Calendar.MINUTE, 0)
            janmCal.set(Calendar.SECOND, 0)
            janmCal.set(Calendar.MILLISECOND, 0)
        }

        val endCal = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).apply {
            timeInMillis = samvatsariCal.timeInMillis
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }

        return ParyushanYearSchedule(
            year = year,
            gacch = gacch,
            startDateMillis = startCal.timeInMillis,
            janmVanchanDateMillis = janmCal.timeInMillis,
            samvatsariDateMillis = samvatsariCal.timeInMillis,
            endDateMillis = endCal.timeInMillis
        )
    }

    fun getCountdownState(
        gacch: JainGacch,
        nowMillis: Long = System.currentTimeMillis(),
        panchangEvents: List<PanchangEventEntity> = emptyList()
    ): ParyushanCountdownState {
        val calNow = Calendar.getInstance(TimeZone.getTimeZone("Asia/Kolkata")).apply {
            timeInMillis = nowMillis
        }
        val currentYear = calNow.get(Calendar.YEAR)

        // Attempt to extract dynamic schedule from panchangEvents for currentYear
        val panchangScheduleCurrentYear = getPanchangParyushanSchedule(panchangEvents, currentYear, gacch)
        val staticScheduleCurrentYear = allSchedules.find { it.year == currentYear && it.gacch == gacch }

        // Find relevant schedule for the current year
        val currentYearSchedule = panchangScheduleCurrentYear
            ?: staticScheduleCurrentYear
            ?: allSchedules.firstOrNull { it.gacch == gacch }
            ?: allSchedules.first()

        val startMillis = currentYearSchedule.startDateMillis
        val dayMs = 24 * 3600 * 1000L
        val day9SunriseMillis = startMillis + (8L * dayMs) // Sunrise of Day 9 (06:00 AM after Day 8 Samvatsari)

        val tapagacchThisYear = allSchedules.find { it.year == currentYearSchedule.year && it.gacch == JainGacch.TAPAGACCH }
        val kharatargacchThisYear = allSchedules.find { it.year == currentYearSchedule.year && it.gacch == JainGacch.KHARATARGACCH }
        val isTwoGacchDiff = tapagacchThisYear != null && kharatargacchThisYear != null &&
                (tapagacchThisYear.startDateMillis != kharatargacchThisYear.startDateMillis ||
                 tapagacchThisYear.samvatsariDateMillis != kharatargacchThisYear.samvatsariDateMillis)

        var phase: ParyushanPhase
        var targetMillis: Long = startMillis
        var currentDay = 0
        var activeDayMainText = ""
        var activeDaySubText = ""

        if (nowMillis < startMillis) {
            // 1. Before Day 1 sunrise: Countdown to Day 1
            phase = ParyushanPhase.COUNTDOWN_TO_PARYUSHAN
            targetMillis = startMillis
            currentDay = 0
        } else if (nowMillis < day9SunriseMillis) {
            // 2. Day 1 sunrise to Day 9 sunrise: 8 Days of Paryushan
            phase = ParyushanPhase.PARYUSHAN_ACTIVE
            val diffMs = (nowMillis - startMillis).coerceAtLeast(0L)
            val dayCalc = (diffMs / dayMs).toInt() + 1
            currentDay = dayCalc.coerceIn(1, 8)

            val duty = PARYUSHAN_DAY_DUTIES.find { it.dayNumber == currentDay }
                ?: ParyushanDayDuty(currentDay, "Day $currentDay", "")
            activeDayMainText = duty.mainText
            activeDaySubText = duty.subText
            targetMillis = startMillis + (currentDay * dayMs)
        } else {
            // 3. After Day 9th sunrise:
            // "After day 9th sunrise the card will show - पर्यूषण पर्व समाप्त 🙏🏻 - until the next years panchang got updated in the app. When the next year panchang got updated then again countdown should start again"
            val nextYear = currentYearSchedule.year + 1
            val nextYearPanchangSchedule = getPanchangParyushanSchedule(panchangEvents, nextYear, gacch)

            if (nextYearPanchangSchedule != null) {
                // Next year's panchang HAS been updated in the app -> countdown starts again!
                phase = ParyushanPhase.POST_PARYUSHAN_NEXT_YEAR
                targetMillis = nextYearPanchangSchedule.startDateMillis
                currentDay = 0
            } else {
                // Next year's panchang is NOT yet updated in the app -> show "पर्यूषण पर्व समाप्त 🙏🏻"
                phase = ParyushanPhase.PARYUSHAN_COMPLETED
                targetMillis = day9SunriseMillis
                currentDay = 0
                activeDayMainText = "पर्यूषण पर्व समाप्त 🙏🏻"
                activeDaySubText = "मिच्छामि दुक्कडम्"
            }
        }

        val diff = (targetMillis - nowMillis).coerceAtLeast(0L)
        val days = diff / (1000 * 60 * 60 * 24)
        val hours = (diff / (1000 * 60 * 60)) % 24
        val minutes = (diff / (1000 * 60)) % 60
        val seconds = (diff / 1000) % 60

        val displaySchedule = if (phase == ParyushanPhase.POST_PARYUSHAN_NEXT_YEAR) {
            getPanchangParyushanSchedule(panchangEvents, currentYearSchedule.year + 1, gacch) ?: currentYearSchedule
        } else {
            currentYearSchedule
        }

        val itinerary = build8DayItinerary(displaySchedule)

        return ParyushanCountdownState(
            year = displaySchedule.year,
            gacch = displaySchedule.gacch,
            phase = phase,
            currentDayNumber = currentDay,
            targetTimeMillis = targetMillis,
            daysRemaining = days,
            hoursRemaining = hours,
            minutesRemaining = minutes,
            secondsRemaining = seconds,
            startDateFormatted = formatDate(displaySchedule.startDateMillis),
            janmVanchanDateFormatted = formatDate(displaySchedule.janmVanchanDateMillis),
            samvatsariDateFormatted = formatDate(displaySchedule.samvatsariDateMillis),
            isTwoGacchDifferentThisYear = isTwoGacchDiff,
            itinerary = itinerary,
            activeDayMainText = activeDayMainText,
            activeDaySubText = activeDaySubText
        )
    }

    private fun build8DayItinerary(schedule: ParyushanYearSchedule): List<DayItinerary> {
        val startMs = schedule.startDateMillis
        val dayMs = 24 * 3600 * 1000L

        val dayDuties = listOf(
            ("Day 1: पर्यूषण 5 कर्तव्य") to "अमारी प्रवर्तन, साधर्मिक भक्ति, क्षमापना, अठ्ठम तप एवं चैत्य परिपाटी।",
            ("Day 2: वार्षिक 11 कर्तव्य") to "संघ पूजा, साधर्मिक वात्सल्य, यात्रा त्रिक, स्नात्र महोत्सव आदि वार्षिक ११ कर्तव्य।",
            ("Day 3: पौषध आत्मा का औषध") to "पौषध व्रत का पालन, आत्मा की शुद्धि, कषायों का शमन एवं धर्म आराधना।",
            ("Day 4: कल्पसूत्र वांचन") to "श्री कल्पसूत्र जी का मंगल आगमन, वांचन प्रारंभ एवं अष्टाह्निका महोत्सव।",
            ("Day 5: जन्म वांचन") to "श्री महावीर स्वामी जन्म वांचन महोत्सव, १४ महास्वप्नों का दर्शन एवं हर्षोल्लास।",
            ("Day 6: पार्श्व, नेम एवं ऋषभ चरित्र") to "प्रभु पार्श्वनाथ, नेमिनाथ एवं ऋषभदेव भगवान के पावन चरित्र का श्रवण।",
            ("Day 7: स्थविरावली एवं समाचारी") to "स्थविरावली श्रवण, साधु आचार विचार एवं संवत्सरी पूर्व तैयारी।",
            ("Day 8: संवत्सरी एवं क्षमापना") to "महापर्व संवत्सरी, वार्षिक प्रतिक्रमण एवं सर्व जीवों से क्षमापना (मिच्छामि दुक्कडम्)।"
        )

        return dayDuties.mapIndexed { index, pair ->
            val curDayMs = startMs + (index * dayMs)
            DayItinerary(
                dayNumber = index + 1,
                dateString = formatDateShort(curDayMs),
                titleHindi = pair.first,
                descriptionHindi = pair.second,
                isHighlighted = (index + 1 == 5 || index + 1 == 8) // Janm Vanchan and Samvatsari
            )
        }
    }
}
