package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class UserSession(
    val isLoggedIn: Boolean = false,
    val phone: String = "",
    val fullName: String = "",
    val firstName: String = "",
    val isAdmin: Boolean = false,
    val profileData: SwadhyaiFormEntity? = null,
    val hasUnansweredQuestions: Boolean = false
)

object UserSessionManager {
    private const val PREFS_NAME = "swadhyai_user_session"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_PHONE = "user_phone"
    private const val KEY_FULL_NAME = "user_full_name"
    private const val KEY_IS_ADMIN = "user_is_admin"

    private const val KEY_PROFILE_JSON = "user_profile_json"

    const val MASTER_ADMIN_PHONE = "9009253000"

    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null
    private var firestoreListener: ListenerRegistration? = null

    private val _sessionState = MutableStateFlow(UserSession())
    val sessionState: StateFlow<UserSession> = _sessionState.asStateFlow()

    private val _hasNewQuestionRedDot = MutableStateFlow(false)
    val hasNewQuestionRedDot: StateFlow<Boolean> = _hasNewQuestionRedDot.asStateFlow()

    private fun obtainPrefs(): SharedPreferences? {
        if (prefs != null) return prefs
        appContext?.let {
            prefs = it.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        }
        return prefs
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        val sp = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs = sp
        val isLoggedIn = sp.getBoolean(KEY_IS_LOGGED_IN, false)
        val phone = sp.getString(KEY_PHONE, "") ?: ""
        val fullName = sp.getString(KEY_FULL_NAME, "") ?: ""
        val isMasterAdmin = isMasterAdminPhone(phone)
        val isAdmin = isMasterAdmin || sp.getBoolean(KEY_IS_ADMIN, false)
        val profileJson = sp.getString(KEY_PROFILE_JSON, "") ?: ""
        val cachedProfile = if (profileJson.isNotBlank()) jsonToSwadhyai(profileJson) else null

        val firstName = extractFirstName(fullName)

        _sessionState.value = UserSession(
            isLoggedIn = isLoggedIn && phone.isNotBlank(),
            phone = phone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = isAdmin,
            profileData = cachedProfile
        )

        if (isLoggedIn && phone.isNotBlank()) {
            startRealtimeUserListener(phone)
        }
        startAdminRolesListener()
    }

    private var adminConfigListener: ListenerRegistration? = null

    fun startAdminRolesListener() {
        adminConfigListener?.remove()
        try {
            val firestore = FirebaseFirestore.getInstance()
            adminConfigListener = firestore.collection("app_config").document("admin_roles")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("UserSessionManager", "Error listening to admin roles: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        val rawList = snapshot.get("adminPhones") as? List<*> ?: emptyList<Any>()
                        val phones = rawList.mapNotNull { it?.toString() }
                            .map { it.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10) }
                            .filter { it.isNotBlank() }
                            .toSet()
                        updateAdminPhoneNumbers(phones)

                        val currentPhone = _sessionState.value.phone
                        if (currentPhone.isNotBlank()) {
                            val isMaster = isMasterAdminPhone(currentPhone)
                            val isAdminNow = isMaster || phones.contains(currentPhone)
                            if (_sessionState.value.isAdmin != isAdminNow) {
                                obtainPrefs()?.edit()?.putBoolean(KEY_IS_ADMIN, isAdminNow)?.apply()
                                _sessionState.value = _sessionState.value.copy(isAdmin = isAdminNow)
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("UserSessionManager", "Failed to start admin config listener: ${e.message}")
        }
    }

    fun isMasterAdminPhone(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        return clean == MASTER_ADMIN_PHONE
    }

    fun isLoggedIn(): Boolean {
        return _sessionState.value.isLoggedIn
    }

    private val _adminPhoneNumbers = MutableStateFlow<Set<String>>(setOf(MASTER_ADMIN_PHONE))
    val adminPhoneNumbers: StateFlow<Set<String>> = _adminPhoneNumbers.asStateFlow()

    fun updateAdminPhoneNumbers(phones: Set<String>) {
        val cleanPhones = phones.map { it.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10) }
            .filter { it.isNotBlank() }
            .toSet()
        val updated = cleanPhones + MASTER_ADMIN_PHONE
        _adminPhoneNumbers.value = updated
        val currentPhone = _sessionState.value.phone
        if (currentPhone.isNotBlank()) {
            val isAdminNow = isPhoneAdmin(currentPhone)
            if (_sessionState.value.isAdmin != isAdminNow) {
                obtainPrefs()?.edit()?.putBoolean(KEY_IS_ADMIN, isAdminNow)?.apply()
                _sessionState.value = _sessionState.value.copy(isAdmin = isAdminNow)
            }
        }
    }

    fun isPhoneAdmin(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (clean.isBlank()) return false
        if (clean == MASTER_ADMIN_PHONE) return true
        return _adminPhoneNumbers.value.contains(clean)
    }

    fun extractFirstName(fullName: String): String {
        val clean = fullName.trim()
        if (clean.isBlank()) return "Swadhyai"
        val parts = clean.split("\\s+".toRegex())
        val first = parts.firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "Swadhyai"
        return if (first.length > 15) first.take(15) else first
    }

    fun login(
        phone: String,
        fullName: String,
        profile: SwadhyaiFormEntity? = null,
        isAdminOverride: Boolean? = null
    ) {
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        val isMaster = isMasterAdminPhone(cleanPhone)
        val admin = isMaster || (isAdminOverride ?: false)
        val firstName = extractFirstName(fullName)

        val editor = obtainPrefs()?.edit()
        editor?.putBoolean(KEY_IS_LOGGED_IN, true)
            ?.putString(KEY_PHONE, cleanPhone)
            ?.putString(KEY_FULL_NAME, fullName)
            ?.putBoolean(KEY_IS_ADMIN, admin)
        
        if (profile != null) {
            editor?.putString(KEY_PROFILE_JSON, swadhyaiToJson(profile))
        }
        editor?.apply()

        _sessionState.value = UserSession(
            isLoggedIn = true,
            phone = cleanPhone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = admin,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
        startRealtimeUserListener(cleanPhone)
    }

    fun updateProfileData(profile: SwadhyaiFormEntity) {
        val current = _sessionState.value
        val firstName = extractFirstName(profile.fullName)
        val isMaster = isMasterAdminPhone(current.phone)

        obtainPrefs()?.edit()
            ?.putString(KEY_FULL_NAME, profile.fullName)
            ?.putString(KEY_PROFILE_JSON, swadhyaiToJson(profile))
            ?.apply()

        _sessionState.value = current.copy(
            fullName = profile.fullName,
            firstName = firstName,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
    }

    fun checkUnansweredQuestions(profile: SwadhyaiFormEntity?) {
        if (profile == null) {
            _hasNewQuestionRedDot.value = false
            return
        }
        // Checks if religious learnings, daily routine activities or lifetime tapasya are missing
        val hasMissing = profile.fullName.isBlank() ||
                profile.fatherName.isBlank() ||
                profile.emergencyContactNo.isBlank() ||
                profile.address.isBlank() ||
                profile.city.isBlank() ||
                profile.state.isBlank()
        _hasNewQuestionRedDot.value = hasMissing
    }

    private fun getLongField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String): Long? {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Number -> return v.toLong()
                    is com.google.firebase.Timestamp -> return v.toDate().time
                    is String -> {
                        val parsed = v.trim().toLongOrNull()
                        if (parsed != null) return parsed
                    }
                    is Boolean -> return if (v) 1L else 0L
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun getBooleanField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String, default: Boolean = false): Boolean {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Boolean -> return v
                    is Number -> return v.toLong() != 0L
                    is String -> {
                        val lower = v.trim().lowercase()
                        if (lower == "true" || lower == "1" || lower == "yes") return true
                        if (lower == "false" || lower == "0" || lower == "no") return false
                    }
                }
            } catch (_: Exception) {}
        }
        return default
    }

    private fun getStringField(doc: com.google.firebase.firestore.DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            try {
                val value = doc.get(key)
                if (value != null) {
                    if (value is List<*>) {
                        val joined = value.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
                        if (joined.isNotBlank()) return joined
                    }
                    val str = value.toString().trim()
                    if (str.isNotBlank() && str != "[]" && str != "null" && str != "{}") return str
                }
            } catch (_: Exception) {}
        }
        return ""
    }

    fun startRealtimeUserListener(phone: String) {
        firestoreListener?.remove()
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanPhone.isBlank()) return

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestoreListener = firestore.collection("swadhyai_forms")
                .document("phone_$cleanPhone")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("UserSessionManager", "Error listening to user document: ${error.message}")
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        val isMaster = isMasterAdminPhone(cleanPhone)
                        val firestoreIsAdmin = getBooleanField(snapshot, "isAdmin")
                        val currentAdminStatus = isMaster || firestoreIsAdmin
                        val serverFullName = getStringField(snapshot, "fullName").ifBlank { _sessionState.value.fullName }
                        val firstName = extractFirstName(serverFullName)

                        val parsedProfile = parseSwadhyaiFromSnapshot(snapshot)

                        val editor = obtainPrefs()?.edit()
                        editor?.putBoolean(KEY_IS_ADMIN, currentAdminStatus)
                            ?.putString(KEY_FULL_NAME, serverFullName)
                        
                        if (parsedProfile != null) {
                            editor?.putString(KEY_PROFILE_JSON, swadhyaiToJson(parsedProfile))
                        }
                        editor?.apply()

                        _sessionState.value = _sessionState.value.copy(
                            isAdmin = currentAdminStatus,
                            fullName = serverFullName,
                            firstName = firstName,
                            profileData = parsedProfile ?: _sessionState.value.profileData
                        )

                        if (parsedProfile != null) {
                            checkUnansweredQuestions(parsedProfile)
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("UserSessionManager", "Failed to start user listener: ${e.message}")
        }
    }

    fun parseSwadhyaiFromSnapshot(doc: com.google.firebase.firestore.DocumentSnapshot): SwadhyaiFormEntity? {
        if (!doc.exists()) return null
        val fullName = getStringField(doc, "fullName", "name").trim()
        val cleanPhone = getStringField(doc, "whatsappNo", "phone").takeLast(10)
        if (fullName.isBlank() && cleanPhone.isBlank()) return null

        val learningsVal = doc.get("religiousLearnings") ?: doc.get("religiousLearningsFormatted")
        val religiousLearningsStr = when (learningsVal) {
            is List<*> -> learningsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString("\n")
            else -> learningsVal?.toString()?.trim() ?: ""
        }

        val tapasyaVal = doc.get("lifetimeTapasya")
        val lifetimeTapasyaStr = when (tapasyaVal) {
            is List<*> -> tapasyaVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString("\n")
            else -> tapasyaVal?.toString()?.trim() ?: ""
        }

        val specsVal = doc.get("specialities")
        val specialitiesStr = when (specsVal) {
            is List<*> -> specsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
            else -> specsVal?.toString()?.trim() ?: ""
        }

        val actsVal = doc.get("dailyRoutineActivities")
        val dailyRoutineStr = when (actsVal) {
            is List<*> -> actsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
            else -> actsVal?.toString()?.trim() ?: ""
        }

        val jYear = getLongField(doc, "joiningYear")?.toInt() ?: 0
        val pCount = getLongField(doc, "paryushanCount")?.toInt() ?: 0
        val ageVal = getLongField(doc, "age")?.toInt() ?: 0

        return SwadhyaiFormEntity(
            id = getLongField(doc, "id") ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L),
            firestoreDocId = doc.id,
            fullName = fullName,
            fatherName = getStringField(doc, "fatherName"),
            motherName = getStringField(doc, "motherName"),
            gender = getStringField(doc, "gender").ifBlank { "Male" },
            dob = getStringField(doc, "dob"),
            age = ageVal,
            bloodGroup = getStringField(doc, "bloodGroup"),
            maritalStatus = getStringField(doc, "maritalStatus"),
            anniversaryDate = getStringField(doc, "anniversaryDate"),
            email = getStringField(doc, "email", "emailId"),
            whatsappNo = cleanPhone,
            contactNo = getStringField(doc, "contactNo"),
            emergencyContactName = getStringField(doc, "emergencyContactName"),
            emergencyContactRelation = getStringField(doc, "emergencyContactRelation"),
            emergencyContactNo = getStringField(doc, "emergencyContactNo"),
            address = getStringField(doc, "address"),
            city = getStringField(doc, "city"),
            pincode = getStringField(doc, "pincode"),
            state = getStringField(doc, "state"),
            nativePlace = getStringField(doc, "nativePlace"),
            education = getStringField(doc, "education"),
            workingStatus = getStringField(doc, "workingStatus"),
            workDescription = getStringField(doc, "workDescription"),
            joiningYear = jYear,
            specialities = specialitiesStr,
            religiousLearnings = religiousLearningsStr,
            anotherGroup = getStringField(doc, "anotherGroup"),
            postInGroup = getStringField(doc, "postInGroup"),
            paryushanCount = pCount,
            paryushanHistoryLog = getStringField(doc, "paryushanHistoryLog"),
            dailyRoutineActivities = dailyRoutineStr,
            lifetimeTapasya = lifetimeTapasyaStr,
            paryushanWillingness = getStringField(doc, "paryushanWillingness"),
            acceptedRules = getBooleanField(doc, "acceptedRules", default = true),
            remarks = getStringField(doc, "remarks"),
            profileImageUri = getStringField(doc, "profileImageUri"),
            updatedAt = getLongField(doc, "updatedAt") ?: System.currentTimeMillis()
        )
    }

    private fun swadhyaiToJson(entity: SwadhyaiFormEntity): String {
        return try {
            org.json.JSONObject().apply {
                put("id", entity.id)
                put("firestoreDocId", entity.firestoreDocId)
                put("fullName", entity.fullName)
                put("fatherName", entity.fatherName)
                put("motherName", entity.motherName)
                put("gender", entity.gender)
                put("dob", entity.dob)
                put("age", entity.age)
                put("bloodGroup", entity.bloodGroup)
                put("maritalStatus", entity.maritalStatus)
                put("anniversaryDate", entity.anniversaryDate)
                put("email", entity.email)
                put("whatsappNo", entity.whatsappNo)
                put("contactNo", entity.contactNo)
                put("emergencyContactName", entity.emergencyContactName)
                put("emergencyContactRelation", entity.emergencyContactRelation)
                put("emergencyContactNo", entity.emergencyContactNo)
                put("address", entity.address)
                put("city", entity.city)
                put("pincode", entity.pincode)
                put("state", entity.state)
                put("nativePlace", entity.nativePlace)
                put("education", entity.education)
                put("workingStatus", entity.workingStatus)
                put("workDescription", entity.workDescription)
                put("joiningYear", entity.joiningYear)
                put("specialities", entity.specialities)
                put("religiousLearnings", entity.religiousLearnings)
                put("anotherGroup", entity.anotherGroup)
                put("postInGroup", entity.postInGroup)
                put("paryushanCount", entity.paryushanCount)
                put("paryushanHistoryLog", entity.paryushanHistoryLog)
                put("dailyRoutineActivities", entity.dailyRoutineActivities)
                put("lifetimeTapasya", entity.lifetimeTapasya)
                put("paryushanWillingness", entity.paryushanWillingness)
                put("acceptedRules", entity.acceptedRules)
                put("remarks", entity.remarks)
                put("profileImageUri", entity.profileImageUri)
                put("updatedAt", entity.updatedAt)
                put("updatedFields", entity.updatedFields)
                put("isDeleted", entity.isDeleted)
            }.toString()
        } catch (e: Exception) {
            ""
        }
    }

    private fun jsonToSwadhyai(jsonStr: String): SwadhyaiFormEntity? {
        return try {
            val obj = org.json.JSONObject(jsonStr)
            SwadhyaiFormEntity(
                id = obj.optLong("id", 0L),
                firestoreDocId = obj.optString("firestoreDocId", ""),
                fullName = obj.optString("fullName", ""),
                fatherName = obj.optString("fatherName", ""),
                motherName = obj.optString("motherName", ""),
                gender = obj.optString("gender", "Male"),
                dob = obj.optString("dob", ""),
                age = obj.optInt("age", 0),
                bloodGroup = obj.optString("bloodGroup", ""),
                maritalStatus = obj.optString("maritalStatus", ""),
                anniversaryDate = obj.optString("anniversaryDate", ""),
                email = obj.optString("email", ""),
                whatsappNo = obj.optString("whatsappNo", ""),
                contactNo = obj.optString("contactNo", ""),
                emergencyContactName = obj.optString("emergencyContactName", ""),
                emergencyContactRelation = obj.optString("emergencyContactRelation", ""),
                emergencyContactNo = obj.optString("emergencyContactNo", ""),
                address = obj.optString("address", ""),
                city = obj.optString("city", ""),
                pincode = obj.optString("pincode", ""),
                state = obj.optString("state", ""),
                nativePlace = obj.optString("nativePlace", ""),
                education = obj.optString("education", ""),
                workingStatus = obj.optString("workingStatus", ""),
                workDescription = obj.optString("workDescription", ""),
                joiningYear = obj.optInt("joiningYear", 0),
                specialities = obj.optString("specialities", ""),
                religiousLearnings = obj.optString("religiousLearnings", ""),
                anotherGroup = obj.optString("anotherGroup", ""),
                postInGroup = obj.optString("postInGroup", ""),
                paryushanCount = obj.optInt("paryushanCount", 0),
                paryushanHistoryLog = obj.optString("paryushanHistoryLog", ""),
                dailyRoutineActivities = obj.optString("dailyRoutineActivities", ""),
                lifetimeTapasya = obj.optString("lifetimeTapasya", ""),
                paryushanWillingness = obj.optString("paryushanWillingness", ""),
                acceptedRules = obj.optBoolean("acceptedRules", true),
                remarks = obj.optString("remarks", ""),
                profileImageUri = obj.optString("profileImageUri", ""),
                updatedAt = obj.optLong("updatedAt", 0L),
                updatedFields = obj.optString("updatedFields", ""),
                isDeleted = obj.optBoolean("isDeleted", false)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun setAdminStatus(
        targetPhone: String,
        newAdminStatus: Boolean,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val cleanTarget = targetPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanTarget.isBlank() || cleanTarget.length < 10) {
            CoroutineScope(Dispatchers.Main).launch {
                onComplete(false, "Invalid phone number")
            }
            return
        }
        if (cleanTarget == MASTER_ADMIN_PHONE && !newAdminStatus) {
            CoroutineScope(Dispatchers.Main).launch {
                onComplete(false, "Cannot remove Master Admin ($MASTER_ADMIN_PHONE)")
            }
            return
        }

        val currentSet = _adminPhoneNumbers.value
        val newSet = if (newAdminStatus) {
            currentSet + cleanTarget
        } else {
            currentSet - cleanTarget
        }
        updateAdminPhoneNumbers(newSet)

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()

                // 1. Update app_config/admin_roles
                val adminDocRef = db.collection("app_config").document("admin_roles")
                val updateData = if (newAdminStatus) {
                    mapOf("adminPhones" to com.google.firebase.firestore.FieldValue.arrayUnion(cleanTarget))
                } else {
                    mapOf("adminPhones" to com.google.firebase.firestore.FieldValue.arrayRemove(cleanTarget))
                }

                adminDocRef.set(updateData, SetOptions.merge())
                    .addOnSuccessListener {
                        Log.d("UserSessionManager", "Updated admin_roles for $cleanTarget -> $newAdminStatus")
                    }
                    .addOnFailureListener { e ->
                        Log.e("UserSessionManager", "Failed to update admin_roles: ${e.message}")
                    }

                // 2. Query swadhyai_forms for EXISTING documents matching cleanTarget phone to update isAdmin
                try {
                    db.collection("swadhyai_forms")
                        .whereEqualTo("whatsappNo", cleanTarget)
                        .get()
                        .addOnSuccessListener { querySnapshot ->
                            querySnapshot.documents.forEach { doc ->
                                val name = doc.getString("fullName") ?: ""
                                if (name.isNotBlank()) {
                                    doc.reference.update("isAdmin", newAdminStatus)
                                }
                            }
                        }
                } catch (e: Exception) {
                    Log.w("UserSessionManager", "Error querying whatsappNo for admin update: ${e.message}")
                }

                try {
                    db.collection("swadhyai_forms")
                        .whereEqualTo("contactNo", cleanTarget)
                        .get()
                        .addOnSuccessListener { querySnapshot ->
                            querySnapshot.documents.forEach { doc ->
                                val name = doc.getString("fullName") ?: ""
                                if (name.isNotBlank()) {
                                    doc.reference.update("isAdmin", newAdminStatus)
                                }
                            }
                        }
                } catch (e: Exception) {
                    Log.w("UserSessionManager", "Error querying contactNo for admin update: ${e.message}")
                }

                // 3. Clean up any rogue ghost docs that may have been created before
                try {
                    db.collection("swadhyai_forms").document("phone_$cleanTarget").get()
                        .addOnSuccessListener { doc ->
                            if (doc.exists()) {
                                val name = doc.getString("fullName") ?: ""
                                if (name.isBlank()) {
                                    doc.reference.delete()
                                }
                            }
                        }
                    db.collection("swadhyai_forms").document(cleanTarget).get()
                        .addOnSuccessListener { doc ->
                            if (doc.exists()) {
                                val name = doc.getString("fullName") ?: ""
                                if (name.isBlank()) {
                                    doc.reference.delete()
                                }
                            }
                        }
                } catch (e: Exception) {
                    Log.w("UserSessionManager", "Error cleaning ghost docs: ${e.message}")
                }

                withContext(Dispatchers.Main) {
                    onComplete(true, null)
                }
            } catch (e: Exception) {
                Log.e("UserSessionManager", "Failed to update admin status: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    onComplete(false, e.message)
                }
            }
        }
    }

    fun getCurrentPhone(): String {
        return _sessionState.value.phone
    }

    fun logout() {
        firestoreListener?.remove()
        firestoreListener = null
        adminConfigListener?.remove()
        adminConfigListener = null

        obtainPrefs()?.edit()
            ?.clear()
            ?.apply()

        _sessionState.value = UserSession(
            isLoggedIn = false,
            phone = "",
            fullName = "",
            firstName = "",
            isAdmin = false,
            profileData = null,
            hasUnansweredQuestions = false
        )
        _hasNewQuestionRedDot.value = false
    }
}
