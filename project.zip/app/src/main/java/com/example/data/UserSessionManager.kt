package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UserSession(
    val isLoggedIn: Boolean = false,
    val phone: String = "",
    val fullName: String = "",
    val firstName: String = "",
    val isAdmin: Boolean = false,
    val profileData: SwadhyaiFormEntity? = null,
    val hasUnansweredQuestions: Boolean = false
)

object UserSessionManager {
    private const val PREFS_NAME = "swadhyai_user_session"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_PHONE = "user_phone"
    private const val KEY_FULL_NAME = "user_full_name"
    private const val KEY_IS_ADMIN = "user_is_admin"

    private const val KEY_PROFILE_JSON = "user_profile_json"

    const val MASTER_ADMIN_PHONE = "9009253000"

    private lateinit var prefs: SharedPreferences
    private var firestoreListener: ListenerRegistration? = null

    private val _sessionState = MutableStateFlow(UserSession())
    val sessionState: StateFlow<UserSession> = _sessionState.asStateFlow()

    private val _hasNewQuestionRedDot = MutableStateFlow(false)
    val hasNewQuestionRedDot: StateFlow<Boolean> = _hasNewQuestionRedDot.asStateFlow()

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        val phone = prefs.getString(KEY_PHONE, "") ?: ""
        val fullName = prefs.getString(KEY_FULL_NAME, "") ?: ""
        val isMasterAdmin = isMasterAdminPhone(phone)
        val isAdmin = isMasterAdmin || prefs.getBoolean(KEY_IS_ADMIN, false)
        val profileJson = prefs.getString(KEY_PROFILE_JSON, "") ?: ""
        val cachedProfile = if (profileJson.isNotBlank()) jsonToSwadhyai(profileJson) else null

        val firstName = extractFirstName(fullName)

        _sessionState.value = UserSession(
            isLoggedIn = isLoggedIn && phone.isNotBlank(),
            phone = phone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = isAdmin,
            profileData = cachedProfile
        )

        if (isLoggedIn && phone.isNotBlank()) {
            startRealtimeUserListener(phone)
        }
        startAdminRolesListener()
    }

    private var adminConfigListener: ListenerRegistration? = null

    fun startAdminRolesListener() {
        adminConfigListener?.remove()
        try {
            val firestore = FirebaseFirestore.getInstance()
            adminConfigListener = firestore.collection("app_config").document("admin_roles")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("UserSessionManager", "Error listening to admin roles: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null && snapshot.exists()) {
                        @Suppress("UNCHECKED_CAST")
                        val list = snapshot.get("adminPhones") as? List<String> ?: emptyList()
                        val phones = list.map { it.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10) }
                            .filter { it.isNotBlank() }
                            .toSet()
                        updateAdminPhoneNumbers(phones)

                        val currentPhone = _sessionState.value.phone
                        if (currentPhone.isNotBlank()) {
                            val isMaster = isMasterAdminPhone(currentPhone)
                            val isAdminNow = isMaster || phones.contains(currentPhone)
                            if (_sessionState.value.isAdmin != isAdminNow) {
                                prefs.edit().putBoolean(KEY_IS_ADMIN, isAdminNow).apply()
                                _sessionState.value = _sessionState.value.copy(isAdmin = isAdminNow)
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("UserSessionManager", "Failed to start admin config listener: ${e.message}")
        }
    }

    fun isMasterAdminPhone(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        return clean == MASTER_ADMIN_PHONE
    }

    private val _adminPhoneNumbers = MutableStateFlow<Set<String>>(setOf(MASTER_ADMIN_PHONE))
    val adminPhoneNumbers: StateFlow<Set<String>> = _adminPhoneNumbers.asStateFlow()

    fun updateAdminPhoneNumbers(phones: Set<String>) {
        val updated = phones + MASTER_ADMIN_PHONE
        _adminPhoneNumbers.value = updated
        val currentPhone = _sessionState.value.phone
        if (currentPhone.isNotBlank()) {
            val isAdminNow = isPhoneAdmin(currentPhone)
            if (_sessionState.value.isAdmin != isAdminNow) {
                prefs.edit().putBoolean(KEY_IS_ADMIN, isAdminNow).apply()
                _sessionState.value = _sessionState.value.copy(isAdmin = isAdminNow)
            }
        }
    }

    fun isPhoneAdmin(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (clean == MASTER_ADMIN_PHONE) return true
        return _adminPhoneNumbers.value.contains(clean)
    }

    fun extractFirstName(fullName: String): String {
        val clean = fullName.trim()
        if (clean.isBlank()) return "Swadhyai"
        val parts = clean.split("\\s+".toRegex())
        val first = parts.firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "Swadhyai"
        return if (first.length > 15) first.take(15) else first
    }

    fun login(
        phone: String,
        fullName: String,
        profile: SwadhyaiFormEntity? = null,
        isAdminOverride: Boolean? = null
    ) {
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        val isMaster = isMasterAdminPhone(cleanPhone)
        val admin = isMaster || (isAdminOverride ?: false)
        val firstName = extractFirstName(fullName)

        val editor = prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_PHONE, cleanPhone)
            .putString(KEY_FULL_NAME, fullName)
            .putBoolean(KEY_IS_ADMIN, admin)
        
        if (profile != null) {
            editor.putString(KEY_PROFILE_JSON, swadhyaiToJson(profile))
        }
        editor.apply()

        _sessionState.value = UserSession(
            isLoggedIn = true,
            phone = cleanPhone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = admin,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
        startRealtimeUserListener(cleanPhone)
    }

    fun updateProfileData(profile: SwadhyaiFormEntity) {
        val current = _sessionState.value
        val firstName = extractFirstName(profile.fullName)
        val isMaster = isMasterAdminPhone(current.phone)

        prefs.edit()
            .putString(KEY_FULL_NAME, profile.fullName)
            .putString(KEY_PROFILE_JSON, swadhyaiToJson(profile))
            .apply()

        _sessionState.value = current.copy(
            fullName = profile.fullName,
            firstName = firstName,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
    }

    fun checkUnansweredQuestions(profile: SwadhyaiFormEntity?) {
        if (profile == null) {
            _hasNewQuestionRedDot.value = false
            return
        }
        // Checks if religious learnings, daily routine activities or lifetime tapasya are missing
        val hasMissing = profile.fullName.isBlank() ||
                profile.fatherName.isBlank() ||
                profile.emergencyContactNo.isBlank() ||
                profile.address.isBlank() ||
                profile.city.isBlank() ||
                profile.state.isBlank()
        _hasNewQuestionRedDot.value = hasMissing
    }

    fun startRealtimeUserListener(phone: String) {
        firestoreListener?.remove()
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanPhone.isBlank()) return

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestoreListener = firestore.collection("swadhyai_forms")
                .document("phone_$cleanPhone")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("UserSessionManager", "Error listening to user document: ${error.message}")
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        val isMaster = isMasterAdminPhone(cleanPhone)
                        val firestoreIsAdmin = snapshot.getBoolean("isAdmin") ?: false
                        val currentAdminStatus = isMaster || firestoreIsAdmin
                        val serverFullName = snapshot.getString("fullName") ?: _sessionState.value.fullName
                        val firstName = extractFirstName(serverFullName)

                        val parsedProfile = parseSwadhyaiFromSnapshot(snapshot)

                        val editor = prefs.edit()
                            .putBoolean(KEY_IS_ADMIN, currentAdminStatus)
                            .putString(KEY_FULL_NAME, serverFullName)
                        
                        if (parsedProfile != null) {
                            editor.putString(KEY_PROFILE_JSON, swadhyaiToJson(parsedProfile))
                        }
                        editor.apply()

                        _sessionState.value = _sessionState.value.copy(
                            isAdmin = currentAdminStatus,
                            fullName = serverFullName,
                            firstName = firstName,
                            profileData = parsedProfile ?: _sessionState.value.profileData
                        )

                        if (parsedProfile != null) {
                            checkUnansweredQuestions(parsedProfile)
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("UserSessionManager", "Failed to start user listener: ${e.message}")
        }
    }

    fun parseSwadhyaiFromSnapshot(doc: com.google.firebase.firestore.DocumentSnapshot): SwadhyaiFormEntity? {
        if (!doc.exists()) return null
        val fullName = (doc.getString("fullName") ?: doc.getString("name") ?: "").trim()
        val cleanPhone = (doc.getString("whatsappNo") ?: doc.getString("phone") ?: "").takeLast(10)
        if (fullName.isBlank() && cleanPhone.isBlank()) return null

        val learningsVal = doc.get("religiousLearnings") ?: doc.get("religiousLearningsFormatted")
        val religiousLearningsStr = when (learningsVal) {
            is List<*> -> learningsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString("\n")
            else -> learningsVal?.toString()?.trim() ?: ""
        }

        val tapasyaVal = doc.get("lifetimeTapasya")
        val lifetimeTapasyaStr = when (tapasyaVal) {
            is List<*> -> tapasyaVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString("\n")
            else -> tapasyaVal?.toString()?.trim() ?: ""
        }

        val specsVal = doc.get("specialities")
        val specialitiesStr = when (specsVal) {
            is List<*> -> specsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
            else -> specsVal?.toString()?.trim() ?: ""
        }

        val actsVal = doc.get("dailyRoutineActivities")
        val dailyRoutineStr = when (actsVal) {
            is List<*> -> actsVal.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
            else -> actsVal?.toString()?.trim() ?: ""
        }

        val jYear = try { doc.getLong("joiningYear")?.toInt() ?: doc.getString("joiningYear")?.toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val pCount = try { doc.getLong("paryushanCount")?.toInt() ?: doc.getString("paryushanCount")?.toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val ageVal = try { doc.getLong("age")?.toInt() ?: doc.getString("age")?.toIntOrNull() ?: 0 } catch (e: Exception) { 0 }

        return SwadhyaiFormEntity(
            id = doc.getLong("id") ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L),
            firestoreDocId = doc.id,
            fullName = fullName,
            fatherName = doc.getString("fatherName") ?: "",
            motherName = doc.getString("motherName") ?: "",
            gender = doc.getString("gender") ?: "Male",
            dob = doc.getString("dob") ?: "",
            age = ageVal,
            bloodGroup = doc.getString("bloodGroup") ?: "",
            maritalStatus = doc.getString("maritalStatus") ?: "",
            anniversaryDate = doc.getString("anniversaryDate") ?: "",
            email = doc.getString("email") ?: doc.getString("emailId") ?: "",
            whatsappNo = cleanPhone,
            contactNo = doc.getString("contactNo") ?: "",
            emergencyContactName = doc.getString("emergencyContactName") ?: "",
            emergencyContactRelation = doc.getString("emergencyContactRelation") ?: "",
            emergencyContactNo = doc.getString("emergencyContactNo") ?: "",
            address = doc.getString("address") ?: "",
            city = doc.getString("city") ?: "",
            pincode = doc.getString("pincode") ?: "",
            state = doc.getString("state") ?: "",
            education = doc.getString("education") ?: "",
            workingStatus = doc.getString("workingStatus") ?: "",
            workDescription = doc.getString("workDescription") ?: "",
            joiningYear = jYear,
            specialities = specialitiesStr,
            religiousLearnings = religiousLearningsStr,
            anotherGroup = doc.getString("anotherGroup") ?: "",
            postInGroup = doc.getString("postInGroup") ?: "",
            paryushanCount = pCount,
            paryushanHistoryLog = doc.getString("paryushanHistoryLog") ?: "",
            dailyRoutineActivities = dailyRoutineStr,
            lifetimeTapasya = lifetimeTapasyaStr,
            paryushanWillingness = doc.getString("paryushanWillingness") ?: "",
            acceptedRules = doc.getBoolean("acceptedRules") ?: true,
            remarks = doc.getString("remarks") ?: "",
            profileImageUri = doc.getString("profileImageUri") ?: "",
            updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
        )
    }

    private fun swadhyaiToJson(entity: SwadhyaiFormEntity): String {
        return try {
            org.json.JSONObject().apply {
                put("id", entity.id)
                put("firestoreDocId", entity.firestoreDocId)
                put("fullName", entity.fullName)
                put("fatherName", entity.fatherName)
                put("motherName", entity.motherName)
                put("gender", entity.gender)
                put("dob", entity.dob)
                put("age", entity.age)
                put("bloodGroup", entity.bloodGroup)
                put("maritalStatus", entity.maritalStatus)
                put("anniversaryDate", entity.anniversaryDate)
                put("email", entity.email)
                put("whatsappNo", entity.whatsappNo)
                put("contactNo", entity.contactNo)
                put("emergencyContactName", entity.emergencyContactName)
                put("emergencyContactRelation", entity.emergencyContactRelation)
                put("emergencyContactNo", entity.emergencyContactNo)
                put("address", entity.address)
                put("city", entity.city)
                put("pincode", entity.pincode)
                put("state", entity.state)
                put("nativePlace", entity.nativePlace)
                put("education", entity.education)
                put("workingStatus", entity.workingStatus)
                put("workDescription", entity.workDescription)
                put("joiningYear", entity.joiningYear)
                put("specialities", entity.specialities)
                put("religiousLearnings", entity.religiousLearnings)
                put("anotherGroup", entity.anotherGroup)
                put("postInGroup", entity.postInGroup)
                put("paryushanCount", entity.paryushanCount)
                put("paryushanHistoryLog", entity.paryushanHistoryLog)
                put("dailyRoutineActivities", entity.dailyRoutineActivities)
                put("lifetimeTapasya", entity.lifetimeTapasya)
                put("paryushanWillingness", entity.paryushanWillingness)
                put("acceptedRules", entity.acceptedRules)
                put("remarks", entity.remarks)
                put("profileImageUri", entity.profileImageUri)
                put("updatedAt", entity.updatedAt)
                put("updatedFields", entity.updatedFields)
                put("isDeleted", entity.isDeleted)
            }.toString()
        } catch (e: Exception) {
            ""
        }
    }

    private fun jsonToSwadhyai(jsonStr: String): SwadhyaiFormEntity? {
        return try {
            val obj = org.json.JSONObject(jsonStr)
            SwadhyaiFormEntity(
                id = obj.optLong("id", 0L),
                firestoreDocId = obj.optString("firestoreDocId", ""),
                fullName = obj.optString("fullName", ""),
                fatherName = obj.optString("fatherName", ""),
                motherName = obj.optString("motherName", ""),
                gender = obj.optString("gender", "Male"),
                dob = obj.optString("dob", ""),
                age = obj.optInt("age", 0),
                bloodGroup = obj.optString("bloodGroup", ""),
                maritalStatus = obj.optString("maritalStatus", ""),
                anniversaryDate = obj.optString("anniversaryDate", ""),
                email = obj.optString("email", ""),
                whatsappNo = obj.optString("whatsappNo", ""),
                contactNo = obj.optString("contactNo", ""),
                emergencyContactName = obj.optString("emergencyContactName", ""),
                emergencyContactRelation = obj.optString("emergencyContactRelation", ""),
                emergencyContactNo = obj.optString("emergencyContactNo", ""),
                address = obj.optString("address", ""),
                city = obj.optString("city", ""),
                pincode = obj.optString("pincode", ""),
                state = obj.optString("state", ""),
                nativePlace = obj.optString("nativePlace", ""),
                education = obj.optString("education", ""),
                workingStatus = obj.optString("workingStatus", ""),
                workDescription = obj.optString("workDescription", ""),
                joiningYear = obj.optInt("joiningYear", 0),
                specialities = obj.optString("specialities", ""),
                religiousLearnings = obj.optString("religiousLearnings", ""),
                anotherGroup = obj.optString("anotherGroup", ""),
                postInGroup = obj.optString("postInGroup", ""),
                paryushanCount = obj.optInt("paryushanCount", 0),
                paryushanHistoryLog = obj.optString("paryushanHistoryLog", ""),
                dailyRoutineActivities = obj.optString("dailyRoutineActivities", ""),
                lifetimeTapasya = obj.optString("lifetimeTapasya", ""),
                paryushanWillingness = obj.optString("paryushanWillingness", ""),
                acceptedRules = obj.optBoolean("acceptedRules", true),
                remarks = obj.optString("remarks", ""),
                profileImageUri = obj.optString("profileImageUri", ""),
                updatedAt = obj.optLong("updatedAt", 0L),
                updatedFields = obj.optString("updatedFields", ""),
                isDeleted = obj.optBoolean("isDeleted", false)
            )
        } catch (e: Exception) {
            null
        }
    }

    fun setAdminStatus(
        targetPhone: String,
        newAdminStatus: Boolean,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val cleanTarget = targetPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanTarget.isBlank()) {
            onComplete(false, "Invalid phone number")
            return
        }
        if (cleanTarget == MASTER_ADMIN_PHONE && !newAdminStatus) {
            onComplete(false, "Cannot remove Master Admin ($MASTER_ADMIN_PHONE)")
            return
        }

        if (newAdminStatus) {
            _adminPhoneNumbers.value = _adminPhoneNumbers.value + cleanTarget
        } else {
            _adminPhoneNumbers.value = _adminPhoneNumbers.value - cleanTarget
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()

                // 1. Update app_config/admin_roles
                val adminDocRef = db.collection("app_config").document("admin_roles")
                if (newAdminStatus) {
                    adminDocRef.set(
                        mapOf("adminPhones" to com.google.firebase.firestore.FieldValue.arrayUnion(cleanTarget)),
                        SetOptions.merge()
                    )
                } else {
                    adminDocRef.set(
                        mapOf("adminPhones" to com.google.firebase.firestore.FieldValue.arrayRemove(cleanTarget)),
                        SetOptions.merge()
                    )
                }

                // 2. Query swadhyai_forms for EXISTING documents matching cleanTarget phone to update isAdmin
                db.collection("swadhyai_forms")
                    .whereEqualTo("whatsappNo", cleanTarget)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        querySnapshot.documents.forEach { doc ->
                            val name = doc.getString("fullName") ?: ""
                            if (name.isNotBlank()) {
                                doc.reference.update("isAdmin", newAdminStatus)
                            }
                        }
                    }

                db.collection("swadhyai_forms")
                    .whereEqualTo("contactNo", cleanTarget)
                    .get()
                    .addOnSuccessListener { querySnapshot ->
                        querySnapshot.documents.forEach { doc ->
                            val name = doc.getString("fullName") ?: ""
                            if (name.isNotBlank()) {
                                doc.reference.update("isAdmin", newAdminStatus)
                            }
                        }
                    }

                // 3. Clean up any rogue ghost docs that may have been created before
                db.collection("swadhyai_forms").document("phone_$cleanTarget").get()
                    .addOnSuccessListener { doc ->
                        if (doc.exists()) {
                            val name = doc.getString("fullName") ?: ""
                            if (name.isBlank()) {
                                doc.reference.delete()
                            }
                        }
                    }
                db.collection("swadhyai_forms").document(cleanTarget).get()
                    .addOnSuccessListener { doc ->
                        if (doc.exists()) {
                            val name = doc.getString("fullName") ?: ""
                            if (name.isBlank()) {
                                doc.reference.delete()
                            }
                        }
                    }

                onComplete(true, null)
            } catch (e: Exception) {
                Log.e("UserSessionManager", "Failed to update admin status: ${e.message}", e)
                onComplete(false, e.message)
            }
        }
    }

    fun getCurrentPhone(): String {
        return _sessionState.value.phone
    }

    fun logout() {
        firestoreListener?.remove()
        firestoreListener = null
        adminConfigListener?.remove()
        adminConfigListener = null

        prefs.edit()
            .clear()
            .apply()

        _sessionState.value = UserSession(
            isLoggedIn = false,
            phone = "",
            fullName = "",
            firstName = "",
            isAdmin = false,
            profileData = null,
            hasUnansweredQuestions = false
        )
        _hasNewQuestionRedDot.value = false
    }
}
