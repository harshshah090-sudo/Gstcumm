package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class UserSession(
    val isLoggedIn: Boolean = false,
    val phone: String = "",
    val fullName: String = "",
    val firstName: String = "",
    val isAdmin: Boolean = false,
    val profileData: SwadhyaiFormEntity? = null,
    val hasUnansweredQuestions: Boolean = false
)

object UserSessionManager {
    private const val PREFS_NAME = "swadhyai_user_session"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_PHONE = "user_phone"
    private const val KEY_FULL_NAME = "user_full_name"
    private const val KEY_IS_ADMIN = "user_is_admin"

    const val MASTER_ADMIN_PHONE = "9009253000"

    private lateinit var prefs: SharedPreferences
    private var firestoreListener: ListenerRegistration? = null

    private val _sessionState = MutableStateFlow(UserSession())
    val sessionState: StateFlow<UserSession> = _sessionState.asStateFlow()

    private val _hasNewQuestionRedDot = MutableStateFlow(false)
    val hasNewQuestionRedDot: StateFlow<Boolean> = _hasNewQuestionRedDot.asStateFlow()

    fun init(context: Context) {
        prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        val phone = prefs.getString(KEY_PHONE, "") ?: ""
        val fullName = prefs.getString(KEY_FULL_NAME, "") ?: ""
        val isMasterAdmin = isMasterAdminPhone(phone)
        val isAdmin = isMasterAdmin || prefs.getBoolean(KEY_IS_ADMIN, false)

        val firstName = extractFirstName(fullName)

        _sessionState.value = UserSession(
            isLoggedIn = isLoggedIn && phone.isNotBlank(),
            phone = phone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = isAdmin
        )

        if (isLoggedIn && phone.isNotBlank()) {
            startRealtimeUserListener(phone)
        }
    }

    fun isMasterAdminPhone(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        return clean == MASTER_ADMIN_PHONE
    }

    private val _adminPhoneNumbers = MutableStateFlow<Set<String>>(setOf(MASTER_ADMIN_PHONE))
    val adminPhoneNumbers: StateFlow<Set<String>> = _adminPhoneNumbers.asStateFlow()

    fun updateAdminPhoneNumbers(phones: Set<String>) {
        _adminPhoneNumbers.value = phones + MASTER_ADMIN_PHONE
    }

    fun isPhoneAdmin(phone: String): Boolean {
        val clean = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (clean == MASTER_ADMIN_PHONE) return true
        return _adminPhoneNumbers.value.contains(clean)
    }

    fun extractFirstName(fullName: String): String {
        val clean = fullName.trim()
        if (clean.isBlank()) return "Swadhyai"
        val parts = clean.split("\\s+".toRegex())
        val first = parts.firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "Swadhyai"
        return if (first.length > 15) first.take(15) else first
    }

    fun login(
        phone: String,
        fullName: String,
        profile: SwadhyaiFormEntity? = null,
        isAdminOverride: Boolean? = null
    ) {
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        val isMaster = isMasterAdminPhone(cleanPhone)
        val admin = isMaster || (isAdminOverride ?: false)
        val firstName = extractFirstName(fullName)

        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putString(KEY_PHONE, cleanPhone)
            .putString(KEY_FULL_NAME, fullName)
            .putBoolean(KEY_IS_ADMIN, admin)
            .apply()

        _sessionState.value = UserSession(
            isLoggedIn = true,
            phone = cleanPhone,
            fullName = fullName,
            firstName = firstName,
            isAdmin = admin,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
        startRealtimeUserListener(cleanPhone)
    }

    fun updateProfileData(profile: SwadhyaiFormEntity) {
        val current = _sessionState.value
        val firstName = extractFirstName(profile.fullName)
        val isMaster = isMasterAdminPhone(current.phone)

        prefs.edit()
            .putString(KEY_FULL_NAME, profile.fullName)
            .apply()

        _sessionState.value = current.copy(
            fullName = profile.fullName,
            firstName = firstName,
            profileData = profile
        )

        checkUnansweredQuestions(profile)
    }

    fun checkUnansweredQuestions(profile: SwadhyaiFormEntity?) {
        if (profile == null) {
            _hasNewQuestionRedDot.value = false
            return
        }
        // Checks if religious learnings, daily routine activities or lifetime tapasya are missing
        val hasMissing = profile.fullName.isBlank() ||
                profile.fatherName.isBlank() ||
                profile.emergencyContactNo.isBlank() ||
                profile.address.isBlank() ||
                profile.city.isBlank() ||
                profile.state.isBlank()
        _hasNewQuestionRedDot.value = hasMissing
    }

    fun startRealtimeUserListener(phone: String) {
        firestoreListener?.remove()
        val cleanPhone = phone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanPhone.isBlank()) return

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestoreListener = firestore.collection("swadhyai_forms")
                .document("phone_$cleanPhone")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w("UserSessionManager", "Error listening to user document: ${error.message}")
                        return@addSnapshotListener
                    }

                    if (snapshot != null && snapshot.exists()) {
                        val isMaster = isMasterAdminPhone(cleanPhone)
                        val firestoreIsAdmin = snapshot.getBoolean("isAdmin") ?: false
                        val currentAdminStatus = isMaster || firestoreIsAdmin
                        val serverFullName = snapshot.getString("fullName") ?: _sessionState.value.fullName
                        val firstName = extractFirstName(serverFullName)

                        prefs.edit()
                            .putBoolean(KEY_IS_ADMIN, currentAdminStatus)
                            .putString(KEY_FULL_NAME, serverFullName)
                            .apply()

                        _sessionState.value = _sessionState.value.copy(
                            isAdmin = currentAdminStatus,
                            fullName = serverFullName,
                            firstName = firstName
                        )
                    }
                }
        } catch (e: Exception) {
            Log.w("UserSessionManager", "Failed to start user listener: ${e.message}")
        }
    }

    fun setAdminStatus(
        targetPhone: String,
        newAdminStatus: Boolean,
        onComplete: (Boolean, String?) -> Unit
    ) {
        val cleanTarget = targetPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
        if (cleanTarget == MASTER_ADMIN_PHONE && !newAdminStatus) {
            onComplete(false, "Cannot remove Master Admin ($MASTER_ADMIN_PHONE)")
            return
        }

        if (newAdminStatus) {
            _adminPhoneNumbers.value = _adminPhoneNumbers.value + cleanTarget
        } else {
            _adminPhoneNumbers.value = _adminPhoneNumbers.value - cleanTarget
        }

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = FirebaseFirestore.getInstance()
                db.collection("swadhyai_forms")
                    .document("phone_$cleanTarget")
                    .set(mapOf("isAdmin" to newAdminStatus), SetOptions.merge())
                    .addOnSuccessListener {
                        // Also update cleanTarget doc if it exists
                        db.collection("swadhyai_forms").document(cleanTarget)
                            .set(mapOf("isAdmin" to newAdminStatus), SetOptions.merge())
                        onComplete(true, null)
                    }
                    .addOnFailureListener { e ->
                        onComplete(false, e.message)
                    }
            } catch (e: Exception) {
                onComplete(false, e.message)
            }
        }
    }

    fun logout() {
        firestoreListener?.remove()
        firestoreListener = null

        prefs.edit()
            .clear()
            .apply()

        _sessionState.value = UserSession(
            isLoggedIn = false,
            phone = "",
            fullName = "",
            firstName = "",
            isAdmin = false,
            profileData = null,
            hasUnansweredQuestions = false
        )
        _hasNewQuestionRedDot.value = false
    }
}
