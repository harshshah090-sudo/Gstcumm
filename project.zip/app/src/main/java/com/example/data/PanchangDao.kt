package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PanchangDao {
    @Query("SELECT * FROM panchang_events ORDER BY dateString ASC")
    fun getAllEvents(): Flow<List<PanchangEventEntity>>

    @Query("SELECT * FROM panchang_events WHERE dateString = :dateString LIMIT 1")
    suspend fun getEventByDate(dateString: String): PanchangEventEntity?

    @Query("SELECT * FROM panchang_events WHERE dateString LIKE :yearMonth || '%' ORDER BY dateString ASC")
    fun getEventsForMonth(yearMonth: String): Flow<List<PanchangEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvents(events: List<PanchangEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: PanchangEventEntity)

    @Query("DELETE FROM panchang_events WHERE id = :id")
    suspend fun deleteEvent(id: Long)

    @Query("DELETE FROM panchang_events")
    suspend fun clearAllEvents()
}
