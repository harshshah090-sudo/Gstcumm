package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gyan_categories")
data class GyanCategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val visualType: String = "EMOJI", // "EMOJI", "IMAGE_BASE64"
    val visualValue: String = "📖",
    val colorHex: String = "#C1861F",
    val description: String = "",
    val orderIndex: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = 0L
)

@Entity(tableName = "gyan_topics")
data class GyanTopicEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val categoryId: Long,
    val title: String = "",
    val content: String,
    val subtext: String = "",
    val textAlignment: String = "LEFT", // "LEFT", "CENTER", "RIGHT"
    val displayStyle: String = "BOX", // "BOX", "PLAIN"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = 0L
)
