package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "swadhyai_forms")
data class SwadhyaiFormEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val firestoreDocId: String = "",
    val fullName: String = "",
    val fatherName: String = "",
    val motherName: String = "",
    val dob: String = "",
    val age: Int = 0,
    val bloodGroup: String = "",
    val maritalStatus: String = "",
    val anniversaryDate: String = "",
    val whatsappNo: String = "",
    val contactNo: String = "",
    val emergencyContactNo: String = "",
    val address: String = "",
    val city: String = "",
    val pincode: String = "",
    val state: String = "",
    val education: String = "",
    val workingStatus: String = "",
    val workDescription: String = "",
    val joiningYear: Int = 0,
    val specialities: String = "",
    val religiousLearnings: String = "",
    val anotherGroup: String = "",
    val postInGroup: String = "",
    val paryushanCount: Int = 0,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

fun SwadhyaiFormEntity.toShareableText(): String {
    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(createdAt))
    return """
    *श्री वर्धमान स्वाध्यायी संघ*
    *स्वाध्यायी पंजीकरण विवरण*
    ======================================
    १. नाम: $fullName
    २. पिता का नाम: $fatherName
    ३. माता का नाम: $motherName
    ४. जन्म तिथि: $dob (${if (age > 0) "$age वर्ष" else "आयु निर्दिष्ट नहीं"})
    ५. वैवाहिक स्थिति: $maritalStatus ${if (anniversaryDate.isNotBlank()) "(विवाह वर्षगांठ: $anniversaryDate)" else ""}
    --------------------------------------
    ६. WhatsApp न.: $whatsappNo
    ७. संपर्क न.: ${contactNo.ifBlank { "N/A" }}
    ८. आपातकालीन संपर्क न.: $emergencyContactNo
    ९. पता: $address
    १०. शहर/राज्य: $city, $state ($pincode)
    --------------------------------------
    ११. शिक्षा: ${education.ifBlank { "N/A" }}
    १२. व्यवसाय/कार्य: $workingStatus (${workDescription.ifBlank { "N/A" }})
    --------------------------------------
    १३. मंडल जुड़ने का वर्ष: ${if (joiningYear > 0) joiningYear else "N/A"}
    १४. विशेषता: ${specialities.ifBlank { "N/A" }}
    १५. धार्मिक ज्ञान: ${religiousLearnings.ifBlank { "N/A" }}
    १६. अन्य ग्रुप: ${anotherGroup.ifBlank { "कोई नहीं" }} (${postInGroup.ifBlank { "N/A" }})
    १७. पर्यूषण आराधना संख्या: $paryushanCount बार
    ======================================
    दिनांक: $dateStr
    """.trimIndent()
}
