package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "swadhyai_forms")
data class SwadhyaiFormEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val firestoreDocId: String = "",
    val fullName: String = "",
    val fatherName: String = "",
    val motherName: String = "",
    val gender: String = "",
    val dob: String = "",
    val age: Int = 0,
    val bloodGroup: String = "",
    val maritalStatus: String = "",
    val anniversaryDate: String = "",
    val email: String = "",
    val whatsappNo: String = "",
    val contactNo: String = "",
    val emergencyContactName: String = "",
    val emergencyContactRelation: String = "",
    val emergencyContactNo: String = "",
    val address: String = "",
    val city: String = "",
    val pincode: String = "",
    val state: String = "",
    val nativePlace: String = "",
    val education: String = "",
    val workingStatus: String = "",
    val workDescription: String = "",
    val joiningYear: Int = 0,
    val specialities: String = "",
    val religiousLearnings: String = "",
    val anotherGroup: String = "",
    val postInGroup: String = "",
    val paryushanCount: Int = 0,
    val paryushanHistoryLog: String = "",
    val dailyRoutineActivities: String = "",
    val lifetimeTapasya: String = "",
    val paryushanWillingness: String = "",
    val acceptedRules: Boolean = true,
    val remarks: String = "",
    val profileImageUri: String = "",
    val updatedAt: Long = 0L,
    val updatedFields: String = "",
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

fun SwadhyaiFormEntity.toShareableText(): String {
    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(createdAt))
    val emergencyInfo = listOf(emergencyContactName, emergencyContactRelation, emergencyContactNo).filter { it.isNotBlank() }.joinToString(" - ")
    val historyLogText = if (paryushanHistoryLog.isNotBlank()) "\n    Paryushan Aaradhna History:\n    ${paryushanHistoryLog.replace("\n", "\n    ")}" else ""
    return """
    *Shri Vardhman Swadhyai Sangh*
    *Swadhyai Registration Full Details*
    ======================================
    [STEP 1: RULES & VERIFICATION]
    1. Rules & Regulations Accepted: ${if (acceptedRules) "Yes (Agreed)" else "Yes"}
    2. Registered WhatsApp No.: ${whatsappNo.ifBlank { "Not specified" }}

    [STEP 2: PERSONAL DETAILS]
    3. Full Name: ${fullName.ifBlank { "Not specified" }}
    4. Father's Name: ${fatherName.ifBlank { "Not specified" }}
    5. Mother's Name: ${motherName.ifBlank { "Not specified" }}
    6. Date of Birth: ${dob.ifBlank { "Not specified" }}
    7. Age: ${if (age > 0) "$age yrs" else "Not specified"}
    8. Blood Group: ${bloodGroup.ifBlank { "Not specified" }}
    9. Marital Status: ${maritalStatus.ifBlank { "Not specified" }}
    10. Date of Anniversary: ${anniversaryDate.ifBlank { "Not Applicable" }}
    11. Educational Qualification: ${education.ifBlank { "Not specified" }}
    12. Your Profession: ${workingStatus.ifBlank { "Not specified" }}
    13. Work Description / Details: ${workDescription.ifBlank { "Not specified" }}

    [STEP 3: CONTACT DETAILS]
    14. Registered WhatsApp No.: ${whatsappNo.ifBlank { "Not specified" }}
    15. Contact No. (Optional): ${contactNo.ifBlank { "Not specified" }}
    16. Email ID: ${email.ifBlank { "Not specified" }}
    17. Emergency Contact Details: ${emergencyInfo.ifBlank { "Not specified" }}
    18. Full Address: ${address.ifBlank { "Not specified" }}
    19. State: ${state.ifBlank { "Not specified" }}
    20. City: ${city.ifBlank { "Not specified" }}
    21. Pin Code: ${pincode.ifBlank { "Not specified" }}

    [STEP 4: RELIGIOUS DETAILS]
    22. Religious Learning: ${religiousLearnings.ifBlank { "Not specified" }}
    23. Speciality: ${specialities.ifBlank { "Not specified" }}
    24. In which Year you Joined the Vardhman Mandal?: ${if (joiningYear > 0) "$joiningYear" else "Not specified"}
    25. How many times you went for Paryushan Aaradhna from Vardhman Mandal?: ${if (paryushanCount > 0) "$paryushanCount times" else "0"}$historyLogText
    26. Another Religious Group (if any): ${anotherGroup.ifBlank { "None" }}
    27. Any special post in any kind of group or sanstha!: ${postInGroup.ifBlank { "None" }}
    28. Daily routine religious activity: ${dailyRoutineActivities.ifBlank { "Not specified" }}
    29. Any religious tapasya or tyag you did for lifetime: ${lifetimeTapasya.ifBlank { "Not specified" }}
    ======================================
    Registration Date: $dateStr
    """.trimIndent()
}
