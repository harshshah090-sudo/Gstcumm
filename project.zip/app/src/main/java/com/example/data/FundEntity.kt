package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fund_holders")
data class FundHolderEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // "BANK" or "CASH"
    val notes: String = ""
)

@Entity(tableName = "fund_transactions")
data class FundTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val firestoreId: String = "",
    val holderId: Long,
    val type: String, // "INCOMING" or "EXPENSE"
    val amount: Double,
    val date: String, // YYYY-MM-DD
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = "",
    val category: String = "General"
)
