package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TimelineDao {
    @Query("SELECT * FROM timeline_posts WHERE isDeleted = 0 ORDER BY dateEpochMillis DESC, createdAtEpochMillis DESC")
    fun getAllPosts(): Flow<List<TimelinePostEntity>>

    @Query("SELECT * FROM timeline_posts WHERE id = :id AND isDeleted = 0 LIMIT 1")
    suspend fun getPostById(id: Long): TimelinePostEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPost(post: TimelinePostEntity): Long

    @Update
    suspend fun updatePost(post: TimelinePostEntity)

    @Query("UPDATE timeline_posts SET isDeleted = 1 WHERE id = :id")
    suspend fun softDeletePost(id: Long)
}
