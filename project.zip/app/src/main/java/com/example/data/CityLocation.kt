package com.example.data

data class CityLocation(
    val id: String,
    val name: String,
    val hindiName: String,
    val stateOrCountry: String,
    val latitude: Double,
    val longitude: Double,
    val timezoneId: String = "Asia/Kolkata"
) {
    val displayName: String
        get() = "$hindiName ($name)"
}

object DefaultCities {
    val DEFAULT_CITY = CityLocation(
        id = "ahmedabad",
        name = "Ahmedabad",
        hindiName = "अहमदाबाद",
        stateOrCountry = "Gujarat, India",
        latitude = 23.0225,
        longitude = 72.5714,
        timezoneId = "Asia/Kolkata"
    )

    val ALL_CITIES = listOf(
        DEFAULT_CITY,
        CityLocation("mumbai", "Mumbai", "मुंबई", "Maharashtra, India", 19.0760, 72.8777, "Asia/Kolkata"),
        CityLocation("surat", "Surat", "सूरत", "Gujarat, India", 21.1702, 72.8311, "Asia/Kolkata"),
        CityLocation("palitana", "Palitana (Shatrunjay)", "पालीताना (शत्रुंजय)", "Gujarat, India", 21.5236, 71.8285, "Asia/Kolkata"),
        CityLocation("shankheshwar", "Shankheshwar", "शंखेश्वर", "Gujarat, India", 23.4984, 71.7766, "Asia/Kolkata"),
        CityLocation("shikharji", "Sammet Shikharji", "सम्मेत शिखरजी", "Jharkhand, India", 23.9785, 86.1554, "Asia/Kolkata"),
        CityLocation("delhi", "New Delhi", "नई दिल्ली", "Delhi, India", 28.6139, 77.2090, "Asia/Kolkata"),
        CityLocation("jaipur", "Jaipur", "जयपुर", "Rajasthan, India", 26.9124, 75.7873, "Asia/Kolkata"),
        CityLocation("rajkot", "Rajkot", "राजकोट", "Gujarat, India", 22.3039, 70.8022, "Asia/Kolkata"),
        CityLocation("vadodara", "Vadodara", "वडोदरा", "Gujarat, India", 22.3072, 73.1812, "Asia/Kolkata"),
        CityLocation("bhavnagar", "Bhavnagar", "भावनगर", "Gujarat, India", 21.7645, 72.1519, "Asia/Kolkata"),
        CityLocation("jamnagar", "Jamnagar", "जामनगर", "Gujarat, India", 22.4707, 70.0577, "Asia/Kolkata"),
        CityLocation("indore", "Indore", "इंदौर", "Madhya Pradesh, India", 22.7196, 75.8577, "Asia/Kolkata"),
        CityLocation("pune", "Pune", "पुणे", "Maharashtra, India", 18.5204, 73.8567, "Asia/Kolkata"),
        CityLocation("bengaluru", "Bengaluru", "बेंगलुरु", "Karnataka, India", 12.9716, 77.5946, "Asia/Kolkata"),
        CityLocation("chennai", "Chennai", "चेन्नई", "Tamil Nadu, India", 13.0827, 80.2707, "Asia/Kolkata"),
        CityLocation("kolkata", "Kolkata", "कोलकाता", "West Bengal, India", 22.5726, 88.3639, "Asia/Kolkata"),
        CityLocation("hyderabad", "Hyderabad", "हैदराबाद", "Telangana, India", 17.3850, 78.4867, "Asia/Kolkata"),
        CityLocation("udaipur", "Udaipur", "उदयपुर", "Rajasthan, India", 24.5854, 73.7125, "Asia/Kolkata"),
        CityLocation("jodhpur", "Jodhpur", "जोधपुर", "Rajasthan, India", 26.2389, 73.0243, "Asia/Kolkata"),
        CityLocation("nagpur", "Nagpur", "नागपुर", "Maharashtra, India", 21.1458, 79.0882, "Asia/Kolkata"),
        // International Hubs
        CityLocation("dubai", "Dubai", "दुबई", "United Arab Emirates", 25.2048, 55.2708, "Asia/Dubai"),
        CityLocation("london", "London", "लंदन", "United Kingdom", 51.5074, -0.1278, "Europe/London"),
        CityLocation("new_york", "New York", "न्यू यॉर्क", "United States", 40.7128, -74.0060, "America/New_York"),
        CityLocation("chicago", "Chicago", "शिकागो", "United States", 41.8781, -87.6298, "America/Chicago"),
        CityLocation("san_francisco", "San Francisco", "सैन फ्रांसिस्को", "United States", 37.7749, -122.4194, "America/Los_Angeles"),
        CityLocation("toronto", "Toronto", "टोरंटो", "Canada", 43.6532, -79.3832, "America/Toronto"),
        CityLocation("singapore", "Singapore", "सिंगापुर", "Singapore", 1.3521, 103.8198, "Asia/Singapore"),
        CityLocation("sydney", "Sydney", "सिडनी", "Australia", -33.8688, 151.2093, "Australia/Sydney"),
        CityLocation("antwerp", "Antwerp", "एंटवर्प", "Belgium", 51.2194, 4.4025, "Europe/Brussels")
    )
}
