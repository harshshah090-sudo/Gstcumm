package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FormDao {
    @Query("SELECT * FROM paryushan_forms WHERE isDeleted = 0 ORDER BY createdAt DESC")
    fun getAllForms(): Flow<List<ParyushanFormEntity>>

    @Query("SELECT * FROM paryushan_forms WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun getDeletedForms(): Flow<List<ParyushanFormEntity>>

    @Query("SELECT * FROM paryushan_forms WHERE id = :id AND isDeleted = 0")
    suspend fun getFormById(id: Long): ParyushanFormEntity?

    @Query("SELECT * FROM paryushan_forms WHERE id = :id")
    fun getFormFlowById(id: Long): Flow<ParyushanFormEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForm(form: ParyushanFormEntity): Long

    @Update
    suspend fun updateForm(form: ParyushanFormEntity)

    @Query("UPDATE paryushan_forms SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :id")
    suspend fun softDeleteForm(id: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE paryushan_forms SET isDeleted = 0, deletedAt = NULL WHERE id = :id")
    suspend fun restoreForm(id: Long)

    @Delete
    suspend fun deleteForm(form: ParyushanFormEntity)

    @Query("DELETE FROM paryushan_forms WHERE id = :id")
    suspend fun deleteFormPermanentlyById(id: Long)

    @Query("DELETE FROM paryushan_forms WHERE id = :id")
    suspend fun deleteFormById(id: Long)

    @Query("DELETE FROM paryushan_forms WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoffTime")
    suspend fun purgeOldDeletedForms(cutoffTime: Long)

    @Query("DELETE FROM paryushan_forms WHERE id NOT IN (:validIds) AND isDeleted = 0")
    suspend fun deleteFormsNotIn(validIds: List<Long>)

    @Query("DELETE FROM paryushan_forms")
    suspend fun deleteAllForms()

    @Query("SELECT COUNT(*) FROM paryushan_forms WHERE isDeleted = 0")
    suspend fun getFormCount(): Int
}
