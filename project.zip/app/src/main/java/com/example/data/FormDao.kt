package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface FormDao {
    @Query("SELECT * FROM paryushan_forms ORDER BY createdAt DESC")
    fun getAllForms(): Flow<List<ParyushanFormEntity>>

    @Query("SELECT * FROM paryushan_forms WHERE id = :id")
    suspend fun getFormById(id: Long): ParyushanFormEntity?

    @Query("SELECT * FROM paryushan_forms WHERE id = :id")
    fun getFormFlowById(id: Long): Flow<ParyushanFormEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForm(form: ParyushanFormEntity): Long

    @Update
    suspend fun updateForm(form: ParyushanFormEntity)

    @Delete
    suspend fun deleteForm(form: ParyushanFormEntity)

    @Query("DELETE FROM paryushan_forms WHERE id = :id")
    suspend fun deleteFormById(id: Long)

    @Query("SELECT COUNT(*) FROM paryushan_forms")
    suspend fun getFormCount(): Int
}
