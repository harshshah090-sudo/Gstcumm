package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FundDao {
    @Query("SELECT * FROM fund_holders ORDER BY type ASC, name ASC")
    fun getAllHolders(): Flow<List<FundHolderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHolder(holder: FundHolderEntity): Long

    @Update
    suspend fun updateHolder(holder: FundHolderEntity)

    @Delete
    suspend fun deleteHolder(holder: FundHolderEntity)

    @Query("SELECT * FROM fund_transactions ORDER BY date DESC, timestamp DESC")
    fun getAllTransactions(): Flow<List<FundTransactionEntity>>

    @Query("SELECT * FROM fund_transactions WHERE holderId = :holderId ORDER BY date DESC, timestamp DESC")
    fun getTransactionsForHolder(holderId: Long): Flow<List<FundTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FundTransactionEntity): Long

    @Delete
    suspend fun deleteTransaction(transaction: FundTransactionEntity)

    @Query("DELETE FROM fund_transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)
}
