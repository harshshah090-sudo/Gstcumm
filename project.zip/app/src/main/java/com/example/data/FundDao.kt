package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FundDao {
    @Query("SELECT * FROM fund_transactions ORDER BY date DESC")
    fun getAllTransactions(): Flow<List<FundTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FundTransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: FundTransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: FundTransactionEntity)

    @Query("DELETE FROM fund_transactions WHERE id = :id")
    suspend fun deleteById(id: Long)
}
