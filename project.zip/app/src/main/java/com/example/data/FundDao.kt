package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FundDao {
    @Query("SELECT * FROM fund_transactions WHERE isDeleted = 0 ORDER BY date DESC")
    fun getAllTransactions(): Flow<List<FundTransactionEntity>>

    @Query("SELECT * FROM fund_transactions WHERE isDeleted = 1 ORDER BY deletedAt DESC, date DESC")
    fun getDeletedTransactions(): Flow<List<FundTransactionEntity>>

    @Query("SELECT * FROM fund_transactions WHERE isDeleted = 0 ORDER BY date DESC")
    suspend fun getAllTransactionsList(): List<FundTransactionEntity>

    @Query("SELECT * FROM fund_transactions ORDER BY date DESC")
    suspend fun getAllTransactionsIncludingDeletedList(): List<FundTransactionEntity>

    @Query("SELECT * FROM fund_transactions WHERE id = :id")
    suspend fun getTransactionById(id: Long): FundTransactionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: FundTransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: FundTransactionEntity)

    @Query("UPDATE fund_transactions SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :id")
    suspend fun softDeleteTransaction(id: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE fund_transactions SET isDeleted = 0, deletedAt = NULL WHERE id = :id")
    suspend fun restoreTransaction(id: Long)

    @Query("DELETE FROM fund_transactions WHERE isDeleted = 1 AND deletedAt IS NOT NULL AND deletedAt < :cutoffTime")
    suspend fun purgeOldDeletedTransactions(cutoffTime: Long)

    @Delete
    suspend fun deleteTransaction(transaction: FundTransactionEntity)

    @Query("DELETE FROM fund_transactions WHERE id = :id")
    suspend fun deleteById(id: Long)
}
