package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FundPersonDao {
    @Query("SELECT * FROM fund_persons ORDER BY name ASC")
    fun getAllPersons(): Flow<List<FundPersonEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: FundPersonEntity): Long

    @Delete
    suspend fun deletePerson(person: FundPersonEntity)
}
