package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "registration_history")
data class RegistrationHistoryEntity(
    @PrimaryKey
    val year: Int,                             // e.g. 2026
    val paryushanStartDate: String = "",       // e.g. "08 Sep 2026"
    val paryushanEndDate: String = "",         // e.g. "15 Sep 2026"
    val totalSanghCount: Int = 0,              // Total registered sanghs count
    val allottedSanghCount: Int = 0,           // Count of allotted sanghs
    val unallottedSanghCount: Int = 0,         // Count of unallotted sanghs
    val totalAllottedSwadhyayisCount: Int = 0, // Total count of allotted swadhyayis
    val totalDonationReceived: Double = 0.0,   // Total donation sum from allotted sanghs
    val archivedAllotmentsJson: String = "",   // JSON array of allotted sanghs + swadhyayis + donations
    val archivedUnallottedSanghsJson: String = "", // JSON array of unallotted sanghs
    val archivedSwadhyaiUpdatesJson: String = "", // JSON array of swadhyai updates for restoration
    val archivedSanghFormsJson: String = "",   // Full JSON array of all registered Sangh forms for complete restoration
    val createdAt: Long = System.currentTimeMillis()
)
