package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "paryushan_forms")
data class ParyushanFormEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val firestoreDocId: String = "",
    val sanghName: String,
    val sanghAddress: String,
    val cityName: String,
    val contact1: String,
    val contact2: String,
    val mulnayakBhagwan: String,
    val totalFamilies: String,
    val hasOtherSangh: String, // "हाँ" or "नहीं"
    val gacchList: String, // Comma separated values e.g. "तपागच्छ, खतरगच्छ"
    val pratikramanTradition: String, // Comma separated values
    val hasMusicianGroup: String, // "हाँ" or "नहीं"
    val callsOutsideMusician: String, // "हाँ" or "नहीं"
    val hasPanchPratikramanPerson: String, // "हाँ" or "नहीं"
    val hasToiletFacility: String, // "हाँ" or "नहीं"
    val aradhanaSamagriList: String, // Comma separated items
    val countRaiPratikraman: String, // "1-10", "11-25", "26-50", "51-100 या अधिक"
    val countDevasiPratikraman: String,
    val countPravachan: String,
    val countSandhyaBhakti: String,
    val mainTrustees: String,
    val agreedToTerms: Boolean,
    val isDeleted: Boolean = false,
    val deletedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

fun ParyushanFormEntity.toShareableText(): String {
    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(createdAt))
    
    fun formatListItems(raw: String, emptyFallback: String = "कोई नहीं"): String {
        val commaNotInParensRegex = Regex(",(?![^()]*\\))")
        val items = raw.split(commaNotInParensRegex).map { it.trim() }.filter { it.isNotBlank() && it != "null" }
        if (items.isEmpty() || raw.trim() == "कोई नहीं" || raw.trim() == "निर्दिष्ट नहीं") return emptyFallback
        return items.joinToString("\n   ✔️ ")
    }

    val formattedGacch = formatListItems(gacchList, "निर्दिष्ट नहीं")
    val formattedTradition = formatListItems(pratikramanTradition, "निर्दिष्ट नहीं")
    val formattedSamagri = formatListItems(aradhanaSamagriList, "कोई नहीं")

    return """
    *श्री वर्धमान स्वाध्यायी मंडल*
    *पर्वाधीराज पर्यूषण आराधना - संघ विवरण*
    ======================================
    १. श्री संघ का नाम: $sanghName
    २. श्री संघ का पूरा पता: $sanghAddress
    ३. शहर/गांव का नाम: $cityName
    --------------------------------------
    ४. स्वाध्याई भाई संपर्क (नाम, पद): $contact1
    ५. स्वाध्याई भाई WhatsApp न.: $contact2
    ६. मुलनायक भगवान: $mulnayakBhagwan
    ७. संघ में कुल परिवार: $totalFamilies
    ८. अन्य संघ उपस्थित है: $hasOtherSangh
    ९. संघ में गच्छ:
   ✔️ $formattedGacch
    १०. प्रतिकमण परंपरा:
   ✔️ $formattedTradition
    ११. संगीतकार / मंडल उपस्थित है: $hasMusicianGroup
    १२. बाहर से संगीतकार बुलाते हों: $callsOutsideMusician
    १३. पंच प्रतिकमण जानकर व्यक्ति: $hasPanchPratikramanPerson
    १४. मात्रू-ठल्ले (Toilet) व्यवस्था: $hasToiletFacility
    १५. उपलब्ध आराधना सामग्री:
   ✔️ $formattedSamagri
    १६. प्रवृत्तियों में हाजिर व्यक्तियों की संख्या:
       • राई प्रतिकमण: $countRaiPratikraman
       • देवसी प्रतिकमण: $countDevasiPratikraman
       • प्रवचन: $countPravachan
       • संध्या भक्ति: $countSandhyaBhakti
    १७. मुख्य ३ अग्रणी/ट्रस्टी: $mainTrustees
    १८. सर्व अग्रणियों की सम्मति एवं नियम स्वीकृति: ${if (agreedToTerms) "समस्त अग्रणियों की सर्वसम्मति एवं नियम स्वीकृत हैं ✔️" else "नहीं ❌"}
    ======================================
    दिनांक: $dateStr
    """.trimIndent()
}
