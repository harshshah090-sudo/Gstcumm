package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "paryushan_forms")
data class ParyushanFormEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val firestoreDocId: String = "",
    val sanghName: String,
    val sanghAddress: String,
    val cityName: String,
    val contact1: String,
    val contact2: String,
    val mulnayakBhagwan: String,
    val totalFamilies: String,
    val hasOtherSangh: String, // "हाँ" or "नहीं"
    val gacchList: String, // Comma separated values e.g. "तपागच्छ, खतरगच्छ"
    val pratikramanTradition: String, // Comma separated values
    val hasMusicianGroup: String, // "हाँ" or "नहीं"
    val callsOutsideMusician: String, // "हाँ" or "नहीं"
    val hasPanchPratikramanPerson: String, // "हाँ" or "नहीं"
    val hasToiletFacility: String, // "हाँ" or "नहीं"
    val aradhanaSamagriList: String, // Comma separated items
    val countRaiPratikraman: String, // "1-10", "11-25", "26-50", "51-100 या अधिक"
    val countDevasiPratikraman: String,
    val countPravachan: String,
    val countSandhyaBhakti: String,
    val mainTrustees: String,
    val agreedToTerms: Boolean,
    val createdAt: Long = System.currentTimeMillis()
)

fun ParyushanFormEntity.toShareableText(): String {
    val dateStr = java.text.SimpleDateFormat("dd/MM/yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(createdAt))
    return """
    *श्री वर्धमान स्वाध्यायी मंडल*
    *पर्वाधीराज पर्यूषण आराधना - संघ विवरण*
    ======================================
    १. श्री संघ का नाम: $sanghName
    २. श्री संघ का पूरा पता: $sanghAddress
    ३. शहर / गांव: $cityName
    --------------------------------------
    ४. संपर्क सूत्र (१): $contact1
    ५. संपर्क सूत्र (२): $contact2
    ६. मुलनायक भगवान: $mulnayakBhagwan
    ७. कुल परिवार: $totalFamilies
    ८. अन्य संघ उपस्थित: $hasOtherSangh
    ९. गच्छ परंपरा: ${gacchList.ifBlank { "निर्दिष्ट नहीं" }}
    १०. प्रतिकमण परंपरा: ${pratikramanTradition.ifBlank { "निर्दिष्ट नहीं" }}
    ११. संगीतकार/मंडल उपस्थित: $hasMusicianGroup
    १२. बाहर से संगीतकार: $callsOutsideMusician
    १३. पंच प्रतिकमण जानकर व्यक्ति: $hasPanchPratikramanPerson
    १४. मात्रू-ठल्ले (Toilet) व्यवस्था: $hasToiletFacility
    १५. उपलब्ध आराधना सामग्री: ${if (aradhanaSamagriList.isBlank()) "कोई नहीं" else aradhanaSamagriList}
    १६. प्रवृत्तियों में औसत उपस्थिति:
       • राई प्रतिकमण: $countRaiPratikraman
       • देवसी प्रतिकमण: $countDevasiPratikraman
       • प्रवचन: $countPravachan
       • संध्या भक्ति: $countSandhyaBhakti
    १७. मुख्य ३ अग्रणी/ट्रस्टी: $mainTrustees
    १८. सर्व अग्रणियों की सम्मति: ${if (agreedToTerms) "हाँ (स्वीकृत ✔️)" else "नहीं"}
    ======================================
    दिनांक: $dateStr
    """.trimIndent()
}
