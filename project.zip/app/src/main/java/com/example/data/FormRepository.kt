package com.example.data

import kotlinx.coroutines.flow.Flow

class FormRepository(private val formDao: FormDao) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long = formDao.insertForm(form)

    suspend fun updateForm(form: ParyushanFormEntity) = formDao.updateForm(form)

    suspend fun deleteFormById(id: Long) = formDao.deleteFormById(id)

    suspend fun prepopulateIfEmpty() {
        // No sample forms pre-populated by default so the list starts clean
    }
}
