package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class FormRepository(
    private val formDao: FormDao,
    private val swadhyaiDao: SwadhyaiDao,
    private val allotmentDao: AllotmentDao? = null,
    private val fundDao: FundDao? = null,
    private val fundPersonDao: FundPersonDao? = null,
    private val context: Context? = null
) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()
    val deletedForms: Flow<List<ParyushanFormEntity>> = formDao.getDeletedForms()
    val allSwadhyaiForms: Flow<List<SwadhyaiFormEntity>> = swadhyaiDao.getAllSwadhyaiForms()
    val allAllotments: Flow<List<AllotmentEntity>> = allotmentDao?.getAllAllotments() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allFundTransactions: Flow<List<FundTransactionEntity>> = fundDao?.getAllTransactions() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val deletedFundTransactions: Flow<List<FundTransactionEntity>> = fundDao?.getDeletedTransactions() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allFundPersons: Flow<List<FundPersonEntity>> = fundPersonDao?.getAllPersons() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    private var firestoreListener: ListenerRegistration? = null
    private var swadhyaiFirestoreListener: ListenerRegistration? = null
    private var configListener: ListenerRegistration? = null
    private var fundFirestoreListener: ListenerRegistration? = null
    private var personFirestoreListener: ListenerRegistration? = null
    private var allotmentFirestoreListener: ListenerRegistration? = null

    private val fundTxSyncMutex = Mutex()
    private val fundPersonSyncMutex = Mutex()

    private val prefs = context?.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    val isSanghRegistrationStopped = kotlinx.coroutines.flow.MutableStateFlow<Boolean>(
        prefs?.getBoolean("is_sangh_registration_stopped", false) ?: false
    )
    val isSyncing = kotlinx.coroutines.flow.MutableStateFlow<Boolean>(false)

    init {
        ensureAuthAndSync()
    }

    private fun ensureAuthAndSync() {
        try {
            val auth = FirebaseAuth.getInstance()
            if (auth.currentUser == null) {
                auth.signInAnonymously()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Log.d("FormRepository", "Signed in anonymously to Firebase")
                        } else {
                            Log.w("FormRepository", "Anonymous auth failed: ${task.exception?.message}")
                        }
                        startCloudSync()
                        refreshCloudData()
                    }
            } else {
                startCloudSync()
                refreshCloudData()
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "FirebaseAuth init error: ${e.message}")
            startCloudSync()
            refreshCloudData()
        }
    }

    fun refreshCloudData() {
        try {
            val firestore = FirebaseFirestore.getInstance()

            firestore.collection("paryushan_forms").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val forms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing doc: ${e.message}")
                                null
                            }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            val localSoftDeletedIds = formDao.getSoftDeletedIds().toSet()
                            val validIds = forms.map { it.id }
                            forms.forEach { cloudForm ->
                                val formToInsert = if (localSoftDeletedIds.contains(cloudForm.id) && !cloudForm.isDeleted) {
                                    cloudForm.copy(isDeleted = true)
                                } else {
                                    cloudForm
                                }
                                formDao.insertForm(formToInsert)
                            }
                            if (validIds.isNotEmpty()) {
                                formDao.deleteFormsNotIn(validIds)
                            }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for paryushan_forms: ${e.message}")
                }

            firestore.collection("swadhyai_forms").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val swadhyaiForms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToSwadhyaiEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing swadhyai doc ${doc.id}: ${e.message}")
                                null
                            }
                        }
                        Log.d("FormRepository", "Fetched ${swadhyaiForms.size} swadhyai forms manually")
                        CoroutineScope(Dispatchers.IO).launch {
                            val validIds = swadhyaiForms.map { it.id }
                            swadhyaiForms.forEach { cloudForm ->
                                swadhyaiDao.insertForm(cloudForm)
                            }
                            if (validIds.isNotEmpty()) {
                                swadhyaiDao.deleteFormsNotIn(validIds)
                            }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for swadhyai_forms: ${e.message}")
                }
            firestore.collection("sangh_allotments").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val allotments = snapshot.documents.mapNotNull { doc ->
                            try {
                                val sId = doc.getLong("sanghId") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                val sName = doc.getString("sanghName") ?: ""
                                val cName = doc.getString("cityName") ?: ""
                                val stName = doc.getString("stateName") ?: ""
                                val swIds = doc.getString("swadhyaiIds") ?: ""
                                val uAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                                AllotmentEntity(sId, sName, cName, stName, swIds, uAt)
                            } catch (e: Exception) { null }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            val validIds = allotments.map { it.sanghId }
                            allotments.forEach { allotmentDao?.saveAllotment(it) }
                            if (validIds.isNotEmpty()) {
                                allotmentDao?.deleteNotIn(validIds)
                            }
                        }
                    }
                }

            firestore.collection("fund_transactions").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            syncFundTransactionsToLocal(snapshot.documents)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for fund_transactions: ${e.message}")
                }

            firestore.collection("fund_persons").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            syncFundPersonsToLocal(snapshot.documents)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for fund_persons: ${e.message}")
                }

            firestore.collection("app_config").document("sangh_registration").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && snapshot.exists() && snapshot.contains("isStopped")) {
                        val stopped = snapshot.getBoolean("isStopped") ?: false
                        isSanghRegistrationStopped.value = stopped
                        prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()
                    }
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Error in refreshCloudData: ${e.message}")
        }
    }

    fun setSanghRegistrationStopped(stopped: Boolean) {
        isSanghRegistrationStopped.value = stopped
        prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()

        try {
            val firestore = FirebaseFirestore.getInstance()
            val data = mapOf(
                "isStopped" to stopped,
                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            firestore.collection("app_config").document("sangh_registration")
                .set(data, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("FormRepository", "Updated sangh_registration isStopped to $stopped")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to update sangh_registration: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error updating sangh_registration status: ${e.message}")
        }
    }

    private suspend fun syncFundTransactionsToLocal(documents: List<DocumentSnapshot>) {
        if (fundDao == null) return

        isSyncing.value = true
        try {
            fundTxSyncMutex.withLock {
            val localList = fundDao.getAllTransactionsIncludingDeletedList()
            val localByRemoteId = localList.filter { it.remoteId.isNotEmpty() }.groupBy { it.remoteId }.toMutableMap()
            val cloudRemoteIds = mutableSetOf<String>()

            documents.forEach { doc ->
                try {
                    val remoteId = doc.id
                    if (remoteId.isBlank()) return@forEach
                    cloudRemoteIds.add(remoteId)

                    val type = doc.getString("type") ?: "INCOMING"
                    val mode = doc.getString("mode") ?: "BANK"
                    val amount = doc.getDouble("amount") ?: 0.0
                    val title = doc.getString("title") ?: ""
                    val description = doc.getString("description") ?: ""
                    val personName = doc.getString("personName") ?: ""
                    val date = doc.getLong("date") ?: System.currentTimeMillis()
                    val transferFrom = doc.getString("transferFrom") ?: ""
                    val transferTo = doc.getString("transferTo") ?: ""
                    val isEdited = doc.getBoolean("isEdited") ?: false
                    val editHistory = doc.getString("editHistory") ?: ""
                    val isDeleted = doc.getBoolean("isDeleted") ?: false
                    val deletedAt = doc.getLong("deletedAt")

                    val existingLocals = localByRemoteId[remoteId] ?: emptyList()
                    val targetLocalId = if (existingLocals.isNotEmpty()) existingLocals.first().id else 0L

                    if (existingLocals.size > 1) {
                        existingLocals.drop(1).forEach { extra ->
                            fundDao.deleteTransaction(extra)
                        }
                    }

                    val entityToSave = FundTransactionEntity(
                        id = targetLocalId,
                        type = type,
                        mode = mode,
                        amount = amount,
                        title = title,
                        description = description,
                        personName = personName,
                        date = date,
                        remoteId = remoteId,
                        transferFrom = transferFrom,
                        transferTo = transferTo,
                        isEdited = isEdited,
                        editHistory = editHistory,
                        isDeleted = isDeleted,
                        deletedAt = deletedAt
                    )
                    val insertedId = fundDao.insertTransaction(entityToSave)
                    val actualLocalId = if (targetLocalId != 0L) targetLocalId else insertedId
                    val savedEntity = entityToSave.copy(id = actualLocalId)
                    localByRemoteId[remoteId] = listOf(savedEntity)
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error syncing individual fund transaction doc: ${e.message}")
                }
            }

            // Remove local records whose remoteId is not present in cloud snapshots
            localList.forEach { localTx ->
                if (localTx.remoteId.isNotEmpty() && !cloudRemoteIds.contains(localTx.remoteId)) {
                    fundDao.deleteTransaction(localTx)
                }
            }
        }
        } finally {
            isSyncing.value = false
        }
    }

    private suspend fun syncFundPersonsToLocal(documents: List<DocumentSnapshot>) {
        if (fundPersonDao == null) return

        isSyncing.value = true
        try {
            fundPersonSyncMutex.withLock {
                val localList = fundPersonDao.getAllPersonsList()
                val localByRemoteId = localList.filter { it.remoteId.isNotEmpty() }.groupBy { it.remoteId }.toMutableMap()
                val cloudRemoteIds = mutableSetOf<String>()

                documents.forEach { doc ->
                    try {
                        val remoteId = doc.id
                        val name = (doc.getString("name") ?: "").trim()
                        if (remoteId.isNotBlank() && name.isNotBlank()) {
                            cloudRemoteIds.add(remoteId)
                            val existingLocals = localByRemoteId[remoteId] ?: emptyList()
                            val targetLocalId = if (existingLocals.isNotEmpty()) existingLocals.first().id else 0L

                            if (existingLocals.size > 1) {
                                existingLocals.drop(1).forEach { extra ->
                                    fundPersonDao.deletePerson(extra)
                                }
                            }

                            val entityToSave = FundPersonEntity(
                                id = targetLocalId,
                                name = name,
                                remoteId = remoteId
                            )
                            val insertedId = fundPersonDao.insertPerson(entityToSave)
                            val actualLocalId = if (targetLocalId != 0L) targetLocalId else insertedId
                            val savedEntity = entityToSave.copy(id = actualLocalId)
                            localByRemoteId[remoteId] = listOf(savedEntity)
                        }
                    } catch (e: Exception) {
                        Log.e("FormRepository", "Error syncing individual fund person doc: ${e.message}")
                    }
                }

                localList.forEach { localPerson ->
                    if (localPerson.remoteId.isNotEmpty() && !cloudRemoteIds.contains(localPerson.remoteId)) {
                        fundPersonDao.deletePerson(localPerson)
                    }
                }
            }
        } finally {
            isSyncing.value = false
        }
    }

    suspend fun insertFundTransaction(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            try {
                val firestore = FirebaseFirestore.getInstance()

                // Generate UUID if remoteId is blank to guarantee instant, unique entity identity
                val remoteId = if (transaction.remoteId.isNotBlank()) {
                    transaction.remoteId
                } else {
                    java.util.UUID.randomUUID().toString()
                }

                val entityWithRemoteId = transaction.copy(remoteId = remoteId)
                val insertedId = fundDao?.insertTransaction(entityWithRemoteId) ?: 0L
                val finalEntity = entityWithRemoteId.copy(id = if (entityWithRemoteId.id == 0L) insertedId else entityWithRemoteId.id)

                val docRef = firestore.collection("fund_transactions").document(remoteId)
                val data = hashMapOf(
                    "remoteId" to remoteId,
                    "type" to finalEntity.type,
                    "mode" to finalEntity.mode,
                    "amount" to finalEntity.amount,
                    "title" to finalEntity.title,
                    "description" to finalEntity.description,
                    "personName" to finalEntity.personName,
                    "date" to finalEntity.date,
                    "transferFrom" to finalEntity.transferFrom,
                    "transferTo" to finalEntity.transferTo,
                    "isEdited" to finalEntity.isEdited,
                    "editHistory" to finalEntity.editHistory,
                    "isDeleted" to finalEntity.isDeleted,
                    "deletedAt" to finalEntity.deletedAt,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                docRef.set(data, SetOptions.merge())
                    .addOnSuccessListener { Log.d("FormRepository", "Fund transaction synced to Firestore: $remoteId") }
                    .addOnFailureListener { e -> Log.e("FormRepository", "Failed to sync fund transaction: ${e.message}") }
            } catch (e: Exception) {
                Log.e("FormRepository", "Error syncing fund transaction: ${e.message}")
            }
        }
    }

    suspend fun insertFundPerson(name: String): Long {
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) return 0L

        fundPersonSyncMutex.withLock {
            val existingList = fundPersonDao?.getAllPersonsList() ?: emptyList()
            val existing = existingList.find { it.name.equals(trimmedName, ignoreCase = true) }
            if (existing != null) {
                return existing.id
            }

            try {
                val firestore = FirebaseFirestore.getInstance()
                val remoteId = java.util.UUID.randomUUID().toString()
                val person = FundPersonEntity(name = trimmedName, remoteId = remoteId)
                val insertedId = fundPersonDao?.insertPerson(person) ?: 0L

                val docRef = firestore.collection("fund_persons").document(remoteId)
                val data = hashMapOf(
                    "remoteId" to remoteId,
                    "name" to trimmedName,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                docRef.set(data, SetOptions.merge())
                return insertedId
            } catch (e: Exception) {
                Log.e("FormRepository", "Error syncing fund person: ${e.message}")
                return 0L
            }
        }
    }

    suspend fun deleteFundPerson(person: FundPersonEntity) {
        fundPersonSyncMutex.withLock {
            if (person.id != 0L) {
                fundPersonDao?.deletePerson(person)
            }
            if (person.remoteId.isNotEmpty()) {
                val existingList = fundPersonDao?.getAllPersonsList() ?: emptyList()
                existingList.filter { it.remoteId == person.remoteId }.forEach {
                    fundPersonDao?.deletePerson(it)
                }
                try {
                    FirebaseFirestore.getInstance().collection("fund_persons").document(person.remoteId).delete()
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error deleting fund person from Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun softDeleteFundTransaction(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            val now = System.currentTimeMillis()
            if (transaction.id != 0L) {
                fundDao?.softDeleteTransaction(transaction.id, now)
            }
            val remoteId = transaction.remoteId
            if (remoteId.isNotBlank()) {
                try {
                    FirebaseFirestore.getInstance().collection("fund_transactions")
                        .document(remoteId)
                        .update(mapOf("isDeleted" to true, "deletedAt" to now, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()))
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error soft-deleting fund transaction in Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun restoreFundTransaction(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            if (transaction.id != 0L) {
                fundDao?.restoreTransaction(transaction.id)
            }
            val remoteId = transaction.remoteId
            if (remoteId.isNotBlank()) {
                try {
                    FirebaseFirestore.getInstance().collection("fund_transactions")
                        .document(remoteId)
                        .update(mapOf("isDeleted" to false, "deletedAt" to null, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()))
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error restoring fund transaction in Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteFundTransactionPermanently(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            if (transaction.id != 0L) {
                fundDao?.deleteById(transaction.id)
            }
            if (transaction.remoteId.isNotEmpty()) {
                val existingList = fundDao?.getAllTransactionsIncludingDeletedList() ?: emptyList()
                existingList.filter { it.remoteId == transaction.remoteId }.forEach {
                    fundDao?.deleteTransaction(it)
                }
                try {
                    FirebaseFirestore.getInstance().collection("fund_transactions").document(transaction.remoteId).delete()
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error deleting fund transaction permanently from Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteFundTransaction(transaction: FundTransactionEntity) {
        softDeleteFundTransaction(transaction)
    }

    private fun startCloudSync() {
        try {
            val firestore = FirebaseFirestore.getInstance()

            if (personFirestoreListener == null) {
                personFirestoreListener = firestore.collection("fund_persons")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for fund_persons: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            CoroutineScope(Dispatchers.IO).launch {
                                syncFundPersonsToLocal(snapshot.documents)
                            }
                        }
                    }
            }

            if (fundFirestoreListener == null) {
                fundFirestoreListener = firestore.collection("fund_transactions")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for fund_transactions: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            CoroutineScope(Dispatchers.IO).launch {
                                syncFundTransactionsToLocal(snapshot.documents)
                            }
                        }
                    }
            }

            if (configListener == null) {
                configListener = firestore.collection("app_config").document("sangh_registration")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for app_config: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && snapshot.exists() && snapshot.contains("isStopped")) {
                            val stopped = snapshot.getBoolean("isStopped") ?: false
                            isSanghRegistrationStopped.value = stopped
                            prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()
                        }
                    }
            }

            if (firestoreListener == null) {
                firestoreListener = firestore.collection("paryushan_forms")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for paryushan_forms: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val forms = snapshot.documents.mapNotNull { doc ->
                                try {
                                    parseDocToEntity(doc)
                                } catch (e: Exception) {
                                    Log.e("FormRepository", "Error parsing Firestore doc: ${e.message}")
                                    null
                                }
                            }
                            CoroutineScope(Dispatchers.IO).launch {
                                val localSoftDeletedIds = formDao.getSoftDeletedIds().toSet()
                                val validIds = forms.map { it.id }
                                forms.forEach { cloudForm ->
                                    val formToInsert = if (localSoftDeletedIds.contains(cloudForm.id) && !cloudForm.isDeleted) {
                                        cloudForm.copy(isDeleted = true)
                                    } else {
                                        cloudForm
                                    }
                                    formDao.insertForm(formToInsert)
                                }
                                if (validIds.isNotEmpty()) {
                                    formDao.deleteFormsNotIn(validIds)
                                }
                            }
                        }
                    }
            }

            if (swadhyaiFirestoreListener == null) {
                swadhyaiFirestoreListener = firestore.collection("swadhyai_forms")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for swadhyai_forms: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val swadhyaiForms = snapshot.documents.mapNotNull { doc ->
                                try {
                                    parseDocToSwadhyaiEntity(doc)
                                } catch (e: Exception) {
                                    Log.e("FormRepository", "Error parsing swadhyai Firestore doc ${doc.id}: ${e.message}")
                                    null
                                }
                            }
                            Log.d("FormRepository", "Realtime update: ${swadhyaiForms.size} swadhyai forms")
                            CoroutineScope(Dispatchers.IO).launch {
                                val validIds = swadhyaiForms.map { it.id }
                                swadhyaiForms.forEach { cloudForm ->
                                    swadhyaiDao.insertForm(cloudForm)
                                }
                                if (validIds.isNotEmpty()) {
                                    swadhyaiDao.deleteFormsNotIn(validIds)
                                }
                            }
                        }
                    }
            }

            if (allotmentFirestoreListener == null) {
                allotmentFirestoreListener = firestore.collection("sangh_allotments")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for sangh_allotments: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val allotments = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val sId = doc.getLong("sanghId") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val sName = doc.getString("sanghName") ?: ""
                                    val cName = doc.getString("cityName") ?: ""
                                    val stName = doc.getString("stateName") ?: ""
                                    val swIds = doc.getString("swadhyaiIds") ?: ""
                                    val uAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                                    AllotmentEntity(sId, sName, cName, stName, swIds, uAt)
                                } catch (e: Exception) { null }
                            }
                            Log.d("FormRepository", "Realtime update: ${allotments.size} allotments")
                            CoroutineScope(Dispatchers.IO).launch {
                                val validIds = allotments.map { it.sanghId }
                                allotments.forEach { allotmentDao?.saveAllotment(it) }
                                if (validIds.isNotEmpty()) {
                                    allotmentDao?.deleteNotIn(validIds)
                                } else {
                                    allotmentDao?.deleteAll()
                                }
                            }
                        }
                    }
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore initialization or sync skipped: ${e.message}")
        }
    }

    private fun getStringField(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            try {
                val value = doc.get(key)
                if (value != null) {
                    if (value is List<*>) {
                        val joined = value.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
                        if (joined.isNotBlank()) return joined
                    }
                    val str = value.toString().trim()
                    if (str.isNotBlank() && str != "[]" && str != "null" && str != "{}") return str
                }
            } catch (e: Exception) {
                // Ignore key lookup error
            }
        }
        return ""
    }

    private fun getTimestampField(doc: DocumentSnapshot): Long {
        try {
            val created = doc.get("createdAt")
            if (created is Number) return created.toLong()
            if (created is com.google.firebase.Timestamp) return created.toDate().time
        } catch (e: Exception) {
            Log.w("FormRepository", "Error reading createdAt: ${e.message}")
        }

        try {
            val ts = doc.get("timestamp")
            if (ts is Number) return ts.toLong()
            if (ts is com.google.firebase.Timestamp) return ts.toDate().time
        } catch (e: Exception) {
            Log.w("FormRepository", "Error reading timestamp: ${e.message}")
        }

        return doc.id.toLongOrNull() ?: System.currentTimeMillis()
    }

    private fun parseDocToEntity(doc: DocumentSnapshot): ParyushanFormEntity {
        val numericId = try {
            doc.getLong("id")
                ?: doc.id.toLongOrNull()
                ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        } catch (e: Exception) {
            doc.id.toLongOrNull() ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        }

        val sanghName = getStringField(doc, "sanghName", "sangh_name", "sangh")
        val sanghAddress = getStringField(doc, "sanghAddress", "sangh_address", "address")

        val cityRaw = getStringField(doc, "cityName", "city_name", "city")
        val districtRaw = getStringField(doc, "district")
        val stateRaw = getStringField(doc, "stateName", "state_name", "state")
        val cityName = if (cityRaw.isNotBlank()) cityRaw else listOf(districtRaw, stateRaw).filter { it.isNotBlank() }.joinToString(", ")
        val stateName = stateRaw

        val contactPerson = getStringField(doc, "contactPersonName", "contactPerson", "contact1", "contact_1", "contact")
        val mobileNumber = getStringField(doc, "whatsappNumber", "mobileNumber", "contact2", "contact_2")

        val contact1 = contactPerson.ifBlank { getStringField(doc, "contact1", "contact_1") }
        val contact2 = mobileNumber.ifBlank { getStringField(doc, "whatsappNumber", "mobileNumber", "contact2", "contact_2") }
        val mulnayakBhagwan = getStringField(doc, "mulnayakBhagwan", "mulnayak_bhagwan", "mulnayak")
        val totalFamilies = getStringField(doc, "totalFamilies", "total_families", "families", "swadhyayisCount")

        val hasOtherSangh = getStringField(doc, "hasOtherSangh", "has_other_sangh").ifBlank { "नहीं" }
        val gacchList = getStringField(doc, "gacchList", "gacch_list", "gacch")
        val pratikramanTradition = getStringField(doc, "pratikramanTradition", "pratikraman_tradition", "tradition")
        val hasMusicianGroup = getStringField(doc, "hasMusicianGroup", "has_musician_group").ifBlank { "नहीं" }
        val callsOutsideMusician = getStringField(doc, "callsOutsideMusician", "calls_outside_musician").ifBlank { "नहीं" }
        val hasPanchPratikramanPerson = getStringField(doc, "hasPanchPratikramanPerson", "has_panch_pratikraman_person").ifBlank { "नहीं" }
        val hasToiletFacility = getStringField(doc, "hasToiletFacility", "has_toilet_facility").ifBlank { "नहीं" }
        val aradhanaSamagriList = getStringField(doc, "aradhanaSamagriList", "aradhanaSamagri", "aradhana_samagri_list", "aradhana_samagri", "samagriList", "samagri", "q15")
        val countRaiPratikraman = getStringField(doc, "countRaiPratikraman", "count_rai_pratikraman")
        val countDevasiPratikraman = getStringField(doc, "countDevasiPratikraman", "count_devasi_pratikraman")
        val countPravachan = getStringField(doc, "countPravachan", "count_pravachan")
        val countSandhyaBhakti = getStringField(doc, "countSandhyaBhakti", "count_sandhya_bhakti")
        val mainTrustees = getStringField(doc, "mainTrustees", "main_trustees", "trustees", "remarks")

        val agreedToTerms = try {
            (doc.get("agreedToTerms") as? Boolean) ?: true
        } catch (e: Exception) { true }

        val isDeleted = try {
            (doc.get("isDeleted") as? Boolean) ?: false
        } catch (e: Exception) { false }

        val deletedAt = try {
            doc.getLong("deletedAt")
        } catch (e: Exception) { null }

        val createdAt = getTimestampField(doc)

        val docIdStr = doc.id

        return ParyushanFormEntity(
            id = numericId,
            firestoreDocId = docIdStr,
            sanghName = sanghName.ifBlank { "श्रीसंघ" },
            sanghAddress = sanghAddress,
            cityName = cityName,
            stateName = stateName,
            contact1 = contact1,
            contact2 = contact2,
            mulnayakBhagwan = mulnayakBhagwan,
            totalFamilies = totalFamilies,
            hasOtherSangh = hasOtherSangh,
            gacchList = gacchList,
            pratikramanTradition = pratikramanTradition,
            hasMusicianGroup = hasMusicianGroup,
            callsOutsideMusician = callsOutsideMusician,
            hasPanchPratikramanPerson = hasPanchPratikramanPerson,
            hasToiletFacility = hasToiletFacility,
            aradhanaSamagriList = aradhanaSamagriList,
            countRaiPratikraman = countRaiPratikraman,
            countDevasiPratikraman = countDevasiPratikraman,
            countPravachan = countPravachan,
            countSandhyaBhakti = countSandhyaBhakti,
            mainTrustees = mainTrustees,
            agreedToTerms = agreedToTerms,
            isDeleted = isDeleted,
            deletedAt = deletedAt,
            createdAt = createdAt
        )
    }

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long {
        val insertedId = formDao.insertForm(form)
        val formWithId = if (form.id == 0L) form.copy(id = insertedId) else form

        // Save to cloud Firestore
        try {
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = formWithId.firestoreDocId.ifBlank { formWithId.id.toString() }
            val docData = hashMapOf(
                "id" to formWithId.id,
                "sanghName" to formWithId.sanghName,
                "sanghAddress" to formWithId.sanghAddress,
                "cityName" to formWithId.cityName,
                "stateName" to formWithId.stateName,
                "contact1" to formWithId.contact1,
                "contact2" to formWithId.contact2,
                "contactPersonName" to formWithId.contact1,
                "whatsappNumber" to formWithId.contact2,
                "mulnayakBhagwan" to formWithId.mulnayakBhagwan,
                "totalFamilies" to formWithId.totalFamilies,
                "hasOtherSangh" to formWithId.hasOtherSangh,
                "gacchList" to formWithId.gacchList,
                "pratikramanTradition" to formWithId.pratikramanTradition,
                "hasMusicianGroup" to formWithId.hasMusicianGroup,
                "callsOutsideMusician" to formWithId.callsOutsideMusician,
                "hasPanchPratikramanPerson" to formWithId.hasPanchPratikramanPerson,
                "hasToiletFacility" to formWithId.hasToiletFacility,
                "aradhanaSamagriList" to formWithId.aradhanaSamagriList,
                "aradhanaSamagri" to formWithId.aradhanaSamagriList,
                "countRaiPratikraman" to formWithId.countRaiPratikraman,
                "countDevasiPratikraman" to formWithId.countDevasiPratikraman,
                "countPravachan" to formWithId.countPravachan,
                "countSandhyaBhakti" to formWithId.countSandhyaBhakti,
                "mainTrustees" to formWithId.mainTrustees,
                "agreedToTerms" to formWithId.agreedToTerms,
                "createdAt" to formWithId.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(targetDocId)
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore save skipped/failed: ${e.message}")
        }

        return insertedId
    }

    suspend fun updateForm(form: ParyushanFormEntity) {
        formDao.updateForm(form)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
            val docData = hashMapOf(
                "id" to form.id,
                "sanghName" to form.sanghName,
                "sanghAddress" to form.sanghAddress,
                "cityName" to form.cityName,
                "stateName" to form.stateName,
                "contact1" to form.contact1,
                "contact2" to form.contact2,
                "contactPersonName" to form.contact1,
                "whatsappNumber" to form.contact2,
                "mulnayakBhagwan" to form.mulnayakBhagwan,
                "totalFamilies" to form.totalFamilies,
                "hasOtherSangh" to form.hasOtherSangh,
                "gacchList" to form.gacchList,
                "pratikramanTradition" to form.pratikramanTradition,
                "hasMusicianGroup" to form.hasMusicianGroup,
                "callsOutsideMusician" to form.callsOutsideMusician,
                "hasPanchPratikramanPerson" to form.hasPanchPratikramanPerson,
                "hasToiletFacility" to form.hasToiletFacility,
                "aradhanaSamagriList" to form.aradhanaSamagriList,
                "aradhanaSamagri" to form.aradhanaSamagriList,
                "countRaiPratikraman" to form.countRaiPratikraman,
                "countDevasiPratikraman" to form.countDevasiPratikraman,
                "countPravachan" to form.countPravachan,
                "countSandhyaBhakti" to form.countSandhyaBhakti,
                "mainTrustees" to form.mainTrustees,
                "agreedToTerms" to form.agreedToTerms,
                "createdAt" to form.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(targetDocId)
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore update skipped/failed: ${e.message}")
        }
    }

    suspend fun softDeleteFormById(id: Long) {
        val now = System.currentTimeMillis()
        formDao.softDeleteForm(id, now)
        try {
            val form = formDao.getFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
                firestore.collection("paryushan_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to true, "deletedAt" to now))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore softDelete update failed: ${e.message}")
        }
    }

    suspend fun restoreFormById(id: Long) {
        formDao.restoreForm(id)
        try {
            val form = formDao.getFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
                firestore.collection("paryushan_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to false, "deletedAt" to null))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore restore update failed: ${e.message}")
        }
    }

    suspend fun purgeOldDeletedForms() {
        val cutoff = System.currentTimeMillis() - (60L * 24 * 60 * 60 * 1000L)
        formDao.purgeOldDeletedForms(cutoff)
    }

    suspend fun deleteFormPermanentlyById(id: Long) {
        deleteFormById(id)
    }

    suspend fun deleteFormById(id: Long) {
        val existing = formDao.getFormAnyById(id)
        val docIdToDelete = existing?.firestoreDocId?.ifBlank { null }
            ?: existing?.id?.toString()
            ?: id.toString()

        formDao.deleteFormPermanentlyById(id)

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("paryushan_forms")
                .document(docIdToDelete)
                .delete()
                .addOnSuccessListener {
                    Log.d("FormRepository", "Successfully deleted doc $docIdToDelete from Firestore")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to delete doc $docIdToDelete from Firestore: ${e.message}")
                }

            if (docIdToDelete != id.toString()) {
                firestore.collection("paryushan_forms")
                    .document(id.toString())
                    .delete()
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete skipped/failed: ${e.message}")
        }
    }

    private fun parseDocToSwadhyaiEntity(doc: DocumentSnapshot): SwadhyaiFormEntity {
        val numericId = try {
            doc.getLong("id")
                ?: doc.id.toLongOrNull()
                ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        } catch (e: Exception) {
            doc.id.toLongOrNull() ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        }

        val fullName = getStringField(doc, "fullName", "full_name", "name", "swadhyaiName", "swadhyai_name")
        val fatherName = getStringField(doc, "fatherName", "father_name", "father")
        val motherName = getStringField(doc, "motherName", "mother_name", "mother")
        val gender = getStringField(doc, "gender", "sex", "genderName", "ling")
        val dob = getStringField(doc, "dob", "dateOfBirth", "date_of_birth", "birthDate")
        val age = try { doc.getLong("age")?.toInt() ?: getStringField(doc, "age").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val bloodGroup = getStringField(doc, "bloodGroup", "blood_group", "bloodgroup")
        val maritalStatus = getStringField(doc, "maritalStatus", "marital_status", "marital")
        val anniversaryDate = getStringField(doc, "anniversaryDate", "anniversary_date", "anniversary")
        val email = getStringField(doc, "email", "emailId", "email_id", "emailAddress")
        val whatsappNo = getStringField(doc, "whatsappNo", "whatsapp_no", "whatsappNumber", "whatsapp", "mobile", "phone")
        val contactNo = getStringField(doc, "contactNo", "contact_no", "contactNumber", "contact")
        val emergencyContactName = getStringField(doc, "emergencyContactName", "emergency_contact_name", "emergencyContactPerson")
        val emergencyContactRelation = getStringField(doc, "emergencyContactRelation", "emergency_contact_relation", "emergencyRelation")
        val emergencyContactNo = getStringField(doc, "emergencyContactNo", "emergency_contact_no", "emergencyNo", "emergency")
        val address = getStringField(doc, "address", "full_address", "residenceAddress")
        val city = getStringField(doc, "city", "cityName", "city_name", "district")
        val pincode = getStringField(doc, "pincode", "pin_code", "pin", "zip")
        val state = getStringField(doc, "state", "stateName", "state_name")
        val nativePlace = getStringField(doc, "nativePlace", "native_place", "moolNiwas", "mool_niwas", "hometown")
        val education = getStringField(doc, "education", "qualification", "degree")
        val workingStatus = getStringField(doc, "workingStatus", "working_status", "occupation", "profession")
        val workDescription = getStringField(doc, "workDescription", "work_description", "occupationDetail", "businessDetail")
        val joiningYear = try { doc.getLong("joiningYear")?.toInt() ?: getStringField(doc, "joiningYear").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val specialities = getStringField(doc, "specialities", "speciality", "specialSkills", "specialityList")
        val religiousLearnings = getStringField(doc, "religiousLearningsFormatted", "religiousLearnings", "religious_learnings", "religiousLearning", "dharmikGyan")
        val anotherGroup = getStringField(doc, "anotherGroup", "another_group", "otherGroup", "groupName")
        val postInGroup = getStringField(doc, "postInGroup", "post_in_group", "postName", "designation")
        val paryushanCount = try { doc.getLong("paryushanCount")?.toInt() ?: getStringField(doc, "paryushanCount").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val dailyRoutineActivities = getStringField(doc, "dailyRoutineActivities", "daily_routine_activities", "dailyRoutineActivity", "dailyActivities")
        val lifetimeTapasya = getStringField(doc, "lifetimeTapasya", "lifetime_tapasya", "lifetimeTyag", "tapasya")
        val paryushanWillingness = getStringField(doc, "paryushanWillingness", "paryushan_willingness", "availableForParyushan", "willingness", "travelWillingness")
        val acceptedRules = try { (doc.get("acceptedRules") as? Boolean) ?: true } catch (e: Exception) { true }
        val remarks = getStringField(doc, "remarks", "remark", "comments", "additionalInfo", "notes")

        val isDeleted = try { (doc.get("isDeleted") as? Boolean) ?: false } catch (e: Exception) { false }
        val deletedAt = try { doc.getLong("deletedAt") } catch (e: Exception) { null }
        val createdAt = getTimestampField(doc)

        return SwadhyaiFormEntity(
            id = numericId,
            firestoreDocId = doc.id,
            fullName = fullName,
            fatherName = fatherName,
            motherName = motherName,
            gender = gender,
            dob = dob,
            age = age,
            bloodGroup = bloodGroup,
            maritalStatus = maritalStatus,
            anniversaryDate = anniversaryDate,
            email = email,
            whatsappNo = whatsappNo,
            contactNo = contactNo,
            emergencyContactName = emergencyContactName,
            emergencyContactRelation = emergencyContactRelation,
            emergencyContactNo = emergencyContactNo,
            address = address,
            city = city,
            pincode = pincode,
            state = state,
            nativePlace = nativePlace,
            education = education,
            workingStatus = workingStatus,
            workDescription = workDescription,
            joiningYear = joiningYear,
            specialities = specialities,
            religiousLearnings = religiousLearnings,
            anotherGroup = anotherGroup,
            postInGroup = postInGroup,
            paryushanCount = paryushanCount,
            dailyRoutineActivities = dailyRoutineActivities,
            lifetimeTapasya = lifetimeTapasya,
            paryushanWillingness = paryushanWillingness,
            acceptedRules = acceptedRules,
            remarks = remarks,
            isDeleted = isDeleted,
            deletedAt = deletedAt,
            createdAt = createdAt
        )
    }

    suspend fun deleteSwadhyaiFormById(id: Long) {
        val existing = swadhyaiDao.getSwadhyaiFormAnyById(id)
        val docIdToDelete = existing?.firestoreDocId?.ifBlank { null }
            ?: existing?.id?.toString()
            ?: id.toString()

        swadhyaiDao.deleteFormPermanentlyById(id)

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("swadhyai_forms")
                .document(docIdToDelete)
                .delete()
                .addOnSuccessListener {
                    Log.d("FormRepository", "Successfully deleted doc $docIdToDelete from swadhyai_forms")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to delete doc $docIdToDelete from swadhyai_forms: ${e.message}")
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai delete skipped/failed: ${e.message}")
        }
    }

    suspend fun saveAllotment(allotment: AllotmentEntity) {
        if (allotment.swadhyaiIds.isBlank()) {
            deleteAllotment(allotment.sanghId)
        } else {
            allotmentDao?.saveAllotment(allotment)
            try {
                val firestore = FirebaseFirestore.getInstance()
                val data = hashMapOf(
                    "sanghId" to allotment.sanghId,
                    "sanghName" to allotment.sanghName,
                    "cityName" to allotment.cityName,
                    "stateName" to allotment.stateName,
                    "swadhyaiIds" to allotment.swadhyaiIds,
                    "updatedAt" to allotment.updatedAt
                )
                firestore.collection("sangh_allotments")
                    .document(allotment.sanghId.toString())
                    .set(data)
            } catch (e: Exception) {
                Log.w("FormRepository", "Firestore save allotment failed: ${e.message}")
            }
        }
    }

    suspend fun deleteAllotment(sanghId: Long) {
        allotmentDao?.deleteAllotment(sanghId)
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("sangh_allotments")
                .document(sanghId.toString())
                .delete()
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete allotment failed: ${e.message}")
        }
    }

    suspend fun prepopulateIfEmpty() {
        // No sample forms pre-populated by default so the list starts clean
    }
}


