package com.example.data

import android.util.Log
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class FormRepository(private val formDao: FormDao) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()

    private var firestoreListener: ListenerRegistration? = null

    init {
        startCloudSync()
        refreshCloudData()
    }

    fun refreshCloudData() {
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("paryushan_forms").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val forms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing doc: ${e.message}")
                                null
                            }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            forms.forEach { formDao.insertForm(it) }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch: ${e.message}")
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Error in refreshCloudData: ${e.message}")
        }
    }

    private fun startCloudSync() {
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestoreListener = firestore.collection("paryushan_forms")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("FormRepository", "Firestore listen failed: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val forms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing Firestore doc: ${e.message}")
                                null
                            }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            forms.forEach { formDao.insertForm(it) }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore initialization or sync skipped: ${e.message}")
        }
    }

    private fun getStringField(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            val value = doc.get(key)
            if (value != null) {
                val str = value.toString().trim()
                if (str.isNotBlank()) return str
            }
        }
        return ""
    }

    private fun getTimestampField(doc: DocumentSnapshot): Long {
        doc.getLong("createdAt")?.let { return it }
        doc.getTimestamp("createdAt")?.let { return it.toDate().time }
        doc.getTimestamp("timestamp")?.let { return it.toDate().time }
        doc.getLong("timestamp")?.let { return it }
        return System.currentTimeMillis()
    }

    private fun parseDocToEntity(doc: DocumentSnapshot): ParyushanFormEntity {
        val numericId = doc.getLong("id")
            ?: doc.id.toLongOrNull()
            ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)

        val sanghName = getStringField(doc, "sanghName", "sangh_name", "sangh")
        val sanghAddress = getStringField(doc, "sanghAddress", "sangh_address", "address")

        val cityRaw = getStringField(doc, "cityName", "city_name", "city")
        val districtRaw = getStringField(doc, "district")
        val stateRaw = getStringField(doc, "state")
        val cityName = if (cityRaw.isNotBlank()) cityRaw else listOf(districtRaw, stateRaw).filter { it.isNotBlank() }.joinToString(", ")

        val contact1 = getStringField(doc, "contact1", "contact_1", "contactPerson", "contact")
        val mobileNumber = getStringField(doc, "mobileNumber", "whatsappNumber")
        val fullContact1 = if (contact1.isNotBlank() && mobileNumber.isNotBlank()) "$contact1 ($mobileNumber)" else contact1.ifBlank { mobileNumber }

        val contact2 = getStringField(doc, "contact2", "contact_2")
        val mulnayakBhagwan = getStringField(doc, "mulnayakBhagwan", "mulnayak_bhagwan", "mulnayak")
        val totalFamilies = getStringField(doc, "totalFamilies", "total_families", "families", "swadhyayisCount")

        val hasOtherSangh = getStringField(doc, "hasOtherSangh", "has_other_sangh").ifBlank { "नहीं" }
        val gacchList = getStringField(doc, "gacchList", "gacch_list", "gacch")
        val pratikramanTradition = getStringField(doc, "pratikramanTradition", "pratikraman_tradition", "tradition")
        val hasMusicianGroup = getStringField(doc, "hasMusicianGroup", "has_musician_group").ifBlank { "नहीं" }
        val callsOutsideMusician = getStringField(doc, "callsOutsideMusician", "calls_outside_musician").ifBlank { "नहीं" }
        val hasPanchPratikramanPerson = getStringField(doc, "hasPanchPratikramanPerson", "has_panch_pratikraman_person").ifBlank { "नहीं" }
        val hasToiletFacility = getStringField(doc, "hasToiletFacility", "has_toilet_facility").ifBlank { "नहीं" }
        val aradhanaSamagriList = getStringField(doc, "aradhanaSamagriList", "aradhana_samagri_list", "aradhana_samagri")
        val countRaiPratikraman = getStringField(doc, "countRaiPratikraman", "count_rai_pratikraman")
        val countDevasiPratikraman = getStringField(doc, "countDevasiPratikraman", "count_devasi_pratikraman")
        val countPravachan = getStringField(doc, "countPravachan", "count_pravachan")
        val countSandhyaBhakti = getStringField(doc, "countSandhyaBhakti", "count_sandhya_bhakti")
        val mainTrustees = getStringField(doc, "mainTrustees", "main_trustees", "trustees", "remarks")

        val agreedToTerms = (doc.get("agreedToTerms") as? Boolean) ?: true
        val createdAt = getTimestampField(doc)

        return ParyushanFormEntity(
            id = numericId,
            sanghName = sanghName,
            sanghAddress = sanghAddress,
            cityName = cityName,
            contact1 = fullContact1,
            contact2 = contact2,
            mulnayakBhagwan = mulnayakBhagwan,
            totalFamilies = totalFamilies,
            hasOtherSangh = hasOtherSangh,
            gacchList = gacchList,
            pratikramanTradition = pratikramanTradition,
            hasMusicianGroup = hasMusicianGroup,
            callsOutsideMusician = callsOutsideMusician,
            hasPanchPratikramanPerson = hasPanchPratikramanPerson,
            hasToiletFacility = hasToiletFacility,
            aradhanaSamagriList = aradhanaSamagriList,
            countRaiPratikraman = countRaiPratikraman,
            countDevasiPratikraman = countDevasiPratikraman,
            countPravachan = countPravachan,
            countSandhyaBhakti = countSandhyaBhakti,
            mainTrustees = mainTrustees,
            agreedToTerms = agreedToTerms,
            createdAt = createdAt
        )
    }

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long {
        val insertedId = formDao.insertForm(form)
        val formWithId = if (form.id == 0L) form.copy(id = insertedId) else form

        // Save to cloud Firestore
        try {
            val firestore = FirebaseFirestore.getInstance()
            val docData = hashMapOf(
                "id" to formWithId.id,
                "sanghName" to formWithId.sanghName,
                "sanghAddress" to formWithId.sanghAddress,
                "cityName" to formWithId.cityName,
                "contact1" to formWithId.contact1,
                "contact2" to formWithId.contact2,
                "mulnayakBhagwan" to formWithId.mulnayakBhagwan,
                "totalFamilies" to formWithId.totalFamilies,
                "hasOtherSangh" to formWithId.hasOtherSangh,
                "gacchList" to formWithId.gacchList,
                "pratikramanTradition" to formWithId.pratikramanTradition,
                "hasMusicianGroup" to formWithId.hasMusicianGroup,
                "callsOutsideMusician" to formWithId.callsOutsideMusician,
                "hasPanchPratikramanPerson" to formWithId.hasPanchPratikramanPerson,
                "hasToiletFacility" to formWithId.hasToiletFacility,
                "aradhanaSamagriList" to formWithId.aradhanaSamagriList,
                "countRaiPratikraman" to formWithId.countRaiPratikraman,
                "countDevasiPratikraman" to formWithId.countDevasiPratikraman,
                "countPravachan" to formWithId.countPravachan,
                "countSandhyaBhakti" to formWithId.countSandhyaBhakti,
                "mainTrustees" to formWithId.mainTrustees,
                "agreedToTerms" to formWithId.agreedToTerms,
                "createdAt" to formWithId.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(formWithId.id.toString())
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore save skipped/failed: ${e.message}")
        }

        return insertedId
    }

    suspend fun updateForm(form: ParyushanFormEntity) {
        formDao.updateForm(form)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val docData = hashMapOf(
                "id" to form.id,
                "sanghName" to form.sanghName,
                "sanghAddress" to form.sanghAddress,
                "cityName" to form.cityName,
                "contact1" to form.contact1,
                "contact2" to form.contact2,
                "mulnayakBhagwan" to form.mulnayakBhagwan,
                "totalFamilies" to form.totalFamilies,
                "hasOtherSangh" to form.hasOtherSangh,
                "gacchList" to form.gacchList,
                "pratikramanTradition" to form.pratikramanTradition,
                "hasMusicianGroup" to form.hasMusicianGroup,
                "callsOutsideMusician" to form.callsOutsideMusician,
                "hasPanchPratikramanPerson" to form.hasPanchPratikramanPerson,
                "hasToiletFacility" to form.hasToiletFacility,
                "aradhanaSamagriList" to form.aradhanaSamagriList,
                "countRaiPratikraman" to form.countRaiPratikraman,
                "countDevasiPratikraman" to form.countDevasiPratikraman,
                "countPravachan" to form.countPravachan,
                "countSandhyaBhakti" to form.countSandhyaBhakti,
                "mainTrustees" to form.mainTrustees,
                "agreedToTerms" to form.agreedToTerms,
                "createdAt" to form.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(form.id.toString())
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore update skipped/failed: ${e.message}")
        }
    }

    suspend fun deleteFormById(id: Long) {
        formDao.deleteFormById(id)
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("paryushan_forms")
                .document(id.toString())
                .delete()
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete skipped/failed: ${e.message}")
        }
    }

    suspend fun prepopulateIfEmpty() {
        // No sample forms pre-populated by default so the list starts clean
    }
}


