package com.example.data

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class FormRepository(private val formDao: FormDao) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()

    private var firestoreListener: ListenerRegistration? = null

    init {
        startCloudSync()
    }

    private fun startCloudSync() {
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestoreListener = firestore.collection("paryushan_forms")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("FormRepository", "Firestore listen failed: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val forms = snapshot.documents.mapNotNull { doc ->
                            try {
                                val id = doc.getLong("id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                ParyushanFormEntity(
                                    id = id,
                                    sanghName = doc.getString("sanghName") ?: "",
                                    sanghAddress = doc.getString("sanghAddress") ?: "",
                                    cityName = doc.getString("cityName") ?: "",
                                    contact1 = doc.getString("contact1") ?: "",
                                    contact2 = doc.getString("contact2") ?: "",
                                    mulnayakBhagwan = doc.getString("mulnayakBhagwan") ?: "",
                                    totalFamilies = doc.getString("totalFamilies") ?: "",
                                    hasOtherSangh = doc.getString("hasOtherSangh") ?: "नहीं",
                                    gacchList = doc.getString("gacchList") ?: "",
                                    pratikramanTradition = doc.getString("pratikramanTradition") ?: "",
                                    hasMusicianGroup = doc.getString("hasMusicianGroup") ?: "नहीं",
                                    callsOutsideMusician = doc.getString("callsOutsideMusician") ?: "नहीं",
                                    hasPanchPratikramanPerson = doc.getString("hasPanchPratikramanPerson") ?: "नहीं",
                                    hasToiletFacility = doc.getString("hasToiletFacility") ?: "नहीं",
                                    aradhanaSamagriList = doc.getString("aradhanaSamagriList") ?: "",
                                    countRaiPratikraman = doc.getString("countRaiPratikraman") ?: "",
                                    countDevasiPratikraman = doc.getString("countDevasiPratikraman") ?: "",
                                    countPravachan = doc.getString("countPravachan") ?: "",
                                    countSandhyaBhakti = doc.getString("countSandhyaBhakti") ?: "",
                                    mainTrustees = doc.getString("mainTrustees") ?: "",
                                    agreedToTerms = doc.getBoolean("agreedToTerms") ?: true,
                                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                                )
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing Firestore doc: ${e.message}")
                                null
                            }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            forms.forEach { formDao.insertForm(it) }
                        }
                    }
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore initialization or sync skipped: ${e.message}")
        }
    }

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long {
        val insertedId = formDao.insertForm(form)
        val formWithId = if (form.id == 0L) form.copy(id = insertedId) else form

        // Save to cloud Firestore
        try {
            val firestore = FirebaseFirestore.getInstance()
            val docData = hashMapOf(
                "id" to formWithId.id,
                "sanghName" to formWithId.sanghName,
                "sanghAddress" to formWithId.sanghAddress,
                "cityName" to formWithId.cityName,
                "contact1" to formWithId.contact1,
                "contact2" to formWithId.contact2,
                "mulnayakBhagwan" to formWithId.mulnayakBhagwan,
                "totalFamilies" to formWithId.totalFamilies,
                "hasOtherSangh" to formWithId.hasOtherSangh,
                "gacchList" to formWithId.gacchList,
                "pratikramanTradition" to formWithId.pratikramanTradition,
                "hasMusicianGroup" to formWithId.hasMusicianGroup,
                "callsOutsideMusician" to formWithId.callsOutsideMusician,
                "hasPanchPratikramanPerson" to formWithId.hasPanchPratikramanPerson,
                "hasToiletFacility" to formWithId.hasToiletFacility,
                "aradhanaSamagriList" to formWithId.aradhanaSamagriList,
                "countRaiPratikraman" to formWithId.countRaiPratikraman,
                "countDevasiPratikraman" to formWithId.countDevasiPratikraman,
                "countPravachan" to formWithId.countPravachan,
                "countSandhyaBhakti" to formWithId.countSandhyaBhakti,
                "mainTrustees" to formWithId.mainTrustees,
                "agreedToTerms" to formWithId.agreedToTerms,
                "createdAt" to formWithId.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(formWithId.id.toString())
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore save skipped/failed: ${e.message}")
        }

        return insertedId
    }

    suspend fun updateForm(form: ParyushanFormEntity) {
        formDao.updateForm(form)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val docData = hashMapOf(
                "id" to form.id,
                "sanghName" to form.sanghName,
                "sanghAddress" to form.sanghAddress,
                "cityName" to form.cityName,
                "contact1" to form.contact1,
                "contact2" to form.contact2,
                "mulnayakBhagwan" to form.mulnayakBhagwan,
                "totalFamilies" to form.totalFamilies,
                "hasOtherSangh" to form.hasOtherSangh,
                "gacchList" to form.gacchList,
                "pratikramanTradition" to form.pratikramanTradition,
                "hasMusicianGroup" to form.hasMusicianGroup,
                "callsOutsideMusician" to form.callsOutsideMusician,
                "hasPanchPratikramanPerson" to form.hasPanchPratikramanPerson,
                "hasToiletFacility" to form.hasToiletFacility,
                "aradhanaSamagriList" to form.aradhanaSamagriList,
                "countRaiPratikraman" to form.countRaiPratikraman,
                "countDevasiPratikraman" to form.countDevasiPratikraman,
                "countPravachan" to form.countPravachan,
                "countSandhyaBhakti" to form.countSandhyaBhakti,
                "mainTrustees" to form.mainTrustees,
                "agreedToTerms" to form.agreedToTerms,
                "createdAt" to form.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(form.id.toString())
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore update skipped/failed: ${e.message}")
        }
    }

    suspend fun deleteFormById(id: Long) {
        formDao.deleteFormById(id)
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("paryushan_forms")
                .document(id.toString())
                .delete()
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete skipped/failed: ${e.message}")
        }
    }

    suspend fun prepopulateIfEmpty() {
        // No sample forms pre-populated by default so the list starts clean
    }
}

