package com.example.data

import kotlinx.coroutines.flow.Flow

class FormRepository(private val formDao: FormDao) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long = formDao.insertForm(form)

    suspend fun updateForm(form: ParyushanFormEntity) = formDao.updateForm(form)

    suspend fun deleteFormById(id: Long) = formDao.deleteFormById(id)

    suspend fun prepopulateIfEmpty() {
        if (formDao.getFormCount() == 0) {
            val sampleForm1 = ParyushanFormEntity(
                sanghName = "श्री श्वेतांबर मूर्तिपूजक जैन संघ",
                sanghAddress = "स्टेशन रोड, महावीर मार्ग, जैन देरासर के पास",
                cityName = "अहमदाबाद (गुजरात)",
                contact1 = "कांतिलाल संघवी (अध्यक्ष) - 9825012345",
                contact2 = "प्रवीणचंद्र शाह (सचिव) - 9426067890",
                mulnayakBhagwan = "श्री शंखेश्वर पार्श्वनाथ भगवान",
                totalFamilies = "120",
                hasOtherSangh = "हाँ",
                gacchList = "तपागच्छ",
                pratikramanTradition = "तपागच्छ",
                hasMusicianGroup = "हाँ",
                callsOutsideMusician = "नहीं",
                hasPanchPratikramanPerson = "हाँ",
                hasToiletFacility = "हाँ",
                aradhanaSamagriList = "आचार्य भगवान - स्थापना जी (महिलाओं/पुरुषों हेतु), कल्पसूत्र, बारसासूत्र",
                countRaiPratikraman = "51-100 या अधिक",
                countDevasiPratikraman = "51-100 या अधिक",
                countPravachan = "51-100 या अधिक",
                countSandhyaBhakti = "51-100 या अधिक",
                mainTrustees = "१. रमणिकलाल शाह (9824011223)\n२. हिम्मतमल मेहता (9426533445)\n३. धीरजलाल दोशी (9898055667)",
                agreedToTerms = true
            )

            val sampleForm2 = ParyushanFormEntity(
                sanghName = "श्री ऋषभदेव जैन श्वेतांबर संघ",
                sanghAddress = "जैन देरासर स्ट्रीट, गांधी चौक",
                cityName = "पाली (राजस्थान)",
                contact1 = "रमेशभाई जैन (ट्रस्टी) - 9829011122",
                contact2 = "विमलकुमार जैन (सह-सचिव) - 9414033344",
                mulnayakBhagwan = "श्री आदिनाथ भगवान",
                totalFamilies = "45",
                hasOtherSangh = "नहीं",
                gacchList = "तपागच्छ, खतरगच्छ",
                pratikramanTradition = "तपागच्छ",
                hasMusicianGroup = "नहीं",
                callsOutsideMusician = "हाँ",
                hasPanchPratikramanPerson = "हाँ",
                hasToiletFacility = "हाँ",
                aradhanaSamagriList = "कल्पसूत्र, बारसासूत्र",
                countRaiPratikraman = "26-50",
                countDevasiPratikraman = "26-50",
                countPravachan = "26-50",
                countSandhyaBhakti = "51-100 या अधिक",
                mainTrustees = "१. संपतलाल बाफना (9829144556)\n२. रतनलाल चोरड़िया (9414277889)\n३. ताराचंद लोढ़ा (9829300112)",
                agreedToTerms = true
            )

            formDao.insertForm(sampleForm1)
            formDao.insertForm(sampleForm2)
        }
    }
}
