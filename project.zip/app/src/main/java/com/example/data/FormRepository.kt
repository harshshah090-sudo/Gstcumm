package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class FormRepository(
    private val formDao: FormDao,
    private val swadhyaiDao: SwadhyaiDao,
    private val allotmentDao: AllotmentDao? = null,
    private val fundDao: FundDao? = null,
    private val fundPersonDao: FundPersonDao? = null,
    private val panchangDao: PanchangDao? = null,
    private val registrationHistoryDao: RegistrationHistoryDao? = null,
    private val timelineDao: TimelineDao? = null,
    private val context: Context? = null
) {
    val allForms: Flow<List<ParyushanFormEntity>> = formDao.getAllForms()
    val deletedForms: Flow<List<ParyushanFormEntity>> = formDao.getDeletedForms()
    val allSwadhyaiForms: Flow<List<SwadhyaiFormEntity>> = swadhyaiDao.getAllSwadhyaiForms()
    val deletedSwadhyaiForms: Flow<List<SwadhyaiFormEntity>> = swadhyaiDao.getDeletedSwadhyaiForms()
    val allAllotments: Flow<List<AllotmentEntity>> = allotmentDao?.getAllAllotments() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allFundTransactions: Flow<List<FundTransactionEntity>> = fundDao?.getAllTransactions() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val deletedFundTransactions: Flow<List<FundTransactionEntity>> = fundDao?.getDeletedTransactions() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allFundPersons: Flow<List<FundPersonEntity>> = fundPersonDao?.getAllPersons() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allPanchangEvents: Flow<List<PanchangEventEntity>> = panchangDao?.getAllEvents() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allRegistrationHistories: Flow<List<RegistrationHistoryEntity>> = registrationHistoryDao?.getAllHistories() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    val allTimelinePosts: Flow<List<TimelinePostEntity>> = timelineDao?.getAllPosts() ?: kotlinx.coroutines.flow.flowOf(emptyList())

    private var firestoreListener: ListenerRegistration? = null
    private var swadhyaiFirestoreListener: ListenerRegistration? = null
    private var configListener: ListenerRegistration? = null
    private var panchangConfigListener: ListenerRegistration? = null
    private var fundFirestoreListener: ListenerRegistration? = null
    private var personFirestoreListener: ListenerRegistration? = null
    private var allotmentFirestoreListener: ListenerRegistration? = null
    private var historyFirestoreListener: ListenerRegistration? = null
    private var panchangEventsFirestoreListener: ListenerRegistration? = null
    private var timelineFirestoreListener: ListenerRegistration? = null

    private val fundTxSyncMutex = Mutex()
    private val fundPersonSyncMutex = Mutex()

    private val prefs = context?.getSharedPreferences("app_settings", Context.MODE_PRIVATE)

    fun getPanchangDeletedDates(): Set<String> {
        return prefs?.getStringSet("panchang_deleted_dates_set", emptySet()) ?: emptySet()
    }

    fun markPanchangDateDeleted(dateString: String) {
        val cleanDate = dateString.trim()
        if (cleanDate.isBlank()) return
        val currentSet = (prefs?.getStringSet("panchang_deleted_dates_set", emptySet()) ?: emptySet()).toMutableSet()
        currentSet.add(cleanDate)

        val userEditedSet = (prefs?.getStringSet("panchang_user_edited_dates_set", emptySet()) ?: emptySet()).toMutableSet()
        if (userEditedSet.contains(cleanDate)) {
            userEditedSet.remove(cleanDate)
        }

        prefs?.edit()
            ?.putStringSet("panchang_deleted_dates_set", currentSet)
            ?.putStringSet("panchang_user_edited_dates_set", userEditedSet)
            ?.remove("panchang_custom_event_$cleanDate")
            ?.putLong("panchang_local_update_$cleanDate", System.currentTimeMillis())
            ?.apply()
    }

    fun markPanchangDateSaved(dateString: String) {
        val cleanDate = dateString.trim()
        if (cleanDate.isBlank()) return
        val currentSet = (prefs?.getStringSet("panchang_deleted_dates_set", emptySet()) ?: emptySet()).toMutableSet()
        if (currentSet.contains(cleanDate)) {
            currentSet.remove(cleanDate)
            prefs?.edit()?.putStringSet("panchang_deleted_dates_set", currentSet)?.apply()
        }
        prefs?.edit()
            ?.putLong("panchang_local_update_$cleanDate", System.currentTimeMillis())
            ?.apply()
    }

    fun markPanchangDateUserEdited(dateString: String, event: PanchangEventEntity, timestamp: Long) {
        val cleanDate = dateString.trim()
        if (cleanDate.isBlank()) return
        val userEditedSet = (prefs?.getStringSet("panchang_user_edited_dates_set", emptySet()) ?: emptySet()).toMutableSet()
        userEditedSet.add(cleanDate)

        val deletedSet = (prefs?.getStringSet("panchang_deleted_dates_set", emptySet()) ?: emptySet()).toMutableSet()
        if (deletedSet.contains(cleanDate)) {
            deletedSet.remove(cleanDate)
        }

        try {
            val json = org.json.JSONObject().apply {
                put("dateString", cleanDate)
                put("dayOfWeek", event.dayOfWeek)
                put("tithi", event.tithi)
                put("isImportantTithi", event.isImportantTithi)
                put("kalyanaks", event.kalyanaks)
                put("parvasAndEvents", event.parvasAndEvents)
                put("sunriseTime", event.sunriseTime)
                put("sunsetTime", event.sunsetTime)
                put("navkarsiTime", event.navkarsiTime)
                put("notes", event.notes)
                put("userEditedAt", timestamp)
            }
            prefs?.edit()
                ?.putStringSet("panchang_user_edited_dates_set", userEditedSet)
                ?.putStringSet("panchang_deleted_dates_set", deletedSet)
                ?.putString("panchang_custom_event_$cleanDate", json.toString())
                ?.putLong("panchang_local_update_$cleanDate", timestamp)
                ?.apply()
        } catch (e: Exception) {
            Log.e("FormRepository", "Failed to cache user edited panchang date: ${e.message}")
            prefs?.edit()
                ?.putStringSet("panchang_user_edited_dates_set", userEditedSet)
                ?.putStringSet("panchang_deleted_dates_set", deletedSet)
                ?.putLong("panchang_local_update_$cleanDate", timestamp)
                ?.apply()
        }
    }

    fun isPanchangDateUserEdited(dateString: String): Boolean {
        val cleanDate = dateString.trim()
        return prefs?.getStringSet("panchang_user_edited_dates_set", emptySet())?.contains(cleanDate) ?: false
    }

    fun getPanchangUserEditedDates(): Set<String> {
        return prefs?.getStringSet("panchang_user_edited_dates_set", emptySet()) ?: emptySet()
    }

    fun getCustomPanchangEvent(dateString: String): PanchangEventEntity? {
        val cleanDate = dateString.trim()
        val jsonStr = prefs?.getString("panchang_custom_event_$cleanDate", null) ?: return null
        return try {
            val obj = org.json.JSONObject(jsonStr)
            PanchangEventEntity(
                id = 0L,
                dateString = cleanDate,
                dayOfWeek = obj.optString("dayOfWeek", ""),
                tithi = obj.optString("tithi", ""),
                isImportantTithi = obj.optBoolean("isImportantTithi", false),
                kalyanaks = obj.optString("kalyanaks", ""),
                parvasAndEvents = obj.optString("parvasAndEvents", ""),
                sunriseTime = obj.optString("sunriseTime", ""),
                sunsetTime = obj.optString("sunsetTime", ""),
                navkarsiTime = obj.optString("navkarsiTime", ""),
                notes = obj.optString("notes", "")
            )
        } catch (_: Exception) {
            null
        }
    }

    suspend fun reapplyUserCustomEdits() {
        if (panchangDao == null) return
        val editedDates = getPanchangUserEditedDates()
        if (editedDates.isEmpty()) return
        for (date in editedDates) {
            val customEvent = getCustomPanchangEvent(date)
            if (customEvent != null) {
                panchangDao.deleteEventByDate(date)
                panchangDao.insertEvent(customEvent)
            }
        }
    }

    fun getPanchangLocalDateUpdateTimestamp(dateString: String): Long {
        val cleanDate = dateString.trim()
        return prefs?.getLong("panchang_local_update_$cleanDate", 0L) ?: 0L
    }

    val hiddenCalendarEventNames = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(
        prefs?.getStringSet("hidden_calendar_event_names", prefs?.getStringSet("hidden_event_names", emptySet()) ?: emptySet()) ?: emptySet()
    )
    val hiddenRepoEventNames = kotlinx.coroutines.flow.MutableStateFlow<Set<String>>(
        prefs?.getStringSet("hidden_repo_event_names", emptySet()) ?: emptySet()
    )
    val hiddenEventNames = hiddenCalendarEventNames

    val isSanghRegistrationStopped = kotlinx.coroutines.flow.MutableStateFlow<Boolean>(
        prefs?.getBoolean("is_sangh_registration_stopped", false) ?: false
    )
    val isSyncing = kotlinx.coroutines.flow.MutableStateFlow<Boolean>(false)

    init {
        CoroutineScope(Dispatchers.IO).launch {
            reapplyUserCustomEdits()
        }
        ensureAuthAndSync()
    }

    private fun ensureAuthAndSync() {
        try {
            val auth = FirebaseAuth.getInstance()
            if (auth.currentUser == null) {
                auth.signInAnonymously()
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Log.d("FormRepository", "Signed in anonymously to Firebase")
                        } else {
                            Log.w("FormRepository", "Anonymous auth failed: ${task.exception?.message}")
                        }
                        startCloudSync()
                        refreshCloudData()
                    }
            } else {
                startCloudSync()
                refreshCloudData()
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "FirebaseAuth init error: ${e.message}")
            startCloudSync()
            refreshCloudData()
        }
    }

    fun refreshCloudData() {
        try {
            val firestore = FirebaseFirestore.getInstance()

            firestore.collection("paryushan_forms").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val forms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing doc: ${e.message}")
                                null
                            }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            val localSoftDeletedIds = formDao.getSoftDeletedIds().toSet()
                            val validIds = forms.map { it.id }
                            forms.forEach { cloudForm ->
                                val formToInsert = if (localSoftDeletedIds.contains(cloudForm.id) && !cloudForm.isDeleted) {
                                    cloudForm.copy(isDeleted = true)
                                } else {
                                    cloudForm
                                }
                                formDao.insertForm(formToInsert)
                            }
                            if (validIds.isNotEmpty()) {
                                formDao.deleteFormsNotIn(validIds)
                            }
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for paryushan_forms: ${e.message}")
                }

            firestore.collection("swadhyai_forms").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val swadhyaiForms = snapshot.documents.mapNotNull { doc ->
                            try {
                                parseDocToSwadhyaiEntity(doc)
                            } catch (e: Exception) {
                                Log.e("FormRepository", "Error parsing swadhyai doc ${doc.id}: ${e.message}")
                                null
                            }
                        }
                        Log.d("FormRepository", "Fetched ${swadhyaiForms.size} swadhyai forms manually")
                        CoroutineScope(Dispatchers.IO).launch {
                            swadhyaiDao.deleteBlankForms()
                            val validIds = swadhyaiForms.map { it.id }
                            swadhyaiForms.forEach { cloudForm ->
                                if (cloudForm.fullName.isNotBlank()) {
                                    swadhyaiDao.insertForm(cloudForm)
                                }
                            }
                            if (validIds.isNotEmpty()) {
                                swadhyaiDao.deleteFormsNotIn(validIds)
                            }
                            swadhyaiDao.deleteBlankForms()
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for swadhyai_forms: ${e.message}")
                }
            firestore.collection("sangh_allotments").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        val allotments = snapshot.documents.mapNotNull { doc ->
                            try {
                                val sId = doc.getLong("sanghId") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                val sName = doc.getString("sanghName") ?: ""
                                val cName = doc.getString("cityName") ?: ""
                                val stName = doc.getString("stateName") ?: ""
                                val swIds = doc.getString("swadhyaiIds") ?: ""
                                val uAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                                AllotmentEntity(sId, sName, cName, stName, swIds, uAt)
                            } catch (e: Exception) { null }
                        }
                        CoroutineScope(Dispatchers.IO).launch {
                            val validIds = allotments.map { it.sanghId }
                            allotments.forEach { allotmentDao?.saveAllotment(it) }
                            if (validIds.isNotEmpty()) {
                                allotmentDao?.deleteNotIn(validIds)
                            }
                        }
                    }
                }

            firestore.collection("fund_transactions").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            syncFundTransactionsToLocal(snapshot.documents)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for fund_transactions: ${e.message}")
                }

            firestore.collection("fund_persons").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null) {
                        CoroutineScope(Dispatchers.IO).launch {
                            syncFundPersonsToLocal(snapshot.documents)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for fund_persons: ${e.message}")
                }

            firestore.collection("panchang_events").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && !snapshot.isEmpty) {
                        CoroutineScope(Dispatchers.IO).launch {
                            processCloudPanchangSnapshot(snapshot.documents)
                        }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for panchang_events: ${e.message}")
                }

            firestore.collection("app_config").document("sangh_registration").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && snapshot.exists() && snapshot.contains("isStopped")) {
                        val stopped = snapshot.getBoolean("isStopped") ?: false
                        isSanghRegistrationStopped.value = stopped
                        prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()
                    }
                }

            firestore.collection("app_config").document("panchang_event_visibility").get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot != null && snapshot.exists()) {
                        @Suppress("UNCHECKED_CAST")
                        val calList = (snapshot.get("hiddenCalendarEventNames") as? List<String>)
                            ?: (snapshot.get("hiddenEventNames") as? List<String>)
                            ?: emptyList()
                        val calSet = calList.toSet()
                        hiddenCalendarEventNames.value = calSet
                        prefs?.edit()?.putStringSet("hidden_calendar_event_names", calSet)?.putStringSet("hidden_event_names", calSet)?.apply()

                        @Suppress("UNCHECKED_CAST")
                        val repoList = (snapshot.get("hiddenRepoEventNames") as? List<String>) ?: emptyList()
                        val repoSet = repoList.toSet()
                        hiddenRepoEventNames.value = repoSet
                        prefs?.edit()?.putStringSet("hidden_repo_event_names", repoSet)?.apply()
                        Log.d("FormRepository", "Fetched panchang_event_visibility from cloud: cal=${calSet.size}, repo=${repoSet.size}")
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed manual cloud fetch for panchang_event_visibility: ${e.message}")
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Error in refreshCloudData: ${e.message}")
        }
    }

    fun setSanghRegistrationStopped(stopped: Boolean) {
        isSanghRegistrationStopped.value = stopped
        prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()

        try {
            val firestore = FirebaseFirestore.getInstance()
            val data = mapOf(
                "isStopped" to stopped,
                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
            )
            firestore.collection("app_config").document("sangh_registration")
                .set(data, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("FormRepository", "Updated sangh_registration isStopped to $stopped")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to update sangh_registration: ${e.message}")
                }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error updating sangh_registration status: ${e.message}")
        }
    }

    private suspend fun syncFundTransactionsToLocal(documents: List<DocumentSnapshot>) {
        if (fundDao == null) return

        isSyncing.value = true
        try {
            fundTxSyncMutex.withLock {
            val localList = fundDao.getAllTransactionsIncludingDeletedList()
            val localByRemoteId = localList.filter { it.remoteId.isNotEmpty() }.groupBy { it.remoteId }.toMutableMap()
            val cloudRemoteIds = mutableSetOf<String>()

            documents.forEach { doc ->
                try {
                    val remoteId = doc.id
                    if (remoteId.isBlank()) return@forEach
                    cloudRemoteIds.add(remoteId)

                    val type = getStringField(doc, "type").ifBlank { "INCOMING" }
                    val mode = getStringField(doc, "mode").ifBlank { "BANK" }
                    val amount = getDoubleField(doc, "amount") ?: 0.0
                    val title = getStringField(doc, "title")
                    val description = getStringField(doc, "description")
                    val personName = getStringField(doc, "personName")
                    val date = getLongField(doc, "date") ?: System.currentTimeMillis()
                    val transferFrom = getStringField(doc, "transferFrom")
                    val transferTo = getStringField(doc, "transferTo")
                    val isEdited = getBooleanField(doc, "isEdited")
                    val editHistory = getStringField(doc, "editHistory")
                    val isDeleted = getBooleanField(doc, "isDeleted")
                    val deletedAt = getLongField(doc, "deletedAt")
                    val createdByName = getStringField(doc, "createdByName")
                    val lastEditedByName = getStringField(doc, "lastEditedByName")
                    val lastEditedAt = getLongField(doc, "lastEditedAt")
                    val deletedByName = getStringField(doc, "deletedByName")

                    val existingLocals = localByRemoteId[remoteId] ?: emptyList()
                    val targetLocalId = if (existingLocals.isNotEmpty()) existingLocals.first().id else 0L

                    if (existingLocals.size > 1) {
                        existingLocals.drop(1).forEach { extra ->
                            fundDao.deleteTransaction(extra)
                        }
                    }

                    val entityToSave = FundTransactionEntity(
                        id = targetLocalId,
                        type = type,
                        mode = mode,
                        amount = amount,
                        title = title,
                        description = description,
                        personName = personName,
                        date = date,
                        remoteId = remoteId,
                        transferFrom = transferFrom,
                        transferTo = transferTo,
                        isEdited = isEdited,
                        editHistory = editHistory,
                        isDeleted = isDeleted,
                        deletedAt = deletedAt,
                        createdByName = createdByName,
                        lastEditedByName = lastEditedByName,
                        lastEditedAt = lastEditedAt,
                        deletedByName = deletedByName
                    )
                    val insertedId = fundDao.insertTransaction(entityToSave)
                    val actualLocalId = if (targetLocalId != 0L) targetLocalId else insertedId
                    val savedEntity = entityToSave.copy(id = actualLocalId)
                    localByRemoteId[remoteId] = listOf(savedEntity)
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error syncing individual fund transaction doc: ${e.message}")
                }
            }

            // Remove local records whose remoteId is not present in cloud snapshots
            localList.forEach { localTx ->
                if (localTx.remoteId.isNotEmpty() && !cloudRemoteIds.contains(localTx.remoteId)) {
                    fundDao.deleteTransaction(localTx)
                }
            }
        }
        } finally {
            isSyncing.value = false
        }
    }

    private suspend fun syncFundPersonsToLocal(documents: List<DocumentSnapshot>) {
        if (fundPersonDao == null) return

        isSyncing.value = true
        try {
            fundPersonSyncMutex.withLock {
                val localList = fundPersonDao.getAllPersonsList()
                val localByRemoteId = localList.filter { it.remoteId.isNotEmpty() }.groupBy { it.remoteId }.toMutableMap()
                val cloudRemoteIds = mutableSetOf<String>()

                documents.forEach { doc ->
                    try {
                        val remoteId = doc.id
                        val name = (doc.getString("name") ?: "").trim()
                        if (remoteId.isNotBlank() && name.isNotBlank()) {
                            cloudRemoteIds.add(remoteId)
                            val existingLocals = localByRemoteId[remoteId] ?: emptyList()
                            val targetLocalId = if (existingLocals.isNotEmpty()) existingLocals.first().id else 0L

                            if (existingLocals.size > 1) {
                                existingLocals.drop(1).forEach { extra ->
                                    fundPersonDao.deletePerson(extra)
                                }
                            }

                            val entityToSave = FundPersonEntity(
                                id = targetLocalId,
                                name = name,
                                remoteId = remoteId
                            )
                            val insertedId = fundPersonDao.insertPerson(entityToSave)
                            val actualLocalId = if (targetLocalId != 0L) targetLocalId else insertedId
                            val savedEntity = entityToSave.copy(id = actualLocalId)
                            localByRemoteId[remoteId] = listOf(savedEntity)
                        }
                    } catch (e: Exception) {
                        Log.e("FormRepository", "Error syncing individual fund person doc: ${e.message}")
                    }
                }

                localList.forEach { localPerson ->
                    if (localPerson.remoteId.isNotEmpty() && !cloudRemoteIds.contains(localPerson.remoteId)) {
                        fundPersonDao.deletePerson(localPerson)
                    }
                }
            }
        } finally {
            isSyncing.value = false
        }
    }

    suspend fun insertFundTransaction(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            try {
                val firestore = FirebaseFirestore.getInstance()

                // Generate UUID if remoteId is blank to guarantee instant, unique entity identity
                val remoteId = if (transaction.remoteId.isNotBlank()) {
                    transaction.remoteId
                } else {
                    java.util.UUID.randomUUID().toString()
                }

                val entityWithRemoteId = transaction.copy(remoteId = remoteId)
                val insertedId = fundDao?.insertTransaction(entityWithRemoteId) ?: 0L
                val finalEntity = entityWithRemoteId.copy(id = if (entityWithRemoteId.id == 0L) insertedId else entityWithRemoteId.id)

                val docRef = firestore.collection("fund_transactions").document(remoteId)
                val data = hashMapOf(
                    "remoteId" to remoteId,
                    "type" to finalEntity.type,
                    "mode" to finalEntity.mode,
                    "amount" to finalEntity.amount,
                    "title" to finalEntity.title,
                    "description" to finalEntity.description,
                    "personName" to finalEntity.personName,
                    "date" to finalEntity.date,
                    "transferFrom" to finalEntity.transferFrom,
                    "transferTo" to finalEntity.transferTo,
                    "isEdited" to finalEntity.isEdited,
                    "editHistory" to finalEntity.editHistory,
                    "isDeleted" to finalEntity.isDeleted,
                    "deletedAt" to finalEntity.deletedAt,
                    "createdByName" to finalEntity.createdByName,
                    "lastEditedByName" to finalEntity.lastEditedByName,
                    "lastEditedAt" to finalEntity.lastEditedAt,
                    "deletedByName" to finalEntity.deletedByName,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                docRef.set(data, SetOptions.merge())
                    .addOnSuccessListener { Log.d("FormRepository", "Fund transaction synced to Firestore: $remoteId") }
                    .addOnFailureListener { e -> Log.e("FormRepository", "Failed to sync fund transaction: ${e.message}") }
            } catch (e: Exception) {
                Log.e("FormRepository", "Error syncing fund transaction: ${e.message}")
            }
        }
    }

    suspend fun insertFundPerson(name: String): Long {
        val trimmedName = name.trim()
        if (trimmedName.isEmpty()) return 0L

        fundPersonSyncMutex.withLock {
            val existingList = fundPersonDao?.getAllPersonsList() ?: emptyList()
            val existing = existingList.find { it.name.equals(trimmedName, ignoreCase = true) }
            if (existing != null) {
                return existing.id
            }

            try {
                val firestore = FirebaseFirestore.getInstance()
                val remoteId = java.util.UUID.randomUUID().toString()
                val person = FundPersonEntity(name = trimmedName, remoteId = remoteId)
                val insertedId = fundPersonDao?.insertPerson(person) ?: 0L

                val docRef = firestore.collection("fund_persons").document(remoteId)
                val data = hashMapOf(
                    "remoteId" to remoteId,
                    "name" to trimmedName,
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                docRef.set(data, SetOptions.merge())
                return insertedId
            } catch (e: Exception) {
                Log.e("FormRepository", "Error syncing fund person: ${e.message}")
                return 0L
            }
        }
    }

    suspend fun deleteFundPerson(person: FundPersonEntity) {
        fundPersonSyncMutex.withLock {
            if (person.id != 0L) {
                fundPersonDao?.deletePerson(person)
            }
            if (person.remoteId.isNotEmpty()) {
                val existingList = fundPersonDao?.getAllPersonsList() ?: emptyList()
                existingList.filter { it.remoteId == person.remoteId }.forEach {
                    fundPersonDao?.deletePerson(it)
                }
                try {
                    FirebaseFirestore.getInstance().collection("fund_persons").document(person.remoteId).delete()
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error deleting fund person from Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun softDeleteFundTransaction(transaction: FundTransactionEntity, deletedByName: String = "") {
        fundTxSyncMutex.withLock {
            val now = System.currentTimeMillis()
            val updatedTx = transaction.copy(
                isDeleted = true,
                deletedAt = now,
                deletedByName = deletedByName.ifBlank { transaction.deletedByName }
            )
            if (transaction.id != 0L) {
                fundDao?.insertTransaction(updatedTx)
            }
            val remoteId = transaction.remoteId
            if (remoteId.isNotBlank()) {
                try {
                    val updateMap = mutableMapOf<String, Any?>(
                        "isDeleted" to true,
                        "deletedAt" to now,
                        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    )
                    if (updatedTx.deletedByName.isNotBlank()) {
                        updateMap["deletedByName"] = updatedTx.deletedByName
                    }
                    FirebaseFirestore.getInstance().collection("fund_transactions")
                        .document(remoteId)
                        .update(updateMap)
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error soft-deleting fund transaction in Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun restoreFundTransaction(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            if (transaction.id != 0L) {
                fundDao?.restoreTransaction(transaction.id)
            }
            val remoteId = transaction.remoteId
            if (remoteId.isNotBlank()) {
                try {
                    FirebaseFirestore.getInstance().collection("fund_transactions")
                        .document(remoteId)
                        .update(mapOf("isDeleted" to false, "deletedAt" to null, "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()))
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error restoring fund transaction in Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteFundTransactionPermanently(transaction: FundTransactionEntity) {
        fundTxSyncMutex.withLock {
            if (transaction.id != 0L) {
                fundDao?.deleteById(transaction.id)
            }
            if (transaction.remoteId.isNotEmpty()) {
                val existingList = fundDao?.getAllTransactionsIncludingDeletedList() ?: emptyList()
                existingList.filter { it.remoteId == transaction.remoteId }.forEach {
                    fundDao?.deleteTransaction(it)
                }
                try {
                    FirebaseFirestore.getInstance().collection("fund_transactions").document(transaction.remoteId).delete()
                } catch (e: Exception) {
                    Log.e("FormRepository", "Error deleting fund transaction permanently from Firestore: ${e.message}")
                }
            }
        }
    }

    suspend fun deleteFundTransaction(transaction: FundTransactionEntity) {
        softDeleteFundTransaction(transaction)
    }

    private fun startCloudSync() {
        try {
            val firestore = FirebaseFirestore.getInstance()

            if (personFirestoreListener == null) {
                personFirestoreListener = firestore.collection("fund_persons")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for fund_persons: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            CoroutineScope(Dispatchers.IO).launch {
                                syncFundPersonsToLocal(snapshot.documents)
                            }
                        }
                    }
            }

            if (fundFirestoreListener == null) {
                fundFirestoreListener = firestore.collection("fund_transactions")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for fund_transactions: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            CoroutineScope(Dispatchers.IO).launch {
                                syncFundTransactionsToLocal(snapshot.documents)
                            }
                        }
                    }
            }

            if (configListener == null) {
                configListener = firestore.collection("app_config").document("sangh_registration")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for app_config: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && snapshot.exists() && snapshot.contains("isStopped")) {
                            val stopped = getBooleanField(snapshot, "isStopped")
                            isSanghRegistrationStopped.value = stopped
                            prefs?.edit()?.putBoolean("is_sangh_registration_stopped", stopped)?.apply()
                        }
                    }
            }

            if (panchangConfigListener == null) {
                panchangConfigListener = firestore.collection("app_config").document("panchang_event_visibility")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for panchang_event_visibility: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && snapshot.exists()) {
                            @Suppress("UNCHECKED_CAST")
                            val calList = (snapshot.get("hiddenCalendarEventNames") as? List<String>)
                                ?: (snapshot.get("hiddenEventNames") as? List<String>)
                                ?: emptyList()
                            val calSet = calList.toSet()
                            hiddenCalendarEventNames.value = calSet
                            prefs?.edit()?.putStringSet("hidden_calendar_event_names", calSet)?.putStringSet("hidden_event_names", calSet)?.apply()

                            @Suppress("UNCHECKED_CAST")
                            val repoList = (snapshot.get("hiddenRepoEventNames") as? List<String>) ?: emptyList()
                            val repoSet = repoList.toSet()
                            hiddenRepoEventNames.value = repoSet
                            prefs?.edit()?.putStringSet("hidden_repo_event_names", repoSet)?.apply()
                        }
                    }
            }

            if (firestoreListener == null) {
                firestoreListener = firestore.collection("paryushan_forms")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for paryushan_forms: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val forms = snapshot.documents.mapNotNull { doc ->
                                try {
                                    parseDocToEntity(doc)
                                } catch (e: Exception) {
                                    Log.e("FormRepository", "Error parsing Firestore doc: ${e.message}")
                                    null
                                }
                            }
                            CoroutineScope(Dispatchers.IO).launch {
                                val localSoftDeletedIds = formDao.getSoftDeletedIds().toSet()
                                val validIds = forms.map { it.id }
                                forms.forEach { cloudForm ->
                                    val formToInsert = if (localSoftDeletedIds.contains(cloudForm.id) && !cloudForm.isDeleted) {
                                        cloudForm.copy(isDeleted = true)
                                    } else {
                                        cloudForm
                                    }
                                    formDao.insertForm(formToInsert)
                                }
                                if (validIds.isNotEmpty()) {
                                    formDao.deleteFormsNotIn(validIds)
                                }
                            }
                        }
                    }
            }

            if (swadhyaiFirestoreListener == null) {
                swadhyaiFirestoreListener = firestore.collection("swadhyai_forms")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for swadhyai_forms: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val swadhyaiForms = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val name = getStringField(doc, "fullName", "full_name", "name", "swadhyaiName", "swadhyai_name").trim()
                                    if (name.isBlank() && (doc.id.startsWith("phone_") || doc.id.matches("\\d{10}".toRegex()))) {
                                        // Auto clean phantom/ghost admin documents from Firestore swadhyai_forms
                                        try { doc.reference.delete() } catch (_: Exception) {}
                                        null
                                    } else {
                                        parseDocToSwadhyaiEntity(doc)
                                    }
                                } catch (e: Exception) {
                                    Log.e("FormRepository", "Error parsing swadhyai Firestore doc ${doc.id}: ${e.message}")
                                    null
                                }
                            }

                            for (dc in snapshot.documentChanges) {
                                if (dc.type == com.google.firebase.firestore.DocumentChange.Type.ADDED ||
                                    dc.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED) {
                                    val doc = dc.document
                                    val name = getStringField(doc, "fullName", "full_name", "name", "swadhyaiName", "swadhyai_name").trim()
                                    if (name.isNotBlank()) {
                                        val id = getLongField(doc, "id") ?: doc.id.toLongOrNull() ?: continue
                                        val city = getStringField(doc, "city", "cityName", "nativePlace")
                                        val docCreatedAt = getLongField(doc, "createdAt") ?: 0L
                                        val docUpdatedAt = getLongField(doc, "updatedAt") ?: 0L
                                        val isEdit = dc.type == com.google.firebase.firestore.DocumentChange.Type.MODIFIED || docUpdatedAt > 0L
                                        val ver = if (docUpdatedAt > 0L) docUpdatedAt else docCreatedAt
                                        val updatedFields = getStringField(doc, "updatedFields", "updated_fields", "modifiedFields")
                                        val updatedByPhone = getStringField(doc, "updatedByPhone", "updatedBy")
                                        val docWhatsapp = getStringField(doc, "whatsappNo", "userPhone")
                                        val docContact = getStringField(doc, "contactNo")

                                        context?.let { ctx ->
                                            val currentPhone = com.example.data.UserSessionManager.getCurrentPhone()
                                            val userClean = currentPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
                                            val cleanDocWhatsapp = docWhatsapp.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
                                            val cleanDocContact = docContact.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
                                            val cleanUpdatedBy = updatedByPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)

                                            val isSelfEdit = userClean.isNotBlank() && (
                                                cleanDocWhatsapp == userClean || cleanDocContact == userClean || cleanUpdatedBy == userClean
                                            )

                                            if (!isSelfEdit) {
                                                val seenTs = com.example.utils.SwadhyaiSeenTracker.getSeenTimestamp(ctx, id)
                                                val baseline = com.example.utils.AppInstallTracker.getInstallBaselineTimestamp(ctx)
                                                val isUnread = ver > baseline && ver > seenTs
                                                if (isUnread) {
                                                    com.example.utils.AppNotificationHelper.notifySwadhyaiRegistration(
                                                        context = ctx,
                                                        swadhyaiId = id,
                                                        swadhyaiName = name,
                                                        city = city,
                                                        isEdit = isEdit,
                                                        eventTimestamp = ver,
                                                        updatedFields = updatedFields
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            val adminPhones = mutableSetOf(com.example.data.UserSessionManager.MASTER_ADMIN_PHONE)
                            snapshot.documents.forEach { doc ->
                                val isAdmin = getBooleanField(doc, "isAdmin")
                                if (isAdmin) {
                                    val phone = (getStringField(doc, "whatsappNo", "userPhone").ifBlank { doc.id })
                                        .replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
                                    if (phone.isNotBlank()) {
                                        adminPhones.add(phone)
                                    }
                                }
                            }
                            com.example.data.UserSessionManager.updateAdminPhoneNumbers(adminPhones)

                            Log.d("FormRepository", "Realtime update: ${swadhyaiForms.size} swadhyai forms, ${adminPhones.size} admins")
                            CoroutineScope(Dispatchers.IO).launch {
                                swadhyaiDao.deleteBlankForms()
                                val validIds = swadhyaiForms.map { it.id }
                                swadhyaiForms.forEach { cloudForm ->
                                    if (cloudForm.fullName.isNotBlank()) {
                                        swadhyaiDao.insertForm(cloudForm)
                                    }
                                }
                                if (validIds.isNotEmpty()) {
                                    swadhyaiDao.deleteFormsNotIn(validIds)
                                }
                                swadhyaiDao.deleteBlankForms()
                            }
                        }
                    }
            }

            if (allotmentFirestoreListener == null) {
                allotmentFirestoreListener = firestore.collection("sangh_allotments")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for sangh_allotments: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val allotments = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val sId = getLongField(doc, "sanghId", "id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val sName = getStringField(doc, "sanghName")
                                    val cName = getStringField(doc, "cityName")
                                    val stName = getStringField(doc, "stateName")
                                    val swIds = getStringField(doc, "swadhyaiIds")
                                    val uAt = getLongField(doc, "updatedAt") ?: System.currentTimeMillis()
                                    AllotmentEntity(sId, sName, cName, stName, swIds, uAt)
                                } catch (e: Exception) { null }
                            }
                            Log.d("FormRepository", "Realtime update: ${allotments.size} allotments")
                            CoroutineScope(Dispatchers.IO).launch {
                                val validIds = allotments.map { it.sanghId }
                                allotments.forEach { allotmentDao?.saveAllotment(it) }
                                if (validIds.isNotEmpty()) {
                                    allotmentDao?.deleteNotIn(validIds)
                                } else {
                                    allotmentDao?.deleteAll()
                                }
                            }
                        }
                    }
            }

            if (historyFirestoreListener == null) {
                historyFirestoreListener = firestore.collection("registration_history")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for registration_history: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val histories = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val year = getIntField(doc, "year") ?: doc.id.toIntOrNull() ?: return@mapNotNull null
                                    val pStart = getStringField(doc, "paryushanStartDate")
                                    val pEnd = getStringField(doc, "paryushanEndDate")
                                    val tSangh = getIntField(doc, "totalSanghCount") ?: 0
                                    val alloSangh = getIntField(doc, "allottedSanghCount") ?: 0
                                    val unalloSangh = getIntField(doc, "unallottedSanghCount") ?: 0
                                    val totalAllottedSw = getIntField(doc, "totalAllottedSwadhyayisCount") ?: 0
                                    val totalDon = getDoubleField(doc, "totalDonationReceived") ?: 0.0
                                    val alloJson = getStringField(doc, "archivedAllotmentsJson")
                                    val unalloJson = getStringField(doc, "archivedUnallottedSanghsJson")
                                    val swUpdatesJson = getStringField(doc, "archivedSwadhyaiUpdatesJson")
                                    val sanghFormsJson = getStringField(doc, "archivedSanghFormsJson")
                                    val cAt = getTimestampField(doc)
                                    RegistrationHistoryEntity(
                                        year = year,
                                        paryushanStartDate = pStart,
                                        paryushanEndDate = pEnd,
                                        totalSanghCount = tSangh,
                                        allottedSanghCount = alloSangh,
                                        unallottedSanghCount = unalloSangh,
                                        totalAllottedSwadhyayisCount = totalAllottedSw,
                                        totalDonationReceived = totalDon,
                                        archivedAllotmentsJson = alloJson,
                                        archivedUnallottedSanghsJson = unalloJson,
                                        archivedSwadhyaiUpdatesJson = swUpdatesJson,
                                        archivedSanghFormsJson = sanghFormsJson,
                                        createdAt = cAt
                                    )
                                } catch (e: Exception) { null }
                            }
                            Log.d("FormRepository", "Realtime update: ${histories.size} registration histories")
                            CoroutineScope(Dispatchers.IO).launch {
                                val validYears = histories.map { it.year }
                                histories.forEach { registrationHistoryDao?.insertHistory(it) }
                                val currentList = registrationHistoryDao?.getAllHistoriesList() ?: emptyList()
                                currentList.filter { !validYears.contains(it.year) }.forEach {
                                    registrationHistoryDao?.deleteHistory(it)
                                }
                            }
                        }
                    }
            }

            if (panchangEventsFirestoreListener == null) {
                panchangEventsFirestoreListener = firestore.collection("panchang_events")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for panchang_events: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null && !snapshot.isEmpty) {
                            Log.d("FormRepository", "Realtime update: ${snapshot.size()} panchang events")
                            CoroutineScope(Dispatchers.IO).launch {
                                processCloudPanchangSnapshot(snapshot.documents)
                            }
                        }
                    }
            }

            if (timelineFirestoreListener == null) {
                timelineFirestoreListener = firestore.collection("timeline_posts")
                    .addSnapshotListener { snapshot, error ->
                        if (error != null) {
                            Log.e("FormRepository", "Firestore listen failed for timeline_posts: ${error.message}")
                            return@addSnapshotListener
                        }
                        if (snapshot != null) {
                            val posts = snapshot.documents.mapNotNull { doc ->
                                try {
                                    val id = getLongField(doc, "id") ?: doc.id.toLongOrNull() ?: return@mapNotNull null
                                    val heading = getStringField(doc, "heading")
                                    val subHeading = getStringField(doc, "subHeading")
                                    val description = getStringField(doc, "description")
                                    val dateEpochMillis = getLongField(doc, "dateEpochMillis") ?: System.currentTimeMillis()
                                    val photoUris = getStringField(doc, "photoUris")
                                    val isDeleted = getBooleanField(doc, "isDeleted")
                                    val createdAtEpochMillis = getLongField(doc, "createdAtEpochMillis") ?: dateEpochMillis
                                    val isGyanShalaUpdate = getBooleanField(doc, "isGyanShalaUpdate")
                                    val gyanCategoryId = getLongField(doc, "gyanCategoryId") ?: 0L
                                    val gyanTopicId = getLongField(doc, "gyanTopicId") ?: 0L
                                    val gyanCategoryName = getStringField(doc, "gyanCategoryName")
                                    val gyanTopicTitle = getStringField(doc, "gyanTopicTitle")
                                    val isGyanEdit = getBooleanField(doc, "isGyanEdit")
                                    val authorInstallId = getStringField(doc, "authorInstallId")
                                    val authorPhone = getStringField(doc, "authorPhone")

                                    val post = TimelinePostEntity(
                                        id = id,
                                        heading = heading,
                                        subHeading = subHeading,
                                        description = description,
                                        dateEpochMillis = dateEpochMillis,
                                        photoUris = photoUris,
                                        isDeleted = isDeleted,
                                        createdAtEpochMillis = createdAtEpochMillis,
                                        isGyanShalaUpdate = isGyanShalaUpdate,
                                        gyanCategoryId = gyanCategoryId,
                                        gyanTopicId = gyanTopicId,
                                        gyanCategoryName = gyanCategoryName,
                                        gyanTopicTitle = gyanTopicTitle,
                                        isGyanEdit = isGyanEdit
                                    )
                                    Triple(post, authorInstallId, authorPhone)
                                } catch (e: Exception) {
                                    Log.e("FormRepository", "Error parsing timeline doc ${doc.id}: ${e.message}")
                                    null
                                }
                            }
                            Log.d("FormRepository", "Realtime update: ${posts.size} timeline posts")
                            CoroutineScope(Dispatchers.IO).launch {
                                posts.forEach { (cloudPost, authorInstallId, authorPhone) ->
                                    if (cloudPost.isDeleted) {
                                        timelineDao?.softDeletePost(cloudPost.id)
                                    } else {
                                        // Check if this post was already in local DB
                                        val existing = timelineDao?.getPostById(cloudPost.id)
                                        timelineDao?.insertPost(cloudPost)

                                        // If it's a new Gyan Shala update and not yet viewed on this device, dispatch notification (author excluded)
                                        if (existing == null && cloudPost.isGyanShalaUpdate && context != null) {
                                            val postTimestamp = if (cloudPost.createdAtEpochMillis > 0L) cloudPost.createdAtEpochMillis else cloudPost.dateEpochMillis
                                            val currentInstallId = com.example.utils.AppInstallTracker.getInstallationId(context)
                                            val currentPhone = com.example.data.UserSessionManager.sessionState.value.phone.trim()

                                            val isAuthor = (authorInstallId.isNotBlank() && authorInstallId == currentInstallId) ||
                                                           (authorPhone.isNotBlank() && currentPhone.isNotBlank() && authorPhone == currentPhone) ||
                                                           com.example.utils.GyanSeenTracker.isTopicAuthoredLocally(context, cloudPost.gyanTopicId, postTimestamp)

                                            if (isAuthor) {
                                                // Mark viewed immediately so author never gets notification or timeline alert
                                                val postKey = "gyan_post_${cloudPost.id}"
                                                com.example.utils.GyanNotificationHelper.markPostAsViewed(context, postKey)
                                            } else {
                                                com.example.utils.AppNotificationHelper.notifyGyanNote(
                                                    context = context,
                                                    categoryId = cloudPost.gyanCategoryId,
                                                    topicId = cloudPost.gyanTopicId,
                                                    categoryName = cloudPost.gyanCategoryName,
                                                    topicTitle = cloudPost.gyanTopicTitle,
                                                    contentSnippet = cloudPost.description.take(120),
                                                    isEdit = cloudPost.isGyanEdit,
                                                    eventTimestamp = postTimestamp,
                                                    authorInstallId = authorInstallId,
                                                    authorPhone = authorPhone
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore initialization or sync skipped: ${e.message}")
        }
    }

    private fun getLongField(doc: DocumentSnapshot, vararg keys: String): Long? {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Number -> return v.toLong()
                    is com.google.firebase.Timestamp -> return v.toDate().time
                    is String -> {
                        val parsed = v.trim().toLongOrNull()
                        if (parsed != null) return parsed
                    }
                    is Boolean -> return if (v) 1L else 0L
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun getIntField(doc: DocumentSnapshot, vararg keys: String): Int? {
        return getLongField(doc, *keys)?.toInt()
    }

    private fun getDoubleField(doc: DocumentSnapshot, vararg keys: String): Double? {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Number -> return v.toDouble()
                    is String -> {
                        val parsed = v.trim().toDoubleOrNull()
                        if (parsed != null) return parsed
                    }
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private fun getBooleanField(doc: DocumentSnapshot, vararg keys: String, default: Boolean = false): Boolean {
        for (key in keys) {
            try {
                val v = doc.get(key) ?: continue
                when (v) {
                    is Boolean -> return v
                    is Number -> return v.toLong() != 0L
                    is String -> {
                        val lower = v.trim().lowercase()
                        if (lower == "true" || lower == "1" || lower == "yes") return true
                        if (lower == "false" || lower == "0" || lower == "no") return false
                    }
                }
            } catch (_: Exception) {}
        }
        return default
    }

    private fun getStringField(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            try {
                val value = doc.get(key)
                if (value != null) {
                    if (value is List<*>) {
                        val joined = value.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString(", ")
                        if (joined.isNotBlank()) return joined
                    }
                    val str = value.toString().trim()
                    if (str.isNotBlank() && str != "[]" && str != "null" && str != "{}") return str
                }
            } catch (e: Exception) {
                // Ignore key lookup error
            }
        }
        return ""
    }

    private fun getNewlineJoinedField(doc: DocumentSnapshot, vararg keys: String): String {
        for (key in keys) {
            try {
                val value = doc.get(key)
                if (value != null) {
                    if (value is List<*>) {
                        val joined = value.filterNotNull().map { it.toString().trim() }.filter { it.isNotBlank() }.joinToString("\n")
                        if (joined.isNotBlank()) return joined
                    }
                    val str = value.toString().trim()
                    if (str.isNotBlank() && str != "[]" && str != "null" && str != "{}") return str
                }
            } catch (e: Exception) {
                // Ignore key lookup error
            }
        }
        return ""
    }

    private fun getTimestampField(doc: DocumentSnapshot): Long {
        try {
            val created = doc.get("createdAt")
            if (created is Number) return created.toLong()
            if (created is com.google.firebase.Timestamp) return created.toDate().time
        } catch (e: Exception) {
            Log.w("FormRepository", "Error reading createdAt: ${e.message}")
        }

        try {
            val ts = doc.get("timestamp")
            if (ts is Number) return ts.toLong()
            if (ts is com.google.firebase.Timestamp) return ts.toDate().time
        } catch (e: Exception) {
            Log.w("FormRepository", "Error reading timestamp: ${e.message}")
        }

        return doc.id.toLongOrNull() ?: System.currentTimeMillis()
    }

    private fun parseDocToEntity(doc: DocumentSnapshot): ParyushanFormEntity {
        val numericId = try {
            doc.getLong("id")
                ?: doc.id.toLongOrNull()
                ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        } catch (e: Exception) {
            doc.id.toLongOrNull() ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        }

        val sanghName = getStringField(doc, "sanghName", "sangh_name", "sangh")
        val sanghAddress = getStringField(doc, "sanghAddress", "sangh_address", "address")

        val cityRaw = getStringField(doc, "cityName", "city_name", "city")
        val districtRaw = getStringField(doc, "district")
        val stateRaw = getStringField(doc, "stateName", "state_name", "state")
        val cityName = if (cityRaw.isNotBlank()) cityRaw else listOf(districtRaw, stateRaw).filter { it.isNotBlank() }.joinToString(", ")
        val stateName = stateRaw

        val contactPerson = getStringField(doc, "contactPersonName", "contactPerson", "contact1", "contact_1", "contact")
        val mobileNumber = getStringField(doc, "whatsappNumber", "mobileNumber", "contact2", "contact_2")

        val contact1 = contactPerson.ifBlank { getStringField(doc, "contact1", "contact_1") }
        val contact2 = mobileNumber.ifBlank { getStringField(doc, "whatsappNumber", "mobileNumber", "contact2", "contact_2") }
        val mulnayakBhagwan = getStringField(doc, "mulnayakBhagwan", "mulnayak_bhagwan", "mulnayak")
        val totalFamilies = getStringField(doc, "totalFamilies", "total_families", "families", "swadhyayisCount")

        val hasOtherSangh = getStringField(doc, "hasOtherSangh", "has_other_sangh").ifBlank { "नहीं" }
        val gacchList = getStringField(doc, "gacchList", "gacch_list", "gacch")
        val pratikramanTradition = getStringField(doc, "pratikramanTradition", "pratikraman_tradition", "tradition")
        val hasMusicianGroup = getStringField(doc, "hasMusicianGroup", "has_musician_group").ifBlank { "नहीं" }
        val callsOutsideMusician = getStringField(doc, "callsOutsideMusician", "calls_outside_musician").ifBlank { "नहीं" }
        val hasPanchPratikramanPerson = getStringField(doc, "hasPanchPratikramanPerson", "has_panch_pratikraman_person").ifBlank { "नहीं" }
        val hasToiletFacility = getStringField(doc, "hasToiletFacility", "has_toilet_facility").ifBlank { "नहीं" }
        val aradhanaSamagriList = getStringField(doc, "aradhanaSamagriList", "aradhanaSamagri", "aradhana_samagri_list", "aradhana_samagri", "samagriList", "samagri", "q15")
        val countRaiPratikraman = getStringField(doc, "countRaiPratikraman", "count_rai_pratikraman")
        val countDevasiPratikraman = getStringField(doc, "countDevasiPratikraman", "count_devasi_pratikraman")
        val countPravachan = getStringField(doc, "countPravachan", "count_pravachan")
        val countSandhyaBhakti = getStringField(doc, "countSandhyaBhakti", "count_sandhya_bhakti")
        val mainTrustees = getStringField(doc, "mainTrustees", "main_trustees", "trustees", "remarks")

        val agreedToTerms = try {
            (doc.get("agreedToTerms") as? Boolean) ?: true
        } catch (e: Exception) { true }

        val isDeleted = try {
            (doc.get("isDeleted") as? Boolean) ?: false
        } catch (e: Exception) { false }

        val deletedAt = try {
            doc.getLong("deletedAt")
        } catch (e: Exception) { null }

        val createdAt = getTimestampField(doc)

        val docIdStr = doc.id

        return ParyushanFormEntity(
            id = numericId,
            firestoreDocId = docIdStr,
            sanghName = sanghName.ifBlank { "श्रीसंघ" },
            sanghAddress = sanghAddress,
            cityName = cityName,
            stateName = stateName,
            contact1 = contact1,
            contact2 = contact2,
            mulnayakBhagwan = mulnayakBhagwan,
            totalFamilies = totalFamilies,
            hasOtherSangh = hasOtherSangh,
            gacchList = gacchList,
            pratikramanTradition = pratikramanTradition,
            hasMusicianGroup = hasMusicianGroup,
            callsOutsideMusician = callsOutsideMusician,
            hasPanchPratikramanPerson = hasPanchPratikramanPerson,
            hasToiletFacility = hasToiletFacility,
            aradhanaSamagriList = aradhanaSamagriList,
            countRaiPratikraman = countRaiPratikraman,
            countDevasiPratikraman = countDevasiPratikraman,
            countPravachan = countPravachan,
            countSandhyaBhakti = countSandhyaBhakti,
            mainTrustees = mainTrustees,
            agreedToTerms = agreedToTerms,
            isDeleted = isDeleted,
            deletedAt = deletedAt,
            createdAt = createdAt
        )
    }

    fun getFormFlow(id: Long): Flow<ParyushanFormEntity?> = formDao.getFormFlowById(id)

    suspend fun getFormById(id: Long): ParyushanFormEntity? = formDao.getFormById(id)

    suspend fun insertForm(form: ParyushanFormEntity): Long {
        val insertedId = formDao.insertForm(form)
        val formWithId = if (form.id == 0L) form.copy(id = insertedId) else form

        // Save to cloud Firestore
        try {
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = formWithId.firestoreDocId.ifBlank { formWithId.id.toString() }
            val docData = hashMapOf(
                "id" to formWithId.id,
                "sanghName" to formWithId.sanghName,
                "sanghAddress" to formWithId.sanghAddress,
                "cityName" to formWithId.cityName,
                "stateName" to formWithId.stateName,
                "contact1" to formWithId.contact1,
                "contact2" to formWithId.contact2,
                "contactPersonName" to formWithId.contact1,
                "whatsappNumber" to formWithId.contact2,
                "mulnayakBhagwan" to formWithId.mulnayakBhagwan,
                "totalFamilies" to formWithId.totalFamilies,
                "hasOtherSangh" to formWithId.hasOtherSangh,
                "gacchList" to formWithId.gacchList,
                "pratikramanTradition" to formWithId.pratikramanTradition,
                "hasMusicianGroup" to formWithId.hasMusicianGroup,
                "callsOutsideMusician" to formWithId.callsOutsideMusician,
                "hasPanchPratikramanPerson" to formWithId.hasPanchPratikramanPerson,
                "hasToiletFacility" to formWithId.hasToiletFacility,
                "aradhanaSamagriList" to formWithId.aradhanaSamagriList,
                "aradhanaSamagri" to formWithId.aradhanaSamagriList,
                "countRaiPratikraman" to formWithId.countRaiPratikraman,
                "countDevasiPratikraman" to formWithId.countDevasiPratikraman,
                "countPravachan" to formWithId.countPravachan,
                "countSandhyaBhakti" to formWithId.countSandhyaBhakti,
                "mainTrustees" to formWithId.mainTrustees,
                "agreedToTerms" to formWithId.agreedToTerms,
                "createdAt" to formWithId.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(targetDocId)
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore save skipped/failed: ${e.message}")
        }

        return insertedId
    }

    suspend fun updateForm(form: ParyushanFormEntity) {
        formDao.updateForm(form)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
            val docData = hashMapOf(
                "id" to form.id,
                "sanghName" to form.sanghName,
                "sanghAddress" to form.sanghAddress,
                "cityName" to form.cityName,
                "stateName" to form.stateName,
                "contact1" to form.contact1,
                "contact2" to form.contact2,
                "contactPersonName" to form.contact1,
                "whatsappNumber" to form.contact2,
                "mulnayakBhagwan" to form.mulnayakBhagwan,
                "totalFamilies" to form.totalFamilies,
                "hasOtherSangh" to form.hasOtherSangh,
                "gacchList" to form.gacchList,
                "pratikramanTradition" to form.pratikramanTradition,
                "hasMusicianGroup" to form.hasMusicianGroup,
                "callsOutsideMusician" to form.callsOutsideMusician,
                "hasPanchPratikramanPerson" to form.hasPanchPratikramanPerson,
                "hasToiletFacility" to form.hasToiletFacility,
                "aradhanaSamagriList" to form.aradhanaSamagriList,
                "aradhanaSamagri" to form.aradhanaSamagriList,
                "countRaiPratikraman" to form.countRaiPratikraman,
                "countDevasiPratikraman" to form.countDevasiPratikraman,
                "countPravachan" to form.countPravachan,
                "countSandhyaBhakti" to form.countSandhyaBhakti,
                "mainTrustees" to form.mainTrustees,
                "agreedToTerms" to form.agreedToTerms,
                "createdAt" to form.createdAt
            )
            firestore.collection("paryushan_forms")
                .document(targetDocId)
                .set(docData)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore update skipped/failed: ${e.message}")
        }
    }

    suspend fun softDeleteFormById(id: Long) {
        val now = System.currentTimeMillis()
        formDao.softDeleteForm(id, now)
        try {
            val form = formDao.getFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
                firestore.collection("paryushan_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to true, "deletedAt" to now))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore softDelete update failed: ${e.message}")
        }
    }

    suspend fun restoreFormById(id: Long) {
        formDao.restoreForm(id)
        try {
            val form = formDao.getFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = form.firestoreDocId.ifBlank { form.id.toString() }
                firestore.collection("paryushan_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to false, "deletedAt" to null))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore restore update failed: ${e.message}")
        }
    }

    suspend fun purgeOldDeletedForms() {
        val cutoff = System.currentTimeMillis() - (60L * 24 * 60 * 60 * 1000L)
        formDao.purgeOldDeletedForms(cutoff)
        swadhyaiDao.purgeOldDeletedForms(cutoff)
    }

    suspend fun deleteFormPermanentlyById(id: Long) {
        deleteFormById(id)
    }

    suspend fun deleteFormById(id: Long) {
        val existing = formDao.getFormAnyById(id)
        val docIdToDelete = existing?.firestoreDocId?.ifBlank { null }
            ?: existing?.id?.toString()
            ?: id.toString()

        formDao.deleteFormPermanentlyById(id)

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("paryushan_forms")
                .document(docIdToDelete)
                .delete()
                .addOnSuccessListener {
                    Log.d("FormRepository", "Successfully deleted doc $docIdToDelete from Firestore")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to delete doc $docIdToDelete from Firestore: ${e.message}")
                }

            if (docIdToDelete != id.toString()) {
                firestore.collection("paryushan_forms")
                    .document(id.toString())
                    .delete()
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete skipped/failed: ${e.message}")
        }
    }

    private fun parseDocToSwadhyaiEntity(doc: DocumentSnapshot): SwadhyaiFormEntity? {
        val fullName = getStringField(doc, "fullName", "full_name", "name", "swadhyaiName", "swadhyai_name").trim()
        val whatsappNo = getStringField(doc, "whatsappNo", "whatsapp_no", "whatsappNumber", "whatsapp", "mobile", "phone").trim()
        val contactNo = getStringField(doc, "contactNo", "contact_no", "contactNumber", "contact").trim()

        // Filter out ghost / empty documents created accidentally by metadata sets
        if (fullName.isBlank() || (fullName == "स्वाध्यायी" && whatsappNo.isBlank() && contactNo.isBlank())) {
            try {
                FirebaseFirestore.getInstance().collection("swadhyai_forms").document(doc.id).delete()
            } catch (_: Exception) {}
            return null
        }

        val numericId = try {
            doc.getLong("id")
                ?: doc.id.toLongOrNull()
                ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        } catch (e: Exception) {
            doc.id.toLongOrNull() ?: (kotlin.math.abs(doc.id.hashCode().toLong()) + 1L)
        }
        val fatherName = getStringField(doc, "fatherName", "father_name", "father")
        val motherName = getStringField(doc, "motherName", "mother_name", "mother")
        val gender = getStringField(doc, "gender", "sex", "genderName", "ling")
        val dob = getStringField(doc, "dob", "dateOfBirth", "date_of_birth", "birthDate")
        val age = try { doc.getLong("age")?.toInt() ?: getStringField(doc, "age").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val bloodGroup = getStringField(doc, "bloodGroup", "blood_group", "bloodgroup")
        val maritalStatus = getStringField(doc, "maritalStatus", "marital_status", "marital")
        val anniversaryDate = getStringField(doc, "anniversaryDate", "anniversary_date", "anniversary")
        val email = getStringField(doc, "email", "emailId", "email_id", "emailAddress")
        val emergencyContactName = getStringField(doc, "emergencyContactName", "emergency_contact_name", "emergencyContactPerson")
        val emergencyContactRelation = getStringField(doc, "emergencyContactRelation", "emergency_contact_relation", "emergencyRelation")
        val emergencyContactNo = getStringField(doc, "emergencyContactNo", "emergency_contact_no", "emergencyNo", "emergency")
        val address = getStringField(doc, "address", "full_address", "residenceAddress")
        val city = getStringField(doc, "city", "cityName", "city_name", "district")
        val pincode = getStringField(doc, "pincode", "pin_code", "pin", "zip")
        val state = getStringField(doc, "state", "stateName", "state_name")
        val nativePlace = getStringField(doc, "nativePlace", "native_place", "moolNiwas", "mool_niwas", "hometown")
        val education = getStringField(doc, "education", "qualification", "degree")
        val workingStatus = getStringField(doc, "workingStatus", "working_status", "occupation", "profession")
        val workDescription = getStringField(doc, "workDescription", "work_description", "occupationDetail", "businessDetail")
        val joiningYear = try { doc.getLong("joiningYear")?.toInt() ?: getStringField(doc, "joiningYear").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val specialities = getStringField(doc, "specialities", "speciality", "specialSkills", "specialityList")
        val religiousLearnings = getNewlineJoinedField(doc, "religiousLearningsFormatted", "religiousLearnings", "religious_learnings", "religiousLearning", "dharmikGyan")
        val anotherGroup = getStringField(doc, "anotherGroup", "another_group", "otherGroup", "groupName")
        val postInGroup = getStringField(doc, "postInGroup", "post_in_group", "postName", "designation")
        val paryushanCount = try { doc.getLong("paryushanCount")?.toInt() ?: getStringField(doc, "paryushanCount").toIntOrNull() ?: 0 } catch (e: Exception) { 0 }
        val paryushanHistoryLog = getNewlineJoinedField(doc, "paryushanHistoryLog", "paryushan_history_log", "aradhanaHistory")
        val dailyRoutineActivities = getStringField(doc, "dailyRoutineActivities", "daily_routine_activities", "dailyRoutineActivity", "dailyActivities")
        val lifetimeTapasya = getNewlineJoinedField(doc, "lifetimeTapasya", "lifetime_tapasya", "lifetimeTyag", "tapasya")
        val paryushanWillingness = getStringField(doc, "paryushanWillingness", "paryushan_willingness", "availableForParyushan", "willingness", "travelWillingness")
        val acceptedRules = try { (doc.get("acceptedRules") as? Boolean) ?: true } catch (e: Exception) { true }
        val remarks = getStringField(doc, "remarks", "remark", "comments", "additionalInfo", "notes")
        val profileImageUri = getStringField(doc, "profileImageUri", "profileImage", "photoUrl", "photo", "imageUrl", "image")
        val updatedAt = try {
            val u = doc.get("updatedAt")
            if (u is Number) u.toLong()
            else if (u is com.google.firebase.Timestamp) u.toDate().time
            else 0L
        } catch (e: Exception) { 0L }
        val updatedFields = getStringField(doc, "updatedFields", "updated_fields", "modifiedFields")

        val isDeleted = try { (doc.get("isDeleted") as? Boolean) ?: false } catch (e: Exception) { false }
        val deletedAt = try { doc.getLong("deletedAt") } catch (e: Exception) { null }
        val createdAt = getTimestampField(doc)

        return SwadhyaiFormEntity(
            id = numericId,
            firestoreDocId = doc.id,
            fullName = fullName,
            fatherName = fatherName,
            motherName = motherName,
            gender = gender,
            dob = dob,
            age = age,
            bloodGroup = bloodGroup,
            maritalStatus = maritalStatus,
            anniversaryDate = anniversaryDate,
            email = email,
            whatsappNo = whatsappNo,
            contactNo = contactNo,
            emergencyContactName = emergencyContactName,
            emergencyContactRelation = emergencyContactRelation,
            emergencyContactNo = emergencyContactNo,
            address = address,
            city = city,
            pincode = pincode,
            state = state,
            nativePlace = nativePlace,
            education = education,
            workingStatus = workingStatus,
            workDescription = workDescription,
            joiningYear = joiningYear,
            specialities = specialities,
            religiousLearnings = religiousLearnings,
            anotherGroup = anotherGroup,
            postInGroup = postInGroup,
            paryushanCount = paryushanCount,
            paryushanHistoryLog = paryushanHistoryLog,
            dailyRoutineActivities = dailyRoutineActivities,
            lifetimeTapasya = lifetimeTapasya,
            paryushanWillingness = paryushanWillingness,
            acceptedRules = acceptedRules,
            remarks = remarks,
            profileImageUri = profileImageUri,
            updatedAt = updatedAt,
            updatedFields = updatedFields,
            isDeleted = isDeleted,
            deletedAt = deletedAt,
            createdAt = createdAt
        )
    }

    suspend fun insertSwadhyaiForm(form: SwadhyaiFormEntity): Long {
        val insertedId = swadhyaiDao.insertForm(form)
        val finalForm = if (form.id == 0L) form.copy(id = insertedId) else form
        try {
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = if (finalForm.firestoreDocId.isNotBlank()) {
                finalForm.firestoreDocId
            } else if (finalForm.whatsappNo.isNotBlank()) {
                "phone_${finalForm.whatsappNo}"
            } else {
                finalForm.id.toString()
            }

            val docData = hashMapOf(
                "id" to finalForm.id,
                "fullName" to finalForm.fullName,
                "fatherName" to finalForm.fatherName,
                "motherName" to finalForm.motherName,
                "gender" to finalForm.gender,
                "dob" to finalForm.dob,
                "age" to finalForm.age,
                "bloodGroup" to finalForm.bloodGroup,
                "maritalStatus" to finalForm.maritalStatus,
                "anniversaryDate" to finalForm.anniversaryDate,
                "email" to finalForm.email,
                "whatsappNo" to finalForm.whatsappNo,
                "searchPhone" to finalForm.whatsappNo,
                "contactNo" to finalForm.contactNo,
                "emergencyContactName" to finalForm.emergencyContactName,
                "emergencyContactRelation" to finalForm.emergencyContactRelation,
                "emergencyContactNo" to finalForm.emergencyContactNo,
                "address" to finalForm.address,
                "city" to finalForm.city,
                "pincode" to finalForm.pincode,
                "state" to finalForm.state,
                "nativePlace" to finalForm.nativePlace,
                "education" to finalForm.education,
                "workingStatus" to finalForm.workingStatus,
                "workDescription" to finalForm.workDescription,
                "joiningYear" to finalForm.joiningYear,
                "specialities" to finalForm.specialities,
                "religiousLearnings" to finalForm.religiousLearnings,
                "religiousLearningsFormatted" to finalForm.religiousLearnings,
                "anotherGroup" to finalForm.anotherGroup,
                "postInGroup" to finalForm.postInGroup,
                "paryushanCount" to finalForm.paryushanCount,
                "paryushanHistoryLog" to finalForm.paryushanHistoryLog,
                "dailyRoutineActivities" to finalForm.dailyRoutineActivities,
                "lifetimeTapasya" to finalForm.lifetimeTapasya,
                "paryushanWillingness" to finalForm.paryushanWillingness,
                "acceptedRules" to finalForm.acceptedRules,
                "remarks" to finalForm.remarks,
                "profileImageUri" to finalForm.profileImageUri,
                "updatedFields" to finalForm.updatedFields,
                "updatedAt" to (if (finalForm.updatedAt > 0L) finalForm.updatedAt else System.currentTimeMillis())
            )

            firestore.collection("swadhyai_forms")
                .document(targetDocId)
                .set(docData, SetOptions.merge())

            if (finalForm.fullName.isNotBlank()) {
                context?.let { ctx ->
                    com.example.utils.AppNotificationHelper.notifySwadhyaiRegistration(
                        context = ctx,
                        swadhyaiId = finalForm.id,
                        swadhyaiName = finalForm.fullName,
                        city = finalForm.city,
                        isEdit = false
                    )
                }
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai insert skipped/failed: ${e.message}")
        }
        return insertedId
    }

    suspend fun updateSwadhyaiForm(form: SwadhyaiFormEntity) {
        swadhyaiDao.updateForm(form)
        try {
            context?.let { ctx ->
                com.example.utils.SwadhyaiSeenTracker.markSwadhyaiSeen(ctx, form.id)
            }
            val firestore = FirebaseFirestore.getInstance()
            val targetDocId = if (form.firestoreDocId.isNotBlank()) {
                form.firestoreDocId
            } else if (form.whatsappNo.isNotBlank()) {
                "phone_${form.whatsappNo}"
            } else {
                form.id.toString()
            }

            val currentPhone = com.example.data.UserSessionManager.getCurrentPhone()
            val docData = hashMapOf(
                "id" to form.id,
                "fullName" to form.fullName,
                "fatherName" to form.fatherName,
                "motherName" to form.motherName,
                "gender" to form.gender,
                "dob" to form.dob,
                "age" to form.age,
                "bloodGroup" to form.bloodGroup,
                "maritalStatus" to form.maritalStatus,
                "anniversaryDate" to form.anniversaryDate,
                "email" to form.email,
                "whatsappNo" to form.whatsappNo,
                "searchPhone" to form.whatsappNo,
                "contactNo" to form.contactNo,
                "emergencyContactName" to form.emergencyContactName,
                "emergencyContactRelation" to form.emergencyContactRelation,
                "emergencyContactNo" to form.emergencyContactNo,
                "address" to form.address,
                "city" to form.city,
                "pincode" to form.pincode,
                "state" to form.state,
                "nativePlace" to form.nativePlace,
                "education" to form.education,
                "workingStatus" to form.workingStatus,
                "workDescription" to form.workDescription,
                "joiningYear" to form.joiningYear,
                "specialities" to form.specialities,
                "religiousLearnings" to form.religiousLearnings,
                "religiousLearningsFormatted" to form.religiousLearnings,
                "anotherGroup" to form.anotherGroup,
                "postInGroup" to form.postInGroup,
                "paryushanCount" to form.paryushanCount,
                "paryushanHistoryLog" to form.paryushanHistoryLog,
                "dailyRoutineActivities" to form.dailyRoutineActivities,
                "lifetimeTapasya" to form.lifetimeTapasya,
                "paryushanWillingness" to form.paryushanWillingness,
                "acceptedRules" to form.acceptedRules,
                "remarks" to form.remarks,
                "profileImageUri" to form.profileImageUri,
                "updatedFields" to form.updatedFields,
                "updatedByPhone" to currentPhone,
                "updatedAt" to (if (form.updatedAt > 0L) form.updatedAt else System.currentTimeMillis())
            )

            firestore.collection("swadhyai_forms")
                .document(targetDocId)
                .set(docData, SetOptions.merge())
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai update skipped/failed: ${e.message}")
        }
    }

    suspend fun softDeleteSwadhyaiFormById(id: Long) {
        val now = System.currentTimeMillis()
        swadhyaiDao.softDeleteForm(id, now)
        try {
            val form = swadhyaiDao.getSwadhyaiFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = if (form.firestoreDocId.isNotBlank()) {
                    form.firestoreDocId
                } else if (form.whatsappNo.isNotBlank()) {
                    "phone_${form.whatsappNo}"
                } else {
                    form.id.toString()
                }
                firestore.collection("swadhyai_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to true, "deletedAt" to now))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai softDelete failed: ${e.message}")
        }
    }

    suspend fun restoreSwadhyaiFormById(id: Long) {
        swadhyaiDao.restoreForm(id)
        try {
            val form = swadhyaiDao.getSwadhyaiFormAnyById(id)
            if (form != null) {
                val firestore = FirebaseFirestore.getInstance()
                val targetDocId = if (form.firestoreDocId.isNotBlank()) {
                    form.firestoreDocId
                } else if (form.whatsappNo.isNotBlank()) {
                    "phone_${form.whatsappNo}"
                } else {
                    form.id.toString()
                }
                firestore.collection("swadhyai_forms")
                    .document(targetDocId)
                    .update(mapOf("isDeleted" to false, "deletedAt" to null))
            }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai restore failed: ${e.message}")
        }
    }

    suspend fun deleteSwadhyaiFormPermanentlyById(id: Long) {
        deleteSwadhyaiFormById(id)
    }

    suspend fun deleteSwadhyaiFormById(id: Long) {
        val existing = swadhyaiDao.getSwadhyaiFormAnyById(id)
        val docIdToDelete = existing?.firestoreDocId?.ifBlank { null }
            ?: existing?.id?.toString()
            ?: id.toString()

        swadhyaiDao.deleteFormPermanentlyById(id)

        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("swadhyai_forms")
                .document(docIdToDelete)
                .delete()
                .addOnSuccessListener {
                    Log.d("FormRepository", "Successfully deleted doc $docIdToDelete from swadhyai_forms")
                }
                .addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to delete doc $docIdToDelete from swadhyai_forms: ${e.message}")
                }
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore swadhyai delete skipped/failed: ${e.message}")
        }
    }

    suspend fun saveAllotment(allotment: AllotmentEntity) {
        allotmentDao?.saveAllotment(allotment)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val data = hashMapOf(
                "sanghId" to allotment.sanghId,
                "sanghName" to allotment.sanghName,
                "cityName" to allotment.cityName,
                "stateName" to allotment.stateName,
                "swadhyaiIds" to allotment.swadhyaiIds,
                "updatedAt" to allotment.updatedAt
            )
            firestore.collection("sangh_allotments")
                .document(allotment.sanghId.toString())
                .set(data)
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore save allotment failed: ${e.message}")
        }
    }

    suspend fun deleteAllotment(sanghId: Long) {
        allotmentDao?.deleteAllotment(sanghId)
        try {
            val firestore = FirebaseFirestore.getInstance()
            firestore.collection("sangh_allotments")
                .document(sanghId.toString())
                .delete()
        } catch (e: Exception) {
            Log.w("FormRepository", "Firestore delete allotment failed: ${e.message}")
        }
    }

    suspend fun prepopulateIfEmpty() {
        if (panchangDao != null) {
            val isInitialSeedDone = prefs?.getBoolean("panchang_initial_seed_done_v2", false) ?: false
            val existing = panchangDao.getAllEventsList()
            if (existing.isEmpty() && !isInitialSeedDone) {
                val deletedDates = getPanchangDeletedDates()
                val userEditedDates = getPanchangUserEditedDates()
                val defaultList = DefaultPanchangSeed.getDefault2026Events().filter {
                    it.dateString.isNotBlank() &&
                    !deletedDates.contains(it.dateString.trim()) &&
                    !userEditedDates.contains(it.dateString.trim())
                }
                // syncToCloud MUST BE FALSE so local initialization never overwrites Firestore cloud collection!
                insertPanchangEvents(defaultList, syncToCloud = false)
                reapplyUserCustomEdits()
                prefs?.edit()?.putBoolean("panchang_initial_seed_done_v2", true)?.apply()
            } else {
                // Ensure all custom edited events are protected and present in Room
                reapplyUserCustomEdits()
            }
        }
    }

    suspend fun insertPanchangEvents(events: List<PanchangEventEntity>, syncToCloud: Boolean = true) {
        if (events.isEmpty()) return
        val now = System.currentTimeMillis()
        val distinctDates = events.map { it.dateString.trim() }.filter { it.isNotEmpty() }.distinct()
        distinctDates.chunked(500).forEach { chunk ->
            panchangDao?.deleteEventsByDates(chunk)
        }
        val deduplicatedEvents = events
            .filter { it.dateString.isNotBlank() }
            .associateBy { it.dateString.trim() }
            .values
            .map { it.copy(id = 0L) }
            .toList()
        panchangDao?.insertEvents(deduplicatedEvents)

        distinctDates.forEach { date ->
            markPanchangDateSaved(date)
        }

        if (!syncToCloud) return

        // Real-time synchronization to Firestore only for explicit manual uploads/imports
        try {
            val firestore = FirebaseFirestore.getInstance()
            deduplicatedEvents.chunked(450).forEach { chunk ->
                val batch = firestore.batch()
                for (item in chunk) {
                    val cleanDate = item.dateString.trim()
                    val docRef = firestore.collection("panchang_events").document(cleanDate)
                    val data = hashMapOf(
                        "dateString" to cleanDate,
                        "dayOfWeek" to item.dayOfWeek,
                        "tithi" to item.tithi,
                        "isImportantTithi" to item.isImportantTithi,
                        "kalyanaks" to item.kalyanaks,
                        "parvasAndEvents" to item.parvasAndEvents,
                        "sunriseTime" to item.sunriseTime,
                        "sunsetTime" to item.sunsetTime,
                        "navkarsiTime" to item.navkarsiTime,
                        "notes" to item.notes,
                        "isDeleted" to false,
                        "updatedAt" to now
                    )
                    batch.set(docRef, data, com.google.firebase.firestore.SetOptions.merge())
                }
                batch.commit().addOnSuccessListener {
                    Log.d("FormRepository", "Panchang events batch synced to Firestore (${chunk.size} events)")
                }.addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to sync panchang batch to Firestore: ${e.message}")
                }
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error syncing panchang events to Firestore: ${e.message}")
        }
    }

    suspend fun insertPanchangEvent(event: PanchangEventEntity) {
        val cleanDate = event.dateString.trim()
        if (cleanDate.isNotBlank()) {
            val now = System.currentTimeMillis()
            panchangDao?.deleteEventByDate(cleanDate)
            panchangDao?.insertEvent(event.copy(id = 0L, dateString = cleanDate))
            
            // Mark user custom edit persistently so it cannot be overwritten by seeds or cloud sync
            markPanchangDateUserEdited(cleanDate, event, now)

            try {
                val firestore = FirebaseFirestore.getInstance()
                val docRef = firestore.collection("panchang_events").document(cleanDate)
                val data = hashMapOf(
                    "dateString" to cleanDate,
                    "dayOfWeek" to event.dayOfWeek,
                    "tithi" to event.tithi,
                    "isImportantTithi" to event.isImportantTithi,
                    "kalyanaks" to event.kalyanaks,
                    "parvasAndEvents" to event.parvasAndEvents,
                    "sunriseTime" to event.sunriseTime,
                    "sunsetTime" to event.sunsetTime,
                    "navkarsiTime" to event.navkarsiTime,
                    "notes" to event.notes,
                    "isDeleted" to false,
                    "isUserEdited" to true,
                    "userEditedAt" to now,
                    "updatedAt" to now
                )
                docRef.set(data, com.google.firebase.firestore.SetOptions.merge()).addOnSuccessListener {
                    Log.d("FormRepository", "Panchang event synced to Firestore: $cleanDate")
                }.addOnFailureListener { e ->
                    Log.e("FormRepository", "Failed to sync panchang event to Firestore: ${e.message}")
                }
            } catch (e: Exception) {
                Log.e("FormRepository", "Error syncing single panchang event to Firestore: ${e.message}")
            }
        }
    }

    suspend fun deletePanchangEvent(id: Long) {
        val existing = panchangDao?.getEventById(id)
        panchangDao?.deleteEvent(id)
        if (existing != null && existing.dateString.isNotBlank()) {
            val cleanDate = existing.dateString.trim()
            markPanchangDateDeleted(cleanDate)
            try {
                val firestore = FirebaseFirestore.getInstance()
                val docRef = firestore.collection("panchang_events").document(cleanDate)
                val tombstone = hashMapOf(
                    "dateString" to cleanDate,
                    "isDeleted" to true,
                    "updatedAt" to System.currentTimeMillis()
                )
                docRef.set(tombstone, com.google.firebase.firestore.SetOptions.merge())
            } catch (e: Exception) {
                Log.e("FormRepository", "Error deleting panchang event from Firestore: ${e.message}")
            }
        }
    }

    suspend fun deletePanchangEventByDate(dateString: String) {
        val cleanDate = dateString.trim()
        if (cleanDate.isNotBlank()) {
            panchangDao?.deleteEventByDate(cleanDate)
            markPanchangDateDeleted(cleanDate)
            try {
                val firestore = FirebaseFirestore.getInstance()
                val docRef = firestore.collection("panchang_events").document(cleanDate)
                val tombstone = hashMapOf(
                    "dateString" to cleanDate,
                    "isDeleted" to true,
                    "updatedAt" to System.currentTimeMillis()
                )
                docRef.set(tombstone, com.google.firebase.firestore.SetOptions.merge())
            } catch (e: Exception) {
                Log.e("FormRepository", "Error deleting panchang event by date from Firestore: ${e.message}")
            }
        }
    }

    suspend fun clearAllPanchangEvents() {
        panchangDao?.clearAllEvents()
        prefs?.edit()?.putBoolean("panchang_initial_seed_done_v2", true)?.apply()
    }

    private suspend fun processCloudPanchangSnapshot(documents: List<DocumentSnapshot>) {
        if (panchangDao == null) return
        val deletedDates = getPanchangDeletedDates()
        val userEditedDates = getPanchangUserEditedDates()
        val eventsToInsert = mutableListOf<PanchangEventEntity>()
        val datesToDeleteLocally = mutableListOf<String>()

        for (doc in documents) {
            try {
                val dateStr = (doc.getString("dateString") ?: doc.id).trim()
                if (dateStr.isBlank()) continue

                val isDeleted = doc.getBoolean("isDeleted") ?: false
                val cloudUpdatedAt = getLongField(doc, "updatedAt", "userEditedAt", "createdAt") ?: 0L
                val cloudIsUserEdited = doc.getBoolean("isUserEdited") ?: false
                val localEditTime = getPanchangLocalDateUpdateTimestamp(dateStr)
                val isLocallyUserEdited = userEditedDates.contains(dateStr)

                if (isDeleted) {
                    markPanchangDateDeleted(dateStr)
                    datesToDeleteLocally.add(dateStr)
                    continue
                }

                // If user deleted this date locally and local delete was after or at cloud time, do not resurrect!
                if (deletedDates.contains(dateStr)) {
                    if (localEditTime >= cloudUpdatedAt) {
                        datesToDeleteLocally.add(dateStr)
                        continue
                    } else {
                        // Cloud update is strictly newer than local delete, unmark deleted
                        markPanchangDateSaved(dateStr)
                    }
                }

                // If user explicitly edited this date locally:
                if (isLocallyUserEdited) {
                    // If cloud document is not an explicit user edit, NEVER overwrite local user's intentional edit!
                    if (!cloudIsUserEdited) {
                        continue
                    }
                    // If local edit is newer or same as cloud, keep local edit!
                    if (localEditTime >= cloudUpdatedAt) {
                        continue
                    }
                } else {
                    // For standard unedited dates: If user modified locally or local time is >= cloud time, do NOT overwrite
                    if (localEditTime >= cloudUpdatedAt && localEditTime > 0L) {
                        continue
                    }
                }

                val entity = PanchangEventEntity(
                    id = 0L,
                    dateString = dateStr,
                    dayOfWeek = doc.getString("dayOfWeek") ?: "",
                    tithi = doc.getString("tithi") ?: "",
                    isImportantTithi = doc.getBoolean("isImportantTithi") ?: false,
                    kalyanaks = doc.getString("kalyanaks") ?: "",
                    parvasAndEvents = doc.getString("parvasAndEvents") ?: "",
                    sunriseTime = doc.getString("sunriseTime") ?: "",
                    sunsetTime = doc.getString("sunsetTime") ?: "",
                    navkarsiTime = doc.getString("navkarsiTime") ?: "",
                    notes = doc.getString("notes") ?: ""
                )
                eventsToInsert.add(entity)

                // If this incoming cloud doc was an explicit user edit that superseded local, update local user edit cache
                if (cloudIsUserEdited) {
                    markPanchangDateUserEdited(dateStr, entity, cloudUpdatedAt)
                }
            } catch (e: Exception) {
                Log.e("FormRepository", "Error processing cloud panchang doc: ${e.message}")
            }
        }

        if (datesToDeleteLocally.isNotEmpty()) {
            datesToDeleteLocally.distinct().chunked(500).forEach { chunk ->
                panchangDao.deleteEventsByDates(chunk)
            }
        }
        if (eventsToInsert.isNotEmpty()) {
            val distinctDates = eventsToInsert.map { it.dateString.trim() }.distinct()
            distinctDates.chunked(500).forEach { chunk ->
                panchangDao.deleteEventsByDates(chunk)
            }
            val deduplicated = eventsToInsert.associateBy { it.dateString.trim() }.values.toList()
            panchangDao.insertEvents(deduplicated)
        }

        // Always re-enforce user custom edits after processing cloud updates as final safeguard!
        reapplyUserCustomEdits()
    }

    fun updateEventVisibility(hiddenCalendar: Set<String>, hiddenRepo: Set<String>) {
        hiddenCalendarEventNames.value = hiddenCalendar
        hiddenRepoEventNames.value = hiddenRepo
        prefs?.edit()
            ?.putStringSet("hidden_calendar_event_names", hiddenCalendar)
            ?.putStringSet("hidden_event_names", hiddenCalendar)
            ?.putStringSet("hidden_repo_event_names", hiddenRepo)
            ?.apply()

        try {
            val firestore = FirebaseFirestore.getInstance()
            val docRef = firestore.collection("app_config").document("panchang_event_visibility")
            docRef.set(
                mapOf(
                    "hiddenCalendarEventNames" to hiddenCalendar.toList(),
                    "hiddenEventNames" to hiddenCalendar.toList(),
                    "hiddenRepoEventNames" to hiddenRepo.toList(),
                    "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                ),
                SetOptions.merge()
            ).addOnSuccessListener {
                Log.d("FormRepository", "Event visibility synced to Firestore: cal=$hiddenCalendar, repo=$hiddenRepo")
            }.addOnFailureListener { e ->
                Log.e("FormRepository", "Failed to sync event visibility to Firestore: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error updating event visibility in Firestore: ${e.message}")
        }
    }

    fun updateHiddenEventNames(hiddenSet: Set<String>) {
        updateEventVisibility(hiddenSet, hiddenRepoEventNames.value)
    }

    suspend fun insertTimelinePost(post: TimelinePostEntity): Long {
        val assignedId = if (post.id == 0L) System.currentTimeMillis() else post.id
        val entityToSave = post.copy(id = assignedId)
        val insertedId = timelineDao?.insertPost(entityToSave) ?: assignedId
        val finalId = if (insertedId != 0L) insertedId else assignedId

        try {
            val firestore = FirebaseFirestore.getInstance()
            val docRef = firestore.collection("timeline_posts").document(finalId.toString())
            val data = hashMapOf(
                "id" to finalId,
                "heading" to entityToSave.heading,
                "subHeading" to entityToSave.subHeading,
                "description" to entityToSave.description,
                "dateEpochMillis" to entityToSave.dateEpochMillis,
                "photoUris" to entityToSave.photoUris,
                "isDeleted" to entityToSave.isDeleted,
                "createdAtEpochMillis" to entityToSave.createdAtEpochMillis,
                "isGyanShalaUpdate" to entityToSave.isGyanShalaUpdate,
                "gyanCategoryId" to entityToSave.gyanCategoryId,
                "gyanTopicId" to entityToSave.gyanTopicId,
                "gyanCategoryName" to entityToSave.gyanCategoryName,
                "gyanTopicTitle" to entityToSave.gyanTopicTitle,
                "isGyanEdit" to entityToSave.isGyanEdit,
                "updatedAt" to System.currentTimeMillis()
            )
            docRef.set(data, SetOptions.merge()).addOnSuccessListener {
                Log.d("FormRepository", "Timeline post synced to Firestore: $finalId")
            }.addOnFailureListener { e ->
                Log.e("FormRepository", "Failed to sync timeline post to Firestore: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error syncing timeline post to Firestore: ${e.message}")
        }
        return finalId
    }

    suspend fun updateTimelinePost(post: TimelinePostEntity) {
        val entityToSave = post.copy(isDeleted = false)
        timelineDao?.insertPost(entityToSave)
        timelineDao?.updatePost(entityToSave)

        try {
            val firestore = FirebaseFirestore.getInstance()
            val docRef = firestore.collection("timeline_posts").document(post.id.toString())
            val data = hashMapOf(
                "id" to post.id,
                "heading" to entityToSave.heading,
                "subHeading" to entityToSave.subHeading,
                "description" to entityToSave.description,
                "dateEpochMillis" to entityToSave.dateEpochMillis,
                "photoUris" to entityToSave.photoUris,
                "isDeleted" to false,
                "createdAtEpochMillis" to entityToSave.createdAtEpochMillis,
                "isGyanShalaUpdate" to entityToSave.isGyanShalaUpdate,
                "gyanCategoryId" to entityToSave.gyanCategoryId,
                "gyanTopicId" to entityToSave.gyanTopicId,
                "gyanCategoryName" to entityToSave.gyanCategoryName,
                "gyanTopicTitle" to entityToSave.gyanTopicTitle,
                "isGyanEdit" to entityToSave.isGyanEdit,
                "updatedAt" to System.currentTimeMillis()
            )
            docRef.set(data, SetOptions.merge()).addOnSuccessListener {
                Log.d("FormRepository", "Timeline post updated in Firestore: ${post.id}")
            }.addOnFailureListener { e ->
                Log.e("FormRepository", "Failed to update timeline post in Firestore: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error updating timeline post in Firestore: ${e.message}")
        }
    }

    suspend fun deleteTimelinePost(postId: Long) {
        timelineDao?.softDeletePost(postId)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val docRef = firestore.collection("timeline_posts").document(postId.toString())
            val data = hashMapOf(
                "isDeleted" to true,
                "updatedAt" to System.currentTimeMillis()
            )
            docRef.set(data, SetOptions.merge()).addOnSuccessListener {
                Log.d("FormRepository", "Timeline post soft deleted in Firestore: $postId")
            }.addOnFailureListener { e ->
                Log.e("FormRepository", "Failed to delete timeline post in Firestore: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error deleting timeline post from Firestore: ${e.message}")
        }
    }

    suspend fun saveRegistrationHistory(history: RegistrationHistoryEntity) {
        registrationHistoryDao?.insertHistory(history)
        try {
            val firestore = FirebaseFirestore.getInstance()
            val data = hashMapOf(
                "year" to history.year,
                "paryushanStartDate" to history.paryushanStartDate,
                "paryushanEndDate" to history.paryushanEndDate,
                "totalSanghCount" to history.totalSanghCount,
                "allottedSanghCount" to history.allottedSanghCount,
                "unallottedSanghCount" to history.unallottedSanghCount,
                "totalAllottedSwadhyayisCount" to history.totalAllottedSwadhyayisCount,
                "totalDonationReceived" to history.totalDonationReceived,
                "archivedAllotmentsJson" to history.archivedAllotmentsJson,
                "archivedUnallottedSanghsJson" to history.archivedUnallottedSanghsJson,
                "archivedSwadhyaiUpdatesJson" to history.archivedSwadhyaiUpdatesJson,
                "archivedSanghFormsJson" to history.archivedSanghFormsJson,
                "createdAt" to history.createdAt
            )
            firestore.collection("registration_history").document(history.year.toString())
                .set(data, SetOptions.merge())
        } catch (e: Exception) {
            Log.e("FormRepository", "Error saving registration history: ${e.message}")
        }
    }

    suspend fun restoreRegistrationHistory(year: Int) {
        val history = registrationHistoryDao?.getHistoryByYear(year) ?: return

        // 1. Restore all Sangh Registrations into Room and Firestore
        try {
            if (history.archivedSanghFormsJson.isNotBlank()) {
                val formsArray = org.json.JSONArray(history.archivedSanghFormsJson)
                for (i in 0 until formsArray.length()) {
                    val obj = formsArray.getJSONObject(i)
                    val sanghForm = jsonToSanghForm(obj)
                    insertForm(sanghForm)
                }
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error restoring sangh forms: ${e.message}")
        }

        // 2. Restore allotments into Room and Firestore
        try {
            if (history.archivedAllotmentsJson.isNotBlank()) {
                val allotmentsArray = org.json.JSONArray(history.archivedAllotmentsJson)
                for (i in 0 until allotmentsArray.length()) {
                    val obj = allotmentsArray.getJSONObject(i)
                    val sanghId = obj.getLong("sanghId")
                    val sanghName = obj.optString("sanghName", "")
                    val cityName = obj.optString("cityName", "")
                    val stateName = obj.optString("stateName", "")
                    val swIds = obj.optString("swadhyaiIds", "")
                    val entity = AllotmentEntity(
                        sanghId = sanghId,
                        sanghName = sanghName,
                        cityName = cityName,
                        stateName = stateName,
                        swadhyaiIds = swIds,
                        updatedAt = System.currentTimeMillis()
                    )
                    allotmentDao?.saveAllotment(entity)

                    // sync to firestore
                    try {
                        FirebaseFirestore.getInstance().collection("sangh_allotments")
                            .document(sanghId.toString())
                            .set(mapOf(
                                "sanghId" to sanghId,
                                "sanghName" to sanghName,
                                "cityName" to cityName,
                                "stateName" to stateName,
                                "swadhyaiIds" to swIds,
                                "updatedAt" to entity.updatedAt
                            ), SetOptions.merge())
                    } catch (e: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error restoring allotments: ${e.message}")
        }

        // 3. Revert swadhyai updates (paryushanCount - 1, remove log line)
        try {
            if (history.archivedSwadhyaiUpdatesJson.isNotBlank()) {
                val swUpdatesArray = org.json.JSONArray(history.archivedSwadhyaiUpdatesJson)
                for (i in 0 until swUpdatesArray.length()) {
                    val obj = swUpdatesArray.getJSONObject(i)
                    val swId = obj.getLong("swadhyaiId")
                    val logLineToRemove = obj.optString("logLine", "")
                    val sw = swadhyaiDao?.getSwadhyaiFormById(swId)
                    if (sw != null) {
                        val newCount = (sw.paryushanCount - 1).coerceAtLeast(0)
                        val newLog = if (logLineToRemove.isNotBlank()) {
                            sw.paryushanHistoryLog.split("\n")
                                .filter { it.trim() != logLineToRemove.trim() && it.isNotBlank() }
                                .joinToString("\n")
                        } else sw.paryushanHistoryLog
                        val updatedSw = sw.copy(paryushanCount = newCount, paryushanHistoryLog = newLog)
                        updateSwadhyaiForm(updatedSw)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error reverting swadhyai updates: ${e.message}")
        }

        // 4. Delete this history record from local and Firestore
        registrationHistoryDao?.deleteByYear(year)
        try {
            FirebaseFirestore.getInstance().collection("registration_history")
                .document(year.toString())
                .delete()
        } catch (e: Exception) {}
    }

    suspend fun archiveParyushanAradhana(
        year: Int,
        paryushanStartDate: String,
        paryushanEndDate: String,
        allFormsList: List<ParyushanFormEntity>,
        allSwadhyaiFormsList: List<SwadhyaiFormEntity>,
        activeAllotmentsList: List<Pair<AllotmentEntity, List<Long>>>,
        allFundTransactionsList: List<FundTransactionEntity>
    ) {
        val swadhyaiMap = allSwadhyaiFormsList.associateBy { it.id }
        val allottedSanghIds = activeAllotmentsList.map { it.first.sanghId }.toSet()
        val unallottedSanghs = allFormsList.filter { !allottedSanghIds.contains(it.id) }

        // 1. Serialize all Sangh forms for complete restoration
        val archivedSanghFormsArray = org.json.JSONArray()
        allFormsList.forEach { form ->
            archivedSanghFormsArray.put(sanghFormToJson(form))
        }

        val archivedAllotmentsArray = org.json.JSONArray()
        var totalAllottedSwadhyayisCount = 0
        var totalDonations = 0.0

        val swadhyaiUpdatesArray = org.json.JSONArray()
        val uniqueAllottedSwadhyayis = mutableSetOf<Long>()

        for ((allotment, swIds) in activeAllotmentsList) {
            val sanghForm = allFormsList.find { it.id == allotment.sanghId }
            val sanghName = sanghForm?.sanghName ?: allotment.sanghName
            val cityName = sanghForm?.cityName ?: allotment.cityName
            val stateName = sanghForm?.stateName ?: allotment.stateName
            val sanghAddress = sanghForm?.sanghAddress ?: ""
            val contact1 = sanghForm?.contact1 ?: ""
            val contact2 = sanghForm?.contact2 ?: ""

            val donation = allFundTransactionsList
                .filter { tx ->
                    !tx.isDeleted && tx.type == "INCOMING" && (
                        (sanghName.isNotBlank() && tx.description.contains(sanghName, ignoreCase = true)) ||
                        (sanghName.isNotBlank() && tx.personName.contains(sanghName, ignoreCase = true))
                    )
                }
                .sumOf { it.amount }
            totalDonations += donation

            val swadhyayisArray = org.json.JSONArray()
            for (swId in swIds) {
                val sw = swadhyaiMap[swId]
                if (sw != null) {
                    totalAllottedSwadhyayisCount++
                    val swObj = org.json.JSONObject().apply {
                        put("swadhyaiId", sw.id)
                        put("fullName", sw.fullName)
                        put("city", sw.city)
                        put("state", sw.state)
                        put("whatsappNo", sw.whatsappNo)
                        put("contactNo", sw.contactNo)
                    }
                    swadhyayisArray.put(swObj)

                    if (!uniqueAllottedSwadhyayis.contains(sw.id)) {
                        uniqueAllottedSwadhyayis.add(sw.id)
                        val logEntry = "Went for Paryushan Aaradhna on- $year - $sanghName / $cityName"
                        val newCount = sw.paryushanCount + 1
                        val newLog = if (sw.paryushanHistoryLog.isBlank()) logEntry else "${sw.paryushanHistoryLog}\n$logEntry"
                        val updatedSw = sw.copy(
                            paryushanCount = newCount,
                            paryushanHistoryLog = newLog
                        )
                        updateSwadhyaiForm(updatedSw)

                        val swUpdateObj = org.json.JSONObject().apply {
                            put("swadhyaiId", sw.id)
                            put("logLine", logEntry)
                        }
                        swadhyaiUpdatesArray.put(swUpdateObj)
                    }
                }
            }

            val sanghObj = if (sanghForm != null) {
                sanghFormToJson(sanghForm).apply {
                    put("swadhyaiIds", allotment.swadhyaiIds)
                    put("donationAmount", donation)
                    put("swadhyayis", swadhyayisArray)
                }
            } else {
                org.json.JSONObject().apply {
                    put("sanghId", allotment.sanghId)
                    put("sanghName", sanghName)
                    put("cityName", cityName)
                    put("stateName", stateName)
                    put("sanghAddress", sanghAddress)
                    put("contact1", contact1)
                    put("contact2", contact2)
                    put("swadhyaiIds", allotment.swadhyaiIds)
                    put("donationAmount", donation)
                    put("swadhyayis", swadhyayisArray)
                }
            }
            archivedAllotmentsArray.put(sanghObj)
        }

        val archivedUnallottedArray = org.json.JSONArray()
        for (unallotted in unallottedSanghs) {
            val uObj = sanghFormToJson(unallotted)
            archivedUnallottedArray.put(uObj)
        }

        val historyEntity = RegistrationHistoryEntity(
            year = year,
            paryushanStartDate = paryushanStartDate,
            paryushanEndDate = paryushanEndDate,
            totalSanghCount = allFormsList.size,
            allottedSanghCount = activeAllotmentsList.size,
            unallottedSanghCount = unallottedSanghs.size,
            totalAllottedSwadhyayisCount = totalAllottedSwadhyayisCount,
            totalDonationReceived = totalDonations,
            archivedAllotmentsJson = archivedAllotmentsArray.toString(),
            archivedUnallottedSanghsJson = archivedUnallottedArray.toString(),
            archivedSwadhyaiUpdatesJson = swadhyaiUpdatesArray.toString(),
            archivedSanghFormsJson = archivedSanghFormsArray.toString(),
            createdAt = System.currentTimeMillis()
        )

        saveRegistrationHistory(historyEntity)

        // Clear active allotments from local Room and Firestore
        allotmentDao?.deleteAll()
        try {
            val firestore = FirebaseFirestore.getInstance()
            activeAllotmentsList.forEach { (allotment, _) ->
                firestore.collection("sangh_allotments").document(allotment.sanghId.toString()).delete()
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error deleting allotments from Firestore: ${e.message}")
        }

        // Clear all active sangh registrations from local Room and Firestore
        formDao.deleteAllActiveForms()
        try {
            val firestore = FirebaseFirestore.getInstance()
            allFormsList.forEach { form ->
                val docId = form.firestoreDocId.ifBlank { form.id.toString() }
                firestore.collection("paryushan_forms").document(docId).delete()
                if (docId != form.id.toString()) {
                    firestore.collection("paryushan_forms").document(form.id.toString()).delete()
                }
            }
        } catch (e: Exception) {
            Log.e("FormRepository", "Error deleting sangh forms from Firestore: ${e.message}")
        }
    }

    private fun sanghFormToJson(form: ParyushanFormEntity): org.json.JSONObject {
        return org.json.JSONObject().apply {
            put("id", form.id)
            put("sanghId", form.id)
            put("firestoreDocId", form.firestoreDocId)
            put("sanghName", form.sanghName)
            put("sanghAddress", form.sanghAddress)
            put("cityName", form.cityName)
            put("stateName", form.stateName)
            put("contact1", form.contact1)
            put("contact2", form.contact2)
            put("mulnayakBhagwan", form.mulnayakBhagwan)
            put("totalFamilies", form.totalFamilies)
            put("hasOtherSangh", form.hasOtherSangh)
            put("gacchList", form.gacchList)
            put("pratikramanTradition", form.pratikramanTradition)
            put("hasMusicianGroup", form.hasMusicianGroup)
            put("callsOutsideMusician", form.callsOutsideMusician)
            put("hasPanchPratikramanPerson", form.hasPanchPratikramanPerson)
            put("hasToiletFacility", form.hasToiletFacility)
            put("aradhanaSamagriList", form.aradhanaSamagriList)
            put("countRaiPratikraman", form.countRaiPratikraman)
            put("countDevasiPratikraman", form.countDevasiPratikraman)
            put("countPravachan", form.countPravachan)
            put("countSandhyaBhakti", form.countSandhyaBhakti)
            put("mainTrustees", form.mainTrustees)
            put("agreedToTerms", form.agreedToTerms)
            put("isDeleted", form.isDeleted)
            put("deletedAt", form.deletedAt ?: org.json.JSONObject.NULL)
            put("createdAt", form.createdAt)
        }
    }

    private fun jsonToSanghForm(obj: org.json.JSONObject): ParyushanFormEntity {
        return ParyushanFormEntity(
            id = obj.optLong("id", obj.optLong("sanghId", 0L)),
            firestoreDocId = obj.optString("firestoreDocId", ""),
            sanghName = obj.optString("sanghName", "श्रीसंघ"),
            sanghAddress = obj.optString("sanghAddress", ""),
            cityName = obj.optString("cityName", ""),
            stateName = obj.optString("stateName", ""),
            contact1 = obj.optString("contact1", ""),
            contact2 = obj.optString("contact2", ""),
            mulnayakBhagwan = obj.optString("mulnayakBhagwan", ""),
            totalFamilies = obj.optString("totalFamilies", ""),
            hasOtherSangh = obj.optString("hasOtherSangh", "नहीं"),
            gacchList = obj.optString("gacchList", ""),
            pratikramanTradition = obj.optString("pratikramanTradition", ""),
            hasMusicianGroup = obj.optString("hasMusicianGroup", "नहीं"),
            callsOutsideMusician = obj.optString("callsOutsideMusician", "नहीं"),
            hasPanchPratikramanPerson = obj.optString("hasPanchPratikramanPerson", "नहीं"),
            hasToiletFacility = obj.optString("hasToiletFacility", "नहीं"),
            aradhanaSamagriList = obj.optString("aradhanaSamagriList", ""),
            countRaiPratikraman = obj.optString("countRaiPratikraman", ""),
            countDevasiPratikraman = obj.optString("countDevasiPratikraman", ""),
            countPravachan = obj.optString("countPravachan", ""),
            countSandhyaBhakti = obj.optString("countSandhyaBhakti", ""),
            mainTrustees = obj.optString("mainTrustees", ""),
            agreedToTerms = obj.optBoolean("agreedToTerms", true),
            isDeleted = obj.optBoolean("isDeleted", false),
            deletedAt = if (obj.has("deletedAt") && !obj.isNull("deletedAt")) obj.optLong("deletedAt") else null,
            createdAt = obj.optLong("createdAt", System.currentTimeMillis())
        )
    }
}


