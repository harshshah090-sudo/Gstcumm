package com.example.data

import com.example.ui.ALL_24_TIRTHANKARAS
import com.example.ui.KalyanakCategory
import com.example.ui.TirthankaraDefinition
import java.text.SimpleDateFormat
import java.util.*

data class CanonicalKalyanakInfo(
    val category: KalyanakCategory,
    val traditionalTithi: String,
    val aliases: List<String> = emptyList()
)

data class CanonicalTirthankaraData(
    val tirthankar: TirthankaraDefinition,
    val kalyanaks: List<CanonicalKalyanakInfo>
)

data class TirthankarDisplayKalyanak(
    val tirthankar: TirthankaraDefinition,
    val category: KalyanakCategory,
    val traditionalTithi: String,
    val formattedDateText: String,
    val eventDateString: String?,
    val event: PanchangEventEntity?,
    val isPresentInCalendar: Boolean,
    val customTitle: String? = null
)

object JainKalyanakRepository {

    val CANONICAL_24_TIRTHANKARAS_KALYANAKS: List<CanonicalTirthankaraData> = listOf(
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[0], // 1. Rishabhdev
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ वदि चौथ", listOf("आषाढ़ वद ४", "आषाढ़ वदि ४", "आषाढ वदि ४", "आषाढ़ वदि चतुर्थी", "ashadh vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "चैत्र वदि नवमी", listOf("चैत्र वद ९", "चैत्र वदि ९", "चैत्र कृष्ण ९", "chaitra vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "चैत्र वदि नवमी", listOf("चैत्र वद ९", "चैत्र वदि ९", "chaitra vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि ग्यारस", listOf("फाल्गुन वद ११", "फाल्गुन वदि ११", "फागुन वदि ११", "फाल्गुन वदि एकादशी", "falgun vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "माघ वदि चौदस", listOf("माघ वद १४", "माघ वदि १४", "माघ वदि चतुर्दशी", "magh vad 14"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[1], // 2. Ajitnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ सुदि पूर्णिमा", listOf("ज्येष्ठ सुद १५", "ज्येष्ठ सुदि १५", "ज्येष्ठ सुदि पूनम", "jyeshtha sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि दशमी", listOf("माघ सुद १०", "माघ सुदि १०", "magh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि दशमी", listOf("माघ सुद १०", "माघ सुदि १०", "magh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि ग्यारस", listOf("पौष सुद ११", "पौष सुदि ११", "पौष सुदि एकादशी", "paush sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि पंचमी", listOf("चैत्र सुद ५", "चैत्र सुदि ५", "chaitra sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[2], // 3. Sambhavnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि आठम", listOf("श्रावण सुद ८", "श्रावण सुदि ८", "श्रावण सुदि अष्टमी", "shravan sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि चौदस", listOf("मार्गशीर्ष सुद १४", "मार्गशीर्ष सुदि १४", "मार्गशीर्ष सुदि चतुर्दशी", "margsirsha sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि पूर्णिमा", listOf("मार्गशीर्ष सुद १५", "मार्गशीर्ष सुदि १५", "मार्गशीर्ष सुदि पूनम", "margsirsha sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक वदि चौथ", listOf("कार्तिक वद ४", "कार्तिक वदि ४", "कार्तिक वदि चतुर्थी", "kartik vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि छठ", listOf("चैत्र सुद ६", "चैत्र सुदि ६", "चैत्र सुदि षष्ठी", "chaitra sud 6"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[3], // 4. Abhinandannath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख सुदि छठ", listOf("वैशाख सुद ६", "वैशाख सुदि ६", "वैशाख सुदि षष्ठी", "vaishakh sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि बारस", listOf("माघ सुद १२", "माघ सुदि १२", "माघ सुदि द्वादशी", "magh sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि बारस", listOf("माघ सुद १२", "माघ सुदि १२", "माघ सुदि द्वादशी", "magh sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि चौदस", listOf("पौष सुद १४", "पौष सुदि १४", "पौष सुदि चतुर्दशी", "paush sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख सुदि आठम", listOf("वैशाख सुद ८", "वैशाख सुदि ८", "वैशाख सुदि अष्टमी", "vaishakh sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[4], // 5. Sumatinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण वदि दूज", listOf("श्रावण वद २", "श्रावण वदि २", "श्रावण वदि द्वितीया", "shravan vad 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "वैशाख सुदि आठम", listOf("वैशाख सुद ८", "वैशाख सुदि ८", "वैशाख सुदि अष्टमी", "vaishakh sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "वैशाख सुदि नवमी", listOf("वैशाख सुद ९", "वैशाख सुदि ९", "vaishakh sud 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि ग्यारस", listOf("चैत्र सुद ११", "चैत्र सुदि ११", "चैत्र सुदि एकादशी", "chaitra sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि ग्यारस", listOf("चैत्र सुद ११", "चैत्र सुदि ११", "चैत्र सुदि एकादशी", "chaitra sud 11"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[5], // 6. Padmaprabha
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "माघ वदि छठ", listOf("माघ वद ६", "माघ वदि ६", "माघ वदि षष्ठी", "magh vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "कार्तिक वदि बारस", listOf("कार्तिक वद १२", "कार्तिक वदि १२", "कार्तिक वदि द्वादशी", "kartik vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "कार्तिक वदि तेरस", listOf("कार्तिक वद १३", "कार्तिक वदि १३", "कार्तिक वदि त्रयोदशी", "kartik vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि पूर्णिमा", listOf("चैत्र सुद १५", "चैत्र सुदि १५", "चैत्र सुदि पूनम", "chaitra sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "मार्गशीर्ष वदि ग्यारस", listOf("मार्गशीर्ष वद ११", "मार्गशीर्ष वदि ११", "मार्गशीर्ष वदि एकादशी", "margsirsha vad 11"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[6], // 7. Suparshvanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "भाद्रपद सुदि आठम", listOf("भाद्रपद सुद ८", "भाद्रपद सुदि ८", "भाद्रपद सुदि अष्टमी", "bhadrapad sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ सुदि बारस", listOf("ज्येष्ठ सुद १२", "ज्येष्ठ सुदि १२", "ज्येष्ठ सुदि द्वादशी", "jyeshtha sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ सुदि तेरस", listOf("ज्येष्ठ सुद १३", "ज्येष्ठ सुदि १३", "ज्येष्ठ सुदि त्रयोदशी", "jyeshtha sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि छठ", listOf("फाल्गुन वद ६", "फाल्गुन वदि ६", "फाल्गुन वदि षष्ठी", "falgun vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन वदि सातम", listOf("फाल्गुन वद ७", "फाल्गुन वदि ७", "फाल्गुन वदि सप्तमी", "falgun vad 7"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[7], // 8. Chandraprabha
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र वदि पंचमी", listOf("चैत्र वद ५", "चैत्र वदि ५", "chaitra vad 5")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "पौष वदि ग्यारस", listOf("पौष वद ११", "पौष वदि ११", "पौष वदि एकादशी", "paush vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "पौष वदि तेरस", listOf("पौष वद १३", "पौष वदि १३", "पौष वदि त्रयोदशी", "paush vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि सातम", listOf("फाल्गुन वद ७", "फाल्गुन वदि ७", "फाल्गुन वदि सप्तमी", "falgun vad 7")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "भाद्रपद सुदि सातम", listOf("भाद्रपद सुद ७", "भाद्रपद सुदि ७", "भाद्रपद सुदि सप्तमी", "bhadrapad sud 7"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[8], // 9. Suvidhinath (Pushpadanta)
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "फाल्गुन वदि नवमी", listOf("फाल्गुन वद ९", "फाल्गुन वदि ९", "falgun vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि एकम", listOf("मार्गशीर्ष सुद १", "मार्गशीर्ष सुदि १", "मार्गशीर्ष सुदि प्रतिपदा", "margsirsha sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि एकम", listOf("मार्गशीर्ष सुद १", "मार्गशीर्ष सुदि १", "मार्गशीर्ष सुदि प्रतिपदा", "margsirsha sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक सुदि तीज", listOf("कार्तिक सुद ३", "कार्तिक सुदि ३", "कार्तिक सुदि तृतीया", "kartik sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "भाद्रपद सुदि नवमी", listOf("भाद्रपद सुद ९", "भाद्रपद सुदि ९", "bhadrapad sud 9"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[9], // 10. Shitalnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र वदि आठम", listOf("चैत्र वद ८", "चैत्र वदि ८", "चैत्र वदि अष्टमी", "chaitra vad 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ वदि बारस", listOf("माघ वद १२", "माघ वदि १२", "माघ वदि द्वादशी", "magh vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ वदि बारस", listOf("माघ वद १२", "माघ वदि १२", "माघ वदि द्वादशी", "magh vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष वदि चौदस", listOf("पौष वद १४", "पौष वदि १४", "पौष वदि चतुर्दशी", "paush vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख वदि दूज", listOf("वैशाख वद २", "वैशाख वदि २", "वैशाख वदि द्वितीया", "vaishakh vad 2"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[10], // 11. Shreyansnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ वदि छठ", listOf("ज्येष्ठ वद ६", "ज्येष्ठ वदि ६", "ज्येष्ठ वदि षष्ठी", "jyeshtha vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "फाल्गुन वदि ग्यारस", listOf("फाल्गुन वद ११", "फाल्गुन वदि ११", "फाल्गुन वदि एकादशी", "falgun vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "फाल्गुन वदि बारस", listOf("फाल्गुन वद १२", "फाल्गुन वदि १२", "फाल्गुन वदि द्वादशी", "falgun vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "माघ वदि अमावस्या", listOf("माघ वद १५", "माघ वदि १५", "माघ अमावस्या", "magh vad 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि पूर्णिमा", listOf("श्रावण सुद १५", "श्रावण सुदि १५", "श्रावण पूर्णिमा", "shravan sud 15"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[11], // 12. Vasupujya
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ वदि नवमी", listOf("आषाढ़ वद ९", "आषाढ़ वदि ९", "ashadh vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "फाल्गुन वदि चौदस", listOf("फाल्गुन वद १४", "फाल्गुन वदि १४", "फाल्गुन वदि चतुर्दशी", "falgun vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "फाल्गुन वदि अमावस्या", listOf("फाल्गुन वद १५", "फाल्गुन वदि १५", "फाल्गुन अमावस्या", "falgun vad 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "माघ सुदि दूज", listOf("माघ सुद २", "माघ सुदि २", "माघ सुदि द्वितीया", "magh sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि तीज", listOf("श्रावण सुद ३", "श्रावण सुदि ३", "श्रावण सुदि तृतीया", "shravan sud 3"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[12], // 13. Vimalnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ वदि बारस", listOf("ज्येष्ठ वद १२", "ज्येष्ठ वदि १२", "ज्येष्ठ वदि द्वादशी", "jyeshtha vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि तीज", listOf("माघ सुद ३", "माघ सुदि ३", "माघ सुदि तृतीया", "magh sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि चौथ", listOf("माघ सुद ४", "माघ सुदि ४", "माघ सुदि चतुर्थी", "magh sud 4")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि छठ", listOf("पौष सुद ६", "पौष सुदि ६", "पौष सुदि षष्ठी", "paush sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "आषाढ़ वदि आठम", listOf("आषाढ़ वद ८", "आषाढ़ वदि ८", "आषाढ़ वदि अष्टमी", "ashadh vad 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[13], // 14. Anantnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "कार्तिक सुदि एकम", listOf("कार्तिक सुद १", "कार्तिक सुदि १", "कार्तिक सुदि प्रतिपदा", "kartik sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि बारस", listOf("ज्येष्ठ वद १२", "ज्येष्ठ वदि १२", "ज्येष्ठ वदि द्वादशी", "jyeshtha vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि तेरस", listOf("ज्येष्ठ वद १३", "ज्येष्ठ वदि १३", "ज्येष्ठ वदि त्रयोदशी", "jyeshtha vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख सुदि पूर्णिमा", listOf("वैशाख सुद १५", "वैशाख सुदि १५", "वैशाख सुदि पूनम", "vaishakh sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि पंचमी", listOf("चैत्र सुद ५", "चैत्र सुदि ५", "chaitra sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[14], // 15. Dharmanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख सुदि आठम", listOf("वैशाख सुद ८", "वैशाख सुदि ८", "वैशाख सुदि अष्टमी", "vaishakh sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि तेरस", listOf("माघ सुद १३", "माघ सुदि १३", "माघ सुदि त्रयोदशी", "magh sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि तेरस", listOf("माघ सुद १३", "माघ सुदि १३", "माघ सुदि त्रयोदशी", "magh sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि पूर्णिमा", listOf("पौष सुद १५", "पौष सुदि १५", "पौष सुदि पूनम", "paush sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "ज्येष्ठ सुदि पंचमी", listOf("ज्येष्ठ सुद ५", "ज्येष्ठ सुदि ५", "jyeshtha sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[15], // 16. Shantinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "भाद्रपद वदि सातम", listOf("भाद्रपद वद ७", "भाद्रपद वदि ७", "भाद्रपद वदि सप्तमी", "bhadrapad vad 7")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि तेरस", listOf("ज्येष्ठ वद १३", "ज्येष्ठ वदि १३", "ज्येष्ठ वदि त्रयोदशी", "jyeshtha vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि चौदस", listOf("ज्येष्ठ वद १४", "ज्येष्ठ वदि १४", "ज्येष्ठ वदि चतुर्दशी", "jyeshtha vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि नवमी", listOf("पौष सुद ९", "पौष सुदि ९", "paush sud 9")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "ज्येष्ठ सुदि तेरस", listOf("ज्येष्ठ सुद १३", "ज्येष्ठ सुदि १३", "ज्येष्ठ सुदि त्रयोदशी", "jyeshtha sud 13"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[16], // 17. Kunthunath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि दशमी", listOf("श्रावण सुद १०", "श्रावण सुदि १०", "shravan sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "वैशाख सुदि चौदस", listOf("वैशाख सुद १४", "वैशाख सुदि १४", "वैशाख सुदि चतुर्दशी", "vaishakh sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "वैशाख सुदि पूर्णिमा", listOf("वैशाख सुद १५", "वैशाख सुदि १५", "वैशाख सुदि पूनम", "vaishakh sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि तीज", listOf("चैत्र सुद ३", "चैत्र सुदि ३", "चैत्र सुदि तृतीया", "chaitra sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख सुदि एकम", listOf("वैशाख सुद १", "वैशाख सुदि १", "वैशाख सुदि प्रतिपदा", "vaishakh sud 1"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[17], // 18. Aranath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "फाल्गुन सुदि तीज", listOf("फाल्गुन सुद ३", "फाल्गुन सुदि ३", "फाल्गुन सुदि तृतीया", "falgun sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि दशमी", listOf("मार्गशीर्ष सुद १०", "मार्गशीर्ष सुदि १०", "margsirsha sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि ग्यारस", listOf("मार्गशीर्ष सुद ११", "मार्गशीर्ष सुदि ११", "मार्गशीर्ष सुदि एकादशी", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक सुदि बारस", listOf("कार्तिक सुद १२", "कार्तिक सुदि १२", "कार्तिक सुदि द्वादशी", "kartik sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "मार्गशीर्ष सुदि दशमी", listOf("मार्गशीर्ष सुद १०", "मार्गशीर्ष सुदि १०", "margsirsha sud 10"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[18], // 19. Mallinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र सुदि एकम", listOf("चैत्र सुद १", "चैत्र सुदि १", "चैत्र सुदि प्रतिपदा", "chaitra sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि ग्यारस", listOf("मार्गशीर्ष सुद ११", "मार्गशीर्ष सुदि ११", "मार्गशीर्ष सुदि एकादशी", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि ग्यारस", listOf("मार्गशीर्ष सुद ११", "मार्गशीर्ष सुदि ११", "मार्गशीर्ष सुदि एकादशी", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि दूज", listOf("पौष सुद २", "पौष सुदि २", "पौष सुदि द्वितीया", "paush sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन सुदि बारस", listOf("फाल्गुन सुद १२", "फाल्गुन सुदि १२", "फाल्गुन सुदि द्वादशी", "falgun sud 12"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[19], // 20. Munisuvratnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि दूज", listOf("श्रावण सुद २", "श्रावण सुदि २", "श्रावण सुदि द्वितीया", "shravan sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि आठम", listOf("ज्येष्ठ वद ८", "ज्येष्ठ वदि ८", "ज्येष्ठ वदि अष्टमी", "jyeshtha vad 8")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि नवमी", listOf("ज्येष्ठ वद ९", "ज्येष्ठ वदि ९", "jyeshtha vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख वदि नवमी", listOf("वैशाख वद ९", "वैशाख वदि ९", "vaishakh vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन वदि बारस", listOf("फाल्गुन वद १२", "फाल्गुन वदि १२", "फाल्गुन वदि द्वादशी", "falgun vad 12"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[20], // 21. Naminath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आश्विन सुदि दूज", listOf("आसो सुद २", "आश्विन सुद २", "आश्विन सुदि २", "ashwin sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "आषाढ़ वदि दशमी", listOf("आषाढ़ वद १०", "आषाढ़ वदि १०", "ashadh vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "आषाढ़ वदि दशमी", listOf("आषाढ़ वद १०", "आषाढ़ वदि १०", "ashadh vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "मार्गशीर्ष सुदि ग्यारस", listOf("मार्गशीर्ष सुद ११", "मार्गशीर्ष सुदि ११", "मार्गशीर्ष सुदि एकादशी", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख वदि चौदस", listOf("वैशाख वद १४", "वैशाख वदि १४", "वैशाख वदि चतुर्दशी", "vaishakh vad 14"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[21], // 22. Neminath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "कार्तिक सुदि बारस", listOf("कार्तिक सुद १२", "कार्तिक सुदि १२", "कार्तिक सुदि द्वादशी", "kartik sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "श्रावण सुदि पूर्णिमा", listOf("श्रावण सुद १५", "श्रावण सुदि १५", "shravan sud 15", "श्रावण पूर्णिमा")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "श्रावण सुदि पूर्णिमा", listOf("श्रावण सुद १५", "श्रावण सुदि १५", "shravan sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "आश्विन सुदि एकम", listOf("आसो सुद १", "आश्विन सुद १", "आश्विन सुदि १", "ashwin sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "आषाढ़ सुदि आठम", listOf("आषाढ़ सुद ८", "आषाढ़ सुदि ८", "आषाढ़ सुदि अष्टमी", "ashadh sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[22], // 23. Parshvanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख वदि दूज", listOf("वैशाख वद २", "वैशाख वदि २", "वैशाख वदि द्वितीया", "vaishakh vad 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "पौष वदि दशमी", listOf("पौष वद १०", "पौष वदि १०", "paush vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "पौष वदि ग्यारस", listOf("पौष वद ११", "पौष वदि ११", "पौष वदि एकादशी", "paush vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र वदि चौथ", listOf("चैत्र वद ४", "चैत्र वदि ४", "चैत्र वदि चतुर्थी", "chaitra vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि आठम", listOf("श्रावण सुद ८", "श्रावण सुदि ८", "श्रावण सुदि अष्टमी", "shravan sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[23], // 24. Mahavira Swami
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ सुदि छठ", listOf("आषाढ़ सुद ६", "आषाढ़ सुदि ६", "आषाढ़ सुदि षष्ठी", "ashadh sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "चैत्र सुदि तेरस", listOf("चैत्र सुद १३", "चैत्र सुदि १३", "महावीर जयंती", "chaitra sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष वदि दशमी", listOf("मार्गशीर्ष वद १०", "मार्गशीर्ष वदि १०", "margsirsha vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख सुदि दशमी", listOf("वैशाख सुद १०", "वैशाख सुदि १०", "vaishakh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "कार्तिक वदि चौदस", listOf("कार्तिक वद १४", "कार्तिक वदि १४", "कार्तिक वदि अमावस्या", "कार्तिक वदि अमावस", "दीपावली", "kartik vad 14"))
            )
        )
    )

    /**
     * Converts any raw tithi (e.g. "श्रावण सुदि Terash (१३)", "कार्तिक वदि १२", "कार्तिक वदि (तेरस)")
     * into complete clean Hindi text without bracketed day names like (तेरस) or numerical digits.
     */
    fun convertTithiToHindiWords(rawTithi: String): String {
        var text = rawTithi.trim()
        if (text.isBlank() || text == "—" || text == "-") return text

        val isVadi = text.contains("वदि") || text.contains("वद") || text.contains("कृष्ण") ||
                text.contains("vad", ignoreCase = true) || text.contains("vadi", ignoreCase = true) || text.contains("krishna", ignoreCase = true)

        // 1. Convert English transliterations of tithis
        val englishReplacements = listOf(
            Regex("(?i)\\b(amavasya|amavas)\\b") to "अमावस्या",
            Regex("(?i)\\b(poonam|purnima|poornima)\\b") to "पूर्णिमा",
            Regex("(?i)\\b(chaudas|chaturdashi|choudas)\\b") to "चौदस",
            Regex("(?i)\\b(terash|teras|trayodashi)\\b") to "तेरस",
            Regex("(?i)\\b(baras|barash|dwadashi)\\b") to "बारस",
            Regex("(?i)\\b(agiyaras|agyaras|ekadashi)\\b") to "ग्यारस",
            Regex("(?i)\\b(dasham|dashami)\\b") to "दशमी",
            Regex("(?i)\\b(nom|navmi|navami)\\b") to "नवमी",
            Regex("(?i)\\b(aatham|atham|ashtami)\\b") to "आठम",
            Regex("(?i)\\b(satam|saptami)\\b") to "सातम",
            Regex("(?i)\\b(chhath|chhathh|shashti)\\b") to "छठ",
            Regex("(?i)\\b(pancham|panchami)\\b") to "पंचमी",
            Regex("(?i)\\b(choth|chaturthi)\\b") to "चौथ",
            Regex("(?i)\\b(teej|tritiya)\\b") to "तीज",
            Regex("(?i)\\b(bij|bheej|dooj|dwitiya)\\b") to "दूज",
            Regex("(?i)\\b(ekam|pratipada|padwa)\\b") to "एकम"
        )
        for ((regex, replacement) in englishReplacements) {
            text = text.replace(regex, replacement)
        }

        // 2. Remove bracketed content if day name already exists outside brackets
        val hasDayNameOutside = listOf("एकम", "दूज", "तीज", "चौथ", "पंचमी", "छठ", "सातम", "आठम", "नवमी", "दशमी", "ग्यारस", "बारस", "तेरस", "चौदस", "पूर्णिमा", "अमावस्या")
            .any { text.replace(Regex("\\([^)]*\\)"), "").contains(it) }

        if (hasDayNameOutside) {
            text = text.replace(Regex("\\s*\\([^)]*\\)"), "")
        } else {
            // Remove the brackets themselves (e.g. "(तेरस)" -> "तेरस", "(१३)" -> "१३")
            text = text.replace("(", " ").replace(")", " ")
        }

        // 3. Convert numbers to Hindi words
        val numberReplacements = listOf(
            Regex("(?<!\\d)(15|१५)(?!\\d)") to if (isVadi) "अमावस्या" else "पूर्णिमा",
            Regex("(?<!\\d)(30|३०)(?!\\d)") to "अमावस्या",
            Regex("(?<!\\d)(14|१४)(?!\\d)") to "चौदस",
            Regex("(?<!\\d)(13|१३)(?!\\d)") to "तेरस",
            Regex("(?<!\\d)(12|१२)(?!\\d)") to "बारस",
            Regex("(?<!\\d)(11|११)(?!\\d)") to "ग्यारस",
            Regex("(?<!\\d)(10|१०)(?!\\d)") to "दशमी",
            Regex("(?<!\\d)(9|९)(?!\\d)") to "नवमी",
            Regex("(?<!\\d)(8|८)(?!\\d)") to "आठम",
            Regex("(?<!\\d)(7|७)(?!\\d)") to "सातम",
            Regex("(?<!\\d)(6|६)(?!\\d)") to "छठ",
            Regex("(?<!\\d)(5|५)(?!\\d)") to "पंचमी",
            Regex("(?<!\\d)(4|४)(?!\\d)") to "चौथ",
            Regex("(?<!\\d)(3|३)(?!\\d)") to "तीज",
            Regex("(?<!\\d)(2|२)(?!\\d)") to "दूज",
            Regex("(?<!\\d)(1|१)(?!\\d)") to "एकम"
        )

        for ((regex, replacement) in numberReplacements) {
            text = text.replace(regex, replacement)
        }

        // Remove any lingering parentheses or bracket artifacts
        text = text.replace("(", "").replace(")", "").replace("[", "").replace("]", "")

        return text.replace(Regex("\\s+"), " ").trim()
    }

    /**
     * Resolves ONLY the Tirthankaras and specific Kalyanak events that are EXPLICITLY present in the active calendar [allEvents].
     * A Kalyanak is included ONLY if an event's `kalyanaks` field is populated in the calendar (or `parvasAndEvents` explicitly contains "कल्याणक").
     * Non-present Tirthankaras and unmentioned/canonical placeholder Kalyanaks are completely excluded.
     */
    fun resolvePresentInCalendarTirthankarKalyanaks(
        allEvents: List<PanchangEventEntity>
    ): List<Pair<TirthankaraDefinition, List<TirthankarDisplayKalyanak>>> {
        val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outSdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

        // 1. Filter only events from the calendar that actually have a Kalyanak presented
        val kalyanakEvents = allEvents.filter { event ->
            val kText = event.kalyanaks.trim()
            val pText = event.parvasAndEvents.trim()
            kText.isNotBlank() ||
            pText.contains("कल्याणक", ignoreCase = true) ||
            pText.contains("kalyanak", ignoreCase = true)
        }

        if (kalyanakEvents.isEmpty()) return emptyList()

        // Map of Tirthankara -> list of matched calendar Kalyanaks
        val tirthankarKalyanaksMap = mutableMapOf<TirthankaraDefinition, MutableList<TirthankarDisplayKalyanak>>()

        kalyanakEvents.forEach { event ->
            val kText = event.kalyanaks.trim()
            val pText = event.parvasAndEvents.trim()

            // Source text to extract kalyanaks from: prefer kalyanaks field, else explicit kalyanak lines in parvas
            val sourceChunks = if (kText.isNotBlank()) {
                kText.split("/", ";", "\n", "|", "•", " एवं ", " और ", " तथा ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
            } else {
                pText.split("/", ";", "\n", "|", "•", " एवं ", " और ", " तथा ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() && (it.contains("कल्याणक", ignoreCase = true) || it.contains("kalyanak", ignoreCase = true)) }
            }

            val formattedDate = try {
                val parsed = inSdf.parse(event.dateString)
                if (parsed != null) outSdf.format(parsed) else event.dateString
            } catch (_: Exception) {
                event.dateString
            }

            sourceChunks.forEach { chunkText ->
                // Match with Tirthankara definitions
                val matchedTirthankaras = ALL_24_TIRTHANKARAS.filter { tirthankar ->
                    tirthankar.aliases.any { alias ->
                        chunkText.contains(alias, ignoreCase = true)
                    }
                }

                // If no specific Tirthankara matched, try matching from the overall kText/event
                val targetTirthankaras = if (matchedTirthankaras.isNotEmpty()) {
                    matchedTirthankaras
                } else {
                    ALL_24_TIRTHANKARAS.filter { tirthankar ->
                        tirthankar.aliases.any { alias ->
                            kText.contains(alias, ignoreCase = true)
                        }
                    }
                }

                // Detect category from chunk text
                val detectedCat = when {
                    chunkText.contains("च्यवन", ignoreCase = true) || chunkText.contains("गर्भ", ignoreCase = true) || chunkText.contains("chyavan", ignoreCase = true) -> KalyanakCategory.CHYAVAN
                    chunkText.contains("जन्म", ignoreCase = true) || chunkText.contains("प्राकट्य", ignoreCase = true) || chunkText.contains("janma", ignoreCase = true) || chunkText.contains("birth", ignoreCase = true) -> KalyanakCategory.JANMA
                    chunkText.contains("दीक्षा", ignoreCase = true) || chunkText.contains("तप", ignoreCase = true) || chunkText.contains("वैराग्य", ignoreCase = true) || chunkText.contains("diksha", ignoreCase = true) -> KalyanakCategory.DIKSHA
                    chunkText.contains("केवलज्ञान", ignoreCase = true) || chunkText.contains("केवल", ignoreCase = true) || chunkText.contains("kevalgyan", ignoreCase = true) || chunkText.contains("kevalgnyan", ignoreCase = true) || chunkText.contains("ज्ञान", ignoreCase = true) -> KalyanakCategory.KEVALGYAN
                    chunkText.contains("निर्वाण", ignoreCase = true) || chunkText.contains("मोक्ष", ignoreCase = true) || chunkText.contains("nirvan", ignoreCase = true) || chunkText.contains("nirvana", ignoreCase = true) || chunkText.contains("moksh", ignoreCase = true) -> KalyanakCategory.NIRVANA
                    else -> KalyanakCategory.NIRVANA
                }

                if (targetTirthankaras.isNotEmpty()) {
                    targetTirthankaras.forEach { tirthankar ->
                        val displayTitle = extractKalyanakNameWithoutTirthankar(chunkText, tirthankar, detectedCat)
                        val formattedTithi = convertTithiToHindiWords(event.tithi).ifBlank { "—" }
                        val kalyanak = TirthankarDisplayKalyanak(
                            tirthankar = tirthankar,
                            category = detectedCat,
                            traditionalTithi = formattedTithi,
                            formattedDateText = formattedDate,
                            eventDateString = event.dateString,
                            event = event,
                            isPresentInCalendar = true,
                            customTitle = displayTitle
                        )
                        tirthankarKalyanaksMap.getOrPut(tirthankar) { mutableListOf() }.add(kalyanak)
                    }
                }
            }
        }

        // Return only Tirthankaras that actually have at least one Kalyanak present in the calendar
        return tirthankarKalyanaksMap.entries
            .map { (tirthankar, kalyanaks) ->
                val distinctKalyanaks = kalyanaks
                    .distinctBy { (it.eventDateString ?: "") to it.category to (it.customTitle ?: "") }
                    .sortedWith(compareBy({ it.eventDateString ?: "" }, { it.category.order }))
                Pair(tirthankar, distinctKalyanaks)
            }
            .sortedBy { it.first.number }
    }

    /**
     * Extracts only the Kalyanak name (e.g., "जन्म कल्याणक", "निर्वाण कल्याणक") by stripping
     * any Tirthankara names, aliases, and honorific prefixes (श्री, स्वामी, प्रभु, भगवान, etc.).
     */
    fun extractKalyanakNameWithoutTirthankar(
        chunkText: String,
        tirthankar: TirthankaraDefinition,
        category: KalyanakCategory
    ): String {
        var cleaned = chunkText
        // Remove specific Tirthankara aliases
        for (alias in tirthankar.aliases) {
            cleaned = cleaned.replace(alias, "", ignoreCase = true)
        }
        // Remove general Tirthankara aliases if present
        for (t in ALL_24_TIRTHANKARAS) {
            for (alias in t.aliases) {
                cleaned = cleaned.replace(alias, "", ignoreCase = true)
            }
        }
        // Remove common honorific and punctuation words
        val honorifics = listOf("श्री", "प्रभु", "स्वामी", "भगवान", "देव", "जिनेन्द्र", "प्रभू", "तीर्थंकर", "गणधर", "गौतम", "जी", "·", "•", "-", ":", "।", "॥")
        for (h in honorifics) {
            cleaned = cleaned.replace(h, "", ignoreCase = true)
        }

        // Remove connecting particles like 'का', 'के', 'की', 'नो', 'नी', 'ना' (e.g. "का केवलज्ञान कल्याणक" -> "केवलज्ञान कल्याणक")
        cleaned = cleaned.replace(Regex("\\b(का|के|की|नो|नी|ना|ka|ke|ki)\\b", RegexOption.IGNORE_CASE), " ")
        cleaned = cleaned.replace(Regex("^\\s*(का|के|की|नो|नी|ना|ka|ke|ki)\\s+", RegexOption.IGNORE_CASE), "")
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim().trim(',', '-', ':', '·', '•').trim()

        val finalName = if (cleaned.isNotBlank() && (cleaned.contains("कल्याणक", ignoreCase = true) || cleaned.contains("kalyanak", ignoreCase = true))) {
            cleaned
        } else {
            category.rawHindiName
        }

        return cleanKalyanakTitle(finalName, category.rawHindiName)
    }

    /**
     * Helper to safely remove any 'का' or other particles before a Kalyanak name
     */
    fun cleanKalyanakTitle(rawTitle: String?, fallback: String): String {
        if (rawTitle.isNullOrBlank()) return fallback
        var res = rawTitle.trim()
        res = res.replace(Regex("^\\s*(का|के|की|नो|नी|ना|ka|ke|ki)\\s+", RegexOption.IGNORE_CASE), "")
        res = res.replace(Regex("\\b(का|के|की|नो|नी|ना)\\b"), " ")
        res = res.replace(Regex("\\s+"), " ").trim().trim(',', '-', ':', '·', '•').trim()
        return res.ifBlank { fallback }
    }
}
