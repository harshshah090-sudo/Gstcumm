package com.example.data

import com.example.ui.ALL_24_TIRTHANKARAS
import com.example.ui.KalyanakCategory
import com.example.ui.TirthankaraDefinition
import java.text.SimpleDateFormat
import java.util.*

data class CanonicalKalyanakInfo(
    val category: KalyanakCategory,
    val traditionalTithi: String,
    val aliases: List<String> = emptyList()
)

data class CanonicalTirthankaraData(
    val tirthankar: TirthankaraDefinition,
    val kalyanaks: List<CanonicalKalyanakInfo>
)

data class TirthankarDisplayKalyanak(
    val tirthankar: TirthankaraDefinition,
    val category: KalyanakCategory,
    val traditionalTithi: String,
    val formattedDateText: String,
    val eventDateString: String?,
    val event: PanchangEventEntity?,
    val isPresentInCalendar: Boolean,
    val customTitle: String? = null
)

object JainKalyanakRepository {

    val CANONICAL_24_TIRTHANKARAS_KALYANAKS: List<CanonicalTirthankaraData> = listOf(
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[0], // 1. Rishabhdev
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ वदि ४", listOf("आषाढ़ वद ४", "आषाढ वदि ४", "ashadh vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "चैत्र वदि ९", listOf("चैत्र वद ९", "चैत्र कृष्ण ९", "chaitra vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "चैत्र वदि ९", listOf("चैत्र वद ९", "chaitra vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि ११", listOf("फाल्गुन वद ११", "फागुन वदि ११", "falgun vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "माघ वदि १४", listOf("माघ वद १४", "magh vad 14"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[1], // 2. Ajitnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ सुदि १५", listOf("ज्येष्ठ सुद १५", "jyeshtha sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि १०", listOf("माघ सुद १०", "magh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि १०", listOf("माघ सुद १०", "magh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि ११", listOf("पौष सुद ११", "paush sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि ५", listOf("चैत्र सुद ५", "chaitra sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[2], // 3. Sambhavnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि ८", listOf("श्रावण सुद ८", "shravan sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि १४", listOf("मार्गशीर्ष सुद १४", "margsirsha sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि १५", listOf("मार्गशीर्ष सुद १५", "margsirsha sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक वदि ४", listOf("कार्तिक वद ४", "kartik vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि ६", listOf("चैत्र सुद ६", "chaitra sud 6"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[3], // 4. Abhinandannath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख सुदि ६", listOf("वैशाख सुद ६", "vaishakh sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि १२", listOf("माघ सुद १२", "magh sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि १२", listOf("माघ सुद १२", "magh sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि १४", listOf("पौष सुद १४", "paush sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख सुदि ८", listOf("वैशाख सुद ८", "vaishakh sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[4], // 5. Sumatinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण वदि २", listOf("श्रावण वद २", "shravan vad 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "वैशाख सुदि ८", listOf("वैशाख सुद ८", "vaishakh sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "वैशाख सुदि ९", listOf("वैशाख सुद ९", "vaishakh sud 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि ११", listOf("चैत्र सुद ११", "chaitra sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि ११", listOf("चैत्र सुद ११", "chaitra sud 11"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[5], // 6. Padmaprabha
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "माघ वदि ६", listOf("माघ वद ६", "magh vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "कार्तिक वदि १२", listOf("कार्तिक वद १२", "kartik vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "कार्तिक वदि १३", listOf("कार्तिक वद १३", "kartik vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि १५", listOf("चैत्र सुद १५", "chaitra sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "मार्गशीर्ष वदि ११", listOf("मार्गशीर्ष वद ११", "margsirsha vad 11"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[6], // 7. Suparshvanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "भाद्रपद सुदि ८", listOf("भाद्रपद सुद ८", "bhadrapad sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ सुदि १२", listOf("ज्येष्ठ सुद १२", "jyeshtha sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ सुदि १३", listOf("ज्येष्ठ सुद १३", "jyeshtha sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि ६", listOf("फाल्गुन वद ६", "falgun vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन वदि ७", listOf("फाल्गुन वद ७", "falgun vad 7"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[7], // 8. Chandraprabha
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र वदि ५", listOf("चैत्र वद ५", "chaitra vad 5")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "पौष वदि ११", listOf("पौष वद ११", "paush vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "पौष वदि १३", listOf("पौष वद १३", "paush vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "फाल्गुन वदि ७", listOf("फाल्गुन वद ७", "falgun vad 7")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "भाद्रपद सुदि ७", listOf("भाद्रपद सुद ७", "bhadrapad sud 7"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[8], // 9. Suvidhinath (Pushpadanta)
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "फाल्गुन वदि ९", listOf("फाल्गुन वद ९", "falgun vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि १", listOf("मार्गशीर्ष सुद १", "margsirsha sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि १", listOf("मार्गशीर्ष सुद १", "margsirsha sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक सुदि ३", listOf("कार्तिक सुद ३", "kartik sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "भाद्रपद सुदि ९", listOf("भाद्रपद सुद ९", "bhadrapad sud 9"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[9], // 10. Shitalnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र वदि ८", listOf("चैत्र वद ८", "chaitra vad 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ वदि १२", listOf("माघ वद १२", "magh vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ वदि १२", listOf("माघ वद १२", "magh vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष वदि १४", listOf("पौष वद १४", "paush vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख वदि २", listOf("वैशाख वद २", "vaishakh vad 2"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[10], // 11. Shreyansnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ वदि ६", listOf("ज्येष्ठ वद ६", "jyeshtha vad 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "फाल्गुन वदि ११", listOf("फाल्गुन वद ११", "falgun vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "फाल्गुन वदि १२", listOf("फाल्गुन वद १२", "falgun vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "माघ वदि १५", listOf("माघ वद १५", "माघ अमावस्या", "magh vad 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि १५", listOf("श्रावण सुद १५", "श्रावण पूर्णिमा", "shravan sud 15"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[11], // 12. Vasupujya
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ वदि ९", listOf("आषाढ़ वद ९", "ashadh vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "फाल्गुन वदि १४", listOf("फाल्गुन वद १४", "falgun vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "फाल्गुन वदि १५", listOf("फाल्गुन वद १५", "फाल्गुन अमावस्या", "falgun vad 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "माघ सुदि २", listOf("माघ सुद २", "magh sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि ३", listOf("श्रावण सुद ३", "shravan sud 3"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[12], // 13. Vimalnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "ज्येष्ठ वदि १२", listOf("ज्येष्ठ वद १२", "jyeshtha vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि ३", listOf("माघ सुद ३", "magh sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि ४", listOf("माघ सुद ४", "magh sud 4")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि ६", listOf("पौष सुद ६", "paush sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "आषाढ़ वदि ८", listOf("आषाढ़ वद ८", "ashadh vad 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[13], // 14. Anantnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "कार्तिक सुदि १", listOf("कार्तिक सुद १", "kartik sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि १२", listOf("ज्येष्ठ वद १२", "jyeshtha vad 12")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि १३", listOf("ज्येष्ठ वद १३", "jyeshtha vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख सुदि १५", listOf("वैशाख सुद १५", "vaishakh sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "चैत्र सुदि ५", listOf("चैत्र सुद ५", "chaitra sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[14], // 15. Dharmanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख सुदि ८", listOf("वैशाख सुद ८", "vaishakh sud 8")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "माघ सुदि १३", listOf("माघ सुद १३", "magh sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "माघ सुदि १३", listOf("माघ सुद १३", "magh sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि १५", listOf("पौष सुद १५", "paush sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "ज्येष्ठ सुदि ५", listOf("ज्येष्ठ सुद ५", "jyeshtha sud 5"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[15], // 16. Shantinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "भाद्रपद वदि ७", listOf("भाद्रपद वद ७", "bhadrapad vad 7")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि १३", listOf("ज्येष्ठ वद १३", "jyeshtha vad 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि १४", listOf("ज्येष्ठ वद १४", "jyeshtha vad 14")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि ९", listOf("पौष सुद ९", "paush sud 9")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "ज्येष्ठ सुदि १३", listOf("ज्येष्ठ सुद १३", "jyeshtha sud 13"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[16], // 17. Kunthunath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि १०", listOf("श्रावण सुद १०", "shravan sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "वैशाख सुदि १४", listOf("वैशाख सुद १४", "vaishakh sud 14")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "वैशाख सुदि १५", listOf("वैशाख सुद १५", "vaishakh sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र सुदि ३", listOf("चैत्र सुद ३", "chaitra sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख सुदि १", listOf("वैशाख सुद १", "vaishakh sud 1"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[17], // 18. Aranath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "फाल्गुन सुदि ३", listOf("फाल्गुन सुद ३", "falgun sud 3")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि १०", listOf("मार्गशीर्ष सुद १०", "margsirsha sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि ११", listOf("मार्गशीर्ष सुद ११", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "कार्तिक सुदि १२", listOf("कार्तिक सुद १२", "kartik sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "मार्गशीर्ष सुदि १०", listOf("मार्गशीर्ष सुद १०", "margsirsha sud 10"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[18], // 19. Mallinath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "चैत्र सुदि १", listOf("चैत्र सुद १", "chaitra sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "मार्गशीर्ष सुदि ११", listOf("मार्गशीर्ष सुद ११", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष सुदि ११", listOf("मार्गशीर्ष सुद ११", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "पौष सुदि २", listOf("पौष सुद २", "paush sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन सुदि १२", listOf("फाल्गुन सुद १२", "falgun sud 12"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[19], // 20. Munisuvratnath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "श्रावण सुदि २", listOf("श्रावण सुद २", "shravan sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "ज्येष्ठ वदि ८", listOf("ज्येष्ठ वद ८", "jyeshtha vad 8")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "ज्येष्ठ वदि ९", listOf("ज्येष्ठ वद ९", "jyeshtha vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख वदि ९", listOf("वैशाख वद ९", "vaishakh vad 9")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "फाल्गुन वदि १२", listOf("फाल्गुन वद १२", "falgun vad 12"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[20], // 21. Naminath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आश्विन सुदि २", listOf("आसो सुद २", "ashwin sud 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "आषाढ़ वदि १०", listOf("आषाढ़ वद १०", "ashadh vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "आषाढ़ वदि १०", listOf("आषाढ़ वद १०", "ashadh vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "मार्गशीर्ष सुदि ११", listOf("मार्गशीर्ष सुद ११", "margsirsha sud 11")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "वैशाख वदि १४", listOf("वैशाख वद १४", "vaishakh vad 14"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[21], // 22. Neminath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "कार्तिक सुदि १२", listOf("कार्तिक सुद १२", "kartik sud 12")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "श्रावण सुदि १५", listOf("श्रावण सुद १५", "shravan sud 15", "श्रावण पूर्णिमा")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "श्रावण सुदि १५", listOf("श्रावण सुद १५", "shravan sud 15")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "आश्विन सुदि १", listOf("आसो सुद १", "ashwin sud 1")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "आषाढ़ सुदि ८", listOf("आषाढ़ सुद ८", "ashadh sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[22], // 23. Parshvanath
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "वैशाख वदि २", listOf("वैशाख वद २", "vaishakh vad 2")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "पौष वदि १०", listOf("पौष वद १०", "paush vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "पौष वदि ११", listOf("पौष वद ११", "paush vad 11")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "चैत्र वदि ४", listOf("चैत्र वद ४", "chaitra vad 4")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "श्रावण सुदि ८", listOf("श्रावण सुद ८", "shravan sud 8"))
            )
        ),
        CanonicalTirthankaraData(
            tirthankar = ALL_24_TIRTHANKARAS[23], // 24. Mahavira Swami
            kalyanaks = listOf(
                CanonicalKalyanakInfo(KalyanakCategory.CHYAVAN, "आषाढ़ सुदि ६", listOf("आषाढ़ सुद ६", "ashadh sud 6")),
                CanonicalKalyanakInfo(KalyanakCategory.JANMA, "चैत्र सुदि १३", listOf("चैत्र सुद १३", "महावीर जयंती", "chaitra sud 13")),
                CanonicalKalyanakInfo(KalyanakCategory.DIKSHA, "मार्गशीर्ष वदि १०", listOf("मार्गशीर्ष वद १०", "margsirsha vad 10")),
                CanonicalKalyanakInfo(KalyanakCategory.KEVALGYAN, "वैशाख सुदि १०", listOf("वैशाख सुद १०", "vaishakh sud 10")),
                CanonicalKalyanakInfo(KalyanakCategory.NIRVANA, "कार्तिक वदि १४", listOf("कार्तिक वद १४", "कार्तिक वदि अमावस", "दीपावली", "kartik vad 14"))
            )
        )
    )

    /**
     * Resolves ONLY the Tirthankaras and specific Kalyanak events that are EXPLICITLY present in the active calendar [allEvents].
     * A Kalyanak is included ONLY if an event's `kalyanaks` field is populated in the calendar (or `parvasAndEvents` explicitly contains "कल्याणक").
     * Non-present Tirthankaras and unmentioned/canonical placeholder Kalyanaks are completely excluded.
     */
    fun resolvePresentInCalendarTirthankarKalyanaks(
        allEvents: List<PanchangEventEntity>
    ): List<Pair<TirthankaraDefinition, List<TirthankarDisplayKalyanak>>> {
        val inSdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val outSdf = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

        // 1. Filter only events from the calendar that actually have a Kalyanak presented
        val kalyanakEvents = allEvents.filter { event ->
            val kText = event.kalyanaks.trim()
            val pText = event.parvasAndEvents.trim()
            kText.isNotBlank() ||
            pText.contains("कल्याणक", ignoreCase = true) ||
            pText.contains("kalyanak", ignoreCase = true)
        }

        if (kalyanakEvents.isEmpty()) return emptyList()

        // Map of Tirthankara -> list of matched calendar Kalyanaks
        val tirthankarKalyanaksMap = mutableMapOf<TirthankaraDefinition, MutableList<TirthankarDisplayKalyanak>>()

        kalyanakEvents.forEach { event ->
            val kText = event.kalyanaks.trim()
            val pText = event.parvasAndEvents.trim()

            // Source text to extract kalyanaks from: prefer kalyanaks field, else explicit kalyanak lines in parvas
            val sourceChunks = if (kText.isNotBlank()) {
                kText.split("/", ";", "\n", "|", "•", " एवं ", " और ", " तथा ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
            } else {
                pText.split("/", ";", "\n", "|", "•", " एवं ", " और ", " तथा ")
                    .map { it.trim() }
                    .filter { it.isNotBlank() && (it.contains("कल्याणक", ignoreCase = true) || it.contains("kalyanak", ignoreCase = true)) }
            }

            val formattedDate = try {
                val parsed = inSdf.parse(event.dateString)
                if (parsed != null) outSdf.format(parsed) else event.dateString
            } catch (_: Exception) {
                event.dateString
            }

            sourceChunks.forEach { chunkText ->
                // Match with Tirthankara definitions
                val matchedTirthankaras = ALL_24_TIRTHANKARAS.filter { tirthankar ->
                    tirthankar.aliases.any { alias ->
                        chunkText.contains(alias, ignoreCase = true)
                    }
                }

                // If no specific Tirthankara matched, try matching from the overall kText/event
                val targetTirthankaras = if (matchedTirthankaras.isNotEmpty()) {
                    matchedTirthankaras
                } else {
                    ALL_24_TIRTHANKARAS.filter { tirthankar ->
                        tirthankar.aliases.any { alias ->
                            kText.contains(alias, ignoreCase = true)
                        }
                    }
                }

                // Detect category from chunk text
                val detectedCat = when {
                    chunkText.contains("च्यवन", ignoreCase = true) || chunkText.contains("गर्भ", ignoreCase = true) || chunkText.contains("chyavan", ignoreCase = true) -> KalyanakCategory.CHYAVAN
                    chunkText.contains("जन्म", ignoreCase = true) || chunkText.contains("प्राकट्य", ignoreCase = true) || chunkText.contains("janma", ignoreCase = true) || chunkText.contains("birth", ignoreCase = true) -> KalyanakCategory.JANMA
                    chunkText.contains("दीक्षा", ignoreCase = true) || chunkText.contains("तप", ignoreCase = true) || chunkText.contains("वैराग्य", ignoreCase = true) || chunkText.contains("diksha", ignoreCase = true) -> KalyanakCategory.DIKSHA
                    chunkText.contains("केवलज्ञान", ignoreCase = true) || chunkText.contains("केवल", ignoreCase = true) || chunkText.contains("kevalgyan", ignoreCase = true) || chunkText.contains("kevalgnyan", ignoreCase = true) || chunkText.contains("ज्ञान", ignoreCase = true) -> KalyanakCategory.KEVALGYAN
                    chunkText.contains("निर्वाण", ignoreCase = true) || chunkText.contains("मोक्ष", ignoreCase = true) || chunkText.contains("nirvan", ignoreCase = true) || chunkText.contains("nirvana", ignoreCase = true) || chunkText.contains("moksh", ignoreCase = true) -> KalyanakCategory.NIRVANA
                    else -> KalyanakCategory.NIRVANA
                }

                if (targetTirthankaras.isNotEmpty()) {
                    targetTirthankaras.forEach { tirthankar ->
                        val displayTitle = extractKalyanakNameWithoutTirthankar(chunkText, tirthankar, detectedCat)
                        val kalyanak = TirthankarDisplayKalyanak(
                            tirthankar = tirthankar,
                            category = detectedCat,
                            traditionalTithi = event.tithi.ifBlank { "—" },
                            formattedDateText = formattedDate,
                            eventDateString = event.dateString,
                            event = event,
                            isPresentInCalendar = true,
                            customTitle = displayTitle
                        )
                        tirthankarKalyanaksMap.getOrPut(tirthankar) { mutableListOf() }.add(kalyanak)
                    }
                }
            }
        }

        // Return only Tirthankaras that actually have at least one Kalyanak present in the calendar
        return tirthankarKalyanaksMap.entries
            .map { (tirthankar, kalyanaks) ->
                val distinctKalyanaks = kalyanaks
                    .distinctBy { (it.eventDateString ?: "") to it.category to (it.customTitle ?: "") }
                    .sortedWith(compareBy({ it.eventDateString ?: "" }, { it.category.order }))
                Pair(tirthankar, distinctKalyanaks)
            }
            .sortedBy { it.first.number }
    }

    /**
     * Extracts only the Kalyanak name (e.g., "जन्म कल्याणक", "निर्वाण कल्याणक") by stripping
     * any Tirthankara names, aliases, and honorific prefixes (श्री, स्वामी, प्रभु, भगवान, etc.).
     */
    fun extractKalyanakNameWithoutTirthankar(
        chunkText: String,
        tirthankar: TirthankaraDefinition,
        category: KalyanakCategory
    ): String {
        var cleaned = chunkText
        // Remove specific Tirthankara aliases
        for (alias in tirthankar.aliases) {
            cleaned = cleaned.replace(alias, "", ignoreCase = true)
        }
        // Remove general Tirthankara aliases if present
        for (t in ALL_24_TIRTHANKARAS) {
            for (alias in t.aliases) {
                cleaned = cleaned.replace(alias, "", ignoreCase = true)
            }
        }
        // Remove common honorific and punctuation words
        val honorifics = listOf("श्री", "प्रभु", "स्वामी", "भगवान", "देव", "जिनेन्द्र", "प्रभू", "तीर्थंकर", "·", "•", "-", ":", "।", "॥")
        for (h in honorifics) {
            cleaned = cleaned.replace(h, "", ignoreCase = true)
        }
        cleaned = cleaned.replace(Regex("\\s+"), " ").trim().trim(',', '-', ':', '·', '•').trim()

        return if (cleaned.isNotBlank() && (cleaned.contains("कल्याणक", ignoreCase = true) || cleaned.contains("kalyanak", ignoreCase = true))) {
            cleaned
        } else {
            category.rawHindiName
        }
    }
}
