package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AllotmentDao {
    @Query("SELECT * FROM sangh_allotments ORDER BY updatedAt DESC")
    fun getAllAllotments(): Flow<List<AllotmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveAllotment(allotment: AllotmentEntity)

    @Query("DELETE FROM sangh_allotments WHERE sanghId = :sanghId")
    suspend fun deleteAllotment(sanghId: Long)

    @Query("DELETE FROM sangh_allotments WHERE sanghId NOT IN (:validSanghIds)")
    suspend fun deleteNotIn(validSanghIds: List<Long>)

    @Query("DELETE FROM sangh_allotments")
    suspend fun deleteAll()
}
