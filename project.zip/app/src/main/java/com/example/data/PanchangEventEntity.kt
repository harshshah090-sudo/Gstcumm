package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "panchang_events")
data class PanchangEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateString: String, // ISO Format YYYY-MM-DD e.g. "2026-04-19"
    val dayOfWeek: String = "", // e.g. "Sunday" / "रविवार"
    val tithi: String = "", // e.g. "Vaisakha Sud Dooj" / "वैशाख सुद २"
    val isImportantTithi: Boolean = false, // true for Agiyaras, Chaudas, Aatham, Poonam, Amas
    val kalyanaks: String = "", // e.g. "Shri Mahavir Swami Janma Kalyanak"
    val parvasAndEvents: String = "", // e.g. "Akshaya Tritiya", "Paryushan Day 1"
    val sunriseTime: String = "", // e.g. "06:12 AM"
    val sunsetTime: String = "", // e.g. "06:48 PM"
    val navkarsiTime: String = "", // e.g. "07:00 AM"
    val notes: String = ""
)
