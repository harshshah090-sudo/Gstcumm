package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SwadhyaiDao {
    @Query("SELECT * FROM swadhyai_forms WHERE isDeleted = 0 ORDER BY createdAt DESC")
    fun getAllSwadhyaiForms(): Flow<List<SwadhyaiFormEntity>>

    @Query("SELECT * FROM swadhyai_forms WHERE isDeleted = 1 ORDER BY deletedAt DESC")
    fun getDeletedSwadhyaiForms(): Flow<List<SwadhyaiFormEntity>>

    @Query("SELECT * FROM swadhyai_forms WHERE id = :id AND isDeleted = 0")
    suspend fun getSwadhyaiFormById(id: Long): SwadhyaiFormEntity?

    @Query("SELECT * FROM swadhyai_forms WHERE id = :id")
    suspend fun getSwadhyaiFormAnyById(id: Long): SwadhyaiFormEntity?

    @Query("SELECT id FROM swadhyai_forms WHERE isDeleted = 1")
    suspend fun getSoftDeletedIds(): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertForm(form: SwadhyaiFormEntity): Long

    @Update
    suspend fun updateForm(form: SwadhyaiFormEntity)

    @Query("UPDATE swadhyai_forms SET isDeleted = 1, deletedAt = :deletedAt WHERE id = :id")
    suspend fun softDeleteForm(id: Long, deletedAt: Long = System.currentTimeMillis())

    @Query("UPDATE swadhyai_forms SET isDeleted = 0, deletedAt = NULL WHERE id = :id")
    suspend fun restoreForm(id: Long)

    @Delete
    suspend fun deleteForm(form: SwadhyaiFormEntity)

    @Query("DELETE FROM swadhyai_forms WHERE id = :id")
    suspend fun deleteFormPermanentlyById(id: Long)

    @Query("DELETE FROM swadhyai_forms WHERE isDeleted = 1 AND deletedAt < :cutoff")
    suspend fun purgeOldDeletedForms(cutoff: Long)

    @Query("DELETE FROM swadhyai_forms WHERE id NOT IN (:validIds) AND isDeleted = 0")
    suspend fun deleteFormsNotIn(validIds: List<Long>)

    @Query("DELETE FROM swadhyai_forms WHERE isDeleted = 0")
    suspend fun deleteAllActiveForms()

    @Query("DELETE FROM swadhyai_forms WHERE TRIM(fullName) = '' OR (TRIM(fullName) = 'स्वाध्यायी' AND TRIM(whatsappNo) = '' AND TRIM(contactNo) = '')")
    suspend fun deleteBlankForms()

    @Query("SELECT COUNT(*) FROM swadhyai_forms WHERE isDeleted = 0")
    suspend fun getCount(): Int
}
