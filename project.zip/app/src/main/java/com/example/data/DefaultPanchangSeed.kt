package com.example.data

object DefaultPanchangSeed {

    fun getDefault2026Events(): List<PanchangEventEntity> {
        return listOf(
            // Mahavir Jayanti 2026
            PanchangEventEntity(
                dateString = "2026-03-31",
                dayOfWeek = "Tuesday / मंगलवार",
                tithi = "Chaitra Sud Terash (१३)",
                isImportantTithi = true,
                kalyanaks = "Shri Mahavir Swami Janma Kalyanak (महावीर जन्म कल्याणक)",
                parvasAndEvents = "भगवान महावीर जन्म कल्याणक महोत्सव",
                sunriseTime = "06:22 AM",
                sunsetTime = "06:42 PM",
                navkarsiTime = "07:10 AM",
                notes = "महावीर जयंती महापर्व"
            ),
            // Akshaya Tritiya 2026
            PanchangEventEntity(
                dateString = "2026-04-19",
                dayOfWeek = "Sunday / रविवार",
                tithi = "Vaisakha Sud Teej (३)",
                isImportantTithi = false,
                kalyanaks = "Shri Rishabhdev Bhagwan Ikshaku Vansh Ikshu-ras Parna",
                parvasAndEvents = "अक्षय तृतीया (अखात्रीज) - वर्षीतप पारणा",
                sunriseTime = "06:05 AM",
                sunsetTime = "06:50 PM",
                navkarsiTime = "06:53 AM",
                notes = "वर्षीतप पारणा दिवस"
            ),
            // Ayambil Oli Spring 2026 Start
            PanchangEventEntity(
                dateString = "2026-03-23",
                dayOfWeek = "Monday / सोमवार",
                tithi = "Chaitra Sud Aatham (८)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "नवपद ओलीजी प्रारंभ (चैत्र ओली)",
                sunriseTime = "06:28 AM",
                sunsetTime = "06:38 PM",
                navkarsiTime = "07:16 AM",
                notes = "श्री सिद्धचक्र नवपद ओलीजी प्रथम दिन"
            ),
            // Paryushan 2026 Tapagacch Day 1
            PanchangEventEntity(
                dateString = "2026-09-08",
                dayOfWeek = "Tuesday / मंगलवार",
                tithi = "Bhadrapad Vad Dwadashi (१२)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "पर्यूषण महापर्व प्रथम दिवस (स्वाध्याय प्रारंभ)",
                sunriseTime = "06:14 AM",
                sunsetTime = "06:40 PM",
                navkarsiTime = "07:02 AM",
                notes = "अमारी प्रवर्तन एवं खाद्य संयम"
            ),
            // Paryushan 2026 Mahavir Janm Vanchan
            PanchangEventEntity(
                dateString = "2026-09-12",
                dayOfWeek = "Saturday / शनिवार",
                tithi = "Bhadrapad Vad Amavasya (३०) / Sud Ekam",
                isImportantTithi = true,
                kalyanaks = "Shri Mahavir Swami Janm Vanchan",
                parvasAndEvents = "श्री महावीर स्वामी जन्म वांचन महोत्सव",
                sunriseTime = "06:15 AM",
                sunsetTime = "06:36 PM",
                navkarsiTime = "07:03 AM",
                notes = "कल्पसूत्र जन्म वांचन हर्षोल्लास"
            ),
            // Paryushan 2026 Samvatsari
            PanchangEventEntity(
                dateString = "2026-09-15",
                dayOfWeek = "Tuesday / मंगलवार",
                tithi = "Bhadrapad Sud Chauth (४)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "महापर्व संवत्सरी - सर्व जीव क्षमापना",
                sunriseTime = "06:16 AM",
                sunsetTime = "06:33 PM",
                navkarsiTime = "07:04 AM",
                notes = "वार्षिक संवत्सरी प्रतिक्रमण एवं मिच्छामि दुक्कडम्"
            ),
            // Diwali & Mahavir Nirvan 2026
            PanchangEventEntity(
                dateString = "2026-11-08",
                dayOfWeek = "Sunday / रविवार",
                tithi = "Karthik Vad Amavasya (१५/३०)",
                isImportantTithi = true,
                kalyanaks = "Shri Mahavir Swami Moksha / Nirvan Kalyanak",
                parvasAndEvents = "दीपावली - श्री महावीर स्वामी मोक्ष कल्याणक",
                sunriseTime = "06:38 AM",
                sunsetTime = "05:42 PM",
                navkarsiTime = "07:26 AM",
                notes = "निर्वाण लाडू समर्पण एवं दीप मालिका"
            ),
            // New Year (Nutan Varsh) 2026
            PanchangEventEntity(
                dateString = "2026-11-09",
                dayOfWeek = "Monday / सोमवार",
                tithi = "Karthik Sud Ekam (१)",
                isImportantTithi = false,
                kalyanaks = "Shri Gautam Swami Kevaljnana Kalyanak",
                parvasAndEvents = "वीर संवत नूतन वर्ष - गौतम स्वामी केवलज्ञान",
                sunriseTime = "06:39 AM",
                sunsetTime = "05:41 PM",
                navkarsiTime = "07:27 AM",
                notes = "वीर निर्वाण संवत नूतन वर्ष प्रारंभ"
            ),
            // Gyan Panchami 2026
            PanchangEventEntity(
                dateString = "2026-11-13",
                dayOfWeek = "Friday / शुक्रवार",
                tithi = "Karthik Sud Pancham (५)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "ज्ञान पंचमी (सौभाग्य पंचमी)",
                sunriseTime = "06:42 AM",
                sunsetTime = "05:39 PM",
                navkarsiTime = "07:30 AM",
                notes = "देव-शास्त्र गुरु पूजन एवं ज्ञान आराधना"
            ),
            // Dev Diwali / Kartiki Poornima 2026
            PanchangEventEntity(
                dateString = "2026-11-23",
                dayOfWeek = "Monday / सोमवार",
                tithi = "Karthik Sud Poonam (१५)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "कार्तिकी पूर्णिमा (देव दिवाली) - शत्रुंजय चातुर्मासिक यात्रा",
                sunriseTime = "06:49 AM",
                sunsetTime = "05:37 PM",
                navkarsiTime = "07:37 AM",
                notes = "चातुर्मास समाप्ति एवं शत्रुंजय तीर्थ यात्रा प्रारंभ"
            )
        )
    }
}
