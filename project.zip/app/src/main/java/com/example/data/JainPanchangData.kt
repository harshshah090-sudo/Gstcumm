package com.example.data

import java.util.Calendar

data class JainEvent(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val dateString: String, // YYYY-MM-DD
    val month: Int, // 1 to 12
    val day: Int,
    val year: Int,
    val tithiHindi: String,
    val category: JainEventCategory,
    val description: String,
    val fastingRule: String = ""
)

enum class JainEventCategory(val labelHindi: String, val labelEnglish: String) {
    MAHAPARVA("महापर्व / उत्सव", "Mahaparva & Festivals"),
    KALYANAK("तीर्थंकर कल्याणक", "Tirthankar Kalyanaks"),
    TITHI_FASTING("तिथि / उपवास", "Fasting Tithis"),
    OLI_PARVA("नवपद ओली", "Navpad Oli")
}

data class DayPanchang(
    val dateString: String,
    val year: Int,
    val month: Int,
    val day: Int,
    val tithiName: String,
    val paksha: String, // Sud / Vad
    val masNameHindi: String, // Bhadrapad, Chaitra, Kartik etc.
    val vikramSamvat: Int,
    val sunriseTime: String = "06:12 AM",
    val sunsetTime: String = "06:48 PM",
    val navkarsiTime: String = "07:00 AM",
    val chauviharTime: String = "06:36 PM",
    val events: List<JainEvent> = emptyList(),
    val isAthamOrChaudas: Boolean = false
)

object JainPanchangRepository {

    val supportedYears = listOf(2025, 2026, 2027)

    private val masterEvents = listOf(
        // 2025 Major Events
        JainEvent(
            id = "e_2025_04_10",
            titleHindi = "महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2025-04-10",
            month = 4, day = 10, year = 2025,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी २५४५वां जन्म कल्याणक महोत्सव। अहिंसा और सत्य का संदेश।",
            fastingRule = "विशेष जाप एवं नवकारसी"
        ),
        JainEvent(
            id = "e_2025_04_30",
            titleHindi = "अक्षय तृतीया (वर्षीतप पारणा)",
            titleEnglish = "Akshaya Tritiya (Varshitap Parna)",
            dateString = "2025-04-30",
            month = 4, day = 30, year = 2025,
            tithiHindi = "वैशाख सुद ३",
            category = JainEventCategory.MAHAPARVA,
            description = "प्रथम तीर्थंकर भगवान ऋषभदेव का इक्षुरस से पारणा एवं वर्षीतप पूर्णता।",
            fastingRule = "इक्षुरस (गन्ने का रस) पारणा"
        ),
        JainEvent(
            id = "e_2025_08_20",
            titleHindi = "पर्यूषण महापर्व प्रारम्भ (तपागच्छ)",
            titleEnglish = "Paryushan Mahaparva Start (Tapagacch)",
            dateString = "2025-08-20",
            month = 8, day = 20, year = 2025,
            tithiHindi = "भाद्रपद वद १२",
            category = JainEventCategory.MAHAPARVA,
            description = "८ दिवसीय आत्मशुद्धि का महाउत्सव पर्यूषण पर्व प्रारम्भ।",
            fastingRule = "अठ्ठाई / एकाशन / उपवास साधना"
        ),
        JainEvent(
            id = "e_2025_08_24",
            titleHindi = "भगवान महावीर जन्म वांचन",
            titleEnglish = "Mahavir Janm Vanchan",
            dateString = "2025-08-24",
            month = 8, day = 24, year = 2025,
            tithiHindi = "भाद्रपद सुद २",
            category = JainEventCategory.MAHAPARVA,
            description = "कल्पसूत्र ग्रन्थ से भगवान महावीर जन्म वांचन एवं १४ स्वप्न महोत्सव।",
            fastingRule = "उपवास / आयम्बिल"
        ),
        JainEvent(
            id = "e_2025_08_27",
            titleHindi = "संवत्सरी महापर्व (तपागच्छ)",
            titleEnglish = "Samvatsari Mahaparva (Tapagacch)",
            dateString = "2025-08-27",
            month = 8, day = 27, year = 2025,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "संवत्सरी प्रतिक्रमण एवं क्षमापना दिवस। 'मिच्छामि दुक्कडम्' - सब जीवों से क्षमा।",
            fastingRule = "अनिवार्य उपवास (उपवास / पौषध)"
        ),
        JainEvent(
            id = "e_2025_08_28",
            titleHindi = "संवत्सरी महापर्व (स्थानकवासी)",
            titleEnglish = "Samvatsari Mahaparva (Sthanakvasi)",
            dateString = "2025-08-28",
            month = 8, day = 28, year = 2025,
            tithiHindi = "भाद्रपद सुद ६",
            category = JainEventCategory.MAHAPARVA,
            description = "स्थानकवासी परंपरा अनुसार संवत्सरी महाप्रतिक्रमण एवं क्षमापना।",
            fastingRule = "अनिवार्य उपवास"
        ),
        JainEvent(
            id = "e_2025_10_20",
            titleHindi = "भगवान महावीर निर्वाण (दीपावली)",
            titleEnglish = "Mahavir Nirvan (Diwali)",
            dateString = "2025-10-20",
            month = 10, day = 20, year = 2025,
            tithiHindi = "कार्तिक वद अमावस्या",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी का मोक्ष गमन (निर्वाण) एवं गौतम स्वामी केवलज्ञान।",
            fastingRule = "वीर निर्वाण जाप एवं एकाशन"
        ),
        JainEvent(
            id = "e_2025_10_25",
            titleHindi = "ज्ञान पंचमी",
            titleEnglish = "Gyan Panchami",
            dateString = "2025-10-25",
            month = 10, day = 25, year = 2025,
            tithiHindi = "कार्तिक सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "ज्ञान पूजा, शास्त्र पूजन एवं देव-वंदन।",
            fastingRule = "देववंदन एवं ज्ञान पूजा"
        ),
        JainEvent(
            id = "e_2025_11_05",
            titleHindi = "कार्तिक पूनम (देव दिवाली)",
            titleEnglish = "Kartik Poonam (Dev Diwali)",
            dateString = "2025-11-05",
            month = 11, day = 5, year = 2025,
            tithiHindi = "कार्तिक सुद १५",
            category = JainEventCategory.MAHAPARVA,
            description = "शत्रुंजय महातीर्थ यात्रा प्रारम्भ एवं चातुर्मास निष्क्रमण।",
            fastingRule = "शत्रुंजय गिरिराज भाव यात्रा"
        ),

        // 2026 Major Events
        JainEvent(
            id = "e_2026_03_31",
            titleHindi = "महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2026-03-31",
            month = 3, day = 31, year = 2026,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी २५४६वां जन्म कल्याणक महोत्सव।",
            fastingRule = "विशेष जाप एवं पूजा"
        ),
        JainEvent(
            id = "e_2026_04_19",
            titleHindi = "अक्षय तृतीया (वर्षीतप पारणा)",
            titleEnglish = "Akshaya Tritiya (Varshitap Parna)",
            dateString = "2026-04-19",
            month = 4, day = 19, year = 2026,
            tithiHindi = "वैशाख सुद ३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान ऋषभदेव का इक्षुरस पारणा।",
            fastingRule = "इक्षुरस पारणा"
        ),
        JainEvent(
            id = "e_2026_09_09",
            titleHindi = "पर्यूषण महापर्व प्रारम्भ (तपागच्छ)",
            titleEnglish = "Paryushan Mahaparva Start (Tapagacch)",
            dateString = "2026-09-09",
            month = 9, day = 9, year = 2026,
            tithiHindi = "भाद्रपद वद १२",
            category = JainEventCategory.MAHAPARVA,
            description = "पर्यूषण महापर्व प्रारम्भ।",
            fastingRule = "अठ्ठाई / तपश्चर्या"
        ),
        JainEvent(
            id = "e_2026_09_13",
            titleHindi = "भगवान महावीर जन्म वांचन",
            titleEnglish = "Mahavir Janm Vanchan",
            dateString = "2026-09-13",
            month = 9, day = 13, year = 2026,
            tithiHindi = "भाद्रपद सुद २",
            category = JainEventCategory.MAHAPARVA,
            description = "जन्म वांचन एवं १४ स्वप्न दर्शन।",
            fastingRule = "उपवास / एकाशन"
        ),
        JainEvent(
            id = "e_2026_09_16",
            titleHindi = "संवत्सरी महापर्व (तपागच्छ)",
            titleEnglish = "Samvatsari Mahaparva (Tapagacch)",
            dateString = "2026-09-16",
            month = 9, day = 16, year = 2026,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "संघात प्रतिक्रमण एवं विश्व क्षमापना दिवस। 'मिच्छामि दुक्कडम्'।",
            fastingRule = "अनिवार्य उपवास"
        ),
        JainEvent(
            id = "e_2026_11_08",
            titleHindi = "भगवान महावीर निर्वाण (दीपावली)",
            titleEnglish = "Mahavir Nirvan (Diwali)",
            dateString = "2026-11-08",
            month = 11, day = 8, year = 2026,
            tithiHindi = "कार्तिक वद अमावस्या",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी निर्वाण दिवस।",
            fastingRule = "वीर निर्वाण एकाशन / जाप"
        ),

        // 2027 Major Events
        JainEvent(
            id = "e_2027_04_19",
            titleHindi = "महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2027-04-19",
            month = 4, day = 19, year = 2027,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी २५४७वां जन्म कल्याणक।",
            fastingRule = "विशेष जाप"
        ),
        JainEvent(
            id = "e_2027_08_29",
            titleHindi = "संवत्सरी महापर्व",
            titleEnglish = "Samvatsari Mahaparva",
            dateString = "2027-08-29",
            month = 8, day = 29, year = 2027,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "संवत्सरी प्रतिक्रमण एवं सर्व जीव क्षमापना।",
            fastingRule = "अनिवार्य उपवास"
        )
    )

    fun getEventsForMonth(year: Int, month: Int): List<JainEvent> {
        return masterEvents.filter { it.year == year && it.month == month }
    }

    fun getAllEventsForYear(year: Int): List<JainEvent> {
        return masterEvents.filter { it.year == year }.sortedBy { String.format("%02d-%02d", it.month, it.day) }
    }

    fun getDayPanchang(year: Int, month: Int, day: Int): DayPanchang {
        val dateKey = String.format("%04d-%02d-%02d", year, month, day)
        val matchedEvents = masterEvents.filter { it.dateString == dateKey }

        val cal = Calendar.getInstance().apply {
            set(year, month - 1, day)
        }
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        // Approximate calculation for Tithi calculation & Vikram Samvat
        val vikramSamvat = year + 57
        val isSud = (day % 2 != 0)
        val pakshaStr = if (isSud) "सुद" else "वद"
        val tithiNum = ((day % 15) + 1)
        val masNames = listOf("चैत्र", "वैशाख", "ज्येष्ठ", "आषाढ़", "श्रावण", "भाद्रपद", "आश्विन", "कार्तिक", "मार्गशीर्ष", "पौष", "माघ", "फाल्गुन")
        val masName = masNames[(month + 2) % 12]

        val tithiFull = "$masName $pakshaStr $tithiNum"

        val isAthamOrChaudas = (tithiNum == 8 || tithiNum == 14)

        return DayPanchang(
            dateString = dateKey,
            year = year,
            month = month,
            day = day,
            tithiName = tithiFull,
            paksha = pakshaStr,
            masNameHindi = masName,
            vikramSamvat = vikramSamvat,
            sunriseTime = "06:14 AM",
            sunsetTime = "06:42 PM",
            navkarsiTime = "07:02 AM",
            chauviharTime = "06:30 PM",
            events = matchedEvents,
            isAthamOrChaudas = isAthamOrChaudas
        )
    }
}
