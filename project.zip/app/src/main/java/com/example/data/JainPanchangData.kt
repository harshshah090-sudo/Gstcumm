package com.example.data

import java.util.Calendar

data class JainEvent(
    val id: String,
    val titleHindi: String,
    val titleEnglish: String,
    val dateString: String, // YYYY-MM-DD
    val month: Int, // 1 to 12
    val day: Int,
    val year: Int,
    val tithiHindi: String,
    val category: JainEventCategory,
    val description: String,
    val fastingRule: String = ""
)

enum class JainEventCategory(val labelHindi: String, val labelEnglish: String) {
    MAHAPARVA("महापर्व / उत्सव", "Mahaparva & Festivals"),
    KALYANAK("तीर्थंकर कल्याणक", "Tirthankar Kalyanaks"),
    TITHI_FASTING("तिथि / उपवास", "Fasting Tithis"),
    OLI_PARVA("नवपद ओली", "Navpad Oli")
}

data class DayPanchang(
    val dateString: String,
    val year: Int,
    val month: Int,
    val day: Int,
    val tithiName: String,
    val paksha: String, // Sud / Vad
    val masNameHindi: String, // Bhadrapad, Chaitra, Kartik etc.
    val vikramSamvat: Int,
    val sunriseTime: String = "06:12 AM",
    val sunsetTime: String = "06:48 PM",
    val navkarsiTime: String = "07:00 AM",
    val chauviharTime: String = "06:36 PM",
    val events: List<JainEvent> = emptyList(),
    val isAthamOrChaudas: Boolean = false
)

object JainPanchangRepository {

    val supportedYears = listOf(2025, 2026, 2027)

    private val masterEvents = listOf(
        // ==================== 2025 Tapagacch Events ====================
        JainEvent(
            id = "e_2025_01_22",
            titleHindi = "श्री पार्श्वनाथ प्रभु दीक्षा / जन्म कल्याणक (पोष दशमी)",
            titleEnglish = "Parshwanath Janm/Diksha Kalyanak (Posya Dashami)",
            dateString = "2025-01-22",
            month = 1, day = 22, year = 2025,
            tithiHindi = "पौष वद १०",
            category = JainEventCategory.KALYANAK,
            description = "२३वें तीर्थंकर भगवान पार्श्वनाथ का पावन जन्म एवं दीक्षा कल्याणक। अठ्ठम तप आराधना।",
            fastingRule = "अठ्ठम तप (३ दिन उपवास) / एकाशन"
        ),
        JainEvent(
            id = "e_2025_02_10",
            titleHindi = "मेरु त्रयोदशी (भगवान ऋषभदेव मोक्ष कल्याणक)",
            titleEnglish = "Meru Trayodashi (Adinath Moksha Kalyanak)",
            dateString = "2025-02-10",
            month = 2, day = 10, year = 2025,
            tithiHindi = "माघ वद १३",
            category = JainEventCategory.KALYANAK,
            description = "प्रथम तीर्थंकर भगवान ऋषभदेव जी का अष्टापद महातीर्थ से निर्वाण कल्याणक।",
            fastingRule = "विशेष जाप एवं उपवास"
        ),
        JainEvent(
            id = "e_2025_03_14",
            titleHindi = "फाल्गुन पूर्णिमा (सिद्धचल ६ गाऊ यात्रा)",
            titleEnglish = "Phalguna Purnima (Siddhachal 6 Gau Yatra)",
            dateString = "2025-03-14",
            month = 3, day = 14, year = 2025,
            tithiHindi = "फाल्गुन सुद १५",
            category = JainEventCategory.MAHAPARVA,
            description = "श्री शत्रुंजय महातीर्थ ६ गाऊ फेरी यात्रा। लाखों श्रद्धालुओं का पावन तीर्थाटन।",
            fastingRule = "६ गाऊ पदयात्रा एवं उपवास / एकाशन"
        ),
        JainEvent(
            id = "e_2025_04_03",
            titleHindi = "चैत्र नवपद ओली प्रारम्भ (तपागच्छ)",
            titleEnglish = "Chaitra Navpad Oli Start (Tapagacch)",
            dateString = "2025-04-03",
            month = 4, day = 3, year = 2025,
            tithiHindi = "चैत्र सुद ७",
            category = JainEventCategory.OLI_PARVA,
            description = "९ दिवसीय श्री नवपद जी ओली आराधनाव्रत प्रारम्भ (अरिहंत पद से सिद्ध चक्र आराधना)।",
            fastingRule = "नवपद आयम्बिल तप (९ दिन)"
        ),
        JainEvent(
            id = "e_2025_04_10",
            titleHindi = "भगवान महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2025-04-10",
            month = 4, day = 10, year = 2025,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.KALYANAK,
            description = "२४वें तीर्थंकर भगवान महावीर स्वामी २५४५वां पावन जन्म कल्याणक महोत्सव।",
            fastingRule = "विशेष जाप, पूजा एवं नवकारसी"
        ),
        JainEvent(
            id = "e_2025_04_11",
            titleHindi = "चैत्र नवपद ओली पूर्णता",
            titleEnglish = "Chaitra Navpad Oli Completion",
            dateString = "2025-04-11",
            month = 4, day = 11, year = 2025,
            tithiHindi = "चैत्र सुद १५ (पूर्णिमा)",
            category = JainEventCategory.OLI_PARVA,
            description = "श्री नवपद ओली तप पूर्णता एवं सिद्धचक्र पूजन।",
            fastingRule = "आयम्बिल पारणा एवं सिद्धचक्र पूजन"
        ),
        JainEvent(
            id = "e_2025_04_30",
            titleHindi = "अक्षय तृतीया (वर्षीतप पारणा)",
            titleEnglish = "Akshaya Tritiya (Varshitap Parna)",
            dateString = "2025-04-30",
            month = 4, day = 30, year = 2025,
            tithiHindi = "वैशाख सुद ३",
            category = JainEventCategory.MAHAPARVA,
            description = "प्रथम तीर्थंकर भगवान ऋषभदेव का हस्तिनापुर में इक्षुरस (गन्ने का रस) से ऐतिहासिक पारणा।",
            fastingRule = "इक्षुरस पारणा / वर्षीतप उद्यापन"
        ),
        JainEvent(
            id = "e_2025_05_07",
            titleHindi = "भगवान महावीर केवलज्ञान कल्याणक",
            titleEnglish = "Mahavir Kevalgyan Kalyanak",
            dateString = "2025-05-07",
            month = 5, day = 7, year = 2025,
            tithiHindi = "वैशाख सुद १०",
            category = JainEventCategory.KALYANAK,
            description = "ऋजुबालुका नदी तट पर भगवान महावीर स्वामी को सर्वज्ञ केवलज्ञान संप्राप्ति।",
            fastingRule = "स्वाध्याय एवं एकाशन"
        ),
        JainEvent(
            id = "e_2025_06_10",
            titleHindi = "भगवान शांतिनाथ जन्म / दीक्षा / मोक्ष कल्याणक",
            titleEnglish = "Shantinath Janm/Diksha/Moksha Kalyanak",
            dateString = "2025-06-10",
            month = 6, day = 10, year = 2025,
            tithiHindi = "ज्येष्ठ सुद १४",
            category = JainEventCategory.KALYANAK,
            description = "१६वें तीर्थंकर चक्रवर्ती शांतिनाथ भगवान का त्रि-कल्याणक पावन दिवस। शांति स्नात्र महापूजा।",
            fastingRule = "शांति स्नात्र पूजा एवं उपवास"
        ),
        JainEvent(
            id = "e_2025_08_20",
            titleHindi = "पर्यूषण महापर्व प्रारम्भ (तपागच्छ)",
            titleEnglish = "Paryushan Mahaparva Start (Tapagacch)",
            dateString = "2025-08-20",
            month = 8, day = 20, year = 2025,
            tithiHindi = "भाद्रपद वद १२",
            category = JainEventCategory.MAHAPARVA,
            description = "८ दिवसीय आत्मशुद्धि का अलौकिक महापर्व पर्यूषण प्रारम्भ। स्वाध्याय, तप एवं सामायिक आराधना।",
            fastingRule = "अठ्ठाई तप / एकाशन / उपवास"
        ),
        JainEvent(
            id = "e_2025_08_24",
            titleHindi = "भगवान महावीर जन्म वांचन (तपागच्छ)",
            titleEnglish = "Mahavir Janm Vanchan (Tapagacch)",
            dateString = "2025-08-24",
            month = 8, day = 24, year = 2025,
            tithiHindi = "भाद्रपद सुद २",
            category = JainEventCategory.MAHAPARVA,
            description = "श्री कल्पसूत्र ग्रन्थ से भगवान महावीर जन्म वांचन एवं १४ महास्वप्न उतारने का पावन प्रसंग।",
            fastingRule = "उपवास / आयम्बिल साधना"
        ),
        JainEvent(
            id = "e_2025_08_27",
            titleHindi = "संवत्सरी महापर्व (तपागच्छ)",
            titleEnglish = "Samvatsari Mahaparva (Tapagacch)",
            dateString = "2025-08-27",
            month = 8, day = 27, year = 2025,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "संवत्सरी महाप्रतिक्रमण एवं विश्व क्षमापना दिवस। 'मिच्छामि दुक्कडम्' - ८४ लाख जीवयोनि से क्षमापना।",
            fastingRule = "अनिवार्य उपवास (पौषध/उपवास)"
        ),
        JainEvent(
            id = "e_2025_09_02",
            titleHindi = "सुगंध दशमी / रोहिणी व्रत",
            titleEnglish = "Sugandh Dashami / Rohini Vrat",
            dateString = "2025-09-02",
            month = 9, day = 2, year = 2025,
            tithiHindi = "भाद्रपद सुद १०",
            category = JainEventCategory.TITHI_FASTING,
            description = "जिनालयों में धूप खेवन एवं कर्म निर्जरा हेतु सुगंध दशमी व्रत।",
            fastingRule = "धूप पूजा एवं एकाशन"
        ),
        JainEvent(
            id = "e_2025_10_20",
            titleHindi = "भगवान महावीर निर्वाण (दीपावली)",
            titleEnglish = "Mahavir Nirvan (Diwali)",
            dateString = "2025-10-20",
            month = 10, day = 20, year = 2025,
            tithiHindi = "कार्तिक वद अमावस्या",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी मोक्ष कल्याणक एवं प्रथम गणधर गौतम स्वामी केवलज्ञान प्राप्त दिवस।",
            fastingRule = "वीर निर्वाण जाप, एकाशन एवं वीर संवत् २५५२ प्रारम्भ"
        ),
        JainEvent(
            id = "e_2025_10_25",
            titleHindi = "ज्ञान पंचमी (सौभाग्य पंचमी)",
            titleEnglish = "Gyan Panchami",
            dateString = "2025-10-25",
            month = 10, day = 25, year = 2025,
            tithiHindi = "कार्तिक सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "ज्ञान की आराधना, जिनागम ज्ञान-भंडार पूजन एवं ५१ ज्ञान पद जाप।",
            fastingRule = "देववंदन, ज्ञान पूजा एवं एकाशन"
        ),
        JainEvent(
            id = "e_2025_10_27",
            titleHindi = "कार्तिक नवपद ओली प्रारम्भ",
            titleEnglish = "Kartik Navpad Oli Start",
            dateString = "2025-10-27",
            month = 10, day = 27, year = 2025,
            tithiHindi = "कार्तिक सुद ७",
            category = JainEventCategory.OLI_PARVA,
            description = "शरदकालीन श्री नवपद ओली आराधना प्रारम्भ।",
            fastingRule = "आयम्बिल तप"
        ),
        JainEvent(
            id = "e_2025_11_05",
            titleHindi = "कार्तिक पूनम (देव दिवाली / चातुर्मास समाप्ति)",
            titleEnglish = "Kartik Poonam (Dev Diwali / Chaturmas Finish)",
            dateString = "2025-11-05",
            month = 11, day = 5, year = 2025,
            tithiHindi = "कार्तिक सुद १५",
            category = JainEventCategory.MAHAPARVA,
            description = "शत्रुंजय गिरिराज यात्रा प्रारम्भ, साधु-साध्वीजी चातुर्मास निष्क्रमण।",
            fastingRule = "शत्रुंजय भाव यात्रा एवं उपवास"
        ),
        JainEvent(
            id = "e_2025_12_01",
            titleHindi = "मौन एकादशी (मागुन अग्यारस)",
            titleEnglish = "Maun Ekadashi",
            dateString = "2025-12-01",
            month = 12, day = 1, year = 2025,
            tithiHindi = "मार्गशीर्ष सुद ११",
            category = JainEventCategory.MAHAPARVA,
            description = "१५० कल्याणक दिवस, काष्ठमौन व्रत एवं विशेष देववंदन।",
            fastingRule = "मौन व्रत एवं उपवास"
        ),

        // ==================== 2026 Tapagacch Events ====================
        JainEvent(
            id = "e_2026_01_13",
            titleHindi = "श्री पार्श्वनाथ प्रभु दीक्षा / जन्म कल्याणक (पोष दशमी)",
            titleEnglish = "Parshwanath Janm/Diksha Kalyanak (Posya Dashami)",
            dateString = "2026-01-13",
            month = 1, day = 13, year = 2026,
            tithiHindi = "पौष वद १०",
            category = JainEventCategory.KALYANAK,
            description = "भगवान पार्श्वनाथ जी का पावन जन्म एवं दीक्षा कल्याणक। श्री पार्श्व पद्मावती जाप।",
            fastingRule = "अठ्ठम तप (३ दिन उपवास) / आयम्बिल"
        ),
        JainEvent(
            id = "e_2026_01_30",
            titleHindi = "मेरु त्रयोदशी (भगवान ऋषभदेव निर्वाण कल्याणक)",
            titleEnglish = "Meru Trayodashi (Adinath Moksha Kalyanak)",
            dateString = "2026-01-30",
            month = 1, day = 30, year = 2026,
            tithiHindi = "माघ वद १३",
            category = JainEventCategory.KALYANAK,
            description = "अष्टापद तीर्थ से प्रथम तीर्थंकर भगवान ऋषभदेव मोक्ष कल्याणक।",
            fastingRule = "विशेष जाप एवं उपवास"
        ),
        JainEvent(
            id = "e_2026_03_03",
            titleHindi = "फाल्गुन पूर्णिमा (६ गाऊ यात्रा)",
            titleEnglish = "Phalguna Purnima (6 Gau Yatra)",
            dateString = "2026-03-03",
            month = 3, day = 3, year = 2026,
            tithiHindi = "फाल्गुन सुद १५",
            category = JainEventCategory.MAHAPARVA,
            description = "श्री शत्रुंजय महातीर्थ छः गाऊ परिक्रमा यात्रा।",
            fastingRule = "६ गाऊ यात्रा एवं तप"
        ),
        JainEvent(
            id = "e_2026_03_24",
            titleHindi = "चैत्र नवपद ओली प्रारम्भ (तपागच्छ)",
            titleEnglish = "Chaitra Navpad Oli Start (Tapagacch)",
            dateString = "2026-03-24",
            month = 3, day = 24, year = 2026,
            tithiHindi = "चैत्र सुद ७",
            category = JainEventCategory.OLI_PARVA,
            description = "वासंतिक श्री नवपद जी ओली तप आराधना प्रारम्भ।",
            fastingRule = "नवपद आयम्बिल तप"
        ),
        JainEvent(
            id = "e_2026_03_31",
            titleHindi = "भगवान महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2026-03-31",
            month = 3, day = 31, year = 2026,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.KALYANAK,
            description = "भगवान महावीर स्वामी २५४६वां जन्म कल्याणक महोत्सव।",
            fastingRule = "विशेष जाप एवं नवकारसी"
        ),
        JainEvent(
            id = "e_2026_04_01",
            titleHindi = "चैत्र नवपद ओली पूर्णता",
            titleEnglish = "Chaitra Navpad Oli Completion",
            dateString = "2026-04-01",
            month = 4, day = 1, year = 2026,
            tithiHindi = "चैत्र सुद १५",
            category = JainEventCategory.OLI_PARVA,
            description = "नवपद जी ओली पूर्णता एवं महापूजन।",
            fastingRule = "आयम्बिल पारणा"
        ),
        JainEvent(
            id = "e_2026_04_19",
            titleHindi = "अक्षय तृतीया (वर्षीतप पारणा)",
            titleEnglish = "Akshaya Tritiya (Varshitap Parna)",
            dateString = "2026-04-19",
            month = 4, day = 19, year = 2026,
            tithiHindi = "वैशाख सुद ३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान ऋषभदेव का इक्षुरस पारणा एवं वर्षीतप पूर्णता।",
            fastingRule = "इक्षुरस पारणा"
        ),
        JainEvent(
            id = "e_2026_04_26",
            titleHindi = "भगवान महावीर केवलज्ञान कल्याणक",
            titleEnglish = "Mahavir Kevalgyan Kalyanak",
            dateString = "2026-04-26",
            month = 4, day = 26, year = 2026,
            tithiHindi = "वैशाख सुद १०",
            category = JainEventCategory.KALYANAK,
            description = "भगवान महावीर स्वामी केवलज्ञान संप्राप्ति पावन अवसर।",
            fastingRule = "एकाशन एवं जाप"
        ),
        JainEvent(
            id = "e_2026_05_30",
            titleHindi = "भगवान शांतिनाथ जन्म / दीक्षा / मोक्ष कल्याणक",
            titleEnglish = "Shantinath Janm/Diksha/Moksha Kalyanak",
            dateString = "2026-05-30",
            month = 5, day = 30, year = 2026,
            tithiHindi = "ज्येष्ठ सुद १४",
            category = JainEventCategory.KALYANAK,
            description = "१६वें तीर्थंकर श्री शांतिनाथ भगवान त्रि-कल्याणक शांति विधान।",
            fastingRule = "शांति स्नात्र एवं उपवास"
        ),
        JainEvent(
            id = "e_2026_09_08",
            titleHindi = "पर्यूषण महापर्व प्रारम्भ (तपागच्छ)",
            titleEnglish = "Paryushan Mahaparva Start (Tapagacch)",
            dateString = "2026-09-08",
            month = 9, day = 8, year = 2026,
            tithiHindi = "भाद्रपद वद १२",
            category = JainEventCategory.MAHAPARVA,
            description = "तपागच्छ परंपरा अनुसार पर्यूषण महापर्व प्रारम्भ। आत्मनिरीक्षण एवं तप साधना।",
            fastingRule = "अठ्ठाई / एकाशन / उपवास"
        ),
        JainEvent(
            id = "e_2026_09_12",
            titleHindi = "भगवान महावीर जन्म वांचन (तपागच्छ)",
            titleEnglish = "Mahavir Janm Vanchan (Tapagacch)",
            dateString = "2026-09-12",
            month = 9, day = 12, year = 2026,
            tithiHindi = "भाद्रपद सुद २",
            category = JainEventCategory.MAHAPARVA,
            description = "श्री कल्पसूत्र ग्रन्थ वांचन एवं १४ स्वप्न दर्शन महोत्सव।",
            fastingRule = "उपवास / आयम्बिल"
        ),
        JainEvent(
            id = "e_2026_09_15",
            titleHindi = "संवत्सरी महापर्व (तपागच्छ)",
            titleEnglish = "Samvatsari Mahaparva (Tapagacch)",
            dateString = "2026-09-15",
            month = 9, day = 15, year = 2026,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "तपागच्छ संवत्सरी महाप्रतिक्रमण एवं क्षमापना दिवस। 'मिच्छामि दुक्कडम्'।",
            fastingRule = "अनिवार्य उपवास"
        ),
        JainEvent(
            id = "e_2026_09_20",
            titleHindi = "सुगंध दशमी / रोहिणी व्रत",
            titleEnglish = "Sugandh Dashami / Rohini Vrat",
            dateString = "2026-09-20",
            month = 9, day = 20, year = 2026,
            tithiHindi = "भाद्रपद सुद १०",
            category = JainEventCategory.TITHI_FASTING,
            description = "धूप खेवन एवं सुगंध दशमी व्रत साधना।",
            fastingRule = "धूप पूजा एवं एकाशन"
        ),
        JainEvent(
            id = "e_2026_10_16",
            titleHindi = "कार्तिक नवपद ओली प्रारम्भ",
            titleEnglish = "Kartik Navpad Oli Start",
            dateString = "2026-10-16",
            month = 10, day = 16, year = 2026,
            tithiHindi = "कार्तिक सुद ७",
            category = JainEventCategory.OLI_PARVA,
            description = "शरदकालीन नवपद ओली आराधना।",
            fastingRule = "आयम्बिल तप"
        ),
        JainEvent(
            id = "e_2026_11_08",
            titleHindi = "भगवान महावीर निर्वाण (दीपावली)",
            titleEnglish = "Mahavir Nirvan (Diwali)",
            dateString = "2026-11-08",
            month = 11, day = 8, year = 2026,
            tithiHindi = "कार्तिक वद अमावस्या",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर स्वामी निर्वाण एवं गौतम स्वामी केवलज्ञान।",
            fastingRule = "वीर निर्वाण एकाशन / जाप"
        ),
        JainEvent(
            id = "e_2026_11_13",
            titleHindi = "ज्ञान पंचमी",
            titleEnglish = "Gyan Panchami",
            dateString = "2026-11-13",
            month = 11, day = 13, year = 2026,
            tithiHindi = "कार्तिक सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "ज्ञान की आराधना एवं शास्त्र पूजन।",
            fastingRule = "ज्ञान पूजा एवं एकाशन"
        ),
        JainEvent(
            id = "e_2026_11_24",
            titleHindi = "कार्तिक पूनम (देव दिवाली)",
            titleEnglish = "Kartik Poonam (Dev Diwali)",
            dateString = "2026-11-24",
            month = 11, day = 24, year = 2026,
            tithiHindi = "कार्तिक सुद १५",
            category = JainEventCategory.MAHAPARVA,
            description = "शत्रुंजय तीर्थ दर्शन एवं चातुर्मास समाप्ति।",
            fastingRule = "शत्रुंजय भाव यात्रा"
        ),
        JainEvent(
            id = "e_2026_12_20",
            titleHindi = "मौन एकादशी (मागुन अग्यारस)",
            titleEnglish = "Maun Ekadashi",
            dateString = "2026-12-20",
            month = 12, day = 20, year = 2026,
            tithiHindi = "मार्गशीर्ष सुद ११",
            category = JainEventCategory.MAHAPARVA,
            description = "१५० कल्याणक दिवस, काष्ठमौन व्रत एवं विशेष देववंदन।",
            fastingRule = "मौन व्रत एवं उपवास"
        ),

        // ==================== 2027 Tapagacch Events ====================
        JainEvent(
            id = "e_2027_01_02",
            titleHindi = "श्री पार्श्वनाथ प्रभु दीक्षा / जन्म कल्याणक (पोष दशमी)",
            titleEnglish = "Parshwanath Janm/Diksha Kalyanak",
            dateString = "2027-01-02",
            month = 1, day = 2, year = 2027,
            tithiHindi = "पौष वद १०",
            category = JainEventCategory.KALYANAK,
            description = "भगवान पार्श्वनाथ जी का पावन जन्म एवं दीक्षा कल्याणक।",
            fastingRule = "अठ्ठम तप / आयम्बिल"
        ),
        JainEvent(
            id = "e_2027_02_18",
            titleHindi = "मेरु त्रयोदशी (भगवान ऋषभदेव निर्वाण कल्याणक)",
            titleEnglish = "Meru Trayodashi",
            dateString = "2027-02-18",
            month = 2, day = 18, year = 2027,
            tithiHindi = "माघ वद १३",
            category = JainEventCategory.KALYANAK,
            description = "भगवान ऋषभदेव मोक्ष कल्याणक।",
            fastingRule = "उपवास / जाप"
        ),
        JainEvent(
            id = "e_2027_04_12",
            titleHindi = "चैत्र नवपद ओली प्रारम्भ (तपागच्छ)",
            titleEnglish = "Chaitra Navpad Oli Start (Tapagacch)",
            dateString = "2027-04-12",
            month = 4, day = 12, year = 2027,
            tithiHindi = "चैत्र सुद ७",
            category = JainEventCategory.OLI_PARVA,
            description = "नवपद जी ओली आराधना प्रारम्भ।",
            fastingRule = "आयम्बिल तप"
        ),
        JainEvent(
            id = "e_2027_04_19",
            titleHindi = "भगवान महावीर जन्म कल्याणक",
            titleEnglish = "Mahavir Janm Kalyanak",
            dateString = "2027-04-19",
            month = 4, day = 19, year = 2027,
            tithiHindi = "चैत्र सुद १३",
            category = JainEventCategory.KALYANAK,
            description = "भगवान महावीर स्वामी २५४७वां जन्म कल्याणक।",
            fastingRule = "विशेष जाप"
        ),
        JainEvent(
            id = "e_2027_05_08",
            titleHindi = "अक्षय तृतीया (वर्षीतप पारणा)",
            titleEnglish = "Akshaya Tritiya",
            dateString = "2027-05-08",
            month = 5, day = 8, year = 2027,
            tithiHindi = "वैशाख सुद ३",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान ऋषभदेव का इक्षुरस पारणा।",
            fastingRule = "इक्षुरस पारणा"
        ),
        JainEvent(
            id = "e_2027_08_28",
            titleHindi = "पर्यूषण महापर्व प्रारम्भ (तपागच्छ)",
            titleEnglish = "Paryushan Mahaparva Start (Tapagacch)",
            dateString = "2027-08-28",
            month = 8, day = 28, year = 2027,
            tithiHindi = "भाद्रपद वद १२",
            category = JainEventCategory.MAHAPARVA,
            description = "पर्यूषण महापर्व प्रारम्भ।",
            fastingRule = "अठ्ठाई / तप साधना"
        ),
        JainEvent(
            id = "e_2027_09_04",
            titleHindi = "संवत्सरी महापर्व (तपागच्छ)",
            titleEnglish = "Samvatsari Mahaparva (Tapagacch)",
            dateString = "2027-09-04",
            month = 9, day = 4, year = 2027,
            tithiHindi = "भाद्रपद सुद ५",
            category = JainEventCategory.MAHAPARVA,
            description = "संवत्सरी प्रतिक्रमण एवं सर्व जीव क्षमापना। 'मिच्छामि दुक्कडम्'।",
            fastingRule = "अनिवार्य उपवास"
        ),
        JainEvent(
            id = "e_2027_10_29",
            titleHindi = "भगवान महावीर निर्वाण (दीपावली)",
            titleEnglish = "Mahavir Nirvan (Diwali)",
            dateString = "2027-10-29",
            month = 10, day = 29, year = 2027,
            tithiHindi = "कार्तिक वद अमावस्या",
            category = JainEventCategory.MAHAPARVA,
            description = "भगवान महावीर निर्वाण कल्याणक।",
            fastingRule = "जाप एवं एकाशन"
        )
    )

    private data class KalyanakRule(
        val masName: String,
        val paksha: String, // "सुद" or "वद"
        val tithi: Int, // 1..15
        val titleHindi: String,
        val titleEnglish: String,
        val description: String,
        val fastingRule: String = "विशेष देववंदन, जाप एवं उपवास / एकाशन"
    )

    private val kalyanakRules = listOf(
        // 1. भगवान ऋषभदेव (आदिनाथ)
        KalyanakRule("चैत्र", "वद", 9, "भगवान ऋषभदेव (आदिनाथ) जन्म व दीक्षा कल्याणक", "Adinath Janm & Diksha Kalyanak", "प्रथम तीर्थंकर भगवान ऋषभदेव जी का पावन जन्म एवं दीक्षा कल्याणक दिवस।", "अठ्ठम तप / एकाशन"),
        KalyanakRule("फाल्गुन", "वद", 11, "भगवान ऋषभदेव (आदिनाथ) केवलज्ञान कल्याणक", "Adinath Kevalgyan Kalyanak", "भगवान ऋषभदेव जी को पुरिमताल नगर में केवलज्ञान संप्राप्ति।", "स्वाध्याय एवं जाप"),
        KalyanakRule("माघ", "वद", 13, "मेरु त्रयोदशी (भगवान ऋषभदेव मोक्ष कल्याणक)", "Meru Trayodashi (Adinath Moksha Kalyanak)", "प्रथम तीर्थंकर भगवान आदिनाथ जी का अष्टापद महातीर्थ से निर्वाण कल्याणक।", "विशेष जाप एवं उपवास"),

        // 2. भगवान अजितनाथ
        KalyanakRule("माघ", "सुद", 10, "भगवान अजितनाथ जन्म व दीक्षा कल्याणक", "Ajitnath Janm & Diksha Kalyanak", "२रे तीर्थंकर भगवान अजितनाथ जी का जन्म व दीक्षा कल्याणक।", "जाप एवं एकाशन"),
        KalyanakRule("चैत्र", "सुद", 5, "भगवान अजितनाथ केवलज्ञान व मोक्ष कल्याणक", "Ajitnath Kevalgyan & Moksha Kalyanak", "भगवान अजितनाथ जी का सम्मेद शिखर जी से मोक्ष कल्याणक।", "उपवास / जाप"),

        // 3. भगवान सम्भवनाथ
        KalyanakRule("मार्गशीर्ष", "सुद", 14, "भगवान सम्भवनाथ जन्म व दीक्षा कल्याणक", "Sambhavnath Janm & Diksha Kalyanak", "३रे तीर्थंकर भगवान सम्भवनाथ स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("कार्तिक", "सुद", 15, "भगवान सम्भवनाथ केवलज्ञान व मोक्ष कल्याणक", "Sambhavnath Kevalgyan & Moksha Kalyanak", "भगवान सम्भवनाथ स्वामी का केवलज्ञान व मोक्ष कल्याणक।", "उपवास व पूजा"),

        // 4. भगवान अभिनन्दन स्वामी
        KalyanakRule("वैशाख", "सुद", 2, "भगवान अभिनन्दन स्वामी जन्म व दीक्षा कल्याणक", "Abhinandan Swami Janm & Diksha Kalyanak", "४थे तीर्थंकर भगवान अभिनन्दन स्वामी का पावन जन्म व दीक्षा कल्याणक।", "जाप एवं एकाशन"),
        KalyanakRule("वैशाख", "सुद", 14, "भगवान अभिनन्दन स्वामी मोक्ष कल्याणक", "Abhinandan Swami Moksha Kalyanak", "भगवान अभिनन्दन स्वामी का सम्मेद शिखर से निर्वाण कल्याणक।", "उपवास व स्वाध्याय"),

        // 5. भगवान सुमतिनाथ
        KalyanakRule("वैशाख", "सुद", 8, "भगवान सुमतिनाथ जन्म व दीक्षा कल्याणक", "Sumatinath Janm & Diksha Kalyanak", "५वें तीर्थंकर भगवान सुमतिनाथ स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("चैत्र", "सुद", 11, "भगवान सुमतिनाथ मोक्ष कल्याणक", "Sumatinath Moksha Kalyanak", "भगवान सुमतिनाथ स्वामी का सम्मेद शिखर से निर्वाण।", "उपवास"),

        // 6. भगवान पद्मप्रभ
        KalyanakRule("कार्तिक", "वद", 12, "भगवान पद्मप्रभ स्वामी जन्म व दीक्षा कल्याणक", "Padmaprabha Janm & Diksha Kalyanak", "६ठे तीर्थंकर भगवान पद्मप्रभ स्वामी जन्म व दीक्षा कल्याणक।", "जाप एवं एकाशन"),
        KalyanakRule("मार्गशीर्ष", "वद", 11, "भगवान पद्मप्रभ केवलज्ञान व मोक्ष कल्याणक", "Padmaprabha Moksha Kalyanak", "भगवान पद्मप्रभ स्वामी का मोक्ष कल्याणक।", "उपवास"),

        // 7. भगवान सुपार्श्वनाथ
        KalyanakRule("ज्येष्ठ", "वद", 12, "भगवान सुपार्श्वनाथ जन्म व दीक्षा कल्याणक", "Suparshwanath Janm & Diksha Kalyanak", "७वें तीर्थंकर भगवान सुपार्श्वनाथ स्वामी जन्म व दीक्षा कल्याणक।", "जाप एवं एकाशन"),
        KalyanakRule("फाल्गुन", "वद", 6, "भगवान सुपार्श्वनाथ मोक्ष कल्याणक", "Suparshwanath Moksha Kalyanak", "भगवान सुपार्श्वनाथ स्वामी सम्मेद शिखर निर्वाण कल्याणक।", "उपवास"),

        // 8. भगवान चन्द्रप्रभ
        KalyanakRule("पौष", "वद", 11, "भगवान चन्द्रप्रभ स्वामी जन्म व दीक्षा कल्याणक", "Chandraprabha Janm & Diksha Kalyanak", "८वें तीर्थंकर भगवान चन्द्रप्रभ स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("फाल्गुन", "वद", 7, "भगवान चन्द्रप्रभ मोक्ष कल्याणक", "Chandraprabha Moksha Kalyanak", "भगवान चन्द्रप्रभ स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 9. भगवान पुष्पदन्त (सुविधिनाथ)
        KalyanakRule("मार्गशीर्ष", "वद", 9, "भगवान सुविधिनाथ (पुष्पदन्त) जन्म व दीक्षा कल्याणक", "Pushpadanta Janm & Diksha Kalyanak", "९वें तीर्थंकर भगवान सुविधिनाथ स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("कार्तिक", "वद", 3, "भगवान सुविधिनाथ मोक्ष कल्याणक", "Pushpadanta Moksha Kalyanak", "भगवान सुविधिनाथ स्वामी निर्वाण कल्याणक।", "उपवास"),

        // 10. भगवान शीतलनाथ
        KalyanakRule("माघ", "वद", 12, "भगवान शीतलनाथ स्वामी जन्म व दीक्षा कल्याणक", "Sheetalnath Janm & Diksha Kalyanak", "१०वें तीर्थंकर भगवान शीतलनाथ स्वामी जन्म व दीक्षा।", "जाप व एकाशन"),
        KalyanakRule("वैशाख", "वद", 2, "भगवान शीतलनाथ मोक्ष कल्याणक", "Sheetalnath Moksha Kalyanak", "भगवान शीतलनाथ स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 11. भगवान श्रेयांसनाथ
        KalyanakRule("फाल्गुन", "वद", 11, "भगवान श्रेयांसनाथ स्वामी जन्म व दीक्षा कल्याणक", "Shreyansnath Janm & Diksha Kalyanak", "११वें तीर्थंकर भगवान श्रेयांसनाथ स्वामी जन्म व दीक्षा।", "जाप व एकाशन"),
        KalyanakRule("माघ", "वद", 3, "भगवान श्रेयांसनाथ मोक्ष कल्याणक", "Shreyansnath Moksha Kalyanak", "भगवान श्रेयांसनाथ स्वामी निर्वाण कल्याणक।", "उपवास"),

        // 12. भगवान वासुपूज्य स्वामी
        KalyanakRule("भाद्रपद", "वद", 14, "भगवान वासुपूज्य स्वामी चतुष्-कल्याणक", "Vasupujya Swami Kalyanak", "१२वें तीर्थंकर भगवान वासुपूज्य स्वामी का चम्पापुरी से चतुष्-कल्याणक (जन्म, दीक्षा, केवलज्ञान, मोक्ष)।", "चम्पापुरी पूजा व उपवास"),

        // 13. भगवान विमलनाथ
        KalyanakRule("माघ", "वद", 3, "भगवान विमलनाथ स्वामी जन्म व दीक्षा कल्याणक", "Vimalnath Janm & Diksha Kalyanak", "१३वें तीर्थंकर भगवान विमलनाथ स्वामी जन्म व दीक्षा।", "जाप व एकाशन"),
        KalyanakRule("माघ", "सुद", 6, "भगवान विमलनाथ मोक्ष कल्याणक", "Vimalnath Moksha Kalyanak", "भगवान विमलनाथ स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 14. भगवान अनन्तनाथ
        KalyanakRule("ज्येष्ठ", "वद", 12, "भगवान अनन्तनाथ स्वामी जन्म व दीक्षा कल्याणक", "Anantnath Janm & Diksha Kalyanak", "१४वें तीर्थंकर भगवान अनन्तनाथ स्वामी जन्म व दीक्षा।", "जाप व एकाशन"),
        KalyanakRule("चैत्र", "वद", 3, "भगवान अनन्तनाथ मोक्ष कल्याणक", "Anantnath Moksha Kalyanak", "भगवान अनन्तनाथ स्वामी निर्वाण कल्याणक।", "उपवास"),

        // 15. भगवान धर्मनाथ
        KalyanakRule("माघ", "सुद", 3, "भगवान धर्मनाथ स्वामी जन्म व दीक्षा कल्याणक", "Dharmanath Janm & Diksha Kalyanak", "१५वें तीर्थंकर भगवान धर्मनाथ स्वामी जन्म व दीक्षा।", "जाप व एकाशन"),
        KalyanakRule("ज्येष्ठ", "वद", 4, "भगवान धर्मनाथ मोक्ष कल्याणक", "Dharmanath Moksha Kalyanak", "भगवान धर्मनाथ स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 16. भगवान शांतिनाथ
        KalyanakRule("ज्येष्ठ", "सुद", 14, "भगवान शांतिनाथ स्वामी त्रि-कल्याणक", "Shantinath Janm/Diksha/Moksha Kalyanak", "१६वें तीर्थंकर चक्रवर्ती शांतिनाथ भगवान का त्रि-कल्याणक (जन्म, दीक्षा व मोक्ष) पावन दिवस।", "शांति स्नात्र पूजा व उपवास"),
        KalyanakRule("पौष", "वद", 10, "भगवान शांतिनाथ स्वामी केवलज्ञान कल्याणक", "Shantinath Kevalgyan Kalyanak", "भगवान शांतिनाथ स्वामी केवलज्ञान संप्राप्ति।", "स्वाध्याय"),

        // 17. भगवान कुन्थुनाथ
        KalyanakRule("वैशाख", "सुद", 14, "भगवान कुन्थुनाथ स्वामी त्रि-कल्याणक", "Kunthunath Tri-Kalyanak", "१७वें तीर्थंकर भगवान कुन्थुनाथ स्वामी जन्म, दीक्षा व मोक्ष कल्याणक।", "पूजा व उपवास"),

        // 18. भगवान अरनाथ
        KalyanakRule("मार्गशीर्ष", "सुद", 10, "भगवान अरनाथ स्वामी त्रि-कल्याणक", "Aranath Tri-Kalyanak", "१८वें तीर्थंकर भगवान अरनाथ स्वामी जन्म, दीक्षा व मोक्ष कल्याणक।", "पूजा व उपवास"),

        // 19. भगवान मल्लिनाथ
        KalyanakRule("मार्गशीर्ष", "सुद", 11, "भगवान मल्लिनाथ स्वामी चतुष्-कल्याणक", "Mallinath Kalyanak", "१९वें तीर्थंकर भगवान मल्लिनाथ स्वामी चतुष्-कल्याणक।", "जाप व उपवास"),

        // 20. भगवान मुनिसुव्रत स्वामी
        KalyanakRule("ज्येष्ठ", "वद", 10, "भगवान मुनिसुव्रत स्वामी जन्म व दीक्षा कल्याणक", "Munisuvrat Swami Janm & Diksha Kalyanak", "२०वें तीर्थंकर भगवान मुनिसुव्रत स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("वैशाख", "वद", 9, "भगवान मुनिसुव्रत स्वामी मोक्ष कल्याणक", "Munisuvrat Swami Moksha Kalyanak", "भगवान मुनिसुव्रत स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 21. भगवान नमिनाथ
        KalyanakRule("ज्येष्ठ", "वद", 2, "भगवान नमिनाथ स्वामी जन्म व दीक्षा कल्याणक", "Naminath Janm & Diksha Kalyanak", "२१वें तीर्थंकर भगवान नमिनाथ स्वामी जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("वैशाख", "सुद", 10, "भगवान नमिनाथ मोक्ष कल्याणक", "Naminath Moksha Kalyanak", "भगवान नमिनाथ स्वामी सम्मेद शिखर निर्वाण।", "उपवास"),

        // 22. भगवान नेमिनाथ (अरिष्टनेमि)
        KalyanakRule("श्रावण", "वद", 6, "भगवान नेमिनाथ (अरिष्टनेमि) जन्म व दीक्षा कल्याणक", "Neminath Janm & Diksha Kalyanak", "२२वें तीर्थंकर भगवान नेमिनाथ स्वामी पावन जन्म व दीक्षा कल्याणक।", "जाप व एकाशन"),
        KalyanakRule("आषाढ़", "सुद", 8, "भगवान नेमिनाथ स्वामी मोक्ष कल्याणक (गिरनार महातीर्थ)", "Neminath Moksha Kalyanak (Girnar)", "भगवान नेमिनाथ स्वामी ५वें टोंक गिरनार महातीर्थ से मोक्ष कल्याणक।", "गिरनार भाव यात्रा व उपवास"),

        // 23. भगवान पार्श्वनाथ
        KalyanakRule("पौष", "वद", 10, "श्री पार्श्वनाथ प्रभु दीक्षा / जन्म कल्याणक (पोष दशमी)", "Parshwanath Janm & Diksha Kalyanak (Posya Dashami)", "२३वें तीर्थंकर भगवान पार्श्वनाथ का पावन जन्म एवं दीक्षा कल्याणक। श्री पार्श्व पद्मावती अठ्ठम आराधना।", "अठ्ठम तप (३ दिन उपवास) / आयम्बिल"),
        KalyanakRule("चैत्र", "वद", 4, "भगवान पार्श्वनाथ स्वामी केवलज्ञान कल्याणक", "Parshwanath Kevalgyan Kalyanak", "भगवान पार्श्वनाथ स्वामी को केवलज्ञान प्राप्ति।", "स्वाध्याय"),
        KalyanakRule("श्रावण", "सुद", 7, "भगवान पार्श्वनाथ स्वामी मोक्ष कल्याणक (सम्मेद शिखर)", "Parshwanath Moksha Kalyanak (Sammed Shikhar)", "२३वें तीर्थंकर भगवान पार्श्वनाथ स्वामी सम्मेद शिखर जी से मोक्ष कल्याणक।", "सम्मेद शिखर पूजा व उपवास"),

        // 24. भगवान महावीर स्वामी
        KalyanakRule("चैत्र", "सुद", 13, "भगवान महावीर स्वामी जन्म कल्याणक (महावीर जयंती)", "Mahavir Janm Kalyanak (Mahavir Jayanti)", "२४वें तीर्थंकर भगवान महावीर स्वामी का पावन जन्म कल्याणक महोत्सव।", "विशेष नवकारसी, जाप व प्रभात फेरी"),
        KalyanakRule("चैत्र", "वद", 10, "भगवान महावीर स्वामी दीक्षा कल्याणक", "Mahavir Diksha Kalyanak", "भगवान महावीर स्वामी का राजसी वैभव त्याग कर संयम अंगीकार (दीक्षा कल्याणक)।", "एकाशन व स्वाध्याय"),
        KalyanakRule("वैशाख", "सुद", 10, "भगवान महावीर स्वामी केवलज्ञान कल्याणक", "Mahavir Kevalgyan Kalyanak", "ऋजुबालुका नदी तट पर भगवान महावीर स्वामी को सर्वज्ञ केवलज्ञान संप्राप्ति।", "केवलज्ञान जाप व एकाशन"),
        KalyanakRule("कार्तिक", "वद", 15, "भगवान महावीर स्वामी मोक्ष कल्याणक (दीपावली)", "Mahavir Nirvan (Diwali)", "पावापुरी महातीर्थ से भगवान महावीर स्वामी का निर्वाण कल्याणक एवं वीर संवत प्रारम्भ।", "वीर निर्वाण जाप, एकाशन व घर में मंगल दीप")
    )

    private data class LunarMonthAnchor(
        val masNameHindi: String,
        val vikramSamvat: Int,
        val sud1Year: Int, val sud1Month: Int, val sud1Day: Int,
        val purnimaYear: Int, val purnimaMonth: Int, val purnimaDay: Int,
        val vad1Year: Int, val vad1Month: Int, val vad1Day: Int,
        val amavasyaYear: Int, val amavasyaMonth: Int, val amavasyaDay: Int
    )

    private val lunarAnchors = listOf(
        // ==================== 2025 Anchors ====================
        LunarMonthAnchor("पौष", 2081, 2024, 12, 31, 2025, 1, 13, 2025, 1, 14, 2025, 1, 29),
        LunarMonthAnchor("माघ", 2081, 2025, 1, 30, 2025, 2, 12, 2025, 2, 13, 2025, 2, 27),
        LunarMonthAnchor("फाल्गुन", 2081, 2025, 2, 28, 2025, 3, 14, 2025, 3, 15, 2025, 3, 29),
        LunarMonthAnchor("चैत्र", 2082, 2025, 3, 30, 2025, 4, 12, 2025, 4, 13, 2025, 4, 27),
        LunarMonthAnchor("वैशाख", 2082, 2025, 4, 28, 2025, 5, 12, 2025, 5, 13, 2025, 5, 27),
        LunarMonthAnchor("ज्येष्ठ", 2082, 2025, 5, 28, 2025, 6, 11, 2025, 6, 12, 2025, 6, 25),
        LunarMonthAnchor("आषाढ़", 2082, 2025, 6, 26, 2025, 7, 10, 2025, 7, 11, 2025, 7, 24),
        LunarMonthAnchor("श्रावण", 2082, 2025, 7, 25, 2025, 8, 8, 2025, 8, 9, 2025, 8, 23),
        LunarMonthAnchor("भाद्रपद", 2082, 2025, 8, 24, 2025, 9, 7, 2025, 9, 8, 2025, 9, 21),
        LunarMonthAnchor("आश्विन", 2082, 2025, 9, 22, 2025, 10, 6, 2025, 10, 7, 2025, 10, 21),
        LunarMonthAnchor("कार्तिक", 2082, 2025, 10, 22, 2025, 11, 5, 2025, 11, 6, 2025, 11, 20),
        LunarMonthAnchor("मार्गशीर्ष", 2082, 2025, 11, 21, 2025, 12, 4, 2025, 12, 5, 2025, 12, 19),
        LunarMonthAnchor("पौष", 2082, 2025, 12, 20, 2026, 1, 3, 2026, 1, 4, 2026, 1, 18),

        // ==================== 2026 Anchors ====================
        LunarMonthAnchor("माघ", 2082, 2026, 1, 19, 2026, 2, 1, 2026, 2, 2, 2026, 2, 17),
        LunarMonthAnchor("फाल्गुन", 2082, 2026, 2, 18, 2026, 3, 3, 2026, 3, 4, 2026, 3, 18),
        LunarMonthAnchor("चैत्र", 2083, 2026, 3, 19, 2026, 4, 1, 2026, 4, 2, 2026, 4, 17),
        LunarMonthAnchor("वैशाख", 2083, 2026, 4, 18, 2026, 5, 1, 2026, 5, 2, 2026, 5, 16),
        LunarMonthAnchor("ज्येष्ठ", 2083, 2026, 5, 17, 2026, 5, 31, 2026, 6, 1, 2026, 6, 14),
        LunarMonthAnchor("आषाढ़", 2083, 2026, 6, 15, 2026, 6, 29, 2026, 6, 30, 2026, 7, 14),
        LunarMonthAnchor("श्रावण", 2083, 2026, 7, 15, 2026, 7, 29, 2026, 7, 30, 2026, 8, 12),
        LunarMonthAnchor("भाद्रपद", 2083, 2026, 8, 13, 2026, 8, 27, 2026, 8, 28, 2026, 9, 10),
        LunarMonthAnchor("आश्विन", 2083, 2026, 9, 11, 2026, 9, 25, 2026, 9, 26, 2026, 10, 10),
        LunarMonthAnchor("कार्तिक", 2083, 2026, 10, 11, 2026, 10, 25, 2026, 10, 26, 2026, 11, 8),
        LunarMonthAnchor("मार्गशीर्ष", 2083, 2026, 11, 9, 2026, 11, 23, 2026, 11, 24, 2026, 12, 8),
        LunarMonthAnchor("पौष", 2083, 2026, 12, 9, 2026, 12, 22, 2026, 12, 23, 2027, 1, 7),

        // ==================== 2027 Anchors ====================
        LunarMonthAnchor("माघ", 2083, 2027, 1, 8, 2027, 1, 22, 2027, 1, 23, 2027, 2, 6),
        LunarMonthAnchor("फाल्गुन", 2083, 2027, 2, 7, 2027, 2, 21, 2027, 2, 22, 2027, 3, 8),
        LunarMonthAnchor("चैत्र", 2084, 2027, 3, 9, 2027, 3, 23, 2027, 3, 24, 2027, 4, 6),
        LunarMonthAnchor("वैशाख", 2084, 2027, 4, 7, 2027, 4, 21, 2027, 4, 22, 2027, 5, 6),
        LunarMonthAnchor("ज्येष्ठ", 2084, 2027, 5, 7, 2027, 5, 21, 2027, 5, 22, 2027, 6, 4),
        LunarMonthAnchor("आषाढ़", 2084, 2027, 6, 5, 2027, 6, 19, 2027, 6, 20, 2027, 7, 3),
        LunarMonthAnchor("श्रावण", 2084, 2027, 7, 4, 2027, 7, 18, 2027, 7, 19, 2027, 8, 2),
        LunarMonthAnchor("भाद्रपद", 2084, 2027, 8, 3, 2027, 8, 17, 2027, 8, 18, 2027, 8, 31),
        LunarMonthAnchor("आश्विन", 2084, 2027, 9, 1, 2027, 9, 15, 2027, 9, 16, 2027, 9, 29),
        LunarMonthAnchor("कार्तिक", 2084, 2027, 9, 30, 2027, 10, 14, 2027, 10, 15, 2027, 10, 29),
        LunarMonthAnchor("मार्गशीर्ष", 2084, 2027, 10, 30, 2027, 11, 13, 2027, 11, 14, 2027, 11, 28),
        LunarMonthAnchor("पौष", 2084, 2027, 11, 29, 2027, 12, 13, 2027, 12, 14, 2028, 1, 12)
    )

    private fun getDaysBetween(y1: Int, m1: Int, d1: Int, y2: Int, m2: Int, d2: Int): Int {
        val cal1 = Calendar.getInstance().apply { set(y1, m1 - 1, d1, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        val cal2 = Calendar.getInstance().apply { set(y2, m2 - 1, d2, 0, 0, 0); set(Calendar.MILLISECOND, 0) }
        return ((cal2.timeInMillis - cal1.timeInMillis) / (24 * 60 * 60 * 1000L)).toInt()
    }

    fun getEventsForMonth(year: Int, month: Int): List<JainEvent> {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val result = mutableListOf<JainEvent>()
        for (d in 1..maxDays) {
            val dp = getDayPanchang(year, month, d)
            result.addAll(dp.events)
        }
        return result.distinctBy { "${it.day}_${it.titleHindi}" }
    }

    fun getAllEventsForYear(year: Int): List<JainEvent> {
        val result = mutableListOf<JainEvent>()
        for (m in 1..12) {
            val monthEvents = getEventsForMonth(year, m)
            val majorEvents = monthEvents.filter {
                it.category == JainEventCategory.MAHAPARVA ||
                it.category == JainEventCategory.KALYANAK ||
                it.category == JainEventCategory.OLI_PARVA
            }
            result.addAll(majorEvents)
        }
        return result.distinctBy { "${it.month}_${it.day}_${it.titleHindi}" }
            .sortedBy { String.format("%02d-%02d", it.month, it.day) }
    }

    fun getDayPanchang(year: Int, month: Int, day: Int): DayPanchang {
        val dateKey = String.format("%04d-%02d-%02d", year, month, day)
        val matchedEvents = masterEvents.filter { it.dateString == dateKey }.toMutableList()

        var masName = "चैत्र"
        var pakshaStr = "सुद"
        var tithiNum = 1
        var vikramSamvat = year + 57

        val matchedAnchor = lunarAnchors.find { anchor ->
            val daysFromSud1 = getDaysBetween(anchor.sud1Year, anchor.sud1Month, anchor.sud1Day, year, month, day)
            val daysToAma = getDaysBetween(year, month, day, anchor.amavasyaYear, anchor.amavasyaMonth, anchor.amavasyaDay)
            daysFromSud1 >= 0 && daysToAma >= 0
        }

        if (matchedAnchor != null) {
            masName = matchedAnchor.masNameHindi
            vikramSamvat = matchedAnchor.vikramSamvat

            val daysFromSud1 = getDaysBetween(matchedAnchor.sud1Year, matchedAnchor.sud1Month, matchedAnchor.sud1Day, year, month, day)
            val daysFromPurnima = getDaysBetween(matchedAnchor.purnimaYear, matchedAnchor.purnimaMonth, matchedAnchor.purnimaDay, year, month, day)
            val daysFromVad1 = getDaysBetween(matchedAnchor.vad1Year, matchedAnchor.vad1Month, matchedAnchor.vad1Day, year, month, day)

            if (daysFromPurnima <= 0) {
                pakshaStr = "सुद"
                tithiNum = daysFromSud1 + 1
            } else {
                pakshaStr = "वद"
                tithiNum = daysFromVad1 + 1
            }
        } else {
            vikramSamvat = year + 57
            pakshaStr = if (day % 2 != 0) "सुद" else "वद"
            tithiNum = ((day % 15) + 1)
        }

        val tithiNumberHindi = when (tithiNum) {
            1 -> "१ (एकम)"
            2 -> "२ (बीज)"
            3 -> "३ (तीज)"
            4 -> "४ (चौथ)"
            5 -> "५ (पंचमी)"
            6 -> "६ (छठ)"
            7 -> "७ (सातम)"
            8 -> "८ (आठम / अष्टमी)"
            9 -> "९ (नौमी)"
            10 -> "१० (दशमी)"
            11 -> "११ (अग्यारस / एकादशी)"
            12 -> "१२ (बारस)"
            13 -> "१३ (तेरस / त्रयोदशी)"
            14 -> "१४ (चौदस / चतुर्दशी)"
            15 -> if (pakshaStr == "सुद") "१५ (पूनम / पूर्णिमा)" else "१५ (अमास / अमावस्या)"
            else -> "$tithiNum"
        }

        val tithiFull = "$masName $pakshaStr $tithiNumberHindi"
        val isAthamOrChaudas = (tithiNum == 8 || tithiNum == 14)

        // Synthesize Kalyanaks matching this lunar Tithi
        val matchingKalyanaks = kalyanakRules.filter {
            it.masName == masName && it.paksha == pakshaStr && it.tithi == tithiNum
        }

        matchingKalyanaks.forEach { kr ->
            if (matchedEvents.none { it.titleHindi.contains(kr.titleHindi) || kr.titleHindi.contains(it.titleHindi) }) {
                matchedEvents.add(
                    JainEvent(
                        id = "e_kal_${year}_${month}_${day}_${kr.tithi}",
                        titleHindi = kr.titleHindi,
                        titleEnglish = kr.titleEnglish,
                        dateString = dateKey,
                        month = month,
                        day = day,
                        year = year,
                        tithiHindi = tithiFull,
                        category = JainEventCategory.KALYANAK,
                        description = kr.description,
                        fastingRule = kr.fastingRule
                    )
                )
            }
        }

        // Automatically synthesize a fasting event for Atham or Chaudas if no fasting event listed
        if (isAthamOrChaudas && matchedEvents.none { it.category == JainEventCategory.TITHI_FASTING }) {
            val tithiTitle = if (tithiNum == 8) "$masName $pakshaStr आठम (अष्टमी)" else "$masName $pakshaStr चौदस (चतुर्दशी)"
            matchedEvents.add(
                JainEvent(
                    id = "e_auto_${year}_${month}_${day}",
                    titleHindi = tithiTitle,
                    titleEnglish = "$masName $pakshaStr " + (if (tithiNum == 8) "Ashtami (Atham)" else "Chaudas (Chaturdashi)"),
                    dateString = dateKey,
                    month = month,
                    day = day,
                    year = year,
                    tithiHindi = tithiFull,
                    category = JainEventCategory.TITHI_FASTING,
                    description = "विशेष जैन पर्व तिथि। हरी काय त्याग, एकाशन/उपवास, देववंदन एवं स्वाध्याय।",
                    fastingRule = "हरी काय (सब्जी) वर्जित, एकाशन / उपवास"
                )
            )
        }

        // Sort matchedEvents so MAHAPARVA and KALYANAK take higher priority than TITHI_FASTING
        matchedEvents.sortBy { ev ->
            when (ev.category) {
                JainEventCategory.MAHAPARVA -> 1
                JainEventCategory.KALYANAK -> 2
                JainEventCategory.OLI_PARVA -> 3
                JainEventCategory.TITHI_FASTING -> 4
            }
        }

        return DayPanchang(
            dateString = dateKey,
            year = year,
            month = month,
            day = day,
            tithiName = tithiFull,
            paksha = pakshaStr,
            masNameHindi = masName,
            vikramSamvat = vikramSamvat,
            sunriseTime = "06:14 AM",
            sunsetTime = "06:42 PM",
            navkarsiTime = "07:02 AM",
            chauviharTime = "06:30 PM",
            events = matchedEvents,
            isAthamOrChaudas = isAthamOrChaudas
        )
    }
}
