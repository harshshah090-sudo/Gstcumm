package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ParyushanFormEntity::class, SwadhyaiFormEntity::class, AllotmentEntity::class, FundTransactionEntity::class, FundPersonEntity::class, PanchangEventEntity::class, RegistrationHistoryEntity::class, GyanCategoryEntity::class, GyanTopicEntity::class, TimelinePostEntity::class], version = 22, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun formDao(): FormDao
    abstract fun swadhyaiDao(): SwadhyaiDao
    abstract fun allotmentDao(): AllotmentDao
    abstract fun fundDao(): FundDao
    abstract fun fundPersonDao(): FundPersonDao
    abstract fun panchangDao(): PanchangDao
    abstract fun registrationHistoryDao(): RegistrationHistoryDao
    abstract fun gyanDao(): GyanDao
    abstract fun timelineDao(): TimelineDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "paryushan_swadhyay_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
