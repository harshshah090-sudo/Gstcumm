package com.example.shahstores.model

data class Customer(
    val name: String = "",
    val address: String = "",
    val registrationType: String = "",
    val gstin: String? = null,
    val state: String = "",
    val stateCode: String = "",
    val transport: String? = null,
    val phoneNumber: String? = null
)
