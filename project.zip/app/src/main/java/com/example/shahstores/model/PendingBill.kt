package com.example.shahstores.model

data class PendingBill(
    val id: String = "",
    val customerName: String = "",
    val customerAddress: String = "",
    val amount: String = ""
)
