package com.example.shahstores.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.shahstores.model.Customer
import com.example.shahstores.model.Item
import com.example.shahstores.util.IndianStates
import com.example.shahstores.util.sanitizeFirebaseKey
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCustomerPopup(
    onDismiss: () -> Unit,
    onCustomerAdded: (Customer) -> Unit,
    customerToEdit: Customer? = null,
    items: List<Item> = emptyList(),
    onAddNewItem: (Item) -> Unit = {}
) {
    var name by remember { mutableStateOf(customerToEdit?.name ?: "") }
    var address by remember { mutableStateOf(customerToEdit?.address ?: "") }
    var registrationType by remember { mutableStateOf(customerToEdit?.registrationType ?: "URD") }
    var gstin by remember { mutableStateOf(customerToEdit?.gstin ?: "") }
    var state by remember { mutableStateOf(customerToEdit?.state ?: "Madhya Pradesh") }
    var stateCode by remember { mutableStateOf(customerToEdit?.stateCode ?: IndianStates.states["Madhya Pradesh"] ?: "") }
    var transport by remember { mutableStateOf(customerToEdit?.transport ?: "") }
    var phoneNumber by remember { mutableStateOf(customerToEdit?.phoneNumber ?: "") }
    
    var showItemRatesPopup by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f),
            color = MaterialTheme.colorScheme.surface,
            shape = MaterialTheme.shapes.medium
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (customerToEdit == null) "Add Customer" else "Edit Customer", color = MaterialTheme.colorScheme.onPrimary)
                }

                LazyColumn(
                    modifier = Modifier.padding(16.dp).weight(1f)
                ) {
                    item {
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = address,
                            onValueChange = { address = it },
                            label = { Text("Address") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = registrationType == "URD",
                                onClick = { registrationType = "URD" }
                            )
                            Text("URD")
                            RadioButton(
                                selected = registrationType == "GSTIN",
                                onClick = { registrationType = "GSTIN" }
                            )
                            Text("GSTIN")
                        }
                        if (registrationType == "GSTIN") {
                            OutlinedTextField(
                                value = gstin,
                                onValueChange = { gstin = it.uppercase() },
                                label = { Text("GSTIN") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                            OutlinedTextField(
                                value = state,
                                onValueChange = { },
                                label = { Text("State") },
                                readOnly = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor()
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                IndianStates.stateList.forEach { selectionOption ->
                                    DropdownMenuItem(
                                        text = { Text(selectionOption) },
                                        onClick = {
                                            state = selectionOption
                                            stateCode = IndianStates.states[selectionOption] ?: ""
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = stateCode,
                            onValueChange = { },
                            label = { Text("State Code") },
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = transport,
                            onValueChange = { transport = it },
                            label = { Text("Transport (optional)") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = phoneNumber,
                            onValueChange = { phoneNumber = it },
                            label = { Text("Phone Number (optional)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                        
                        Spacer(modifier = Modifier.height(16.dp))
                        
                        if (name.isNotBlank()) {
                            Button(
                                onClick = { showItemRatesPopup = true },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Text("Item Rates")
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(onClick = {
                        val newCustomer = Customer(
                            name = name,
                            address = address,
                            registrationType = registrationType,
                            gstin = if (registrationType == "GSTIN") gstin else "URD",
                            state = state,
                            stateCode = stateCode,
                            transport = transport,
                            phoneNumber = phoneNumber
                        )
                        onCustomerAdded(newCustomer)
                        onDismiss()
                    }) {
                        Text("Save")
                    }
                }
            }
        }
    }
    
    if (showItemRatesPopup) {
        ItemRatesPopup(
            customerName = name,
            items = items,
            onDismiss = { showItemRatesPopup = false },
            onAddNewItem = onAddNewItem
        )
    }
}

@Composable
fun ItemRatesPopup(
    customerName: String,
    items: List<Item>,
    onDismiss: () -> Unit,
    onAddNewItem: (Item) -> Unit = {}
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredItems = remember(searchQuery, items) {
        items.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }
    
    val customerRates = remember { mutableStateMapOf<String, String>() }
    val ratesRef = remember { Firebase.database.getReference("customer_item_rates").child(sanitizeFirebaseKey(customerName)) }
    val keyboardController = LocalSoftwareKeyboardController.current

    var showAddItemPopup by remember { mutableStateOf(false) }
    // State to trigger focus on a specific item's Rate field
    var focusedItemTrigger by remember { mutableStateOf<Pair<Item, Long>?>(null) }

    LaunchedEffect(customerName) {
        ratesRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { child ->
                    customerRates[child.key ?: ""] = child.value?.toString() ?: ""
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    if (showAddItemPopup) {
        AddItemPopup(
            onDismiss = { showAddItemPopup = false },
            onItemAdded = { newItem ->
                onAddNewItem(newItem)
                showAddItemPopup = false
            }
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth().fillMaxHeight(0.9f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Item Rates",
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleLarge
                    )
                    IconButton(onClick = { showAddItemPopup = true }) {
                        Icon(Icons.Default.Add, contentDescription = "Add New Item", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }
                
                Column(modifier = Modifier.padding(16.dp)) {
                    // Search Bar
                    Surface(
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        color = Color.White,
                        shape = RoundedCornerShape(8.dp),
                        shadowElevation = 2.dp
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null, tint = Color.Gray)
                            Spacer(modifier = Modifier.width(8.dp))
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                decorationBox = { innerTextField ->
                                    if (searchQuery.isEmpty()) {
                                        Text("Search Items", color = Color.Gray)
                                    }
                                    innerTextField()
                                }
                            )
                            if (searchQuery.isNotEmpty()) {
                                Icon(
                                    Icons.Default.Close,
                                    contentDescription = null,
                                    tint = Color.Gray,
                                    modifier = Modifier.clickable { searchQuery = "" }
                                )
                            }
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    LazyColumn(modifier = Modifier.weight(1f)) {
                        items(filteredItems) { item ->
                            val itemKey = if (item.id.isNotBlank()) item.id else sanitizeFirebaseKey(item.name)
                            val rateFocusRequester = remember { FocusRequester() }

                            LaunchedEffect(focusedItemTrigger) {
                                if (focusedItemTrigger?.first == item) {
                                    delay(100)
                                    rateFocusRequester.requestFocus()
                                    keyboardController?.show()
                                }
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                                    .clickable {
                                        focusedItemTrigger = item to System.currentTimeMillis()
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name, fontWeight = FontWeight.Medium)
                                    Text(item.uom, fontSize = 12.sp, color = Color.Gray)
                                }
                                
                                Box(
                                    modifier = Modifier
                                        .width(100.dp)
                                        .height(40.dp)
                                        .border(1.dp, Color.LightGray, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp),
                                    contentAlignment = Alignment.CenterStart
                                ) {
                                    BasicTextField(
                                        value = customerRates[itemKey] ?: "",
                                        onValueChange = { newValue ->
                                            if (newValue.isEmpty()) {
                                                customerRates.remove(itemKey)
                                                ratesRef.child(itemKey).removeValue()
                                            } else {
                                                customerRates[itemKey] = newValue
                                                ratesRef.child(itemKey).setValue(newValue)
                                            }
                                        },
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        textStyle = TextStyle(textAlign = TextAlign.End, fontSize = 16.sp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .focusRequester(rateFocusRequester)
                                    )
                                    if ((customerRates[itemKey] ?: "").isEmpty()) {
                                        Text("Rate", color = Color.LightGray, modifier = Modifier.align(Alignment.CenterEnd))
                                    }
                                }
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.5f))
                        }
                    }
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Close")
                    }
                }
            }
        }
    }
}
