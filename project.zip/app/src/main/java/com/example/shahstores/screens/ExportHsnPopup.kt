package com.example.shahstores.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExportHsnPopup(
    onDismiss: () -> Unit,
    onExportClick: (Long, Long) -> Unit
) {
    val datePickerStateStart = rememberDatePickerState()
    val datePickerStateEnd = rememberDatePickerState()
    var showStartPicker by remember { mutableStateOf(false) }
    var showEndPicker by remember { mutableStateOf(false) }

    val formatter = SimpleDateFormat("dd/MM/yyyy", Locale.ENGLISH)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Export HSN Summary",
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleLarge
                    )
                }

                Column(modifier = Modifier.padding(16.dp)) {
                    // Start Date
                    Text(text = "Start Date", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(
                        onClick = { showStartPicker = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = datePickerStateStart.selectedDateMillis?.let { formatter.format(Date(it)) } ?: "Select Start Date"
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // End Date
                    Text(text = "End Date", style = MaterialTheme.typography.labelLarge)
                    OutlinedButton(
                        onClick = { showEndPicker = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = datePickerStateEnd.selectedDateMillis?.let { formatter.format(Date(it)) } ?: "Select End Date"
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val start = datePickerStateStart.selectedDateMillis
                                val end = datePickerStateEnd.selectedDateMillis
                                if (start != null && end != null) {
                                    onExportClick(start, end)
                                    onDismiss()
                                }
                            },
                            enabled = datePickerStateStart.selectedDateMillis != null && datePickerStateEnd.selectedDateMillis != null
                        ) {
                            Text("Export")
                        }
                    }
                }
            }
        }
    }

    if (showStartPicker) {
        DatePickerDialog(
            onDismissRequest = { showStartPicker = false },
            confirmButton = {
                TextButton(onClick = { showStartPicker = false }) { Text("OK") }
            }
        ) {
            DatePicker(state = datePickerStateStart)
        }
    }

    if (showEndPicker) {
        DatePickerDialog(
            onDismissRequest = { showEndPicker = false },
            confirmButton = {
                TextButton(onClick = { showEndPicker = false }) { Text("OK") }
            }
        ) {
            DatePicker(state = datePickerStateEnd)
        }
    }
}
