package com.example.shahstores.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.shahstores.model.Item
import com.example.shahstores.model.Uom
import com.example.shahstores.viewmodel.UomViewModel
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.ui.ExperimentalComposeUiApi::class)
@Composable
fun AddItemPopup(
    onDismiss: () -> Unit,
    onItemAdded: (Item) -> Unit,
    itemToEdit: Item? = null,
    uomViewModel: UomViewModel = viewModel()
) {
    var name by remember { mutableStateOf(itemToEdit?.name ?: "") }
    var hsnCode by remember { mutableStateOf(itemToEdit?.hsnCode ?: "") }
    var uom by remember { mutableStateOf(itemToEdit?.uom ?: "") }
    var gstRate by remember { mutableStateOf(itemToEdit?.gstRate?.replace("%", "") ?: "") }
    var variants by remember { mutableStateOf(itemToEdit?.variants ?: emptyList<String>()) }
    var showVariantsInput by remember { mutableStateOf(variants.isNotEmpty()) }
    var variantInput by remember { mutableStateOf("") }

    val uomOptions by uomViewModel.uoms.collectAsState()
    val gstRateOptions = listOf("5", "12", "18", "28")
    val showAddUomDialog = remember { mutableStateOf(false) }

    if (showAddUomDialog.value) {
        AddUomDialog(
            onDismiss = { showAddUomDialog.value = false },
            onUomAdded = { newUom ->
                uomViewModel.addUom(Uom(name = newUom))
            },
            uomViewModel = uomViewModel
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 580.dp),
                color = MaterialTheme.colorScheme.surface,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (itemToEdit == null) "Add Item" else "Edit Item", color = MaterialTheme.colorScheme.onPrimary)
                }

                LazyColumn(
                    modifier = Modifier.padding(16.dp)
                ) {
                    item {
                        // Name
                        OutlinedTextField(
                            value = name,
                            onValueChange = { name = it },
                            label = { Text("Name") },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Next)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // UOM
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            var uomExpanded by remember { mutableStateOf(false) }

                            ExposedDropdownMenuBox(
                                expanded = uomExpanded,
                                onExpandedChange = { uomExpanded = !uomExpanded },
                                modifier = Modifier.weight(1f)
                            ) {
                                OutlinedTextField(
                                    value = uom,
                                    onValueChange = { uom = it },
                                    label = { Text("UOM") },
                                    readOnly = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .menuAnchor(),
                                    singleLine = true
                                )
                                ExposedDropdownMenu(
                                    expanded = uomExpanded,
                                    onDismissRequest = { uomExpanded = false }
                                ) {
                                    uomOptions.forEach { selectionOption ->
                                        DropdownMenuItem(
                                            text = { Text(selectionOption.name) },
                                            onClick = {
                                                uom = selectionOption.name
                                                uomExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            IconButton(onClick = { showAddUomDialog.value = true }) {
                                Icon(Icons.Default.Add, contentDescription = "Add UOM")
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // HSN Code
                        OutlinedTextField(
                            value = hsnCode,
                            onValueChange = { hsnCode = it },
                            label = { Text("HSN Code") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // GST Rate
                        var gstExpanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(
                            expanded = gstExpanded,
                            onExpandedChange = { gstExpanded = !gstExpanded }
                        ) {
                            OutlinedTextField(
                                value = if (gstRate.isNotEmpty()) "$gstRate%" else "" ,
                                onValueChange = { },
                                label = { Text("GST Rate") },
                                readOnly = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .menuAnchor(),
                                singleLine = true
                            )
                            ExposedDropdownMenu(
                                expanded = gstExpanded,
                                onDismissRequest = { gstExpanded = false }
                            ) {
                                gstRateOptions.forEach { selectionOption ->
                                    DropdownMenuItem(
                                        text = { Text("$selectionOption%") },
                                        onClick = {
                                            gstRate = selectionOption
                                            gstExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Variants Toggle
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth().clickable { showVariantsInput = !showVariantsInput }
                        ) {
                            Checkbox(
                                checked = showVariantsInput,
                                onCheckedChange = { showVariantsInput = it }
                            )
                            Text("Add Variants")
                        }

                        if (showVariantsInput) {
                            OutlinedTextField(
                                value = variantInput,
                                onValueChange = { variantInput = it },
                                label = { Text("Variant Name (Press Enter to add)") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                                keyboardActions = KeyboardActions(
                                    onDone = {
                                        if (variantInput.isNotBlank()) {
                                            variants = variants + variantInput.trim()
                                            variantInput = ""
                                        }
                                    }
                                )
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            LazyRow(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                items(variants) { variant ->
                                    Surface(
                                        color = MaterialTheme.colorScheme.secondaryContainer,
                                        shape = RoundedCornerShape(16.dp),
                                        modifier = Modifier.padding(vertical = 4.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        ) {
                                            Text(text = variant, fontSize = 12.sp)
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove",
                                                modifier = Modifier.size(16.dp).clickable {
                                                    variants = variants - variant
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = onDismiss) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(onClick = {
                                val id = itemToEdit?.id ?: Firebase.database.getReference("items").push().key ?: ""
                                val newItem = Item(
                                    id = id, 
                                    name = name, 
                                    uom = uom, 
                                    hsnCode = hsnCode, 
                                    gstRate = gstRate,
                                    variants = if (showVariantsInput) variants else emptyList()
                                )
                                onItemAdded(newItem)
                                onDismiss()
                            }) {
                                Text("Save")
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun AddUomDialog(
    onDismiss: () -> Unit,
    onUomAdded: (String) -> Unit,
    uomViewModel: UomViewModel
) {
    var newUom by remember { mutableStateOf("") }
    val uoms by uomViewModel.uoms.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add UOM") },
        text = {
            Column {
                OutlinedTextField(
                    value = newUom,
                    onValueChange = { newUom = it },
                    label = { Text("New UOM") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                )
                Spacer(modifier = Modifier.height(16.dp))
                LazyColumn(modifier = Modifier.heightIn(max = 240.dp)) {
                    items(uoms) { uom ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(uom.name)
                            IconButton(onClick = { uomViewModel.deleteUom(uom.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete UOM")
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (newUom.isNotBlank()) {
                    onUomAdded(newUom)
                    newUom = ""
                }
            }) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
