package com.example.shahstores.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.shahstores.model.BillEntry
import kotlinx.coroutines.delay

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EntriesScreen(
    billEntries: List<BillEntry>,
    onEditBill: (BillEntry) -> Unit,
    onDeleteBill: (BillEntry) -> Unit,
    onViewBill: (BillEntry) -> Unit,
    onRetrySync: (BillEntry) -> Unit = {},
    onTimeout: (BillEntry) -> Unit = {},
    highlightedBillNo: String? = null,
    onHighlightCleared: () -> Unit = {}
) {
    val scrollState = rememberScrollState()
    val lazyListState = rememberLazyListState()
    var showDeleteConfirmationDialog by remember { mutableStateOf<BillEntry?>(null) }
    val context = LocalContext.current

    val infiniteTransition = rememberInfiniteTransition(label = "syncRotation")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -360f, // ANTICLOCKWISE rotation
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    LaunchedEffect(highlightedBillNo) {
        if (highlightedBillNo != null) {
            val index = billEntries.indexOfFirst { it.billNo == highlightedBillNo }
            if (index != -1) {
                lazyListState.animateScrollToItem(index)
                delay(2000) // Keep highlighted for 2 seconds
                onHighlightCleared()
            } else {
                onHighlightCleared()
            }
        }
    }

    if (showDeleteConfirmationDialog != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirmationDialog = null },
            title = { Text("Delete Entry") },
            text = { Text("Are you sure you want to delete this entry?") },
            confirmButton = {
                TextButton(onClick = {
                    showDeleteConfirmationDialog?.let { onDeleteBill(it) }
                    showDeleteConfirmationDialog = null
                }) {
                    Text("Yes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmationDialog = null }) {
                    Text("No")
                }
            }
        )
    }

    if (billEntries.isEmpty()) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "No entries found")
        }
    } else {
        Box(modifier = Modifier.fillMaxSize().horizontalScroll(scrollState)) {
            LazyColumn(
                state = lazyListState,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                itemsIndexed(billEntries, key = { _, entry -> entry.id.ifBlank { entry.sn.toString() } }) { index, entry ->
                    val isSyncing = entry.pdfUrl == "syncing"
                    val isError = entry.pdfUrl == "error"
                    val isHighlighted = entry.billNo == highlightedBillNo

                    val backgroundColor = remember { Animatable(Color.Transparent) }
                    
                    LaunchedEffect(isHighlighted) {
                        if (isHighlighted) {
                            repeat(3) {
                                backgroundColor.animateTo(Color.Yellow.copy(alpha = 0.5f), animationSpec = tween(300))
                                backgroundColor.animateTo(Color.Transparent, animationSpec = tween(300))
                            }
                        } else {
                            backgroundColor.snapTo(Color.Transparent)
                        }
                    }
                    
                    // Trigger timeout if syncing for more than 30 seconds
                    if (isSyncing) {
                        LaunchedEffect(entry.sn, entry.pdfUrl) {
                            delay(30000)
                            // If still syncing after 30s, force it to error state to stop rotation
                            if (entry.pdfUrl == "syncing") {
                                onTimeout(entry)
                            }
                        }
                    }
                    
                    Column(modifier = Modifier.background(backgroundColor.value)) {
                        Row(modifier = Modifier
                            .height(IntrinsicSize.Min)
                            .padding(vertical = 8.dp)
                            .combinedClickable(
                                onClick = { if (!isSyncing && !isError) onEditBill(entry) },
                                onLongClick = {
                                    if (index == 0) {
                                        showDeleteConfirmationDialog = entry
                                    } else {
                                        Toast.makeText(context, "Only the most recent bill can be deleted", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            ),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val displayBillNo = entry.billNo.split("/").lastOrNull() ?: entry.billNo
                            
                            Box(modifier = Modifier.width(60.dp), contentAlignment = Alignment.CenterStart) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = displayBillNo,
                                        modifier = Modifier.combinedClickable(
                                            onClick = {
                                                if (isSyncing) {
                                                     Toast.makeText(context, "Bill is still syncing...", Toast.LENGTH_SHORT).show()
                                                } else if (isError) {
                                                     Toast.makeText(context, "Retrying sync...", Toast.LENGTH_SHORT).show()
                                                     onRetrySync(entry)
                                                } else {
                                                    onViewBill(entry)
                                                }
                                            },
                                            onLongClick = {
                                                if (index == 0) {
                                                    showDeleteConfirmationDialog = entry
                                                } else {
                                                    Toast.makeText(context, "Only the most recent bill can be deleted", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        )
                                    )
                                    if (isSyncing || isError) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = if (isSyncing) Icons.Default.Sync else Icons.Default.Refresh,
                                            contentDescription = if (isSyncing) "Syncing" else "Retry Sync",
                                            tint = Color.Red,
                                            modifier = Modifier
                                                .size(16.dp)
                                                .rotate(if (isSyncing) rotation else 0f)
                                                .clickable { 
                                                    onRetrySync(entry)
                                                }
                                        )
                                    }
                                }
                            }
                            
                            VerticalDivider(Modifier.fillMaxHeight().padding(horizontal = 8.dp), color = Color.LightGray)
                            Text(text = entry.date, modifier = Modifier.width(100.dp))
                            VerticalDivider(Modifier.fillMaxHeight().padding(horizontal = 8.dp), color = Color.LightGray)
                            Text(text = entry.bundle, modifier = Modifier.width(20.dp))
                            VerticalDivider(Modifier.fillMaxHeight().padding(horizontal = 8.dp), color = Color.LightGray)
                            Text(
                                text = entry.customerName,
                                modifier = Modifier.width(200.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            VerticalDivider(Modifier.fillMaxHeight().padding(horizontal = 8.dp), color = Color.LightGray)
                            Text(
                                text = entry.customer?.address ?: "",
                                modifier = Modifier.width(100.dp),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            VerticalDivider(Modifier.fillMaxHeight().padding(horizontal = 8.dp), color = Color.LightGray)
                            Text(text = String.format("%.2f", entry.amount), modifier = Modifier.width(100.dp))
                        }
                        HorizontalDivider(color = Color.LightGray)
                    }
                }
                item {
                    Spacer(modifier = Modifier.height(80.dp))
                }
            }
        }
    }
}
