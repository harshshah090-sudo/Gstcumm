package com.example.shahstores.viewmodel

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.shahstores.data.FirmInfoRepository
import com.example.shahstores.model.FirmInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class FirmInfoUiState {
    object Loading : FirmInfoUiState()
    data class Success(val firmInfo: FirmInfo) : FirmInfoUiState()
    object Error : FirmInfoUiState()
}

class FirmInfoViewModel : ViewModel() {
    private val repository = FirmInfoRepository()

    private val _uiState = MutableStateFlow<FirmInfoUiState>(FirmInfoUiState.Loading)
    val uiState: StateFlow<FirmInfoUiState> = _uiState.asStateFlow()

    var isEditing by mutableStateOf(false)
        private set

    init {
        loadFirmInfo()
    }

    fun loadFirmInfo() {
        viewModelScope.launch {
            _uiState.value = FirmInfoUiState.Loading
            repository.getFirmInfo().collect {
                _uiState.value = if (it != null) {
                    FirmInfoUiState.Success(it)
                } else {
                    isEditing = true
                    FirmInfoUiState.Success(FirmInfo())
                }
            }
        }
    }

    fun saveFirmInfo(
        firmInfo: FirmInfo,
        logoUri: Uri?,
        signatureUri: Uri?,
        qrCodeUri: Uri?,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val updatedInfo = repository.saveFirmInfo(firmInfo, logoUri, signatureUri, qrCodeUri)
            _uiState.value = FirmInfoUiState.Success(updatedInfo)
            isEditing = false
            onSuccess()
        }
    }

    fun enterEditMode() {
        isEditing = true
    }

    fun exitEditMode() {
        isEditing = false
    }
}
