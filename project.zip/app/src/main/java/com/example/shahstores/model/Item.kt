package com.example.shahstores.model

data class Item(
    val id: String = "",
    val name: String = "",
    val uom: String = "",
    val hsnCode: String = "",
    val gstRate: String = "",
    val variants: List<String> = emptyList()
)
