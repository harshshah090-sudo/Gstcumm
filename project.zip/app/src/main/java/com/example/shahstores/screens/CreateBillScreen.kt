package com.example.shahstores.screens

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.util.Log
import android.view.Gravity
import android.widget.TextView
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.shahstores.model.BillEntry
import com.example.shahstores.model.BillItem
import com.example.shahstores.model.Customer
import com.example.shahstores.model.Item
import com.example.shahstores.model.PendingBill
import com.example.shahstores.util.calculateNextBillNo
import com.example.shahstores.util.downloadImage
import com.example.shahstores.util.generatePdf
import com.example.shahstores.util.getFinancialYear
import com.example.shahstores.util.uploadPdfToFirebase
import com.example.shahstores.util.sanitizeFirebaseKey
import com.example.shahstores.viewmodel.FirmInfoUiState
import com.example.shahstores.viewmodel.FirmInfoViewModel
import com.example.shahstores.viewmodel.UomViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.database.ktx.getValue
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.text.DecimalFormat
import java.util.Calendar
import java.util.TimeZone
import kotlin.random.Random
import kotlinx.coroutines.CoroutineScope
import java.io.File

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalComposeUiApi::class)
@Composable
fun CreateBillScreen(
    onDismiss: () -> Unit,
    onCancel: () -> Unit,
    onPreviewPdf: (File) -> Unit,
    customers: List<Customer>,
    items: List<Item>,
    onEditCustomer: (Customer) -> Unit,
    firmInfoViewModel: FirmInfoViewModel = viewModel(),
    onBillSaved: (BillEntry) -> Unit,
    editingBill: BillEntry? = null,
    initialBillNo: String = "SS/25-26/0001",
    initialDate: String? = null,
    isOnline: Boolean = true,
    deviceId: String = "",
    billEntries: List<BillEntry> = emptyList(),
    externalScope: CoroutineScope = rememberCoroutineScope(),
    pendingBills: List<PendingBill> = emptyList(),
    onUpdatePendingBill: (PendingBill) -> Unit = {},
    onDeletePendingBill: (PendingBill) -> Unit = {},
    selectedCustomer: Customer? = null,
    onCustomerSelected: (Customer?) -> Unit = {},
    uomViewModel: UomViewModel = viewModel(),
    onAddNewItem: (Item) -> Unit = {}
) {
    var showCustomerSelectionDialog by remember { mutableStateOf(editingBill == null && selectedCustomer == null) }
    var showItemSelectionDialog by remember { mutableStateOf(false) }
    var showExitConfirmationDialog by remember { mutableStateOf(false) }
    var showConflictDialog by remember { mutableStateOf(false) }
    var showBundleDialog by remember { mutableStateOf(false) }
    var showInvoiceEditDialog by remember { mutableStateOf(false) }
    var showDatePicker by remember { mutableStateOf(false) }
    var showPendingBillPrompt by remember { mutableStateOf<PendingBill?>(null) }

    var selectedDate by remember { mutableStateOf(editingBill?.date ?: initialDate ?: SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH).format(Date())) }
    var currentBillNo by remember { mutableStateOf(editingBill?.billNo ?: initialBillNo) }
    var isManualBillNo by remember { mutableStateOf(editingBill != null) }
    
    val sdf = remember { SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH) }

    var logoBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var signatureBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var qrCodeBitmap by remember { mutableStateOf<Bitmap?>(null) }

    // Helper to get numeric part of bill
    fun getBillNum(billNo: String): Int? = billNo.split("/").lastOrNull()?.toIntOrNull()

    // Find date bounds for "Sandwich Rule"
    fun getBillDateBounds(billNo: String): Pair<Date?, Date?> {
        val num = getBillNum(billNo) ?: return null to null
        val session = getFinancialYear(try { sdf.parse(selectedDate) } catch(_:Exception) { Date() } ?: Date())
        
        val sameSessionBills = billEntries.filter {
            try {
                val d = sdf.parse(it.date)
                d != null && getFinancialYear(d) == session
            } catch (_: Exception) { false }
        }

        val prevBill = sameSessionBills.find { getBillNum(it.billNo) == num - 1 }
        val nextBill = sameSessionBills.find { getBillNum(it.billNo) == num + 1 }

        val lowerDate = prevBill?.let { try { sdf.parse(it.date) } catch(_:Exception){null} }
        val upperDate = nextBill?.let { try { sdf.parse(it.date) } catch(_:Exception){null} }

        return lowerDate to upperDate
    }

    // Logic to update Invoice Number when date OR billEntries changes (fixes race condition)
    LaunchedEffect(selectedDate, billEntries) {
        if (editingBill == null && !isManualBillNo) {
            val newBillNo = calculateNextBillNo(selectedDate, billEntries)
            if (currentBillNo != newBillNo) {
                currentBillNo = newBillNo
            }
        }
    }

    // Logic to adjust date based on Bill No (Gap filling)
    LaunchedEffect(currentBillNo) {
        if (editingBill == null && isManualBillNo) {
            val bounds = getBillDateBounds(currentBillNo)
            // If there's a next bill, default to its date as requested
            bounds.second?.let { nextDate ->
                val nextDateStr = sdf.format(nextDate)
                if (selectedDate != nextDateStr) {
                    selectedDate = nextDateStr
                }
            } ?: bounds.first?.let { prevDate ->
                // Otherwise if there's a previous bill, ensure current date isn't older
                val currentD = try { sdf.parse(selectedDate) } catch(_:Exception) { null }
                if (currentD != null && currentD.before(prevDate)) {
                    selectedDate = sdf.format(prevDate)
                }
            }
        }
    }

    val billItems = remember { mutableStateListOf<Pair<Item, BillItem>>() }
    val customerRates = remember { mutableStateMapOf<String, String>() }
    
    val context = LocalContext.current
    val uiState by firmInfoViewModel.uiState.collectAsState()
    val scope = rememberCoroutineScope()
    var focusedItem by remember { mutableStateOf<Item?>(null) }
    val keyboardController = LocalSoftwareKeyboardController.current
    var isSaving by remember { mutableStateOf(false) }

    val database = Firebase.database
    val lockRef = database.getReference("creation_lock")
    val ratesRef = database.getReference("customer_item_rates")

    // Pre-download bitmaps
    LaunchedEffect(uiState) {
        if (uiState is FirmInfoUiState.Success) {
            val firmInfo = (uiState as FirmInfoUiState.Success).firmInfo
            if (firmInfo.firmLogoUrl.isNotBlank()) {
                logoBitmap = downloadImage(firmInfo.firmLogoUrl)
            }
            if (firmInfo.signatureUrl.isNotBlank()) {
                signatureBitmap = downloadImage(firmInfo.signatureUrl)
            }
            if (firmInfo.qrCodeUrl.isNotBlank()) {
                qrCodeBitmap = downloadImage(firmInfo.qrCodeUrl)
            }
        }
    }

    // Fetch saved rates for the selected customer
    LaunchedEffect(selectedCustomer) {
        selectedCustomer?.let { customer ->
            ratesRef.child(sanitizeFirebaseKey(customer.name)).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    customerRates.clear()
                    snapshot.children.forEach { child ->
                        val itemKey = child.key ?: ""
                        val rate = child.value?.toString() ?: ""
                        if (itemKey.isNotBlank() && rate.isNotBlank()) {
                            customerRates[itemKey] = rate
                        }
                    }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
        } ?: customerRates.clear()
    }

    LaunchedEffect(Unit) {
        lockRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val currentLock = snapshot.getValue<Map<String, Any>>()
                if (currentLock != null && currentLock["deviceId"] != deviceId) {
                    val timestamp = (currentLock["timestamp"] as? Number)?.toLong() ?: 0L
                    val now = System.currentTimeMillis()
                    // Only exit if lock is fresh (within 10 mins)
                    if (now - timestamp < 600000) {
                        Toast.makeText(context, "Another user started creating a bill, closing window", Toast.LENGTH_LONG).show()
                        onCancel()
                    }
                }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    LaunchedEffect(editingBill) {
        if (editingBill != null) {
            billItems.clear()
            editingBill.items.forEach { detail ->
                billItems.add(detail.item to BillItem(
                    qty = detail.quantity, 
                    rate = detail.rate, 
                    isSelected = true,
                    variantSelections = detail.variantSelections
                ))
            }
            if (selectedCustomer == null) {
                onCustomerSelected(editingBill.customer)
            }
        }
    }

    BackHandler {
        if (showConflictDialog) {
            // Force user to exit via the dialog button
        } else if (billItems.isEmpty()) {
            onCancel()
        } else {
            showExitConfirmationDialog = true
        }
    }

    if (showConflictDialog) {
        AlertDialog(
            onDismissRequest = { /* Force exit via button */ },
            title = { Text("Access Denied") },
            text = { Text("Another device has created the bill, Kindly Exit") },
            confirmButton = {
                TextButton(onClick = onCancel) {
                    Text("Exit")
                }
            }
        )
    }

    if (showExitConfirmationDialog) {
        AlertDialog(
            onDismissRequest = { showExitConfirmationDialog = false },
            title = { Text("Exit Confirmation") },
            text = { Text("Are you sure you want to exit, all the changes will be deleted") },
            confirmButton = {
                TextButton(onClick = onCancel) {
                    Text("Yes")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitConfirmationDialog = false }) {
                    Text("No")
                }
            }
        )
    }

    if (showCustomerSelectionDialog) {
        CustomerSelectionDialog(
            customers = customers,
            onDismiss = { showCustomerSelectionDialog = false },
            onCustomerSelected = { customer ->
                onCustomerSelected(customer)
                showCustomerSelectionDialog = false
                val pending = pendingBills.find { it.customerName == customer.name && it.customerAddress == customer.address }
                if (pending != null) {
                    showPendingBillPrompt = pending
                }
            }
        )
    }

    if (showPendingBillPrompt != null) {
        Dialog(onDismissRequest = { showPendingBillPrompt = null }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primary)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Pending Bill",
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.titleLarge
                        )
                    }
                    
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Aapko is customer ka ${showPendingBillPrompt!!.amount} ka bill banana baki hai",
                            style = MaterialTheme.typography.bodyLarge
                        )
                        
                        Spacer(modifier = Modifier.height(24.dp))
                        
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            TextButton(onClick = { showPendingBillPrompt = null }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(onClick = {
                                val targetAmount = showPendingBillPrompt!!.amount.toDoubleOrNull() ?: 0.0
                                generateRandomBill(items, billItems, targetAmount, targetAmount, context, 6, customerRates)
                                showPendingBillPrompt = null
                            }) {
                                Text("Create")
                            }
                        }
                    }
                }
            }
        }
    }

    if (showItemSelectionDialog) {
        ItemSelectionDialog(
            items = items,
            onDismiss = { showItemSelectionDialog = false },
            onItemsSelected = { selectedItemsMapFromDialog ->
                selectedItemsMapFromDialog.forEach { (item, billItem) ->
                    val existingEntry = billItems.find { it.first == item }
                    if (existingEntry != null) {
                        billItems.remove(existingEntry)
                    }
                    val itemKey = if (item.id.isNotBlank()) item.id else sanitizeFirebaseKey(item.name)
                    val initialRate = customerRates[itemKey] ?: ""
                    val updatedBillItem = if (existingEntry != null) {
                        existingEntry.second.copy(
                            qty = billItem.qty, 
                            variantSelections = billItem.variantSelections,
                            rate = if (existingEntry.second.rate.isBlank()) initialRate else existingEntry.second.rate
                        )
                    } else {
                        billItem.copy(rate = initialRate, isSelected = true)
                    }
                    billItems.add(item to updatedBillItem)
                }
                showItemSelectionDialog = false
            },
            uomViewModel = uomViewModel,
            onAddNewItem = onAddNewItem
        )
    }

    if (showInvoiceEditDialog) {
        InvoiceNumberDialog(
            currentInvoiceNo = currentBillNo,
            onDismiss = { showInvoiceEditDialog = false },
            onSave = { newInvoiceNo ->
                val alreadyExists = billEntries.any { it.billNo == newInvoiceNo && it.sn != editingBill?.sn }
                if (alreadyExists) {
                    Toast.makeText(context, "Invoice number already exists", Toast.LENGTH_SHORT).show()
                } else {
                    currentBillNo = newInvoiceNo
                    isManualBillNo = true
                    showInvoiceEditDialog = false
                }
            }
        )
    }

    if (showDatePicker) {
        val datePickerState = rememberDatePickerState(
            initialSelectedDateMillis = try { 
                val date = sdf.parse(selectedDate)
                val cal = Calendar.getInstance()
                cal.time = date
                val utcCal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                    set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH), 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                utcCal.timeInMillis
            } catch (e: Exception) { null }
        )

        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { selectedMillis ->
                        val calendarUtc = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = selectedMillis }
                        
                        // Convert UTC midnight from picker to Local midnight for comparison and formatting
                        val localCal = Calendar.getInstance().apply {
                            set(calendarUtc.get(Calendar.YEAR), calendarUtc.get(Calendar.MONTH), calendarUtc.get(Calendar.DAY_OF_MONTH), 0, 0, 0)
                            set(Calendar.MILLISECOND, 0)
                        }
                        val selectedLocalD = localCal.time
                        val newDateStr = sdf.format(selectedLocalD)
                        
                        val bounds = getBillDateBounds(currentBillNo)
                        val prevDate = bounds.first
                        val nextDate = bounds.second

                        if (prevDate != null && selectedLocalD.before(prevDate)) {
                            Toast.makeText(context, "Date cannot be older than Bill #${getBillNum(currentBillNo)!! - 1} (${sdf.format(prevDate)})", Toast.LENGTH_LONG).show()
                        } else if (nextDate != null && selectedLocalD.after(nextDate)) {
                            Toast.makeText(context, "Date cannot be newer than Bill #${getBillNum(currentBillNo)!! + 1} (${sdf.format(nextDate)})", Toast.LENGTH_LONG).show()
                        } else {
                            selectedDate = newDateStr
                            showDatePicker = false
                        }
                    }
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    val totalSum = billItems
        .filter { it.second.isSelected }
        .sumOf { (item, billItem) ->
            val amount = (billItem.qty.toDoubleOrNull() ?: 0.0) * (billItem.rate.toDoubleOrNull() ?: 0.0)
            val gstStr = item.gstRate.replace("%", "")
            val gst = amount * (gstStr.toDoubleOrNull() ?: 0.0) / 100.0
            amount + gst
        }

    val selectedItems = billItems.filter { it.second.isSelected }
    val allItemsValid = selectedItems.all { it.second.qty.isNotBlank() && it.second.rate.isNotBlank() }
    val isInteractionEnabled = isOnline && !isSaving && !showConflictDialog
    val isSaveEnabled = selectedCustomer != null && selectedItems.isNotEmpty() && allItemsValid && isInteractionEnabled

    val performSave: (String) -> Unit = { bundleNumber ->
        isSaving = true
        if (uiState is FirmInfoUiState.Success) {
            val firmInfo = (uiState as FirmInfoUiState.Success).firmInfo
            val firmInfoMap = mapOf(
                "firmName" to firmInfo.firmName,
                "address" to firmInfo.firmAddress,
                "gstin" to firmInfo.firmGstin,
                "phone" to "${firmInfo.phoneNo1} ${firmInfo.phoneNo2} ${firmInfo.phoneNo3}",
                "logoUri" to firmInfo.firmLogoUrl,
                "bankName" to firmInfo.bankName,
                "accountNumber" to firmInfo.bankAccNo,
                "ifscCode" to firmInfo.bankIfsc,
                "signatureUri" to firmInfo.signatureUrl,
                "qrCodeUri" to firmInfo.qrCodeUrl
            )
            scope.launch {
                val pdfFile = generatePdf(
                    context, 
                    firmInfoMap, 
                    selectedCustomer!!, 
                    selectedItems.toMap(), 
                    currentBillNo,
                    bundleNumber,
                    selectedDate,
                    logoBitmap,
                    signatureBitmap,
                    qrCodeBitmap
                )
                if (pdfFile != null) {
                    // Handling Pending Bill logic
                    val pending = pendingBills.find { it.customerName == selectedCustomer.name && it.customerAddress == selectedCustomer.address }
                    if (pending != null) {
                        val pendingAmt = pending.amount.toDoubleOrNull() ?: 0.0
                        if (totalSum >= pendingAmt) {
                            onDeletePendingBill(pending)
                        } else {
                            onUpdatePendingBill(pending.copy(amount = String.format("%.2f", pendingAmt - totalSum)))
                        }
                    }

                    // IMMEDIATELY show the PDF within the app
                    onPreviewPdf(pdfFile)

                    val newBillItems = selectedItems.map { (item, billItem) ->
                        val amount = (billItem.qty.toDoubleOrNull() ?: 0.0) * (billItem.rate.toDoubleOrNull() ?: 0.0)
                        val gstStr = item.gstRate.replace("%", "")
                        val gst = amount * (gstStr.toDoubleOrNull() ?: 0.0) / 100.0
                        
                        // Update Customer Specific Item Rate in Firebase using ID
                        val itemKey = if (item.id.isNotBlank()) item.id else sanitizeFirebaseKey(item.name)
                        ratesRef.child(sanitizeFirebaseKey(selectedCustomer.name))
                            .child(itemKey)
                            .setValue(billItem.rate)

                        com.example.shahstores.model.BillEntryItem(
                            item = item,
                            quantity = billItem.qty,
                            rate = billItem.rate,
                            amount = amount + gst,
                            variantSelections = billItem.variantSelections
                        )
                    }

                    // Save the bill entry with "ready" status so it is immediately available across all devices
                    val finalBillEntry = BillEntry(
                        sn = editingBill?.sn ?: 0,
                        billNo = currentBillNo,
                        date = selectedDate,
                        bundle = bundleNumber,
                        customerName = selectedCustomer.name,
                        amount = totalSum,
                        pdfUrl = "ready", // Synced and ready to view/print on all devices
                        customer = selectedCustomer,
                        items = newBillItems
                    )
                    
                    onBillSaved(finalBillEntry)
                    
                    // IMMEDIATELY dismiss the creation screen
                    onDismiss()

                    // Release the lock in externalScope
                    externalScope.launch {
                        try {
                            // If Firebase Storage is available, upload as optional cloud backup
                            uploadPdfToFirebase(pdfFile)?.let { cloudUrl ->
                                onBillSaved(finalBillEntry.copy(pdfUrl = cloudUrl))
                            }
                        } catch (e: Exception) {
                            Log.w("CreateBillScreen", "Optional cloud PDF backup skipped: ${e.message}")
                        } finally {
                            // ALWAYS release the lock
                            lockRef.removeValue()
                        }
                    }
                } else {
                    Toast.makeText(context, "Failed to generate PDF", Toast.LENGTH_SHORT).show()
                    isSaving = false
                }
            }
        } else {
            Toast.makeText(context, "Firm information not loaded yet", Toast.LENGTH_SHORT).show()
            isSaving = false
        }
    }

    if (showBundleDialog) {
        BundleDialog(
            onDismiss = { showBundleDialog = false },
            onConfirm = { bundleNumber ->
                showBundleDialog = false
                performSave(bundleNumber)
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = currentBillNo,
                            modifier = Modifier.combinedClickable(
                                onClick = {},
                                onLongClick = { if (isInteractionEnabled) showInvoiceEditDialog = true }
                            )
                        )
                        if (!isOnline) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = Color.Blue,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "OFFLINE",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                },
                actions = {
                    Text(
                        text = selectedDate,
                        modifier = Modifier
                            .padding(end = 16.dp)
                            .combinedClickable(
                                onClick = {},
                                onLongClick = { if (isInteractionEnabled) showDatePicker = true }
                            )
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)) {
            LazyColumn(modifier = Modifier.padding(16.dp)) {
                item {
                    selectedCustomer?.let { customer ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .combinedClickable(
                                    onClick = { 
                                        if (!isInteractionEnabled) {
                                            if (!isOnline) Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                        } else if (!isSaving) {
                                            showCustomerSelectionDialog = true 
                                        }
                                    },
                                    onLongClick = { 
                                        if (isInteractionEnabled) {
                                            onEditCustomer(customer) 
                                        } else if (!isOnline) {
                                            Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                ),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(1.dp, Color.Black)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(IntrinsicSize.Min)
                                    .padding(16.dp)
                            ) {
                                if (customer.phoneNumber.isNullOrBlank() && customer.transport.isNullOrBlank()) {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (customer.name.isNotBlank()) {
                                            AutoResizingText(text = customer.name)
                                        }
                                        if (customer.address.isNotBlank()) {
                                            AutoResizingText(text = customer.address)
                                        }
                                    }
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Divider(
                                        color = Color.Black,
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .width(1.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (!customer.gstin.isNullOrBlank()) {
                                            AutoResizingText(text = customer.gstin!!)
                                        }
                                        val stateInfo = when {
                                            customer.state.isNotBlank() && customer.stateCode.isNotBlank() -> "${customer.state} - ${customer.stateCode}"
                                            customer.state.isNotBlank() -> customer.state
                                            customer.stateCode.isNotBlank() -> customer.stateCode
                                            else -> null
                                        }
                                        if (stateInfo != null) {
                                            AutoResizingText(text = stateInfo)
                                        }
                                    }
                                } else {
                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        if (customer.name.isNotBlank()) {
                                            AutoResizingText(text = customer.name)
                                        }
                                        if (customer.address.isNotBlank()) {
                                            AutoResizingText(text = customer.address)
                                        }
                                        if (!customer.gstin.isNullOrBlank()) {
                                            AutoResizingText(text = customer.gstin!!)
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))
                                    Divider(
                                        color = Color.Black,
                                        modifier = Modifier
                                            .fillMaxHeight()
                                            .width(1.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))

                                    Column(
                                        modifier = Modifier.weight(1f),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        val stateInfo = when {
                                            customer.state.isNotBlank() && customer.stateCode.isNotBlank() -> "${customer.state} - ${customer.stateCode}"
                                            customer.state.isNotBlank() -> customer.state
                                            customer.stateCode.isNotBlank() -> customer.stateCode
                                            else -> null
                                        }
                                        if (stateInfo != null) {
                                            AutoResizingText(text = stateInfo)
                                        }

                                        if (!customer.phoneNumber.isNullOrBlank()) {
                                            AutoResizingText(text = customer.phoneNumber!!)
                                        }

                                        if (!customer.transport.isNullOrBlank()) {
                                            AutoResizingText(text = customer.transport!!)
                                        }
                                    }
                                }
                            }
                        }
                    } ?: run {
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { 
                                    if (!isInteractionEnabled) {
                                        if (!isOnline) Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                    } else if (!isSaving) {
                                        showCustomerSelectionDialog = true 
                                    }
                                },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color.Gray)
                        ) {
                            Box(modifier = Modifier.padding(16.dp)) {
                                Text("Select Customer", color = Color.Gray)
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }

                item {
                    val scrollState = rememberScrollState()
                    Column(Modifier.horizontalScroll(scrollState)) {
                        Row(
                            modifier = Modifier
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val allItemsSelected = billItems.all { it.second.isSelected } && billItems.isNotEmpty()
                            Checkbox(
                                checked = allItemsSelected,
                                enabled = isInteractionEnabled,
                                onCheckedChange = {
                                    if (isInteractionEnabled) {
                                        val newSelectionState = !allItemsSelected
                                        billItems.forEachIndexed { index, pair ->
                                            billItems[index] = pair.copy(second = pair.second.copy(isSelected = newSelectionState))
                                        }
                                    }
                                }
                            )
                            Text("Item Name", modifier = Modifier.width(150.dp), textAlign = TextAlign.Left)
                            Text("UOM", modifier = Modifier.width(80.dp), textAlign = TextAlign.Left)
                            Text("Qty", modifier = Modifier.width(80.dp), textAlign = TextAlign.Left)
                            Text("Rate", modifier = Modifier.width(100.dp), textAlign = TextAlign.Left)
                            Text("GST", modifier = Modifier.width(80.dp), textAlign = TextAlign.Left)
                        }

                        billItems.forEachIndexed { index, (item, billItem) ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = billItem.isSelected,
                                    enabled = isInteractionEnabled,
                                    onCheckedChange = {
                                        billItems[index] = item to billItem.copy(isSelected = it)
                                    }
                                )
                                Column(modifier = Modifier.width(150.dp)) {
                                    Text(
                                        item.name,
                                        modifier = Modifier
                                            .clickable(enabled = isInteractionEnabled) {
                                                billItems[index] = item to billItem.copy(isSelected = !billItem.isSelected)
                                            },
                                        textAlign = TextAlign.Left
                                    )
                                    if (billItem.variantSelections.isNotEmpty()) {
                                        val variantText = billItem.variantSelections.entries.joinToString(", ") { "${it.key}/${it.value}" }
                                        Text(
                                            text = variantText,
                                            fontSize = 10.sp,
                                            color = Color.Gray,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                                Text(item.uom, modifier = Modifier.width(80.dp), textAlign = TextAlign.Left)
                                BasicTextField(
                                    value = billItem.qty,
                                    onValueChange = { billItems[index] = item to billItem.copy(qty = it) },
                                    modifier = Modifier.width(80.dp),
                                    enabled = isInteractionEnabled && billItem.variantSelections.isEmpty(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() })
                                )
                                BasicTextField(
                                    value = billItem.rate,
                                    onValueChange = { billItems[index] = item to billItem.copy(rate = it) },
                                    modifier = Modifier
                                        .width(100.dp)
                                        .onFocusChanged {
                                            if (it.isFocused) {
                                                focusedItem = item
                                            }
                                        },
                                    enabled = isInteractionEnabled,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                    keyboardActions = KeyboardActions(onDone = { keyboardController?.hide() })
                                )
                                Text(item.gstRate, modifier = Modifier.width(80.dp), textAlign = TextAlign.Left)
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(300.dp)) }
            }

            val saveOnClick: () -> Unit = {
                if (!isOnline) {
                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                } else if (showConflictDialog) {
                    // Access Denied
                } else if (isSaveEnabled) {
                    showBundleDialog = true
                } else if (selectedCustomer == null) {
                    Toast.makeText(context, "Please select a customer", Toast.LENGTH_SHORT).show()
                } else if (selectedItems.isEmpty()) {
                    Toast.makeText(context, "Please select at least one item", Toast.LENGTH_SHORT).show()
                } else {
                    showRedToast(context, "Please input Qty and Rate for all selected items")
                }
            }
            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 4.dp, vertical = 8.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                shadowElevation = 8.dp,
                color = Color.White,
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    val buttonColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                    val blackTextColor = Color.Black
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Button(
                            onClick = { 
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (!showConflictDialog) {
                                    generateRandomBill(items, billItems, 1000.0, 1200.0, context, 2, customerRates) 
                                }
                            },
                            modifier = Modifier.width(80.dp),
                            enabled = isInteractionEnabled,
                            colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                        ) { Text("1K", color = blackTextColor) }
                        Button(
                            onClick = { 
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (!showConflictDialog) {
                                    generateRandomBill(items, billItems, 3900.0, 4100.0, context, null, customerRates) 
                                }
                            },
                            modifier = Modifier.width(80.dp),
                            enabled = isInteractionEnabled,
                            colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                        ) { Text("4K", color = blackTextColor) }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .width(140.dp)
                                .height(40.dp)
                                .background(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = ButtonDefaults.shape
                                )
                                .border(
                                    width = 1.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                    shape = ButtonDefaults.shape
                                )
                                .clickable {
                                    if (!isOnline) {
                                        Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "%.2f".format(totalSum),
                                textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 12.sp
                            )
                        }
                        Button(
                            onClick = saveOnClick,
                            enabled = isSaveEnabled,
                            modifier = Modifier.width(140.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary,
                                disabledContainerColor = Color.Gray
                            )
                        ) {
                            if (isSaving) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color.White
                                )
                            } else {
                                Text("Save")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Button(
                            onClick = { 
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (!showConflictDialog) {
                                    generateRandomBill(items, billItems, 7900.0, 8100.0, context, null, customerRates) 
                                }
                            },
                            modifier = Modifier.width(80.dp),
                            enabled = isInteractionEnabled,
                            colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                        ) { Text("8K", color = blackTextColor) }
                        Button(
                            onClick = { 
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (!showConflictDialog) {
                                    generateRandomBill(items, billItems, 12900.0, 13100.0, context, null, customerRates) 
                                }
                            },
                            modifier = Modifier.width(80.dp),
                            enabled = isInteractionEnabled,
                            colors = ButtonDefaults.buttonColors(containerColor = buttonColor)
                        ) { Text("13K", color = blackTextColor) }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        FloatingActionButton(
                            onClick = {
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (isInteractionEnabled) {
                                    focusedItem?.let { item ->
                                        val billItemIndex = billItems.indexOfFirst { it.first == item }
                                        if (billItemIndex != -1) {
                                            val billItem = billItems[billItemIndex].second
                                            val rate = billItem.rate.toDoubleOrNull()
                                            val gstStr = item.gstRate.replace("%", "")
                                            val gstRate = gstStr.toDoubleOrNull()
                                            if (rate != null && gstRate != null) {
                                                val newRate = (rate * 100) / (gstRate + 100)
                                                val df = DecimalFormat("#.####")
                                                billItems[billItemIndex] = item to billItem.copy(rate = df.format(newRate))
                                            } else {
                                                Toast.makeText(context, "Invalid rate or GST", Toast.LENGTH_SHORT).show()
                                            }
                                        } else {
                                            Toast.makeText(context, "Please select an item", Toast.LENGTH_SHORT).show()
                                        }
                                    } ?: Toast.makeText(context, "Please select a rate field", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.size(38.dp),
                            shape = CircleShape,
                            containerColor = if (isInteractionEnabled) MaterialTheme.colorScheme.primary else Color.Gray
                        ) {
                            Text(text = "-%", color = Color.White, fontSize = 12.sp)
                        }
                        FloatingActionButton(
                            onClick = {
                                if (!isOnline) {
                                    Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                } else if (isInteractionEnabled) {
                                    if (selectedCustomer != null) {
                                        showItemSelectionDialog = true
                                    } else {
                                        showCustomerSelectionDialog = true
                                    }
                                }
                            },
                            modifier = Modifier.size(38.dp),
                            shape = CircleShape,
                            containerColor = if (isInteractionEnabled) MaterialTheme.colorScheme.primary else Color.Gray
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BundleDialog(
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var bundleText by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(300)
        focusRequester.requestFocus()
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Bundle",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                OutlinedTextField(
                    value = bundleText,
                    onValueChange = { if (it.all { char -> char.isDigit() }) bundleText = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Number,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            onConfirm(bundleText)
                        }
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    TextButton(onClick = { onConfirm(bundleText) }) {
                        Text("OK")
                    }
                }
            }
        }
    }
}

@Composable
fun InvoiceNumberDialog(
    currentInvoiceNo: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    val prefix = currentInvoiceNo.substringBeforeLast("/") + "/"
    val initialNumber = currentInvoiceNo.substringAfterLast("/")
    var invoiceNumber by remember { mutableStateOf(initialNumber) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        delay(300)
        focusRequester.requestFocus()
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Invoice Number",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
                OutlinedTextField(
                    value = invoiceNumber,
                    onValueChange = { if (it.all { char -> char.isDigit() }) invoiceNumber = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    label = { Text("Number") },
                    prefix = { Text(prefix) },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    TextButton(onClick = { onSave(prefix + invoiceNumber) }) { Text("Save") }
                }
            }
        }
    }
}

private fun generateRandomBill(
    items: List<Item>,
    billItems: MutableList<Pair<Item, BillItem>>,
    minTotal: Double,
    maxTotal: Double,
    context: Context,
    itemCount: Int? = null,
    savedRates: Map<String, String> = emptyMap()
) {
    val finalItemCount = itemCount ?: Random.nextInt(4, 6)
    if (items.size < finalItemCount) {
        Toast.makeText(context, "Not enough items available to generate a bill", Toast.LENGTH_SHORT).show()
        return
    }

    billItems.clear()
    val randomItems = items.shuffled().take(finalItemCount)
    val targetTotal = if (minTotal == maxTotal) minTotal else Random.nextDouble(minTotal, maxTotal)
    var remainingTotal = targetTotal

    randomItems.forEachIndexed { index, item ->
        val isLast = index == randomItems.size - 1
        
        val gstStr = item.gstRate.replace("%", "")
        val gstRate = gstStr.toDoubleOrNull() ?: 0.0
        val gstFactor = 1.0 + (gstRate / 100.0)

        val itemTarget = if (isLast) {
            remainingTotal
        } else {
            // Distribute remaining amount somewhat evenly
            val average = remainingTotal / (randomItems.size - index)
            Random.nextDouble(average * 0.8, average * 1.2)
        }

        // Use saved rate if available and in range [10, 150], otherwise random 10-150
        val itemKey = if (item.id.isNotBlank()) item.id else sanitizeFirebaseKey(item.name)
        val savedRateStr = savedRates[itemKey]
        val savedRate = savedRateStr?.toDoubleOrNull()
        val rateToUse = if (savedRate != null && savedRate >= 10.0 && savedRate <= 150.0) {
            savedRate
        } else {
            Random.nextInt(10, 150).toDouble()
        }

        // Calculate quantity needed for this item's target amount (including GST)
        // qty * rate * gstFactor = itemTarget
        var qty = (itemTarget / (rateToUse * gstFactor)).toInt()
        if (qty < 1) qty = 1
        
        // Final adjustment for last item to be precise
        var finalRate = if (isLast) {
            itemTarget / (qty * gstFactor)
        } else {
            rateToUse
        }

        // Ensure finalRate stays within [10, 150] by adjusting qty if needed
        if (isLast) {
            if (finalRate > 150.0) {
                while (finalRate > 150.0) {
                    qty++
                    finalRate = itemTarget / (qty * gstFactor)
                }
            } else if (finalRate < 10.0 && qty > 1) {
                while (finalRate < 10.0 && qty > 1) {
                    qty--
                    finalRate = itemTarget / (qty * gstFactor)
                }
            }
        }

        val formattedRate = String.format("%.2f", finalRate)
        billItems.add(item to BillItem(
            qty = qty.toString(),
            rate = formattedRate,
            isSelected = true
        ))

        remainingTotal -= qty * formattedRate.toDouble() * gstFactor
    }
}


fun showRedToast(context: Context, message: String) {
    val toast = Toast.makeText(context, message, Toast.LENGTH_SHORT)
    val view = toast.view
    @Suppress("DEPRECATION")
    view?.setBackgroundColor(android.graphics.Color.RED)
    val text = view?.findViewById<TextView>(android.R.id.message)
    text?.setTextColor(android.graphics.Color.WHITE)
    toast.setGravity(Gravity.CENTER, 0, 0)
    toast.show()
}


@Composable
private fun AutoResizingText(text: String) {
    var multiplier by remember { mutableStateOf(1f) }
    Text(
        text = text,
        maxLines = 1,
        softWrap = false,
        style = MaterialTheme.typography.bodyMedium.copy(
            fontSize = MaterialTheme.typography.bodyMedium.fontSize * multiplier
        ),
        onTextLayout = {
            if (it.didOverflowWidth) {
                multiplier *= 0.9f
            }
        }
    )
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
private fun CustomerSelectionDialog(
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onCustomerSelected: (Customer) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredCustomers = remember(searchQuery, customers) {
        if (searchQuery.isBlank()) {
            emptyList()
        } else {
            customers.filter { it.name.contains(searchQuery, ignoreCase = true) }.sortedBy { it.name }
        }
    }
    val focusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    LaunchedEffect(Unit) {
        delay(300)
        focusRequester.requestFocus()
        keyboardController?.show()
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            @Suppress("DEPRECATION")
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "Select Customer",
                        color = MaterialTheme.colorScheme.onPrimary,
                        style = MaterialTheme.typography.titleLarge
                    )
                }
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Search Customer") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .focusRequester(focusRequester),
                        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                    )
                    LazyColumn(modifier = Modifier.padding(top = 16.dp)) {
                        items(filteredCustomers) { customer ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onCustomerSelected(customer) }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = customer.name,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = customer.address,
                                    fontSize = 12.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(start = 8.dp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun ItemSelectionDialog(
    items: List<Item>,
    onDismiss: () -> Unit,
    onItemsSelected: (Map<Item, BillItem>) -> Unit,
    uomViewModel: UomViewModel,
    onAddNewItem: (Item) -> Unit
) {
    val selectedItemsMap = remember { mutableStateMapOf<Item, BillItem>() }
    val selectionOrder = remember { mutableStateListOf<Item>() }
    var searchQuery by remember { mutableStateOf("") }
    val filteredItems = remember(searchQuery, items) {
        items.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }
    val itemHeight = 48.dp
    val maxHeight = itemHeight * 5
    
    val searchFocusRequester = remember { FocusRequester() }
    val keyboardController = LocalSoftwareKeyboardController.current

    var showAddItemPopup by remember { mutableStateOf(false) }
    var itemForVariantSelection by remember { mutableStateOf<Item?>(null) }
    // State to trigger focus on a specific item's Qty field
    var focusedItemTrigger by remember { mutableStateOf<Pair<Item, Long>?>(null) }

    LaunchedEffect(Unit) {
        delay(300)
        searchFocusRequester.requestFocus()
        keyboardController?.show()
    }

    if (showAddItemPopup) {
        AddItemPopup(
            onDismiss = { showAddItemPopup = false },
            onItemAdded = { newItem ->
                onAddNewItem(newItem)
                showAddItemPopup = false
            },
            uomViewModel = uomViewModel
        )
    }

    if (itemForVariantSelection != null) {
        VariantSelectionDialog(
            item = itemForVariantSelection!!,
            initialSelections = selectedItemsMap[itemForVariantSelection!!]?.variantSelections ?: emptyMap(),
            onDismiss = { itemForVariantSelection = null },
            onConfirmed = { variantSelections ->
                val totalQty = variantSelections.values.sumOf { it.toIntOrNull() ?: 0 }
                if (totalQty > 0) {
                    selectedItemsMap[itemForVariantSelection!!] = BillItem(
                        qty = totalQty.toString(),
                        rate = "",
                        isSelected = true,
                        variantSelections = variantSelections
                    )
                    if (!selectionOrder.contains(itemForVariantSelection!!)) {
                        selectionOrder.add(itemForVariantSelection!!)
                    }
                } else {
                    selectedItemsMap.remove(itemForVariantSelection!!)
                    selectionOrder.remove(itemForVariantSelection!!)
                }
                itemForVariantSelection = null
            }
        )
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()){
                        Text(
                            text = "Select Items",
                            color = MaterialTheme.colorScheme.onPrimary,
                            style = MaterialTheme.typography.titleLarge
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { showAddItemPopup = true }) {
                                Icon(Icons.Default.Add, contentDescription = "Add New Item", tint = MaterialTheme.colorScheme.onPrimary)
                            }
                            IconButton(onClick = {
                                val orderedSelectedItems = linkedMapOf<Item, BillItem>()
                                selectionOrder.forEach { item ->
                                    orderedSelectedItems[item] = selectedItemsMap[item] ?: BillItem("", "", false)
                                }
                                onItemsSelected(orderedSelectedItems)
                            }) {
                                Icon(Icons.Default.Done, contentDescription = "Done", tint = MaterialTheme.colorScheme.onPrimary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        contentAlignment = Alignment.CenterStart,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .border(
                                width = 1.dp,
                                color = MaterialTheme.colorScheme.outline,
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 16.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier
                                    .weight(1f)
                                    .focusRequester(searchFocusRequester),
                                singleLine = true,
                                textStyle = TextStyle(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    fontSize = MaterialTheme.typography.bodySmall.fontSize
                                ),
                                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                                decorationBox = { innerTextField ->
                                    if (searchQuery.isEmpty()) {
                                        Text(
                                            text = "Search Item",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    innerTextField()
                                }
                            )
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = { 
                                        searchQuery = ""
                                        searchFocusRequester.requestFocus()
                                        keyboardController?.show()
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear Search",
                                        tint = Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                LazyColumn(modifier = Modifier.padding(16.dp).heightIn(max = maxHeight)) {
                    items(filteredItems) { item ->
                        val billItem = selectedItemsMap[item]
                        val isChecked = billItem != null
                        val qtyFocusRequester = remember { FocusRequester() }
                        
                        LaunchedEffect(focusedItemTrigger) {
                            if (focusedItemTrigger?.first == item && isChecked && item.variants.isEmpty()) {
                                delay(100)
                                qtyFocusRequester.requestFocus()
                                keyboardController?.show()
                            }
                        }
                        
                        Column(modifier = Modifier.fillMaxWidth()) {
                            val onCheckedChange: (Boolean) -> Unit = { checked ->
                                if (checked) {
                                    if (item.variants.isNotEmpty()) {
                                        itemForVariantSelection = item
                                    } else {
                                        if (!selectedItemsMap.containsKey(item)) {
                                            selectedItemsMap[item] = BillItem("", "", true)
                                            selectionOrder.add(item)
                                        }
                                        focusedItemTrigger = item to System.currentTimeMillis()
                                    }
                                } else {
                                    selectedItemsMap.remove(item)
                                    selectionOrder.remove(item)
                                }
                            }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(itemHeight)
                                    .clickable { 
                                        if (isChecked) {
                                            if (item.variants.isNotEmpty()) {
                                                itemForVariantSelection = item
                                            } else {
                                                focusedItemTrigger = item to System.currentTimeMillis()
                                            }
                                        } else {
                                            onCheckedChange(true)
                                        }
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = onCheckedChange
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.name)
                                    if (billItem?.variantSelections?.isNotEmpty() == true) {
                                        val variantText = billItem.variantSelections.entries.joinToString(", ") { "${it.key}/${it.value}" }
                                        Text(variantText, fontSize = 10.sp, color = Color.Gray)
                                    }
                                }
                                if (isChecked) {
                                    Box(
                                        modifier = Modifier
                                            .width(70.dp)
                                            .height(45.dp)
                                            .border(
                                                width = 1.dp,
                                                color = MaterialTheme.colorScheme.outline,
                                                shape = RoundedCornerShape(4.dp)
                                            )
                                            .padding(horizontal = 8.dp),
                                        contentAlignment = Alignment.CenterStart
                                    ) {
                                        BasicTextField(
                                            value = billItem?.qty ?: "",
                                            onValueChange = { 
                                                if (item.variants.isEmpty()) {
                                                    selectedItemsMap[item] = billItem?.copy(qty = it) ?: BillItem(it, "", true)
                                                }
                                            },
                                            enabled = item.variants.isEmpty(),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                                            keyboardActions = KeyboardActions(onDone = {
                                                val orderedSelectedItems = linkedMapOf<Item, BillItem>()
                                                selectionOrder.forEach { item ->
                                                    orderedSelectedItems[item] = selectedItemsMap[item] ?: BillItem("", "", false)
                                                }
                                                onItemsSelected(orderedSelectedItems)
                                            }),
                                            singleLine = true,
                                            textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Start),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .focusRequester(qtyFocusRequester)
                                        )
                                        if ((billItem?.qty ?: "").isEmpty()) {
                                            Text("Qty", color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                } else {
                                    Text(
                                        text = item.uom,
                                        fontSize = 12.sp,
                                        color = Color.Gray,
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }
                            Divider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VariantSelectionDialog(
    item: Item,
    initialSelections: Map<String, String>,
    onDismiss: () -> Unit,
    onConfirmed: (Map<String, String>) -> Unit
) {
    val selections = remember { mutableStateMapOf<String, String>().apply { putAll(initialSelections) } }
    val selectedVariants = remember { mutableStateListOf<String>().apply { addAll(initialSelections.keys) } }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            @Suppress("DEPRECATION")
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Select Variants for ${item.name}",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                LazyColumn(modifier = Modifier.heightIn(max = 400.dp)) {
                    items(item.variants) { variant ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = selectedVariants.contains(variant),
                                onCheckedChange = { checked ->
                                    if (checked) {
                                        selectedVariants.add(variant)
                                    } else {
                                        selectedVariants.remove(variant)
                                        selections.remove(variant)
                                    }
                                }
                            )
                            Text(text = variant, modifier = Modifier.weight(1f))
                            if (selectedVariants.contains(variant)) {
                                OutlinedTextField(
                                    value = selections[variant] ?: "",
                                    onValueChange = { selections[variant] = it },
                                    label = { Text("Qty") },
                                    modifier = Modifier.width(80.dp),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = {
                        val finalSelections = selections.filter { it.key in selectedVariants && it.value.isNotBlank() }
                        onConfirmed(finalSelections)
                    }) {
                        Text("OK")
                    }
                }
            }
        }
    }
}
