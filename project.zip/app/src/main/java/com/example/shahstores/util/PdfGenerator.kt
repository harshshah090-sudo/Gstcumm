package com.example.shahstores.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Log
import com.example.shahstores.model.BillEntry
import com.example.shahstores.model.BillItem
import com.example.shahstores.model.Customer
import com.example.shahstores.model.FirmInfo
import com.example.shahstores.model.Item
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.ktx.storage
import com.itextpdf.io.font.constants.StandardFonts
import com.itextpdf.io.image.ImageDataFactory
import com.itextpdf.kernel.colors.ColorConstants
import com.itextpdf.kernel.colors.DeviceRgb
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.kernel.geom.PageSize
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.action.PdfAction
import com.itextpdf.layout.Document
import com.itextpdf.layout.borders.Border
import com.itextpdf.layout.borders.SolidBorder
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.Image
import com.itextpdf.layout.element.Link
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.element.Text
import com.itextpdf.layout.properties.HorizontalAlignment
import com.itextpdf.layout.properties.TextAlignment
import com.itextpdf.layout.properties.UnitValue
import com.itextpdf.layout.properties.VerticalAlignment
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

suspend fun downloadImage(url: String): Bitmap? {
    return withContext(Dispatchers.IO) {
        try {
            Log.d("PdfGenerator", "Downloading image from: $url")
            val connection = URL(url).openConnection()
            connection.connect()
            val inputStream = connection.getInputStream()
            val bitmap = BitmapFactory.decodeStream(inputStream)
            inputStream.close()
            Log.d("PdfGenerator", "Image downloaded successfully.")
            bitmap
        } catch (e: Exception) {
            Log.e("PdfGenerator", "Error downloading image from $url", e)
            null
        }
    }
}

suspend fun generatePdf(
    context: Context,
    firmInfo: Map<String, String>,
    customer: Customer,
    billItems: Map<Item, BillItem>,
    invoiceNumber: String,
    bundleNumber: String = "",
    invoiceDate: String = "",
    logoBitmap: Bitmap? = null,
    signatureBitmap: Bitmap? = null,
    qrCodeBitmap: Bitmap? = null
): File? {
    val safeInvoiceNumber = invoiceNumber.replace('/', '-')
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val fileName = "Invoice_${safeInvoiceNumber}_${timestamp}.pdf"

    val file = File(context.cacheDir, fileName)

    return try {
        val outputStream = FileOutputStream(file)
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A5)
        document.setMargins(15f, 15f, 15f, 15f)

        val mainTable = Table(1).useAllAvailableWidth().setBorder(SolidBorder(ColorConstants.BLACK, 1.5f))

        val firmDetailsCell = Cell().setBorder(Border.NO_BORDER)
        val headerTable = Table(UnitValue.createPercentArray(floatArrayOf(1.3f, 2.5f, 1.5f))).useAllAvailableWidth().setBorder(Border.NO_BORDER)

        val logoCell = Cell().setBorder(Border.NO_BORDER).setVerticalAlignment(VerticalAlignment.MIDDLE).setPadding(5f)
        logoBitmap?.let { bitmap ->
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val image = Image(ImageDataFactory.create(stream.toByteArray()))
            image.setWidth(55f)
            logoCell.add(image)
        }
        headerTable.addCell(logoCell)

        val firmInfoCell = Cell().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.CENTER)
        firmInfoCell.add(Paragraph(firmInfo["firmName"] ?: "").setFontSize(20f).setBold().setTextAlignment(TextAlignment.CENTER))
        firmInfoCell.add(Paragraph(firmInfo["address"] ?: "").setFontSize(9f).setTextAlignment(TextAlignment.CENTER))
        firmInfoCell.add(Paragraph("GSTIN : ${firmInfo["gstin"] ?: ""}").setFontSize(9f).setTextAlignment(TextAlignment.CENTER))
        headerTable.addCell(firmInfoCell)

        val phoneCell = Cell().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingTop(5f).setPaddingRight(5f)
        (firmInfo["phone"] ?: "").split(" ").forEach { if (it.isNotBlank()) phoneCell.add(Paragraph(it).setFontSize(9f)) }
        headerTable.addCell(phoneCell)
        firmDetailsCell.add(headerTable)
        mainTable.addCell(firmDetailsCell)

        mainTable.addCell(Cell().add(Paragraph("TAX INVOICE").setBold().setTextAlignment(TextAlignment.CENTER)))

        val receiverInvoiceCell = Cell().setBorder(Border.NO_BORDER)
        val detailsTable = Table(UnitValue.createPercentArray(floatArrayOf(5.5f, 4.5f))).useAllAvailableWidth()
        val receiverNestedTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 3f))).useAllAvailableWidth()

        // Calculate extra lines for Name and Address to adjust table rows
        val nameWidth = 155f // Approximate width of the value column in points
        val nameLines = estimateLines(customer.name, 9f, nameWidth)
        val addressLines = estimateLines(customer.address, 9f, nameWidth)
        val extraLines = (nameLines - 1).coerceAtLeast(0) + (addressLines - 1).coerceAtLeast(0)

        val compactPara: (String) -> Paragraph = { text -> Paragraph(text).setFontSize(9f).setMargin(0f).setPadding(0f).setMultipliedLeading(1.0f) }

        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Name")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.name}")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Address")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.address}")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("GSTIN")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.gstin ?: ""}")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("State")))
        receiverNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.state}")))
        val receiverParentCell = Cell().add(Paragraph("Details of Receiver").setBold().setFontSize(9f).setMarginBottom(2f)).add(receiverNestedTable).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f))
        detailsTable.addCell(receiverParentCell)

        val invoiceNestedTable = Table(UnitValue.createPercentArray(floatArrayOf(2.5f, 2.5f))).useAllAvailableWidth()
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("INVOICE No.")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : $invoiceNumber").setBold()))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Date")))
        
        val displayDate = if (invoiceDate.isNotBlank()) {
            try {
                val inputSdf = SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH)
                val outputSdf = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH)
                val date = inputSdf.parse(invoiceDate)
                if (date != null) outputSdf.format(date) else invoiceDate
            } catch (e: Exception) {
                invoiceDate
            }
        } else {
            SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH).format(Date())
        }
        
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : $displayDate")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Transport Name")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.transport ?: ""}")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Mobile")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : ${customer.phoneNumber ?: ""}")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara("Bundle")))
        invoiceNestedTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(compactPara(" : $bundleNumber")))
        detailsTable.addCell(Cell().add(invoiceNestedTable).setPaddingLeft(5f))
        receiverInvoiceCell.add(detailsTable)
        mainTable.addCell(receiverInvoiceCell)

        val itemsCell = Cell().setBorder(Border.NO_BORDER).setPadding(0f)
        val itemsTable = Table(UnitValue.createPercentArray(floatArrayOf(0.8f, 3.84f, 1.5f, 0.8f, 0.8f, 0.8f, 0.96f, 1.5f))).useAllAvailableWidth()
        val headers = arrayOf("S.N.", "Item Description", "HSN Code", "Qty", "UOM", "GST", "Rate", "Amount")
        headers.forEach { itemsTable.addHeaderCell(Cell().add(Paragraph(it).setFontSize(9f).setBold()).setBorderBottom(SolidBorder(ColorConstants.BLACK, 0.5f))) }

        // Width for Item Description column is approx 136 points
        val descriptionWidth = 130f 
        var totalContentLines = 0

        var serialNumber = 1
        val selectedItemsList = billItems.filter { it.value.isSelected }
        selectedItemsList.forEach { (item, billItem) ->
            val qty = billItem.qty.toFloatOrNull() ?: 0f
            val rate = billItem.rate.toFloatOrNull() ?: 0f
            val amount = qty * rate
            val displayGst = item.gstRate.replace("%", "")
            
            itemsTable.addCell(Cell().add(Paragraph((serialNumber++).toString()).setFontSize(9f)).setTextAlignment(TextAlignment.CENTER).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            
            val itemDescriptionCell = Cell().setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f))
            itemDescriptionCell.add(Paragraph(item.name).setFontSize(9f))
            
            val itemLines = estimateLines(item.name, 9f, descriptionWidth)
            var variantLines = 0

            if (billItem.variantSelections.isNotEmpty()) {
                val variantText = billItem.variantSelections.entries.joinToString(", ") { "${it.key}/${it.value}" }
                itemDescriptionCell.add(Paragraph(variantText).setFontSize(7f).setItalic().setFontColor(ColorConstants.DARK_GRAY))
                variantLines = estimateLines(variantText, 7f, descriptionWidth)
            }
            
            totalContentLines += (itemLines + variantLines)
            
            itemsTable.addCell(itemDescriptionCell)
            
            itemsTable.addCell(Cell().add(Paragraph(item.hsnCode).setFontSize(9f)).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            itemsTable.addCell(Cell().add(Paragraph(billItem.qty).setFontSize(9f)).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            itemsTable.addCell(Cell().add(Paragraph(item.uom).setFontSize(9f)).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            itemsTable.addCell(Cell().add(Paragraph("$displayGst%").setFontSize(9f)).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            itemsTable.addCell(Cell().add(Paragraph(billItem.rate).setFontSize(9f)).setBorder(Border.NO_BORDER).setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f)))
            itemsTable.addCell(Cell().add(Paragraph(String.format("%.2f", amount)).setFontSize(9f)).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER))
        }

        val gstRateCount = selectedItemsList.keys.map { it.gstRate.replace("%", "").toFloatOrNull() ?: 0f }.distinct().count()

        // Adjusted target for filler rows to account for multi-line item descriptions
        val baseCapacity = 13
        val remainingCapacity = (baseCapacity - (gstRateCount - 1).coerceAtLeast(0) - extraLines - totalContentLines).coerceAtLeast(0)

        for (i in 0 until remainingCapacity) {
            for (j in 0..7) {
                val cell = Cell().add(Paragraph("\u00A0").setFontSize(9f)).setBorder(Border.NO_BORDER)
                if (j < 7) {
                    cell.setBorderRight(SolidBorder(ColorConstants.BLACK, 0.5f))
                }
                itemsTable.addCell(cell)
            }
        }
        itemsCell.add(itemsTable)
        mainTable.addCell(itemsCell)

        val gstCell = Cell().setBorder(Border.NO_BORDER).setPadding(0f)
        val gstTable = Table(UnitValue.createPercentArray(floatArrayOf(2f, 2f, 1.5f, 1.5f, 1.5f, 2f))).useAllAvailableWidth()
        val gstHeaders = arrayOf("GST Rate", "Taxable Amount", "CGST", "SGST", "IGST", "Total Amount")
        gstHeaders.forEach { gstTable.addHeaderCell(Cell().add(Paragraph(it).setFontSize(8f).setBold())) }

        var totalTaxableAmount = 0f
        var totalCgst = 0f
        var totalSgst = 0f
        var totalIgst = 0f

        billItems.filter { it.value.isSelected }.keys.map { it.gstRate.replace("%", "").toFloatOrNull() ?: 0f }.distinct().sorted().forEach { rate ->
            val itemsInRate = billItems.filter { (it.key.gstRate.replace("%", "").toFloatOrNull() ?: 0f) == rate && it.value.isSelected }
            var taxableAmount = 0f
            itemsInRate.values.forEach { billItem ->
                taxableAmount += (billItem.qty.toFloatOrNull() ?: 0f) * (billItem.rate.toFloatOrNull() ?: 0f)
            }

            if (taxableAmount > 0) {
                var cgst = 0f
                var sgst = 0f
                var igst = 0f
                if (customer.state.equals("Madhya Pradesh", ignoreCase = true)) {
                    cgst = taxableAmount * (rate / 200)
                    sgst = taxableAmount * (rate / 200)
                } else {
                    igst = taxableAmount * (rate / 100)
                }
                val totalAmount = taxableAmount + cgst + sgst + igst
                totalTaxableAmount += taxableAmount
                totalCgst += cgst
                totalSgst += sgst
                totalIgst += igst

                gstTable.addCell(Cell().add(Paragraph("${rate.toInt()}%").setFontSize(8f)))
                gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", taxableAmount)).setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
                gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", cgst)).setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
                gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", sgst)).setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
                gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", igst)).setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
                gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalAmount)).setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
            }
        }

        gstTable.addCell(Cell().add(Paragraph("Total").setBold().setFontSize(8f)))
        gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalTaxableAmount)).setBold().setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
        gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalCgst)).setBold().setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
        gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalSgst)).setBold().setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
        gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalIgst)).setBold().setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
        gstTable.addCell(Cell().add(Paragraph(String.format("%.2f", totalTaxableAmount + totalCgst + totalSgst + totalIgst)).setBold().setFontSize(8f)).setTextAlignment(TextAlignment.RIGHT))
        gstCell.add(gstTable)
        mainTable.addCell(gstCell)

        val footerCell = Cell().setBorder(Border.NO_BORDER)
        val footerTable = Table(UnitValue.createPercentArray(floatArrayOf(1.2f, 0.6f, 1.2f))).useAllAvailableWidth()

        val thinBlackBorder = SolidBorder(ColorConstants.BLACK, 0.5f)

        // LEFT COLUMN: Bank & Terms
        val leftColCell = Cell().setPadding(0f).setBorder(Border.NO_BORDER).setBorderRight(thinBlackBorder)
        val leftContentTable = Table(1).useAllAvailableWidth()
        
        // Bank Details Section
        val bankSection = Cell().setPadding(3f).setBorder(Border.NO_BORDER).setBorderBottom(thinBlackBorder)
        bankSection.add(Paragraph("Bank Details").setBold().setFontSize(9f).setMarginBottom(1f))
        
        val bankInfoTable = Table(UnitValue.createPercentArray(floatArrayOf(3.2f, 6.8f))).useAllAvailableWidth()
        fun addBankRow(label: String, value: String) {
            bankInfoTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(Paragraph(label).setFontSize(8f)))
            bankInfoTable.addCell(Cell().setBorder(Border.NO_BORDER).setPadding(0f).add(Paragraph(" : $value").setFontSize(8f)))
        }
        addBankRow("Bank", firmInfo["bankName"] ?: "")
        addBankRow("Bank A/C", firmInfo["accountNumber"] ?: "")
        addBankRow("Bank IFSC", firmInfo["ifscCode"] ?: "")
        bankSection.add(bankInfoTable)
        leftContentTable.addCell(bankSection)
        
        // Terms & Conditions Section
        val termsSection = Cell().setPadding(3f).setBorder(Border.NO_BORDER)
        termsSection.add(Paragraph("Terms & Conditions").setBold().setFontSize(8f).setMarginBottom(1f))
        termsSection.add(Paragraph("Subject to Indore Jurisdiction").setFontSize(7f))
        leftContentTable.addCell(termsSection)
        
        leftColCell.add(leftContentTable)
        footerTable.addCell(leftColCell)

        // CENTER COLUMN: QR Code
        val centerColCell = Cell().setPadding(5f).setBorder(Border.NO_BORDER).setBorderRight(thinBlackBorder)
            .setVerticalAlignment(VerticalAlignment.MIDDLE).setTextAlignment(TextAlignment.CENTER)
        qrCodeBitmap?.let { bitmap ->
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val image = Image(ImageDataFactory.create(stream.toByteArray()))
            image.setWidth(55f)
            image.setHorizontalAlignment(HorizontalAlignment.CENTER)
            centerColCell.add(image)
        }
        centerColCell.add(Paragraph("Scan QR to Pay").setFontSize(9f).setTextAlignment(TextAlignment.CENTER).setMarginTop(5f))
        footerTable.addCell(centerColCell)

        // RIGHT COLUMN: Signature
        val rightColCell = Cell().setPadding(5f).setBorder(Border.NO_BORDER)
        rightColCell.add(Paragraph("For SHAH STORES").setBold().setFontSize(9f).setTextAlignment(TextAlignment.RIGHT))
        
        signatureBitmap?.let { bitmap ->
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val image = Image(ImageDataFactory.create(stream.toByteArray()))
            image.setHeight(35f)
            image.setHorizontalAlignment(HorizontalAlignment.RIGHT)
            rightColCell.add(image)
        } ?: rightColCell.add(Paragraph("\n\n"))
        
        // Horizontal line for signature
        val sigLineCell = Cell().setBorder(Border.NO_BORDER).setBorderBottom(thinBlackBorder).setMarginBottom(2f).setMarginLeft(10f).setMarginRight(5f)
        rightColCell.add(sigLineCell)
        
        rightColCell.add(Paragraph("Authorised Signatory").setFontSize(9f).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(5f))
        footerTable.addCell(rightColCell)

        footerCell.add(footerTable)
        mainTable.addCell(footerCell)

        document.add(mainTable)
        document.close()
        file
    } catch (e: Exception) {
        Log.e("PdfGenerator", "Error generating PDF", e)
        null
    }
}

suspend fun generateCustomerStatementPdf(
    context: Context,
    customer: Customer,
    billEntries: List<BillEntry>,
    financialYear: String
): File? {
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val fileName = "Statement_${customer.name.replace(" ", "_")}_${financialYear.replace("/", "-")}_${timestamp}.pdf"
    val file = File(context.cacheDir, fileName)

    return try {
        val outputStream = FileOutputStream(file)
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A4)
        document.setMargins(0f, 0f, 20f, 0f)

        val primaryBlue = DeviceRgb(0, 45, 98)
        val secondaryBlue = DeviceRgb(59, 113, 202)
        val lightBlue = DeviceRgb(238, 244, 255)
        val yellowish = DeviceRgb(255, 249, 230)
        val yellowBorder = DeviceRgb(255, 224, 130)

        // Header
        val headerTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth()
        headerTable.setBackgroundColor(primaryBlue)
        headerTable.setPadding(20f)
        
        val leftHeader = Cell().setBorder(Border.NO_BORDER).setPadding(20f)
        leftHeader.add(Paragraph("Shah Stores").setFontSize(26f).setBold().setFontColor(ColorConstants.WHITE).setMargin(0f))
        leftHeader.add(Paragraph("Business Transaction Ledger").setFontSize(13f).setFontColor(ColorConstants.WHITE).setOpacity(0.8f).setMargin(0f))
        headerTable.addCell(leftHeader)

        val rightHeader = Cell().setBorder(Border.NO_BORDER).setPadding(20f).setTextAlignment(TextAlignment.RIGHT)
        val now = SimpleDateFormat("dd-MMM-yyyy 'at' hh:mm a", Locale.ENGLISH).format(Date())
        rightHeader.add(Paragraph("Generated: $now").setFontSize(11f).setFontColor(ColorConstants.WHITE).setMargin(0f))
        rightHeader.add(Paragraph("Report Type: Customer Statement").setFontSize(11f).setFontColor(ColorConstants.WHITE).setMargin(0f))
        rightHeader.add(Paragraph("FY: $financialYear").setFontSize(11f).setFontColor(ColorConstants.WHITE).setMargin(0f))
        headerTable.addCell(rightHeader)
        document.add(headerTable)

        // Customer Info Section
        val customerInfoTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth().setMarginTop(20f).setMarginLeft(30f).setMarginRight(30f)
        
        fun addInfoGroup(table: Table, label: String, value: String, subValues: List<String> = emptyList()) {
            val cell = Cell().setBorder(Border.NO_BORDER).setPaddingLeft(15f).setBorderLeft(SolidBorder(secondaryBlue, 3f))
            cell.add(Paragraph(label.uppercase()).setFontSize(10f).setFontColor(ColorConstants.GRAY).setBold().setMarginBottom(4f))
            cell.add(Paragraph(value).setFontSize(14f).setBold().setFontColor(DeviceRgb(26, 26, 26)).setMarginBottom(8f))
            subValues.forEach {
                cell.add(Paragraph(it).setFontSize(13f).setFontColor(DeviceRgb(68, 68, 68)).setMarginBottom(2f))
            }
            table.addCell(cell)
        }

        addInfoGroup(customerInfoTable, "Customer Name", customer.name, listOf("Billing Address", customer.address))
        addInfoGroup(customerInfoTable, "State / Place of Supply", "${customer.state} (State Code: ${customer.stateCode})", listOf("GSTIN / Registration Detail", customer.gstin ?: "URD"))
        document.add(customerInfoTable)

        // Summary Details Title
        document.add(Paragraph("Invoice Summary Details").setFontSize(18f).setBold().setFontColor(primaryBlue).setMarginTop(20f).setMarginLeft(30f).setMarginBottom(10f))

        // Determine if customer is local (Intrastate) or out-of-state (Interstate)
        // Madhya Pradesh is considered local for Shah Stores
        val isLocal = customer.state.equals("Madhya Pradesh", ignoreCase = true)
        val hasCgstSgst = isLocal
        val hasIgst = !isLocal

        // Table logic
        val columnWidths = mutableListOf(2f, 1.5f, 2f, 2f)
        val headersList = mutableListOf("Invoice No.", "View Bill", "Date", "Pre Tex Val (₹)")
        
        if (hasCgstSgst) {
            columnWidths.add(1.2f)
            columnWidths.add(1.2f)
            headersList.add("CGST (₹)")
            headersList.add("SGST (₹)")
        }
        
        if (hasIgst) {
            columnWidths.add(1.2f)
            headersList.add("IGST (₹)")
        }
        
        columnWidths.add(2f)
        headersList.add("Total (₹)")

        val dataTable = Table(UnitValue.createPercentArray(columnWidths.toFloatArray())).useAllAvailableWidth().setMarginLeft(30f).setMarginRight(30f)
        
        headersList.forEach {
            dataTable.addHeaderCell(Cell().add(Paragraph(it).setFontSize(10f).setBold().setFontColor(ColorConstants.WHITE)).setBackgroundColor(secondaryBlue).setPadding(8f).setBorder(Border.NO_BORDER))
        }

        var totalPreTax = 0.0
        var totalCgst = 0.0
        var totalSgst = 0.0
        var totalIgst = 0.0
        var totalAmount = 0.0

        billEntries.forEachIndexed { index, entry ->
            val rowColor = if (index % 2 == 0) ColorConstants.WHITE else DeviceRgb(249, 251, 255)
            
            var billPreTax = 0.0
            var billCgst = 0.0
            var billSgst = 0.0
            var billIgst = 0.0

            if (entry.items.isNotEmpty()) {
                entry.items.forEach { entryItem ->
                    val qty = entryItem.quantity.toDoubleOrNull() ?: 0.0
                    val rate = entryItem.rate.toDoubleOrNull() ?: 0.0
                    val itemTaxable = qty * rate
                    val rateVal = entryItem.item.gstRate.replace("%", "").toDoubleOrNull() ?: 0.0
                    
                    if (isLocal) {
                        billCgst += itemTaxable * (rateVal / 200.0)
                        billSgst += itemTaxable * (rateVal / 200.0)
                    } else {
                        billIgst += itemTaxable * (rateVal / 100.0)
                    }
                    billPreTax += itemTaxable
                }
            } else {
                billPreTax = entry.amount / 1.12
                if (isLocal) {
                    billCgst = (entry.amount - billPreTax) / 2.0
                    billSgst = billCgst
                } else {
                    billIgst = entry.amount - billPreTax
                }
            }
            
            val billTotal = billPreTax + billCgst + billSgst + billIgst
            
            totalPreTax += billPreTax
            totalCgst += billCgst
            totalSgst += billSgst
            totalIgst += billIgst
            totalAmount += billTotal

            val cellStyle = { cell: Cell -> cell.setBackgroundColor(rowColor).setPadding(8f).setBorder(Border.NO_BORDER).setBorderBottom(SolidBorder(DeviceRgb(238, 238, 238), 1f)) }

            dataTable.addCell(cellStyle(Cell().add(Paragraph(entry.billNo).setFontSize(10f))))
            
            val viewBillLink = Cell().setBackgroundColor(rowColor).setPadding(8f).setBorder(Border.NO_BORDER).setBorderBottom(SolidBorder(DeviceRgb(238, 238, 238), 1f))
            if (!entry.pdfUrl.isNullOrEmpty()) {
                val link = Link("View Bill", PdfAction.createURI(entry.pdfUrl))
                link.setFontSize(10f).setBold().setFontColor(secondaryBlue).setUnderline()
                viewBillLink.add(Paragraph().add(link))
            } else {
                viewBillLink.add(Paragraph("-").setFontSize(10f))
            }
            dataTable.addCell(viewBillLink)
            
            dataTable.addCell(cellStyle(Cell().add(Paragraph(entry.date).setFontSize(10f))))
            dataTable.addCell(cellStyle(Cell().add(Paragraph(String.format("%.2f", billPreTax)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
            
            if (hasCgstSgst) {
                dataTable.addCell(cellStyle(Cell().add(Paragraph(String.format("%.2f", billCgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
                dataTable.addCell(cellStyle(Cell().add(Paragraph(String.format("%.2f", billSgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
            }
            
            if (hasIgst) {
                dataTable.addCell(cellStyle(Cell().add(Paragraph(String.format("%.2f", billIgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
            }
            
            dataTable.addCell(cellStyle(Cell().add(Paragraph(String.format("%.2f", billTotal)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
        }

        // Total Summary Row
        val totalStyle = { cell: Cell -> cell.setBackgroundColor(lightBlue).setPadding(8f).setBorder(Border.NO_BORDER).setBold().setBorderTop(SolidBorder(secondaryBlue, 2f)) }
        dataTable.addCell(totalStyle(Cell(1, 3).add(Paragraph("Total Summary").setFontSize(10f))))
        dataTable.addCell(totalStyle(Cell().add(Paragraph(String.format("%.2f", totalPreTax)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
        
        if (hasCgstSgst) {
            dataTable.addCell(totalStyle(Cell().add(Paragraph(String.format("%.2f", totalCgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
            dataTable.addCell(totalStyle(Cell().add(Paragraph(String.format("%.2f", totalSgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
        }
        
        if (hasIgst) {
            dataTable.addCell(totalStyle(Cell().add(Paragraph(String.format("%.2f", totalIgst)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))
        }
        
        dataTable.addCell(totalStyle(Cell().add(Paragraph(String.format("%.2f", totalAmount)).setFontSize(10f)).setTextAlignment(TextAlignment.RIGHT)))

        document.add(dataTable)

        // Terms Box
        val declarationBox = Table(1).useAllAvailableWidth().setMarginTop(40f).setMarginLeft(30f).setMarginRight(30f)
        val declCell = Cell().setBackgroundColor(yellowish).setBorder(SolidBorder(yellowBorder, 1f)).setPadding(15f)
        val p = Paragraph().setFontSize(11f).setFontColor(DeviceRgb(102, 92, 63)).setMultipliedLeading(1.6f)
        p.add(Paragraph("Terms & Declaration: ").setBold().setItalic().setFontColor(DeviceRgb(133, 100, 4)))
        p.add("This is a computer-generated summary statement of bills issued during the specified period. Tax components detailed above are reported under applicable HSN codes to the GST Department. Please cross-verify this ledger statement with your GSTR-2B for input tax credit compliance.")
        declCell.add(p)
        declarationBox.addCell(declCell)
        
        // Page numbering
        val totalPages = pdf.numberOfPages
        for (i in 1..totalPages) {
            document.showTextAligned(Paragraph("Page $i of $totalPages").setFontSize(10f).setFontColor(ColorConstants.GRAY), 
                550f, 20f, i, TextAlignment.RIGHT, VerticalAlignment.BOTTOM, 0f)
        }

        document.close()
        file
    } catch (e: Exception) {
        Log.e("PdfGenerator", "Error generating customer statement PDF", e)
        null
    }
}

suspend fun generateLetterHeadPdf(
    context: Context,
    firmInfo: FirmInfo,
    logoBitmap: Bitmap? = null
): File? {
    val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ENGLISH).format(Date())
    val fileName = "LetterHead_${timestamp}.pdf"
    val file = File(context.cacheDir, fileName)

    return try {
        val outputStream = FileOutputStream(file)
        val writer = PdfWriter(outputStream)
        val pdf = PdfDocument(writer)
        val document = Document(pdf, PageSize.A5)
        
        // Ensure content doesn't overflow into the fixed signature and footer area at the bottom.
        // A5 height is 595.27pt. Footer is at 20pt. Signature block ends around 100pt from bottom.
        document.setMargins(15f, 25f, 110f, 25f)

        // Watermark Logo
        logoBitmap?.let { bitmap ->
            val stream = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream)
            val image = ImageDataFactory.create(stream.toByteArray())
            val pdfImage = Image(image)
            pdfImage.setFixedPosition((PageSize.A5.width - 200f) / 2, (PageSize.A5.height - 200f) / 2)
            pdfImage.setWidth(200f)
            pdfImage.setOpacity(0.07f)
            document.add(pdfImage)
        }

        // Top Metadata (Jurisdiction and Mobiles)
        val topMetaTable = Table(UnitValue.createPercentArray(floatArrayOf(1f, 1f))).useAllAvailableWidth()
        topMetaTable.addCell(Cell().add(Paragraph("Subject to Indore Jurisdiction").setFontSize(8f).setItalic()).setBorder(Border.NO_BORDER))
        val phones = listOfNotNull(firmInfo.phoneNo1.takeIf { it.isNotBlank() }, firmInfo.phoneNo2.takeIf { it.isNotBlank() }, firmInfo.phoneNo3.takeIf { it.isNotBlank() }).joinToString(", ")
        topMetaTable.addCell(Cell().add(Paragraph("Mob: $phones").setFontSize(8f).setItalic()).setTextAlignment(TextAlignment.RIGHT).setBorder(Border.NO_BORDER))
        document.add(topMetaTable)
        
        // Header line
        document.add(Table(1).useAllAvailableWidth().addCell(Cell().setBorder(Border.NO_BORDER).setBorderBottom(SolidBorder(ColorConstants.BLACK, 0.5f)).setHeight(2f)))

        // Branding
        val timesBold = PdfFontFactory.createFont(StandardFonts.TIMES_BOLD) 
        val brandingPara = Paragraph().setTextAlignment(TextAlignment.CENTER).setMarginTop(8f).setMarginBottom(0f)
        
        brandingPara.add(Text("\u5350 ").setBold().setFontSize(22f))
        brandingPara.add(Text(firmInfo.firmName).setFont(timesBold).setBold().setFontSize(34f).setCharacterSpacing(1.2f))
        brandingPara.add(Text(" \u5350").setBold().setFontSize(22f))
        document.add(brandingPara)
        
        if (firmInfo.tagLine.isNotBlank()) {
            document.add(Paragraph(firmInfo.tagLine).setFontSize(9f).setItalic().setTextAlignment(TextAlignment.CENTER).setMarginTop(0f))
        }

        // Horizontal Lines separation
        val lineTable = Table(1).useAllAvailableWidth().setMarginTop(8f)
        lineTable.addCell(Cell().setBorder(Border.NO_BORDER).setBorderBottom(SolidBorder(ColorConstants.BLACK, 1.2f)))
        lineTable.addCell(Cell().setBorder(Border.NO_BORDER).setBorderBottom(SolidBorder(ColorConstants.BLACK, 0.5f)).setHeight(1f))
        document.add(lineTable)

        // Date Line
        val datePara = Paragraph("Date: _______________").setFontSize(10f).setBold().setTextAlignment(TextAlignment.RIGHT).setMarginTop(12f)
        document.add(datePara)

        // Proprietor Signature Block - Fixed position just before footer
        // Positioned at y=65f (bottom-up coordinate) so it sits above the footer at y=20f
        val sigTable = Table(1).useAllAvailableWidth()
        sigTable.setFixedPosition(0f, 65f, PageSize.A5.width)
        val sigCell = Cell().setBorder(Border.NO_BORDER).setTextAlignment(TextAlignment.RIGHT).setPaddingRight(25f)
        
        // Horizontal line for signature
        val sigLineTable = Table(1).setWidth(120f).setHorizontalAlignment(HorizontalAlignment.RIGHT)
        sigLineTable.addCell(Cell().setBorder(Border.NO_BORDER).setBorderTop(SolidBorder(ColorConstants.BLACK, 1f)))
        sigCell.add(sigLineTable)

        sigCell.add(Paragraph("PROPRIETOR").setFontSize(10.5f).setBold().setMarginTop(2f).setMarginBottom(0f))
        
        val firmLine = Paragraph().setTextAlignment(TextAlignment.RIGHT).setMarginTop(0f)
        firmLine.add(Text(firmInfo.firmName).setBold().setFontSize(10.5f))
        firmLine.add(Text(", Indore").setFontSize(9.5f))
        sigCell.add(firmLine)
        
        sigTable.addCell(sigCell)
        document.add(sigTable)

        // Footer - Fixed position at bottom
        val footerTable = Table(1).useAllAvailableWidth().setFixedPosition(0f, 20f, PageSize.A5.width)
        footerTable.addCell(Cell().setBorder(Border.NO_BORDER).setBorderTop(SolidBorder(ColorConstants.BLACK, 1f)).setPaddingTop(5f).setTextAlignment(TextAlignment.CENTER).add(Paragraph(firmInfo.firmAddress).setFontSize(9f).setBold()))
        document.add(footerTable)

        document.close()
        file
    } catch (e: Exception) {
        Log.e("PdfGenerator", "Error generating Letter Head PDF", e)
        null
    }
}

private fun estimateLines(text: String, fontSize: Float, maxWidth: Float): Int {
    if (text.isEmpty()) return 1
    return try {
        val font = PdfFontFactory.createFont(StandardFonts.HELVETICA)
        var totalLines = 0
        text.split("\n").forEach { line ->
            val width = font.getWidth(line, fontSize)
            totalLines += ceil(width / maxWidth).toInt().coerceAtLeast(1)
        }
        totalLines.coerceAtLeast(1)
    } catch (e: Exception) {
        val avgCharWidth = fontSize * 0.5f
        var totalLines = 0
        text.split("\n").forEach { line ->
            totalLines += ceil(line.length * avgCharWidth / maxWidth).toInt().coerceAtLeast(1)
        }
        totalLines.coerceAtLeast(1)
    }
}

suspend fun uploadPdfToFirebase(file: File): String? {
    return try {
        val storageRef = Firebase.storage.reference
        val pdfRef = storageRef.child("invoices/${file.name}")
        val uploadTask = pdfRef.putFile(Uri.fromFile(file))
        val downloadUrl = uploadTask.continueWithTask { task ->
            if (!task.isSuccessful) {
                task.exception?.let {
                    throw it
                }
            }
            pdfRef.downloadUrl
        }.await()
        downloadUrl.toString()
    } catch (e: Exception) {
        Log.e("PdfGenerator", "Error uploading PDF", e)
        null
    }
}
