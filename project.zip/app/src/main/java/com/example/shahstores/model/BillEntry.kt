package com.example.shahstores.model

data class BillEntry(
    val id: String = "",
    val sn: Int = 0,
    val billNo: String = "",
    val date: String = "",
    val bundle: String = "",
    val customerName: String = "",
    val amount: Double = 0.0,
    val pdfUrl: String? = null,
    val customer: Customer? = null,
    val items: List<BillEntryItem> = emptyList()
)

data class BillEntryItem(
    val item: Item = Item(),
    val quantity: String = "",
    val rate: String = "",
    val amount: Double = 0.0,
    val variantSelections: Map<String, String> = emptyMap()
)
