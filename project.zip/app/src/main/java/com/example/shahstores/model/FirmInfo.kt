package com.example.shahstores.model

import com.google.firebase.firestore.DocumentId

data class FirmInfo(
    @DocumentId val id: String = "",
    val firmName: String = "",
    val firmAddress: String = "",
    val firmGstin: String = "",
    val phoneNo1: String = "",
    val phoneNo2: String = "",
    val phoneNo3: String = "",
    val firmLogoUrl: String = "",
    val bankName: String = "",
    val bankAccNo: String = "",
    val bankIfsc: String = "",
    val signatureUrl: String = "",
    val qrCodeUrl: String = "",
    val tagLine: String = ""
)
