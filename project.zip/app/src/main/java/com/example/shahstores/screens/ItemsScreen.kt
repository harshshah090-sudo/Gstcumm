package com.example.shahstores.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.shahstores.model.Item
import com.example.shahstores.ui.theme.AlternateRowShading
import com.example.shahstores.ui.theme.DefaultTextColor
import com.example.shahstores.ui.theme.TableHeaderBg

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ItemsScreen(
    items: List<Item>,
    onItemClick: (Int) -> Unit,
    selectionMode: Boolean,
    selectedItems: Set<Int>,
    onItemLongClick: (Int) -> Unit,
    onItemSelected: (Int) -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        itemsIndexed(items) { index, item ->
            val isSelected = selectedItems.contains(index)
            val rowBg = when {
                isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                index % 2 == 1 -> AlternateRowShading
                else -> Color.Transparent
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(rowBg)
                    .combinedClickable(
                        onClick = {
                            if (selectionMode) onItemSelected(index) else onItemClick(index)
                        },
                        onLongClick = { onItemLongClick(index) }
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "${index + 1}", modifier = Modifier.weight(0.1f), color = DefaultTextColor)
                    Text(text = item.name, modifier = Modifier.weight(0.3f), color = DefaultTextColor)
                    Text(text = item.uom, modifier = Modifier.weight(0.2f), color = DefaultTextColor)
                    Text(text = item.hsnCode, modifier = Modifier.weight(0.2f), color = DefaultTextColor)
                    Text(text = item.gstRate, modifier = Modifier.weight(0.2f), color = DefaultTextColor)
                    if (selectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onItemSelected(index) }
                        )
                    }
                }
                Divider(color = TableHeaderBg)
            }
        }
    }
}

