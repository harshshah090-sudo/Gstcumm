package com.example.shahstores.util

object IndianStates {
    val states = mapOf(
        "Andhra Pradesh" to "37",
        "Arunachal Pradesh" to "12",
        "Assam" to "18",
        "Bihar" to "10",
        "Chhattisgarh" to "22",
        "Goa" to "30",
        "Gujarat" to "24",
        "Haryana" to "06",
        "Himachal Pradesh" to "02",
        "Jharkhand" to "20",
        "Karnataka" to "29",
        "Kerala" to "32",
        "Madhya Pradesh" to "23",
        "Maharashtra" to "27",
        "Manipur" to "14",
        "Meghalaya" to "17",
        "Mizoram" to "15",
        "Nagaland" to "13",
        "Odisha" to "21",
        "Punjab" to "03",
        "Rajasthan" to "08",
        "Sikkim" to "11",
        "Tamil Nadu" to "33",
        "Telangana" to "36",
        "Tripura" to "16",
        "Uttar Pradesh" to "09",
        "Uttarakhand" to "05",
        "West Bengal" to "19",
        "Andaman and Nicobar Islands" to "35",
        "Chandigarh" to "04",
        "Dadra and Nagar Haveli and Daman and Diu" to "26",
        "Lakshadweep" to "31",
        "Delhi" to "07",
        "Puducherry" to "34",
        "Ladakh" to "38",
        "Jammu and Kashmir" to "01"
    )

    val stateList = states.keys.toList().sorted()
}
