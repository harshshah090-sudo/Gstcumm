package com.example.shahstores.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DeepTeal80,
    onPrimary = Color(0xFF003833),
    primaryContainer = DeepTealDark,
    onPrimaryContainer = DeepTealContainer,
    secondary = Saffron80,
    onSecondary = Color(0xFF451E00),
    secondaryContainer = Color(0xFF6B3300),
    onSecondaryContainer = SaffronContainer,
    background = DarkBackground,
    onBackground = Color(0xFFE2E8F0),
    surface = DarkSurface,
    onSurface = Color(0xFFE2E8F0),
    surfaceVariant = Color(0xFF1E3A37),
    onSurfaceVariant = Color(0xFF99F6E4)
)

private val LightColorScheme = lightColorScheme(
    primary = DeepTeal,
    onPrimary = Color.White,
    primaryContainer = DeepTealContainer,
    onPrimaryContainer = OnDeepTealContainer,
    secondary = Saffron,
    onSecondary = Color.White,
    secondaryContainer = SaffronContainer,
    onSecondaryContainer = OnSaffronContainer,
    tertiary = SaffronDark,
    onTertiary = Color.White,
    background = AppBackground,
    onBackground = Color(0xFF0F172A),
    surface = AppSurface,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = AppSurfaceVariant,
    onSurfaceVariant = Color(0xFF334155),
    outline = AppOutline
)

@Composable
fun ShahStoresTheme(
    darkTheme: Boolean = false,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
