package com.example.shahstores.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = ChocolatePrimary,
    onPrimary = Color.White,
    secondary = GoldAccent,
    onSecondary = ChocolatePrimaryDark,
    tertiary = GoldAccent,
    onTertiary = ChocolatePrimaryDark,
    background = ScreenBackground,
    onBackground = DefaultTextColor,
    surface = CardBackground,
    onSurface = DefaultTextColor,
    surfaceVariant = TableHeaderBg,
    onSurfaceVariant = DefaultTextColor,
    outline = OutlineColor,
    outlineVariant = TableHeaderBg,
)

private val LightColorScheme = lightColorScheme(
    primary = ChocolatePrimary,
    onPrimary = Color.White,
    secondary = GoldAccent,
    onSecondary = ChocolatePrimaryDark,
    tertiary = GoldAccent,
    onTertiary = ChocolatePrimaryDark,
    background = ScreenBackground,
    onBackground = DefaultTextColor,
    surface = CardBackground,
    onSurface = DefaultTextColor,
    surfaceVariant = TableHeaderBg,
    onSurfaceVariant = DefaultTextColor,
    outline = OutlineColor,
    outlineVariant = TableHeaderBg,
)

@Composable
fun ShahStoresTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

