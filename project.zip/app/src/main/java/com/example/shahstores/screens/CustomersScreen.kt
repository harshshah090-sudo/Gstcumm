package com.example.shahstores.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.shahstores.model.Customer

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CustomersScreen(
    customers: List<Customer>,
    onCustomerClick: (Int) -> Unit,
    selectionMode: Boolean,
    selectedCustomers: Set<Int>,
    onCustomerLongClick: (Int) -> Unit,
    onCustomerSelected: (Int) -> Unit
) {
    val scrollState = rememberScrollState()

    LazyColumn(modifier = Modifier.fillMaxSize()) {
        itemsIndexed(customers) { index, customer ->
            val isSelected = selectedCustomers.contains(index)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent)
                    .combinedClickable(
                        onClick = {
                            if (selectionMode) onCustomerSelected(index) else onCustomerClick(index)
                        },
                        onLongClick = { onCustomerLongClick(index) }
                    )
            ) {
                Row(
                    modifier = Modifier
                        .padding(8.dp)
                        .horizontalScroll(scrollState),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${index + 1}",
                        modifier = Modifier.width(40.dp),
                        maxLines = 1
                    )
                    Text(
                        text = customer.name,
                        modifier = Modifier.width(120.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.address,
                        modifier = Modifier.width(150.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.gstin ?: "",
                        modifier = Modifier.width(120.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.state,
                        modifier = Modifier.width(120.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.phoneNumber ?: "",
                        modifier = Modifier.width(120.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = customer.transport ?: "",
                        modifier = Modifier.width(120.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (selectionMode) {
                        Checkbox(
                            checked = isSelected,
                            onCheckedChange = { onCustomerSelected(index) }
                        )
                    }
                }
                Divider()
            }
        }
    }
}
