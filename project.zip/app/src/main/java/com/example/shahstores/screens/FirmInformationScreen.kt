package com.example.shahstores.screens

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.shahstores.model.FirmInfo
import com.example.shahstores.ui.theme.*
import com.example.shahstores.viewmodel.FirmInfoUiState
import com.example.shahstores.viewmodel.FirmInfoViewModel
import com.yalantis.ucrop.UCrop
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirmInformationScreen(
    onDismiss: () -> Unit,
    viewModel: FirmInfoViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    when (val state = uiState) {
        is FirmInfoUiState.Loading -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ScreenBackground),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    CircularProgressIndicator(color = ChocolatePrimary)
                    Text(
                        text = "Loading Firm Details...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = ChocolatePrimaryDark
                    )
                }
            }
        }
        is FirmInfoUiState.Success -> {
            val isEditing = viewModel.isEditing

            var firmName by remember { mutableStateOf(state.firmInfo.firmName) }
            var firmAddress by remember { mutableStateOf(state.firmInfo.firmAddress) }
            var firmGstin by remember { mutableStateOf(state.firmInfo.firmGstin) }
            var phoneNo1 by remember { mutableStateOf(state.firmInfo.phoneNo1) }
            var phoneNo2 by remember { mutableStateOf(state.firmInfo.phoneNo2) }
            var phoneNo3 by remember { mutableStateOf(state.firmInfo.phoneNo3) }
            var tagLine by remember { mutableStateOf(state.firmInfo.tagLine) }
            var firmLogoUri by remember { mutableStateOf<Uri?>(null) }
            var bankName by remember { mutableStateOf(state.firmInfo.bankName) }
            var bankAccNo by remember { mutableStateOf(state.firmInfo.bankAccNo) }
            var bankIfsc by remember { mutableStateOf(state.firmInfo.bankIfsc) }
            var qrCodeUri by remember { mutableStateOf<Uri?>(null) }
            var signatureUri by remember { mutableStateOf<Uri?>(null) }
            var isSaving by remember { mutableStateOf(false) }

            LaunchedEffect(state.firmInfo, isEditing) {
                if (isEditing) {
                    firmName = state.firmInfo.firmName
                    firmAddress = state.firmInfo.firmAddress
                    firmGstin = state.firmInfo.firmGstin
                    phoneNo1 = state.firmInfo.phoneNo1
                    phoneNo2 = state.firmInfo.phoneNo2
                    phoneNo3 = state.firmInfo.phoneNo3
                    tagLine = state.firmInfo.tagLine
                    bankName = state.firmInfo.bankName
                    bankAccNo = state.firmInfo.bankAccNo
                    bankIfsc = state.firmInfo.bankIfsc
                    firmLogoUri = null
                    qrCodeUri = null
                    signatureUri = null
                    isSaving = false
                }
            }

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = if (isEditing) "Edit Firm Profile" else "Firm Information",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 19.sp
                                )
                                Text(
                                    text = if (isEditing) "Update company details & branding" else "Official Business Profile",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = Color.White
                                )
                            }
                        },
                        actions = {
                            if (!isEditing) {
                                IconButton(onClick = { viewModel.enterEditMode() }) {
                                    Icon(
                                        imageVector = Icons.Default.Edit,
                                        contentDescription = "Edit Profile",
                                        tint = Color.White
                                    )
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = ChocolatePrimary,
                            titleContentColor = Color.White,
                            navigationIconContentColor = Color.White
                        )
                    )
                },
                bottomBar = {
                    if (isEditing) {
                        Surface(
                            shadowElevation = 12.dp,
                            color = CardBackground,
                            border = BorderStroke(1.dp, TableHeaderBg)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .navigationBarsPadding()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(
                                    onClick = { viewModel.exitEditMode() },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, OutlineColor),
                                    enabled = !isSaving
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Cancel", color = ChocolatePrimary, fontWeight = FontWeight.SemiBold)
                                }

                                Button(
                                    onClick = {
                                        if (firmName.isBlank()) {
                                            Toast.makeText(context, "Please enter Firm Name", Toast.LENGTH_SHORT).show()
                                            return@Button
                                        }
                                        isSaving = true
                                        val updatedInfo = state.firmInfo.copy(
                                            firmName = firmName.trim(),
                                            firmAddress = firmAddress.trim(),
                                            firmGstin = firmGstin.trim().uppercase(),
                                            phoneNo1 = phoneNo1.trim(),
                                            phoneNo2 = phoneNo2.trim(),
                                            phoneNo3 = phoneNo3.trim(),
                                            tagLine = tagLine.trim(),
                                            bankName = bankName.trim(),
                                            bankAccNo = bankAccNo.trim(),
                                            bankIfsc = bankIfsc.trim().uppercase()
                                        )
                                        viewModel.saveFirmInfo(updatedInfo, firmLogoUri, signatureUri, qrCodeUri) {
                                            isSaving = false
                                            Toast.makeText(context, "Firm Information Saved Successfully!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1.2f),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = ChocolatePrimary,
                                        contentColor = Color.White
                                    ),
                                    enabled = !isSaving
                                ) {
                                    if (isSaving) {
                                        CircularProgressIndicator(
                                            color = Color.White,
                                            modifier = Modifier.size(18.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Saving...")
                                    } else {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Save Changes", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(ScreenBackground)
                        .padding(innerPadding)
                ) {
                    if (isEditing) {
                        FirmInfoEditView(
                            firmName = firmName, onFirmNameChange = { firmName = it },
                            firmAddress = firmAddress, onFirmAddressChange = { firmAddress = it },
                            firmGstin = firmGstin, onFirmGstinChange = { firmGstin = it },
                            phoneNo1 = phoneNo1, onPhoneNo1Change = { phoneNo1 = it },
                            phoneNo2 = phoneNo2, onPhoneNo2Change = { phoneNo2 = it },
                            phoneNo3 = phoneNo3, onPhoneNo3Change = { phoneNo3 = it },
                            tagLine = tagLine, onTagLineChange = { tagLine = it },
                            firmLogoUri = firmLogoUri, onFirmLogoUriChange = { firmLogoUri = it },
                            existingLogoUrl = state.firmInfo.firmLogoUrl,
                            bankName = bankName, onBankNameChange = { bankName = it },
                            bankAccNo = bankAccNo, onBankAccNoChange = { bankAccNo = it },
                            bankIfsc = bankIfsc, onBankIfscChange = { bankIfsc = it },
                            qrCodeUri = qrCodeUri, onQrCodeUriChange = { qrCodeUri = it },
                            existingQrCodeUrl = state.firmInfo.qrCodeUrl,
                            signatureUri = signatureUri, onSignatureUriChange = { signatureUri = it },
                            existingSignatureUrl = state.firmInfo.signatureUrl
                        )
                    } else {
                        FirmInfoDisplayView(firmInfo = state.firmInfo)
                    }
                }
            }
        }
        is FirmInfoUiState.Error -> {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(ScreenBackground),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    modifier = Modifier
                        .padding(24.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBackground)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "Error loading firm information.",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.error
                        )
                        Button(
                            onClick = { viewModel.loadFirmInfo() },
                            colors = ButtonDefaults.buttonColors(containerColor = ChocolatePrimary)
                        ) {
                            Text("Retry")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FirmInfoDisplayView(firmInfo: FirmInfo) {
    val clipboardManager = LocalClipboardManager.current
    val context = LocalContext.current
    var zoomedImageModel by remember { mutableStateOf<Any?>(null) }
    var zoomedTitle by remember { mutableStateOf("") }

    val copyWithToast = { label: String, text: String ->
        clipboardManager.setText(AnnotatedString(text))
        Toast.makeText(context, "$label copied to clipboard", Toast.LENGTH_SHORT).show()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Brand Profile Card
        item {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = CardBackground),
                elevation = CardDefaults.elevatedCardElevation(defaultElevation = 3.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    TableHeaderBg.copy(alpha = 0.6f),
                                    CardBackground
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Firm Logo Avatar
                        val logoModel = getCoilImageModel(firmInfo.firmLogoUrl)
                        Surface(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(RoundedCornerShape(18.dp)),
                            color = TableHeaderBg,
                            shadowElevation = 4.dp
                        ) {
                            if (logoModel != null) {
                                Image(
                                    painter = rememberAsyncImagePainter(model = logoModel),
                                    contentDescription = "Firm Logo",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            } else {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Storefront,
                                        contentDescription = null,
                                        tint = ChocolatePrimary,
                                        modifier = Modifier.size(46.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Firm Name
                        Text(
                            text = firmInfo.firmName.ifBlank { "Firm Name Not Set" },
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.ExtraBold,
                            color = ChocolatePrimary,
                            textAlign = TextAlign.Center
                        )

                        // Tagline
                        if (firmInfo.tagLine.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“${firmInfo.tagLine}”",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Medium,
                                color = GoldAccent,
                                textAlign = TextAlign.Center
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // GSTIN Badge Pill with Copy
                        if (firmInfo.firmGstin.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(24.dp),
                                color = ChocolatePrimary.copy(alpha = 0.08f),
                                border = BorderStroke(1.dp, ChocolatePrimary.copy(alpha = 0.25f)),
                                modifier = Modifier.clickable {
                                    copyWithToast("GSTIN", firmInfo.firmGstin)
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = null,
                                        tint = TotalSalesGreen,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "GSTIN: ${firmInfo.firmGstin}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = ChocolatePrimaryDark,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy GSTIN",
                                        tint = ChocolatePrimary.copy(alpha = 0.7f),
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 1: Business Details & Address
        item {
            AestheticSectionCard(
                title = "Business & Location",
                icon = Icons.Default.Storefront
            ) {
                InfoDisplayRow(
                    label = "Firm Legal Name",
                    value = firmInfo.firmName.ifBlank { "Not Specified" },
                    icon = Icons.Default.Business
                )
                HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                InfoDisplayRow(
                    label = "Registered Address",
                    value = firmInfo.firmAddress.ifBlank { "Not Specified" },
                    icon = Icons.Default.Place,
                    onCopy = if (firmInfo.firmAddress.isNotBlank()) {
                        { copyWithToast("Address", firmInfo.firmAddress) }
                    } else null
                )
                if (firmInfo.tagLine.isNotBlank()) {
                    HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                    InfoDisplayRow(
                        label = "Business Tagline",
                        value = firmInfo.tagLine,
                        icon = Icons.Default.FormatQuote
                    )
                }
            }
        }

        // Section 2: Contact Numbers
        item {
            AestheticSectionCard(
                title = "Contact Numbers",
                icon = Icons.Default.Phone
            ) {
                InfoDisplayRow(
                    label = "Primary Phone",
                    value = firmInfo.phoneNo1.ifBlank { "Not Specified" },
                    icon = Icons.Default.Phone,
                    onCopy = if (firmInfo.phoneNo1.isNotBlank()) {
                        { copyWithToast("Primary Phone", firmInfo.phoneNo1) }
                    } else null
                )
                if (firmInfo.phoneNo2.isNotBlank()) {
                    HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                    InfoDisplayRow(
                        label = "Secondary Phone",
                        value = firmInfo.phoneNo2,
                        icon = Icons.Default.PhoneAndroid,
                        onCopy = { copyWithToast("Secondary Phone", firmInfo.phoneNo2) }
                    )
                }
                if (firmInfo.phoneNo3.isNotBlank()) {
                    HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                    InfoDisplayRow(
                        label = "Landline / Alternative",
                        value = firmInfo.phoneNo3,
                        icon = Icons.Default.PhoneInTalk,
                        onCopy = { copyWithToast("Phone", firmInfo.phoneNo3) }
                    )
                }
            }
        }

        // Section 3: Banking & Settlement
        item {
            AestheticSectionCard(
                title = "Bank Account Details",
                icon = Icons.Default.AccountBalance
            ) {
                InfoDisplayRow(
                    label = "Bank Name",
                    value = firmInfo.bankName.ifBlank { "Not Specified" },
                    icon = Icons.Default.AccountBalance
                )
                HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                InfoDisplayRow(
                    label = "Account Number",
                    value = firmInfo.bankAccNo.ifBlank { "Not Specified" },
                    icon = Icons.Default.CreditCard,
                    isMonospace = true,
                    onCopy = if (firmInfo.bankAccNo.isNotBlank()) {
                        { copyWithToast("Account Number", firmInfo.bankAccNo) }
                    } else null
                )
                HorizontalDivider(color = TableHeaderBg, thickness = 0.7.dp)
                InfoDisplayRow(
                    label = "IFSC Code",
                    value = firmInfo.bankIfsc.ifBlank { "Not Specified" },
                    icon = Icons.Default.Pin,
                    isMonospace = true,
                    onCopy = if (firmInfo.bankIfsc.isNotBlank()) {
                        { copyWithToast("IFSC Code", firmInfo.bankIfsc) }
                    } else null
                )
            }
        }

        // Section 4: Branding Assets & Signatures
        item {
            AestheticSectionCard(
                title = "Official Digital Assets",
                icon = Icons.Default.Verified
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Logo Asset Tile
                    AssetPreviewTile(
                        title = "Firm Logo",
                        model = getCoilImageModel(firmInfo.firmLogoUrl),
                        placeholderIcon = Icons.Default.Image,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val model = getCoilImageModel(firmInfo.firmLogoUrl)
                            if (model != null) {
                                zoomedImageModel = model
                                zoomedTitle = "Firm Logo"
                            }
                        }
                    )

                    // QR Code Asset Tile
                    AssetPreviewTile(
                        title = "Payment QR",
                        model = getCoilImageModel(firmInfo.qrCodeUrl),
                        placeholderIcon = Icons.Default.QrCode,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val model = getCoilImageModel(firmInfo.qrCodeUrl)
                            if (model != null) {
                                zoomedImageModel = model
                                zoomedTitle = "Payment QR Code"
                            }
                        }
                    )

                    // Signature Asset Tile
                    AssetPreviewTile(
                        title = "Signature",
                        model = getCoilImageModel(firmInfo.signatureUrl),
                        placeholderIcon = Icons.Default.Draw,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            val model = getCoilImageModel(firmInfo.signatureUrl)
                            if (model != null) {
                                zoomedImageModel = model
                                zoomedTitle = "Authorised Signature"
                            }
                        }
                    )
                }
            }
        }
    }

    // Zoom Dialog for QR / Images
    if (zoomedImageModel != null) {
        Dialog(onDismissRequest = { zoomedImageModel = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBackground)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = zoomedTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = ChocolatePrimary
                        )
                        IconButton(onClick = { zoomedImageModel = null }) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .border(1.dp, TableHeaderBg, RoundedCornerShape(12.dp))
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = rememberAsyncImagePainter(model = zoomedImageModel),
                            contentDescription = zoomedTitle,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Used in Invoices, Letterheads & Statements",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun AestheticSectionCard(
    title: String,
    icon: ImageVector,
    content: @Composable ColumnScope.() -> Unit
) {
    ElevatedCard(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = CardBackground),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(ChocolatePrimary.copy(alpha = 0.08f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = ChocolatePrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ChocolatePrimaryDark
                )
            }

            content()
        }
    }
}

@Composable
private fun InfoDisplayRow(
    label: String,
    value: String,
    icon: ImageVector,
    isMonospace: Boolean = false,
    onCopy: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(TableHeaderBg.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ChocolatePrimary.copy(alpha = 0.8f),
                modifier = Modifier.size(16.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = value,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                color = DefaultTextColor,
                fontFamily = if (isMonospace) FontFamily.Monospace else FontFamily.Default,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }

        if (onCopy != null) {
            IconButton(
                onClick = onCopy,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = "Copy $label",
                    tint = GoldAccent,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun AssetPreviewTile(
    title: String,
    model: Any?,
    placeholderIcon: ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = model != null, onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        color = TableHeaderBg.copy(alpha = 0.4f),
        border = BorderStroke(1.dp, TableHeaderBg)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White)
                    .border(1.dp, TableHeaderBg, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (model != null) {
                    Image(
                        painter = rememberAsyncImagePainter(model = model),
                        contentDescription = title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(4.dp)
                    )
                } else {
                    Icon(
                        imageVector = placeholderIcon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = ChocolatePrimaryDark,
                textAlign = TextAlign.Center
            )

            Text(
                text = if (model != null) "Uploaded" else "Not set",
                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                color = if (model != null) TotalSalesGreen else MaterialTheme.colorScheme.outline,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun FirmInfoEditView(
    firmName: String, onFirmNameChange: (String) -> Unit,
    firmAddress: String, onFirmAddressChange: (String) -> Unit,
    firmGstin: String, onFirmGstinChange: (String) -> Unit,
    phoneNo1: String, onPhoneNo1Change: (String) -> Unit,
    phoneNo2: String, onPhoneNo2Change: (String) -> Unit,
    phoneNo3: String, onPhoneNo3Change: (String) -> Unit,
    tagLine: String, onTagLineChange: (String) -> Unit,
    firmLogoUri: Uri?, onFirmLogoUriChange: (Uri?) -> Unit,
    existingLogoUrl: String,
    bankName: String, onBankNameChange: (String) -> Unit,
    bankAccNo: String, onBankAccNoChange: (String) -> Unit,
    bankIfsc: String, onBankIfscChange: (String) -> Unit,
    qrCodeUri: Uri?, onQrCodeUriChange: (Uri?) -> Unit,
    existingQrCodeUrl: String,
    signatureUri: Uri?, onSignatureUriChange: (Uri?) -> Unit,
    existingSignatureUrl: String
) {
    val context = LocalContext.current

    val cropLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val resultUri = result.data?.let { UCrop.getOutput(it) }
                onQrCodeUriChange(resultUri)
            } else if (result.resultCode == UCrop.RESULT_ERROR) {
                val cropError = result.data?.let { UCrop.getError(it) }
                Toast.makeText(context, "Crop Error: ${cropError?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    )

    val qrPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let { sourceUri ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(sourceUri)?.use {
                    BitmapFactory.decodeStream(it, null, options)
                }

                if (options.outWidth != options.outHeight && options.outWidth > 0) {
                    val destinationUri = Uri.fromFile(File(context.cacheDir, "cropped_qr_${UUID.randomUUID()}.png"))
                    val uCrop = UCrop.of(sourceUri, destinationUri)
                        .withAspectRatio(1f, 1f)
                        .withMaxResultSize(1000, 1000)

                    cropLauncher.launch(uCrop.getIntent(context))
                } else {
                    onQrCodeUriChange(sourceUri)
                }
            }
        }
    )

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onFirmLogoUriChange(uri) }
    )

    val signaturePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onSignatureUriChange(uri) }
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Business Identity
        item {
            AestheticSectionCard(
                title = "Business Identity",
                icon = Icons.Default.Business
            ) {
                OutlinedTextField(
                    value = firmName,
                    onValueChange = onFirmNameChange,
                    label = { Text("Firm Legal Name *") },
                    placeholder = { Text("e.g. Shah Stores") },
                    leadingIcon = { Icon(Icons.Default.Storefront, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = tagLine,
                    onValueChange = onTagLineChange,
                    label = { Text("Business Tagline") },
                    placeholder = { Text("e.g. Textiles & Novelties Merchant") },
                    leadingIcon = { Icon(Icons.Default.FormatQuote, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = firmGstin,
                    onValueChange = { onFirmGstinChange(it.uppercase()) },
                    label = { Text("Firm GSTIN Number") },
                    placeholder = { Text("e.g. 23AALFS7386D1Z5") },
                    leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = firmAddress,
                    onValueChange = onFirmAddressChange,
                    label = { Text("Firm Registered Address") },
                    placeholder = { Text("e.g. Sarafa Bazar, Depalpur, Dist. Indore (M.P.) - 453115") },
                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    minLines = 2,
                    maxLines = 4
                )
            }
        }

        // Section: Contact Numbers
        item {
            AestheticSectionCard(
                title = "Contact Numbers",
                icon = Icons.Default.Phone
            ) {
                OutlinedTextField(
                    value = phoneNo1,
                    onValueChange = onPhoneNo1Change,
                    label = { Text("Primary Phone Number *") },
                    placeholder = { Text("e.g. 94250 82823") },
                    leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = phoneNo2,
                    onValueChange = onPhoneNo2Change,
                    label = { Text("Secondary Phone (Optional)") },
                    placeholder = { Text("e.g. 98260 12345") },
                    leadingIcon = { Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = phoneNo3,
                    onValueChange = onPhoneNo3Change,
                    label = { Text("Landline / Alternative (Optional)") },
                    placeholder = { Text("e.g. 0731 285000") },
                    leadingIcon = { Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
            }
        }

        // Section: Banking & Settlement
        item {
            AestheticSectionCard(
                title = "Bank Account (Printed on Invoices)",
                icon = Icons.Default.AccountBalance
            ) {
                OutlinedTextField(
                    value = bankName,
                    onValueChange = onBankNameChange,
                    label = { Text("Firm's Bank Name") },
                    placeholder = { Text("e.g. State Bank of India") },
                    leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bankAccNo,
                    onValueChange = onBankAccNoChange,
                    label = { Text("Bank Account Number") },
                    placeholder = { Text("e.g. 30123456789") },
                    leadingIcon = { Icon(Icons.Default.CreditCard, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = bankIfsc,
                    onValueChange = { onBankIfscChange(it.uppercase()) },
                    label = { Text("Bank IFSC Code") },
                    placeholder = { Text("e.g. SBIN0001234") },
                    leadingIcon = { Icon(Icons.Default.Pin, contentDescription = null, tint = ChocolatePrimary) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                    singleLine = true
                )
            }
        }

        // Section: Branding & Uploads
        item {
            AestheticSectionCard(
                title = "Branding Assets & Signatures",
                icon = Icons.Default.Image
            ) {
                Text(
                    text = "Upload high quality PNG/JPEG images. These are embedded directly into Tax Invoices, Statements, and Letterheads.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                // 1. Logo Upload Tile
                val logoToShow: Any? = firmLogoUri ?: getCoilImageModel(existingLogoUrl)
                AssetUploadCard(
                    title = "Firm Logo",
                    description = "Displayed on top header of bills & letterheads",
                    model = logoToShow,
                    placeholderIcon = Icons.Default.AddPhotoAlternate,
                    onPickClick = { logoPickerLauncher.launch("image/*") },
                    onClearClick = if (firmLogoUri != null) { { onFirmLogoUriChange(null) } } else null
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 2. QR Code Upload Tile
                val qrToShow: Any? = qrCodeUri ?: getCoilImageModel(existingQrCodeUrl)
                AssetUploadCard(
                    title = "UPI Payment QR Code",
                    description = "1:1 Square cropped image for customer scan & pay",
                    model = qrToShow,
                    placeholderIcon = Icons.Default.QrCode,
                    onPickClick = { qrPickerLauncher.launch("image/*") },
                    onClearClick = if (qrCodeUri != null) { { onQrCodeUriChange(null) } } else null
                )

                Spacer(modifier = Modifier.height(12.dp))

                // 3. Signature Upload Tile
                val sigToShow: Any? = signatureUri ?: getCoilImageModel(existingSignatureUrl)
                AssetUploadCard(
                    title = "Authorised Signatory",
                    description = "Owner's signature printed on invoice footer",
                    model = sigToShow,
                    placeholderIcon = Icons.Default.Draw,
                    onPickClick = { signaturePickerLauncher.launch("image/*") },
                    onClearClick = if (signatureUri != null) { { onSignatureUriChange(null) } } else null
                )
            }
        }
    }
}

@Composable
private fun AssetUploadCard(
    title: String,
    description: String,
    model: Any?,
    placeholderIcon: ImageVector,
    onPickClick: () -> Unit,
    onClearClick: (() -> Unit)? = null
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = TableHeaderBg.copy(alpha = 0.35f),
        border = BorderStroke(1.dp, TableHeaderBg)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Preview Thumbnail
            Box(
                modifier = Modifier
                    .size(62.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White)
                    .border(1.dp, TableHeaderBg, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (model != null) {
                    Image(
                        painter = rememberAsyncImagePainter(model = model),
                        contentDescription = title,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(4.dp)
                    )
                } else {
                    Icon(
                        imageVector = placeholderIcon,
                        contentDescription = null,
                        tint = ChocolatePrimary.copy(alpha = 0.5f),
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Details & Actions
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = ChocolatePrimaryDark
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton(
                        onClick = onPickClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = ChocolatePrimary.copy(alpha = 0.12f),
                            contentColor = ChocolatePrimary
                        ),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Icon(
                            imageVector = if (model != null) Icons.Default.Cached else Icons.Default.CloudUpload,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (model != null) "Change" else "Upload",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (onClearClick != null) {
                        OutlinedButton(
                            onClick = onClearClick,
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Reset", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

fun getCoilImageModel(source: String?): Any? {
    if (source.isNullOrBlank()) return null
    return if (source.startsWith("http://") || source.startsWith("https://") || source.startsWith("content://") || source.startsWith("file://")) {
        source
    } else {
        try {
            val base64Data = if (source.contains(",")) source.substringAfter(",") else source
            android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT)
        } catch (_: Exception) {
            source
        }
    }
}
