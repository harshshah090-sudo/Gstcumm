package com.example.shahstores.screens

import android.app.Activity
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.shahstores.model.FirmInfo
import com.example.shahstores.viewmodel.FirmInfoUiState
import com.example.shahstores.viewmodel.FirmInfoViewModel
import com.yalantis.ucrop.UCrop
import java.io.File
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirmInformationScreen(onDismiss: () -> Unit, viewModel: FirmInfoViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()

    when (val state = uiState) {
        is FirmInfoUiState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is FirmInfoUiState.Success -> {
            val isEditing = viewModel.isEditing

            var firmName by remember { mutableStateOf(state.firmInfo.firmName) }
            var firmAddress by remember { mutableStateOf(state.firmInfo.firmAddress) }
            var firmGstin by remember { mutableStateOf(state.firmInfo.firmGstin) }
            var phoneNo1 by remember { mutableStateOf(state.firmInfo.phoneNo1) }
            var phoneNo2 by remember { mutableStateOf(state.firmInfo.phoneNo2) }
            var phoneNo3 by remember { mutableStateOf(state.firmInfo.phoneNo3) }
            var tagLine by remember { mutableStateOf(state.firmInfo.tagLine) }
            var firmLogoUri by remember { mutableStateOf<Uri?>(null) }
            var bankName by remember { mutableStateOf(state.firmInfo.bankName) }
            var bankAccNo by remember { mutableStateOf(state.firmInfo.bankAccNo) }
            var bankIfsc by remember { mutableStateOf(state.firmInfo.bankIfsc) }
            var qrCodeUri by remember { mutableStateOf<Uri?>(null) }
            var signatureUri by remember { mutableStateOf<Uri?>(null) }

            LaunchedEffect(state.firmInfo, isEditing) {
                if (isEditing) {
                    firmName = state.firmInfo.firmName
                    firmAddress = state.firmInfo.firmAddress
                    firmGstin = state.firmInfo.firmGstin
                    phoneNo1 = state.firmInfo.phoneNo1
                    phoneNo2 = state.firmInfo.phoneNo2
                    phoneNo3 = state.firmInfo.phoneNo3
                    tagLine = state.firmInfo.tagLine
                    bankName = state.firmInfo.bankName
                    bankAccNo = state.firmInfo.bankAccNo
                    bankIfsc = state.firmInfo.bankIfsc
                    firmLogoUri = null
                    qrCodeUri = null
                    signatureUri = null
                }
            }

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("Firm Information") },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        },
                        actions = {
                            if (!isEditing) {
                                IconButton(onClick = { viewModel.enterEditMode() }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = MaterialTheme.colorScheme.onPrimary,
                            navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                            actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                },
                bottomBar = {
                    if (isEditing) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(onClick = { viewModel.exitEditMode() }) {
                                Text("Cancel")
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Button(
                                onClick = {
                                    val updatedInfo = state.firmInfo.copy(
                                        firmName = firmName,
                                        firmAddress = firmAddress,
                                        firmGstin = firmGstin,
                                        phoneNo1 = phoneNo1,
                                        phoneNo2 = phoneNo2,
                                        phoneNo3 = phoneNo3,
                                        tagLine = tagLine,
                                        bankName = bankName,
                                        bankAccNo = bankAccNo,
                                        bankIfsc = bankIfsc
                                    )
                                    viewModel.saveFirmInfo(updatedInfo, firmLogoUri, signatureUri, qrCodeUri, onDismiss)
                                }
                            ) {
                                Text("Save")
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(modifier = Modifier.padding(innerPadding)) {
                    if (isEditing) {
                        FirmInfoEditView(
                            firmName = firmName, onFirmNameChange = { firmName = it },
                            firmAddress = firmAddress, onFirmAddressChange = { firmAddress = it },
                            firmGstin = firmGstin, onFirmGstinChange = { firmGstin = it },
                            phoneNo1 = phoneNo1, onPhoneNo1Change = { phoneNo1 = it },
                            phoneNo2 = phoneNo2, onPhoneNo2Change = { phoneNo2 = it },
                            phoneNo3 = phoneNo3, onPhoneNo3Change = { phoneNo3 = it },
                            tagLine = tagLine, onTagLineChange = { tagLine = it },
                            firmLogoUri = firmLogoUri, onFirmLogoUriChange = { firmLogoUri = it },
                            existingLogoUrl = state.firmInfo.firmLogoUrl,
                            bankName = bankName, onBankNameChange = { bankName = it },
                            bankAccNo = bankAccNo, onBankAccNoChange = { bankAccNo = it },
                            bankIfsc = bankIfsc, onBankIfscChange = { bankIfsc = it },
                            qrCodeUri = qrCodeUri, onQrCodeUriChange = { qrCodeUri = it },
                            existingQrCodeUrl = state.firmInfo.qrCodeUrl,
                            signatureUri = signatureUri, onSignatureUriChange = { signatureUri = it },
                            existingSignatureUrl = state.firmInfo.signatureUrl
                        )
                    } else {
                        FirmInfoDisplayView(firmInfo = state.firmInfo)
                    }
                }
            }
        }
        is FirmInfoUiState.Error -> {
            Text("Error loading firm information.")
        }
    }
}

@Composable
private fun FirmInfoDisplayView(firmInfo: FirmInfo) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (firmInfo.firmName.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.firmName,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.headlineSmall.copy(
                        fontSize = MaterialTheme.typography.headlineSmall.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.firmAddress.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.firmAddress,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.firmGstin.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.firmGstin,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.phoneNo1.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = "Phone 1: ${firmInfo.phoneNo1}",
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.phoneNo2.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = "Phone 2: ${firmInfo.phoneNo2}",
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.phoneNo3.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = "Phone 3: ${firmInfo.phoneNo3}",
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.tagLine.isNotBlank()) {
            item {
                Text(
                    text = "Tag Line: ${firmInfo.tagLine}",
                    style = MaterialTheme.typography.bodyLarge
                )
            }
        }
        if (firmInfo.firmLogoUrl.isNotBlank()) {
            item {
                Image(
                    painter = rememberAsyncImagePainter(model = firmInfo.firmLogoUrl),
                    contentDescription = "Firm Logo",
                    modifier = Modifier.size(100.dp)
                )
            }
        }
        if (firmInfo.bankName.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.bankName,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.bankAccNo.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.bankAccNo,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.bankIfsc.isNotBlank()) {
            item {
                var multiplier by remember { mutableStateOf(1f) }
                Text(
                    text = firmInfo.bankIfsc,
                    maxLines = 1,
                    softWrap = false,
                    style = MaterialTheme.typography.bodyLarge.copy(
                        fontSize = MaterialTheme.typography.bodyLarge.fontSize * multiplier
                    ),
                    onTextLayout = {
                        if (it.didOverflowWidth) {
                            multiplier *= 0.9f
                        }
                    }
                )
            }
        }
        if (firmInfo.qrCodeUrl.isNotBlank()) {
            item {
                Image(
                    painter = rememberAsyncImagePainter(model = firmInfo.qrCodeUrl),
                    contentDescription = "QR Code",
                    modifier = Modifier.size(100.dp)
                )
            }
        }
        if (firmInfo.signatureUrl.isNotBlank()) {
            item {
                Image(
                    painter = rememberAsyncImagePainter(model = firmInfo.signatureUrl),
                    contentDescription = "Owner's Signature",
                    modifier = Modifier.size(100.dp)
                )
            }
        }
    }
}

@Composable
private fun FirmInfoEditView(
    firmName: String, onFirmNameChange: (String) -> Unit,
    firmAddress: String, onFirmAddressChange: (String) -> Unit,
    firmGstin: String, onFirmGstinChange: (String) -> Unit,
    phoneNo1: String, onPhoneNo1Change: (String) -> Unit,
    phoneNo2: String, onPhoneNo2Change: (String) -> Unit,
    phoneNo3: String, onPhoneNo3Change: (String) -> Unit,
    tagLine: String, onTagLineChange: (String) -> Unit,
    firmLogoUri: Uri?, onFirmLogoUriChange: (Uri?) -> Unit,
    existingLogoUrl: String,
    bankName: String, onBankNameChange: (String) -> Unit,
    bankAccNo: String, onBankAccNoChange: (String) -> Unit,
    bankIfsc: String, onBankIfscChange: (String) -> Unit,
    qrCodeUri: Uri?, onQrCodeUriChange: (Uri?) -> Unit,
    existingQrCodeUrl: String,
    signatureUri: Uri?, onSignatureUriChange: (Uri?) -> Unit,
    existingSignatureUrl: String
) {
    val context = LocalContext.current
    
    val cropLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val resultUri = result.data?.let { UCrop.getOutput(it) }
                onQrCodeUriChange(resultUri)
            } else if (result.resultCode == UCrop.RESULT_ERROR) {
                val cropError = result.data?.let { UCrop.getError(it) }
                Toast.makeText(context, "Crop Error: ${cropError?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    )

    val qrPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let { sourceUri ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(sourceUri)?.use { 
                    BitmapFactory.decodeStream(it, null, options) 
                }
                
                if (options.outWidth != options.outHeight && options.outWidth > 0) {
                    val destinationUri = Uri.fromFile(File(context.cacheDir, "cropped_qr_${UUID.randomUUID()}.png"))
                    val uCrop = UCrop.of(sourceUri, destinationUri)
                        .withAspectRatio(1f, 1f)
                        .withMaxResultSize(1000, 1000)
                    
                    cropLauncher.launch(uCrop.getIntent(context))
                } else {
                    onQrCodeUriChange(sourceUri)
                }
            }
        }
    )

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onFirmLogoUriChange(uri) }
    )

    val signaturePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onSignatureUriChange(uri) }
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { OutlinedTextField(value = firmName, onValueChange = onFirmNameChange, label = { Text("Firm Name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)) }
        item { OutlinedTextField(value = firmAddress, onValueChange = onFirmAddressChange, label = { Text("Firm Address") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)) }
        item { OutlinedTextField(value = firmGstin, onValueChange = { onFirmGstinChange(it.uppercase()) }, label = { Text("Firm GSTIN") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters)) }
        item { OutlinedTextField(value = phoneNo1, onValueChange = onPhoneNo1Change, label = { Text("Phone No.") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
        item { OutlinedTextField(value = phoneNo2, onValueChange = onPhoneNo2Change, label = { Text("Phone No. 2") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
        item { OutlinedTextField(value = phoneNo3, onValueChange = onPhoneNo3Change, label = { Text("Phone No. 3") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)) }
        item { OutlinedTextField(value = tagLine, onValueChange = onTagLineChange, label = { Text("Tag Line") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { logoPickerLauncher.launch("image/png") }) { Text("Upload Firm's Logo") }
                Spacer(modifier = Modifier.width(16.dp))
                val logoToShow = firmLogoUri ?: if (existingLogoUrl.isNotBlank()) Uri.parse(existingLogoUrl) else null
                if (logoToShow != null) {
                    Image(painter = rememberAsyncImagePainter(model = logoToShow), contentDescription = "Firm Logo", modifier = Modifier.size(50.dp))
                }
            }
        }
        item { OutlinedTextField(value = bankName, onValueChange = onBankNameChange, label = { Text("Firm's Bank Name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)) }
        item { OutlinedTextField(value = bankAccNo, onValueChange = onBankAccNoChange, label = { Text("Firm's Bank Acc No.") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(value = bankIfsc, onValueChange = { onBankIfscChange(it.uppercase()) }, label = { Text("Firm's Bank IFS Code") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters)) }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { qrPickerLauncher.launch("image/*") }) { Text("Upload QR Code") }
                Spacer(modifier = Modifier.width(16.dp))
                val qrToShow = qrCodeUri ?: if (existingQrCodeUrl.isNotBlank()) Uri.parse(existingQrCodeUrl) else null
                if (qrToShow != null) {
                    Image(painter = rememberAsyncImagePainter(model = qrToShow), contentDescription = "QR Code", modifier = Modifier.size(50.dp))
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Button(onClick = { signaturePickerLauncher.launch("image/png") }) { Text("Upload Owner's Signature") }
                Spacer(modifier = Modifier.width(16.dp))
                val signatureToShow = signatureUri ?: if (existingSignatureUrl.isNotBlank()) Uri.parse(existingSignatureUrl) else null
                if (signatureToShow != null) {
                    Image(painter = rememberAsyncImagePainter(model = signatureToShow), contentDescription = "Owner's Signature", modifier = Modifier.size(50.dp))
                }
            }
        }
    }
}
