package com.example.shahstores.screens

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.rememberAsyncImagePainter
import com.example.shahstores.model.FirmInfo
import com.example.shahstores.viewmodel.FirmInfoUiState
import com.example.shahstores.viewmodel.FirmInfoViewModel
import com.yalantis.ucrop.UCrop
import java.io.File
import java.util.UUID

/**
 * Safely decodes base64-encoded data URLs (data:image/png;base64,...) or raw base64 strings into an Android Bitmap.
 */
fun decodeBase64ToBitmap(dataStr: String): Bitmap? {
    return try {
        val base64Data = if (dataStr.contains(";base64,")) {
            dataStr.substringAfter(";base64,")
        } else if (dataStr.startsWith("data:")) {
            dataStr.substringAfter(",")
        } else {
            dataStr
        }
        val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
    } catch (e: Exception) {
        null
    }
}

/**
 * Universal image preview composable that handles base64 data URLs, local content URIs,
 * and remote HTTP URLs gracefully with appropriate placeholders.
 */
@Composable
fun FirmImage(
    imageSource: Any?,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit,
    placeholderIcon: ImageVector = Icons.Default.Image
) {
    val context = LocalContext.current
    val bitmap = remember(imageSource) {
        when (imageSource) {
            is String -> {
                if (imageSource.startsWith("data:image/") || imageSource.contains(";base64,") || imageSource.length > 200) {
                    decodeBase64ToBitmap(imageSource)
                } else null
            }
            is Uri -> {
                try {
                    context.contentResolver.openInputStream(imageSource)?.use {
                        BitmapFactory.decodeStream(it)
                    }
                } catch (e: Exception) {
                    null
                }
            }
            is Bitmap -> imageSource
            else -> null
        }
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap.asImageBitmap(),
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        } else if (imageSource is String && (imageSource.startsWith("http://") || imageSource.startsWith("https://"))) {
            Image(
                painter = rememberAsyncImagePainter(model = imageSource),
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        } else if (imageSource is Uri) {
            Image(
                painter = rememberAsyncImagePainter(model = imageSource),
                contentDescription = contentDescription,
                modifier = Modifier.fillMaxSize(),
                contentScale = contentScale
            )
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = placeholderIcon,
                    contentDescription = contentDescription,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "No image",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FirmInformationScreen(onDismiss: () -> Unit, viewModel: FirmInfoViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsState()

    when (val state = uiState) {
        is FirmInfoUiState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is FirmInfoUiState.Success -> {
            val isEditing = viewModel.isEditing

            var firmName by remember { mutableStateOf(state.firmInfo.firmName) }
            var firmAddress by remember { mutableStateOf(state.firmInfo.firmAddress) }
            var firmGstin by remember { mutableStateOf(state.firmInfo.firmGstin) }
            var phoneNo1 by remember { mutableStateOf(state.firmInfo.phoneNo1) }
            var phoneNo2 by remember { mutableStateOf(state.firmInfo.phoneNo2) }
            var phoneNo3 by remember { mutableStateOf(state.firmInfo.phoneNo3) }
            var tagLine by remember { mutableStateOf(state.firmInfo.tagLine) }
            var firmLogoUri by remember { mutableStateOf<Uri?>(null) }
            var bankName by remember { mutableStateOf(state.firmInfo.bankName) }
            var bankAccNo by remember { mutableStateOf(state.firmInfo.bankAccNo) }
            var bankIfsc by remember { mutableStateOf(state.firmInfo.bankIfsc) }
            var qrCodeUri by remember { mutableStateOf<Uri?>(null) }
            var signatureUri by remember { mutableStateOf<Uri?>(null) }

            LaunchedEffect(state.firmInfo, isEditing) {
                if (isEditing) {
                    firmName = state.firmInfo.firmName
                    firmAddress = state.firmInfo.firmAddress
                    firmGstin = state.firmInfo.firmGstin
                    phoneNo1 = state.firmInfo.phoneNo1
                    phoneNo2 = state.firmInfo.phoneNo2
                    phoneNo3 = state.firmInfo.phoneNo3
                    tagLine = state.firmInfo.tagLine
                    bankName = state.firmInfo.bankName
                    bankAccNo = state.firmInfo.bankAccNo
                    bankIfsc = state.firmInfo.bankIfsc
                    firmLogoUri = null
                    qrCodeUri = null
                    signatureUri = null
                }
            }

            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Text(
                                text = if (isEditing) "Edit Firm Information" else "Firm Information",
                                fontWeight = FontWeight.Bold
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = onDismiss) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        },
                        actions = {
                            if (!isEditing) {
                                FilledTonalButton(
                                    onClick = { viewModel.enterEditMode() },
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f),
                                        contentColor = MaterialTheme.colorScheme.onPrimary
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Edit",
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Edit")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            titleContentColor = MaterialTheme.colorScheme.onPrimary,
                            navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                            actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                },
                bottomBar = {
                    if (isEditing) {
                        Surface(
                            shadowElevation = 8.dp,
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedButton(onClick = { viewModel.exitEditMode() }) {
                                    Text("Cancel")
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                val isSaving = viewModel.isSaving
                                val context = LocalContext.current
                                Button(
                                    enabled = !isSaving,
                                    onClick = {
                                        val updatedInfo = state.firmInfo.copy(
                                            firmName = firmName,
                                            firmAddress = firmAddress,
                                            firmGstin = firmGstin,
                                            phoneNo1 = phoneNo1,
                                            phoneNo2 = phoneNo2,
                                            phoneNo3 = phoneNo3,
                                            tagLine = tagLine,
                                            bankName = bankName,
                                            bankAccNo = bankAccNo,
                                            bankIfsc = bankIfsc
                                        )
                                        viewModel.saveFirmInfo(
                                            context = context,
                                            firmInfo = updatedInfo,
                                            logoUri = firmLogoUri,
                                            signatureUri = signatureUri,
                                            qrCodeUri = qrCodeUri,
                                            onSuccess = {
                                                Toast.makeText(context, "Firm details saved successfully!", Toast.LENGTH_SHORT).show()
                                                onDismiss()
                                            },
                                            onError = { errorMsg ->
                                                Toast.makeText(context, "Saved: $errorMsg", Toast.LENGTH_LONG).show()
                                                onDismiss()
                                            }
                                        )
                                    }
                                ) {
                                    if (isSaving) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            color = MaterialTheme.colorScheme.onPrimary,
                                            strokeWidth = 2.dp
                                        )
                                    } else {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Save Changes")
                                    }
                                }
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(MaterialTheme.colorScheme.background)
                ) {
                    if (isEditing) {
                        FirmInfoEditView(
                            firmName = firmName, onFirmNameChange = { firmName = it },
                            firmAddress = firmAddress, onFirmAddressChange = { firmAddress = it },
                            firmGstin = firmGstin, onFirmGstinChange = { firmGstin = it },
                            phoneNo1 = phoneNo1, onPhoneNo1Change = { phoneNo1 = it },
                            phoneNo2 = phoneNo2, onPhoneNo2Change = { phoneNo2 = it },
                            phoneNo3 = phoneNo3, onPhoneNo3Change = { phoneNo3 = it },
                            tagLine = tagLine, onTagLineChange = { tagLine = it },
                            firmLogoUri = firmLogoUri, onFirmLogoUriChange = { firmLogoUri = it },
                            existingLogoUrl = state.firmInfo.firmLogoUrl,
                            bankName = bankName, onBankNameChange = { bankName = it },
                            bankAccNo = bankAccNo, onBankAccNoChange = { bankAccNo = it },
                            bankIfsc = bankIfsc, onBankIfscChange = { bankIfsc = it },
                            qrCodeUri = qrCodeUri, onQrCodeUriChange = { qrCodeUri = it },
                            existingQrCodeUrl = state.firmInfo.qrCodeUrl,
                            signatureUri = signatureUri, onSignatureUriChange = { signatureUri = it },
                            existingSignatureUrl = state.firmInfo.signatureUrl
                        )
                    } else {
                        FirmInfoDisplayView(firmInfo = state.firmInfo)
                    }
                }
            }
        }
        is FirmInfoUiState.Error -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Error loading firm information.")
            }
        }
    }
}

@Composable
private fun FirmInfoDisplayView(firmInfo: FirmInfo) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. HERO BRANDED HEADER CARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primary
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Firm Logo Badge
                    Surface(
                        shape = CircleShape,
                        color = Color.White,
                        shadowElevation = 4.dp,
                        border = BorderStroke(2.dp, MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.size(76.dp)
                    ) {
                        FirmImage(
                            imageSource = firmInfo.firmLogoUrl.ifBlank { null },
                            contentDescription = "Firm Logo",
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(6.dp),
                            contentScale = ContentScale.Fit,
                            placeholderIcon = Icons.Default.Business
                        )
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = firmInfo.firmName.ifBlank { "Firm Name Not Set" },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimary,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        if (firmInfo.tagLine.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "“${firmInfo.tagLine}”",
                                style = MaterialTheme.typography.bodyMedium,
                                fontStyle = FontStyle.Italic,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f),
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Registration Scheme Pill
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = firmInfo.gstRegistrationType.ifBlank { "Regular GST" },
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. BUSINESS & CONTACT DETAILS CARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Business & Contact",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    // GSTIN
                    InfoRow(
                        label = "GSTIN",
                        value = firmInfo.firmGstin.ifBlank { "Not Provided" },
                        isHighlighted = firmInfo.firmGstin.isNotBlank()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Address
                    InfoRow(
                        label = "Address",
                        value = firmInfo.firmAddress.ifBlank { "Not Provided" }
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Phone Numbers
                    val phones = listOfNotNull(
                        firmInfo.phoneNo1.takeIf { it.isNotBlank() },
                        firmInfo.phoneNo2.takeIf { it.isNotBlank() },
                        firmInfo.phoneNo3.takeIf { it.isNotBlank() }
                    )

                    InfoRow(
                        label = "Phone Contacts",
                        value = if (phones.isNotEmpty()) phones.joinToString("  •  ") else "Not Provided"
                    )
                }
            }
        }

        // 3. BANK & PAYMENT DETAILS CARD
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalance,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Banking Details",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(14.dp))

                    InfoRow(label = "Bank Name", value = firmInfo.bankName.ifBlank { "Not Provided" })
                    Spacer(modifier = Modifier.height(12.dp))
                    InfoRow(label = "Account Number", value = firmInfo.bankAccNo.ifBlank { "Not Provided" }, isMonospace = true)
                    Spacer(modifier = Modifier.height(12.dp))
                    InfoRow(label = "IFSC Code", value = firmInfo.bankIfsc.ifBlank { "Not Provided" }, isMonospace = true)
                }
            }
        }

        // 4. DEDICATED VISUAL ASSETS CARD (LOGO, QR CODE, SIGNATURE)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhotoLibrary,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Firm Media & Verification Assets",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Displayed on generated bills, letters, and statements",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(16.dp))

                    // 3 Media Preview Blocks in an organized layout
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // 1. Logo
                        MediaItemBox(
                            title = "Firm Logo",
                            imageSource = firmInfo.firmLogoUrl.ifBlank { null },
                            placeholderIcon = Icons.Default.Business,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // 2. QR Code
                        MediaItemBox(
                            title = "Payment QR",
                            imageSource = firmInfo.qrCodeUrl.ifBlank { null },
                            placeholderIcon = Icons.Default.QrCode2,
                            modifier = Modifier.weight(1f)
                        )

                        Spacer(modifier = Modifier.width(12.dp))

                        // 3. Signature
                        MediaItemBox(
                            title = "Signature",
                            imageSource = firmInfo.signatureUrl.ifBlank { null },
                            placeholderIcon = Icons.Default.Draw,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoRow(
    label: String,
    value: String,
    isHighlighted: Boolean = false,
    isMonospace: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodyLarge,
            fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Normal,
            color = if (isHighlighted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            fontFamily = if (isMonospace) androidx.compose.ui.text.font.FontFamily.Monospace else androidx.compose.ui.text.font.FontFamily.Default
        )
    }
}

@Composable
private fun MediaItemBox(
    title: String,
    imageSource: Any?,
    placeholderIcon: ImageVector,
    modifier: Modifier = Modifier
) {
    val isAvailable = when (imageSource) {
        is String -> imageSource.isNotBlank()
        is Uri -> true
        is Bitmap -> true
        else -> false
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            modifier = Modifier
                .size(96.dp)
                .clip(RoundedCornerShape(12.dp)),
            shape = RoundedCornerShape(12.dp),
            color = if (isAvailable) Color.White else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
            border = BorderStroke(
                1.dp,
                if (isAvailable) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                else MaterialTheme.colorScheme.outlineVariant
            ),
            shadowElevation = if (isAvailable) 2.dp else 0.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                FirmImage(
                    imageSource = imageSource,
                    contentDescription = title,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit,
                    placeholderIcon = placeholderIcon
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center
        )

        Text(
            text = if (isAvailable) "Uploaded" else "Not set",
            style = MaterialTheme.typography.labelSmall,
            color = if (isAvailable) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun FirmInfoEditView(
    firmName: String, onFirmNameChange: (String) -> Unit,
    firmAddress: String, onFirmAddressChange: (String) -> Unit,
    firmGstin: String, onFirmGstinChange: (String) -> Unit,
    phoneNo1: String, onPhoneNo1Change: (String) -> Unit,
    phoneNo2: String, onPhoneNo2Change: (String) -> Unit,
    phoneNo3: String, onPhoneNo3Change: (String) -> Unit,
    tagLine: String, onTagLineChange: (String) -> Unit,
    firmLogoUri: Uri?, onFirmLogoUriChange: (Uri?) -> Unit,
    existingLogoUrl: String,
    bankName: String, onBankNameChange: (String) -> Unit,
    bankAccNo: String, onBankAccNoChange: (String) -> Unit,
    bankIfsc: String, onBankIfscChange: (String) -> Unit,
    qrCodeUri: Uri?, onQrCodeUriChange: (Uri?) -> Unit,
    existingQrCodeUrl: String,
    signatureUri: Uri?, onSignatureUriChange: (Uri?) -> Unit,
    existingSignatureUrl: String
) {
    val context = LocalContext.current

    val cropLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult(),
        onResult = { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val resultUri = result.data?.let { UCrop.getOutput(it) }
                onQrCodeUriChange(resultUri)
            } else if (result.resultCode == UCrop.RESULT_ERROR) {
                val cropError = result.data?.let { UCrop.getError(it) }
                Toast.makeText(context, "Crop Error: ${cropError?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    )

    val qrPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? ->
            uri?.let { sourceUri ->
                val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(sourceUri)?.use { 
                    BitmapFactory.decodeStream(it, null, options) 
                }
                
                if (options.outWidth != options.outHeight && options.outWidth > 0) {
                    val destinationUri = Uri.fromFile(File(context.cacheDir, "cropped_qr_${UUID.randomUUID()}.png"))
                    val uCrop = UCrop.of(sourceUri, destinationUri)
                        .withAspectRatio(1f, 1f)
                        .withMaxResultSize(1000, 1000)
                    
                    cropLauncher.launch(uCrop.getIntent(context))
                } else {
                    onQrCodeUriChange(sourceUri)
                }
            }
        }
    )

    val logoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onFirmLogoUriChange(uri) }
    )

    val signaturePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent(),
        onResult = { uri: Uri? -> onSignatureUriChange(uri) }
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Basic Info
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("General Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(value = firmName, onValueChange = onFirmNameChange, label = { Text("Firm Name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words), singleLine = true)
                    OutlinedTextField(value = tagLine, onValueChange = onTagLineChange, label = { Text("Tag Line") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words), singleLine = true)
                    OutlinedTextField(value = firmGstin, onValueChange = { onFirmGstinChange(it.uppercase()) }, label = { Text("Firm GSTIN") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters), singleLine = true)
                    OutlinedTextField(value = firmAddress, onValueChange = onFirmAddressChange, label = { Text("Firm Address") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words))
                }
            }
        }

        // Section: Contact Info
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Contact Numbers", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(value = phoneNo1, onValueChange = onPhoneNo1Change, label = { Text("Phone No. 1") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(value = phoneNo2, onValueChange = onPhoneNo2Change, label = { Text("Phone No. 2 (Optional)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                    OutlinedTextField(value = phoneNo3, onValueChange = onPhoneNo3Change, label = { Text("Phone No. 3 (Optional)") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                }
            }
        }

        // Section: Bank Details
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Banking Information", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    OutlinedTextField(value = bankName, onValueChange = onBankNameChange, label = { Text("Firm's Bank Name") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words), singleLine = true)
                    OutlinedTextField(value = bankAccNo, onValueChange = onBankAccNoChange, label = { Text("Firm's Bank Acc No.") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = bankIfsc, onValueChange = { onBankIfscChange(it.uppercase()) }, label = { Text("Firm's Bank IFSC Code") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters), singleLine = true)
                }
            }
        }

        // Section: Visual Assets Upload
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Media & Visual Assets", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

                    // Upload Logo Row
                    val logoSource = firmLogoUri ?: existingLogoUrl.ifBlank { null }
                    EditUploadRow(
                        label = "Firm's Logo",
                        buttonLabel = if (logoSource != null) "Change Logo" else "Upload Logo",
                        imageSource = logoSource,
                        placeholderIcon = Icons.Default.Business,
                        onUploadClick = { logoPickerLauncher.launch("image/*") }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Upload QR Code Row
                    val qrSource = qrCodeUri ?: existingQrCodeUrl.ifBlank { null }
                    EditUploadRow(
                        label = "Payment QR Code",
                        buttonLabel = if (qrSource != null) "Change QR" else "Upload QR",
                        imageSource = qrSource,
                        placeholderIcon = Icons.Default.QrCode2,
                        onUploadClick = { qrPickerLauncher.launch("image/*") }
                    )

                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

                    // Upload Signature Row
                    val signatureSource = signatureUri ?: existingSignatureUrl.ifBlank { null }
                    EditUploadRow(
                        label = "Owner's Signature",
                        buttonLabel = if (signatureSource != null) "Change Signature" else "Upload Signature",
                        imageSource = signatureSource,
                        placeholderIcon = Icons.Default.Draw,
                        onUploadClick = { signaturePickerLauncher.launch("image/*") }
                    )
                }
            }
        }
    }
}

@Composable
private fun EditUploadRow(
    label: String,
    buttonLabel: String,
    imageSource: Any?,
    placeholderIcon: ImageVector,
    onUploadClick: () -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            OutlinedButton(
                onClick = onUploadClick,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(buttonLabel, fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.width(16.dp))

        Surface(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(8.dp)),
            shape = RoundedCornerShape(8.dp),
            color = Color.White,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                FirmImage(
                    imageSource = imageSource,
                    contentDescription = label,
                    modifier = Modifier.fillMaxSize(),
                    placeholderIcon = placeholderIcon
                )
            }
        }
    }
}
