package com.example.shahstores.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.shahstores.model.Customer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareBillDetailsPopup(
    customers: List<Customer>,
    financialYears: List<String>,
    currentFY: String,
    onDismiss: () -> Unit,
    onGenerate: (Customer, String) -> Unit
) {
    var selectedFY by remember { mutableStateOf(currentFY) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var showFYDropdown by remember { mutableStateOf(false) }

    val filteredCustomers = remember(searchQuery, customers) {
        if (searchQuery.isBlank()) customers
        else customers.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = MaterialTheme.shapes.extraLarge
        ) {
            Column(
                modifier = Modifier
                    .padding(24.dp)
                    .fillMaxWidth()
            ) {
                Text(
                    text = "Share Bill Details",
                    style = MaterialTheme.typography.headlineSmall,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Financial Year Selection
                ExposedDropdownMenuBox(
                    expanded = showFYDropdown,
                    onExpandedChange = { showFYDropdown = !showFYDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedFY,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Financial Year") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showFYDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = showFYDropdown,
                        onDismissRequest = { showFYDropdown = false }
                    ) {
                        financialYears.forEach { fy ->
                            DropdownMenuItem(
                                text = { Text(fy) },
                                onClick = {
                                    selectedFY = fy
                                    showFYDropdown = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Customer Search & Selection
                OutlinedTextField(
                    value = if (selectedCustomer != null && searchQuery.isEmpty()) selectedCustomer!!.name else searchQuery,
                    onValueChange = { 
                        searchQuery = it
                        selectedCustomer = null 
                    },
                    label = { Text("Search Customer") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine = true
                )

                if (selectedCustomer == null && searchQuery.isNotEmpty()) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 200.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                    ) {
                        LazyColumn {
                            items(filteredCustomers) { customer ->
                                ListItem(
                                    headlineContent = { 
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = customer.name,
                                                modifier = Modifier.weight(1f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                style = MaterialTheme.typography.bodyLarge
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = customer.address,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                textAlign = TextAlign.End,
                                                modifier = Modifier.weight(0.6f)
                                            )
                                        }
                                    },
                                    modifier = Modifier.clickable {
                                        selectedCustomer = customer
                                        searchQuery = ""
                                    }
                                )
                                HorizontalDivider(
                                    modifier = Modifier.padding(horizontal = 16.dp),
                                    thickness = 0.5.dp,
                                    color = MaterialTheme.colorScheme.outlineVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) {
                        Text("Cancel")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            selectedCustomer?.let { onGenerate(it, selectedFY) }
                        },
                        enabled = selectedCustomer != null
                    ) {
                        Text("Generate & Share")
                    }
                }
            }
        }
    }
}
