package com.example.shahstores.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.shahstores.model.BillEntry
import com.example.shahstores.model.Customer
import com.example.shahstores.ui.theme.*
import com.example.shahstores.util.buildWebBillUrl
import com.example.shahstores.util.formatIndianCurrency
import com.example.shahstores.util.getBillSession
import com.example.shahstores.util.getFinancialYear
import com.example.shahstores.util.tryParseDate
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareBillDetailsPopup(
    customers: List<Customer>,
    financialYears: List<String>,
    currentFY: String,
    allBillEntries: List<BillEntry>,
    onDismiss: () -> Unit,
    onPreview: (Customer, String, List<BillEntry>) -> Unit,
    onShare: (Customer, String, List<BillEntry>) -> Unit,
    onViewBill: (BillEntry) -> Unit = {}
) {
    var selectedFY by remember { 
        mutableStateOf(currentFY.ifBlank { financialYears.lastOrNull() ?: "24-25" }) 
    }
    var searchQuery by remember { mutableStateOf("") }
    var selectedCustomer by remember { mutableStateOf<Customer?>(null) }
    var showFYDropdown by remember { mutableStateOf(false) }
    val context = LocalContext.current

    fun getBillsForCustomer(cust: Customer?, fy: String): List<BillEntry> {
        if (cust == null) return emptyList()
        val targetName = cust.name.trim()
        return allBillEntries.filter { entry ->
            val nameMatch = entry.customerName.trim().equals(targetName, ignoreCase = true) ||
                    (entry.customer?.name?.trim()?.equals(targetName, ignoreCase = true) == true)
            if (!nameMatch) return@filter false
            val parsedDate = tryParseDate(entry.date)
            val entryFy = if (parsedDate != null) getFinancialYear(parsedDate) else getBillSession(entry.billNo)
            entryFy == fy
        }.sortedWith(compareBy({ tryParseDate(it.date)?.time ?: 0L }, { entry ->
            entry.billNo.split("/").lastOrNull()?.toIntOrNull() ?: 0
        }))
    }

    val filteredCustomers = remember(searchQuery, customers) {
        val q = searchQuery.trim()
        val list = if (q.isBlank()) {
            customers
        } else {
            customers.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.address.contains(q, ignoreCase = true) ||
                (it.gstin?.contains(q, ignoreCase = true) == true)
            }
        }
        list.sortedBy { it.name.lowercase() }
    }

    val customerBills = remember(selectedCustomer, selectedFY, allBillEntries.size) {
        getBillsForCustomer(selectedCustomer, selectedFY)
    }

    val totalAmount = remember(customerBills) {
        customerBills.sumOf { it.amount }
    }

    val customTextFieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChocolatePrimary,
        unfocusedBorderColor = TableHeaderBg,
        cursorColor = ChocolatePrimary,
        focusedLabelColor = ChocolatePrimary,
        focusedContainerColor = CardBackground,
        unfocusedContainerColor = CardBackground
    )

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 16.dp)
                .wrapContentHeight(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = ScreenBackground),
            border = BorderStroke(1.dp, TableHeaderBg),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Signature Full-Width App Theme Header in Chocolate Primary
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(ChocolatePrimary)
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.White.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Share Bill Details",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Text(
                                text = "Customer statement ledger report",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.82f)
                            )
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close, 
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }
                    }
                }

                // Popup Body Content
                Column(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth()
                ) {
                    // Financial Year Selection
                    ExposedDropdownMenuBox(
                        expanded = showFYDropdown,
                        onExpandedChange = { showFYDropdown = !showFYDropdown }
                    ) {
                        OutlinedTextField(
                            value = "FY $selectedFY",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Financial Year") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = showFYDropdown) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = customTextFieldColors
                        )
                        ExposedDropdownMenu(
                            expanded = showFYDropdown,
                            onDismissRequest = { showFYDropdown = false },
                            modifier = Modifier.background(CardBackground)
                        ) {
                            val fyList = if (financialYears.isEmpty()) listOf(selectedFY) else financialYears
                            fyList.forEach { fy ->
                                DropdownMenuItem(
                                    text = { 
                                        Text(
                                            "FY $fy",
                                            fontWeight = if (fy == selectedFY) FontWeight.Bold else FontWeight.Normal,
                                            color = if (fy == selectedFY) ChocolatePrimary else DefaultTextColor
                                        ) 
                                    },
                                    onClick = {
                                        selectedFY = fy
                                        showFYDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Customer Selection Section
                    if (selectedCustomer == null) {
                        // Customer Search Input
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            label = { Text("Search & Select Customer") },
                            placeholder = { Text("Type name, address or GSTIN") },
                            modifier = Modifier.fillMaxWidth(),
                            leadingIcon = { 
                                Icon(
                                    imageVector = Icons.Default.Search, 
                                    contentDescription = null,
                                    tint = ChocolatePrimary
                                ) 
                            },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(
                                            imageVector = Icons.Default.Clear, 
                                            contentDescription = "Clear search",
                                            tint = ChocolatePrimary
                                        )
                                    }
                                }
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = customTextFieldColors
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = if (searchQuery.isBlank()) "Select from customer list:" else "Matching customers:",
                            style = MaterialTheme.typography.labelMedium,
                            color = ChocolatePrimaryDark.copy(alpha = 0.8f),
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )

                        // Scrollable Customer List Card
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 210.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            border = BorderStroke(1.dp, TableHeaderBg)
                        ) {
                            if (filteredCustomers.isEmpty()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(24.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = if (searchQuery.isBlank()) "No customers available" else "No customer matching \"$searchQuery\"",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            } else {
                                LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                    items(filteredCustomers) { customer ->
                                        val count = remember(customer.name, selectedFY, allBillEntries.size) {
                                            getBillsForCustomer(customer, selectedFY).size
                                        }

                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    selectedCustomer = customer
                                                    searchQuery = ""
                                                }
                                                .padding(horizontal = 14.dp, vertical = 10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(
                                                    text = customer.name,
                                                    fontWeight = FontWeight.SemiBold,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = ChocolatePrimaryDark,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                                if (customer.address.isNotBlank()) {
                                                    Text(
                                                        text = customer.address,
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                        maxLines = 1,
                                                        overflow = TextOverflow.Ellipsis
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Surface(
                                                shape = RoundedCornerShape(12.dp),
                                                color = if (count > 0) GoldAccent.copy(alpha = 0.25f) else TableHeaderBg,
                                                border = if (count > 0) BorderStroke(0.5.dp, GoldAccent) else null,
                                                modifier = Modifier.padding(start = 4.dp)
                                            ) {
                                                Text(
                                                    text = if (count > 0) "$count bills" else "0 bills",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = if (count > 0) ChocolatePrimaryDark else MaterialTheme.colorScheme.onSurfaceVariant,
                                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                    fontWeight = if (count > 0) FontWeight.Bold else FontWeight.Normal
                                                )
                                            }
                                        }
                                        HorizontalDivider(
                                            thickness = 0.5.dp,
                                            color = TableHeaderBg
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        // Selected Customer Display Card
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = CardBackground),
                            border = BorderStroke(1.5.dp, GoldAccent)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(ChocolatePrimary.copy(alpha = 0.12f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Person,
                                            contentDescription = null,
                                            tint = ChocolatePrimary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = selectedCustomer!!.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = ChocolatePrimaryDark
                                        )
                                        if (selectedCustomer!!.address.isNotBlank()) {
                                            Text(
                                                text = selectedCustomer!!.address,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (!selectedCustomer!!.gstin.isNullOrBlank()) {
                                            Text(
                                                text = "GSTIN: ${selectedCustomer!!.gstin}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = ChocolatePrimary,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    }
                                    TextButton(
                                        onClick = { 
                                            selectedCustomer = null 
                                            searchQuery = ""
                                        }
                                    ) {
                                        Text("Change", color = ChocolatePrimary, fontWeight = FontWeight.Bold)
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                HorizontalDivider(thickness = 0.7.dp, color = TableHeaderBg)
                                Spacer(modifier = Modifier.height(10.dp))

                                // Bills Found Info
                                if (customerBills.isNotEmpty()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = Icons.Default.CheckCircle,
                                                contentDescription = null,
                                                tint = TotalSalesGreen,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = "${customerBills.size} bills found in FY $selectedFY",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                color = ChocolatePrimaryDark
                                            )
                                        }

                                        Text(
                                            text = "₹ ${formatIndianCurrency(totalAmount)}",
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TotalSalesGreen
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Compact list of bills
                                    Card(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(max = 140.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = CardDefaults.cardColors(containerColor = ScreenBackground),
                                        border = BorderStroke(1.dp, TableHeaderBg)
                                    ) {
                                        LazyColumn(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)) {
                                            items(customerBills) { bill ->
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .clickable { onViewBill(bill) }
                                                        .padding(vertical = 5.dp, horizontal = 4.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Default.Receipt,
                                                            contentDescription = "Bill",
                                                            tint = ChocolatePrimary,
                                                            modifier = Modifier.size(16.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(6.dp))
                                                        Column {
                                                            Text(
                                                                text = bill.billNo,
                                                                style = MaterialTheme.typography.bodySmall,
                                                                fontWeight = FontWeight.Bold,
                                                                color = ChocolatePrimary
                                                            )
                                                            Text(
                                                                text = bill.date,
                                                                style = MaterialTheme.typography.labelSmall,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }
                                                    }
                                                    
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            text = "₹ ${formatIndianCurrency(bill.amount)}",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            fontWeight = FontWeight.Bold,
                                                            color = DefaultTextColor
                                                        )
                                                        Spacer(modifier = Modifier.width(8.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = ChocolatePrimary.copy(alpha = 0.12f),
                                                            modifier = Modifier.clickable { onViewBill(bill) }
                                                        ) {
                                                            Row(
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Default.Visibility,
                                                                    contentDescription = "View",
                                                                    tint = ChocolatePrimary,
                                                                    modifier = Modifier.size(12.dp)
                                                                )
                                                                Spacer(modifier = Modifier.width(3.dp))
                                                                Text(
                                                                    text = "View",
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = ChocolatePrimary,
                                                                    fontWeight = FontWeight.Bold
                                                                )
                                                            }
                                                        }
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Surface(
                                                            shape = RoundedCornerShape(6.dp),
                                                            color = GoldAccent.copy(alpha = 0.2f),
                                                            modifier = Modifier.clickable {
                                                                try {
                                                                    val url = buildWebBillUrl(context, bill)
                                                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                                                                    context.startActivity(intent)
                                                                } catch (e: Exception) {
                                                                    android.widget.Toast.makeText(context, "Cannot open browser: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        ) {
                                                            Row(
                                                                verticalAlignment = Alignment.CenterVertically,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                            ) {
                                                                Icon(
                                                                    imageVector = Icons.Default.Language,
                                                                    contentDescription = "Web View",
                                                                    tint = ChocolatePrimaryDark,
                                                                    modifier = Modifier.size(12.dp)
                                                                )
                                                                Spacer(modifier = Modifier.width(3.dp))
                                                                Text(
                                                                    text = "Web",
                                                                    style = MaterialTheme.typography.labelSmall,
                                                                    color = ChocolatePrimaryDark,
                                                                    fontWeight = FontWeight.Bold
                                                                )
                                                            }
                                                        }
                                                    }
                                                }
                                                HorizontalDivider(thickness = 0.5.dp, color = TableHeaderBg)
                                            }
                                        }
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Info,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "No bills found in FY $selectedFY for this customer",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Bottom Action Buttons in Theme
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel", color = ChocolatePrimary, fontWeight = FontWeight.SemiBold)
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        val canGenerate = selectedCustomer != null && customerBills.isNotEmpty()

                        OutlinedButton(
                            onClick = {
                                selectedCustomer?.let { cust ->
                                    onPreview(cust, selectedFY, customerBills)
                                }
                            },
                            enabled = canGenerate,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (canGenerate) ChocolatePrimary else TableHeaderBg)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Visibility,
                                contentDescription = null,
                                tint = if (canGenerate) ChocolatePrimary else MaterialTheme.colorScheme.outline,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Preview", 
                                color = if (canGenerate) ChocolatePrimary else MaterialTheme.colorScheme.outline,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                selectedCustomer?.let { cust ->
                                    onShare(cust, selectedFY, customerBills)
                                }
                            },
                            enabled = canGenerate,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ChocolatePrimary,
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.Share,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Share", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
