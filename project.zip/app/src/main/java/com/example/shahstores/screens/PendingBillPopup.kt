package com.example.shahstores.screens

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.shahstores.model.Customer
import com.example.shahstores.model.PendingBill
import java.util.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PendingBillPopup(
    onDismiss: () -> Unit,
    pendingBills: List<PendingBill>,
    customers: List<Customer>,
    onAddPendingBill: (PendingBill) -> Unit,
    onUpdatePendingBill: (PendingBill) -> Unit,
    onDeletePendingBill: (PendingBill) -> Unit
) {
    var showCustomerSearch by remember { mutableStateOf(false) }
    var showAmountDialog by remember { mutableStateOf(false) }
    var selectedCustomerForAmount by remember { mutableStateOf<Customer?>(null) }
    var editingPendingBill by remember { mutableStateOf<PendingBill?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column {
                // Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(12.dp)
                ) {
                    Text(
                        text = "Bills to be created",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.Center)
                    )
                    IconButton(
                        onClick = { showCustomerSearch = true },
                        modifier = Modifier.align(Alignment.CenterEnd)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add", tint = MaterialTheme.colorScheme.onPrimary)
                    }
                }

                // List Table
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("S.N.", modifier = Modifier.weight(0.15f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Name", modifier = Modifier.weight(0.35f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Address", modifier = Modifier.weight(0.3f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Amount", modifier = Modifier.weight(0.2f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    LazyColumn(modifier = Modifier.fillMaxSize()) {
                        itemsIndexed(pendingBills) { index, pendingBill ->
                            var showDeleteConfirm by remember { mutableStateOf(false) }
                            
                            if (showDeleteConfirm) {
                                AlertDialog(
                                    onDismissRequest = { showDeleteConfirm = false },
                                    title = { Text("Delete Entry") },
                                    text = { Text("Are you sure you want to delete this entry for ${pendingBill.customerName}?") },
                                    confirmButton = {
                                        TextButton(onClick = {
                                            onDeletePendingBill(pendingBill)
                                            showDeleteConfirm = false
                                        }) { Text("Delete", color = Color.Red) }
                                    },
                                    dismissButton = {
                                        TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") }
                                    }
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .combinedClickable(
                                        onClick = {
                                            editingPendingBill = pendingBill
                                            showAmountDialog = true
                                        },
                                        onLongClick = { showDeleteConfirm = true }
                                    )
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${index + 1}", modifier = Modifier.weight(0.15f), fontSize = 12.sp)
                                Text(pendingBill.customerName, modifier = Modifier.weight(0.35f), fontSize = 12.sp)
                                Text(pendingBill.customerAddress, modifier = Modifier.weight(0.3f), fontSize = 12.sp)
                                Text(pendingBill.amount, modifier = Modifier.weight(0.2f), fontSize = 12.sp)
                            }
                            Divider(color = Color.LightGray, thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }

    if (showCustomerSearch) {
        CustomerSearchDialog(
            customers = customers,
            onDismiss = { showCustomerSearch = false },
            onCustomerSelected = { customer ->
                if (pendingBills.any { it.customerName == customer.name && it.customerAddress == customer.address }) {
                    // Duplicate handled
                } else {
                    selectedCustomerForAmount = customer
                    showAmountDialog = true
                }
                showCustomerSearch = false
            },
            existingPendingBills = pendingBills
        )
    }

    if (showAmountDialog) {
        AmountInputDialog(
            onDismiss = { 
                showAmountDialog = false
                selectedCustomerForAmount = null
                editingPendingBill = null
            },
            onAmountEntered = { amount ->
                if (editingPendingBill != null) {
                    onUpdatePendingBill(editingPendingBill!!.copy(amount = amount))
                } else if (selectedCustomerForAmount != null) {
                    onAddPendingBill(
                        PendingBill(
                            id = UUID.randomUUID().toString(),
                            customerName = selectedCustomerForAmount!!.name,
                            customerAddress = selectedCustomerForAmount!!.address,
                            amount = amount
                        )
                    )
                }
                showAmountDialog = false
                selectedCustomerForAmount = null
                editingPendingBill = null
            },
            initialAmount = editingPendingBill?.amount ?: ""
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerSearchDialog(
    customers: List<Customer>,
    onDismiss: () -> Unit,
    onCustomerSelected: (Customer) -> Unit,
    existingPendingBills: List<PendingBill>
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredCustomers = remember(searchQuery, customers) {
        customers.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.8f),
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Search Customer",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    placeholder = { Text("Search Customer") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = null)
                            }
                        }
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words)
                )

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(filteredCustomers) { _, customer ->
                        val isAlreadyAdded = existingPendingBills.any { it.customerName == customer.name && it.customerAddress == customer.address }
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable(enabled = !isAlreadyAdded) { onCustomerSelected(customer) }
                                .padding(16.dp)
                                .background(if (isAlreadyAdded) Color.LightGray.copy(alpha = 0.3f) else Color.Transparent),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(customer.name, fontWeight = FontWeight.Bold)
                                Text(customer.address, fontSize = 12.sp, color = Color.Gray)
                            }
                            if (isAlreadyAdded) {
                                Text("Already Added", fontSize = 10.sp, color = Color.Red)
                            }
                        }
                        Divider(thickness = 0.5.dp)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AmountInputDialog(
    onDismiss: () -> Unit,
    onAmountEntered: (String) -> Unit,
    initialAmount: String = ""
) {
    var amount by remember { mutableStateOf(initialAmount) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = MaterialTheme.shapes.medium,
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Enter Amount",
                        color = MaterialTheme.colorScheme.onPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        label = { Text("Amount") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Number,
                            imeAction = ImeAction.Done
                        ),
                        keyboardActions = KeyboardActions(
                            onDone = { if (amount.isNotBlank()) onAmountEntered(amount) }
                        ),
                        singleLine = true,
                        placeholder = { Text("0.00") }
                    )
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) {
                            Text("Cancel")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(onClick = { if (amount.isNotBlank()) onAmountEntered(amount) }) {
                            Text("OK")
                        }
                    }
                }
            }
        }
    }
}
