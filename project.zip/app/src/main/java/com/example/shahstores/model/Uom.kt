package com.example.shahstores.model

import com.google.firebase.database.IgnoreExtraProperties

@IgnoreExtraProperties
data class Uom(
    var id: String = "",
    var name: String = ""
)
