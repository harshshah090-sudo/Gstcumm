package com.example.shahstores.model

import com.google.firebase.firestore.DocumentId

data class Uom(
    @DocumentId val id: String = "",
    val name: String = ""
)
