package com.example.shahstores.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onDismiss: () -> Unit,
    onFirmInformationClick: () -> Unit,
    onLetterHeadClick: () -> Unit,
    onExportHsnSummaryClick: () -> Unit = {},
    onBillsToBeCreatedClick: () -> Unit = {},
    onShareBillDetailsClick: () -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onFirmInformationClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Person, contentDescription = "Firm Information")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Firm Information")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLetterHeadClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Description, contentDescription = "Letter Head")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Letter Head")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onExportHsnSummaryClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = "Export HSN Summary")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Export HSN Summary")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onBillsToBeCreatedClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = "Bills to be Created")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Bills to be Created")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onShareBillDetailsClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Share, contentDescription = "Share Bill Details")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Share Bill Details")
            }
        }
    }
}
