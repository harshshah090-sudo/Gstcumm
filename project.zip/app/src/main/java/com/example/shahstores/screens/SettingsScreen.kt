package com.example.shahstores.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onDismiss: () -> Unit,
    onFirmInformationClick: () -> Unit,
    onLetterHeadClick: () -> Unit,
    onExportHsnSummaryClick: () -> Unit = {},
    onBillsToBeCreatedClick: () -> Unit = {},
    onShareBillDetailsClick: () -> Unit = {},
    selectedGstType: String = "",
    onSelectGstType: (String) -> Unit = {}
) {
    var showGstDialog by remember { mutableStateOf(false) }

    if (showGstDialog) {
        AlertDialog(
            onDismissRequest = { showGstDialog = false },
            title = { Text("Select GST Registration Type") },
            text = {
                Column {
                    val options = listOf("Regular GST", "Composition Scheme")
                    options.forEach { option ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    onSelectGstType(option)
                                    showGstDialog = false
                                }
                                .padding(vertical = 8.dp)
                        ) {
                            RadioButton(
                                selected = (selectedGstType == option),
                                onClick = {
                                    onSelectGstType(option)
                                    showGstDialog = false
                                }
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(option, style = MaterialTheme.typography.bodyLarge)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showGstDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.padding(innerPadding)) {
            // Select GST Registration Type
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showGstDialog = true }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AccountBalance, contentDescription = "GST Registration Type")
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text("Select GST Registration Type", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        text = if (selectedGstType.isNotBlank()) selectedGstType else "Not Selected (Tap to choose)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Divider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onFirmInformationClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Person, contentDescription = "Firm Information")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Firm Information")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onLetterHeadClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Description, contentDescription = "Letter Head")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Letter Head")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onExportHsnSummaryClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.FileDownload, contentDescription = "Export Summary")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Export Summary")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onBillsToBeCreatedClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.ReceiptLong, contentDescription = "Bills to be Created")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Bills to be Created")
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onShareBillDetailsClick() }
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Share, contentDescription = "Share Bill Details")
                Spacer(modifier = Modifier.width(16.dp))
                Text("Share Bill Details")
            }
        }
    }
}
