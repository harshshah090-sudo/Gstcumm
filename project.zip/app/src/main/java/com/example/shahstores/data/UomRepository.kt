package com.example.shahstores.data

import com.example.shahstores.model.Uom
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class UomRepository {
    private val db = FirebaseFirestore.getInstance()
    private val uomCollection = db.collection("uoms")

    fun getUoms(): Flow<List<Uom>> = callbackFlow {
        val listenerRegistration = uomCollection.addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            if (snapshot != null) {
                val uoms = snapshot.toObjects(Uom::class.java)
                trySend(uoms).isSuccess
            }
        }
        awaitClose { listenerRegistration.remove() }
    }

    fun addUom(uom: Uom) {
        uomCollection.add(uom)
    }

    fun deleteUom(uomId: String) {
        uomCollection.document(uomId).delete()
    }
}
