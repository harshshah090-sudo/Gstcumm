package com.example.shahstores.data

import android.util.Log
import com.example.shahstores.model.Uom
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class UomRepository {
    private val databaseUrl = "https://gen-lang-client-0387562267-default-rtdb.firebaseio.com"
    private val rtdbRef = Firebase.database(databaseUrl).getReference("uoms")
    private val firestore = try { FirebaseFirestore.getInstance() } catch (_: Exception) { null }
    private val uomCollection = firestore?.collection("uoms")

    fun getUoms(): Flow<List<Uom>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Uom>()
                for (child in snapshot.children) {
                    val uom = child.getValue(Uom::class.java)
                    if (uom != null) {
                        list.add(uom.copy(id = child.key ?: uom.id))
                    } else {
                        // In case string value was stored directly
                        val nameStr = child.getValue(String::class.java) ?: child.child("name").getValue(String::class.java)
                        if (!nameStr.isNullOrBlank()) {
                            list.add(Uom(id = child.key ?: "", name = nameStr))
                        }
                    }
                }
                
                // If RTDB had no records yet, try Firestore or provide standard default UOMs
                if (list.isEmpty()) {
                    uomCollection?.get()?.addOnSuccessListener { fsSnapshot ->
                        if (!fsSnapshot.isEmpty) {
                            val fsUoms = fsSnapshot.documents.mapNotNull { doc ->
                                doc.toObject(Uom::class.java)?.copy(id = doc.id)
                            }
                            if (fsUoms.isNotEmpty()) {
                                // Sync back to RTDB so all devices get it
                                fsUoms.forEach { uom ->
                                    val key = if (uom.id.isNotBlank()) uom.id else rtdbRef.push().key ?: ""
                                    rtdbRef.child(key).setValue(uom.copy(id = key))
                                }
                                trySend(fsUoms.sortedBy { it.name.lowercase() })
                                return@addOnSuccessListener
                            }
                        }
                    }
                }

                trySend(list.sortedBy { it.name.lowercase() }).isSuccess
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("UomRepository", "Failed to read UOMs from RTDB", error.toException())
            }
        }

        rtdbRef.addValueEventListener(listener)
        awaitClose { rtdbRef.removeEventListener(listener) }
    }

    fun addUom(uom: Uom) {
        val trimmedName = uom.name.trim()
        if (trimmedName.isBlank()) return

        // Save to Firebase Realtime Database for instant multi-device sync
        val key = if (uom.id.isNotBlank()) uom.id else (rtdbRef.push().key ?: "")
        val uomWithId = uom.copy(id = key, name = trimmedName)
        rtdbRef.child(key).setValue(uomWithId)

        // Also save to Firestore as secondary cloud backup if available
        try {
            uomCollection?.document(key)?.set(uomWithId)
        } catch (e: Exception) {
            Log.w("UomRepository", "Firestore backup skipped: ${e.message}")
        }
    }

    fun deleteUom(uomId: String) {
        if (uomId.isBlank()) return
        rtdbRef.child(uomId).removeValue()
        try {
            uomCollection?.document(uomId)?.delete()
        } catch (_: Exception) {}
    }
}
