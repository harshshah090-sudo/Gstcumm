package com.example.shahstores.util

import com.example.shahstores.model.BillEntry
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class ValidationError(
    val message: String,
    val billNo: String
)

data class ValidationResult(
    val duplicateErrors: List<ValidationError> = emptyList(),
    val sequenceErrors: List<ValidationError> = emptyList()
) {
    fun isEmpty() = duplicateErrors.isEmpty() && sequenceErrors.isEmpty()
}

fun getFinancialYear(date: Date): String {
    val calendar = Calendar.getInstance()
    calendar.time = date
    val year = calendar.get(Calendar.YEAR) % 100
    val month = calendar.get(Calendar.MONTH)

    return if (month >= 3) { // April to December
        "${"%02d".format(year)}-${"%02d".format((year + 1) % 100)}"
    } else { // January to March
        "${"%02d".format((year - 1 + 100) % 100)}-${"%02d".format(year)}"
    }
}

/**
 * Attempts to parse a date string using multiple locales to handle legacy data
 * saved in non-English formats (e.g. Hindi, Gujarati).
 */
fun tryParseDate(dateStr: String): Date? {
    val pattern = "dd/MMM/yy"
    
    // 1. Try English (Standard)
    try {
        val date = SimpleDateFormat(pattern, Locale.ENGLISH).parse(dateStr)
        if (date != null) return date
    } catch (_: Exception) {}

    // 2. Try common Indian locales that might have been used
    val fallbackLocales = listOf(
        Locale("hi"), // Hindi
        Locale("gu"), // Gujarati
        Locale("mr"), // Marathi
        Locale.getDefault() // Whatever the device is currently set to
    )

    for (locale in fallbackLocales) {
        try {
            val date = SimpleDateFormat(pattern, locale).parse(dateStr)
            if (date != null) return date
        } catch (_: Exception) {}
    }
    
    return null
}

/**
 * Converts any date string to the standard Locale.ENGLISH format.
 * Returns null if the date cannot be parsed.
 */
fun getStandardizedDate(dateStr: String): String? {
    val date = tryParseDate(dateStr) ?: return null
    return SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH).format(date)
}

fun getBillNum(billNo: String): Int? = billNo.split("/").lastOrNull()?.toIntOrNull()

fun getBillSession(billNo: String): String? = billNo.split("/").getOrNull(1)

fun calculateNextBillNo(selectedDate: String, billEntries: List<BillEntry>): String {
    val sdf = SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH)
    val date = try { sdf.parse(selectedDate) } catch (e: Exception) { Date() } ?: Date()
    val session = getFinancialYear(date)
    
    val sessionBills = billEntries.filter { 
        getBillSession(it.billNo) == session
    }
    
    val lastBillNoStr = sessionBills.mapNotNull { getBillNum(it.billNo) }.maxOrNull() ?: 0
    val nextNo = lastBillNoStr + 1
    return "SS/$session/${"%04d".format(nextNo)}"
}

fun validateBillEntries(billEntries: List<BillEntry>): ValidationResult {
    val duplicateErrors = mutableListOf<ValidationError>()
    val sequenceErrors = mutableListOf<ValidationError>()
    val sdf = SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH)

    // 1. Check for duplicate invoice numbers
    val duplicates = billEntries.groupBy { it.billNo }.filter { it.value.size > 1 }
    duplicates.forEach { (billNo, entries) ->
        duplicateErrors.add(ValidationError("$billNo - ${entries.size} Times", billNo))
    }

    // 2. Check chronological order (Sandwich Rule)
    val entriesByYear = billEntries.groupBy { entry ->
        try {
            val date = sdf.parse(entry.date)
            if (date != null) getFinancialYear(date) else "Unknown"
        } catch (e: Exception) {
            "Unknown"
        }
    }

    entriesByYear.forEach { (year, yearEntries) ->
        if (year == "Unknown") return@forEach
        
        val sortedEntries = yearEntries.mapNotNull { entry ->
            val num = getBillNum(entry.billNo)
            if (num != null) num to entry else null
        }.sortedBy { it.first }

        for (i in 1 until sortedEntries.size) {
            val prev = sortedEntries[i-1].second
            val curr = sortedEntries[i].second
            
            try {
                val prevDate = sdf.parse(prev.date)
                val currDate = sdf.parse(curr.date)
                
                if (prevDate != null && currDate != null && currDate.before(prevDate)) {
                    sequenceErrors.add(
                        ValidationError(
                            "$year -> Invoice ${curr.billNo} (${curr.date}) cannot be before ${prev.billNo} (${prev.date})",
                            curr.billNo
                        )
                    )
                }
            } catch (e: Exception) {}
        }
    }

    return ValidationResult(duplicateErrors, sequenceErrors)
}
