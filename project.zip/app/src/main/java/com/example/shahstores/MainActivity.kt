package com.example.shahstores

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.rememberAsyncImagePainter
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import java.io.File
import com.example.shahstores.model.FirmInfo
import com.example.shahstores.model.BillEntry
import com.example.shahstores.model.BillEntryItem
import com.example.shahstores.model.BillItem
import com.example.shahstores.model.Customer
import com.example.shahstores.model.Item
import com.example.shahstores.model.PendingBill
import com.example.shahstores.screens.*
import com.example.shahstores.util.*
import com.example.shahstores.viewmodel.FirmInfoUiState
import com.example.shahstores.viewmodel.FirmInfoViewModel
import com.example.shahstores.viewmodel.UomViewModel
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.MutableData
import com.google.firebase.database.Transaction
import com.google.firebase.database.ValueEventListener
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.apache.poi.ss.usermodel.DataFormatter
import org.apache.poi.ss.usermodel.WorkbookFactory
import com.example.shahstores.ui.theme.ShahStoresTheme

import com.example.shahstores.ui.theme.GoldAccent
import com.example.shahstores.ui.theme.ChocolatePrimaryDark
import com.example.shahstores.ui.theme.TotalSalesGreen
import com.example.shahstores.ui.theme.InactiveNavIconColor
import com.example.shahstores.ui.theme.DefaultTextColor


@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class, ExperimentalMaterialApi::class)
class MainActivity : ComponentActivity() {
    private val uomViewModel: UomViewModel by viewModels()
    private val firmInfoViewModel: FirmInfoViewModel by viewModels()
    private val deepLinkBillNo = mutableStateOf<String?>(null)

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractDeepLink(intent)
    }

    private fun extractDeepLink(intent: Intent?) {
        val data = intent?.data ?: return
        val no = data.getQueryParameter("no") 
            ?: data.getQueryParameter("billNo") 
            ?: data.lastPathSegment
        if (!no.isNullOrBlank() && no != "bill") {
            deepLinkBillNo.value = no
        }
    }

    private fun getAppDeviceId(): String {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        var id = prefs.getString("device_id", null)
        if (id == null) {
            id = UUID.randomUUID().toString()
            prefs.edit().putString("device_id", id).apply()
        }
        return id
    }

    private fun readCustomersExcelFile(inputStream: InputStream): List<Customer> {
        val customers = mutableListOf<Customer>()
        val workbook = WorkbookFactory.create(inputStream)
        val sheet = workbook.getSheetAt(0)
        val headerRow = sheet.getRow(0)
        val headerMap = mutableMapOf<String, Int>()
        val formatter = DataFormatter()

        headerRow.forEach { cell ->
            headerMap[formatter.formatCellValue(cell).lowercase()] = cell.columnIndex
        }

        for (i in 1..sheet.lastRowNum) {
            val row = sheet.getRow(i) ?: continue

            val name = formatter.formatCellValue(row.getCell(headerMap["name"]!!))
            val address = formatter.formatCellValue(row.getCell(headerMap["address"]!!))
            val registrationType = formatter.formatCellValue(row.getCell(headerMap["registrationtype"]!!))

            val gstinValue = formatter.formatCellValue(row.getCell(headerMap["gstin"]!!))
            val gstin = gstinValue.ifBlank { null }

            val state = formatter.formatCellValue(row.getCell(headerMap["state"]!!))
            val stateCode = formatter.formatCellValue(row.getCell(headerMap["statecode"]!!))

            val transportValue = formatter.formatCellValue(row.getCell(headerMap["transport"]!!))
            val transport = transportValue.ifBlank { null }

            val phoneNumberValue = formatter.formatCellValue(row.getCell(headerMap["phonenumber"]!!))
            val phoneNumber = phoneNumberValue.ifBlank { null }

            customers.add(Customer(name, address, registrationType, gstin, state, stateCode, transport, phoneNumber))
        }
        return customers
    }

    private fun readItemsExcelFile(inputStream: InputStream): List<Item> {
        val items = mutableListOf<Item>()
        val workbook = WorkbookFactory.create(inputStream)
        val sheet = workbook.getSheetAt(0)
        val headerRow = sheet.getRow(0)
        val headerMap = mutableMapOf<String, Int>()
        val formatter = DataFormatter()

        headerRow.forEach { cell ->
            headerMap[formatter.formatCellValue(cell).lowercase()] = cell.columnIndex
        }

        for (i in 1..sheet.lastRowNum) {
            val row = sheet.getRow(i) ?: continue

            val name = formatter.formatCellValue(row.getCell(headerMap["name"]!!))
            val uom = formatter.formatCellValue(row.getCell(headerMap["uom"]!!))
            val hsnCode = formatter.formatCellValue(row.getCell(headerMap["hsncode"]!!))
            val gstRate = formatter.formatCellValue(row.getCell(headerMap["gstrate"]!!))

            items.add(Item(name, uom, hsnCode, gstRate))
        }
        return items
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        extractDeepLink(intent)
        cleanPdfCache(this)
        
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
        } catch (_: Exception) {}

        val deviceId = getAppDeviceId()
        setContent {
            ShahStoresTheme {
                val database = FirebaseDatabase.getInstance()
                val itemsRef = remember { database.getReference("items") }
                val customersRef = remember { database.getReference("customers") }
                val billEntriesRef = remember { database.getReference("bill_entries") }
                val pendingBillsRef = remember { database.getReference("pending_bills") }
                val connectedRef = remember { database.getReference(".info/connected") }
                val lockRef = remember { database.getReference("creation_lock") }

                val pagerState = rememberPagerState(initialPage = 1) { 3 }
                val scope = rememberCoroutineScope()
                var customerSearchQuery by remember { mutableStateOf("") }
                var entriesSearchQuery by remember { mutableStateOf("") }
                var itemSearchQuery by remember { mutableStateOf("") }
                var entriesDateFilter by remember { mutableStateOf<String?>(null) }
                var showEntriesDateOptions by remember { mutableStateOf(false) }
                var showEntriesDatePicker by remember { mutableStateOf(false) }
                var showEntriesMonthPicker by remember { mutableStateOf(false) }

                val showAddItemPopup = remember { mutableStateOf(false) }
                val showAddCustomerPopup = remember { mutableStateOf(false) }
                val showCreateBillScreen = remember { mutableStateOf(false) }
                val showSettingsScreen = remember { mutableStateOf(false) }
                val showFirmInformationScreen = remember { mutableStateOf(false) }
                val showExportHsnPopup = remember { mutableStateOf(false) }
                val showPdfViewerScreen = remember { mutableStateOf(false) }
                val showPendingBillPopup = remember { mutableStateOf(false) }
                val showShareBillDetailsPopup = remember { mutableStateOf(false) }
                val isQuotationMode = remember { mutableStateOf(false) }
                var pdfSource by remember { mutableStateOf<Any?>(null) }
                var pdfTitle by remember { mutableStateOf("Bill Preview") }

                val items = remember { mutableStateOf(listOf<Item>()) }
                val customers = remember { mutableStateOf(listOf<Customer>()) }
                val billEntries = remember { mutableStateListOf<BillEntry>() }
                val pendingBills = remember { mutableStateOf(listOf<PendingBill>()) }
                var editingBill by remember { mutableStateOf<BillEntry?>(null) }
                var itemToEdit by remember { mutableStateOf<Item?>(null) }
                var customerToEdit by remember { mutableStateOf<Customer?>(null) }
                var selectedCustomerForBill by remember { mutableStateOf<Customer?>(null) }
                
                var itemSelectionMode by remember { mutableStateOf(false) }
                var customerSelectionMode by remember { mutableStateOf(false) }
                var selectedItems by remember { mutableStateOf(emptySet<Int>()) }
                var selectedCustomers by remember { mutableStateOf(emptySet<Int>()) }
                val context = LocalContext.current
                val uiState by firmInfoViewModel.uiState.collectAsState()
                LaunchedEffect(uiState) {
                    val state = uiState
                    if (state is FirmInfoUiState.Success && state.firmInfo.firmName.isNotBlank()) {
                        try {
                            database.getReference("firm_info").setValue(state.firmInfo)
                        } catch (_: Exception) {}
                    }
                }
                val isRefreshing by remember { mutableStateOf(false) }
                var isOnline by remember { mutableStateOf(true) }
                var isBillEntriesLoaded by remember { mutableStateOf(false) }
                var isLocking by remember { mutableStateOf(false) }

                var validationResult by remember { mutableStateOf<ValidationResult?>(null) }
                var highlightedBillNo by remember { mutableStateOf<String?>(null) }

                val financialYears by remember {
                    derivedStateOf {
                        val years = billEntries.map { 
                            try {
                                val parsedDate = tryParseDate(it.date)
                                if (parsedDate != null) getFinancialYear(parsedDate) else getFinancialYear(Date())
                            } catch (_: Exception) {
                                getFinancialYear(Date())
                            }
                        }.toSet().toMutableList()
                        val currentFinancialYear = getFinancialYear(Date())
                        if (!years.contains(currentFinancialYear)) {
                            years.add(currentFinancialYear)
                        }
                        years.sorted()
                    }
                }
                var selectedFinancialYear by remember { mutableStateOf(getFinancialYear(Date())) }
                var showFinancialYearDropdown by remember { mutableStateOf(false) }

                val openBillPreview: (BillEntry) -> Unit = { entry ->
                    showShareBillDetailsPopup.value = false
                    showSettingsScreen.value = false

                    // Resolve customer if missing
                    val targetCustomer = entry.customer
                        ?: customers.value.find { it.name.equals(entry.customerName, ignoreCase = true) }
                        ?: Customer(name = entry.customerName.ifBlank { "Customer" })

                    // Resolve items if missing (for legacy or compact entries)
                    val targetItems = if (entry.items.isNotEmpty()) {
                        entry.items
                    } else {
                        val preTax = entry.amount / 1.12
                        listOf(
                            BillEntryItem(
                                item = Item(
                                    name = "Goods/Services as per Bill",
                                    uom = "PCS",
                                    hsnCode = "5208",
                                    gstRate = "12%"
                                ),
                                quantity = "1",
                                rate = String.format(Locale.ENGLISH, "%.2f", preTax),
                                amount = preTax
                            )
                        )
                    }

                    val isDeadStorage = entry.pdfUrl?.let {
                        it.contains("firebasestorage.googleapis.com") || it.contains("storage.googleapis.com")
                    } ?: false

                    pdfSource = "syncing"
                    pdfTitle = "Bill Preview - ${entry.billNo}"
                    showPdfViewerScreen.value = true
                    lifecycleScope.launch {
                        try {
                            val currentUiState = firmInfoViewModel.uiState.value
                            val firmInfo = (currentUiState as? FirmInfoUiState.Success)?.firmInfo ?: FirmInfo()
                            val firmInfoMap = mapOf(
                                "firmName" to firmInfo.firmName,
                                "tagLine" to firmInfo.tagLine,
                                "address" to firmInfo.firmAddress,
                                "gstin" to firmInfo.firmGstin,
                                "phone" to "${firmInfo.phoneNo1} ${firmInfo.phoneNo2} ${firmInfo.phoneNo3}",
                                "logoUri" to firmInfo.firmLogoUrl,
                                "bankName" to firmInfo.bankName,
                                "accountNumber" to firmInfo.bankAccNo,
                                "ifscCode" to firmInfo.bankIfsc,
                                "signatureUri" to firmInfo.signatureUrl,
                                "qrCodeUri" to firmInfo.qrCodeUrl
                            )
                            val logo = if (firmInfo.firmLogoUrl.isNotBlank()) downloadImage(firmInfo.firmLogoUrl) else null
                            val signature = if (firmInfo.signatureUrl.isNotBlank()) downloadImage(firmInfo.signatureUrl) else null
                            val qrCode = if (firmInfo.qrCodeUrl.isNotBlank()) downloadImage(firmInfo.qrCodeUrl) else null

                            val itemsMap = targetItems.associate { it.item to BillItem(qty = it.quantity, rate = it.rate, isSelected = true) }
                            val pdfFile = generatePdf(
                                context,
                                firmInfoMap,
                                targetCustomer,
                                itemsMap,
                                entry.billNo,
                                entry.bundle,
                                entry.date,
                                logo,
                                signature,
                                qrCode
                            )
                            if (pdfFile != null) {
                                pdfSource = pdfFile
                            } else if (!isDeadStorage && !entry.pdfUrl.isNullOrBlank() && entry.pdfUrl.startsWith("http")) {
                                pdfSource = entry.pdfUrl
                            } else {
                                pdfSource = null
                                showPdfViewerScreen.value = false
                                Toast.makeText(context, "Failed to generate bill preview", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            Log.e("MainActivity", "Error generating on-demand PDF", e)
                            if (!isDeadStorage && !entry.pdfUrl.isNullOrBlank() && entry.pdfUrl.startsWith("http")) {
                                pdfSource = entry.pdfUrl
                            } else {
                                pdfSource = null
                                showPdfViewerScreen.value = false
                                Toast.makeText(context, "Error opening bill", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                LaunchedEffect(deepLinkBillNo.value, isBillEntriesLoaded) {
                    val requestedNo = deepLinkBillNo.value
                    if (!requestedNo.isNullOrBlank() && isBillEntriesLoaded) {
                        val matched = billEntries.find { 
                            it.billNo.equals(requestedNo, ignoreCase = true) ||
                            it.billNo.endsWith("/$requestedNo") ||
                            it.sn.toString() == requestedNo
                        }
                        if (matched != null) {
                            openBillPreview(matched)
                            deepLinkBillNo.value = null
                        } else {
                            Toast.makeText(context, "Bill #$requestedNo not found", Toast.LENGTH_SHORT).show()
                            deepLinkBillNo.value = null
                        }
                    }
                }

                val filteredItems = remember(itemSearchQuery, items.value) {
                    if (itemSearchQuery.isBlank()) {
                        items.value
                    } else {
                        items.value.filter { it.name.contains(itemSearchQuery, ignoreCase = true) }
                    }
                }

                val filteredCustomers = remember(customerSearchQuery, customers.value) {
                    if (customerSearchQuery.isBlank()) {
                        customers.value
                    } else {
                        customers.value.filter { it.name.contains(customerSearchQuery, ignoreCase = true) }
                    }
                }

                val filteredBillEntries by remember {
                    derivedStateOf {
                        billEntries
                            .filter { 
                                try {
                                    val parsedDate = tryParseDate(it.date)
                                    parsedDate != null && getFinancialYear(parsedDate) == selectedFinancialYear 
                                } catch (_: Exception) {
                                    false
                                }
                            }
                            .filter { it.customerName.contains(entriesSearchQuery, ignoreCase = true) }
                            .filter { entry ->
                                entriesDateFilter == null || entry.date.contains(entriesDateFilter!!, ignoreCase = true)
                            }
                            .sortedByDescending { entry ->
                                entry.billNo.split("/").lastOrNull()?.toIntOrNull() ?: 0
                            }
                    }
                }

                val totalSales by remember {
                    derivedStateOf {
                        filteredBillEntries.sumOf { it.amount }
                    }
                }

                val customerLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    uri?.let { selectedUri ->
                        scope.launch {
                            withContext(Dispatchers.IO) {
                                try {
                                    val inputStream = context.contentResolver.openInputStream(selectedUri)
                                    val newCustomers = inputStream?.let { stream -> readCustomersExcelFile(stream) } ?: emptyList()
                                    val currentCustomers = customers.value.toMutableList()
                                    currentCustomers.addAll(newCustomers)
                                    customersRef.setValue(currentCustomers)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(context, "Customers uploaded successfully", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(context, "Failed to upload customers: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }
                    }
                }

                val itemLauncher = rememberLauncherForActivityResult(
                    contract = ActivityResultContracts.GetContent()
                ) { uri: Uri? ->
                    uri?.let { selectedUri ->
                        scope.launch {
                            withContext(Dispatchers.IO) {
                                try {
                                    val inputStream = context.contentResolver.openInputStream(selectedUri)
                                    val newItems = inputStream?.let { stream -> readItemsExcelFile(stream) } ?: emptyList()
                                    val currentItems = items.value.toMutableList()
                                    currentItems.addAll(newItems)
                                    itemsRef.setValue(currentItems)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(context, "Items uploaded successfully", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(context, "Failed to upload items: ${e.message}", Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        }
                    }
                }


                LaunchedEffect(Unit) {
                    connectedRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            isOnline = snapshot.getValue(Boolean::class.java) ?: false
                        }
                        override fun onCancelled(error: DatabaseError) {}
                    })

                    itemsRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            val list = snapshot.getValue(object : com.google.firebase.database.GenericTypeIndicator<List<Item>>() {}) ?: emptyList()
                            items.value = list.sortedBy { it.name.lowercase() }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(context, "Failed to load Items: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })

                    customersRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            val list = snapshot.getValue(object : com.google.firebase.database.GenericTypeIndicator<List<Customer>>() {}) ?: emptyList()
                            customers.value = list.sortedBy { it.name.lowercase() }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(context, "Failed to load Customers: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })

                    billEntriesRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            val remoteEntries = snapshot.children.mapNotNull { childSnapshot ->
                                childSnapshot.getValue(BillEntry::class.java)?.copy(id = childSnapshot.key ?: "")
                            }
                            
                            scope.launch(Dispatchers.IO) {
                                remoteEntries.forEach { entry ->
                                    val standardizedDate = getStandardizedDate(entry.date)
                                    if (standardizedDate != null && entry.date != standardizedDate) {
                                        val billId = entry.id.ifBlank { entry.sn.toString() }
                                        Log.d("SmartRepair", "Fixing date for Bill ${entry.billNo}: ${entry.date} -> $standardizedDate")
                                        billEntriesRef.child(billId).child("date").setValue(standardizedDate)
                                    }
                                }
                            }

                            billEntries.clear()
                            billEntries.addAll(remoteEntries.sortedByDescending { it.sn })
                            isBillEntriesLoaded = true
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(context, "Failed to load Bill Entries: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })

                    pendingBillsRef.addValueEventListener(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            pendingBills.value = snapshot.children.mapNotNull { it.getValue(PendingBill::class.java) }
                        }
                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(context, "Failed to load Pending Bills: ${error.message}", Toast.LENGTH_SHORT).show()
                        }
                    })
                }

                val navItems = listOf(
                    Triple("Customers", Icons.Default.Group, "Customers Screen"),
                    Triple("Entries", Icons.Default.Description, "Entries Screen"),
                    Triple("Items", Icons.Default.Inventory, "Items Screen")
                )

                var backPressedTime by remember { mutableStateOf(0L) }

                BackHandler {
                    if (showShareBillDetailsPopup.value) {
                        showShareBillDetailsPopup.value = false
                    } else if (showPendingBillPopup.value) {
                        showPendingBillPopup.value = false
                    } else if (showPdfViewerScreen.value) {
                        showPdfViewerScreen.value = false
                        pdfSource = null
                        cleanPdfCache(context)
                        if (isQuotationMode.value) {
                            isQuotationMode.value = false
                            showCreateBillScreen.value = false
                            selectedCustomerForBill = null
                            showSettingsScreen.value = true
                        }
                    } else if (showFirmInformationScreen.value) {
                        showFirmInformationScreen.value = false
                    } else if (showSettingsScreen.value) {
                        showSettingsScreen.value = false
                    } else if (showCreateBillScreen.value) {
                        if (isQuotationMode.value) {
                            showCreateBillScreen.value = false
                            isQuotationMode.value = false
                            selectedCustomerForBill = null
                            showSettingsScreen.value = true
                        } else {
                            scope.launch {
                                lockRef.removeValue()
                                showCreateBillScreen.value = false
                                selectedCustomerForBill = null
                            }
                        }
                    } else if (itemSelectionMode) {
                        itemSelectionMode = false
                        selectedItems = emptySet()
                    } else if (customerSelectionMode) {
                        customerSelectionMode = false
                        selectedCustomers = emptySet()
                    } else if (pagerState.currentPage != 1) {
                        scope.launch {
                            pagerState.animateScrollToPage(1)
                        }
                    } else {
                        val currentTime = System.currentTimeMillis()
                        if (backPressedTime + 2000 > currentTime) {
                            (context as? Activity)?.finish()
                        } else {
                            Toast.makeText(context, "Press back again to exit", Toast.LENGTH_SHORT).show()
                            backPressedTime = currentTime
                        }
                    }
                }

                validationResult?.let { result ->
                    if (!result.isEmpty()) {
                        AlertDialog(
                            onDismissRequest = { validationResult = null },
                            title = { Text("Invoice Errors Found") },
                            text = {
                                LazyColumn {
                                    if (result.duplicateErrors.isNotEmpty()) {
                                        item {
                                            Text(
                                                "Duplicate Invoice No.",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                        items(result.duplicateErrors) { error ->
                                            Text(
                                                text = "• ${error.message}",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        val session = getBillSession(error.billNo)
                                                        if (session != null) {
                                                            selectedFinancialYear = session
                                                        }
                                                        entriesSearchQuery = ""
                                                        entriesDateFilter = null
                                                        highlightedBillNo = error.billNo
                                                        validationResult = null
                                                        scope.launch { pagerState.animateScrollToPage(1) }
                                                    }
                                                    .padding(vertical = 4.dp)
                                            )
                                        }
                                    }

                                    if (result.sequenceErrors.isNotEmpty()) {
                                        item {
                                            Text(
                                                "Date Sequence Error",
                                                style = MaterialTheme.typography.titleMedium,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(vertical = 8.dp)
                                            )
                                        }
                                        items(result.sequenceErrors) { error ->
                                            Text(
                                                text = "• ${error.message}",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable {
                                                        val session = getBillSession(error.billNo)
                                                        if (session != null) {
                                                            selectedFinancialYear = session
                                                        }
                                                        entriesSearchQuery = ""
                                                        entriesDateFilter = null
                                                        highlightedBillNo = error.billNo
                                                        validationResult = null
                                                        scope.launch { pagerState.animateScrollToPage(1) }
                                                    }
                                                    .padding(vertical = 4.dp)
                                            )
                                        }
                                    }
                                }
                            },
                            confirmButton = {
                                TextButton(onClick = { validationResult = null }) {
                                    Text("OK")
                                }
                            }
                        )
                    }
                }

                if (showAddItemPopup.value) {
                    AddItemPopup(
                        onDismiss = { 
                            showAddItemPopup.value = false
                            itemToEdit = null
                        },
                        onItemAdded = { newItem ->
                            val currentList = items.value.toMutableList()
                            val oldItem = itemToEdit
                            if (oldItem != null) {
                                val index = currentList.indexOfFirst { it.name == oldItem.name }
                                if (index != -1) {
                                    currentList[index] = newItem
                                } else {
                                    currentList.add(newItem)
                                }
                            } else {
                                currentList.add(newItem)
                            }
                            itemsRef.setValue(currentList)
                            itemToEdit = null
                        },
                        itemToEdit = itemToEdit,
                        uomViewModel = uomViewModel
                    )
                }

                if (showAddCustomerPopup.value) {
                    AddCustomerPopup(
                        onDismiss = { 
                            showAddCustomerPopup.value = false
                            customerToEdit = null
                         },
                        onCustomerAdded = { newCustomer ->
                            val currentList = customers.value.toMutableList()
                            val oldCustomer = customerToEdit
                            if (oldCustomer != null) {
                                val index = currentList.indexOfFirst { it.name == oldCustomer.name }
                                if (index != -1) {
                                    currentList[index] = newCustomer
                                } else {
                                    currentList.add(newCustomer)
                                }
                                if (selectedCustomerForBill?.name == oldCustomer.name) {
                                    selectedCustomerForBill = newCustomer
                                }
                            } else {
                                currentList.add(newCustomer)
                            }
                            customersRef.setValue(currentList)
                            customerToEdit = null
                        },
                        customerToEdit = customerToEdit,
                        items = items.value
                    )
                }

                if (showExportHsnPopup.value) {
                    ExportHsnPopup(
                        onDismiss = { showExportHsnPopup.value = false },
                        onExportClick = { start, end ->
                            exportHsnSummaryToExcel(context, billEntries, start, end)
                        }
                    )
                }

                if (showPendingBillPopup.value) {
                    PendingBillPopup(
                        onDismiss = { showPendingBillPopup.value = false },
                        pendingBills = pendingBills.value,
                        customers = customers.value,
                        onAddPendingBill = { pendingBillsRef.child(it.id).setValue(it) },
                        onUpdatePendingBill = { pendingBillsRef.child(it.id).setValue(it) },
                        onDeletePendingBill = { pendingBillsRef.child(it.id).removeValue() }
                    )
                }

                if (showShareBillDetailsPopup.value) {
                    ShareBillDetailsPopup(
                        customers = customers.value,
                        financialYears = financialYears,
                        currentFY = selectedFinancialYear,
                        allBillEntries = billEntries,
                        onDismiss = { showShareBillDetailsPopup.value = false },
                        onPreview = { customer, fy, customerBills ->
                            showShareBillDetailsPopup.value = false
                            showSettingsScreen.value = false
                            pdfSource = "syncing"
                            pdfTitle = "Statement - ${customer.name}"
                            showPdfViewerScreen.value = true
                            lifecycleScope.launch {
                                try {
                                    val file = generateCustomerStatementPdf(context, customer, customerBills, fy)
                                    if (file != null) {
                                        pdfSource = file
                                    } else {
                                        pdfSource = null
                                        showPdfViewerScreen.value = false
                                        Toast.makeText(context, "Failed to generate statement", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Log.e("MainActivity", "Error generating statement", e)
                                    pdfSource = null
                                    showPdfViewerScreen.value = false
                                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onShare = { customer, fy, customerBills ->
                            showShareBillDetailsPopup.value = false
                            lifecycleScope.launch {
                                try {
                                    Toast.makeText(context, "Generating statement PDF...", Toast.LENGTH_SHORT).show()
                                    val file = generateCustomerStatementPdf(context, customer, customerBills, fy)
                                    if (file != null) {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = "application/pdf"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Share Statement"))
                                    } else {
                                        Toast.makeText(context, "Failed to generate statement PDF", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Exception) {
                                    Log.e("MainActivity", "Error sharing statement", e)
                                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onViewBill = openBillPreview
                    )
                }

                if (showEntriesDateOptions) {
                    Dialog(onDismissRequest = { showEntriesDateOptions = false }) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surface
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Filter by Date", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 16.dp))
                                TextButton(onClick = { showEntriesDateOptions = false; showEntriesDatePicker = true }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Select Day", textAlign = androidx.compose.ui.text.style.TextAlign.Start, modifier = Modifier.fillMaxWidth())
                                }
                                TextButton(onClick = { showEntriesDateOptions = false; showEntriesMonthPicker = true }, modifier = Modifier.fillMaxWidth()) {
                                    Text("Select Month", textAlign = androidx.compose.ui.text.style.TextAlign.Start, modifier = Modifier.fillMaxWidth())
                                }
                                if (entriesDateFilter != null) {
                                    TextButton(onClick = { showEntriesDateOptions = false; entriesDateFilter = null }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Clear Filter", textAlign = androidx.compose.ui.text.style.TextAlign.Start, modifier = Modifier.fillMaxWidth(), color = Color.Red)
                                    }
                                }
                            }
                        }
                    }
                }

                if (showEntriesDatePicker) {
                    val datePickerState = rememberDatePickerState()
                    DatePickerDialog(
                        onDismissRequest = { showEntriesDatePicker = false },
                        confirmButton = {
                            TextButton(onClick = {
                                datePickerState.selectedDateMillis?.let {
                                    val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = it }
                                    val formatted = SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(cal.time)
                                    entriesDateFilter = formatted
                                }
                                showEntriesDatePicker = false
                            }) { Text("OK") }
                        }
                    ) {
                        DatePicker(state = datePickerState)
                    }
                }

                if (showEntriesMonthPicker) {
                    val monthsList = listOf("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")
                    var selectedMonth by remember { mutableStateOf(monthsList[Calendar.getInstance().get(Calendar.MONTH)]) }

                    Dialog(onDismissRequest = { showEntriesMonthPicker = false }) {
                        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surface) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Select Month", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(bottom = 8.dp))
                                Column(modifier = Modifier.fillMaxWidth().height(300.dp)) {
                                    LazyColumn {
                                        items(monthsList) { month ->
                                            Text(
                                                text = month,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clickable { selectedMonth = month }
                                                    .background(if (selectedMonth == month) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else Color.Transparent)
                                                    .padding(12.dp)
                                            )
                                        }
                                    }
                                }
                                Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.End) {
                                    TextButton(onClick = { showEntriesMonthPicker = false }) { Text("Cancel") }
                                    TextButton(onClick = {
                                        val sessionParts = selectedFinancialYear.split("-")
                                        val firstYearShort = sessionParts[0].toIntOrNull() ?: 0
                                        val secondYearShort = sessionParts[1].toIntOrNull() ?: 0
                                        
                                        val monthsMap = monthsList.indexOf(selectedMonth)
                                        val yearToUse = if (monthsMap >= 3) firstYearShort else secondYearShort
                                        
                                        entriesDateFilter = "$selectedMonth/${String.format("%02d", yearToUse)}"
                                        showEntriesMonthPicker = false
                                    }) { Text("OK") }
                                }
                            }
                        }
                    }
                }

                if (showPdfViewerScreen.value) {
                    PdfViewerScreen(
                        pdfSource = pdfSource!!,
                        title = pdfTitle,
                        onDismiss = {
                            showPdfViewerScreen.value = false
                            pdfSource = null
                            cleanPdfCache(context)
                            if (isQuotationMode.value) {
                                isQuotationMode.value = false
                                showCreateBillScreen.value = false
                                selectedCustomerForBill = null
                                showSettingsScreen.value = true
                            }
                        },
                        onShare = { file ->
                            val pdfUri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "application/pdf"
                                putExtra(Intent.EXTRA_STREAM, pdfUri)
                                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, if (isQuotationMode.value) "Share Quotation" else "Share Bill"))
                        }
                    )
                } else if (showFirmInformationScreen.value) {
                    FirmInformationScreen(onDismiss = { showFirmInformationScreen.value = false }, viewModel = firmInfoViewModel)
                } else if (showSettingsScreen.value) {
                    val currentFirmInfo = (firmInfoViewModel.uiState.collectAsState().value as? FirmInfoUiState.Success)?.firmInfo
                    SettingsScreen(
                        onDismiss = { showSettingsScreen.value = false },
                        onFirmInformationClick = { showFirmInformationScreen.value = true },
                        firmInfo = currentFirmInfo,
                        onLetterHeadClick = {
                            val state = firmInfoViewModel.uiState.value
                            if (state is FirmInfoUiState.Success) {
                                if (state.firmInfo.firmName.isBlank()) {
                                    Toast.makeText(context, "Please fill Firm Information first", Toast.LENGTH_SHORT).show()
                                } else {
                                    pdfSource = "syncing"
                                    pdfTitle = "Letter Head"
                                    showPdfViewerScreen.value = true
                                    
                                    scope.launch {
                                        val info = state.firmInfo
                                        val logo = if (info.firmLogoUrl.isNotBlank()) downloadImage(info.firmLogoUrl) else null
                                        val file = generateLetterHeadPdf(context, info, logo)
                                        
                                        if (file != null) {
                                            pdfSource = file
                                        } else {
                                            pdfSource = null
                                            showPdfViewerScreen.value = false
                                            Toast.makeText(context, "Failed to generate Letter Head", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Firm Information not loaded", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onExportHsnSummaryClick = { showExportHsnPopup.value = true },
                        onBillsToBeCreatedClick = {
                            showPendingBillPopup.value = true
                        },
                        onShareBillDetailsClick = {
                            showShareBillDetailsPopup.value = true
                        },
                        onCreateQuotationClick = {
                            showSettingsScreen.value = false
                            isQuotationMode.value = true
                            selectedCustomerForBill = null
                            showCreateBillScreen.value = true
                        }
                    )
                } else if (showCreateBillScreen.value) {
                    val sdf = remember { SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH) }
                    val currentSession = getFinancialYear(Date())
                    
                    val initialData = remember(billEntries.size, currentSession) {
                        val sessionBills = billEntries.filter { 
                            try {
                                val d = tryParseDate(it.date)
                                d != null && getFinancialYear(d) == currentSession
                            } catch (_: Exception) { false }
                        }.sortedByDescending { 
                            try { tryParseDate(it.date) } catch (_: Exception) { null }
                        }
                        
                        val lastBill = sessionBills.firstOrNull()
                        val today = Date()
                        
                        val dateToUse = if (lastBill != null) {
                            try {
                                val lastDate = tryParseDate(lastBill.date)
                                if (lastDate != null && lastDate.after(today)) {
                                    lastBill.date
                                } else {
                                    sdf.format(today)
                                }
                            } catch (_: Exception) {
                                sdf.format(today)
                            }
                        } else {
                            sdf.format(today)
                        }
                        
                        val lastNo = sessionBills.mapNotNull { it.billNo.split("/").lastOrNull()?.toIntOrNull() }.maxOrNull() ?: 0
                        val nextNo = lastNo + 1
                        val billNoToUse = "SS/$currentSession/${"%04d".format(nextNo)}"
                        
                        Pair(dateToUse, billNoToUse)
                    }
                    
                    val initialDate = initialData.first
                    val nextBillNo = initialData.second

                    if (initialDate != sdf.format(Date())) {
                        LaunchedEffect(Unit) {
                            Toast.makeText(context, "Future date is selected, Please check the Bills", Toast.LENGTH_LONG).show()
                        }
                    }

                    CreateBillScreen(
                        onDismiss = { 
                            if (isQuotationMode.value) {
                                showCreateBillScreen.value = false
                                isQuotationMode.value = false
                                selectedCustomerForBill = null
                                showSettingsScreen.value = true
                            } else {
                                showCreateBillScreen.value = false
                                selectedCustomerForBill = null
                            }
                        },
                        onCancel = {
                            if (isQuotationMode.value) {
                                showCreateBillScreen.value = false
                                isQuotationMode.value = false
                                selectedCustomerForBill = null
                                showSettingsScreen.value = true
                            } else {
                                scope.launch {
                                    lockRef.removeValue()
                                    showCreateBillScreen.value = false
                                    selectedCustomerForBill = null
                                }
                            }
                        },
                        onPreviewPdf = { file ->
                            pdfSource = file
                            pdfTitle = if (isQuotationMode.value) "Quotation Preview" else "Bill Preview"
                            showPdfViewerScreen.value = true
                        },
                        customers = customers.value,
                        items = items.value,
                        onEditCustomer = { customer ->
                            customerToEdit = customer
                            showAddCustomerPopup.value = true
                        },
                        firmInfoViewModel = firmInfoViewModel,
                        onBillSaved = { updatedBillEntry ->
                            if (!isQuotationMode.value) {
                                val finalEntry = if (updatedBillEntry.sn != 0) {
                                    updatedBillEntry
                                } else {
                                    val existing = billEntries.find { 
                                        it.billNo == updatedBillEntry.billNo && 
                                        it.customerName == updatedBillEntry.customerName 
                                    }
                                    
                                    if (existing != null) {
                                        updatedBillEntry.copy(sn = existing.sn)
                                    } else {
                                        val maxSn = billEntries.maxOfOrNull { it.sn } ?: 0
                                        updatedBillEntry.copy(sn = maxSn + 1)
                                    }
                                }
                                
                                billEntriesRef.child(finalEntry.sn.toString()).setValue(finalEntry)
                                scope.launch {
                                    pagerState.animateScrollToPage(1)
                                }
                            }
                        },
                        editingBill = editingBill,
                        initialBillNo = nextBillNo,
                        initialDate = initialDate,
                        isOnline = isOnline,
                        deviceId = deviceId,
                        billEntries = billEntries,
                        externalScope = lifecycleScope,
                        pendingBills = pendingBills.value,
                        onUpdatePendingBill = { pendingBillsRef.child(it.id).setValue(it) },
                        onDeletePendingBill = { pendingBillsRef.child(it.id).removeValue() },
                        selectedCustomer = selectedCustomerForBill,
                        onCustomerSelected = { selectedCustomerForBill = it },
                        uomViewModel = uomViewModel,
                        onAddNewItem = { newItem ->
                            val currentList = items.value.toMutableList()
                            val index = currentList.indexOfFirst { 
                                (it.id.isNotBlank() && it.id == newItem.id) || it.name.equals(newItem.name, ignoreCase = true)
                            }
                            if (index != -1) {
                                currentList[index] = newItem
                            } else {
                                currentList.add(newItem)
                            }
                            itemsRef.setValue(currentList)
                        },
                        isQuotation = isQuotationMode.value
                    )
                } else {
                    val pullRefreshState = rememberPullRefreshState(
                        refreshing = isRefreshing,
                        onRefresh = {
                            when (pagerState.currentPage) {
                                0 -> customerSearchQuery = ""
                                1 -> { entriesSearchQuery = ""; entriesDateFilter = null }
                                2 -> itemSearchQuery = ""
                            }
                        }
                    )

                    Scaffold(
                        topBar = {
                            if (itemSelectionMode) {
                                SelectionAppBar(
                                    selectedItemCount = selectedItems.size,
                                    onSelectAll = {
                                        selectedItems = if (selectedItems.size == filteredItems.size) {
                                            emptySet()
                                        } else {
                                            filteredItems.indices.toSet()
                                        }
                                    },
                                    onDelete = {
                                        val itemsToDelete = selectedItems.map { filteredItems[it] }.toSet()
                                        val remainingItems = items.value.filter { it !in itemsToDelete }
                                        itemsRef.setValue(remainingItems)
                                        itemSelectionMode = false
                                        selectedItems = emptySet()
                                    },
                                    onCancel = {
                                        itemSelectionMode = false
                                        selectedItems = emptySet()
                                    },
                                    allSelected = selectedItems.size == filteredItems.size
                                )
                            } else if (customerSelectionMode) {
                                SelectionAppBar(
                                    selectedItemCount = selectedCustomers.size,
                                    onSelectAll = {
                                        selectedCustomers = if (selectedCustomers.size == filteredCustomers.size) {
                                            emptySet()
                                        } else {
                                            filteredCustomers.indices.toSet()
                                        }
                                    },
                                    onDelete = {
                                        val customersToDelete = selectedCustomers.map { filteredCustomers[it] }.toSet()
                                        val remainingCustomers = customers.value.filter { it !in customersToDelete }
                                        customersRef.setValue(remainingCustomers)
                                        customerSelectionMode = false
                                        selectedCustomers = emptySet()
                                    },
                                    onCancel = {
                                        customerSelectionMode = false
                                        selectedCustomers = emptySet()
                                    },
                                    allSelected = selectedCustomers.size == filteredCustomers.size
                                )
                            } else {
                                Column(modifier = Modifier.background(MaterialTheme.colorScheme.primary)) {
                                    TopAppBar(
                                        colors = TopAppBarDefaults.topAppBarColors(
                                            containerColor = Color.Transparent,
                                            titleContentColor = MaterialTheme.colorScheme.onPrimary,
                                            actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                                        ),
                                        title = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                val firmInfo = (uiState as? FirmInfoUiState.Success)?.firmInfo
                                                Text(if (pagerState.currentPage == 1) (firmInfo?.firmName?.ifBlank { "Shah Stores" } ?: "Shah Stores") else navItems[pagerState.currentPage].first)
                                                if (pagerState.currentPage == 1 && !isOnline) {
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Surface(
                                                        color = Color.Blue,
                                                        shape = RoundedCornerShape(4.dp)
                                                    ) {
                                                        Text(
                                                            text = "OFFLINE",
                                                            color = Color.White,
                                                            fontSize = 10.sp,
                                                            fontWeight = FontWeight.Bold,
                                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                        )
                                                    }
                                                }
                                            }
                                        },
                                        actions = {
                                            when(pagerState.currentPage) {
                                                 1 -> {
                                                    IconButton(onClick = { showSettingsScreen.value = true }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Settings,
                                                            contentDescription = "Settings"
                                                        )
                                                    }
                                                }
                                                0 -> {
                                                    IconButton(onClick = { customerLauncher.launch("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Upload,
                                                            contentDescription = "Upload"
                                                        )
                                                    }
                                                }
                                                2 -> {
                                                    IconButton(onClick = { itemLauncher.launch("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") }) {
                                                        Icon(
                                                            imageVector = Icons.Default.Upload,
                                                            contentDescription = "Upload"
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    )
                                    
                                    if (pagerState.currentPage == 1) {
                                        Surface(
                                            modifier = Modifier
                                                .padding(horizontal = 16.dp, vertical = 4.dp)
                                                .fillMaxWidth(),
                                            color = Color.White,
                                            shape = RoundedCornerShape(8.dp),
                                            shadowElevation = 2.dp
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(text = "Total Sales", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = DefaultTextColor)
                                                Text(text = "₹ ${formatIndianCurrency(totalSales)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = TotalSalesGreen)
                                            }

                                        }
                                    }

                                    when (pagerState.currentPage) {
                                        0 -> SearchBar(
                                            searchQuery = customerSearchQuery,
                                            onSearchQueryChange = { customerSearchQuery = it },
                                            placeholder = "Search Customers",
                                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                                        )
                                        1 -> SearchBar(
                                            searchQuery = entriesSearchQuery,
                                            onSearchQueryChange = { entriesSearchQuery = it },
                                            placeholder = "Search Entries",
                                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp),
                                            trailingIcon = {
                                                IconButton(onClick = { showEntriesDateOptions = true }) {
                                                    Icon(imageVector = Icons.Default.Event, contentDescription = "Date Filter", tint = if (entriesDateFilter != null) MaterialTheme.colorScheme.primary else Color.Gray)
                                                }
                                            }
                                        )
                                        2 -> SearchBar(
                                            searchQuery = itemSearchQuery,
                                            onSearchQueryChange = { itemSearchQuery = it },
                                            placeholder = "Search Items",
                                            modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 8.dp)
                                        )
                                    }
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .padding(innerPadding)
                                .fillMaxSize()
                                .pullRefresh(pullRefreshState)
                        ) {
                            HorizontalPager(
                                state = pagerState,
                                userScrollEnabled = false,
                                modifier = Modifier.fillMaxSize()
                            ) { page ->
                                when (page) {
                                    0 -> CustomersScreen(
                                        customers = filteredCustomers,
                                        onCustomerClick = { index ->
                                            customerToEdit = filteredCustomers[index]
                                            showAddCustomerPopup.value = true
                                        },
                                        selectionMode = customerSelectionMode,
                                        selectedCustomers = selectedCustomers,
                                        onCustomerLongClick = { index ->
                                            customerSelectionMode = true
                                            selectedCustomers = selectedCustomers + index
                                        },
                                        onCustomerSelected = { index ->
                                            selectedCustomers = if (selectedCustomers.contains(index)) {
                                                selectedCustomers - index
                                            } else {
                                                selectedCustomers + index
                                            }
                                            if (selectedCustomers.isEmpty()) {
                                                customerSelectionMode = false
                                            }
                                        }
                                    )
                                    1 -> EntriesScreen(
                                        billEntries = filteredBillEntries,
                                        onEditBill = { billEntry ->
                                            if (!isOnline) {
                                                Toast.makeText(context, "Connect to Internet first", Toast.LENGTH_SHORT).show()
                                            } else {
                                                editingBill = billEntry
                                                selectedCustomerForBill = billEntry.customer
                                                showCreateBillScreen.value = true
                                                
                                                val now = System.currentTimeMillis()
                                                lockRef.setValue(mapOf("deviceId" to deviceId, "timestamp" to now))
                                            }
                                        },
                                        onDeleteBill = { billEntry ->
                                            billEntriesRef.child(billEntry.id.ifBlank { billEntry.sn.toString() }).removeValue()
                                        },
                                        onViewBill = openBillPreview,
                                        onRetrySync = { billEntry ->
                                            val billId = billEntry.id.ifBlank { billEntry.sn.toString() }
                                            billEntriesRef.child(billId).child("pdfUrl").setValue(null)
                                            Toast.makeText(context, "Sync cleared", Toast.LENGTH_SHORT).show()
                                        },
                                        onTimeout = { billEntry ->
                                            val billId = billEntry.id.ifBlank { billEntry.sn.toString() }
                                            billEntriesRef.child(billId).child("pdfUrl").setValue("error")
                                        },
                                        highlightedBillNo = highlightedBillNo,
                                        onHighlightCleared = { highlightedBillNo = null }
                                    )
                                    2 -> ItemsScreen(
                                        items = filteredItems,
                                        onItemClick = { index ->
                                            itemToEdit = filteredItems[index]
                                            showAddItemPopup.value = true
                                        },
                                        selectionMode = itemSelectionMode,
                                        selectedItems = selectedItems,
                                        onItemLongClick = { index ->
                                            itemSelectionMode = true
                                            selectedItems = selectedItems + index
                                        },
                                        onItemSelected = { index ->
                                            selectedItems = if (selectedItems.contains(index)) {
                                                selectedItems - index
                                            } else {
                                                selectedItems + index
                                            }
                                            if (selectedItems.isEmpty()) {
                                                itemSelectionMode = false
                                            }
                                        }
                                    )
                                }
                            }

                            PullRefreshIndicator(
                                refreshing = isRefreshing,
                                state = pullRefreshState,
                                modifier = Modifier.align(Alignment.TopCenter)
                            )

                            Box(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 16.dp)
                                    .fillMaxWidth()
                                    .height(38.dp)
                            ) {
                                Surface(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .height(38.dp),
                                    shape = RoundedCornerShape(50.dp),
                                    shadowElevation = 8.dp,
                                    color = Color.White
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxHeight(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        navItems.forEachIndexed { index, item ->
                                            if (index == 1) {
                                                Box {
                                                    Box(
                                                        modifier = Modifier
                                                            .padding(horizontal = 24.dp)
                                                            .fillMaxHeight()
                                                            .combinedClickable(
                                                                onClick = { scope.launch { pagerState.animateScrollToPage(index) } },
                                                                onLongClick = { showFinancialYearDropdown = true }
                                                            ),
                                                        contentAlignment = Alignment.Center
                                                    ) {
                                                        Icon(
                                                            imageVector = item.second,
                                                            contentDescription = item.first,
                                                            tint = if (pagerState.currentPage == index) MaterialTheme.colorScheme.primary else InactiveNavIconColor
                                                        )
                                                    }
                                                    DropdownMenu(
                                                        expanded = showFinancialYearDropdown,
                                                        onDismissRequest = { showFinancialYearDropdown = false }
                                                    ) {
                                                        financialYears.forEach { year ->
                                                            DropdownMenuItem(text = { Text(year) }, onClick = {
                                                                selectedFinancialYear = year
                                                                showFinancialYearDropdown = false
                                                             })
                                                        }
                                                    }
                                                }
                                            } else {
                                                Box(
                                                    modifier = Modifier
                                                        .padding(horizontal = 24.dp)
                                                        .fillMaxHeight()
                                                        .clickable { scope.launch { pagerState.animateScrollToPage(index) } },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(
                                                        imageVector = item.second,
                                                        contentDescription = item.first,
                                                        tint = if (pagerState.currentPage == index) MaterialTheme.colorScheme.primary else InactiveNavIconColor
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                if (!itemSelectionMode && !customerSelectionMode) {
                                    val isFabEnabled = when (pagerState.currentPage) {
                                        1 -> isOnline && isBillEntriesLoaded && !isLocking
                                        else -> true
                                    }
                                    
                                    FloatingActionButton(
                                        onClick = {
                                            if (!isFabEnabled && pagerState.currentPage == 1) {
                                                if (!isOnline) {
                                                    Toast.makeText(context, "Waiting for internet connection...", Toast.LENGTH_SHORT).show()
                                                } else if (!isBillEntriesLoaded) {
                                                    Toast.makeText(context, "Loading bills, please wait...", Toast.LENGTH_SHORT).show()
                                                }
                                                return@FloatingActionButton
                                            }
                                            when (pagerState.currentPage) {
                                                0 -> {
                                                    customerToEdit = null
                                                    showAddCustomerPopup.value = true
                                                }
                                                1 -> {
                                                    val result = validateBillEntries(billEntries)
                                                    if (result.isEmpty()) {
                                                        isLocking = true
                                                        lockRef.runTransaction(object : Transaction.Handler {
                                                            override fun doTransaction(currentData: MutableData): Transaction.Result {
                                                                val lock = currentData.getValue(object : com.google.firebase.database.GenericTypeIndicator<Map<String, Any>>() {})
                                                                val now = System.currentTimeMillis()
                                                                
                                                                if (lock != null) {
                                                                    val lockDeviceId = lock["deviceId"] as? String
                                                                    val timestamp = (lock["timestamp"] as? Number)?.toLong() ?: 0L
                                                                    
                                                                    if (lockDeviceId != deviceId && now - timestamp < 600000) {
                                                                        return Transaction.abort()
                                                                    }
                                                                }
                                                                
                                                                currentData.value = mapOf("deviceId" to deviceId, "timestamp" to now)
                                                                return Transaction.success(currentData)
                                                            }

                                                            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                                                                isLocking = false
                                                                if (committed) {
                                                                    editingBill = null
                                                                    selectedCustomerForBill = null
                                                                    showCreateBillScreen.value = true
                                                                } else {
                                                                    Toast.makeText(context, "Another user is currently creating a bill", Toast.LENGTH_SHORT).show()
                                                                }
                                                            }
                                                        })
                                                    } else {
                                                        validationResult = result
                                                    }
                                                }
                                                2 -> {
                                                    itemToEdit = null
                                                    showAddItemPopup.value = true
                                                }
                                            }
                                        },
                                        modifier = Modifier
                                            .align(Alignment.CenterEnd)
                                            .padding(end = 16.dp)
                                            .size(38.dp),
                                        shape = CircleShape,
                                        containerColor = if (isFabEnabled) GoldAccent else InactiveNavIconColor
                                    ) {
                                        if (isLocking) {
                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = ChocolatePrimaryDark, strokeWidth = 2.dp)
                                        } else {
                                            Icon(Icons.Filled.Add, contentDescription = "Add", tint = ChocolatePrimaryDark)
                                        }
                                    }

                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBar(
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    trailingIcon: @Composable (() -> Unit)? = null
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp),
        color = Color.White,
        shape = RoundedCornerShape(8.dp),
        shadowElevation = 4.dp
    ) {
        BasicTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier.fillMaxSize(),
            singleLine = true,
            textStyle = TextStyle(fontSize = 16.sp),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            decorationBox = { innerTextField ->
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = "Search Icon",
                        tint = Color.Gray
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(modifier = Modifier.weight(1f)) {
                        if (searchQuery.isEmpty()) {
                            Text(placeholder, color = Color.Gray)
                        }
                        innerTextField()
                    }
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Clear Search",
                                tint = Color.Gray
                            )
                        }
                    }
                    if (trailingIcon != null) {
                        trailingIcon()
                    }
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SelectionAppBar(
    selectedItemCount: Int,
    onSelectAll: () -> Unit,
    onDelete: () -> Unit,
    onCancel: () -> Unit,
    allSelected: Boolean
) {
    TopAppBar(
        title = { Text(text = "$selectedItemCount selected") },
        navigationIcon = {
            IconButton(onClick = onCancel) {
                Icon(Icons.Default.Close, contentDescription = "Cancel Selection")
            }
        },
        actions = {
            Checkbox(checked = allSelected, onCheckedChange = { onSelectAll() })
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Selected Items")
            }
        }
    )
}
