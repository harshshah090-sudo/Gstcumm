package com.example.shahstores.data

import android.net.Uri
import com.example.shahstores.model.FirmInfo
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirmInfoRepository {
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()

    private val firmInfoCollection = db.collection("firmInfo")

    fun getFirmInfo(): Flow<FirmInfo?> = flow {
        val snapshot = firmInfoCollection.limit(1).get().await()
        emit(snapshot.documents.firstOrNull()?.toObject(FirmInfo::class.java))
    }

    suspend fun saveFirmInfo(firmInfo: FirmInfo, logoUri: Uri?, signatureUri: Uri?, qrCodeUri: Uri?): FirmInfo {
        val logoUrl = logoUri?.let { uploadImage(it, "firm_logo") }
        val signatureUrl = signatureUri?.let { uploadImage(it, "owner_signature") }
        val qrCodeUrl = qrCodeUri?.let { uploadImage(it, "qr_code") }

        val updatedFirmInfo = firmInfo.copy(
            firmLogoUrl = logoUrl ?: firmInfo.firmLogoUrl,
            signatureUrl = signatureUrl ?: firmInfo.signatureUrl,
            qrCodeUrl = qrCodeUrl ?: firmInfo.qrCodeUrl
        )

        if (updatedFirmInfo.id.isBlank()) {
            firmInfoCollection.add(updatedFirmInfo).await()
        } else {
            firmInfoCollection.document(updatedFirmInfo.id).set(updatedFirmInfo).await()
        }
        return updatedFirmInfo
    }

    private suspend fun uploadImage(uri: Uri, path: String): String {
        val storageRef = storage.reference.child("$path/${UUID.randomUUID()}")
        storageRef.putFile(uri).await()
        return storageRef.downloadUrl.await().toString()
    }
}
