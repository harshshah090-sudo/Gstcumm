package com.example.shahstores.data

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.shahstores.model.FirmInfo
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class FirmInfoRepository {
    private val databaseUrl = "https://gen-lang-client-0387562267-default-rtdb.firebaseio.com"
    private val rtdb = Firebase.database(databaseUrl).getReference("firmInfo")
    private val firestore = try { FirebaseFirestore.getInstance() } catch (e: Exception) { null }
    private val storage = try { FirebaseStorage.getInstance() } catch (e: Exception) { null }

    fun getFirmInfo(): Flow<FirmInfo?> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val info = snapshot.getValue(FirmInfo::class.java)
                if (info != null) {
                    trySend(info)
                } else {
                    // Fallback to Firestore if RTDB doesn't have it yet
                    firestore?.collection("firmInfo")?.limit(1)?.get()?.addOnSuccessListener { fsSnapshot ->
                        val fsInfo = fsSnapshot.documents.firstOrNull()?.toObject(FirmInfo::class.java)
                        trySend(fsInfo)
                    }?.addOnFailureListener {
                        trySend(null)
                    } ?: trySend(null)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirmInfoRepo", "RTDB cancelled: ${error.message}")
                firestore?.collection("firmInfo")?.limit(1)?.get()?.addOnSuccessListener { fsSnapshot ->
                    val fsInfo = fsSnapshot.documents.firstOrNull()?.toObject(FirmInfo::class.java)
                    trySend(fsInfo)
                }?.addOnFailureListener {
                    trySend(null)
                } ?: trySend(null)
            }
        }

        rtdb.addValueEventListener(listener)
        awaitClose { rtdb.removeEventListener(listener) }
    }

    suspend fun saveFirmInfo(context: Context?, firmInfo: FirmInfo, logoUri: Uri?, signatureUri: Uri?, qrCodeUri: Uri?): FirmInfo {
        var logoUrl = firmInfo.firmLogoUrl
        var signatureUrl = firmInfo.signatureUrl
        var qrCodeUrl = firmInfo.qrCodeUrl

        logoUri?.let { uri ->
            context?.let { ctx -> encodeUriToBase64(ctx, uri, 300)?.let { logoUrl = it } }
        }
        signatureUri?.let { uri ->
            context?.let { ctx -> encodeUriToBase64(ctx, uri, 300)?.let { signatureUrl = it } }
        }
        qrCodeUri?.let { uri ->
            context?.let { ctx -> encodeUriToBase64(ctx, uri, 300)?.let { qrCodeUrl = it } }
        }

        val updatedFirmInfo = firmInfo.copy(
            id = firmInfo.id.ifBlank { "default_firm" },
            firmLogoUrl = logoUrl,
            signatureUrl = signatureUrl,
            qrCodeUrl = qrCodeUrl
        )

        // Save to Realtime Database (with timeout guard)
        try {
            kotlinx.coroutines.withTimeout(5000) {
                rtdb.setValue(updatedFirmInfo).await()
            }
        } catch (e: Exception) {
            Log.w("FirmInfoRepo", "RTDB await timed out or offline, writing non-blocking: ${e.message}")
            rtdb.setValue(updatedFirmInfo) // will queue offline or send in background
        }

        // Also sync to Firestore for backup non-blocking
        try {
            firestore?.collection("firmInfo")?.document(updatedFirmInfo.id)?.set(updatedFirmInfo)
        } catch (e: Exception) {
            Log.w("FirmInfoRepo", "Firestore backup save skipped: ${e.message}")
        }

        return updatedFirmInfo
    }

    private fun encodeUriToBase64(context: Context, uri: Uri, maxDimension: Int): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri)
            val originalBitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
            inputStream?.close()
            if (originalBitmap == null) return null

            val width = originalBitmap.width
            val height = originalBitmap.height
            val scale = if (width > maxDimension || height > maxDimension) {
                val ratio = width.toFloat() / height.toFloat()
                if (ratio > 1) {
                    android.graphics.Bitmap.createScaledBitmap(originalBitmap, maxDimension, (maxDimension / ratio).toInt(), true)
                } else {
                    android.graphics.Bitmap.createScaledBitmap(originalBitmap, (maxDimension * ratio).toInt(), maxDimension, true)
                }
            } else {
                originalBitmap
            }

            val baos = java.io.ByteArrayOutputStream()
            scale.compress(android.graphics.Bitmap.CompressFormat.PNG, 85, baos)
            val bytes = baos.toByteArray()
            val base64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
            "data:image/png;base64,$base64"
        } catch (e: Exception) {
            Log.e("FirmInfoRepo", "Error encoding image to base64", e)
            null
        }
    }

    private suspend fun uploadImage(uri: Uri, path: String): String {
        val st = storage ?: throw IllegalStateException("Storage not initialized")
        val storageRef = st.reference.child("$path/${UUID.randomUUID()}")
        storageRef.putFile(uri).await()
        return storageRef.downloadUrl.await().toString()
    }
}
