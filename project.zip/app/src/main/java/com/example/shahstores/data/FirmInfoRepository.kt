package com.example.shahstores.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.shahstores.model.FirmInfo
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

class FirmInfoRepository {
    private val db = FirebaseFirestore.getInstance()
    private val firmInfoCollection = db.collection("firmInfo")

    fun getFirmInfo(): Flow<FirmInfo?> = flow {
        val snapshot = firmInfoCollection.limit(1).get().await()
        emit(snapshot.documents.firstOrNull()?.toObject(FirmInfo::class.java))
    }

    suspend fun saveFirmInfo(context: Context, firmInfo: FirmInfo, logoUri: Uri?, signatureUri: Uri?, qrCodeUri: Uri?): FirmInfo {
        val logoUrl = logoUri?.let { convertUriToBase64(context, it) }
        val signatureUrl = signatureUri?.let { convertUriToBase64(context, it) }
        val qrCodeUrl = qrCodeUri?.let { convertUriToBase64(context, it) }

        val updatedFirmInfo = firmInfo.copy(
            firmLogoUrl = logoUrl ?: firmInfo.firmLogoUrl,
            signatureUrl = signatureUrl ?: firmInfo.signatureUrl,
            qrCodeUrl = qrCodeUrl ?: firmInfo.qrCodeUrl
        )

        if (updatedFirmInfo.id.isBlank()) {
            firmInfoCollection.add(updatedFirmInfo).await()
        } else {
            firmInfoCollection.document(updatedFirmInfo.id).set(updatedFirmInfo).await()
        }
        return updatedFirmInfo
    }

    private suspend fun convertUriToBase64(context: Context, uri: Uri, maxWidth: Int = 800, maxHeight: Int = 800): String? {
        return withContext(Dispatchers.IO) {
            try {
                val inputStream = context.contentResolver.openInputStream(uri) ?: return@withContext null
                val originalBitmap = BitmapFactory.decodeStream(inputStream)
                inputStream.close()
                if (originalBitmap == null) return@withContext null

                val width = originalBitmap.width
                val height = originalBitmap.height
                val scale = minOf(maxWidth.toFloat() / width, maxHeight.toFloat() / height, 1.0f)
                val targetWidth = (width * scale).toInt().coerceAtLeast(1)
                val targetHeight = (height * scale).toInt().coerceAtLeast(1)

                val scaledBitmap = if (scale < 1.0f) {
                    Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
                } else {
                    originalBitmap
                }

                val outputStream = ByteArrayOutputStream()
                scaledBitmap.compress(Bitmap.CompressFormat.PNG, 90, outputStream)
                val bytes = outputStream.toByteArray()
                Base64.encodeToString(bytes, Base64.NO_WRAP)
            } catch (e: Exception) {
                Log.e("FirmInfoRepository", "Error converting image to Base64", e)
                null
            }
        }
    }
}
