package com.example.shahstores.model

data class BillItem(
    val qty: String,
    val rate: String,
    val isSelected: Boolean,
    val variantSelections: Map<String, String> = emptyMap()
)
