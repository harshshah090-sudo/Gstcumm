package com.example.shahstores.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfViewerScreen(
    pdfSource: Any?,
    title: String = "Bill Preview",
    onDismiss: () -> Unit,
    onShare: (File) -> Unit
) {
    val context = LocalContext.current
    var isLoading by remember { mutableStateOf(true) }
    var pdfFile by remember { mutableStateOf<File?>(null) }
    val pages = remember { mutableStateListOf<Bitmap>() }

    LaunchedEffect(pdfSource) {
        if (pdfSource == null) {
            isLoading = false
            return@LaunchedEffect
        }

        // If explicitly syncing/generating, keep loading state and wait for next update
        if (pdfSource == "syncing") {
            isLoading = true
            return@LaunchedEffect
        }
        
        isLoading = true
        pages.clear()
        
        val targetFile = withContext(Dispatchers.IO) {
            when (pdfSource) {
                is File -> pdfSource
                is String -> {
                    if (pdfSource.isBlank() || pdfSource == "syncing" || pdfSource == "error") return@withContext null
                    
                    val hashCode = pdfSource.hashCode()
                    val hashCodeStr = if (hashCode < 0) "n${-hashCode}" else hashCode.toString()
                    val fileName = "bill_$hashCodeStr.pdf"
                    val file = File(context.cacheDir, fileName)
                    
                    if (file.exists() && file.length() > 0) {
                        return@withContext file
                    }

                    try {
                        val connection = URL(pdfSource).openConnection() as HttpURLConnection
                        connection.connectTimeout = 30000
                        connection.readTimeout = 30000
                        connection.instanceFollowRedirects = true
                        connection.setRequestProperty("User-Agent", "Mozilla/5.0")
                        
                        val responseCode = connection.responseCode
                        if (responseCode == HttpURLConnection.HTTP_OK) {
                            connection.inputStream.use { input ->
                                FileOutputStream(file).use { output ->
                                    input.copyTo(output)
                                }
                            }
                            if (file.exists() && file.length() > 0) file else null
                        } else {
                            Log.e("PdfViewer", "Download failed code: $responseCode")
                            null
                        }
                    } catch (e: Exception) {
                        Log.e("PdfViewer", "Download error", e)
                        if (file.exists()) file.delete()
                        null
                    }
                }
                else -> null
            }
        }

        pdfFile = targetFile

        targetFile?.let { file ->
            try {
                withContext(Dispatchers.IO) {
                    val fileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    val renderer = PdfRenderer(fileDescriptor)
                    for (i in 0 until renderer.pageCount) {
                        val page = renderer.openPage(i)
                        val bitmap = Bitmap.createBitmap(page.width * 3, page.height * 3, Bitmap.Config.ARGB_8888)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        withContext(Dispatchers.Main) {
                            pages.add(bitmap)
                        }
                        page.close()
                    }
                    renderer.close()
                    fileDescriptor.close()
                }
            } catch (e: Exception) {
                Log.e("PdfViewer", "Render error", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error reading PDF: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        isLoading = false
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    pdfFile?.let { file ->
                        IconButton(onClick = { onShare(file) }) {
                            Icon(Icons.Default.Share, contentDescription = "Share")
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = MaterialTheme.colorScheme.onPrimary,
                    navigationIconContentColor = MaterialTheme.colorScheme.onPrimary,
                    actionIconContentColor = MaterialTheme.colorScheme.onPrimary
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
            .background(Color(0xFF525659))
        ) {
            if (isLoading) {
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Color.White)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Opening...", color = Color.White)
                }
            } else if (pages.isEmpty()) {
                Text("Unable to load PDF", modifier = Modifier.align(Alignment.Center), color = Color.White)
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(top = 16.dp, bottom = 120.dp)
                ) {
                    items(pages) { page ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth(0.92f)
                                .shadow(8.dp, RoundedCornerShape(2.dp)),
                            color = Color.White,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Image(
                                bitmap = page.asImageBitmap(),
                                contentDescription = "PDF Page",
                                modifier = Modifier.fillMaxWidth(),
                                contentScale = ContentScale.FillWidth
                            )
                        }
                    }
                }
            }

            // Bottom Navigation Pill Bar
            if (!isLoading && pdfFile != null) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 32.dp)
                        .height(50.dp)
                        .width(160.dp)
                        .shadow(12.dp, RoundedCornerShape(25.dp)),
                    shape = RoundedCornerShape(25.dp),
                    color = Color.White
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Print 1x
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { printPdf(context, pdfFile!!, 1) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = "Print 1x",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = " 1x",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        // Vertical Divider
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(24.dp)
                                .background(Color.LightGray.copy(alpha = 0.5f))
                        )

                        // Print 2x
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                                .clickable { printPdf(context, pdfFile!!, 2) },
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Print,
                                    contentDescription = "Print 2x",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = " 2x",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun printPdf(context: Context, file: File, copies: Int) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    val jobName = "ShahStores_${file.nameWithoutExtension}"
    
    // For 2 copies, we create a temporary PDF with duplicated pages to automate the process
    val targetFile = if (copies == 2) {
        try {
            val destFile = File(context.cacheDir, "print_temp_2x.pdf")
            val srcDoc = PdfDocument(PdfReader(file))
            val destDoc = PdfDocument(PdfWriter(destFile))
            for (i in 1..srcDoc.numberOfPages) {
                srcDoc.copyPagesTo(i, i, destDoc)
                srcDoc.copyPagesTo(i, i, destDoc)
            }
            srcDoc.close()
            destDoc.close()
            destFile
        } catch (e: Exception) {
            Log.e("PdfViewer", "Error duplicating pages", e)
            file
        }
    } else {
        file
    }

    printManager.print(jobName, object : PrintDocumentAdapter() {
        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback?,
            extras: Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onLayoutCancelled()
                return
            }
            
            val info = PrintDocumentInfo.Builder(targetFile.name)
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                .build()
            
            callback?.onLayoutFinished(info, true)
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback?
        ) {
            try {
                FileInputStream(targetFile).use { input ->
                    FileOutputStream(destination?.fileDescriptor).use { output ->
                        input.copyTo(output)
                    }
                }
                callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback?.onWriteFailed(e.message)
            }
        }
    }, null)
}
