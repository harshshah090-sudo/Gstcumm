package com.example.shahstores.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.shahstores.model.BillEntry
import com.example.shahstores.model.Customer
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class HsnSummaryRow(
    val hsnCode: String,
    val uom: String,
    var totalQty: Double = 0.0,
    var taxableValue: Double = 0.0,
    val rate: String,
    var cgst: Double = 0.0,
    var sgst: Double = 0.0,
    var igst: Double = 0.0,
    var totalValue: Double = 0.0
)

fun exportHsnSummaryToExcel(
    context: Context,
    billEntries: List<BillEntry>,
    startDateMillis: Long,
    endDateMillis: Long
) {
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = endDateMillis
    calendar.set(Calendar.HOUR_OF_DAY, 23)
    calendar.set(Calendar.MINUTE, 59)
    calendar.set(Calendar.SECOND, 59)
    calendar.set(Calendar.MILLISECOND, 999)
    val adjustedEndMillis = calendar.timeInMillis

    val filteredBills = billEntries.filter { entry ->
        val sType = if (entry.schemeType.isBlank()) "Regular GST" else entry.schemeType
        if (!sType.equals("Regular GST", ignoreCase = true)) return@filter false
        try {
            val date = tryParseDate(entry.date)
            date != null && date.time in startDateMillis..adjustedEndMillis
        } catch (e: Exception) {
            false
        }
    }

    if (filteredBills.isEmpty()) {
        Toast.makeText(context, "No Regular GST bills found in selected date range", Toast.LENGTH_SHORT).show()
        return
    }

    val workbook = XSSFWorkbook()
    val sheet = workbook.createSheet("HSN Summary")

    val gstSummary = mutableMapOf<String, HsnSummaryRow>()
    val urdSummary = mutableMapOf<String, HsnSummaryRow>()

    filteredBills.forEach { bill ->
        val isGstCustomer = bill.customer?.registrationType == "GSTIN"
        val targetMap = if (isGstCustomer) gstSummary else urdSummary
        val isSameState = bill.customer?.state?.equals("Madhya Pradesh", ignoreCase = true) ?: true

        bill.items.forEach { billItem ->
            val hsn = billItem.item.hsnCode
            val uom = billItem.item.uom
            val rate = billItem.item.gstRate
            val key = "$hsn-$uom-$rate"
            
            val row = targetMap.getOrPut(key) { HsnSummaryRow(hsnCode = hsn, uom = uom, rate = rate) }
            
            val qty = billItem.quantity.toDoubleOrNull() ?: 0.0
            val taxable = qty * (billItem.rate.toDoubleOrNull() ?: 0.0)
            val gstRateNum = rate.toDoubleOrNull() ?: 0.0
            
            row.totalQty += qty
            row.taxableValue += taxable
            
            val itemTax: Double
            if (isSameState) {
                val tax = taxable * (gstRateNum / 200.0)
                row.cgst += tax
                row.sgst += tax
                itemTax = tax * 2
            } else {
                val tax = taxable * (gstRateNum / 100.0)
                row.igst += tax
                itemTax = tax
            }
            row.totalValue += (taxable + itemTax)
        }
    }

    var currentRowNum = 0

    val headerStyle = workbook.createCellStyle().apply {
        fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
        fillPattern = FillPatternType.SOLID_FOREGROUND
        val font = workbook.createFont().apply {
            bold = true
        }
        setFont(font)
    }

    fun writeTable(title: String, data: List<HsnSummaryRow>) {
        val titleRow = sheet.createRow(currentRowNum++)
        val titleCell = titleRow.createCell(0)
        titleCell.setCellValue(title)
        val titleFont = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 12
        }
        val tStyle = workbook.createCellStyle().apply { setFont(titleFont) }
        titleCell.cellStyle = tStyle
        
        val headerRow = sheet.createRow(currentRowNum++)
        val headers = arrayOf("S.N.", "HSN Code", "UOM", "Total Qty", "Taxable Value", "Rate", "CGST", "SGST", "IGST", "Total Value")
        headers.forEachIndexed { index, s -> 
            val cell = headerRow.createCell(index)
            cell.setCellValue(s)
            cell.setCellStyle(headerStyle)
        }

        data.forEachIndexed { index, rowData ->
            val row = sheet.createRow(currentRowNum++)
            row.createCell(0).setCellValue((index + 1).toDouble())
            row.createCell(1).setCellValue(rowData.hsnCode)
            row.createCell(2).setCellValue(rowData.uom)
            row.createCell(3).setCellValue(rowData.totalQty)
            row.createCell(4).setCellValue(rowData.taxableValue)
            row.createCell(5).setCellValue(rowData.rate)
            row.createCell(6).setCellValue(rowData.cgst)
            row.createCell(7).setCellValue(rowData.sgst)
            row.createCell(8).setCellValue(rowData.igst)
            row.createCell(9).setCellValue(rowData.totalValue)
        }
        currentRowNum += 2
    }

    writeTable("GST Customers HSN Summary", gstSummary.values.toList())
    writeTable("URD Customers HSN Summary", urdSummary.values.toList())

    for (i in 0..9) {
        sheet.autoSizeColumn(i)
    }

    val fileName = "HSN_Summary_${System.currentTimeMillis()}.xlsx"
    val downloadDir = context.getExternalFilesDir("Download")
    if (downloadDir != null && !downloadDir.exists()) {
        downloadDir.mkdirs()
    }
    val file = File(downloadDir, fileName)
    
    try {
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Share Export Summary")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
    }
}

fun exportCompositionSummaryToExcel(
    context: Context,
    billEntries: List<BillEntry>,
    customers: List<Customer>,
    startDateMillis: Long,
    endDateMillis: Long
) {
    val calendar = Calendar.getInstance()
    calendar.timeInMillis = endDateMillis
    calendar.set(Calendar.HOUR_OF_DAY, 23)
    calendar.set(Calendar.MINUTE, 59)
    calendar.set(Calendar.SECOND, 59)
    calendar.set(Calendar.MILLISECOND, 999)
    val adjustedEndMillis = calendar.timeInMillis

    val filteredBills = billEntries
        .filter { entry ->
            val sType = if (entry.schemeType.isBlank()) "Regular GST" else entry.schemeType
            sType.equals("Composition Scheme", ignoreCase = true)
        }
        .filter { entry ->
            try {
                val date = tryParseDate(entry.date)
                date != null && date.time in startDateMillis..adjustedEndMillis
            } catch (e: Exception) {
                false
            }
        }
        .sortedBy { entry ->
            tryParseDate(entry.date)?.time ?: 0L
        }

    if (filteredBills.isEmpty()) {
        Toast.makeText(context, "No Composition Scheme bills found in selected date range", Toast.LENGTH_SHORT).show()
        return
    }

    val workbook = XSSFWorkbook()
    val sheet = workbook.createSheet("Composition Summary")

    val titleStyle = workbook.createCellStyle().apply {
        val font = workbook.createFont().apply {
            bold = true
            fontHeightInPoints = 14
        }
        setFont(font)
    }

    val subTitleStyle = workbook.createCellStyle().apply {
        val font = workbook.createFont().apply {
            italic = true
            fontHeightInPoints = 11
        }
        setFont(font)
    }

    val headerStyle = workbook.createCellStyle().apply {
        fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
        fillPattern = FillPatternType.SOLID_FOREGROUND
        val font = workbook.createFont().apply {
            bold = true
        }
        setFont(font)
    }

    val totalStyle = workbook.createCellStyle().apply {
        fillForegroundColor = IndexedColors.LEMON_CHIFFON.index
        fillPattern = FillPatternType.SOLID_FOREGROUND
        val font = workbook.createFont().apply {
            bold = true
        }
        setFont(font)
    }

    val numberFormat = workbook.createDataFormat().getFormat("#,##0.00")
    val amountStyle = workbook.createCellStyle().apply {
        dataFormat = numberFormat
    }
    val totalAmountStyle = workbook.createCellStyle().apply {
        fillForegroundColor = IndexedColors.LEMON_CHIFFON.index
        fillPattern = FillPatternType.SOLID_FOREGROUND
        val font = workbook.createFont().apply {
            bold = true
        }
        setFont(font)
        dataFormat = numberFormat
    }

    var currentRowNum = 0

    // Title Row
    val titleRow = sheet.createRow(currentRowNum++)
    titleRow.createCell(0).apply {
        setCellValue("Composition Scheme Bills Summary")
        cellStyle = titleStyle
    }

    // Subtitle / Date range
    val displayFormat = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH)
    val subTitleRow = sheet.createRow(currentRowNum++)
    subTitleRow.createCell(0).apply {
        setCellValue("Period: ${displayFormat.format(Date(startDateMillis))} to ${displayFormat.format(Date(endDateMillis))}")
        cellStyle = subTitleStyle
    }
    currentRowNum++ // blank spacing row

    // Table Header: Bill no., Date, Customer Name, Address, Bill Amount
    val headerRow = sheet.createRow(currentRowNum++)
    val headers = arrayOf("S.N.", "Bill No.", "Date", "Customer Name", "Address", "Bill Amount (₹)")
    headers.forEachIndexed { index, header ->
        val cell = headerRow.createCell(index)
        cell.setCellValue(header)
        cell.setCellStyle(headerStyle)
    }

    var totalAmount = 0.0

    // Data Rows
    filteredBills.forEachIndexed { index, entry ->
        val row = sheet.createRow(currentRowNum++)
        row.createCell(0).setCellValue((index + 1).toDouble())
        row.createCell(1).setCellValue(entry.billNo)
        row.createCell(2).setCellValue(entry.date)
        row.createCell(3).setCellValue(entry.customerName)

        val address = entry.customer?.address?.ifBlank { null }
            ?: customers.firstOrNull { it.name.trim().equals(entry.customerName.trim(), ignoreCase = true) }?.address
            ?: ""
        row.createCell(4).setCellValue(address)

        val amountCell = row.createCell(5)
        amountCell.setCellValue(entry.amount)
        amountCell.cellStyle = amountStyle

        totalAmount += entry.amount
    }

    // Total Row
    val totalRow = sheet.createRow(currentRowNum++)
    val totalLabelCell = totalRow.createCell(0)
    totalLabelCell.setCellValue("Total Summary")
    totalLabelCell.cellStyle = totalStyle

    for (c in 1..4) {
        val blankCell = totalRow.createCell(c)
        blankCell.cellStyle = totalStyle
    }

    val totalValueCell = totalRow.createCell(5)
    totalValueCell.setCellValue(totalAmount)
    totalValueCell.cellStyle = totalAmountStyle

    // Auto-fit columns
    for (i in 0..5) {
        sheet.autoSizeColumn(i)
    }

    val fileName = "Composition_Summary_${System.currentTimeMillis()}.xlsx"
    val downloadDir = context.getExternalFilesDir("Download")
    if (downloadDir != null && !downloadDir.exists()) {
        downloadDir.mkdirs()
    }
    val file = File(downloadDir, fileName)

    try {
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()

        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(intent, "Share Export Summary")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    } catch (e: Exception) {
        Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
