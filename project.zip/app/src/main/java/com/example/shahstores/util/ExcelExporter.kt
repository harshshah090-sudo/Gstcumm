package com.example.shahstores.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.shahstores.model.BillEntry
import org.apache.poi.ss.usermodel.FillPatternType
import org.apache.poi.ss.usermodel.IndexedColors
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

data class HsnSummaryRow(
    val hsnCode: String,
    val uom: String,
    var totalQty: Double = 0.0,
    var taxableValue: Double = 0.0,
    val rate: String,
    var cgst: Double = 0.0,
    var sgst: Double = 0.0,
    var igst: Double = 0.0,
    var totalValue: Double = 0.0
)

fun exportHsnSummaryToExcel(
    context: Context,
    billEntries: List<BillEntry>,
    startDateMillis: Long,
    endDateMillis: Long
) {
    val workbook = XSSFWorkbook()
    val sheet = workbook.createSheet("HSN Summary")
    val df = SimpleDateFormat("dd/MMM/yy", Locale.ENGLISH)
    
    val filteredBills = billEntries.filter { entry ->
        try {
            val date = df.parse(entry.date)
            date != null && date.time in startDateMillis..endDateMillis
        } catch (e: Exception) {
            false
        }
    }

    val gstSummary = mutableMapOf<String, HsnSummaryRow>()
    val urdSummary = mutableMapOf<String, HsnSummaryRow>()

    filteredBills.forEach { bill ->
        val isGstCustomer = bill.customer?.registrationType == "GSTIN"
        val targetMap = if (isGstCustomer) gstSummary else urdSummary
        val isSameState = bill.customer?.state?.equals("Madhya Pradesh", ignoreCase = true) ?: true

        bill.items.forEach { billItem ->
            val hsn = billItem.item.hsnCode
            val uom = billItem.item.uom
            val rate = billItem.item.gstRate
            val key = "$hsn-$uom-$rate"
            
            val row = targetMap.getOrPut(key) { HsnSummaryRow(hsnCode = hsn, uom = uom, rate = rate) }
            
            val qty = billItem.quantity.toDoubleOrNull() ?: 0.0
            val taxable = qty * (billItem.rate.toDoubleOrNull() ?: 0.0)
            val gstRateNum = rate.toDoubleOrNull() ?: 0.0
            
            row.totalQty += qty
            row.taxableValue += taxable
            
            val itemTax: Double
            if (isSameState) {
                val tax = taxable * (gstRateNum / 200.0)
                row.cgst += tax
                row.sgst += tax
                itemTax = tax * 2
            } else {
                val tax = taxable * (gstRateNum / 100.0)
                row.igst += tax
                itemTax = tax
            }
            row.totalValue += (taxable + itemTax)
        }
    }

    var currentRowNum = 0

    val headerStyle = workbook.createCellStyle().apply {
        fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
        fillPattern = FillPatternType.SOLID_FOREGROUND
        val font = workbook.createFont()
        font.bold = true
        setFont(font)
    }

    fun writeTable(title: String, data: List<HsnSummaryRow>) {
        val titleRow = sheet.createRow(currentRowNum++)
        titleRow.createCell(0).setCellValue(title)
        
        val headerRow = sheet.createRow(currentRowNum++)
        val headers = arrayOf("S.N.", "HSN Code", "UOM", "Total Qty", "Taxable Value", "Rate", "CGST", "SGST", "IGST", "Total Value")
        headers.forEachIndexed { index, s -> 
            val cell = headerRow.createCell(index)
            cell.setCellValue(s)
            cell.setCellStyle(headerStyle)
        }

        data.forEachIndexed { index, rowData ->
            val row = sheet.createRow(currentRowNum++)
            row.createCell(0).setCellValue((index + 1).toDouble())
            row.createCell(1).setCellValue(rowData.hsnCode)
            row.createCell(2).setCellValue(rowData.uom)
            row.createCell(3).setCellValue(rowData.totalQty)
            row.createCell(4).setCellValue(rowData.taxableValue)
            row.createCell(5).setCellValue(rowData.rate)
            row.createCell(6).setCellValue(rowData.cgst)
            row.createCell(7).setCellValue(rowData.sgst)
            row.createCell(8).setCellValue(rowData.igst)
            row.createCell(9).setCellValue(rowData.totalValue)
        }
        currentRowNum += 2
    }

    writeTable("GST Customers HSN Summary", gstSummary.values.toList())
    writeTable("URD Customers HSN Summary", urdSummary.values.toList())

    val fileName = "HSN_Summary_${System.currentTimeMillis()}.xlsx"
    val downloadDir = context.getExternalFilesDir("Download")
    if (downloadDir != null && !downloadDir.exists()) {
        downloadDir.mkdirs()
    }
    val file = File(downloadDir, fileName)
    
    try {
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        
        val uri: Uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share HSN Summary"))
    } catch (e: Exception) {
        Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
    }
}
