package com.example.shahstores.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.shahstores.data.UomRepository
import com.example.shahstores.model.Uom
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class UomViewModel : ViewModel() {
    private val repository = UomRepository()
    private val _uoms = MutableStateFlow<List<Uom>>(emptyList())
    val uoms: StateFlow<List<Uom>> = _uoms

    init {
        viewModelScope.launch {
            repository.getUoms().collect { 
                _uoms.value = it
            }
        }
    }

    fun addUom(uom: Uom) {
        repository.addUom(uom)
    }

    fun deleteUom(uomId: String) {
        repository.deleteUom(uomId)
    }
}
