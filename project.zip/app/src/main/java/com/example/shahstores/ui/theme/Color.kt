package com.example.shahstores.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Deep Teal
val DeepTeal = Color(0xFF0F766E)
val DeepTealLight = Color(0xFF14B8A6)
val DeepTealDark = Color(0xFF115E59)
val DeepTealContainer = Color(0xFFCCFBF1)
val OnDeepTealContainer = Color(0xFF134E4A)

// Accent Saffron
val Saffron = Color(0xFFF59E0B)
val SaffronLight = Color(0xFFFBBF24)
val SaffronDark = Color(0xFFD97706)
val SaffronContainer = Color(0xFFFEF3C7)
val OnSaffronContainer = Color(0xFF78350F)

// Background & Surface
val AppBackground = Color(0xFFF4FAF9)
val AppSurface = Color(0xFFFFFFFF)
val AppSurfaceVariant = Color(0xFFE6F4F1)
val AppOutline = Color(0xFFCBD5E1)

// Dark Theme Variants
val DeepTeal80 = Color(0xFF5EEAD4)
val Saffron80 = Color(0xFFFCD34D)
val TealGrey80 = Color(0xFF99F6E4)
val DarkBackground = Color(0xFF0A1F1D)
val DarkSurface = Color(0xFF112E2B)
