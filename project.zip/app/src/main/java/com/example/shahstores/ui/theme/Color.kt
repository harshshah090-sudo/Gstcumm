package com.example.shahstores.ui.theme

import androidx.compose.ui.graphics.Color

// Chocolate + Gold Theme Palette
val ChocolatePrimary = Color(0xFF4E342E) // Primary (top bars, Save button, selected nav icon, outlines)
val ChocolatePrimaryDark = Color(0xFF3E2723) // Text/icon colour on accent
val GoldAccent = Color(0xFFD4A24C) // Accent (floating "+" button, "+" button on the invoice screen)
val ScreenBackground = Color(0xFFFBF7F2) // Screen background
val CardBackground = Color(0xFFFFFFFF) // Cards, search boxes, bottom nav bar, bottom keypad panel
val TableHeaderBg = Color(0xFFEFE6DD) // Table header row and light chip background
val AlternateRowShading = Color(0xFFF3EBE3) // Alternate list row shading
val TotalSalesGreen = Color(0xFF2E7D32) // Total Sales amount (green)
val DefaultTextColor = Color(0xFF1B1B1F) // Default text
val InactiveNavIconColor = Color(0x66757575) // Inactive nav icons: grey at ~40% opacity (0x66)
val OutlineColor = Color(0xFF4E342E) // Outline color matching Primary

// Legacy mappings for backwards compatibility
val Purple80 = GoldAccent
val PurpleGrey80 = TableHeaderBg
val Pink80 = AlternateRowShading
val Purple40 = ChocolatePrimary
val PurpleGrey40 = ChocolatePrimaryDark
val Pink40 = GoldAccent
val Blue = Color(0xFF0000FF)
val OffWhite = ScreenBackground
val Red = Color(0xFFFF0000)
val Green = TotalSalesGreen
val Black = DefaultTextColor
val NewHeader = ChocolatePrimary

