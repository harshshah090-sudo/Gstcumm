package com.example

import android.app.Application
import com.google.firebase.FirebaseApp

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            FirebaseApp.initializeApp(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            com.example.data.CityPreferences.init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            com.example.data.UserSessionManager.init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            com.example.utils.AppInstallTracker.init(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        try {
            com.example.utils.AppNotificationHelper.createNotificationChannel(this)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
