package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.GyanCategoryEntity
import com.example.data.GyanTopicEntity
import com.example.data.TimelinePostEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object GyanSeenTracker {
    private const val PREFS_NAME = "gyan_device_seen_prefs"
    private const val KEY_TOPIC_PREFIX = "seen_topic_ts_"
    private const val KEY_TOPIC_AUTHORED_PREFIX = "authored_topic_ts_"
    private const val KEY_CATEGORY_PREFIX = "seen_category_ts_"
    private const val KEY_INSTALL_BASELINE = "gyan_app_install_baseline_ts"
    private const val KEY_INITIAL_INSTALL_SYNCED = "gyan_initial_install_synced_v2"

    private val _seenUpdateSignal = MutableStateFlow(0L)
    val seenUpdateSignal: StateFlow<Long> = _seenUpdateSignal.asStateFlow()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Gets the timestamp when the app was installed / initialized on this device.
     * Past changes or notes created/edited before this installation baseline will not appear
     * on the timeline or show unread red dots.
     */
    fun getInstallBaselineTimestamp(context: Context): Long {
        val prefs = getPrefs(context)
        var baseline = prefs.getLong(KEY_INSTALL_BASELINE, 0L)
        if (baseline == 0L) {
            baseline = maxOf(System.currentTimeMillis(), AppInstallTracker.getInstallBaselineTimestamp(context))
            prefs.edit().putLong(KEY_INSTALL_BASELINE, baseline).apply()
        }
        return baseline
    }

    fun getTopicSeenTimestamp(context: Context, topicId: Long): Long {
        return getPrefs(context).getLong("$KEY_TOPIC_PREFIX$topicId", 0L)
    }

    fun getCategorySeenTimestamp(context: Context, categoryId: Long): Long {
        return getPrefs(context).getLong("$KEY_CATEGORY_PREFIX$categoryId", 0L)
    }

    /**
     * Records that the current user/device authored or edited this topic at the given timestamp.
     * Marks the topic as seen on this device so the author never sees an unread indicator or notification.
     */
    fun markTopicAuthored(context: Context, topicId: Long, timestamp: Long = System.currentTimeMillis()) {
        getPrefs(context).edit()
            .putLong("$KEY_TOPIC_AUTHORED_PREFIX$topicId", timestamp)
            .putLong("$KEY_TOPIC_PREFIX$topicId", maxOf(timestamp, System.currentTimeMillis() + 300_000L))
            .apply()
        _seenUpdateSignal.value = timestamp
    }

    /**
     * Checks if this topic was authored or edited locally on this device.
     */
    fun isTopicAuthoredLocally(context: Context, topicId: Long, topicTimestamp: Long = 0L): Boolean {
        val authoredTs = getPrefs(context).getLong("$KEY_TOPIC_AUTHORED_PREFIX$topicId", 0L)
        if (authoredTs == 0L) return false
        if (topicTimestamp <= 0L) return true
        // Within 60 seconds tolerance for minor clock variance between local and cloud
        return authoredTs >= (topicTimestamp - 60_000L)
    }

    /**
     * Mark a specific topic/note as seen/viewed on this device.
     */
    fun markTopicSeen(context: Context, topicId: Long, timestamp: Long = System.currentTimeMillis()) {
        getPrefs(context).edit().putLong("$KEY_TOPIC_PREFIX$topicId", timestamp).apply()
        _seenUpdateSignal.value = timestamp
    }

    /**
     * Mark a category and optionally all its contained topics as seen.
     */
    fun markCategorySeen(context: Context, categoryId: Long, topics: List<GyanTopicEntity> = emptyList()) {
        val now = System.currentTimeMillis()
        val editor = getPrefs(context).edit()
        editor.putLong("$KEY_CATEGORY_PREFIX$categoryId", now)
        topics.forEach { topic ->
            editor.putLong("$KEY_TOPIC_PREFIX${topic.id}", now)
        }
        editor.apply()
        _seenUpdateSignal.value = now
    }

    /**
     * Ensures all categories and topics present during initial installation / first run
     * are marked as seen so that newly installed apps never display red dots on pre-existing content.
     */
    fun markAllExistingAsSeen(
        context: Context,
        categories: List<GyanCategoryEntity>,
        topics: List<GyanTopicEntity> = emptyList()
    ) {
        val now = System.currentTimeMillis()
        val editor = getPrefs(context).edit()
        categories.forEach { cat ->
            editor.putLong("$KEY_CATEGORY_PREFIX${cat.id}", now)
        }
        topics.forEach { topic ->
            editor.putLong("$KEY_TOPIC_PREFIX${topic.id}", now)
        }
        editor.putBoolean(KEY_INITIAL_INSTALL_SYNCED, true)
        editor.putLong(KEY_INSTALL_BASELINE, now)
        editor.apply()
        _seenUpdateSignal.value = now
    }

    /**
     * Automatically marks all existing categories and topics as seen if this is the first install/launch.
     */
    fun checkAndMarkInitialInstallSeen(
        context: Context,
        categories: List<GyanCategoryEntity>,
        topics: List<GyanTopicEntity> = emptyList()
    ) {
        if (categories.isEmpty()) return
        val prefs = getPrefs(context)
        if (!prefs.getBoolean(KEY_INITIAL_INSTALL_SYNCED, false)) {
            markAllExistingAsSeen(context, categories, topics)
        }
    }

    /**
     * Checks if this note/topic is brand new or was updated since last viewed on this device.
     * On app install, pre-existing notes will NOT show a red dot.
     * A red dot appears if:
     * - The note was created after app installation on this device and hasn't been viewed yet.
     * - Or the note was edited after last being viewed on this device (and after install baseline).
     */
    fun isTopicUnreadOrUpdated(context: Context, topic: GyanTopicEntity): Boolean {
        val prefs = getPrefs(context)
        if (!prefs.getBoolean(KEY_INITIAL_INSTALL_SYNCED, false)) {
            return false
        }
        val topicTimestamp = if (topic.updatedAt > 0L) topic.updatedAt else topic.createdAt
        // The creator or editor on this device should never see an unread red dot for their own note
        if (isTopicAuthoredLocally(context, topic.id, topicTimestamp)) {
            return false
        }
        val baseline = getInstallBaselineTimestamp(context)
        if (topicTimestamp <= 0L || topicTimestamp <= baseline) {
            return false
        }

        val seenTimestamp = getTopicSeenTimestamp(context, topic.id)
        if (seenTimestamp == 0L) {
            // Never viewed on this device yet: only unread if created/updated after app install
            return topicTimestamp > baseline
        }
        // Has been viewed before: unread if edited since last viewed and after install baseline
        return topicTimestamp > seenTimestamp && topicTimestamp > baseline
    }

    /**
     * Checks if a category has any unread or updated notes.
     * The Red Dot only appears when there are any new notes in the category or an existing note was updated.
     */
    fun isCategoryUnreadOrUpdated(
        context: Context,
        category: GyanCategoryEntity,
        topicsForCategory: List<GyanTopicEntity>
    ): Boolean {
        val prefs = getPrefs(context)
        if (!prefs.getBoolean(KEY_INITIAL_INSTALL_SYNCED, false)) {
            return false
        }

        // The Red Dot should only appear whenever there are any new notes in any category or any note should get updated
        return topicsForCategory.any { isTopicUnreadOrUpdated(context, it) }
    }

    /**
     * Returns whether any category or topic in Gyan Shala has an unread red-dot on this device.
     */
    fun hasAnyGyanUnreadOrUpdated(
        context: Context,
        categories: List<GyanCategoryEntity>,
        allTopics: List<GyanTopicEntity>
    ): Boolean {
        val topicsByCat = allTopics.groupBy { it.categoryId }
        return categories.any { cat ->
            isCategoryUnreadOrUpdated(context, cat, topicsByCat[cat.id] ?: emptyList())
        } || allTopics.any { isTopicUnreadOrUpdated(context, it) }
    }

    /**
     * Determines whether a timeline post for Gyan Shala update should be shown on this device.
     * Rules:
     * - Non-Gyan posts are always shown (subject to standard feed logic).
     * - Gyan Shala posts that were made BEFORE app installation on this device are HIDDEN.
     * - Gyan Shala posts made AFTER app installation will be shown on all devices where the app is installed,
     *   until acknowledged/viewed by the user on this device.
     */
    fun shouldShowTimelinePost(context: Context, post: TimelinePostEntity): Boolean {
        if (!post.isGyanShalaUpdate) return true

        val baseline = getInstallBaselineTimestamp(context)
        val postTimestamp = if (post.createdAtEpochMillis > 0L) post.createdAtEpochMillis else post.dateEpochMillis

        // 0. The creator or editor on this device should not see a timeline prompt for their own note
        if (isTopicAuthoredLocally(context, post.gyanTopicId, postTimestamp)) {
            return false
        }

        // 1. If post happened prior to app install on this device, do not show card
        if (postTimestamp <= baseline) {
            return false
        }

        // 2. If user already viewed this specific notification key
        if (GyanNotificationHelper.isGyanTopicViewed(
                context = context,
                categoryId = post.gyanCategoryId,
                topicId = post.gyanTopicId,
                lastEditTimestamp = post.dateEpochMillis
            )
        ) {
            return false
        }

        // 3. If topic was already seen after this post timestamp
        val topicSeenTs = getTopicSeenTimestamp(context, post.gyanTopicId)
        if (topicSeenTs >= post.dateEpochMillis) {
            return false
        }

        return true
    }
}
