package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.util.Base64
import android.util.Log
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BrokenImage
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.math.max
import kotlin.math.roundToInt

object TimelineImageUtils {
    private const val TAG = "TimelineImageUtils"
    const val PHOTO_DELIMITER = "|||"
    // LRU Cache for decoded Bitmaps to guarantee 60fps smooth scrolling
    private val bitmapCache = LruCache<String, Bitmap>(40)

    /**
     * Parses stored photo strings into clean photo URIs/Base64 strings.
     * Supports both new delimiter (|||) and recovers any legacy comma-separated Base64 entries.
     */
    fun parsePhotoUris(raw: String?): List<String> {
        if (raw.isNullOrBlank()) return emptyList()
        val trimmed = raw.trim()

        // 1. If serialized with new delimiter (|||), split cleanly
        if (trimmed.contains(PHOTO_DELIMITER)) {
            return trimmed.split(PHOTO_DELIMITER)
                .map { it.trim() }
                .filter { it.isNotBlank() && it != "data:image/jpeg;base64" && it != "data:image/png;base64" }
                .distinct()
        }

        // 2. Legacy / Comma-separated recovery:
        val tokens = trimmed.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val recoveredList = mutableListOf<String>()
        var i = 0
        while (i < tokens.size) {
            val token = tokens[i]
            if ((token.equals("data:image/jpeg;base64", ignoreCase = true) ||
                 token.equals("data:image/png;base64", ignoreCase = true) ||
                 token.equals("data:image/webp;base64", ignoreCase = true)) && (i + 1 < tokens.size)) {
                // Reconstruct split data URI
                val next = tokens[i + 1]
                if (next.length > 20) {
                    recoveredList.add("$token,$next")
                    i += 2
                    continue
                }
            }
            
            if (token.startsWith("http://", ignoreCase = true) ||
                token.startsWith("https://", ignoreCase = true) ||
                token.startsWith("content://", ignoreCase = true) ||
                token.startsWith("file://", ignoreCase = true)) {
                recoveredList.add(token)
            } else if (token.startsWith("data:image", ignoreCase = true) && token.contains(",")) {
                recoveredList.add(token)
            } else if (token.length > 80 && !token.contains(" ") && !token.contains("/") && !token.contains(":")) {
                // Raw Base64 string payload
                recoveredList.add("data:image/jpeg;base64,$token")
            }
            i++
        }
        return recoveredList.distinct()
    }

    /**
     * Serializes a list of photo URIs/Base64 strings using the safe delimiter (|||).
     */
    fun serializePhotoUris(photos: List<String>): String {
        return photos
            .map { it.trim() }
            .filter { it.isNotBlank() && it != "data:image/jpeg;base64" && it != "data:image/png;base64" }
            .distinct()
            .joinToString(PHOTO_DELIMITER)
    }

    /**
     * Converts a photo Uri from Android Gallery/Camera into an optimized Base64 JPEG string.
     * Compresses to max dimension (e.g. 800px) with 75% quality (~40-60 KB per photo).
     */
    suspend fun processUriToBase64(
        context: Context,
        uriString: String,
        maxDimension: Int = 800,
        quality: Int = 75
    ): String? = withContext(Dispatchers.IO) {
        if (uriString.isBlank()) return@withContext null

        // If it's already a Base64 or remote URL, return as is
        if (uriString.startsWith("http://", ignoreCase = true) ||
            uriString.startsWith("https://", ignoreCase = true) ||
            uriString.startsWith("data:image", ignoreCase = true) ||
            (uriString.length > 300 && !uriString.startsWith("content://") && !uriString.startsWith("file://"))
        ) {
            return@withContext uriString
        }

        try {
            val uri = Uri.parse(uriString)
            var inputStream: InputStream? = context.contentResolver.openInputStream(uri)
                ?: return@withContext null

            // 1. Decode bounds first to prevent OutOfMemory on huge camera pictures
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            val origWidth = options.outWidth
            val origHeight = options.outHeight
            if (origWidth <= 0 || origHeight <= 0) return@withContext null

            // Calculate inSampleSize
            var inSampleSize = 1
            val maxOriginal = max(origWidth, origHeight)
            if (maxOriginal > maxDimension) {
                inSampleSize = (maxOriginal.toFloat() / maxDimension.toFloat()).roundToInt().coerceAtLeast(1)
            }

            val decodeOptions = BitmapFactory.Options().apply {
                this.inSampleSize = inSampleSize
                inPreferredConfig = Bitmap.Config.RGB_565 // Lower memory footprint
            }

            inputStream = context.contentResolver.openInputStream(uri)
            val sampledBitmap = BitmapFactory.decodeStream(inputStream, null, decodeOptions)
            inputStream?.close()

            if (sampledBitmap == null) return@withContext null

            // 2. Handle EXIF orientation
            val rotatedBitmap = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    val exifStream = context.contentResolver.openInputStream(uri)
                    if (exifStream != null) {
                        val exif = ExifInterface(exifStream)
                        val orientation = exif.getAttributeInt(
                            ExifInterface.TAG_ORIENTATION,
                            ExifInterface.ORIENTATION_NORMAL
                        )
                        exifStream.close()
                        rotateBitmapIfRequired(sampledBitmap, orientation)
                    } else sampledBitmap
                } else sampledBitmap
            } catch (e: Exception) {
                sampledBitmap
            }

            // 3. Scale down proportionally to exact maxDimension if still larger
            val currentMax = max(rotatedBitmap.width, rotatedBitmap.height)
            val finalBitmap = if (currentMax > maxDimension) {
                val scale = maxDimension.toFloat() / currentMax.toFloat()
                val targetW = (rotatedBitmap.width * scale).roundToInt().coerceAtLeast(1)
                val targetH = (rotatedBitmap.height * scale).roundToInt().coerceAtLeast(1)
                Bitmap.createScaledBitmap(rotatedBitmap, targetW, targetH, true)
            } else {
                rotatedBitmap
            }

            // 4. Compress to JPEG
            val baos = ByteArrayOutputStream()
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, quality, baos)
            val byteArray = baos.toByteArray()

            val base64Str = Base64.encodeToString(byteArray, Base64.NO_WRAP)
            "data:image/jpeg;base64,$base64Str"
        } catch (e: Exception) {
            Log.e(TAG, "Error compressing image uri $uriString: ${e.message}")
            null
        }
    }

    /**
     * Decodes Base64 to Bitmap with LRU in-memory caching
     */
    fun decodeBase64Bitmap(base64String: String): Bitmap? {
        if (base64String.isBlank()) return null
        val cached = bitmapCache.get(base64String)
        if (cached != null && !cached.isRecycled) {
            return cached
        }

        return try {
            val cleanBase64 = if (base64String.contains(",")) {
                base64String.substringAfter(",")
            } else {
                base64String
            }
            val decodedBytes = Base64.decode(cleanBase64, Base64.DEFAULT)
            val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
            if (bitmap != null) {
                bitmapCache.put(base64String, bitmap)
            }
            bitmap
        } catch (e: Exception) {
            Log.e(TAG, "Error decoding Base64 to Bitmap: ${e.message}")
            null
        }
    }

    private fun rotateBitmapIfRequired(bitmap: Bitmap, orientation: Int): Bitmap {
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }
}

/**
 * Universal Timeline Image Renderer:
 * - Seamlessly displays Base64 encoded images (Option A: Direct Firestore sync without Storage)
 * - Seamlessly displays HTTPS URLs (Option B: Firebase Cloud Storage in the future)
 * - Seamlessly displays local Content / File URIs
 */
@Composable
fun TimelinePhotoDisplay(
    photoSource: String,
    contentDescription: String? = "Post photo",
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val isUrl = photoSource.startsWith("http://", ignoreCase = true) ||
            photoSource.startsWith("https://", ignoreCase = true)
    val isContentUri = photoSource.startsWith("content://") || photoSource.startsWith("file://")
    val isBase64 = photoSource.startsWith("data:image") || (!isUrl && !isContentUri && photoSource.length > 60)

    val context = LocalContext.current

    if (isBase64) {
        val bitmapState = produceState<Bitmap?>(
            initialValue = TimelineImageUtils.decodeBase64Bitmap(photoSource),
            key1 = photoSource
        ) {
            if (value == null) {
                value = withContext(Dispatchers.IO) {
                    TimelineImageUtils.decodeBase64Bitmap(photoSource)
                }
            }
        }

        val bmp = bitmapState.value
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = contentDescription,
                contentScale = contentScale,
                modifier = modifier
            )
        } else {
            Box(
                modifier = modifier.background(Color.DarkGray.copy(alpha = 0.3f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.BrokenImage,
                    contentDescription = null,
                    tint = Color.White.copy(alpha = 0.5f)
                )
            }
        }
    } else {
        // Coil AsyncImage for Remote URLs (Option B) or Local URIs
        AsyncImage(
            model = ImageRequest.Builder(context)
                .data(photoSource)
                .crossfade(true)
                .build(),
            contentDescription = contentDescription,
            contentScale = contentScale,
            modifier = modifier.background(Color.DarkGray.copy(alpha = 0.3f))
        )
    }
}
