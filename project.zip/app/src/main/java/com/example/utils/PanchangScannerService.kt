package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import com.example.data.PanchangEventEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit

data class ExtractedPanchangItem(
    val dateString: String, // YYYY-MM-DD
    val dayOfWeek: String = "",
    val tithi: String = "",
    val isImportantTithi: Boolean = false,
    val kalyanaks: String = "",
    val parvasAndEvents: String = "",
    val sunriseTime: String = "",
    val sunsetTime: String = "",
    val navkarsiTime: String = "",
    val notes: String = ""
)

object PanchangScannerService {

    private const val TAG = "PanchangScannerService"
    private const val PREFS_NAME = "panchang_scanner_prefs"
    private const val KEY_CUSTOM_API_KEY = "custom_gemini_api_key"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun saveCustomApiKey(context: Context, key: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_CUSTOM_API_KEY, key.trim()).apply()
    }

    fun getSavedCustomApiKey(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_CUSTOM_API_KEY, "") ?: ""
    }

    private fun resolveApiKey(context: Context, customKey: String?): String {
        if (!customKey.isNullOrBlank()) return customKey.trim()
        val savedKey = getSavedCustomApiKey(context)
        if (savedKey.isNotBlank()) return savedKey.trim()
        val buildKey = BuildConfig.GEMINI_API_KEY
        if (!buildKey.isNullOrBlank() && buildKey != "MY_GEMINI_API_KEY") return buildKey.trim()
        return ""
    }

    private fun String?.isNullAndBlank(): Boolean = this == null || this.isBlank()

    suspend fun analyzePanchangImage(
        context: Context,
        imageUri: Uri,
        customApiKey: String? = null,
        allowDemoFallback: Boolean = false
    ): Result<List<PanchangEventEntity>> = withContext(Dispatchers.IO) {
        try {
            if (allowDemoFallback) {
                return@withContext Result.success(getDemoPanchangExtraction())
            }

            val bitmap = loadResizedBitmapFromUri(context, imageUri)
                ?: return@withContext Result.failure(Exception("Unable to process image. Please choose another image."))

            val base64Image = bitmap.toBase64Jpeg()
            bitmap.recycle()

            val apiKey = resolveApiKey(context, customApiKey)
            if (apiKey.isBlank()) {
                return@withContext Result.failure(Exception("NO_API_KEY_CONFIGURED"))
            }

            val promptText = """
                You are an expert Jain Panchang and Calendar OCR Parser.
                Analyze the provided Panchang page photo carefully.
                Extract all date entries, Jain Tithis (e.g., Sud/Vad Ekadashi, Chaudas, Aatham, Poonam, Amas), Jain Kalyanaks (e.g., Janma, Diksha, Kevaljnana, Moksha Kalyanaks of Tirthankaras), Parvas & Festivals (e.g., Paryushan, Ayambil Oli, Mahavir Jayanti, Akshaya Tritiya, Ashtahnika), and Pachkhan/Sunrise/Sunset timings.

                Output ONLY a JSON array of objects. Each object MUST contain these fields:
                - "dateString": string formatted as "YYYY-MM-DD" (e.g. "2026-04-19"). If year is missing in photo, assume 2026.
                - "dayOfWeek": string in Hindi/English (e.g. "Sunday" or "रविवार")
                - "tithi": string (e.g. "Vaisakha Sud Dooj" or "वैशाख सुद २")
                - "isImportantTithi": boolean (true if Agiyaras/Ekadashi, Chaudas/Chaturdashi, Aatham/Ashtami, Poornima/Poonam, Amavasya/Amas)
                - "kalyanaks": string describing Tirthankar Kalyanaks or empty string ""
                - "parvasAndEvents": string describing Jain festivals/parvas or empty string ""
                - "sunriseTime": string (e.g. "06:12 AM") or empty string ""
                - "sunsetTime": string (e.g. "06:48 PM") or empty string ""
                - "navkarsiTime": string (e.g. "07:00 AM") or empty string ""
                - "notes": string containing any extra notes or empty string ""

                Be precise and thorough. Return ONLY valid JSON array with no markdown formatting.
            """.trimIndent()

            val reqObj = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val textPart = JSONObject().apply {
                                put("text", promptText)
                            }
                            val imagePart = JSONObject().apply {
                                val inlineDataObj = JSONObject().apply {
                                    put("mimeType", "image/jpeg")
                                    put("data", base64Image)
                                }
                                put("inlineData", inlineDataObj)
                            }
                            put(textPart)
                            put(imagePart)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                val generationConfigObj = JSONObject().apply {
                    val responseFormatObj = JSONObject().apply {
                        put("responseMimeType", "application/json")
                    }
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                }
                put("generationConfig", generationConfigObj)
            }

            val candidateModels = listOf("gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.0-flash")
            var lastResponseBody = ""
            var lastErrorCode = 0
            var successfulResponseBody: String? = null

            for (model in candidateModels) {
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
                val request = Request.Builder()
                    .url(url)
                    .post(reqObj.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
                    .build()

                try {
                    val response = httpClient.newCall(request).execute()
                    val responseBodyString = response.body?.string() ?: ""
                    if (response.isSuccessful) {
                        successfulResponseBody = responseBodyString
                        break
                    } else {
                        lastErrorCode = response.code
                        lastResponseBody = responseBodyString
                        Log.e(TAG, "Gemini API error with $model (${response.code}): $responseBodyString")
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Network call failed for model $model", e)
                }
            }

            if (successfulResponseBody == null) {
                if (lastErrorCode == 400 || lastErrorCode == 403) {
                    return@withContext Result.failure(Exception("API Key Error (HTTP $lastErrorCode): The key you entered is invalid, expired, or API access is restricted. Please check your key in Google AI Studio."))
                }
                return@withContext Result.failure(Exception("AI Extraction failed (HTTP $lastErrorCode). Please verify your API key and try again."))
            }

            val extractedItems = parseGeminiResponseToItems(successfulResponseBody)
            if (extractedItems.isEmpty()) {
                return@withContext Result.failure(Exception("No Panchang entries found in the image. Please ensure the image is clear and contains a calendar page."))
            }

            val entities = extractedItems.map { item ->
                PanchangEventEntity(
                    dateString = item.dateString,
                    dayOfWeek = item.dayOfWeek,
                    tithi = item.tithi,
                    isImportantTithi = item.isImportantTithi,
                    kalyanaks = item.kalyanaks,
                    parvasAndEvents = item.parvasAndEvents,
                    sunriseTime = item.sunriseTime,
                    sunsetTime = item.sunsetTime,
                    navkarsiTime = item.navkarsiTime,
                    notes = item.notes
                )
            }

            Result.success(entities)
        } catch (e: Exception) {
            Log.e(TAG, "Exception during panchang extraction: ${e.message}", e)
            Result.failure(e)
        }
    }

    private fun loadResizedBitmapFromUri(context: Context, uri: Uri): Bitmap? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream?.close()

            val maxDim = 1280
            var sampleSize = 1
            while (options.outWidth / sampleSize > maxDim || options.outHeight / sampleSize > maxDim) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
            }
            val secondStream = context.contentResolver.openInputStream(uri)
            val bitmap = BitmapFactory.decodeStream(secondStream, null, decodeOptions)
            secondStream?.close()
            bitmap
        } catch (e: Exception) {
            Log.e(TAG, "Error loading bitmap: ${e.message}")
            null
        }
    }

    private fun Bitmap.toBase64Jpeg(): String {
        val stream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 85, stream)
        val bytes = stream.toByteArray()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun parseGeminiResponseToItems(rawJson: String): List<ExtractedPanchangItem> {
        val resultList = mutableListOf<ExtractedPanchangItem>()
        try {
            val rootObj = JSONObject(rawJson)
            val candidates = rootObj.optJSONArray("candidates") ?: return emptyList()
            val candidate = candidates.optJSONObject(0) ?: return emptyList()
            val content = candidate.optJSONObject("content") ?: return emptyList()
            val parts = content.optJSONArray("parts") ?: return emptyList()
            val textPart = parts.optJSONObject(0)?.optString("text") ?: ""

            val cleanedJson = cleanJsonString(textPart)
            val jsonArray = if (cleanedJson.startsWith("[")) {
                JSONArray(cleanedJson)
            } else if (cleanedJson.startsWith("{")) {
                val singleObj = JSONObject(cleanedJson)
                singleObj.optJSONArray("events") ?: singleObj.optJSONArray("panchang") ?: JSONArray()
            } else {
                JSONArray()
            }

            for (i in 0 until jsonArray.length()) {
                val itemObj = jsonArray.optJSONObject(i) ?: continue
                val dateStr = itemObj.optString("dateString", "")
                if (dateStr.isNotBlank()) {
                    resultList.add(
                        ExtractedPanchangItem(
                            dateString = dateStr,
                            dayOfWeek = itemObj.optString("dayOfWeek", ""),
                            tithi = itemObj.optString("tithi", ""),
                            isImportantTithi = itemObj.optBoolean("isImportantTithi", false),
                            kalyanaks = itemObj.optString("kalyanaks", ""),
                            parvasAndEvents = itemObj.optString("parvasAndEvents", ""),
                            sunriseTime = itemObj.optString("sunriseTime", ""),
                            sunsetTime = itemObj.optString("sunsetTime", ""),
                            navkarsiTime = itemObj.optString("navkarsiTime", ""),
                            notes = itemObj.optString("notes", "")
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing Gemini json response: ${e.message}")
        }
        return resultList
    }

    private fun cleanJsonString(raw: String): String {
        var str = raw.trim()
        if (str.startsWith("\"") && str.endsWith("\"")) {
            str = str.substring(1, str.length - 1)
        }
        str = str.replace("\\\"", "\"").replace("\\n", "\n")
        if (str.contains("```json")) {
            str = str.substringAfter("```json").substringBefore("```")
        } else if (str.contains("```")) {
            str = str.substringAfter("```").substringBefore("```")
        }
        return str.trim()
    }

    fun getDemoPanchangExtraction(): List<PanchangEventEntity> {
        return listOf(
            PanchangEventEntity(
                dateString = "2026-08-15",
                dayOfWeek = "Saturday / शनिवार",
                tithi = "Bhadrapad Sud Teej (३)",
                isImportantTithi = false,
                kalyanaks = "",
                parvasAndEvents = "स्वातंत्र्य दिन / रक्षाबंधन पूर्व संध्या",
                sunriseTime = "06:11 AM",
                sunsetTime = "06:58 PM",
                navkarsiTime = "06:59 AM",
                notes = "डेमो पंचांग स्कैन से प्राप्त तिथि"
            ),
            PanchangEventEntity(
                dateString = "2026-08-20",
                dayOfWeek = "Thursday / गुरुवार",
                tithi = "Bhadrapad Sud Aatham (८)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "विशेष अष्टमी तिथि",
                sunriseTime = "06:13 AM",
                sunsetTime = "06:53 PM",
                navkarsiTime = "07:01 AM",
                notes = "अष्टमी उपवास एवं स्वाध्याय"
            ),
            PanchangEventEntity(
                dateString = "2026-08-23",
                dayOfWeek = "Sunday / रविवार",
                tithi = "Bhadrapad Sud Agiyaras (११)",
                isImportantTithi = true,
                kalyanaks = "Shri Parshvanath Bhagwan Nirvan Kalyanak",
                parvasAndEvents = "पवित्र एकादशी महापर्व",
                sunriseTime = "06:14 AM",
                sunsetTime = "06:50 PM",
                navkarsiTime = "07:02 AM",
                notes = "एकादशी उपवास एवं जप"
            ),
            PanchangEventEntity(
                dateString = "2026-08-27",
                dayOfWeek = "Thursday / गुरुवार",
                tithi = "Bhadrapad Sud Poonam (१५)",
                isImportantTithi = true,
                kalyanaks = "",
                parvasAndEvents = "भाद्रपद पूर्णिमा",
                sunriseTime = "06:16 AM",
                sunsetTime = "06:45 PM",
                navkarsiTime = "07:04 AM",
                notes = "पूर्णिमा नियम एवं देव दर्शन"
            )
        )
    }
}
