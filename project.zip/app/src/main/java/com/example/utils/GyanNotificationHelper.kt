package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R

object GyanNotificationHelper {

    private const val PREFS_NAME = "gyan_viewed_notifications_prefs"
    private const val KEY_VIEWED_SET = "viewed_gyan_timeline_post_ids"
    private const val CHANNEL_ID = "gyan_shala_updates_channel"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Checks if the user on this device has already viewed/acknowledged this Gyan Shala update.
     */
    fun isPostViewed(context: Context, postIdOrKey: String): Boolean {
        if (postIdOrKey.isBlank()) return false
        val viewedSet = getPrefs(context).getStringSet(KEY_VIEWED_SET, emptySet()) ?: emptySet()
        return viewedSet.contains(postIdOrKey)
    }

    /**
     * Marks a specific Gyan Shala update card as viewed on this device so it disappears from Timeline.
     */
    fun markPostAsViewed(context: Context, postIdOrKey: String) {
        if (postIdOrKey.isBlank()) return
        val currentSet = getPrefs(context).getStringSet(KEY_VIEWED_SET, emptySet())?.toMutableSet() ?: mutableSetOf()
        currentSet.add(postIdOrKey)
        getPrefs(context).edit().putStringSet(KEY_VIEWED_SET, currentSet).apply()
    }

    fun isGyanTopicViewed(context: Context, categoryId: Long, topicId: Long, lastEditTimestamp: Long): Boolean {
        val key = "topic_${categoryId}_${topicId}_$lastEditTimestamp"
        return isPostViewed(context, key)
    }

    fun markGyanTopicAsViewed(context: Context, categoryId: Long, topicId: Long, editTimestamp: Long) {
        val key = "topic_${categoryId}_${topicId}_$editTimestamp"
        markPostAsViewed(context, key)
    }

    fun dismissTopicNotification(context: Context, topicId: Long) {
        try {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.cancel(topicId.hashCode())
        } catch (e: Exception) {
            // Ignore
        }
    }

    /**
     * Creates the Android notification channel for Gyan Shala Real-Time Updates.
     */
    private fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "Gyan Shala Updates"
            val descriptionText = "Instant notifications when new notes and topics are added or updated in Gyan Shala"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                setShowBadge(true)
            }
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Posts a device system notification when a note is added/updated in Gyan Shala.
     */
    fun postGyanUpdateNotification(
        context: Context,
        notificationId: Int,
        topicTitle: String,
        categoryName: String,
        isUpdate: Boolean,
        categoryId: Long,
        topicId: Long
    ) {
        try {
            createNotificationChannel(context)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("destination", "gyan_shala")
                putExtra("target_category_id", categoryId)
                putExtra("target_topic_id", topicId)
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val actionLabel = if (isUpdate) "Updated Note" else "New Note"
            val titleText = "📖 Gyan Shala: $actionLabel"
            val bodyText = if (topicTitle.isNotBlank()) {
                "[$categoryName] $topicTitle"
            } else {
                "New learning added in $categoryName"
            }

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.header_logo)
                .setContentTitle(titleText)
                .setContentText(bodyText)
                .setStyle(NotificationCompat.BigTextStyle().bigText("$bodyText\nTap to open note directly."))
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pendingIntent)
                .build()

            notificationManager.notify(notificationId, notification)
        } catch (e: Exception) {
            android.util.Log.e("GyanNotificationHelper", "Failed to post notification: ${e.message}")
        }
    }
}
