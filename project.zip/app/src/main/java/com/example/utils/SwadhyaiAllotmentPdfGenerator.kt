package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.widget.Toast
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.data.SwadhyaiFormEntity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SwadhyaiAllotmentPdfGenerator {

    fun generatePdf(
        context: Context,
        sangh: ParyushanFormEntity,
        swadhyaiList: List<SwadhyaiFormEntity>,
        messageText: String
    ): File {
        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 32f
        val contentWidth = pageWidth - (margin * 2)

        val logoOptions = BitmapFactory.Options().apply { inScaled = false }
        val originalLogo = BitmapFactory.decodeResource(context.resources, R.drawable.header_logo, logoOptions)

        val watermarkPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            alpha = 32
        }

        val bitmapPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            isDither = true
        }

        val primaryRed = Color.rgb(139, 0, 0)
        val deepRed = Color.rgb(178, 34, 34)
        val cardBgColor = Color.rgb(255, 253, 249)
        val cardBorderColor = Color.rgb(228, 205, 178)
        val accentGoldColor = Color.rgb(180, 125, 30)
        val darkTextColor = Color.rgb(35, 22, 10)
        val subTextColor = Color.rgb(105, 75, 45)

        val borderPaint = Paint().apply {
            color = cardBorderColor
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val redBorderPaint = Paint().apply {
            color = primaryRed
            style = Paint.Style.STROKE
            strokeWidth = 1.5f
            isAntiAlias = true
        }

        val cardBgPaint = Paint().apply {
            color = cardBgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val headerAccentPaint = Paint().apply {
            color = primaryRed
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val titlePaint = TextPaint().apply {
            color = primaryRed
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val taglinePaint = TextPaint().apply {
            color = deepRed
            textSize = 12.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val badgeTextPaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val sectionTitlePaint = TextPaint().apply {
            color = primaryRed
            textSize = 11.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val labelPaint = TextPaint().apply {
            color = subTextColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val valuePaint = TextPaint().apply {
            color = darkTextColor
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val swadhyaiNamePaint = TextPaint().apply {
            color = primaryRed
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val footerPaint = TextPaint().apply {
            color = subTextColor
            textSize = 8.5f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        fun drawWatermark(c: Canvas) {
            if (originalLogo != null) {
                val watermarkWidth = 330f
                val watermarkHeight = watermarkWidth * (originalLogo.height.toFloat() / originalLogo.width.toFloat())
                val left = (pageWidth - watermarkWidth) / 2f
                val top = (pageHeight - watermarkHeight) / 2f
                val dstRect = RectF(left, top, left + watermarkWidth, top + watermarkHeight)
                c.drawBitmap(originalLogo, null, dstRect, watermarkPaint)
            }
        }

        fun drawHeader(c: Canvas): Float {
            drawWatermark(c)

            var curY = margin
            val logoSize = 52f
            if (originalLogo != null) {
                val logoRect = RectF(margin, curY, margin + logoSize, curY + logoSize)
                c.drawBitmap(originalLogo, null, logoRect, bitmapPaint)
            }

            val textStartX = margin + logoSize + 12f
            c.drawText("श्री वर्द्धमान स्वाध्याय संघ", textStartX, curY + 20f, titlePaint)
            c.drawText("।। जिन आज्ञा परमो धर्मः ।।", textStartX, curY + 38f, taglinePaint)

            curY += logoSize + 8f

            // Red divider line
            c.drawLine(margin, curY, pageWidth - margin, curY, redBorderPaint)
            curY += 8f

            // Badge for Document Type
            val badgeHeight = 18f
            val badgeWidth = 260f
            val badgeLeft = (pageWidth - badgeWidth) / 2f
            val badgeRect = RectF(badgeLeft, curY, badgeLeft + badgeWidth, curY + badgeHeight)
            c.drawRoundRect(badgeRect, 9f, 9f, headerAccentPaint)
            c.drawText("स्वाध्यायी आवंटन पत्र / ALLOTMENT DETAILS", pageWidth / 2f, curY + 13f, badgeTextPaint)

            // Date on right
            val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val datePaint = TextPaint(labelPaint).apply { textAlign = Paint.Align.RIGHT }
            c.drawText("दिनांक: $dateStr", pageWidth - margin, curY + 13f, datePaint)

            curY += badgeHeight + 10f
            return curY
        }

        var currentY = drawHeader(canvas)

        // Helper to draw section box
        fun drawSectionCard(
            title: String,
            startY: Float,
            drawContent: (Canvas, Float, Float, Float) -> Float
        ): Float {
            val cardLeft = margin
            val cardRight = pageWidth - margin
            val cardPadding = 10f
            val contentWidthInside = cardRight - cardLeft - (cardPadding * 2)

            val contentStartY = startY + 22f
            // Measure or draw content
            val endContentY = drawContent(canvas, cardLeft + cardPadding, contentStartY, contentWidthInside)
            val cardHeight = (endContentY - startY) + 6f
            val cardRect = RectF(cardLeft, startY, cardRight, startY + cardHeight)

            // Draw card background & border behind content
            // We use a separate canvas save/restore or layer
            val bgCardRect = RectF(cardLeft, startY, cardRight, startY + cardHeight)
            canvas.drawRoundRect(bgCardRect, 6f, 6f, cardBgPaint)
            canvas.drawRoundRect(bgCardRect, 6f, 6f, borderPaint)

            // Left accent bar in red
            val accentBar = RectF(cardLeft, startY, cardLeft + 4f, startY + cardHeight)
            canvas.drawRoundRect(accentBar, 2f, 2f, headerAccentPaint)

            // Section title
            canvas.drawText(title, cardLeft + cardPadding, startY + 15f, sectionTitlePaint)
            val titleLineY = startY + 18f
            canvas.drawLine(cardLeft + cardPadding, titleLineY, cardRight - cardPadding, titleLineY, borderPaint)

            // Redraw content on top of background
            val finalEndY = drawContent(canvas, cardLeft + cardPadding, contentStartY, contentWidthInside)
            return startY + cardHeight + 10f
        }

        // Section 1: Sangh Details
        currentY = drawSectionCard("🏛️ संघ का विवरण (Sangh Details)", currentY) { c, startX, startContentY, w ->
            var cy = startContentY
            val location = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName

            // Sangh Name
            c.drawText("संघ का नाम:", startX, cy + 9f, labelPaint)
            c.drawText(sangh.sanghName.ifBlank { "निर्दिष्ट नहीं" }, startX + 65f, cy + 9f, valuePaint)
            cy += 14f

            // Location & Mulnayak
            c.drawText("स्थान / शहर:", startX, cy + 9f, labelPaint)
            c.drawText(location.ifBlank { "निर्दिष्ट नहीं" }, startX + 65f, cy + 9f, valuePaint)

            if (sangh.mulnayakBhagwan.isNotBlank()) {
                val halfW = w / 2f
                c.drawText("मूलनायक:", startX + halfW, cy + 9f, labelPaint)
                c.drawText(sangh.mulnayakBhagwan, startX + halfW + 55f, cy + 9f, valuePaint)
            }
            cy += 14f

            // Address
            if (sangh.sanghAddress.isNotBlank()) {
                c.drawText("उपाश्रय का पता:", startX, cy + 9f, labelPaint)
                val addrLayout = StaticLayout.Builder.obtain(sangh.sanghAddress, 0, sangh.sanghAddress.length, valuePaint, (w - 75f).toInt())
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 1.1f)
                    .build()
                c.save()
                c.translate(startX + 75f, cy)
                addrLayout.draw(c)
                c.restore()
                cy += addrLayout.height + 4f
            }

            // Contact 1 & Contact 2
            val c1 = sangh.contact1.trim()
            val c2 = sangh.contact2.trim()
            if (c1.isNotBlank() || c2.isNotBlank()) {
                c.drawText("संघ संपर्क सूत्र:", startX, cy + 9f, labelPaint)
                val contactsText = listOf(c1, c2).filter { it.isNotBlank() }.joinToString("   |   ")
                c.drawText(contactsText, startX + 75f, cy + 9f, valuePaint)
                cy += 14f
            }

            // Tradition & Samagri
            if (sangh.pratikramanTradition.isNotBlank()) {
                c.drawText("प्रतिक्रमण परंपरा:", startX, cy + 9f, labelPaint)
                c.drawText(sangh.pratikramanTradition, startX + 85f, cy + 9f, valuePaint)
                cy += 14f
            }

            cy
        }

        // Section 2: Assigned Swadhyayis
        currentY = drawSectionCard("👥 निर्धारित स्वाध्यायी (Assigned Swadhyayis)", currentY) { c, startX, startContentY, w ->
            var cy = startContentY
            if (swadhyaiList.isEmpty()) {
                c.drawText("कोई स्वाध्यायी आवंटित नहीं", startX, cy + 9f, valuePaint)
                cy += 16f
            } else {
                swadhyaiList.forEachIndexed { idx, swadhyai ->
                    val phone = swadhyai.whatsappNo.ifBlank { swadhyai.contactNo }.trim()
                    val cityState = if (swadhyai.state.isNotBlank()) "${swadhyai.city} (${swadhyai.state})" else swadhyai.city

                    // Swadhyai Box
                    val boxRect = RectF(startX, cy, startX + w, cy + 30f)
                    val swBgPaint = Paint().apply {
                        color = Color.rgb(255, 248, 238)
                        style = Paint.Style.FILL
                    }
                    val swBorder = Paint().apply {
                        color = Color.rgb(230, 200, 160)
                        style = Paint.Style.STROKE
                        strokeWidth = 0.8f
                    }
                    c.drawRoundRect(boxRect, 4f, 4f, swBgPaint)
                    c.drawRoundRect(boxRect, 4f, 4f, swBorder)

                    c.drawText("${idx + 1}. ${swadhyai.fullName.ifBlank { "स्वाध्यायी" }}", startX + 8f, cy + 13f, swadhyaiNamePaint)

                    val infoParts = mutableListOf<String>()
                    if (cityState.isNotBlank()) infoParts.add("📍 $cityState")
                    if (phone.isNotBlank()) infoParts.add("📞 $phone")
                    if (swadhyai.workingStatus.isNotBlank()) infoParts.add("💼 ${swadhyai.workingStatus}")

                    c.drawText(infoParts.joinToString("   •   "), startX + 8f, cy + 24f, valuePaint)
                    cy += 36f
                }
            }
            cy
        }

        // Section 3: Detailed Message & Aradhana Guidelines
        val cleanMsg = messageText.trim()
        if (cleanMsg.isNotBlank()) {
            currentY = drawSectionCard("📜 संदेश एवं आराधना विवरण (Message to Swadhyai)", currentY) { c, startX, startContentY, w ->
                var cy = startContentY
                val msgPaint = TextPaint(valuePaint).apply {
                    textSize = 9.5f
                    color = Color.rgb(40, 25, 12)
                }

                val msgLayout = StaticLayout.Builder.obtain(cleanMsg, 0, cleanMsg.length, msgPaint, w.toInt())
                    .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                    .setLineSpacing(0f, 1.2f)
                    .build()

                c.save()
                c.translate(startX, cy)
                msgLayout.draw(c)
                c.restore()
                cy += msgLayout.height + 4f
                cy
            }
        }

        // Footer at bottom of page
        val footerY = pageHeight - margin + 10f
        canvas.drawLine(margin, footerY - 14f, pageWidth - margin, footerY - 14f, borderPaint)
        canvas.drawText(
            "श्री वर्द्धमान स्वाध्याय संघ • यह आवंटन पत्र संघ के आधिकारिक रिकॉर्ड अनुसार जारी किया गया है।",
            pageWidth / 2f,
            footerY,
            footerPaint
        )

        pdfDocument.finishPage(page)

        val cleanSanghName = sangh.sanghName.replace("[^a-zA-Z0-9_\\u0900-\\u097F]".toRegex(), "_").take(30)
        val fileName = "Swadhyai_Allotment_${cleanSanghName}_${System.currentTimeMillis()}.pdf"
        val outputFile = File(context.cacheDir, fileName)
        if (outputFile.exists()) {
            outputFile.delete()
        }

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        // Also attempt to copy to Downloads public directory so user can find it in their file manager
        saveToPublicDownloads(context, outputFile, fileName)

        return outputFile
    }

    private fun saveToPublicDownloads(context: Context, sourceFile: File, fileName: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VardhmanSwadhyaySangh")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "VardhmanSwadhyaySangh")
                if (!targetDir.exists()) targetDir.mkdirs()
                val destFile = File(targetDir, fileName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out)
                    }
                }
            }
        } catch (e: Exception) {
            // Silently fall back to cache file
        }
    }
}
