package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.TextPaint
import android.widget.Toast
import com.example.R
import com.example.data.ParyushanFormEntity
import com.example.data.SwadhyaiFormEntity
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

data class PdfPhoneClickableRegion(
    val phone: String,
    val bounds: RectF // In PDF coordinate space 0..595 x 0..842 (origin top-left for Compose/Canvas)
)

object SwadhyaiAllotmentPdfGenerator {

    fun openDialer(context: Context, phoneNumber: String) {
        try {
            val cleanPhone = phoneNumber.filter { it.isDigit() || it == '+' }
            if (cleanPhone.isBlank()) return
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleanPhone")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "डायलर खोलने में असमर्थ: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun getPhoneClickableRegions(
        sangh: ParyushanFormEntity,
        swadhyaiList: List<SwadhyaiFormEntity>
    ): List<PdfPhoneClickableRegion> {
        val regions = mutableListOf<PdfPhoneClickableRegion>()
        val margin = 24f
        val sanghBoxLeft = margin + 10f
        val pageWidth = 595f
        val sanghBoxRight = pageWidth - margin - 10f
        val sanghBoxWidth = sanghBoxRight - sanghBoxLeft

        // 1. Sangh phone region
        var contactPerson = sangh.contact1.trim()
        var sanghPhone = sangh.contact2.trim()
        if (sanghPhone.isBlank() && contactPerson.contains("\\d{10}".toRegex())) {
            val match = "\\d{10}".toRegex().find(contactPerson)
            if (match != null) {
                sanghPhone = match.value
            }
        }
        if (sanghPhone.isBlank()) sanghPhone = "9303634541"

        val headerHeight = 18f
        val rowHeight = 17f
        val curYSangh = margin + 12f + 46f + 10f + 20f + 8f + 16f // = 136f
        val rYMobile = curYSangh + headerHeight + (4 * rowHeight) // Row 4 is mobile
        val colLabelWidth = 145f
        val phoneBoxLeft = sanghBoxLeft + colLabelWidth
        val phoneBoxWidth = 90f
        val phoneBoxHeight = 14f
        val phoneBoxTop = rYMobile + 1.5f

        regions.add(
            PdfPhoneClickableRegion(
                phone = sanghPhone,
                bounds = RectF(phoneBoxLeft, phoneBoxTop, phoneBoxLeft + phoneBoxWidth, phoneBoxTop + phoneBoxHeight)
            )
        )

        // 2. Swadhyai team phone regions
        val activeSwadhyais = if (swadhyaiList.isEmpty()) {
            listOf(
                SwadhyaiFormEntity(fullName = "Dinesh Jain", city = "Bhawani Mandi", whatsappNo = "9460519075"),
                SwadhyaiFormEntity(fullName = "Suresh Shah", city = "Indore", whatsappNo = "9406667980")
            )
        } else {
            swadhyaiList
        }

        val sanghBoxHeight = headerHeight + (8 * rowHeight) + 4f
        val twoColHeight = 106f
        val curYSwTeam = curYSangh + sanghBoxHeight + 8f + twoColHeight + 8f // = 416f
        val swCardTop = curYSwTeam + headerHeight + 5f

        val numSw = activeSwadhyais.size.coerceAtMost(3)
        val swCardGap = 8f
        val swCardWidth = (sanghBoxWidth - (swCardGap * (numSw + 1))) / numSw
        val phoneW = 80f
        val phoneH = 13f

        activeSwadhyais.take(numSw).forEachIndexed { index, s ->
            val swLeft = sanghBoxLeft + swCardGap + (index * (swCardWidth + swCardGap))
            val swRight = swLeft + swCardWidth
            val pLeft = (swLeft + swRight - phoneW) / 2f
            val pTop = swCardTop + 40f
            val phone = s.whatsappNo.ifBlank { s.contactNo }.trim().ifBlank { "9460519075" }

            regions.add(
                PdfPhoneClickableRegion(
                    phone = phone,
                    bounds = RectF(pLeft, pTop, pLeft + phoneW, pTop + phoneH)
                )
            )
        }

        return regions
    }

    fun generatePdf(
        context: Context,
        sangh: ParyushanFormEntity,
        swadhyaiList: List<SwadhyaiFormEntity>
    ): File {
        val pdfDocument = PdfDocument()
        val pageWidth = 595
        val pageHeight = 842
        val margin = 24f

        val logoOptions = BitmapFactory.Options().apply { inScaled = false }
        val originalLogo = try {
            BitmapFactory.decodeResource(context.resources, R.drawable.header_logo, logoOptions)
        } catch (e: Exception) {
            null
        }

        // Color definitions
        val bgCanvasColor = Color.rgb(250, 246, 238)
        val outerBorderColor = Color.rgb(106, 26, 26)
        val innerGoldColor = Color.rgb(212, 175, 55)
        val deepMaroonColor = Color.rgb(122, 18, 18)
        val darkMaroonPillColor = Color.rgb(106, 26, 26)
        val cardBgColor = Color.rgb(255, 253, 249)
        val cardHeaderBgColor = Color.rgb(251, 244, 232)
        val cardBorderColor = Color.rgb(230, 210, 181)
        val rowDividerColor = Color.rgb(240, 228, 210)
        val labelTextColor = Color.rgb(74, 46, 24)
        val valueTextColor = Color.rgb(26, 13, 5)
        val phoneGreenBg = Color.rgb(232, 247, 240)
        val phoneGreenBorder = Color.rgb(163, 228, 215)
        val phoneGreenText = Color.rgb(0, 102, 68)
        val swadhyaiBoxBg = Color.rgb(255, 250, 240)

        // Paints
        val bgPaint = Paint().apply {
            color = bgCanvasColor
            style = Paint.Style.FILL
        }

        val cardBgPaint = Paint().apply {
            color = cardBgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val cardHeaderBgPaint = Paint().apply {
            color = cardHeaderBgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val outerBorderPaint = Paint().apply {
            color = outerBorderColor
            style = Paint.Style.STROKE
            strokeWidth = 3f
            isAntiAlias = true
        }

        val innerGoldBorderPaint = Paint().apply {
            color = innerGoldColor
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val cardBorderPaint = Paint().apply {
            color = cardBorderColor
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val rowDividerPaint = Paint().apply {
            color = rowDividerColor
            style = Paint.Style.STROKE
            strokeWidth = 0.8f
            isAntiAlias = true
        }

        val watermarkPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            alpha = 24
        }

        val bitmapPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            isDither = true
        }

        // Text Paints
        val titlePaint = TextPaint().apply {
            color = deepMaroonColor
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val taglinePaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val diamondDividerPaint = TextPaint().apply {
            color = innerGoldColor
            textSize = 9.5f
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val bannerTextPaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 11.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val greetingPaint = TextPaint().apply {
            color = deepMaroonColor
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val sectionTitlePaint = TextPaint().apply {
            color = outerBorderColor
            textSize = 11f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val labelPaint = TextPaint().apply {
            color = labelTextColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val boldValuePaint = TextPaint().apply {
            color = valueTextColor
            textSize = 9.8f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val bodyPaint = TextPaint().apply {
            color = valueTextColor
            textSize = 9.2f
            isAntiAlias = true
        }

        val bodyBoldPaint = TextPaint().apply {
            color = valueTextColor
            textSize = 9.2f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val phonePillBgPaint = Paint().apply {
            color = phoneGreenBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val phonePillBorderPaint = Paint().apply {
            color = phoneGreenBorder
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val phoneTextPaint = TextPaint().apply {
            color = phoneGreenText
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val swadhyaiBadgeTextPaint = TextPaint().apply {
            color = Color.WHITE
            textSize = 8.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val swadhyaiNamePaint = TextPaint().apply {
            color = valueTextColor
            textSize = 12f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val swadhyaiCityPaint = TextPaint().apply {
            color = Color.rgb(90, 56, 32)
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val callHintPaint = TextPaint().apply {
            color = deepMaroonColor
            textSize = 12.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas = page.canvas

        // 1. Draw Page Background & Borders
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), pageHeight.toFloat(), bgPaint)

        val outerRect = RectF(margin, margin, pageWidth - margin, pageHeight - margin)
        canvas.drawRoundRect(outerRect, 4f, 4f, outerBorderPaint)

        val innerRect = RectF(margin + 3f, margin + 3f, pageWidth - margin - 3f, pageHeight - margin - 3f)
        canvas.drawRoundRect(innerRect, 3f, 3f, innerGoldBorderPaint)

        // 2. Draw Watermark in Background
        if (originalLogo != null) {
            val wmSize = 300f
            val wmLeft = (pageWidth - wmSize) / 2f
            val wmTop = (pageHeight - wmSize) / 2f
            val wmRect = RectF(wmLeft, wmTop, wmLeft + wmSize, wmTop + wmSize)
            canvas.drawBitmap(originalLogo, null, wmRect, watermarkPaint)
        }

        var curY = margin + 12f

        // 3. Header: Left Logo, Title, Tagline, Right Logo
        val logoSize = 46f
        val logoTop = curY
        if (originalLogo != null) {
            val leftLogoRect = RectF(margin + 12f, logoTop, margin + 12f + logoSize, logoTop + logoSize)
            canvas.drawBitmap(originalLogo, null, leftLogoRect, bitmapPaint)

            val rightLogoRect = RectF(pageWidth - margin - 12f - logoSize, logoTop, pageWidth - margin - 12f, logoTop + logoSize)
            canvas.drawBitmap(originalLogo, null, rightLogoRect, bitmapPaint)
        }

        canvas.drawText("श्री वर्द्धमान स्वाध्याय संघ", pageWidth / 2f, curY + 16f, titlePaint)

        val taglinePillWidth = 140f
        val taglinePillHeight = 14f
        val tagLeft = (pageWidth - taglinePillWidth) / 2f
        val tagTop = curY + 22f
        val tagRect = RectF(tagLeft, tagTop, tagLeft + taglinePillWidth, tagTop + taglinePillHeight)
        val tagBgPaint = Paint().apply {
            color = darkMaroonPillColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(tagRect, 7f, 7f, tagBgPaint)
        canvas.drawText("।। जिन आज्ञा परमो धर्मः ।।", pageWidth / 2f, tagTop + 10.5f, taglinePaint)

        canvas.drawText("❖ ─── • ✦ • ─── ❖", pageWidth / 2f, tagTop + 24f, diamondDividerPaint)

        curY += logoSize + 10f

        // 4. Banner Bar: "🌸 पर्वाधिराज पर्युषण आराधना – संघ जानकारी 🌸"
        val bannerHeight = 20f
        val bannerRect = RectF(margin + 10f, curY, pageWidth - margin - 10f, curY + bannerHeight)
        val bannerBgPaint = Paint().apply {
            color = deepMaroonColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(bannerRect, 4f, 4f, bannerBgPaint)
        canvas.drawRoundRect(bannerRect, 4f, 4f, innerGoldBorderPaint)
        canvas.drawText("🌸 पर्वाधिराज पर्युषण आराधना – संघ जानकारी 🌸", pageWidth / 2f, curY + 14f, bannerTextPaint)

        curY += bannerHeight + 8f

        // 5. Greeting Text
        canvas.drawText("🙏 जय जिनेंद्र ! पर्युषण महापर्व के मौके पर आपकी आराधना के लिए निम्न संघ निर्धारित किया गया है।", pageWidth / 2f, curY + 9f, greetingPaint)

        curY += 16f

        // 6. Section 1: Sangh & Location Details Box
        val sanghBoxLeft = margin + 10f
        val sanghBoxRight = pageWidth - margin - 10f
        val sanghBoxWidth = sanghBoxRight - sanghBoxLeft
        val sanghLocation = if (sangh.stateName.isNotBlank()) "${sangh.cityName}, ${sangh.stateName}" else sangh.cityName

        var contactPerson = sangh.contact1.trim()
        var sanghPhone = sangh.contact2.trim()
        if (sanghPhone.isBlank() && contactPerson.contains("\\d{10}".toRegex())) {
            val match = "\\d{10}".toRegex().find(contactPerson)
            if (match != null) {
                sanghPhone = match.value
                contactPerson = contactPerson.replace(match.value, "").trim().trim('-', ':', ',')
            }
        }
        if (contactPerson.isBlank()) contactPerson = "प्रतिनिधि / संघ मंत्री"
        if (sanghPhone.isBlank()) sanghPhone = "9303634541"

        val mulnayak = sangh.mulnayakBhagwan.ifBlank { "Shri Parasnath Bhagwan" }
        val tradition = sangh.pratikramanTradition.ifBlank { "तपागच्छ" }
        val toiletFacility = if (sangh.hasToiletFacility.trim() == "हाँ") "✅ हाँ (शौचालय की उचित व्यवस्था उपलब्ध है)" else sangh.hasToiletFacility.ifBlank { "हाँ (शौचालय की उचित व्यवस्था उपलब्ध है)" }

        val rows = listOf(
            Pair("🏛️ संघ का नाम", sangh.sanghName.ifBlank { "Jain Shwetambar Shri Sangh" }),
            Pair("📍 स्थान / राज्य", sanghLocation.ifBlank { "Singoli, Madhya Pradesh" }),
            Pair("🏠 पूरा पता", sangh.sanghAddress.ifBlank { "Murti Pooja Shri Sangh, Singoli (M.P.)" }),
            Pair("👤 संपर्क व्यक्ति", contactPerson),
            Pair("📞 मोबाइल / WhatsApp", sanghPhone),
            Pair("🛕 मूलनायक भगवान", mulnayak),
            Pair("🔍 प्रतिक्रमण परंपरा", tradition),
            Pair("🚻 पौषध शौचालय व्यवस्था", toiletFacility)
        )

        val rowHeight = 17f
        val headerHeight = 18f
        val sanghBoxHeight = headerHeight + (rows.size * rowHeight) + 4f
        val sanghCardRect = RectF(sanghBoxLeft, curY, sanghBoxRight, curY + sanghBoxHeight)

        canvas.drawRoundRect(sanghCardRect, 5f, 5f, cardBgPaint)
        canvas.drawRoundRect(sanghCardRect, 5f, 5f, cardBorderPaint)

        val headerRect = RectF(sanghBoxLeft, curY, sanghBoxRight, curY + headerHeight)
        canvas.drawRoundRect(headerRect, 5f, 5f, cardHeaderBgPaint)
        canvas.drawLine(sanghBoxLeft, curY + headerHeight, sanghBoxRight, curY + headerHeight, cardBorderPaint)
        canvas.drawText("🏛️ संघ एवं स्थान विवरण (Sangh & Location Details)", sanghBoxLeft + 8f, curY + 13f, sectionTitlePaint)

        var rY = curY + headerHeight
        val colLabelWidth = 145f
        rows.forEachIndexed { idx, pair ->
            if (idx > 0) {
                canvas.drawLine(sanghBoxLeft, rY, sanghBoxRight, rY, rowDividerPaint)
            }
            val textY = rY + 11.5f
            canvas.drawText(pair.first, sanghBoxLeft + 8f, textY, labelPaint)

            if (pair.first.contains("मोबाइल")) {
                val phoneBoxLeft = sanghBoxLeft + colLabelWidth
                val phoneBoxWidth = 90f
                val phoneBoxHeight = 13f
                val phoneBoxTop = rY + 2f
                val pRect = RectF(phoneBoxLeft, phoneBoxTop, phoneBoxLeft + phoneBoxWidth, phoneBoxTop + phoneBoxHeight)
                canvas.drawRoundRect(pRect, 3f, 3f, phonePillBgPaint)
                canvas.drawRoundRect(pRect, 3f, 3f, phonePillBorderPaint)
                canvas.drawText("📞 ${pair.second}", phoneBoxLeft + 6f, textY - 1f, phoneTextPaint)
            } else {
                canvas.drawText(pair.second, sanghBoxLeft + colLabelWidth, textY, boldValuePaint)
            }
            rY += rowHeight
        }

        curY += sanghBoxHeight + 8f

        // 7. Section 2: Two Columns Side by Side (Available Items & Special Instructions)
        val colGap = 8f
        val colWidth = (sanghBoxWidth - colGap) / 2f
        val col1Left = sanghBoxLeft
        val col1Right = col1Left + colWidth
        val col2Left = col1Right + colGap
        val col2Right = sanghBoxRight

        val rawSamagri = sangh.aradhanaSamagriList.trim()
        val samagriItems = if (rawSamagri.isBlank() || rawSamagri == "कोई नहीं") {
            listOf(
                "आचार्य भगवान (स्थापना जी - पुरुषों के लिए)",
                "आचार्य भगवान (स्थापना जी - महिलाओं के लिए)",
                "कल्पसूत्र जी",
                "बारसासूत्र जी",
                "पौषध सामग्री (दण्डासन, सुपडी, मातृ-ठल्ले की कुंडी)"
            )
        } else {
            val commaNotInParensRegex = Regex(",(?![^()]*\\))")
            rawSamagri.split(commaNotInParensRegex).map { it.trim() }.filter { it.isNotBlank() && it != "null" }
        }

        val twoColHeight = 106f

        // Left Column: Available Items
        val col1Rect = RectF(col1Left, curY, col1Right, curY + twoColHeight)
        canvas.drawRoundRect(col1Rect, 5f, 5f, cardBgPaint)
        canvas.drawRoundRect(col1Rect, 5f, 5f, cardBorderPaint)
        val col1HeaderRect = RectF(col1Left, curY, col1Right, curY + headerHeight)
        canvas.drawRoundRect(col1HeaderRect, 5f, 5f, cardHeaderBgPaint)
        canvas.drawLine(col1Left, curY + headerHeight, col1Right, curY + headerHeight, cardBorderPaint)
        canvas.drawText("✨ उपलब्ध सामग्री (Available Items)", col1Left + 8f, curY + 13f, sectionTitlePaint)

        var itemY = curY + headerHeight + 12f
        samagriItems.take(5).forEach { item ->
            canvas.drawText("✦ $item", col1Left + 8f, itemY, bodyPaint)
            itemY += 15.5f
        }

        // Right Column: Special Instructions
        val col2Rect = RectF(col2Left, curY, col2Right, curY + twoColHeight)
        canvas.drawRoundRect(col2Rect, 5f, 5f, cardBgPaint)
        canvas.drawRoundRect(col2Rect, 5f, 5f, cardBorderPaint)
        val col2HeaderRect = RectF(col2Left, curY, col2Right, curY + headerHeight)
        canvas.drawRoundRect(col2HeaderRect, 5f, 5f, cardHeaderBgPaint)
        canvas.drawLine(col2Left, curY + headerHeight, col2Right, curY + headerHeight, cardBorderPaint)
        canvas.drawText("📜 आराधना विशेष निर्देश", col2Left + 8f, curY + 13f, sectionTitlePaint)

        val rules = listOf(
            Pair("परंपरा: ", "श्री तपागच्छ विधि-विधान अनुसार आराधना"),
            Pair("आवास व्यवस्था: ", "पौषध एवं स्वाध्याय हेतु अनुकूल व्यवस्था"),
            Pair("समयबद्धता: ", "स्वाध्याय व प्रतिक्रमण समयानुसार संपन्न करें"),
            Pair("सहयोग: ", "किसी भी आवश्यकता हेतु संघ मंत्री से संपर्क करें")
        )

        var ruleY = curY + headerHeight + 12f
        rules.forEach { rule ->
            canvas.drawText("✦ ", col2Left + 8f, ruleY, bodyPaint)
            canvas.drawText(rule.first, col2Left + 16f, ruleY, bodyBoldPaint)
            val prefixWidth = bodyBoldPaint.measureText(rule.first)
            canvas.drawText(rule.second, col2Left + 16f + prefixWidth, ruleY, bodyPaint)
            ruleY += 19f
        }

        curY += twoColHeight + 8f

        // 8. Section 3: Swadhyai Team Section
        val swTeamBoxHeight = 84f
        val swTeamRect = RectF(sanghBoxLeft, curY, sanghBoxRight, curY + swTeamBoxHeight)
        canvas.drawRoundRect(swTeamRect, 5f, 5f, cardBgPaint)
        canvas.drawRoundRect(swTeamRect, 5f, 5f, cardBorderPaint)

        val swHeaderRect = RectF(sanghBoxLeft, curY, sanghBoxRight, curY + headerHeight)
        canvas.drawRoundRect(swHeaderRect, 5f, 5f, cardHeaderBgPaint)
        canvas.drawLine(sanghBoxLeft, curY + headerHeight, sanghBoxRight, curY + headerHeight, cardBorderPaint)
        canvas.drawText("👥 स्वाध्यायी टीम (Swadhyayi Team)", sanghBoxLeft + 8f, curY + 13f, sectionTitlePaint)

        val activeSwadhyais = if (swadhyaiList.isEmpty()) {
            listOf(
                SwadhyaiFormEntity(fullName = "Dinesh Jain", city = "Bhawani Mandi", whatsappNo = "9460519075"),
                SwadhyaiFormEntity(fullName = "Suresh Shah", city = "Indore", whatsappNo = "9406667980")
            )
        } else {
            swadhyaiList
        }

        val numSw = activeSwadhyais.size.coerceAtMost(3)
        val swCardGap = 8f
        val swCardWidth = (sanghBoxWidth - (swCardGap * (numSw + 1))) / numSw
        val swCardHeight = 56f
        val swCardTop = curY + headerHeight + 5f

        val swBgPaint = Paint().apply {
            color = swadhyaiBoxBg
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val hindiNums = listOf("१", "२", "३")
        activeSwadhyais.take(numSw).forEachIndexed { index, s ->
            val swLeft = sanghBoxLeft + swCardGap + (index * (swCardWidth + swCardGap))
            val swRight = swLeft + swCardWidth
            val swRect = RectF(swLeft, swCardTop, swRight, swCardTop + swCardHeight)

            canvas.drawRoundRect(swRect, 4f, 4f, swBgPaint)
            canvas.drawRoundRect(swRect, 4f, 4f, cardBorderPaint)

            // Badge
            val badgeWidth = 64f
            val badgeHeight = 11f
            val badgeLeft = (swLeft + swRight - badgeWidth) / 2f
            val badgeTop = swCardTop + 4f
            val bRect = RectF(badgeLeft, badgeTop, badgeLeft + badgeWidth, badgeTop + badgeHeight)
            val bBgPaint = Paint().apply {
                color = darkMaroonPillColor
                style = Paint.Style.FILL
                isAntiAlias = true
            }
            canvas.drawRoundRect(bRect, 5.5f, 5.5f, bBgPaint)
            val numStr = hindiNums.getOrElse(index) { "${index + 1}" }
            canvas.drawText("• स्वाध्यायी $numStr", (swLeft + swRight) / 2f, badgeTop + 8.5f, swadhyaiBadgeTextPaint)

            // Name
            canvas.drawText(s.fullName.ifBlank { "स्वाध्यायी बंधु" }, (swLeft + swRight) / 2f, swCardTop + 26f, swadhyaiNamePaint)

            // City
            val cityStr = if (s.city.isNotBlank()) "📍 ${s.city}" else "📍 भारत"
            canvas.drawText(cityStr, (swLeft + swRight) / 2f, swCardTop + 37f, swadhyaiCityPaint)

            // Phone Box
            val phone = s.whatsappNo.ifBlank { s.contactNo }.trim()
            val phoneW = 80f
            val phoneH = 12f
            val pLeft = (swLeft + swRight - phoneW) / 2f
            val pTop = swCardTop + 40.5f
            val pBoxRect = RectF(pLeft, pTop, pLeft + phoneW, pTop + phoneH)
            canvas.drawRoundRect(pBoxRect, 3f, 3f, phonePillBgPaint)
            canvas.drawRoundRect(pBoxRect, 3f, 3f, phonePillBorderPaint)

            val pText = if (phone.isNotBlank()) "📞 $phone" else "📞 9460519075"
            val pPaintCentered = TextPaint(phoneTextPaint).apply { textAlign = Paint.Align.CENTER }
            canvas.drawText(pText, (swLeft + swRight) / 2f, pTop + 9f, pPaintCentered)
        }

        curY += swTeamBoxHeight + 8f

        // 9. Bottom Blessing Banner
        val blessHeight = 20f
        val blessRect = RectF(sanghBoxLeft, curY, sanghBoxRight, curY + blessHeight)
        val blessBgPaint = Paint().apply {
            color = Color.rgb(255, 246, 232)
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawRoundRect(blessRect, 4f, 4f, blessBgPaint)
        canvas.drawRoundRect(blessRect, 4f, 4f, cardBorderPaint)
        canvas.drawText("🙏 जय जिनेंद्र! पर्युषण महापर्व आप सभी के लिए आत्म-कल्याणकारी एवं मंगलमय हो 🌼", pageWidth / 2f, curY + 13.5f, greetingPaint)

        curY += blessHeight + 12f

        // 10. Prominent Call Hint directly below Blessing Banner with larger font size
        canvas.drawText("फोन लगाने के लिए 📞 नंबर पर टैप करें।", pageWidth / 2f, curY + 12f, callHintPaint)

        pdfDocument.finishPage(page)

        val cleanSanghName = sangh.sanghName.replace("[^a-zA-Z0-9_\\u0900-\\u097F]".toRegex(), "_").take(30)
        val fileName = "Swadhyai_Allotment_${cleanSanghName}_${System.currentTimeMillis()}.pdf"
        val outputFile = File(context.cacheDir, fileName)
        if (outputFile.exists()) outputFile.delete()

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }
        pdfDocument.close()

        // Inject clickable PDF Link Annotations for external PDF readers
        val clickableRegions = getPhoneClickableRegions(sangh, swadhyaiList)
        injectLinkAnnotations(outputFile, clickableRegions, pageHeight.toFloat())

        saveToPublicDownloads(context, outputFile, fileName)
        return outputFile
    }

    private fun injectLinkAnnotations(pdfFile: File, links: List<PdfPhoneClickableRegion>, pageHeight: Float = 842f) {
        if (links.isEmpty()) return
        try {
            val bytes = pdfFile.readBytes()
            val content = String(bytes, Charsets.ISO_8859_1)

            val annotsSb = StringBuilder()
            annotsSb.append("/Annots [")
            for (link in links) {
                val cleanDigits = link.phone.filter { it.isDigit() }
                if (cleanDigits.length < 6) continue
                val llx = String.format(Locale.US, "%.2f", link.bounds.left)
                val lly = String.format(Locale.US, "%.2f", pageHeight - link.bounds.bottom)
                val urx = String.format(Locale.US, "%.2f", link.bounds.right)
                val ury = String.format(Locale.US, "%.2f", pageHeight - link.bounds.top)

                annotsSb.append(" << /Type /Annot /Subtype /Link /Rect [ $llx $lly $urx $ury ] /Border [ 0 0 0 ] /A << /Type /Action /S /URI /URI (tel:$cleanDigits) >> >>")
            }
            annotsSb.append(" ]")

            val pageIndex = content.indexOf("/Type /Page")
            if (pageIndex != -1) {
                val nextObj = content.indexOf("endobj", pageIndex)
                if (nextObj != -1) {
                    val insertPos = content.lastIndexOf(">>", nextObj)
                    if (insertPos != -1) {
                        val updatedContent = content.substring(0, insertPos) + " " + annotsSb.toString() + " " + content.substring(insertPos)
                        pdfFile.writeBytes(updatedContent.toByteArray(Charsets.ISO_8859_1))
                    }
                }
            }
        } catch (e: Exception) {
            // Non-fatal if annotation injection fails
        }
    }

    private fun saveToPublicDownloads(context: Context, sourceFile: File, fileName: String) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/VardhmanSwadhyaySangh")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                if (uri != null) {
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        FileInputStream(sourceFile).use { input ->
                            input.copyTo(out)
                        }
                    }
                }
            } else {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val targetDir = File(downloadsDir, "VardhmanSwadhyaySangh")
                if (!targetDir.exists()) targetDir.mkdirs()
                val destFile = File(targetDir, fileName)
                FileInputStream(sourceFile).use { input ->
                    FileOutputStream(destFile).use { out ->
                        input.copyTo(out)
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
    }
}

