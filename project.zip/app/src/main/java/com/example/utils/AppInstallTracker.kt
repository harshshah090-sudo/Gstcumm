package com.example.utils

import android.content.Context
import android.content.SharedPreferences

object AppInstallTracker {
    private const val PREFS_NAME = "app_install_baseline_prefs"
    private const val KEY_INSTALL_BASELINE = "app_install_baseline_ts"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Initializes the installation baseline timestamp on first run if not already set.
     */
    fun init(context: Context) {
        getInstallBaselineTimestamp(context)
    }

    /**
     * Returns the timestamp (in epoch milliseconds) when this app was first installed/opened
     * on this device.
     * Past changes or updates prior to this timestamp are strictly ignored for notifications.
     */
    fun getInstallBaselineTimestamp(context: Context): Long {
        val prefs = getPrefs(context)
        var baseline = prefs.getLong(KEY_INSTALL_BASELINE, 0L)
        if (baseline == 0L) {
            baseline = System.currentTimeMillis()
            prefs.edit().putLong(KEY_INSTALL_BASELINE, baseline).apply()
        }
        return baseline
    }

    /**
     * Checks if a given event/update occurred strictly after the app was installed on this device.
     */
    fun isAfterInstall(context: Context, eventTimestamp: Long): Boolean {
        if (eventTimestamp <= 0L) return false
        val baseline = getInstallBaselineTimestamp(context)
        return eventTimestamp > baseline
    }
}
