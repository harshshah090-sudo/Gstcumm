package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.AppNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object AppNotificationHelper {

    private const val TAG = "AppNotificationHelper"
    private const val CHANNEL_ID = "svsm_updates_channel"

    /**
     * Create the unified high-priority notification channel
     */
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "SVSM Community Updates"
            val descriptionText = "Notifications for Gyan Shala notes and Swadhyai registrations"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * Triggers a notification:
     * 1. Saves it into Room database `app_notifications`
     * 2. Fires a system status bar notification if permitted
     * NOTE: Strictly ignores past changes/updates that occurred before the app installation baseline.
     * NOTE: The author/editor of the note NEVER receives device or in-app notifications.
     */
    fun notifyGyanNote(
        context: Context,
        categoryId: Long,
        topicId: Long,
        categoryName: String,
        topicTitle: String,
        contentSnippet: String,
        isEdit: Boolean,
        eventTimestamp: Long = System.currentTimeMillis(),
        authorInstallId: String = "",
        authorPhone: String = ""
    ) {
        val appContext = context.applicationContext

        // 1. STRICT AUTHOR EXCLUSION:
        // The user who creates or edits the note must NEVER get a notification on the device or inside the app.
        val myInstallId = AppInstallTracker.getInstallationId(appContext)
        val myPhone = com.example.data.UserSessionManager.sessionState.value.phone.trim()

        val isAuthor = (authorInstallId.isNotBlank() && authorInstallId == myInstallId) ||
                       (authorPhone.isNotBlank() && myPhone.isNotBlank() && authorPhone == myPhone) ||
                       GyanSeenTracker.isTopicAuthoredLocally(appContext, topicId, eventTimestamp)

        if (isAuthor) {
            Log.d(TAG, "Skipping Gyan note notification: current user/device is the author/editor (topicId=$topicId)")
            return
        }

        if (!AppInstallTracker.isAfterInstall(appContext, eventTimestamp)) {
            Log.d(TAG, "Ignoring past Gyan note update prior to app install baseline: $topicTitle ($eventTimestamp)")
            return
        }

        val title = if (isEdit) {
            "Gyan Shala: Note Updated"
        } else {
            "Gyan Shala: New Note Added"
        }
        val preview = if (topicTitle.isNotBlank()) {
            "$categoryName • $topicTitle: $contentSnippet"
        } else {
            "$categoryName: $contentSnippet"
        }

        val appNotification = AppNotification(
            type = "GYAN_NOTE",
            title = title,
            message = preview.trim(),
            targetId = topicId.toString(),
            targetExtraId = categoryId.toString(),
            timestamp = eventTimestamp,
            isSeen = false
        )

        saveAndPost(appContext, appNotification, destination = "gyan_shala")
    }

    fun notifySwadhyaiRegistration(
        context: Context,
        swadhyaiId: Long,
        swadhyaiName: String,
        city: String,
        isEdit: Boolean,
        eventTimestamp: Long = System.currentTimeMillis(),
        updatedFields: String = ""
    ) {
        if (!AppInstallTracker.isAfterInstall(context, eventTimestamp)) {
            Log.d(TAG, "Ignoring past Swadhyai update prior to app install baseline: $swadhyaiName ($eventTimestamp)")
            return
        }

        val title = if (isEdit) {
            "Swadhyai Profile Updated"
        } else {
            "New Swadhyai Registered"
        }

        val fieldSummary = if (isEdit && updatedFields.isNotBlank()) {
            formatUpdatedFieldsSummary(updatedFields)
        } else ""

        val preview = if (isEdit && fieldSummary.isNotBlank()) {
            if (city.isNotBlank()) {
                "$swadhyaiName ($city) updated $fieldSummary."
            } else {
                "$swadhyaiName updated $fieldSummary."
            }
        } else if (city.isNotBlank()) {
            "$swadhyaiName ($city) has been ${if (isEdit) "updated" else "registered"} in Swadhyayi Mandal."
        } else {
            "$swadhyaiName has been ${if (isEdit) "updated" else "registered"} in Swadhyayi Mandal."
        }

        val appNotification = AppNotification(
            type = "SWADHYAI_REGISTRATION",
            title = title,
            message = preview.trim(),
            targetId = swadhyaiId.toString(),
            targetExtraId = updatedFields,
            timestamp = eventTimestamp,
            isSeen = false
        )

        saveAndPost(context, appNotification, destination = "swadhyai_registrations")
    }

    fun formatUpdatedFieldsSummary(updatedFields: String): String {
        val tokens = updatedFields.split(",").map { it.trim() }.filter { it.isNotBlank() }
        val summaries = linkedSetOf<String>()
        tokens.forEach { token ->
            when (token) {
                "contactNo", "whatsappNo", "email" -> summaries.add("contact details")
                "address", "city", "state", "pincode", "nativePlace" -> summaries.add("address")
                "emergencyContact", "emergencyContactName", "emergencyContactRelation", "emergencyContactNo" -> summaries.add("emergency contact")
                "religiousLearnings" -> summaries.add("religious learnings")
                "dailyRoutineActivities" -> summaries.add("daily routine")
                "lifetimeTapasya" -> summaries.add("lifetime tapasya")
                "specialities" -> summaries.add("specialities")
                "paryushanCount" -> summaries.add("paryushan count")
                "joiningYear" -> summaries.add("joining year")
                "education" -> summaries.add("education")
                "workingStatus", "workDescription" -> summaries.add("profession")
                "profileImageUri", "photo" -> summaries.add("profile photo")
                "fullName" -> summaries.add("name")
                "dob", "age" -> summaries.add("personal details")
                "bloodGroup" -> summaries.add("blood group")
                "maritalStatus", "anniversaryDate" -> summaries.add("marital status")
                "anotherGroup", "postInGroup" -> summaries.add("group details")
                "paryushanWillingness" -> summaries.add("paryushan willingness")
                "remarks" -> summaries.add("remarks")
            }
        }
        return if (summaries.isNotEmpty()) summaries.take(3).joinToString(", ") else "profile details"
    }

    private fun saveAndPost(context: Context, notification: AppNotification, destination: String) {
        val appContext = context.applicationContext
        if (!AppInstallTracker.isAfterInstall(appContext, notification.timestamp)) {
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(appContext)
                val existingCount = db.appNotificationDao().countByTargetAndTimestamp(
                    type = notification.type,
                    targetId = notification.targetId,
                    timestamp = notification.timestamp
                )
                if (existingCount > 0) {
                    Log.d(TAG, "Notification already recorded for ${notification.type} ${notification.targetId} at ${notification.timestamp}, skipping.")
                    return@launch
                }

                val insertedId = db.appNotificationDao().insertNotification(notification)
                val finalNotification = notification.copy(id = insertedId)

                // Dispatch Android System notification
                postDeviceNotification(appContext, finalNotification, destination)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save or post notification: ${e.message}", e)
            }
        }
    }

    fun postDeviceNotification(context: Context, notification: AppNotification, destination: String) {
        if (!AppInstallTracker.isAfterInstall(context, notification.timestamp)) {
            return
        }
        try {
            createNotificationChannel(context)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("destination", destination)
                putExtra("notification_id", notification.id)
                putExtra("notification_type", notification.type)
                putExtra("target_id", notification.targetId)
                putExtra("target_extra_id", notification.targetExtraId)
                if (destination == "gyan_shala") {
                    putExtra("target_category_id", notification.targetExtraId.toLongOrNull() ?: -1L)
                    putExtra("target_topic_id", notification.targetId.toLongOrNull() ?: -1L)
                } else if (destination == "swadhyai_registrations") {
                    putExtra("target_swadhyai_id", notification.targetId.toLongOrNull() ?: -1L)
                }
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                (notification.id.toInt().takeIf { it != 0 } ?: (System.currentTimeMillis() % 100000).toInt()),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(notification.title)
                .setContentText(notification.message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(notification.message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val sysNotifId = (notification.id.toInt().takeIf { it != 0 } ?: (notification.targetId.hashCode() + notification.type.hashCode()))
            notificationManager.notify(sysNotifId, builder.build())
        } catch (e: Exception) {
            Log.e(TAG, "Error showing system notification: ${e.message}")
        }
    }
}
