package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.AppDatabase
import com.example.data.AppNotification
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object AppNotificationHelper {

    private const val TAG = "AppNotificationHelper"
    private const val CHANNEL_ID = "svsm_updates_channel"

    /**
     * Create the unified high-priority notification channel
     */
    fun createNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "SVSM Community Updates"
            val descriptionText = "Notifications for Gyan Shala notes and Swadhyai registrations"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
                enableVibration(true)
                setShowBadge(true)
            }
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    /**
     * Triggers a notification:
     * 1. Saves it into Room database `app_notifications`
     * 2. Fires a system status bar notification if permitted
     * NOTE: Strictly ignores past changes/updates that occurred before the app installation baseline.
     */
    fun notifyGyanNote(
        context: Context,
        categoryId: Long,
        topicId: Long,
        categoryName: String,
        topicTitle: String,
        contentSnippet: String,
        isEdit: Boolean,
        eventTimestamp: Long = System.currentTimeMillis()
    ) {
        if (!AppInstallTracker.isAfterInstall(context, eventTimestamp)) {
            Log.d(TAG, "Ignoring past Gyan note update prior to app install baseline: $topicTitle ($eventTimestamp)")
            return
        }

        val title = if (isEdit) {
            "Gyan Shala: Note Updated"
        } else {
            "Gyan Shala: New Note Added"
        }
        val preview = if (topicTitle.isNotBlank()) {
            "$categoryName • $topicTitle: $contentSnippet"
        } else {
            "$categoryName: $contentSnippet"
        }

        val appNotification = AppNotification(
            type = "GYAN_NOTE",
            title = title,
            message = preview.trim(),
            targetId = topicId.toString(),
            targetExtraId = categoryId.toString(),
            timestamp = eventTimestamp,
            isSeen = false
        )

        saveAndPost(context, appNotification, destination = "gyan_shala")
    }

    fun notifySwadhyaiRegistration(
        context: Context,
        swadhyaiId: Long,
        swadhyaiName: String,
        city: String,
        isEdit: Boolean,
        eventTimestamp: Long = System.currentTimeMillis()
    ) {
        if (!AppInstallTracker.isAfterInstall(context, eventTimestamp)) {
            Log.d(TAG, "Ignoring past Swadhyai update prior to app install baseline: $swadhyaiName ($eventTimestamp)")
            return
        }

        val title = if (isEdit) {
            "Swadhyai Profile Updated"
        } else {
            "New Swadhyai Registered"
        }
        val preview = if (city.isNotBlank()) {
            "$swadhyaiName ($city) has been ${if (isEdit) "updated" else "registered"} in Swadhyayi Mandal."
        } else {
            "$swadhyaiName has been ${if (isEdit) "updated" else "registered"} in Swadhyayi Mandal."
        }

        val appNotification = AppNotification(
            type = "SWADHYAI_REGISTRATION",
            title = title,
            message = preview.trim(),
            targetId = swadhyaiId.toString(),
            targetExtraId = "",
            timestamp = eventTimestamp,
            isSeen = false
        )

        saveAndPost(context, appNotification, destination = "swadhyai_registrations")
    }

    private fun saveAndPost(context: Context, notification: AppNotification, destination: String) {
        val appContext = context.applicationContext
        if (!AppInstallTracker.isAfterInstall(appContext, notification.timestamp)) {
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val db = AppDatabase.getDatabase(appContext)
                val insertedId = db.appNotificationDao().insertNotification(notification)
                val finalNotification = notification.copy(id = insertedId)

                // Dispatch Android System notification
                postDeviceNotification(appContext, finalNotification, destination)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save or post notification: ${e.message}", e)
            }
        }
    }

    fun postDeviceNotification(context: Context, notification: AppNotification, destination: String) {
        if (!AppInstallTracker.isAfterInstall(context, notification.timestamp)) {
            return
        }
        try {
            createNotificationChannel(context)
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("destination", destination)
                putExtra("notification_id", notification.id)
                putExtra("notification_type", notification.type)
                putExtra("target_id", notification.targetId)
                putExtra("target_extra_id", notification.targetExtraId)
                if (destination == "gyan_shala") {
                    putExtra("target_category_id", notification.targetExtraId.toLongOrNull() ?: -1L)
                    putExtra("target_topic_id", notification.targetId.toLongOrNull() ?: -1L)
                } else if (destination == "swadhyai_registrations") {
                    putExtra("target_swadhyai_id", notification.targetId.toLongOrNull() ?: -1L)
                }
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                (notification.id.toInt().takeIf { it != 0 } ?: (System.currentTimeMillis() % 100000).toInt()),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val builder = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(notification.title)
                .setContentText(notification.message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(notification.message))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)

            val sysNotifId = (notification.id.toInt().takeIf { it != 0 } ?: (notification.targetId.hashCode() + notification.type.hashCode()))
            notificationManager.notify(sysNotifId, builder.build())
        } catch (e: Exception) {
            Log.e(TAG, "Error showing system notification: ${e.message}")
        }
    }
}
