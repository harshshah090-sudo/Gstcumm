package com.example.utils

import android.util.Log
import com.example.data.CityLocation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.*

data class PachkhanItem(
    val hindiName: String,
    val subtitle: String,
    val timeFormatted: String
)

data class SolarTimings(
    val sunrise: String,      // e.g. "06:18 AM"
    val sunset: String,       // e.g. "07:08 PM"
    val navkarshi: String,    // e.g. "07:06 AM" (Sunrise + 48 min)
    val porsi: String = "",
    val sadhPorsi: String = "",
    val purimuddh: String = "",
    val avaddh: String = "",
    val pachkhanList: List<PachkhanItem> = emptyList(),
    val isFromOnline: Boolean = false
)

object SolarTimingCalculator {
    private const val TAG = "SolarTimingCalculator"

    // Cache: "cityId_yyyy-MM-dd" -> SolarTimings
    private val memoryCache = ConcurrentHashMap<String, SolarTimings>()

    fun formatMinutesToTime(totalMinutes: Double): String {
        val totalM = ((totalMinutes.roundToInt() % 1440) + 1440) % 1440
        val h24 = (totalM / 60) % 24
        val m = totalM % 60
        val amPm = if (h24 < 12) "AM" else "PM"
        val h12 = if (h24 == 0) 12 else if (h24 > 12) h24 - 12 else h24
        return String.format(Locale.ENGLISH, "%02d:%02d %s", h12, m, amPm)
    }

    fun buildPachkhanList(sunriseMinutes: Double, sunsetMinutes: Double): List<PachkhanItem> {
        var dayLength = sunsetMinutes - sunriseMinutes
        if (dayLength <= 0) {
            dayLength = (sunsetMinutes + 1440 - sunriseMinutes) % 1440
        }
        if (dayLength <= 0) {
            dayLength = 720.0 // Default 12 hours
        }

        val navkarshiMin = (sunriseMinutes + 48.0) % 1440
        val porsiMin = (sunriseMinutes + dayLength * 0.25) % 1440
        val sadhPorsiMin = (sunriseMinutes + dayLength * 0.375) % 1440
        val purimuddhMin = (sunriseMinutes + dayLength * 0.5) % 1440
        val avaddhMin = (sunriseMinutes + dayLength * 0.75) % 1440

        return listOf(
            PachkhanItem(
                hindiName = "नवकारशी",
                subtitle = "सूर्योदय + ४८ मि.",
                timeFormatted = formatMinutesToTime(navkarshiMin)
            ),
            PachkhanItem(
                hindiName = "पोरसी",
                subtitle = "१ प्रहर (१/४ दिन)",
                timeFormatted = formatMinutesToTime(porsiMin)
            ),
            PachkhanItem(
                hindiName = "साढ पोरसी",
                subtitle = "१.५ प्रहर (३/८ दिन)",
                timeFormatted = formatMinutesToTime(sadhPorsiMin)
            ),
            PachkhanItem(
                hindiName = "पुरिमुड्ढ",
                subtitle = "२ प्रहर (१/२ दिन)",
                timeFormatted = formatMinutesToTime(purimuddhMin)
            ),
            PachkhanItem(
                hindiName = "अवड्ढ",
                subtitle = "३ प्रहर (३/४ दिन)",
                timeFormatted = formatMinutesToTime(avaddhMin)
            )
        )
    }

    /**
     * Calculates solar timings offline using the standard NOAA solar position algorithm,
     * ensuring immediate and accurate response anytime.
     */
    fun calculateLocalSolarTimings(
        calendar: Calendar,
        city: CityLocation
    ): SolarTimings {
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone(city.timezoneId)
        }.format(calendar.time)

        val cacheKey = "${city.id}_$dateKey"
        memoryCache[cacheKey]?.let { return it }

        val calYear = calendar.get(Calendar.YEAR)
        val calMonth = calendar.get(Calendar.MONTH) + 1
        val calDay = calendar.get(Calendar.DAY_OF_MONTH)

        val times = computeNoaaTimes(calYear, calMonth, calDay, city.latitude, city.longitude, city.timezoneId)
        val pachList = buildPachkhanList(times.sunriseMinutes, times.sunsetMinutes)

        val timings = SolarTimings(
            sunrise = times.sunriseStr,
            sunset = times.sunsetStr,
            navkarshi = times.navkarshiStr,
            porsi = pachList.getOrNull(1)?.timeFormatted ?: "",
            sadhPorsi = pachList.getOrNull(2)?.timeFormatted ?: "",
            purimuddh = pachList.getOrNull(3)?.timeFormatted ?: "",
            avaddh = pachList.getOrNull(4)?.timeFormatted ?: "",
            pachkhanList = pachList,
            isFromOnline = false
        )
        memoryCache[cacheKey] = timings
        return timings
    }

    /**
     * Fetches live online sunrise & sunset timing for the city and date from standard solar search API,
     * falling back to the NOAA algorithm if offline.
     */
    suspend fun getLiveSolarTimings(
        calendar: Calendar,
        city: CityLocation
    ): SolarTimings = withContext(Dispatchers.IO) {
        val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
            timeZone = TimeZone.getTimeZone(city.timezoneId)
        }.format(calendar.time)

        val cacheKey = "${city.id}_$dateKey"
        memoryCache[cacheKey]?.let { return@withContext it }

        // Attempt online lookup first
        try {
            val urlString = "https://api.open-meteo.com/v1/forecast?latitude=${city.latitude}&longitude=${city.longitude}&daily=sunrise,sunset&timezone=${city.timezoneId}&start_date=$dateKey&end_date=$dateKey"
            val url = URL(urlString)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 4000
                requestMethod = "GET"
            }

            if (connection.responseCode == 200) {
                val reader = BufferedReader(InputStreamReader(connection.inputStream))
                val response = reader.readText()
                reader.close()

                val json = JSONObject(response)
                val daily = json.optJSONObject("daily")
                if (daily != null) {
                    val sunriseArr = daily.optJSONArray("sunrise")
                    val sunsetArr = daily.optJSONArray("sunset")
                    if (sunriseArr != null && sunriseArr.length() > 0 && sunsetArr != null && sunsetArr.length() > 0) {
                        val rawSunrise = sunriseArr.getString(0) // e.g. "2026-08-21T06:17"
                        val rawSunset = sunsetArr.getString(0)

                        val isoFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).apply {
                            timeZone = TimeZone.getTimeZone(city.timezoneId)
                        }
                        val timeFormat = SimpleDateFormat("hh:mm a", Locale.ENGLISH).apply {
                            timeZone = TimeZone.getTimeZone(city.timezoneId)
                        }

                        val sunriseDate = isoFormat.parse(rawSunrise)
                        val sunsetDate = isoFormat.parse(rawSunset)

                        if (sunriseDate != null && sunsetDate != null) {
                            val sunriseStr = timeFormat.format(sunriseDate)
                            val sunsetStr = timeFormat.format(sunsetDate)

                            val calRise = Calendar.getInstance(TimeZone.getTimeZone(city.timezoneId)).apply { time = sunriseDate }
                            val riseMin = calRise.get(Calendar.HOUR_OF_DAY) * 60.0 + calRise.get(Calendar.MINUTE)

                            val calSet = Calendar.getInstance(TimeZone.getTimeZone(city.timezoneId)).apply { time = sunsetDate }
                            val setMin = calSet.get(Calendar.HOUR_OF_DAY) * 60.0 + calSet.get(Calendar.MINUTE)

                            val pachList = buildPachkhanList(riseMin, setMin)

                            val onlineTimings = SolarTimings(
                                sunrise = sunriseStr,
                                sunset = sunsetStr,
                                navkarshi = pachList.getOrNull(0)?.timeFormatted ?: "",
                                porsi = pachList.getOrNull(1)?.timeFormatted ?: "",
                                sadhPorsi = pachList.getOrNull(2)?.timeFormatted ?: "",
                                purimuddh = pachList.getOrNull(3)?.timeFormatted ?: "",
                                avaddh = pachList.getOrNull(4)?.timeFormatted ?: "",
                                pachkhanList = pachList,
                                isFromOnline = true
                            )
                            memoryCache[cacheKey] = onlineTimings
                            return@withContext onlineTimings
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "Online solar fetch fallback to NOAA: ${e.message}")
        }

        // Fallback to high-precision NOAA algorithm
        return@withContext calculateLocalSolarTimings(calendar, city)
    }

    private data class NoaaResult(
        val sunriseStr: String,
        val sunsetStr: String,
        val navkarshiStr: String,
        val sunriseMinutes: Double,
        val sunsetMinutes: Double
    )

    /**
     * NOAA Solar Calculation implementation
     */
    private fun computeNoaaTimes(
        year: Int, month: Int, day: Int,
        lat: Double, lng: Double,
        timezoneId: String
    ): NoaaResult {
        val tz = TimeZone.getTimeZone(timezoneId)
        val tzOffsetHours = tz.rawOffset / (1000.0 * 60.0 * 60.0)

        // Day of Year
        val cal = Calendar.getInstance(tz).apply {
            set(year, month - 1, day, 12, 0, 0)
        }
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)

        // Fractional year in radians
        val gamma = 2 * Math.PI / 365.0 * (dayOfYear - 1 + (12.0 - 12.0) / 24.0)

        // Equation of time in minutes
        val eqtime = 229.18 * (0.000075 + 0.001868 * cos(gamma) - 0.032077 * sin(gamma) - 0.014615 * cos(2 * gamma) - 0.040849 * sin(2 * gamma))

        // Solar declination angle in radians
        val decl = 0.006918 - 0.399912 * cos(gamma) + 0.070257 * sin(gamma) - 0.006758 * cos(2 * gamma) + 0.000907 * sin(2 * gamma) - 0.002697 * cos(3 * gamma) + 0.00148 * sin(3 * gamma)

        val zenithRad = Math.toRadians(90.833) // Atmospheric refraction + solar disc
        val latRad = Math.toRadians(lat)

        val cosHA = (cos(zenithRad) - sin(latRad) * sin(decl)) / (cos(latRad) * cos(decl))
        val haRad = if (cosHA > 1.0) 0.0 else if (cosHA < -1.0) Math.PI else acos(cosHA)
        val haDeg = Math.toDegrees(haRad)

        // Sunrise & Sunset in UTC minutes from midnight
        val sunriseUtcMinutes = 720.0 - 4.0 * lng - eqtime - 4.0 * haDeg
        val sunsetUtcMinutes = 720.0 - 4.0 * lng - eqtime + 4.0 * haDeg

        // Convert to Local Minutes
        val sunriseLocalMinutes = ((sunriseUtcMinutes + tzOffsetHours * 60.0) % 1440 + 1440) % 1440
        val sunsetLocalMinutes = ((sunsetUtcMinutes + tzOffsetHours * 60.0) % 1440 + 1440) % 1440
        val navkarshiLocalMinutes = (sunriseLocalMinutes + 48.0) % 1440

        val sunriseStr = formatMinutesToTime(sunriseLocalMinutes)
        val sunsetStr = formatMinutesToTime(sunsetLocalMinutes)
        val navkarshiStr = formatMinutesToTime(navkarshiLocalMinutes)

        return NoaaResult(
            sunriseStr = sunriseStr,
            sunsetStr = sunsetStr,
            navkarshiStr = navkarshiStr,
            sunriseMinutes = sunriseLocalMinutes,
            sunsetMinutes = sunsetLocalMinutes
        )
    }
}
