package com.example.utils

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.PanchangEventEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object PanchangNotificationHelper {

    private const val PREFS_NAME = "panchang_notification_prefs"
    const val KEY_MASTER_ENABLED = "master_notifications_enabled"
    const val KEY_KALYANAK_ENABLED = "kalyanak_notifications_enabled"
    const val KEY_EVENTS_ENABLED = "events_notifications_enabled"
    const val KEY_PARVA_ENABLED = "parva_notifications_enabled"
    const val KEY_IMPORTANT_TITHI_ENABLED = "important_tithi_notifications_enabled"
    const val KEY_REMINDER_TIMINGS = "reminder_timing_modes_set" // Set<String>: "1_DAY_BEFORE_8PM", "1_DAY_BEFORE_7AM", "SAME_DAY_6AM"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun isMasterEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_MASTER_ENABLED, true)
    fun setMasterEnabled(context: Context, enabled: Boolean) = getPrefs(context).edit().putBoolean(KEY_MASTER_ENABLED, enabled).apply()

    fun isKalyanakEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_KALYANAK_ENABLED, true)
    fun setKalyanakEnabled(context: Context, enabled: Boolean) = getPrefs(context).edit().putBoolean(KEY_KALYANAK_ENABLED, enabled).apply()

    fun isEventsEnabled(context: Context): Boolean {
        val prefs = getPrefs(context)
        return if (prefs.contains(KEY_EVENTS_ENABLED)) {
            prefs.getBoolean(KEY_EVENTS_ENABLED, true)
        } else {
            prefs.getBoolean(KEY_PARVA_ENABLED, true)
        }
    }
    fun setEventsEnabled(context: Context, enabled: Boolean) {
        getPrefs(context).edit()
            .putBoolean(KEY_EVENTS_ENABLED, enabled)
            .putBoolean(KEY_PARVA_ENABLED, enabled)
            .apply()
    }

    fun isParvaEnabled(context: Context): Boolean = isEventsEnabled(context)
    fun setParvaEnabled(context: Context, enabled: Boolean) = setEventsEnabled(context, enabled)

    fun isImportantTithiEnabled(context: Context): Boolean = getPrefs(context).getBoolean(KEY_IMPORTANT_TITHI_ENABLED, true)
    fun setImportantTithiEnabled(context: Context, enabled: Boolean) = getPrefs(context).edit().putBoolean(KEY_IMPORTANT_TITHI_ENABLED, enabled).apply()

    fun getReminderTimings(context: Context): Set<String> {
        val set = getPrefs(context).getStringSet(KEY_REMINDER_TIMINGS, null)
        if (set != null) return set
        // Fallback for legacy single preference
        val legacy = getPrefs(context).getString("reminder_timing_mode", "1_DAY_BEFORE_8PM") ?: "1_DAY_BEFORE_8PM"
        return setOf(legacy)
    }

    fun setReminderTimings(context: Context, timings: Set<String>) {
        getPrefs(context).edit().putStringSet(KEY_REMINDER_TIMINGS, timings).apply()
    }

    fun sendTestNotification(context: Context) {
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "panchang_event_alerts"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Jain Panchang Event Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for Kalyanaks, Parvas, and Special Tithis"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val tapIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            999,
            tapIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("✨ Jain Panchang Test Alert")
            .setContentText("Notification service active! You will receive reminders before Kalyanaks & special events.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setDefaults(NotificationCompat.DEFAULT_ALL)

        try {
            notificationManager.notify(9999, builder.build())
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun scheduleNotificationsForEvents(context: Context, events: List<PanchangEventEntity>): Int {
        if (!isMasterEnabled(context)) return 0

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return 0
        val notifyKalyanak = isKalyanakEnabled(context)
        val notifyEvents = isEventsEnabled(context)
        val notifyTithi = isImportantTithiEnabled(context)
        val selectedTimings = getReminderTimings(context)
        if (selectedTimings.isEmpty()) return 0

        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val todayStr = sdf.format(Date())

        var count = 0

        events.forEach { event ->
            // Check if this event qualifies based on settings
            val isKalyanak = event.kalyanaks.isNotBlank()
            val isEvent = event.parvasAndEvents.isNotBlank()
            val isImportantTithi = event.isImportantTithi

            val shouldNotify = (isKalyanak && notifyKalyanak) ||
                    (isEvent && notifyEvents) ||
                    (isImportantTithi && notifyTithi)

            if (shouldNotify) {
                try {
                    val eventDate = sdf.parse(event.dateString) ?: return@forEach

                    selectedTimings.forEach { timingMode ->
                        // Determine notification trigger time based on timingMode
                        val triggerCal = Calendar.getInstance().apply { time = eventDate }
                        triggerCal.set(Calendar.MILLISECOND, 0)
                        when (timingMode) {
                            "1_DAY_BEFORE_8PM" -> {
                                triggerCal.add(Calendar.DAY_OF_YEAR, -1)
                                triggerCal.set(Calendar.HOUR_OF_DAY, 20)
                                triggerCal.set(Calendar.MINUTE, 0)
                                triggerCal.set(Calendar.SECOND, 0)
                            }
                            "1_DAY_BEFORE_7AM" -> {
                                triggerCal.add(Calendar.DAY_OF_YEAR, -1)
                                triggerCal.set(Calendar.HOUR_OF_DAY, 7)
                                triggerCal.set(Calendar.MINUTE, 0)
                                triggerCal.set(Calendar.SECOND, 0)
                            }
                            "SAME_DAY_8AM" -> {
                                triggerCal.set(Calendar.HOUR_OF_DAY, 8)
                                triggerCal.set(Calendar.MINUTE, 0)
                                triggerCal.set(Calendar.SECOND, 0)
                            }
                            else -> { // "SAME_DAY_6AM"
                                triggerCal.set(Calendar.HOUR_OF_DAY, 6)
                                triggerCal.set(Calendar.MINUTE, 0)
                                triggerCal.set(Calendar.SECOND, 0)
                            }
                        }

                        // Only schedule future alarms
                        if (triggerCal.timeInMillis > System.currentTimeMillis()) {
                            val title = when {
                                isKalyanak -> "✨ Kalyanak Alert: ${event.kalyanaks}"
                                isEvent -> "🚩 Event Reminder: ${event.parvasAndEvents}"
                                else -> "📌 Important Tithi Alert: ${event.tithi}"
                            }

                            val message = buildString {
                                if (timingMode.startsWith("1_DAY_BEFORE")) {
                                    append("Tomorrow is ${event.tithi}.")
                                } else {
                                    append("Today is ${event.tithi}.")
                                }
                                if (event.parvasAndEvents.isNotBlank()) append(" Event: ${event.parvasAndEvents}.")
                                if (event.kalyanaks.isNotBlank()) append(" Kalyanak: ${event.kalyanaks}.")
                            }

                            val requestCode = (event.dateString + timingMode + event.id).hashCode().let { Math.abs(it) }

                            val intent = Intent(context, PanchangNotificationReceiver::class.java).apply {
                                putExtra("title", title)
                                putExtra("message", message)
                                putExtra("notificationId", requestCode)
                            }

                            val pendingIntent = PendingIntent.getBroadcast(
                                context,
                                requestCode,
                                intent,
                                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                            )

                            val canScheduleExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                alarmManager.canScheduleExactAlarms()
                            } else {
                                true
                            }

                            if (canScheduleExact) {
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                    alarmManager.setExactAndAllowWhileIdle(
                                        AlarmManager.RTC_WAKEUP,
                                        triggerCal.timeInMillis,
                                        pendingIntent
                                    )
                                } else {
                                    alarmManager.setExact(
                                        AlarmManager.RTC_WAKEUP,
                                        triggerCal.timeInMillis,
                                        pendingIntent
                                    )
                                }
                            } else {
                                try {
                                    val clockInfo = AlarmManager.AlarmClockInfo(triggerCal.timeInMillis, pendingIntent)
                                    alarmManager.setAlarmClock(clockInfo, pendingIntent)
                                } catch (e: Exception) {
                                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                        alarmManager.setAndAllowWhileIdle(
                                            AlarmManager.RTC_WAKEUP,
                                            triggerCal.timeInMillis,
                                            pendingIntent
                                        )
                                    } else {
                                        alarmManager.set(
                                            AlarmManager.RTC_WAKEUP,
                                            triggerCal.timeInMillis,
                                            pendingIntent
                                        )
                                    }
                                }
                            }

                            count++
                        }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        return count
    }
}
