package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import com.example.R
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class SanghPdfItem(
    val sNo: Int,
    val sanghName: String,
    val sanghCityState: String,
    val sanghContactName: String,
    val sanghContactPhone: String,
    val swadhyaiListText: List<String>
)

object SanghPdfGenerator {

    fun generatePdf(context: Context, items: List<SanghPdfItem>): File {
        val pdfDocument = PdfDocument()

        val pageWidth = 595
        val pageHeight = 842
        val margin = 36f

        val logoOptions = BitmapFactory.Options().apply {
            inScaled = false
        }
        val originalLogo = BitmapFactory.decodeResource(context.resources, R.drawable.header_logo, logoOptions)

        val watermarkPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            alpha = 48
        }

        val bitmapPaint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            isDither = true
        }

        val primaryColor = Color.rgb(139, 0, 0)
        val headerBgColor = Color.rgb(245, 240, 235)
        val borderColor = Color.rgb(200, 200, 200)
        val darkTextColor = Color.rgb(33, 33, 33)
        val secondaryTextColor = Color.rgb(100, 100, 100)

        val borderPaint = Paint().apply {
            color = borderColor
            style = Paint.Style.STROKE
            strokeWidth = 1f
            isAntiAlias = true
        }

        val headerBgPaint = Paint().apply {
            color = headerBgColor
            style = Paint.Style.FILL
            isAntiAlias = true
        }

        val headerTitlePaint = TextPaint().apply {
            color = primaryColor
            textSize = 21f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val headerSubtextPaint = TextPaint().apply {
            color = primaryColor
            textSize = 13f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val docTitlePaint = TextPaint().apply {
            color = primaryColor
            textSize = 15f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
        }

        val docSubtextPaint = TextPaint().apply {
            color = secondaryTextColor
            textSize = 9.5f
            isAntiAlias = true
        }

        val tableHeaderPaint = TextPaint().apply {
            color = darkTextColor
            textSize = 10.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val cellBoldPaint = TextPaint().apply {
            color = darkTextColor
            textSize = 10f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            isAntiAlias = true
        }

        val cellRegularPaint = TextPaint().apply {
            color = darkTextColor
            textSize = 9.5f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            isAntiAlias = true
        }

        val col1Width = 35f
        val col2Width = 165f
        val col3Width = 140f
        val col4Width = 183f

        val col1Left = margin
        val col2Left = col1Left + col1Width
        val col3Left = col2Left + col2Width
        val col4Left = col3Left + col3Width

        var pageNumber = 1
        var pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
        var page = pdfDocument.startPage(pageInfo)
        var canvas = page.canvas

        fun drawWatermark(c: Canvas) {
            if (originalLogo != null) {
                val watermarkWidth = 320f
                val watermarkHeight = watermarkWidth * (originalLogo.height.toFloat() / originalLogo.width.toFloat())
                val left = (pageWidth - watermarkWidth) / 2f
                val top = (pageHeight - watermarkHeight) / 2f
                val dstRect = RectF(left, top, left + watermarkWidth, top + watermarkHeight)
                c.drawBitmap(originalLogo, null, dstRect, watermarkPaint)
            }
        }

        fun drawPageHeader(c: Canvas): Float {
            drawWatermark(c)

            var currentY = margin

            val logoSize = 58f
            if (originalLogo != null) {
                val logoRect = RectF(margin, currentY, margin + logoSize, currentY + logoSize)
                c.drawBitmap(originalLogo, null, logoRect, bitmapPaint)
            }

            c.drawText("श्री वर्द्धमान स्वाध्याय संघ", margin + logoSize + 14f, currentY + 24f, headerTitlePaint)
            c.drawText("।। जिन आज्ञा परमो धर्मः ।।", margin + logoSize + 14f, currentY + 46f, headerSubtextPaint)

            currentY += logoSize + 10f

            c.drawLine(margin, currentY, pageWidth - margin, currentY, borderPaint)

            currentY += 16f

            c.drawText("संघ एवं उनके निर्धारित स्वाध्यायियों की सूची", pageWidth / 2f, currentY, docTitlePaint)

            currentY += 14f

            val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
            val metaText = "कुल संघ: ${items.size}   |   दिनांक: $dateStr"
            c.drawText(metaText, pageWidth - margin, currentY, docSubtextPaint.apply { textAlign = Paint.Align.RIGHT })

            currentY += 12f

            return currentY
        }

        fun drawTableHeader(c: Canvas, startY: Float): Float {
            val headerHeight = 26f
            val headerRect = RectF(margin, startY, pageWidth - margin, startY + headerHeight)
            c.drawRect(headerRect, headerBgPaint)
            c.drawRect(headerRect, borderPaint)

            c.drawLine(col2Left, startY, col2Left, startY + headerHeight, borderPaint)
            c.drawLine(col3Left, startY, col3Left, startY + headerHeight, borderPaint)
            c.drawLine(col4Left, startY, col4Left, startY + headerHeight, borderPaint)

            val textY = startY + 17f

            tableHeaderPaint.textAlign = Paint.Align.CENTER
            c.drawText("क्र.सं.", col1Left + (col1Width / 2f), textY, tableHeaderPaint)

            tableHeaderPaint.textAlign = Paint.Align.LEFT
            c.drawText("संघ का नाम एवं शहर/राज्य", col2Left + 6f, textY, tableHeaderPaint)
            c.drawText("संघ संपर्क", col3Left + 6f, textY, tableHeaderPaint)
            c.drawText("निर्धारित स्वाध्यायी", col4Left + 6f, textY, tableHeaderPaint)

            return startY + headerHeight
        }

        var currentY = drawPageHeader(canvas)
        currentY = drawTableHeader(canvas, currentY)

        val cellPadding = 6f
        val pageBottomLimit = pageHeight - margin - 20f

        for (item in items) {
            val col1Text = "${item.sNo}"
            val col1Layout = StaticLayout.Builder.obtain(
                col1Text, 0, col1Text.length, cellBoldPaint.apply { textAlign = Paint.Align.CENTER },
                (col1Width - (cellPadding * 2)).toInt()
            ).setAlignment(Layout.Alignment.ALIGN_CENTER).build()

            val col2FullText = if (item.sanghCityState.isNotBlank()) "${item.sanghName}\n${item.sanghCityState}" else item.sanghName
            val col2Layout = StaticLayout.Builder.obtain(
                col2FullText, 0, col2FullText.length, cellBoldPaint.apply { textAlign = Paint.Align.LEFT },
                (col2Width - (cellPadding * 2)).toInt()
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            val col3FullText = buildString {
                if (item.sanghContactName.isNotBlank()) append(item.sanghContactName)
                if (item.sanghContactPhone.isNotBlank()) {
                    if (isNotEmpty()) append("\n")
                    append(item.sanghContactPhone)
                }
            }
            val col3Layout = StaticLayout.Builder.obtain(
                col3FullText, 0, col3FullText.length, cellRegularPaint,
                (col3Width - (cellPadding * 2)).toInt()
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            val col4FullText = if (item.swadhyaiListText.isNotEmpty()) {
                item.swadhyaiListText.joinToString("\n")
            } else {
                "कोई नहीं"
            }
            val col4Layout = StaticLayout.Builder.obtain(
                col4FullText, 0, col4FullText.length, cellRegularPaint,
                (col4Width - (cellPadding * 2)).toInt()
            ).setAlignment(Layout.Alignment.ALIGN_NORMAL).build()

            val maxTextHeight = listOf(col1Layout.height, col2Layout.height, col3Layout.height, col4Layout.height).maxOrNull() ?: 20
            val rowHeight = maxTextHeight + (cellPadding * 2)

            if (currentY + rowHeight > pageBottomLimit) {
                pdfDocument.finishPage(page)

                pageNumber++
                pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNumber).create()
                page = pdfDocument.startPage(pageInfo)
                canvas = page.canvas

                currentY = drawPageHeader(canvas)
                currentY = drawTableHeader(canvas, currentY)
            }

            val rowRect = RectF(margin, currentY, pageWidth - margin, currentY + rowHeight)
            canvas.drawRect(rowRect, borderPaint)

            canvas.drawLine(col2Left, currentY, col2Left, currentY + rowHeight, borderPaint)
            canvas.drawLine(col3Left, currentY, col3Left, currentY + rowHeight, borderPaint)
            canvas.drawLine(col4Left, currentY, col4Left, currentY + rowHeight, borderPaint)

            canvas.save()
            canvas.translate(col1Left + cellPadding, currentY + cellPadding)
            col1Layout.draw(canvas)
            canvas.restore()

            canvas.save()
            canvas.translate(col2Left + cellPadding, currentY + cellPadding)
            col2Layout.draw(canvas)
            canvas.restore()

            canvas.save()
            canvas.translate(col3Left + cellPadding, currentY + cellPadding)
            col3Layout.draw(canvas)
            canvas.restore()

            canvas.save()
            canvas.translate(col4Left + cellPadding, currentY + cellPadding)
            col4Layout.draw(canvas)
            canvas.restore()

            currentY += rowHeight
        }

        pdfDocument.finishPage(page)

        val outputFile = File(context.cacheDir, "sangh_allotment_list.pdf")
        if (outputFile.exists()) {
            outputFile.delete()
        }

        FileOutputStream(outputFile).use { out ->
            pdfDocument.writeTo(out)
        }

        pdfDocument.close()
        return outputFile
    }
}
