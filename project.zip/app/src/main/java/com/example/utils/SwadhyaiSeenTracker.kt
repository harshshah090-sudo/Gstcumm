package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.SwadhyaiFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object SwadhyaiSeenTracker {
    private const val PREFS_NAME = "swadhyai_device_seen_prefs"
    private const val KEY_PREFIX = "seen_ts_"
    private const val KEY_INSTALL_BASELINE = "app_install_baseline_ts"

    private val _seenUpdateSignal = MutableStateFlow(0L)
    val seenUpdateSignal: StateFlow<Long> = _seenUpdateSignal.asStateFlow()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    /**
     * Gets the timestamp when the app was installed / initialized on this device.
     * Existing registrations present on app installation will not show red dots.
     */
    fun getInstallBaselineTimestamp(context: Context): Long {
        return AppInstallTracker.getInstallBaselineTimestamp(context)
    }

    fun getSeenTimestamp(context: Context, swadhyaiId: Long): Long {
        return getPrefs(context).getLong("$KEY_PREFIX$swadhyaiId", 0L)
    }

    /**
     * Mark a swadhyai as seen/viewed on this device.
     */
    fun markSwadhyaiSeen(context: Context, swadhyaiId: Long, timestamp: Long = System.currentTimeMillis()) {
        getPrefs(context).edit().putLong("$KEY_PREFIX$swadhyaiId", timestamp).apply()
        _seenUpdateSignal.value = timestamp
    }

    /**
     * Checks if this swadhyai registration is brand new or was updated since last viewed on this device.
     * On app install, existing registrations will NOT show a red dot.
     * A red dot will only appear if a new swadhyai registration is created or an existing registration is updated.
     * If the registration belongs to the currently logged in user, it will NOT show a red dot for themselves.
     */
    fun isUnreadOrUpdated(
        context: Context,
        swadhyai: SwadhyaiFormEntity,
        currentUserPhone: String = com.example.data.UserSessionManager.getCurrentPhone()
    ): Boolean {
        // If this profile belongs to the currently logged-in user, do not show red dot to themselves
        if (currentUserPhone.isNotBlank()) {
            val userClean = currentUserPhone.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
            val swadhyaiCleanWhatsapp = swadhyai.whatsappNo.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
            val swadhyaiCleanContact = swadhyai.contactNo.replace("+91", "").replace("[^0-9]".toRegex(), "").takeLast(10)
            if (userClean.isNotBlank() && (swadhyaiCleanWhatsapp == userClean || swadhyaiCleanContact == userClean)) {
                return false
            }
        }

        val seenTimestamp = getSeenTimestamp(context, swadhyai.id)
        if (seenTimestamp == 0L) {
            val baseline = getInstallBaselineTimestamp(context)
            // Only show red dot if created or updated after app installation
            val isNewAfterInstall = swadhyai.createdAt > baseline
            val isUpdatedAfterInstall = swadhyai.updatedAt > baseline
            return isNewAfterInstall || isUpdatedAfterInstall
        }
        val latestTimestamp = if (swadhyai.updatedAt > 0L) swadhyai.updatedAt else swadhyai.createdAt
        return latestTimestamp > seenTimestamp
    }

    /**
     * Returns whether any swadhyai in the list has an unread red-dot on this device.
     */
    fun hasAnyUnreadOrUpdated(
        context: Context,
        swadhyayis: List<SwadhyaiFormEntity>,
        currentUserPhone: String = com.example.data.UserSessionManager.getCurrentPhone()
    ): Boolean {
        return swadhyayis.any { isUnreadOrUpdated(context, it, currentUserPhone) }
    }

    /**
     * Returns a set of field keys that were updated and need red-dot highlight.
     */
    fun getUpdatedFieldKeys(
        context: Context,
        swadhyai: SwadhyaiFormEntity,
        currentUserPhone: String = com.example.data.UserSessionManager.getCurrentPhone()
    ): Set<String> {
        if (!isUnreadOrUpdated(context, swadhyai, currentUserPhone)) return emptySet()
        if (swadhyai.updatedFields.isBlank()) return emptySet()
        return swadhyai.updatedFields.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }
}
