package com.example.utils

import android.content.Context
import android.content.SharedPreferences
import com.example.data.SwadhyaiFormEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object SwadhyaiSeenTracker {
    private const val PREFS_NAME = "swadhyai_device_seen_prefs"
    private const val KEY_PREFIX = "seen_ts_"

    private val _seenUpdateSignal = MutableStateFlow(0L)
    val seenUpdateSignal: StateFlow<Long> = _seenUpdateSignal.asStateFlow()

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun getSeenTimestamp(context: Context, swadhyaiId: Long): Long {
        return getPrefs(context).getLong("$KEY_PREFIX$swadhyaiId", 0L)
    }

    /**
     * Mark a swadhyai as seen/viewed on this device.
     */
    fun markSwadhyaiSeen(context: Context, swadhyaiId: Long, timestamp: Long = System.currentTimeMillis()) {
        getPrefs(context).edit().putLong("$KEY_PREFIX$swadhyaiId", timestamp).apply()
        _seenUpdateSignal.value = timestamp
    }

    /**
     * Checks if this swadhyai registration is brand new or was updated since last viewed on this device.
     */
    fun isUnreadOrUpdated(context: Context, swadhyai: SwadhyaiFormEntity): Boolean {
        val seenTimestamp = getSeenTimestamp(context, swadhyai.id)
        if (seenTimestamp == 0L) {
            // Brand new registration never opened on this device
            return true
        }
        val latestTimestamp = if (swadhyai.updatedAt > 0L) swadhyai.updatedAt else swadhyai.createdAt
        return latestTimestamp > seenTimestamp
    }

    /**
     * Returns whether any swadhyai in the list has an unread red-dot on this device.
     */
    fun hasAnyUnreadOrUpdated(context: Context, swadhyayis: List<SwadhyaiFormEntity>): Boolean {
        return swadhyayis.any { isUnreadOrUpdated(context, it) }
    }

    /**
     * Returns a set of field keys that were updated and need red-dot highlight.
     */
    fun getUpdatedFieldKeys(context: Context, swadhyai: SwadhyaiFormEntity): Set<String> {
        if (!isUnreadOrUpdated(context, swadhyai)) return emptySet()
        if (swadhyai.updatedFields.isBlank()) return emptySet()
        return swadhyai.updatedFields.split(",").map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }
}
