import base64

with open('public/bill_logo_clean.png', 'rb') as f:
    b64_logo = base64.b64encode(f.read()).decode('utf-8')

with open('public/signature_trimmed.png', 'rb') as f:
    b64_sig = base64.b64encode(f.read()).decode('utf-8')

html_content = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tax Invoice - Shah Stores</title>
    <style>
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }}

        body {{
            background-color: #ECEFF1;
            color: #000000;
            font-family: Arial, Helvetica, sans-serif;
            font-size: 11px;
            line-height: 1.25;
            padding: 14px 6px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }}

        /* Top Action Bar */
        .action-bar {{
            width: 100%;
            max-width: 620px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #ffffff;
            padding: 10px 16px;
            border-radius: 8px;
            margin-bottom: 12px;
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
        }}

        .bar-brand {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            font-weight: bold;
            color: #002D62;
        }}

        .bar-brand img {{
            width: 28px;
            height: 28px;
            object-fit: contain;
        }}

        .btn-action {{
            background: #002D62;
            color: #ffffff;
            border: none;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }}

        .btn-action:hover {{
            background: #3B71CA;
        }}

        /* Sheet Wrapper: prevents mobile squishing and table collision */
        .sheet-wrapper {{
            width: 100%;
            max-width: 620px;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
            display: flex;
            justify-content: center;
        }}

        /* Main Tax Invoice Sheet Container (Matches A5 Layout exactly) */
        .invoice-sheet {{
            width: 100%;
            max-width: 620px;
            min-width: 520px;
            background: #ffffff;
            border: 2px solid #000000;
            box-shadow: 0 4px 14px rgba(0, 0, 0, 0.15);
            box-sizing: border-box;
            position: relative;
        }}

        /* Loading / Error States */
        .status-box {{
            padding: 50px 20px;
            text-align: center;
            font-family: Arial, sans-serif;
        }}

        .spinner {{
            width: 36px;
            height: 36px;
            border: 3px solid #ccc;
            border-top-color: #002D62;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
            margin: 0 auto 12px;
        }}

        @keyframes spin {{
            to {{ transform: rotate(360deg); }}
        }}

        /* Header Table: 24% Logo | 48% Firm Info | 28% Phone numbers */
        .header-table {{
            width: 100%;
            border-collapse: collapse;
            border-bottom: 1.5px solid #000000;
            table-layout: fixed;
        }}

        .header-logo-cell {{
            width: 24%;
            text-align: center;
            vertical-align: middle;
            padding: 6px 4px;
            overflow: hidden;
        }}

        .header-logo-cell img {{
            max-width: 68px;
            max-height: 56px;
            width: auto;
            height: auto;
            object-fit: contain;
            display: block;
            margin: 0 auto;
        }}

        .header-info-cell {{
            width: 48%;
            text-align: center;
            vertical-align: middle;
            padding: 6px 2px;
            overflow: hidden;
        }}

        .header-info-cell .firm-title {{
            font-size: 22px;
            font-weight: bold;
            letter-spacing: 0.2px;
            margin-bottom: 2px;
            color: #000000;
            line-height: 1.15;
        }}

        .header-info-cell .firm-address {{
            font-size: 10.5px;
            line-height: 1.35;
            color: #000000;
        }}

        .header-info-cell .firm-gstin {{
            font-size: 10.5px;
            font-weight: normal;
            margin-top: 2px;
            color: #000000;
        }}

        .header-phone-cell {{
            width: 28%;
            text-align: right;
            vertical-align: top;
            padding: 8px 10px 4px 2px;
            font-size: 10.5px;
            line-height: 1.45;
            overflow: hidden;
        }}

        /* TAX INVOICE Band */
        .tax-invoice-bar {{
            text-align: center;
            font-weight: bold;
            font-size: 13px;
            letter-spacing: 1px;
            padding: 4px 0;
            border-bottom: 1.5px solid #000000;
            background: #ffffff;
        }}

        /* Meta Section: Receiver (55%) & Invoice (45%) */
        .meta-table {{
            width: 100%;
            border-collapse: collapse;
            border-bottom: 1.5px solid #000000;
            table-layout: fixed;
        }}

        .meta-cell-left {{
            width: 55%;
            border-right: 1px solid #000000;
            vertical-align: top;
            padding: 4px 6px;
            overflow: hidden;
        }}

        .meta-cell-right {{
            width: 45%;
            vertical-align: top;
            padding: 4px 6px;
            overflow: hidden;
        }}

        .meta-section-title {{
            font-weight: bold;
            font-size: 10.5px;
            margin-bottom: 2px;
        }}

        .meta-sub-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            table-layout: fixed;
        }}

        .meta-sub-table td {{
            padding: 1.5px 0;
            vertical-align: top;
        }}

        .meta-sub-table td.lbl {{
            white-space: nowrap;
            overflow: hidden;
        }}

        .meta-sub-table td.colon {{
            width: 8px;
            text-align: center;
        }}

        .meta-sub-table td.val {{
            font-weight: normal;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }}

        /* Items Table: 8 Columns */
        .items-table {{
            width: 100%;
            border-collapse: collapse;
            border-bottom: 1.5px solid #000000;
            font-size: 10.5px;
            table-layout: fixed;
        }}

        .items-table th {{
            font-weight: bold;
            text-align: left;
            padding: 3.5px 4px;
            border-bottom: 1px solid #000000;
            border-right: 1px solid #000000;
            white-space: nowrap;
        }}

        .items-table th:last-child {{
            border-right: none;
        }}

        .items-table td {{
            padding: 2.5px 4px;
            border-right: 1px solid #000000;
            vertical-align: top;
            overflow: hidden;
        }}

        .items-table td:last-child {{
            border-right: none;
        }}

        .col-sn {{ width: 5%; text-align: center; }}
        .col-desc {{ width: 37%; }}
        .col-hsn {{ width: 12%; text-align: center; white-space: nowrap; }}
        .col-qty {{ width: 8%; text-align: center; }}
        .col-uom {{ width: 8%; text-align: center; }}
        .col-gst {{ width: 8%; text-align: center; }}
        .col-rate {{ width: 10%; text-align: right; }}
        .col-amt {{ width: 12%; text-align: right; }}

        .item-variant-text {{
            font-size: 8.5px;
            color: #444444;
            font-style: italic;
            margin-top: 1px;
        }}

        /* GST Breakdown Table: 6 Columns */
        .gst-table {{
            width: 100%;
            border-collapse: collapse;
            border-bottom: 1.5px solid #000000;
            font-size: 10px;
            table-layout: fixed;
        }}

        .gst-table th {{
            font-weight: bold;
            padding: 3px 5px;
            border-bottom: 1px solid #000000;
            border-right: 1px solid #000000;
            text-align: right;
            white-space: nowrap;
        }}

        .gst-table th:first-child {{
            text-align: left;
        }}

        .gst-table th:last-child {{
            border-right: none;
        }}

        .gst-table td {{
            padding: 2px 5px;
            border-right: 1px solid #000000;
            text-align: right;
            overflow: hidden;
        }}

        .gst-table td:first-child {{
            text-align: left;
        }}

        .gst-table td:last-child {{
            border-right: none;
        }}

        .gst-table tr.total-row td {{
            font-weight: bold;
            border-top: 1px solid #000000;
        }}

        /* Footer Section: 40% Bank & Terms | 20% QR | 40% Authorised Signatory */
        .footer-table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 10px;
            table-layout: fixed;
        }}

        .footer-cell-bank {{
            width: 40%;
            border-right: 1px solid #000000;
            vertical-align: top;
            padding: 4px 6px;
            box-sizing: border-box;
            overflow: hidden;
        }}

        .footer-cell-qr {{
            width: 20%;
            border-right: 1px solid #000000;
            vertical-align: middle;
            text-align: center;
            padding: 4px 2px;
            box-sizing: border-box;
            overflow: hidden;
        }}

        .footer-cell-sign {{
            width: 40%;
            vertical-align: top;
            padding: 4px 8px;
            text-align: right;
            box-sizing: border-box;
            overflow: hidden;
            position: relative;
        }}

        .bank-title {{
            font-weight: bold;
            font-size: 10.5px;
            margin-bottom: 2px;
        }}

        .terms-title {{
            font-weight: bold;
            font-size: 9.5px;
            margin-top: 3px;
            margin-bottom: 1px;
        }}

        .qr-image {{
            width: 55px;
            height: 55px;
            max-width: 55px;
            max-height: 55px;
            object-fit: contain;
            display: block;
            margin: 0 auto;
        }}

        .qr-label {{
            font-size: 8.5px;
            margin-top: 3px;
            text-align: center;
            white-space: nowrap;
        }}

        .for-firm-title {{
            font-weight: bold;
            font-size: 10.5px;
            margin-bottom: 2px;
            text-align: right;
        }}

        .signature-container {{
            height: 32px;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            margin: 1px 0;
            overflow: hidden;
        }}

        .signature-img {{
            max-height: 28px;
            max-width: 100px;
            width: auto;
            object-fit: contain;
            display: block;
        }}

        .sign-divider-line {{
            border-top: 1px solid #000000;
            width: 100%;
            margin: 2px 0;
        }}

        .signatory-label {{
            font-size: 9.5px;
            text-align: right;
        }}

        /* Print Specific Styling */
        @media print {{
            body {{
                background: #ffffff !important;
                padding: 0 !important;
                margin: 0 !important;
            }}

            .action-bar {{
                display: none !important;
            }}

            .sheet-wrapper {{
                max-width: 100% !important;
                width: 100% !important;
                display: block !important;
            }}

            .invoice-sheet {{
                box-shadow: none !important;
                border: 2px solid #000000 !important;
                max-width: 100% !important;
                width: 100% !important;
                min-width: 100% !important;
                margin: 0 !important;
                page-break-inside: avoid;
            }}

            @page {{
                size: A5 portrait;
                margin: 5mm;
            }}
        }}
    </style>
</head>
<body>

    <!-- Action Bar -->
    <div class="action-bar">
        <div class="bar-brand">
            <img id="barLogo" src="data:image/png;base64,{b64_logo}" alt="Logo">
            <span id="barFirmTitle">Shah Stores - Tax Invoice</span>
        </div>
        <button class="btn-action" onclick="window.print()">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 6 2 18 2 18 9"></polyline>
                <path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path>
                <rect x="6" y="14" width="12" height="8"></rect>
            </svg>
            Print / Save PDF
        </button>
    </div>

    <!-- Sheet Wrapper -->
    <div class="sheet-wrapper">

        <!-- Main Invoice Sheet -->
        <div class="invoice-sheet" id="invoiceSheet">

            <!-- Loading State -->
            <div id="loadingBox" class="status-box">
                <div class="spinner"></div>
                <div style="font-size: 13px; font-weight: bold; color: #555;">Loading Tax Invoice...</div>
            </div>

            <!-- Error State -->
            <div id="errorBox" class="status-box" style="display: none;">
                <div style="font-size: 36px; margin-bottom: 8px;">⚠️</div>
                <div id="errorTitle" style="font-size: 15px; font-weight: bold; color: #D32F2F; margin-bottom: 6px;">Invoice Not Found</div>
                <div id="errorMsg" style="font-size: 11px; color: #666; max-width: 320px; margin: 0 auto 16px;"></div>
                <div style="margin-top: 12px;">
                    <input type="text" id="manualInput" placeholder="Enter Bill / Serial No." style="padding: 6px 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 11px; width: 180px;">
                    <button onclick="lookupManualBill()" style="padding: 6px 12px; background: #002D62; color: #fff; border: none; border-radius: 4px; font-size: 11px; cursor: pointer; margin-left: 6px;">Search</button>
                </div>
            </div>

            <!-- Invoice Document Body -->
            <div id="invoiceBody" style="display: none;">

                <!-- Header Section -->
                <table class="header-table">
                    <tr>
                        <td class="header-logo-cell">
                            <img id="firmLogo" src="data:image/png;base64,{b64_logo}" alt="Shah Stores Logo">
                        </td>
                        <td class="header-info-cell">
                            <div class="firm-title" id="firmName">Shah Stores</div>
                            <div class="firm-address" id="firmAddress1">48, Shiv Vilas Palace, Rajwada, Indore</div>
                            <div class="firm-address" id="firmAddress2">(M.P.) - 452004</div>
                            <div class="firm-gstin" id="firmGstin">GSTIN : 23AHCPS6232M1Z6</div>
                        </td>
                        <td class="header-phone-cell">
                            <div id="phone1">9406667980</div>
                            <div id="phone2">9009253000</div>
                            <div id="phone3">9009254000</div>
                        </td>
                    </tr>
                </table>

                <!-- TAX INVOICE Band -->
                <div class="tax-invoice-bar">TAX INVOICE</div>

                <!-- Meta Section: Details of Receiver | Invoice Details -->
                <table class="meta-table">
                    <tr>
                        <!-- Receiver Details (55%) -->
                        <td class="meta-cell-left">
                            <div class="meta-section-title">Details of Receiver</div>
                            <table class="meta-sub-table">
                                <colgroup>
                                    <col style="width: 58px;">
                                    <col style="width: 8px;">
                                    <col style="width: auto;">
                                </colgroup>
                                <tr>
                                    <td class="lbl">Name</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="custName">Royal Collection</td>
                                </tr>
                                <tr>
                                    <td class="lbl">Address</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="custAddress">Raipur</td>
                                </tr>
                                <tr>
                                    <td class="lbl">GSTIN</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="custGstin">22ACDPV8068L1Z2</td>
                                </tr>
                                <tr>
                                    <td class="lbl">State</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="custState">Chhatisgarh</td>
                                </tr>
                            </table>
                        </td>

                        <!-- Invoice Details (45%) -->
                        <td class="meta-cell-right">
                            <table class="meta-sub-table">
                                <colgroup>
                                    <col style="width: 90px;">
                                    <col style="width: 8px;">
                                    <col style="width: auto;">
                                </colgroup>
                                <tr>
                                    <td class="lbl">INVOICE No.</td>
                                    <td class="colon">:</td>
                                    <td class="val"><strong id="invNo">SS/26-27/1626</strong></td>
                                </tr>
                                <tr>
                                    <td class="lbl">Date</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="invDate">31-Oct-2026</td>
                                </tr>
                                <tr>
                                    <td class="lbl">Transport Name</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="invTransport"></td>
                                </tr>
                                <tr>
                                    <td class="lbl">Mobile</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="invMobile"></td>
                                </tr>
                                <tr>
                                    <td class="lbl">Bundle</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="invBundle">1</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>

                <!-- Items Table (8 Columns with continuous vertical grid borders) -->
                <table class="items-table">
                    <thead>
                        <tr>
                            <th class="col-sn">S.N.</th>
                            <th class="col-desc">Item Description</th>
                            <th class="col-hsn">HSN Code</th>
                            <th class="col-qty">Qty</th>
                            <th class="col-uom">UOM</th>
                            <th class="col-gst">GST</th>
                            <th class="col-rate">Rate</th>
                            <th class="col-amt">Amount</th>
                        </tr>
                    </thead>
                    <tbody id="itemsBody">
                        <!-- Populated dynamically via JS -->
                    </tbody>
                </table>

                <!-- GST Breakdown Summary Table -->
                <table class="gst-table">
                    <thead>
                        <tr>
                            <th style="width: 19%;">GST Rate</th>
                            <th style="width: 19%;">Taxable Amount</th>
                            <th style="width: 14.3%;">CGST</th>
                            <th style="width: 14.3%;">SGST</th>
                            <th style="width: 14.3%;">IGST</th>
                            <th style="width: 19.1%;">Total Amount</th>
                        </tr>
                    </thead>
                    <tbody id="gstBody">
                        <!-- Populated dynamically via JS -->
                    </tbody>
                </table>

                <!-- Footer: Bank Details (40%) | QR Code (20%) | Signatory (40%) -->
                <table class="footer-table">
                    <colgroup>
                        <col style="width: 40%;">
                        <col style="width: 20%;">
                        <col style="width: 40%;">
                    </colgroup>
                    <tr>
                        <!-- Bank Details & Terms -->
                        <td class="footer-cell-bank">
                            <div class="bank-title">Bank Details</div>
                            <table class="meta-sub-table">
                                <colgroup>
                                    <col style="width: 54px;">
                                    <col style="width: 6px;">
                                    <col style="width: auto;">
                                </colgroup>
                                <tr>
                                    <td class="lbl">Bank</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="bankName">Punjab National Bank</td>
                                </tr>
                                <tr>
                                    <td class="lbl">Bank A/C</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="bankAccNo">9638002100000474</td>
                                </tr>
                                <tr>
                                    <td class="lbl">Bank IFSC</td>
                                    <td class="colon">:</td>
                                    <td class="val" id="bankIfsc">PUNB0963800</td>
                                </tr>
                            </table>
                            <div style="border-top: 1px solid #000000; margin: 4px 0 2px 0;"></div>
                            <div class="terms-title">Terms & Conditions</div>
                            <div style="font-size: 8.5px;" id="termsText">Subject to Indore Jurisdiction</div>
                        </td>

                        <!-- Center: QR Code -->
                        <td class="footer-cell-qr">
                            <img class="qr-image" id="qrCodeImg" src="" alt="QR">
                            <div class="qr-label">Scan QR to Pay</div>
                        </td>

                        <!-- Right: Signatory & Signature -->
                        <td class="footer-cell-sign">
                            <div class="for-firm-title" id="forFirmTitle">For SHAH STORES</div>
                            <div class="signature-container">
                                <img class="signature-img" id="signatureImg" src="data:image/png;base64,{b64_sig}" alt="Authorised Signature">
                            </div>
                            <div class="sign-divider-line"></div>
                            <div class="signatory-label">Authorised Signatory</div>
                        </td>
                    </tr>
                </table>

            </div>

        </div>

    </div>

    <!-- Data Loading & Rendering Script -->
    <script>
        const DEFAULT_LOGO = "data:image/png;base64,{b64_logo}";
        const DEFAULT_SIGNATURE = "data:image/png;base64,{b64_sig}";
        const RTDB_BASE = "https://shah-stores-default-rtdb.firebaseio.com";

        function getBillParams() {{
            const params = new URLSearchParams(window.location.search);
            const hash = window.location.hash.replace(/^#/, '');
            const hashParams = new URLSearchParams(hash);

            return {{
                sn: params.get('sn') || hashParams.get('sn'),
                billNo: params.get('billNo') || params.get('no') || hashParams.get('billNo') || hashParams.get('no'),
                data: hashParams.get('d') || params.get('d')
            }};
        }}

        function formatDisplayDate(dateStr) {{
            if (!dateStr) return '';
            try {{
                const clean = dateStr.replace(/[\/\.]/g, '-');
                const parts = clean.split('-');
                if (parts.length === 3) {{
                    let d = parts[0];
                    let m = parts[1];
                    let y = parts[2];
                    if (y.length === 2) y = '20' + y;
                    return `${{d}}-${{m}}-${{y}}`;
                }}
            }} catch (_) {{}}
            return dateStr;
        }}

        function renderBill(bill, firmInfo = {{}}) {{
            document.getElementById('loadingBox').style.display = 'none';
            document.getElementById('errorBox').style.display = 'none';
            document.getElementById('invoiceBody').style.display = 'block';

            // Firm Header
            const firmName = firmInfo.firmName || "Shah Stores";
            document.getElementById('firmName').innerText = firmName;
            document.getElementById('forFirmTitle').innerText = `For ${{firmName.toUpperCase()}}`;
            document.getElementById('barFirmTitle').innerText = `${{firmName}} - Tax Invoice`;

            // Always enforce the authentic clean SS bill logo
            const logoEl = document.getElementById('firmLogo');
            logoEl.src = DEFAULT_LOGO;
            logoEl.onerror = function() {{ this.src = DEFAULT_LOGO; }};

            const barLogoEl = document.getElementById('barLogo');
            if (barLogoEl) {{
                barLogoEl.src = DEFAULT_LOGO;
                barLogoEl.onerror = function() {{ this.src = DEFAULT_LOGO; }};
            }}

            // Always enforce authentic signature strictly within cell boundary
            const sigEl = document.getElementById('signatureImg');
            sigEl.src = DEFAULT_SIGNATURE;
            sigEl.onerror = function() {{ this.src = DEFAULT_SIGNATURE; }};

            // Address formatting: Clean split around (M.P.) without duplicate
            let fullAddr = firmInfo.firmAddress || "48, Shiv Vilas Palace, Rajwada, Indore (M.P.) - 452004";
            fullAddr = fullAddr.trim();
            if (fullAddr.includes("(M.P.)")) {{
                const idx = fullAddr.indexOf("(M.P.)");
                const line1 = fullAddr.substring(0, idx).trim().replace(/,\s*$/, "");
                const line2 = fullAddr.substring(idx).trim();
                document.getElementById('firmAddress1').innerText = line1;
                document.getElementById('firmAddress2').innerText = line2;
                document.getElementById('firmAddress2').style.display = 'block';
            }} else if (fullAddr.includes("\\n")) {{
                const parts = fullAddr.split(/\\r?\\n/).map(s => s.trim()).filter(Boolean);
                document.getElementById('firmAddress1').innerText = parts[0] || '48, Shiv Vilas Palace, Rajwada, Indore';
                document.getElementById('firmAddress2').innerText = parts[1] || '';
                document.getElementById('firmAddress2').style.display = parts[1] ? 'block' : 'none';
            }} else {{
                document.getElementById('firmAddress1').innerText = fullAddr;
                document.getElementById('firmAddress2').innerText = '';
                document.getElementById('firmAddress2').style.display = 'none';
            }}

            if (firmInfo.firmGstin) {{
                document.getElementById('firmGstin').innerText = `GSTIN : ${{firmInfo.firmGstin}}`;
            }}

            // Phone numbers
            document.getElementById('phone1').innerText = firmInfo.phoneNo1 || '9406667980';
            document.getElementById('phone2').innerText = firmInfo.phoneNo2 || '9009253000';
            document.getElementById('phone3').innerText = firmInfo.phoneNo3 || '9009254000';

            // Bank Details
            if (firmInfo.bankName) document.getElementById('bankName').innerText = firmInfo.bankName;
            if (firmInfo.bankAccNo) document.getElementById('bankAccNo').innerText = firmInfo.bankAccNo;
            if (firmInfo.bankIfsc) document.getElementById('bankIfsc').innerText = firmInfo.bankIfsc;

            // Customer Details
            const cust = bill.customer || {{}};
            const custName = bill.customerName || cust.name || 'Walk-in Customer';
            document.getElementById('custName').innerText = custName;
            document.getElementById('custAddress').innerText = cust.address || 'Burhanpur';
            document.getElementById('custGstin').innerText = cust.gstin || 'URD';
            
            const custState = cust.state || 'Madhya Pradesh';
            document.getElementById('custState').innerText = custState;

            // Invoice details
            document.getElementById('invNo').innerText = bill.billNo || 'N/A';
            document.getElementById('invDate').innerText = formatDisplayDate(bill.date) || '';
            document.getElementById('invTransport').innerText = cust.transport || bill.transport || '';
            document.getElementById('invMobile').innerText = cust.phoneNumber || cust.phone || bill.mobile || '';
            document.getElementById('invBundle').innerText = bill.bundle || '1';
            document.title = `Tax Invoice - ${{bill.billNo || firmName}}`;

            // Check if intra-state (MP)
            const isLocal = custState.toLowerCase().includes('madhya pradesh');

            // Items Processing
            const items = bill.items || [];
            const itemsBody = document.getElementById('itemsBody');
            itemsBody.innerHTML = '';

            let totalTaxable = 0;
            let totalCgst = 0;
            let totalSgst = 0;
            let totalIgst = 0;
            let grandTotal = 0;

            const gstBreakdown = {{}};

            if (items.length > 0) {{
                items.forEach((itemEntry, idx) => {{
                    const itemObj = itemEntry.item || {{}};
                    const name = itemObj.name || itemEntry.name || 'Item';
                    const hsn = itemObj.hsnCode || itemEntry.hsnCode || '-';
                    const uom = itemObj.uom || itemEntry.uom || 'Pcs';
                    const qty = parseFloat(itemEntry.quantity) || 0;
                    const rate = parseFloat(itemEntry.rate) || 0;
                    const taxable = qty * rate;

                    const gstRateRaw = String(itemObj.gstRate || itemEntry.gstRate || '5').replace('%', '').trim();
                    const gstRateVal = parseFloat(gstRateRaw) || 0;

                    let cgst = 0, sgst = 0, igst = 0;
                    if (isLocal) {{
                        cgst = taxable * (gstRateVal / 200.0);
                        sgst = taxable * (gstRateVal / 200.0);
                    }} else {{
                        igst = taxable * (gstRateVal / 100.0);
                    }}
                    const itemTotal = taxable + cgst + sgst + igst;

                    totalTaxable += taxable;
                    totalCgst += cgst;
                    totalSgst += sgst;
                    totalIgst += igst;
                    grandTotal += itemTotal;

                    const key = gstRateVal;
                    if (!gstBreakdown[key]) {{
                        gstBreakdown[key] = {{ taxable: 0, cgst: 0, sgst: 0, igst: 0, total: 0 }};
                    }}
                    gstBreakdown[key].taxable += taxable;
                    gstBreakdown[key].cgst += cgst;
                    gstBreakdown[key].sgst += sgst;
                    gstBreakdown[key].igst += igst;
                    gstBreakdown[key].total += itemTotal;

                    let variantHtml = '';
                    if (itemEntry.variantSelections && typeof itemEntry.variantSelections === 'object') {{
                        const parts = Object.entries(itemEntry.variantSelections).map(([k, v]) => `${{k}}/${{v}}`);
                        if (parts.length > 0) {{
                            variantHtml = `<div class="item-variant-text">${{parts.join(', ')}}</div>`;
                        }}
                    }}

                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td class="col-sn">${{idx + 1}}</td>
                        <td class="col-desc">
                            <div>${{name}}</div>
                            ${{variantHtml}}
                        </td>
                        <td class="col-hsn">${{hsn}}</td>
                        <td class="col-qty">${{qty}}</td>
                        <td class="col-uom">${{uom}}</td>
                        <td class="col-gst">${{gstRateVal}}%</td>
                        <td class="col-rate">${{rate.toFixed(2)}}</td>
                        <td class="col-amt">${{taxable.toFixed(2)}}</td>
                    `;
                    itemsBody.appendChild(tr);
                }});
            }} else {{
                const billAmt = parseFloat(bill.amount) || 0;
                totalTaxable = billAmt / 1.12;
                if (isLocal) {{
                    totalCgst = (billAmt - totalTaxable) / 2.0;
                    totalSgst = totalCgst;
                }} else {{
                    totalIgst = billAmt - totalTaxable;
                }}
                grandTotal = billAmt;

                gstBreakdown[12] = {{
                    taxable: totalTaxable,
                    cgst: totalCgst,
                    sgst: totalSgst,
                    igst: totalIgst,
                    total: billAmt
                }};

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="col-sn">1</td>
                    <td class="col-desc">Tax Invoice Items</td>
                    <td class="col-hsn">-</td>
                    <td class="col-qty">1</td>
                    <td class="col-uom">Ls</td>
                    <td class="col-gst">12%</td>
                    <td class="col-rate">${{totalTaxable.toFixed(2)}}</td>
                    <td class="col-amt">${{totalTaxable.toFixed(2)}}</td>
                `;
                itemsBody.appendChild(tr);
            }}

            // Continuous vertical grid spacer rows to match authentic PDF ledger format
            const filledRows = items.length > 0 ? items.length : 1;
            const targetRows = Math.max(12, filledRows);
            const emptyRowsToAdd = Math.max(0, targetRows - filledRows);

            for (let i = 0; i < emptyRowsToAdd; i++) {{
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="col-sn">&nbsp;</td>
                    <td class="col-desc">&nbsp;</td>
                    <td class="col-hsn">&nbsp;</td>
                    <td class="col-qty">&nbsp;</td>
                    <td class="col-uom">&nbsp;</td>
                    <td class="col-gst">&nbsp;</td>
                    <td class="col-rate">&nbsp;</td>
                    <td class="col-amt">&nbsp;</td>
                `;
                itemsBody.appendChild(tr);
            }}

            // GST Breakdown Table
            const gstBody = document.getElementById('gstBody');
            gstBody.innerHTML = '';

            const sortedRates = Object.keys(gstBreakdown).map(Number).sort((a, b) => a - b);
            sortedRates.forEach(rate => {{
                const row = gstBreakdown[rate];
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${{rate}}%</td>
                    <td>${{row.taxable.toFixed(2)}}</td>
                    <td>${{row.cgst.toFixed(2)}}</td>
                    <td>${{row.sgst.toFixed(2)}}</td>
                    <td>${{row.igst.toFixed(2)}}</td>
                    <td>${{row.total.toFixed(2)}}</td>
                `;
                gstBody.appendChild(tr);
            }});

            const totalTr = document.createElement('tr');
            totalTr.className = 'total-row';
            totalTr.innerHTML = `
                <td>Total</td>
                <td>${{totalTaxable.toFixed(2)}}</td>
                <td>${{totalCgst.toFixed(2)}}</td>
                <td>${{totalSgst.toFixed(2)}}</td>
                <td>${{totalIgst.toFixed(2)}}</td>
                <td>${{grandTotal.toFixed(2)}}</td>
            `;
            gstBody.appendChild(totalTr);

            // QR Code: support raw base64 from RTDB as well as data URIs / HTTP
            const qrImg = document.getElementById('qrCodeImg');
            if (firmInfo.qrCodeUrl && firmInfo.qrCodeUrl.length > 20) {{
                if (firmInfo.qrCodeUrl.startsWith('data:image') || firmInfo.qrCodeUrl.startsWith('http')) {{
                    qrImg.src = firmInfo.qrCodeUrl;
                }} else {{
                    qrImg.src = 'data:image/png;base64,' + firmInfo.qrCodeUrl;
                }}
            }} else {{
                const upiUrl = `upi://pay?pa=9406667980@paytm&pn=Shah%20Stores&am=${{grandTotal.toFixed(2)}}&cu=INR`;
                qrImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${{encodeURIComponent(upiUrl)}}`;
            }}
        }}

        async function fetchAndRender() {{
            const {{ sn, billNo, data }} = getBillParams();

            if (data) {{
                try {{
                    const jsonStr = decodeURIComponent(escape(atob(data)));
                    const parsed = JSON.parse(jsonStr);
                    renderBill(parsed);
                    fetchFirmInfo().then(info => {{ if (info) renderBill(parsed, info); }});
                    return;
                }} catch (e) {{
                    console.warn("Could not decode hash data", e);
                }}
            }}

            const firmInfoPromise = fetchFirmInfo();
            let billData = null;

            if (sn) {{
                try {{
                    const res = await fetch(`${{RTDB_BASE}}/bill_entries/${{sn}}.json`);
                    if (res.ok) {{
                        billData = await res.json();
                    }}
                }} catch (e) {{
                    console.error("Error fetching bill by sn", e);
                }}
            }}

            if (!billData && billNo) {{
                try {{
                    const res = await fetch(`${{RTDB_BASE}}/bill_entries.json?shallow=false`);
                    if (res.ok) {{
                        const allBills = await res.json();
                        if (allBills) {{
                            for (const k in allBills) {{
                                const b = allBills[k];
                                if (b && (b.billNo === billNo || b.billNo === decodeURIComponent(billNo))) {{
                                    billData = b;
                                    break;
                                }}
                            }}
                        }}
                    }}
                }} catch (e) {{
                    console.error("Error searching bill by billNo", e);
                }}
            }}

            const firmInfo = await firmInfoPromise;

            if (billData) {{
                renderBill(billData, firmInfo || {{}});
            }} else {{
                showError("Invoice Not Found", `Unable to find invoice ${{billNo || sn || ''}}. Please check the link or search manually.`);
            }}
        }}

        async function fetchFirmInfo() {{
            try {{
                const res = await fetch(`${{RTDB_BASE}}/firm_info.json`);
                if (res.ok) return await res.json();
            }} catch (_) {{}}
            return null;
        }}

        function showError(title, msg) {{
            document.getElementById('loadingBox').style.display = 'none';
            document.getElementById('invoiceBody').style.display = 'none';
            document.getElementById('errorBox').style.display = 'block';
            document.getElementById('errorTitle').innerText = title;
            document.getElementById('errorMsg').innerText = msg;
        }}

        function lookupManualBill() {{
            const val = document.getElementById('manualInput').value.trim();
            if (!val) return;
            window.location.search = `?sn=${{encodeURIComponent(val)}}`;
        }}

        window.addEventListener('DOMContentLoaded', fetchAndRender);
    </script>
</body>
</html>
'''

with open('public/view.html', 'w', encoding='utf-8') as f:
    f.write(html_content)

print("public/view.html written successfully, bytes:", len(html_content))
