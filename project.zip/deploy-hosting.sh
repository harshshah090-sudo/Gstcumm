#!/bin/bash
# Script to deploy Shah Stores web invoice viewer to Firebase Hosting
# Project: shah-stores
# Account: sureshshah090@gmail.com

set -e

echo "=== Shah Stores Web Viewer Deployment ==="
echo "Target Project: shah-stores"
echo "Public Directory: public/"

if ! command -v firebase &> /dev/null; then
    echo "Firebase CLI not found. Installing firebase-tools..."
    npm install -g firebase-tools
fi

echo "Deploying to Firebase Hosting..."
firebase deploy --only hosting --project shah-stores

echo ""
echo "=== Deployment Successful! ==="
echo "Your Web Invoice Viewer is now live at:"
echo "https://shah-stores.web.app/view.html"
echo "https://shah-stores.firebaseapp.com/view.html"
