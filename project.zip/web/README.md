# SVSS Web App (Exact Android App Mirror)

This is the installable Progressive Web App (PWA) mirroring the **SVSS Android application**. It starts directly on the **Login Screen** and replicates every feature and workflow from the native app for iOS (iPhone/iPad) and web browsers.

---

## 🌟 Key Features Mirrored from the Android App

1. **Authentication & Multi-Step Registration (`AuthAndRegistrationScreen`)**:
   - **Starts on Login Screen**: App opens on the phone verification screen.
   - **Instant Login for Existing Users**: Automatically queries Firestore `swadhyai_forms` by mobile number. If already registered, instantly logs in to the Home Dashboard with a personal greeting.
   - **Master Admin Recognition**: Recognizes `9009253000` and admin roles to grant administrative privileges.
   - **4-Step Registration for New Users**:
     - Step 1: Rules & Code of Conduct (नियम एवं आचार संहिता)
     - Step 2: Personal details (Name, Parents' names, DOB, Age calculation, Blood group, Education/Work)
     - Step 3: Contact details (Emergency mobile number, Full residential address, City, State, Pincode)
     - Step 4: Spiritual background (Paryushan Seva experience, Specialities: Pratikraman, Vaanchan, Vyakhyan, Samayik, Tapasya)

2. **Home Dashboard (`HomeScreen`)**:
   - **Top App Bar**: Greeting ("जय जिनेन्द्र, [Name] 🙏"), Role badge (व्यवस्थापक / स्वाध्यायी), Notification bell with unread badge, and Settings button.
   - **Live Jain Tithi & Kalyanak Card**: Live Tithi (भाद्रपद शुक्ल दशमी), sunrise/sunset times, and upcoming Parva countdown.
   - **Summary Stats Cards**:
     - 🏛️ **संघ आवेदन (Sangh Forms)**: Live count of submitted sangh forms.
     - 🙏 **स्वाध्यायी भाई (Swadhyai Directory)**: Live count of registered swadhyayis.
     - 💰 **मंडल कोष (Mandal Fund)**: Total balance with Bank vs Cash breakdown.
     - 🤝 **संघ आवंटन (Allotments)**: Live allotment numbers.
   - **Quick Action Pills**: "नया संघ फॉर्म", "स्वाध्यायी फॉर्म", "डिजिटल पंचांग", "नई घोषणा".
   - **Mandal Timeline Feed**: Live announcements from `timeline_posts` with share action and Admin post creation.

3. **Gyan Shala (`GyanScreen`)**:
   - Circular reorderable categories grid with drag-and-drop finger tracking, golden glow, and unread red dots.
   - Category topics subscreen.
   - Full-screen Reading Modal with rich typography.
   - Docked floating Audio Player with timeline scrubber, play/pause, 10s skip, and lock-screen Web MediaSession controls for iOS.

4. **Registrations & Directory (`RegistrationsScreen`)**:
   - **संघ आवेदन (Sangh Forms)**: List of applications with search, required swadhyai count, and direct call action.
   - **स्वाध्यायी भाई (Swadhyai Directory)**: List of registered brothers with seva history, city/state, phone, and direct Call & WhatsApp buttons.
   - **संघ आवंटन (Sangh Allotments)**: List of all allotted sanghs with assigned swadhyai brothers.

5. **Digital Panchang (`DigitalPanchangScreen`)**:
   - Jain calendar overview (Vir Samvat 2552 / Vikram Samvat 2082).
   - Daily Choghadiya (Amrit, Shubh, Labh, Char).
   - Upcoming Parva & Kalyanaks (Paryushan Mahaparva, Samvatsari, Oli).

6. **Profile (`ProfileScreen`)**:
   - User profile card with phone, role badge.
   - Seva history and personal information.
   - Links to History Archives, About Us, Settings.
   - **लॉगआउट (Logout)**: Clears local session and returns to the Login screen.

7. **Modals & Secondary Views**:
   - Embedded Sangh Registration Form (`sangh.html`)
   - Embedded Swadhyai Registration Form (`swadhyai.html`)
   - Mandal Fund breakdown & transactions list
   - Registration History (2025, 2024 archives)
   - About Us & Mandal contacts
   - Settings & cache manager

---

## 📱 How to Install on iPhone / iPad (iOS)

1. Open `https://svsm-a67d9.web.app` in **Safari** on your iPhone or iPad.
2. Tap the **Share** button (the square with an arrow pointing upward ⬆ at the bottom of Safari).
3. Scroll down and tap **"Add to Home Screen"** (⊞).
4. Tap **Add** in the top-right corner.
5. The **SVSS** app icon will appear on your iPhone home screen! Tapping it opens full-screen without any browser address bar, running identically to a native iOS app.

---

## 🚀 Deployment to Firebase Hosting

To deploy your updated web app to Firebase Hosting:

1. Navigate to the `web` folder in your terminal:
   ```bash
   cd web
   ```
2. Deploy to Firebase:
   ```bash
   firebase deploy --only hosting
   ```
   *(If prompted, log in with `firebase login` using the Google account owning `svsm-a67d9`)*
