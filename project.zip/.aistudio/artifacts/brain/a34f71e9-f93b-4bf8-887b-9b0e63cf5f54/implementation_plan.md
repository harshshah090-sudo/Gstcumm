# Implementation Plan - Aesthetic Firm Information Screen & Image Display Fix

The Firm Information screen will be redesigned to present firm details aesthetically using modern Material 3 cards, a branded header, and a dedicated media card for uploaded images (Firm Logo, QR Code, and Owner's Signature), while resolving the bug preventing base64-encoded images from displaying.

---

## 1. Problem Diagnosis: Why Images Are Not Showing

1. **Base64 Data URLs Incompatibility with Coil**:
   * Images uploaded via `FirmInfoRepository.kt` are compressed and converted into base64 data URLs in the format `data:image/png;base64,<payload>`.
   * Coil's `rememberAsyncImagePainter(model = ...)` does not natively decode data URI strings or `data:` URIs created by `Uri.parse()`. Because no custom DataFetcher was supplied, Coil fails silently and leaves the image blank.
2. **Lack of Structure and Styling in Display View**:
   * `FirmInfoDisplayView` currently renders raw text elements in an unstyled LazyColumn with no cards, badges, or clear section hierarchy.
   * Image previews were hardcoded to raw 100.dp boxes without framing, labels, or empty state indicators.

---

## 2. Proposed Changes

### A. Image Decoding & Rendering Utility
* Create a dedicated helper `decodeBase64OrUrlBitmap(imageSource: String?)` and a Composable `FirmImagePreview`:
  * Detects `data:image/` or raw base64 data and decodes it via `android.util.Base64.decode` into an Android `Bitmap`.
  * If a normal http/https URL is passed, loads via Coil's `rememberAsyncImagePainter`.
  * If a local `Uri` is passed (during edit/crop mode), handles it seamlessly.
  * Adds error handling, loading indicator, and placeholder graphic.

### B. Aesthetic Redesign of `FirmInfoDisplayView` (View Mode)
Structure the screen into organized, cohesive Material 3 cards adhering to the app's primary teal (`#0F766E`) theme:

1. **Hero Header Card**:
   * Deep teal gradient/container banner.
   * Prominently displays **Firm Name** (bold title), **Tagline** in italicized contrast, and a circular framed **Firm Logo** badge.
2. **Business & Contact Details Card**:
   * **Address**: Accompanied by a location pin icon.
   * **GSTIN**: Styled in a mono-spaced badge with registration scheme type.
   * **Contact Numbers**: Phone 1, Phone 2, and Phone 3 with phone icons.
3. **Banking Details Card**:
   * Styled card with bank icon.
   * Bank Name, Account Number, and IFSC Code.
4. **Dedicated Visual Assets Card**:
   * A unified visual media section showcasing:
     * **Firm Logo**: Centered rounded emblem with subtitle "Firm Logo".
     * **Payment QR Code**: Square high-contrast framed preview with subtitle "Payment QR Code".
     * **Owner's Signature**: Framed preview with subtle border and subtitle "Authorized Signature".
   * For any asset not yet uploaded, displays an elegant dashed outline placeholder with "No image uploaded".

### C. Polish of `FirmInfoEditView` (Edit Mode)
* Update image upload rows in edit mode to display instant thumbnail previews of the current/newly selected images.
* Keep the existing UCrop square cropping tool for QR code uploads and image picker launchers.

---

## 3. Files Impacted

* `app/src/main/java/com/example/shahstores/screens/FirmInformationScreen.kt`:
  * Implement base64 decoding helper and `FirmImagePreview` composable.
  * Completely revamp `FirmInfoDisplayView` with modern cards, hero header, and media card.
  * Update `FirmInfoEditView` to ensure selected and existing images display reliably.

---

## 4. Verification Plan

1. **Build & Compilation**:
   * Run `compile_applet` to ensure syntax, imports, and Compose layouts compile cleanly without errors.
2. **Visual & Functional Verification**:
   * Verify that existing or newly uploaded Firm Logo, QR Code, and Signature render clearly in both Display mode and Edit mode.
   * Verify that text formatting (Firm Name, Address, GSTIN, Phone numbers, Bank details) displays without truncation.
   * Verify switching between View Mode and Edit Mode works smoothly, and saving retains all fields and images.
