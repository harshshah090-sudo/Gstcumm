import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import java.lang.reflect.Method;

public class TestIText {
    public static void main(String[] args) {
        for (Method m : Document.class.getMethods()) {
            if (m.getName().equals("setMargins")) {
                System.out.println(m);
            }
        }
    }
}
